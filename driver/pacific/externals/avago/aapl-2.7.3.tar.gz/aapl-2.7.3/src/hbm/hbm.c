/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* AAPL (ASIC and ASSP Programming Layer) diagnostic/test support. */

/** Doxygen File Header */
/** @file */
/** @brief HBM functions. */
/** @defgroup HBM Functions */
/** @{ */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_HBM

/* 1500 Commands */
#define START_WIR_WRITE 0x1
#define START_WDR_WRITE 0x2
#define START_WDR_READ  0x4
#define SHIFT_WRITE_WDR 0xa
#define SHIFT_READ_WDR  0xc
#define STOP_1500       0x0

/* HBM Misc */
#define HBM_SEL 1
#define PHY_SEL 0

/* WDR Definitions */
#define PHY_MMT_CONFIG                 0x16
#define PHY_MMT_CONFIG_LENGTH          440
#define PHY_CTC_ID                     0x16
#define PHY_CTC_ID_LENGTH              8   
#define PHY_SOFT_LANE_REPAIR           0x12
#define PHY_SOFT_LANE_REPAIR_LENGTH    72 
#define HBM_TEMP                       0xf 
#define HBM_TEMP_LENGTH                8
#define HBM_MODE_REG_DUMP_SET          0x10
#define HBM_MODE_REG_DUMP_SET_LENGTH   128

#define HBM_CTC_IDCODE                 0x0f
#define HBM_STOP_IDCODE                0x10


int avago_hbm_default_timeout = 15000;

/*============================================================================= */
/* AVAGO HBM FW CHECK */
/** */
/** @brief  Verify firmware has been loaded */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr   Sbus address of the spico */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
static int avago_hbm_fw_check(Aapl_t *aapl, uint spico_addr)
{
  avago_firmware_get_rev(aapl, spico_addr); /* check rev, which will update spico_running */
  if( !aapl_get_spico_running_flag(aapl, spico_addr) ) {
    aapl_fail(aapl, __func__, __LINE__, "HBM operation cannot run because the firmware has not been loaded or SPICO at address %s is not running.\n", aapl_addr_to_str(spico_addr));
    return -1;
  }
  return 0;
}


/*============================================================================= */
/* AVAGO HBM WAIT FOR 1500 DONE */
/** */
/** @brief  Waits for the 1500 BUSY DONE register to equal the expected value */
/** */
/** @param  aapl       Aapl_t struct */
/** @param  apc_addr   sbus_address of the APC receiver */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
static int avago_hbm_wait_for_1500_done(Aapl_t *aapl, uint apc_addr, uint expected_value)
{
  uint timeout = 15000;
  uint done_value = (expected_value ^ 1) & 0x1;

  while ((done_value != expected_value) && timeout > 0) {
    done_value = avago_sbus_rd(aapl, apc_addr, 0x12); /* BUSY_DONE_1500_REG */
    done_value = done_value & 0x1;
    timeout = timeout - 1;
  }

  if (timeout == 0) {
    aapl_fail(aapl, __func__, __LINE__, "HBM operation timed out while waiting for 1500 DONE at APC addr 0x%02x.\n", apc_addr);
  }

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO HBM APC 1500 BUSY DONE HANDSHAKE */
/** */
/** @brief  Performs a 1500 operation handshake to ensure the command was accepted */
/** */
/** @param  aapl       Aapl_t struct */
/** @param  apc_addr   sbus_address of the APC receiver */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
static int avago_hbm_apc_1500_busy_done_handshake(Aapl_t *aapl, uint apc_addr)
{
  avago_hbm_wait_for_1500_done(aapl, apc_addr, 1);
  avago_sbus_wr(aapl, apc_addr, 0x10, STOP_1500); /* CONTROL_1500 */
  avago_sbus_wr(aapl, apc_addr, 0x0f, 0);         /* LENGTH/SHIFT_ONLY */
  avago_hbm_wait_for_1500_done(aapl, apc_addr, 0);
  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO HBM WIR WRITE CHANNEL */
/** */
/** @brief  Sets the IEEE 1500 WIR */
/** */
/** @param  aapl        Aapl_t struct */
/** @param  apc_addr    sbus_address of the APC receiver */
/** @param  channel     HBM channel to write to */
/** @param  instruction WIR instruction */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
static int avago_hbm_wir_write_channel(Aapl_t *aapl, uint apc_addr, uint hbm_phy_sel, uint channel, uint instruction)
{
  /*aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Writing 1500 instruction 0x%02x on channel %d to APC at address 0x%02x \n", instruction, channel, apc_addr); */
  avago_sbus_wr(aapl, apc_addr, 0x02, ((hbm_phy_sel << 12) | (channel << 8) | instruction));  /* WIR_REG */
  avago_sbus_wr(aapl, apc_addr, 0x10, START_WIR_WRITE); /* CONTROL_1500 */
  avago_hbm_apc_1500_busy_done_handshake(aapl, apc_addr);

  return aapl->return_code;
}

/*============================================================================= */
/* AVAGO HBM WDR WRITE DATA */
/** */
/** @brief  Performs a WDR write operation */
/** */
/** @param  aapl       Aapl_t struct */
/** @param  apc_addr   sbus_address of the APC receiver */
/** @param  control_1500   1500 write instruction */
/** @param  length         WIR length */
/** @param  word_count     Number of 32-data words to write */
/** @param  ...            Data words */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
/*static int avago_hbm_wdr_write_data(Aapl_t *aapl, uint apc_addr, int control_1500, int length, int word_count, ...) */
/*{ */
/*  int word; */
/*  va_list data_words; */
/*  va_start(data_words, word_count); */
/* */
/*  //aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Writing 1500 data of length %d to APC at address 0x%02x \n", length, apc_addr); */
/*  for (word = 0; word < word_count; word++) { */
/*    avago_sbus_wr(aapl, apc_addr, word+4, va_arg(data_words, int)); // WDR_WRITE_DATA_* */
/*  } */
/*  va_end(data_words); */
/* */
/*  avago_sbus_wr(aapl, apc_addr, 0x10, ((length<<4) | control_1500)); // CONTROL_1500 */
/*  avago_hbm_apc_1500_busy_done_handshake(aapl, apc_addr); */
/* */
/*  return aapl->return_code; */
/* */
/*} */


/*============================================================================= */
/* AVAGO HBM WDR READ */
/** */
/** @brief  Performs a WDR read operation */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  apc_addr     sbus_address of the APC receiver */
/** @param  control_1500 Read operation type */
/** @param  length       WIR length */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
static int avago_hbm_wdr_read(Aapl_t *aapl, uint apc_addr, int length, int shift_only)
{
  if (aapl_get_process_id(aapl, apc_addr) == AVAGO_TSMC_16) {
    avago_sbus_wr(aapl, apc_addr, 0x10, STOP_1500);
    avago_sbus_wr(aapl, apc_addr, 0x10, ((length<<4) | START_WDR_READ));
    avago_hbm_apc_1500_busy_done_handshake(aapl, apc_addr);

  } else {
    avago_sbus_wr(aapl, apc_addr, 0x0f, (length | (shift_only<<9)));
    avago_sbus_wr(aapl, apc_addr, 0x10, STOP_1500);
    avago_sbus_wr(aapl, apc_addr, 0x10, START_WDR_READ);
    avago_hbm_apc_1500_busy_done_handshake(aapl, apc_addr);
  }
  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO HBM FIRMWARE DMEM READ SUPPORTED */
/** */
/** @brief  Returns TRUE if the HBM firmware supports dmem reads */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr   Sbus address of the spico */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
static BOOL avago_hbm_firmware_dmem_read_supported(Aapl_t *aapl, uint spico_addr)
{
  uint fw_revision;
  uint fw_build_id;

  fw_revision =  avago_sbm_get_firmware_rev(aapl, spico_addr);
  fw_build_id = avago_sbm_get_firmware_build_id(aapl, spico_addr);

  if (fw_build_id == 0x2002 && fw_revision < 0x550) {
    return FALSE;
  } else {
    return TRUE;
  }
}


/*============================================================================= */
/* AVAGO HBM SBUS RING HAS APC */
/** */
/** @brief  Returns TRUE if the spico ring has an APC block */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr   Sbus address of the spico */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
/*static BOOL avago_hbm_sbus_ring_has_apc(Aapl_t *aapl, uint spico_addr) */
/*{ */
/*  uint sbus; */
/*  Avago_addr_t addr_struct; */
/*  avago_addr_to_struct(spico_addr, &addr_struct); */
/* */
/*  for( sbus = 1; sbus <= aapl->max_sbus_addr[addr_struct.chip][addr_struct.ring]; sbus++ ) */
/*  { */
/*    uint addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, sbus); */
/*    if( aapl_get_ip_type(aapl, addr) == AVAGO_APC ) { */
/*      return TRUE; */
/*    } */
/*  } */
/* */
/*  return FALSE; */
/*} */


/*============================================================================= */
/* AVAGO HBM GET SPICO ADDRESS */
/** */
/** @brief  Returns the SPICO sbus address if either an APC or SPICO address is provided */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr   Sbus address of the spico or apc */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
static uint avago_hbm_get_spico_address(Aapl_t *aapl, uint spico_addr)
{
  if (aapl_check_ip_type(aapl, spico_addr, __func__, __LINE__, FALSE, 1, AVAGO_APC)) {
    spico_addr = avago_make_sbus_master_addr(spico_addr);
  }

  if (!aapl_check_ip_type(aapl, spico_addr, __func__, __LINE__, FALSE, 1, AVAGO_SPICO)) {
    Avago_ip_type_t ip_type = aapl_get_ip_type(aapl, spico_addr);
    aapl_fail(aapl, __func__, __LINE__, "The address 0x%0x is not a SPICO or APC address.  IP Type = %d\n", spico_addr, ip_type);
  }

  return spico_addr;
}


/*============================================================================= */
/* AVAGO HBM READ LFSR COMPARE STICKY */
/** */
/** @brief  Reads the stored LFSR COMPARE STICKY results saved by firmware.  A */
/*          AWORD/DWORD firmware operation must have been run prior to calling this */
/*          function. Note this firmware is very specific to firmware implementation may */
/*          vary based on firmware version.  This is intended for debug use only. */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr   Sbus address of the spico */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
static int avago_hbm_read_lfsr_compare_sticky(Aapl_t *aapl, uint spico_addr, int hbm_not_phy, int result_group, const char * prefix)
{
  uint base_addr;
  uint channel;

  if (avago_hbm_firmware_dmem_read_supported(aapl, spico_addr) == FALSE) {
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   LFSR_COMPARE_STICKY diagnostics not supported with this version of firmware\n");
    return 0;
  }

  base_addr = 0x0518;

  for( channel = 0;  channel < 8; channel++ ) {
    uint xdmem_start;
    uint lfsr_31_0;
    uint lfsr_63_42;
    uint lfsr_95_64;
    uint lfsr_127_96;
    uint lfsr_159_128;
    uint lfsr_191_160;

    xdmem_start = base_addr + 12*channel + 96*result_group;

    lfsr_31_0 = avago_spico_int(aapl, spico_addr, 0x37, xdmem_start);
    lfsr_31_0 = lfsr_31_0 | (avago_spico_int(aapl, spico_addr, 0x37, xdmem_start+1) << 16);
    lfsr_63_42 = avago_spico_int(aapl, spico_addr, 0x37, xdmem_start+2);
    lfsr_63_42 = lfsr_63_42 | (avago_spico_int(aapl, spico_addr, 0x37, xdmem_start+3) << 16);
    lfsr_95_64 = avago_spico_int(aapl, spico_addr, 0x37, xdmem_start+4);
    lfsr_95_64 = lfsr_95_64 | (avago_spico_int(aapl, spico_addr, 0x37, xdmem_start+5) << 16);
    lfsr_127_96 = avago_spico_int(aapl, spico_addr, 0x37, xdmem_start+6);
    lfsr_127_96 = lfsr_127_96 | (avago_spico_int(aapl, spico_addr, 0x37, xdmem_start+7) << 16);
    lfsr_159_128 = avago_spico_int(aapl, spico_addr, 0x37, xdmem_start+8);
    lfsr_159_128 = lfsr_159_128 | (avago_spico_int(aapl, spico_addr, 0x37, xdmem_start+9) << 16);
    lfsr_191_160 = avago_spico_int(aapl, spico_addr, 0x37, xdmem_start+10);
    lfsr_191_160 = lfsr_191_160 | (avago_spico_int(aapl, spico_addr, 0x37, xdmem_start+11) << 16);

    /* PHY LFSR_COMPARE_STICKY = 184 btis */
    /* HBM LFSR_COMPARE_STICKY = 175 btis */
    if (hbm_not_phy == 1) {
      lfsr_191_160 = lfsr_191_160 & 0x3fff;
    } else {
      lfsr_191_160 = lfsr_191_160 & 0x7fffff;
    }

    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   %s Channel:%d LFSR_COMPARE: 0x%06x%08x%08x%08x%08x%08x\n",
        prefix,
        channel,
        lfsr_191_160, lfsr_159_128, lfsr_127_96, lfsr_95_64, lfsr_63_42, lfsr_31_0);
  }
  return 0;
}


/*============================================================================= */
/* AVAGO HBM ERROR CODE DESC */
/** */
/** @brief  Returns a string description of the integer error code */
/** @param  error_code    error code integer */
/** */
/** @return  Error code description */
static const char * avago_hbm_error_code_desc(uint error_code)
{
  const char * desc;

  switch(error_code) {
    case 0x00: { desc =  "NO_ERROR";                                   break; }
    case 0x01: { desc =  "ERROR_DETECTED";                             break; }
    case 0x02: { desc =  "ERROR_UNEXPECTED_RESET_STATE";               break; }
    case 0x03: { desc =  "ERROR_ILLEGAL_CHANNEL_NUMBER";               break; }
    case 0x04: { desc =  "ERROR_TIMEOUT_WAITING_FOR_1500_DONE";        break; }
    case 0x05: { desc =  "ERROR_TIMEOUT_WAITING_FOR_BIST_DONE";        break; }
    case 0x06: { desc =  "ERROR_DATA_COMPARE_FAILED";                  break; }
    case 0x07: { desc =  "ERROR_ALL_CHANNELS_NOT_SELECTED_FOR_RESET";  break; }
    case 0x08: { desc =  "ERROR_REPAIR_LIMIT_EXCEEDED";                break; }
    case 0x09: { desc =  "ERROR_NON_REPAIRABLE_FAULTS_FOUND";          break; }
    case 0x0a: { desc =  "ERROR_MBIST_FAILED";                         break; }
    case 0x0b: { desc =  "ERROR_EXCEEDED_BANK_REPAIR_LIMIT";           break; }
    case 0x0c: { desc =  "ERROR_ALL_CHANNELS_NOT_ENABLED";             break; }
    case 0x0d: { desc =  "ERROR_TIMEOUT_WAITING_FOR_PHYUPD_HANDSHAKE"; break; }
    case 0x0e: { desc =  "ERROR_CHANNEL_UNREPAIRABLE";                 break; }
    case 0x0f: { desc =  "ERROR_NO_FUSES_AVAILBALE_FOR_REPAIR";        break; }
    case 0x10: { desc =  "ERROR_TIMEOUT_WAITING_FOR_VALID_TEMP";       break; }
    case 0x11: { desc =  "ERROR_CHANNEL_FAILURES_EXIST";               break; }
    case 0x12: { desc =  "ERROR_UNKNOWN_ERROR";                        break; }
    case 0x13: { desc =  "ERROR_TIMEOUT_WAITING_FOR_NWL_INIT";         break; }
    case 0x14: { desc =  "ERROR_CTC_WRITE_READ_COMPARE_FAILURE";       break; }
    case 0x15: { desc =  "ERROR_CTC_NO_WRITES_PERFORMED";              break; }
    case 0x16: { desc =  "ERROR_CTC_NO_READS_PERFORMED";               break; }
    case 0x17: { desc =  "ERROR_LANE_ERRORS_DETECTED";                 break; }
    case 0x18: { desc =  "ERROR_CTC_TIMEOUT_WAITING_FOR_CTC_BUSY";     break; }
    case 0x19: { desc =  "ERROR_UNSUPPORTED_HBM_CONFIGURATION";        break; }
    case 0x1a: { desc =  "ERROR_HBM_MISR_PRESET_FAILED";               break; }
    case 0x1b: { desc =  "ERROR_PHY_MISR_PRESET_FAILED";               break; }
    case 0x1c: { desc =  "ERROR_CORE_POWERON_RST_L_ASSERTED";          break; }
    case 0x1d: { desc =  "ERROR_UNSUPPORTED_INTERRUPT";                break; }
    case 0x1e: { desc =  "ERROR_EXTEST_SLB_FAILURE";                   break; }
    default:   { desc =  "UNKNOWN_ERROR_CODE";                         break; }
  }
  return desc;
}


/*============================================================================= */
/* AVAGO HBM OPERATION DESC */
/** */
/** @brief  Returns a string description of the integer operation code */
/** @param  operation_code    operation code integer */
/** */
/** @return  Error code description */
static const char * avago_hbm_operation_desc(uint operation_code)
{
  const char * desc;

  switch(operation_code) {
    case 0x00: { desc = "OP_SUCCESS";             break; }
    case 0x01: { desc = "OP_BYPASS";              break; }
    case 0x02: { desc = "OP_DEVICE_ID";           break; }
    case 0x03: { desc = "OP_AWORD";               break; }
    case 0x04: { desc = "OP_AERR";                break; }
    case 0x05: { desc = "OP_AWORD_ILB";           break; }
    case 0x06: { desc = "OP_AERR_ILB";            break; }
    case 0x07: { desc = "OP_AERR_INJ_ILB";        break; }
    case 0x08: { desc = "OP_DWORD_WRITE";         break; }
    case 0x09: { desc = "OP_DWORD_READ";          break; }
    case 0x0a: { desc = "OP_DERR";                break; }
    case 0x0b: { desc = "OP_DWORD_UPPER_ILB";     break; }
    case 0x0c: { desc = "OP_DWORD_LOWER_ILB";     break; }
    case 0x0d: { desc = "OP_DERR_ILB";            break; }
    case 0x0e: { desc = "OP_DERR_IBJ_ILB";        break; }
    case 0x0f: { desc = "OP_LANE_REPAIR";         break; }
    case 0x10: { desc = "OP_DEVICE_TEMP";         break; }
    case 0x11: { desc = "OP_CONNECTIVITY_CHECK";  break; }
    case 0x12: { desc = "OP_RESET";               break; }
    case 0x13: { desc = "OP_MBIST";               break; }
    case 0x14: { desc = "OP_BITCELL_REPAIR";      break; }
    case 0x15: { desc = "OP_AWORD_SLB";           break; }
    case 0x16: { desc = "OP_AERR_SLB";            break; }
    case 0x17: { desc = "OP_AERR_INJ_SLB";        break; }
    case 0x18: { desc = "OP_DWORD_UPPER_SLB";     break; }
    case 0x19: { desc = "OP_DWORD_LOWER_SLB";     break; }
    case 0x1a: { desc = "OP_DERR_SLB";            break; }
    case 0x1b: { desc = "OP_DERR_INJ_SLB";        break; }
    case 0x1c: { desc = "OP_TMRS";                break; }
    case 0x1d: { desc = "OP_CHIPPING";            break; }
    case 0x1e: { desc = "OP_MC_INIT";             break; }
    case 0x1f: { desc = "OP_CTC_OR_MMT";          break; }
    case 0x20: { desc = "OP_APPLY_LANE_REPAIR";   break; }
    case 0x21: { desc = "OP_BURN_LANE_REPAIR";    break; }
    case 0x22: { desc = "OP_CATTRIP";             break; }
    case 0x23: { desc = "OP_FUSE_SCAN";           break; }
    case 0x24: { desc = "OP_EXTEST_SLB";          break; }
    default :  { desc = "UNKNOWN_OPERATION";      break; }
  }
  return desc;
}


/*============================================================================= */
/* AVAGO HBM READ MBIST RESULTS */
/** */
/** @brief  Read the MBIST repair results from xdmem */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr   Sbus address of the spico */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
static int avago_hbm_read_mbist_results(Aapl_t *aapl, uint spico_addr, uint manufacturer_id)
{
  uint base_addr;
  uint channel;
  uint repair_num;
  uint xdmem_addr;
  uint repair_15_0;
  uint repair_31_16;
  uint repair;
  uint repair_en;
  uint row;
  uint bank;
  uint sid;
  uint sid_num;
  uint pc;
  uint dual_dq;


  if (avago_hbm_firmware_dmem_read_supported(aapl, spico_addr) == FALSE) {
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MBIST detailed diagnostics not supported with this version of firmware\n");
    return 0;
  }

  base_addr = 0x0518;

  for( channel = 0;  channel < 8; channel++ ) {
    for( sid_num = 0;  sid_num < 2; sid_num++ ) {
      for( repair_num = 0;  repair_num < 8; repair_num++ ) {

        /*xdmem_addr = base_addr + (repair_num*2) + (channel * 16 * 2); */
        xdmem_addr = base_addr + ( ((sid_num<<3) | channel ) * 16 * 2) + (repair_num*2);

        repair_15_0 = avago_spico_int(aapl, spico_addr, 0x37, xdmem_addr);
        repair_31_16 = avago_spico_int(aapl, spico_addr, 0x37, xdmem_addr+1);
        repair = (repair_31_16 << 16) | repair_15_0;

        repair_en = 0;
        if (manufacturer_id == 0x1) { /* SAMSUNG */
          repair_en = (repair >> 20) & 0x1;
        } else if (manufacturer_id == 0x6) { /* SKH */
          repair_en = repair & 0x1;
        }

        /* Check if repair is valid */
        if (repair_en == 1) {
          if (manufacturer_id == 0x1) {
            row     = repair & 0x3fff; 
            bank    = (repair >> 14) & 0xf;
            pc      = (repair >> 18) & 0x1;
            sid     = (repair >> 19) & 0x1;
            dual_dq = (repair >> 21) & 0x1;
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Channel:%d Repair:%d Row:%d Bank:%d PC:%d SID:%d DUAL_DQ:%d\n",
                channel, repair_num, row, bank, pc, sid, dual_dq);

          } else if (manufacturer_id == 0x6) { /* SKH */
            row  = (repair >> 1) & 0x1fff;
            bank = (repair >> 14) & 0xf;
            sid  = (repair >> 18) & 0x1;
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Channel:%d Repair:%d Row:%d Bank:%d SID:%d\n",
                channel, repair_num, row, bank, sid);
          }
        }
      }
    }
  }

  return 0;
}


/*============================================================================= */
/* AVAGO HBM SET PARAMETER */
/** */
/** @brief  Sets an hbm parameter in firmware */
/** */
/** @param  aapl       Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @param  param      Parameter number to set */
/** @param  value      Parameter value to set */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_set_parameter(Aapl_t *aapl, uint spico_addr, Avago_hbm_parameter_t param, uint value)
{
  uint result;
  uint status;

  /* Set the parameter number */
  result = avago_spico_int(aapl, spico_addr, 0x34, param);
  status = result >> 16;

  if (status == 0x7fff) {
    aapl_fail(aapl, __func__, __LINE__, "Illegal HBM parameter number, %d.\n", param);
    return aapl->return_code;
  }

  /* Set the parameter value */
  avago_spico_int(aapl, spico_addr, 0x35, value);

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO HBM GET PARAMETER */
/** */
/** @brief  Gets an HBM firmware parameter */
/** */
/** @param  aapl       Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @param  param      Parameter number to get */
/** */
/** @return  Returns the parameter value.  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_get_parameter(Aapl_t *aapl, uint spico_addr, Avago_hbm_parameter_t param)
{
  uint result;
  uint data;
  uint status;

  /* Set the parameter number */
  result = avago_spico_int(aapl, spico_addr, 0x33, param);
  data = result & 0xffff;
  status = result >> 16;

  if (status == 0x7fff) {
    aapl_fail(aapl, __func__, __LINE__, "Illegal HBM parameter number, %d.\n", param);
    return aapl->return_code;
  }

  return data;
}


/*============================================================================= */
/* AVAGO HBM LAUNCH OPERATION */
/** */
/** @brief  Launches an HBM operation on all PHY/HBM channels */
/** */
/** @param  aapl       Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @param  operation  Operations to run */
/** @param  results    Results structure */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_launch_operation(
    Aapl_t *aapl, 
    uint spico_addr, 
    Avago_hbm_operation_t operation, 
    Avago_hbm_operation_results_t *results,
    int max_timeout)
{
  return avago_hbm_launch_channel_operation(aapl, spico_addr, operation, results, 0xf, max_timeout);
}


/*============================================================================= */
/* AVAGO HBM LAUNCH CHANNEL_OPERATION */
/** */
/** @brief  Launches an HBM operation on a single PHY/HBM channel */
/** */
/** @param  aapl       Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @param  operation  Operations to run */
/** @param  results    Results structure /// @param  channel    Channel number to run on */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_launch_channel_operation(
    Aapl_t *aapl, 
    uint spico_addr, 
    Avago_hbm_operation_t operation, 
    Avago_hbm_operation_results_t *results, 
    uint channel,
    int max_timeout)
{

  int timeout = 0;
  uint result;
  uint status;
  int rc;

  Avago_addr_t addr_struct;
  avago_addr_to_struct(spico_addr, &addr_struct);

  /* Initialize the results */
  memset(results, 0, sizeof(*results));


  /* accepts either a spico or APC address */
  rc = aapl->return_code;
  spico_addr = avago_hbm_get_spico_address(aapl, spico_addr);
  if (aapl->return_code != rc) { return -1; }

  /* Is firmware loaded */
  if (avago_hbm_fw_check(aapl, spico_addr) != 0) {
    return -1;
  }

  /* Start the operation */
  if (channel == 0xf) {
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Begin HBM operation 0x%02x for all channels on SBus ring %d \n", operation, addr_struct.ring);
    result = avago_spico_int(aapl, spico_addr, 0x30, operation);
  } else {
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Begin HBM operation 0x%02x for channel%d on SBus ring %d \n", channel, addr_struct.ring);
    result = avago_spico_int(aapl, spico_addr, 0x31, ((channel << 8) | operation));
  }
  status = result >> 16;


  if (status == 0x7fff) {
    aapl_fail(aapl, __func__, __LINE__, "HBM operation already in progress on SBus ring %d.\n", addr_struct.ring);
    return -1;
  }

  /* Wait for completion */
  /*   result[0] - Training Done */
  /*   result[1] - Training Active */
  /*   result[2] - Training Error Results */
  do {
    result = avago_spico_int(aapl, spico_addr, 0x32, 0x00);
    if (max_timeout != 0) { timeout += 1; }
  } while ((result & 0x03) != 0x01 && timeout <= max_timeout);

  aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "HBM operation result code: 0x%02x\n", result);

  /* Error if training timed out */
  if ((timeout >= max_timeout) && (max_timeout != 0)) {
    aapl_fail(aapl, __func__, __LINE__, "HBM operation timed out on SBus ring %d.\n", addr_struct.ring);
    return -1;
  }

  /* Error if training active/done not in expected state */
  if ((result & 0x03) != 0x01) {
    aapl_fail(aapl, __func__, __LINE__, "HBM training result produced an unexpected result: 0x%02x.\n", result);
    return -1;
  }

  /* If an error was found, read the channel error/operation codes */
  if ((result & 0x04) == 0x04) {
    avago_hbm_get_operation_results(aapl, spico_addr, results);
    /*avago_hbm_print_operation_results(aapl, results); */
    aapl_fail(aapl, __func__, __LINE__, "HBM operation 0x%02x failed on SBus ring %d.\n", operation, addr_struct.ring);
    return -1;

  } else {
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "HBM operation 0x%02x successfully completed on all channels on SBus ring %d \n", operation, addr_struct.ring);
    return 0;
  }

  return 0;
}


/*============================================================================= */
/* AVAGO HBM GET OPERATION RESULTS */
/** */
/** @brief  Reads the HBM channel errors code from firmware and stores the */
/*          results in the results struct */
/** */
/** @param  aapl       Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @param  results    Updated with the result of the operation */
/** */
/** @return Always returns 0 */
int avago_hbm_get_operation_results(Aapl_t *aapl, uint spico_addr, Avago_hbm_operation_results_t *results)
{
  int channel;

  results->global_error_code = avago_spico_int(aapl, spico_addr, 0x32, 0x01);
  for (channel = 0; channel <= 7; channel++) {
    results->channel_error_code[channel] = avago_spico_int(aapl, spico_addr, 0x32, 0x02+channel);
    results->channel_operation_code[channel]  = avago_spico_int(aapl, spico_addr, 0x32, 0x0a+channel);
  }

  return 0;
}


/*============================================================================= */
/* AVAGO HBM PRINT OPERATION RESULTS */
/** */
/** @brief  Print the operation results */
/** */
/** @param  aapl       Aapl_t struct */
/** @param  results    Operation results struct */
/** */
/** @return  0 */
int avago_hbm_print_operation_results(Aapl_t *aapl, Avago_hbm_operation_results_t *results)
{
  int channel;

  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   global_error_code:%s\n", 
      avago_hbm_error_code_desc(results->global_error_code));

  for (channel = 0; channel <= 7; channel++) {
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   channel:%1d error_code:%s\n", 
        channel, avago_hbm_error_code_desc(results->channel_error_code[channel]) );
  }

  for (channel = 0; channel <= 7; channel++) {
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   channel:%1d operation:%s\n", 
        channel, avago_hbm_operation_desc(results->channel_operation_code[channel]) );
  }

  return 0;
}


/*============================================================================= */
/* AVAGO HBM GET_APC_ADDR */
/** */
/** @brief  Retrieves the APC Address via firmware */
/** */
/** @param  spico_addr sbus_address of the sbus master spico */
/** */
/** @return  Error code description */
int avago_hbm_get_apc_addr(Aapl_t *aapl, uint spico_addr, uint *apc_addr)
{
  int rc;
  Avago_addr_t addr_struct;

  /* Accepts either a spico or APC address */
  rc = aapl->return_code;
  spico_addr = avago_hbm_get_spico_address(aapl, spico_addr);
  if (aapl->return_code != rc) { return -1; }

  /* Only run diagnostics if firmware is uploaded and running */
  if (avago_hbm_fw_check(aapl, spico_addr) != 0) {
    return -1;
  }

  /* Get APC address */
  avago_addr_to_struct(spico_addr, &addr_struct);
  *apc_addr = avago_spico_int(aapl, spico_addr, 0x36, 0);
  *apc_addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, *apc_addr);

  if (!aapl_check_ip_type(aapl, *apc_addr, __func__, __LINE__, FALSE, 1, AVAGO_APC)) {
    aapl_fail(aapl, __func__, __LINE__, "Firmware returned an invalid APC address: 0x%0x\n", *apc_addr);
    return -1;
  }

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO HBM READ DEVICE ID */
/** */
/** @brief  Retrieves the HBM device id for the HBM on the SBus ring */
/** */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @param  device_id  reference to a Avago_hbm_device_id_t struct */
/** */
/** @return  Error code description */
int avago_hbm_read_device_id(Aapl_t *aapl, uint spico_addr, Avago_hbm_device_id_t *device_id)
{
  uint device_id_15_0;
  uint device_id_31_16;
  uint device_id_47_32;
  uint device_id_64_48;
  uint device_id_79_64;
  uint device_id_82_80;
  int rc;
  Avago_hbm_operation_results_t results;

  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_READ_DEVICE_ID, &results, avago_hbm_default_timeout);
  if (rc != 0) { return -1; }

  device_id_15_0  = avago_spico_int(aapl, spico_addr, 0x32, 0x12);
  device_id_31_16 = avago_spico_int(aapl, spico_addr, 0x32, 0x13);
  device_id_47_32 = avago_spico_int(aapl, spico_addr, 0x32, 0x14);
  device_id_64_48 = avago_spico_int(aapl, spico_addr, 0x32, 0x15);
  device_id_79_64 = avago_spico_int(aapl, spico_addr, 0x32, 0x16);
  device_id_82_80 = avago_spico_int(aapl, spico_addr, 0x32, 0x17);

  /* Initialize the data struct to all zeros */
  memset(device_id, 0, sizeof(*device_id));

  device_id->value0 = ( device_id_31_16 << 16) | device_id_15_0;
  device_id->value1 = ( device_id_64_48 << 16) | device_id_47_32;
  device_id->value2 = ( device_id_82_80 << 16) | device_id_79_64;

  /* device_id[81] */
  device_id->gen2_test = device_id_82_80 >> 1;

  /* device_id[80] */
  device_id->ecc = device_id_82_80 & 0x1;

  /* device_id[79:76] */
  device_id->density = device_id_79_64 >> 12;

  /* device_id[75:72] */
  device_id->manufacturer_id = (device_id_79_64 >> 8) & 0xf;

  /* device_id[71:68] */
  device_id->manufacturing_loc = (device_id_79_64 >> 4) & 0xf;

  /* device_id[67:60] */
  device_id->manufacturing_year = ((device_id_79_64 & 0xf) << 4) | ((device_id_64_48 >> 12) & 0xf);

  /* device_id[59:52] */
  device_id->manufacturing_week = (device_id_64_48 >> 4) & 0xff;

  /* device_id[51:18] */
  device_id->serial_number_31_0 = ((long) device_id_31_16 >> 2) | ((long) device_id_47_32 << 14) | ((device_id_64_48 & 0xfffff) << 30);
  device_id->serial_number_33_32 = (device_id_64_48 >> 2) & 0x3;

  /* device_id[17:16] */
  device_id->addressing_mode = device_id_31_16 & 0x3;

  /* device_id[15:8] */
  device_id->channel_available = (device_id_15_0 >> 8);

  /* device_id[7] */
  device_id->hbm_stack_height = (device_id_15_0 >> 7) & 1;

  /* device_id[6:0] */
  device_id->model_number = device_id_15_0 & 0x7f;

  return 0;
}


/*============================================================================= */
/* AVAGO HBM PRINT DEVICE ID */
/** */
/** @brief   Prints the HBM device id to the log  */
/** */
/** @param   spico_addr sbus_address of the sbus master spico */
/** */
/** @return  0 */
int avago_hbm_print_device_id(Aapl_t *aapl, uint spico_addr)
{
  Avago_hbm_device_id_t device_id;
  avago_hbm_read_device_id(aapl, spico_addr, &device_id);

  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "HBM Device ID: 0x%05x%08x%08x\n", 
      device_id.value2,
      device_id.value1,
      device_id.value0);

  if (device_id.gen2_test == 1) {
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Gen2 Features:      supported\n");
  } else {
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Gen2 Features:      not supported\n");
  }

  if (device_id.ecc == 1) {
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   ECC Support:        supported\n");
  } else {
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   ECC Support:        not supported\n");
  }

  switch(device_id.density) {
    case 0x01: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Density:            1Gb\n");     break; }
    case 0x02: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Density:            2Gb\n");     break; }
    case 0x03: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Density:            4Gb\n");     break; }
    case 0x04: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Density:            8Gb\n");     break; }
    case 0x05: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Density:            16Gb\n");    break; }
    case 0x06: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Density:            32Gb\n");    break; }
    default:   { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Density:            Unknown\n"); break; }
  }

  switch(device_id.manufacturer_id) {
    case 0x01: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Manufacturer ID:    Samsung\n");  break; }
    case 0x06: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Manufacturer ID:    SK Hynix\n"); break; }
    default:   { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Manufacturer ID:    Unknown\n");  break; }
  }

  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Manufacturer Loc:   %d\n", device_id.manufacturing_loc);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Manufacturer Year:  %d\n", 2011+device_id.manufacturing_year);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Manufacturer Week:  %d\n", device_id.manufacturing_week);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Serial Number:      0x%x%08lx\n", device_id.serial_number_33_32, device_id.serial_number_31_0);

  switch(device_id.addressing_mode) {
    case 0x01: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Addressing Mode:    Pseudo Channel Support\n");  break; }
    case 0x02: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Addressing Mode:    Legacy Mode Support\n");  break; }
    default:   { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Addressing Mode:    Unknown\n");  break; }
  }

  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Channels Available: 0x%02x\n", device_id.channel_available);

  switch(device_id.hbm_stack_height) {
    case 0x0: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   HBM Stack Height:   2 or 4 High Stack\n");  break; }
    case 0x1: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   HBM Stack Height:   8 High Stack\n");  break; }
  }

  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Model Number:       %d\n", device_id.model_number);

  return 0;
}


/*============================================================================= */
/* AVAGO HBM MRS */
/** */
/** @brief  Retrieves the HBM device id for the HBM on the SBus ring */
/** */
/** @param  spico_addr sbus_address of the sbus master spico */
/** */
/** @return  Error code description */
int avago_hbm_read_mrs(Aapl_t *aapl, uint spico_addr, Avago_hbm_mrs_t *mrs, uint channel)
{
  uint apc_addr;
  uint data;

  /* Get APC address */
  avago_hbm_get_apc_addr(aapl, spico_addr, &apc_addr);

  /* Initialize the data struct to all zeros */
  memset(mrs, 0, sizeof(*mrs));

  /* Read the MRS values via 1500 */
  avago_hbm_wir_write_channel(aapl, apc_addr, HBM_SEL, channel, HBM_MODE_REG_DUMP_SET);
  avago_hbm_wdr_read(aapl, apc_addr, HBM_MODE_REG_DUMP_SET_LENGTH, 0);
  avago_sbus_wr(aapl, apc_addr, 0x11, (1 << channel));

  data = avago_sbus_rd(aapl, apc_addr, 0x14);
  mrs->mr0 = data & 0xff;
  mrs->mr1 = (data >> 8) & 0xff;
  mrs->mr2 = (data >> 16) & 0xff;
  mrs->mr3 = (data >> 24) & 0xff;

  data = avago_sbus_rd(aapl, apc_addr, 0x15);
  mrs->mr4 = data & 0xff;
  mrs->mr5 = (data >> 8) & 0xff;
  mrs->mr6 = (data >> 16) & 0xff;
  mrs->mr7 = (data >> 24) & 0xff;

  data = avago_sbus_rd(aapl, apc_addr, 0x16);
  mrs->mr8 = data & 0xff;
  mrs->mr9 = (data >> 8) & 0xff;
  mrs->mr10 = (data >> 16) & 0xff;
  mrs->mr11 = (data >> 24) & 0xff;

  data = avago_sbus_rd(aapl, apc_addr, 0x17);
  mrs->mr12 = data & 0xff;
  mrs->mr13 = (data >> 8) & 0xff;
  mrs->mr14 = (data >> 16) & 0xff;
  mrs->mr15 = (data >> 24) & 0xff;

  return 0;
}


/*============================================================================= */
/* AVAGO HBM PRINT MRS */
/** */
/** @brief   Prints the HBM mode registers to the log  */
/** */
/** @param   spico_addr sbus_address of the sbus master spico */
/** */
/** @return  0 */
int avago_hbm_print_mrs(Aapl_t *aapl, uint spico_addr, uint channel)
{
  Avago_hbm_mrs_t mrs;
  uint dbiac_read;
  uint dbiac_write;
  uint tcsr;
  uint dq_read_parity;
  uint dq_write_parity;
  uint addr_cmd_parity;
  uint test_mode;
  uint write_recovery;
  uint drive_strength;
  uint wl;
  uint rl;
  uint ras;
  uint bank_group;
  uint bl;
  uint ecc;
  uint dm;
  uint pl;
  uint trr_mode_ban;
  uint trr_ps_select;
  uint trr;
  uint impre_trp;
  uint loopback;
  uint read_mux_ctrl;
  uint misr_ctrl;
  uint cattrip;
  uint da28_lockout;
  uint int_vref;

  avago_hbm_read_mrs(aapl, spico_addr, &mrs, channel);

  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "HBM MRS: 0x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x\n", 
      mrs.mr15,
      mrs.mr14,
      mrs.mr13,
      mrs.mr12,
      mrs.mr11,
      mrs.mr10,
      mrs.mr9,
      mrs.mr8,
      mrs.mr7,
      mrs.mr6,
      mrs.mr5,
      mrs.mr4,
      mrs.mr3,
      mrs.mr2,
      mrs.mr1,
      mrs.mr0);

  dbiac_read      = (mrs.mr0 >> 0) & 0x1;
  dbiac_write     = (mrs.mr0 >> 1) & 0x1;
  tcsr            = (mrs.mr0 >> 2) & 0x1;
  dq_read_parity  = (mrs.mr0 >> 4) & 0x1;
  dq_write_parity = (mrs.mr0 >> 5) & 0x1;
  addr_cmd_parity = (mrs.mr0 >> 6) & 0x1;
  test_mode       = (mrs.mr0 >> 7) & 0x1;
  write_recovery  = (mrs.mr1 >> 0) & 0x1f;
  drive_strength  = (mrs.mr1 >> 5) & 0x7;
  wl              = (mrs.mr2 >> 0) & 0x7;
  rl              = (mrs.mr2 >> 3) & 0x1f;
  ras             = (mrs.mr3 >> 0) & 0x3f;
  bank_group      = (mrs.mr3 >> 6) & 0x1;
  bl              = (mrs.mr3 >> 7) & 0x1;
  ecc             = (mrs.mr4 >> 0) & 0x1;
  dm              = (mrs.mr4 >> 1) & 0x1;
  pl              = (mrs.mr4 >> 2) & 0x3;
  trr_mode_ban    = (mrs.mr5 >> 0) & 0xf;
  trr_ps_select   = (mrs.mr5 >> 6) & 0x1;
  trr             = (mrs.mr5 >> 7) & 0x1;
  impre_trp       = (mrs.mr6 >> 3) & 0x1f;
  loopback        = (mrs.mr7 >> 0) & 0x1;
  read_mux_ctrl   = (mrs.mr7 >> 1) & 0x3;
  misr_ctrl       = (mrs.mr7 >> 3) & 0x7;
  cattrip         = (mrs.mr7 >> 7) & 0x1;
  da28_lockout    = (mrs.mr8 >> 0) & 0x1;
  int_vref        = (mrs.mr15 >> 0) & 0x7;

  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR0 -- %s\n", test_mode == 1 ? "Test Mode" : "Normal Mode");
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR0 -- Address, Command Parity %s\n", addr_cmd_parity == 1 ? "Enabled" : "Disabled");
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR0 -- DQ Bus Write Parity %s\n", dq_write_parity == 1 ? "Enabled" : "Disabled");
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR0 -- DQ Bus Read Parity %s\n", dq_read_parity == 1 ? "Enabled" : "Disabled");
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR0 -- Temp Compensated Self Refresh %s\n", tcsr == 1 ? "Enabled" : "Disabled");
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR0 -- Write DBIac %s\n", dbiac_write == 1 ? "Enabled" : "Disabled");
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR0 -- Read DBIac %s\n", dbiac_read == 1 ? "Enabled" : "Disabled");
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR1 -- Nominal Drive Strength = %d mA driver\n", drive_strength*3+6);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR1 -- Write Recovery WR = %d nCK\n", write_recovery);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR2 -- Read Latency = %d nCK\n", rl+2);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR2 -- Write Latency = %d nCK\n", wl+1);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR3 -- Burst Length = %d\n", bl == 1 ? 4 : 2);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR3 -- Bank Group %s\n", bank_group == 1 ? "Enabled" : "Disabled");
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR3 -- Activate to Precharge RAS = %d nCK\n", ras);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR4 -- Parity Latency = %d nCK\n", pl);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR4 -- DM %s\n", dm == 1 ? "Disabled" : "Enabled");
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR4 -- ECC %s\n", ecc == 1 ? "Enabled" : "Disabled");
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR5 -- TRR Mode %s\n", trr == 1 ? "Enabled" : "Disabled");
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR5 -- Enable TRR mode for Pseudo Channel %d\n", trr_ps_select);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR5 -- TRR Mode Bank %d\n", trr_mode_ban);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR6 -- imPRE tRP Value = %d nCK\n", impre_trp+2);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR7 -- %s CATTRIP\n", cattrip == 1 ? "Assert" : "Clear");

  switch(misr_ctrl) {
    case 0x0: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR7 -- Preset mode\n"); break; }
    case 0x1: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR7 -- LFSR mode (read)\n"); break; }
    case 0x2: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR7 -- Register mode\n"); break; }
    case 0x3: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR7 -- MISR mode\n"); break; }
    case 0x4: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR7 -- LFSR compare mode (write)\n"); break; }
  }

  switch(read_mux_ctrl) {
    case 0x0: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR7 -- Reserved DWORD Read Mux Control\n"); break; }
    case 0x1: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR7 -- Return data from MISR registers\n"); break; }
    case 0x2: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR7 -- Return data from Rx path sampler\n"); break; }
    case 0x3: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR7 -- Return LFSR_COMPARE_STICKY\n"); break; }
  }

  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR7 -- Loopback %s\n", loopback == 1 ? "Enabled" : "Disabled");
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR8 -- DA28 lockout %s\n", da28_lockout == 1 ? "Enabled" : "Disabled");

  switch(int_vref) {
    case 0x0: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR15 -- Internal Vref 50 percent VDD\n"); break; }
    case 0x1: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR15 -- Internal Vref 46 percent VDD\n"); break; }
    case 0x2: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR15 -- Internal Vref 42 percent VDD\n"); break; }
    case 0x3: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR15 -- Internal Vref 38 percent VDD\n"); break; }
    case 0x4: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR15 -- Internal Vref 54 percent VDD\n"); break; }
    case 0x5: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR15 -- Internal Vref 58 percent VDD\n"); break; }
    case 0x6: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR15 -- Internal Vref 62 percent VDD\n"); break; }
    case 0x7: { aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   MR15 -- Internal Vref 66 percent VDD\n"); break; }
  }

  return 0;
}


/*============================================================================= */
/* AVAGO HBM READ DEVICE TEMP */
/** */
/** @brief  Retrieves the HBM device id for the HBM on the SBus ring */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** */
/** @return  Error code description */
int avago_hbm_read_device_temp(Aapl_t *aapl, uint spico_addr)
{
  Avago_hbm_operation_results_t results;
  avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_READ_TEMPERATURE, &results, avago_hbm_default_timeout);
  return avago_spico_int(aapl, spico_addr, 0x32, 0x12);
}

/*============================================================================= */
/* AVAGO HBM PRINT CTC RESULTS */
/** */
/** @brief   */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  apc_addr sbus_address of the APC block */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
static int avago_hbm_print_ctc_results_by_addr(Aapl_t *aapl, uint ctc_addr, uint channel)
{
  uint ctc_option;
  uint total_writes;
  uint total_reads;
  uint error_count;
  const char * ctc_type;

  ctc_option = avago_sbus_rd(aapl, ctc_addr, 0xf);
  total_writes = avago_sbus_rd(aapl, ctc_addr, 0x07);
  total_reads  = avago_sbus_rd(aapl, ctc_addr, 0x08);
  error_count  = avago_sbus_rd(aapl, ctc_addr, 0xa8);

  switch(ctc_option) {
    case 0x0: { ctc_type = "DIV1"; break; }
    case 0x1: { ctc_type = "DIV2"; break; }
    case 0x2: { ctc_type = "DUAL_MUX"; break; }
    case 0x3: { ctc_type = "DP_PC0"; break; }
    case 0x4: { ctc_type = "DP_PC1"; break; }
    default:  { ctc_type = "UNKNOWN"; break; }
  }

  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Channel:%d CTC_Type:%-8s Writes:0x%08x Reads:0x%08x Errors:0x%08x\n", 
      channel, ctc_type, total_writes, total_reads, error_count);

  return ctc_option;
}


/*============================================================================= */
/* AVAGO HBM HAS CTC */
/** */
/** @brief  Returns true if CTC blocks are includes on the sbus ring */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr   sbus_address of the spico */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
BOOL avago_hbm_has_ctc(Aapl_t *aapl, uint spico_addr)
{
  uint sbus;
  Avago_addr_t addr_struct;
  avago_addr_to_struct(spico_addr, &addr_struct);

  for( sbus = 1; sbus <= aapl->max_sbus_addr[addr_struct.chip][addr_struct.ring]; sbus++ )
  {
    uint addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, sbus);
    if( aapl_get_ip_type(aapl, addr) == AVAGO_DDR_CTC ) {
      return TRUE;
    }
  }

  return FALSE;
}

/*============================================================================= */
/* AVAGO HBM PRINT CTC RESULTS */
/** */
/** @brief  Prints CTC read/write/error results */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  apc_addr sbus_address of the APC block */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_print_ctc_results(Aapl_t *aapl, uint apc_addr)
{
  uint channel;


  for (channel = 0; channel <= 7; channel++) {
    uint ctc_addr;
    uint idcode;
    uint ctc_option;
    Avago_addr_t addr_struct;

    avago_hbm_wir_write_channel(aapl, apc_addr, PHY_SEL, channel, PHY_CTC_ID);
    avago_hbm_wdr_read(aapl, apc_addr, PHY_CTC_ID_LENGTH, 0);
    avago_sbus_wr(aapl, apc_addr, 0x11, (1 << channel));  /* READ_CHANNEL */

    /* Get sbus address of the stop block associated with this channel. */
    /* The generated CTC_ID always points to the second sbus device in the */
    /* ctc/stop block (which may be a stop or ctc).   */
    avago_addr_to_struct(apc_addr, &addr_struct);
    ctc_addr = avago_sbus_rd(aapl, apc_addr, 0x14) & 0xff;
    ctc_addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, ctc_addr);

    idcode = avago_sbus_rd(aapl, ctc_addr, 0xff);
    if (idcode == HBM_STOP_IDCODE) {
      ctc_addr = ctc_addr - 1;
    }
    ctc_option = avago_hbm_print_ctc_results_by_addr(aapl, ctc_addr, channel);

    if (ctc_option == 4) {
      ctc_option = avago_hbm_print_ctc_results_by_addr(aapl, ctc_addr-1, channel);
    }

  }

  return 0;
}

/*============================================================================= */
/* AVAGO HBM RUN MBIST DIAGNOSTICS */
/** */
/** @brief  Runs just the MBIST operation and reports extended dianostic info for any failures */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico or APC */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_run_mbist_diagnostics(Aapl_t *aapl, uint spico_addr)
{
  int rc;
  Avago_hbm_device_id_t device_id;
  Avago_hbm_operation_results_t results;
  uint apc_addr;
  Avago_addr_t addr_struct;
  uint fw_build_id;
  uint fw_revision;

  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "AAPL_version: %s, compiled %s %s\n", AAPL_VERSION, __DATE__, __TIME__);

  /* accepts either a spico or APC address */
  rc = aapl->return_code;
  spico_addr = avago_hbm_get_spico_address(aapl, spico_addr);
  if (aapl->return_code != rc) { return -1; }

  /* Only run diagnostics if firmware is uploaded and running */
  if (avago_hbm_fw_check(aapl, spico_addr) != 0) {
    return -1;
  }

  avago_addr_to_struct(spico_addr, &addr_struct);

  /* Get the firmware version */
  fw_revision =  avago_sbm_get_firmware_rev(aapl, spico_addr);
  fw_build_id = avago_sbm_get_firmware_build_id(aapl, spico_addr);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Firmware Revision: 0x%04x\n", fw_revision);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Firmware Build ID: 0x%04x\n", fw_build_id);



  /* Get APC address */
  apc_addr = avago_spico_int(aapl, spico_addr, 0x36, 0);
  apc_addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, apc_addr);

  if (!aapl_check_ip_type(aapl, apc_addr, __func__, __LINE__, FALSE, 1, AVAGO_APC)) {
    aapl_fail(aapl, __func__, __LINE__, "Firmware returned an invalid APC address: 0x%0x\n", apc_addr);
    return -1;
  }


  /* Device ID */
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RESET, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test Reset: %s\n", rc == 0 ? "PASS" : "FAIL");

  rc = avago_hbm_read_device_id(aapl, spico_addr, &device_id);
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
  } else {
    avago_hbm_print_device_id(aapl, spico_addr);
  }


  /* Run MBIST */
  /* Note: Old firmware included MBIST in the core image, but only limited */
  /*       MBIST patterns.  The core FW image is 0x2002 and 0x9002/0x1002. */
  /*       Newer firmware supports additional tests.  The new MBIST firwmare is */
  /*       0x2012 and 0x9012/0x1012 */
  if (device_id.manufacturer_id == 1) {
    avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_MBIST_PATTERN, 0);
    rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RUN_SAMSUNG_MBIST, &results, 0);
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test SAMSUNG SCAN MBIST: %s\n", rc == 0 ? "PASS" : "FAIL");
    if (rc != 0) {
      avago_hbm_print_operation_results(aapl, &results);
    }
    avago_hbm_read_mbist_results(aapl, spico_addr, device_id.manufacturer_id);

    if (fw_build_id == 0x2012 || fw_build_id == 0x9012 || fw_build_id == 0x1012 || (fw_build_id == 0x1002 && fw_revision >= 0xa)) {
      avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_MBIST_PATTERN, 1);
      rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RUN_SAMSUNG_MBIST, &results, 0);
      aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test SAMSUNG MARCH MBIST: %s\n", rc == 0 ? "PASS" : "FAIL");
      if (rc != 0) {
        avago_hbm_print_operation_results(aapl, &results);
      }
      avago_hbm_read_mbist_results(aapl, spico_addr, device_id.manufacturer_id);
    }

  } else if (device_id.manufacturer_id == 6) {
    if (fw_build_id == 0x2002 || fw_build_id == 0x9002 || (fw_build_id == 0x1002 && fw_revision < 0xa)) {
      avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_MBIST_PATTERN, 0);
      rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RUN_SKH_MBIST, &results, 0);
      aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test SKH PAUSE MBIST: %s\n", rc == 0 ? "PASS" : "FAIL");
      if (rc != 0) {
        avago_hbm_print_operation_results(aapl, &results);
      }
      avago_hbm_read_mbist_results(aapl, spico_addr, device_id.manufacturer_id);

      avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_MBIST_PATTERN, 1);
      rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RUN_SKH_MBIST, &results, 0);
      aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test SKH GROSS MBIST: %s\n", rc == 0 ? "PASS" : "FAIL");
      if (rc != 0) {
        avago_hbm_print_operation_results(aapl, &results);
      }
      avago_hbm_read_mbist_results(aapl, spico_addr, device_id.manufacturer_id);

    } else {
      avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_MBIST_PATTERN, 0);
      rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RUN_SKH_MBIST, &results, 0);
      aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test SKH YMC MBIST: %s\n", rc == 0 ? "PASS" : "FAIL");
      if (rc != 0) {
        avago_hbm_print_operation_results(aapl, &results);
      }
      avago_hbm_read_mbist_results(aapl, spico_addr, device_id.manufacturer_id);

      avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_MBIST_PATTERN, 1);
      rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RUN_SKH_MBIST, &results, 0);
      aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test SKH GROSS MBIST: %s\n", rc == 0 ? "PASS" : "FAIL");
      if (rc != 0) {
        avago_hbm_print_operation_results(aapl, &results);
      }
      avago_hbm_read_mbist_results(aapl, spico_addr, device_id.manufacturer_id);

      avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_MBIST_PATTERN, 2);
      rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RUN_SKH_MBIST, &results, 0);
      aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test SKH XMC MBIST: %s\n", rc == 0 ? "PASS" : "FAIL");
      if (rc != 0) {
        avago_hbm_print_operation_results(aapl, &results);
      }
      avago_hbm_read_mbist_results(aapl, spico_addr, device_id.manufacturer_id);
    }
  }

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO HBM CTC START */
/** */
/** @brief  Start the CTC running the requested pattern type */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico or APC */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_ctc_start(Aapl_t *aapl, uint spico_addr, int pattern_type, int init)
{
  int rc;
  Avago_hbm_device_id_t device_id;
  Avago_hbm_operation_results_t results;
  uint apc_addr;


  /* Get the apc address */
  avago_hbm_get_apc_addr(aapl, spico_addr, &apc_addr);

  /* Reset if init is being run */
  if (init == 1) {
    rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RESET, &results, avago_hbm_default_timeout);
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test Reset: %s\n", rc == 0 ? "PASS" : "FAIL");
  }

  /* Device ID */
  rc = avago_hbm_read_device_id(aapl, spico_addr, &device_id);
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
  } else {
    avago_hbm_print_device_id(aapl, spico_addr);
  }

  /* Initialize the memory controller */
  if (init == 1) {
    rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RESET, &results, avago_hbm_default_timeout);
    if (rc != 0) {
      avago_hbm_print_operation_results(aapl, &results);
    }
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test RESET: %s\n", rc == 0 ? "PASS" : "FAIL");

    rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_INITIALIZE_NWL_MCS, &results, avago_hbm_default_timeout);
    if (rc != 0) {
      avago_hbm_print_operation_results(aapl, &results);
    }
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test INIT NWL: %s\n", rc == 0 ? "PASS" : "FAIL");
  }

  /* Set the pattern type */
  avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_CTC_PATTERN_TYPE, pattern_type);

  /* Start running CTC */
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_START_CTC, &results, avago_hbm_default_timeout);
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
  }
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test CTC START: %s\n", rc == 0 ? "PASS" : "FAIL");


  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO HBM CTC STOP */
/** */
/** @brief  Stop the CTC running */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico or APC */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_ctc_stop(Aapl_t *aapl, uint spico_addr)
{
  int rc;
  Avago_hbm_operation_results_t results;
  uint apc_addr;


  /* Get the apc address */
  avago_hbm_get_apc_addr(aapl, spico_addr, &apc_addr);

  /* Stop the CTC test */
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_STOP_CTC, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test CTC: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_print_ctc_results(aapl, apc_addr);
  }

  /*avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RELEASE_CTC_CONTROL, &results, avago_hbm_default_timeout); */

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO HBM RUN DIAGNOSTICS */
/** */
/** @brief  Runs all firmware operations and report extended diagnostic info for any failures */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico or APC */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_run_diagnostics(Aapl_t *aapl, uint spico_addr)
{
  uint hbm_temp;
  uint count;
  uint repair_count;
  int rc;
  Avago_hbm_device_id_t device_id;
  Avago_hbm_operation_results_t results;
  uint apc_addr;
  uint fw_build_id;
  uint fw_revision;
  Avago_addr_t addr_struct;


  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "AAPL_version: %s, compiled %s %s\n", AAPL_VERSION, __DATE__, __TIME__);

  /* Only run diagnostics if firmware is uploaded and running */
  if (avago_hbm_fw_check(aapl, spico_addr) != 0) {
    return -1;
  }

  /* Get the apc address */
  avago_hbm_get_apc_addr(aapl, spico_addr, &apc_addr);

  avago_addr_to_struct(spico_addr, &addr_struct);

  /* Get the build id */
  fw_revision =  avago_sbm_get_firmware_rev(aapl, spico_addr);
  fw_build_id = avago_sbm_get_firmware_build_id(aapl, spico_addr);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Firmware Revision: 0x%04x\n", fw_revision);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Firmware Build ID: 0x%04x\n", fw_build_id);


  /* Device ID */
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RESET, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test Reset: %s\n", rc == 0 ? "PASS" : "FAIL");

  rc = avago_hbm_read_device_id(aapl, spico_addr, &device_id);
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
  } else {
    avago_hbm_print_device_id(aapl, spico_addr);
  }


  /* HBM Temperature */
  hbm_temp = avago_hbm_read_device_temp(aapl, spico_addr);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "HBM Temperature: %d\n", hbm_temp);


  /* Hard lane repairs */
  avago_hbm_print_hard_lane_repairs(aapl, spico_addr);

  /* Lane repairs / EXTEST_RX */
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_LANE_REPAIR, &results, avago_hbm_default_timeout); /* Print out number of repairs and repaired lanes */
  repair_count  = avago_spico_int(aapl, spico_addr, 0x32, 0x12);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Total Lane Faults: %d\n", repair_count);

  if (repair_count > 24) { repair_count = 24; }
  for (count = 1; count <= repair_count; count++) {
    uint repaired_lane;
    repaired_lane  = avago_spico_int(aapl, spico_addr, 0x32, 0x12+count);
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Lane Number: %d\n", repaired_lane);
  }
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test LANE REPAIR: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
  }


  /* Chipping test */
  if (device_id.manufacturer_id == 1) {
    rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_SAMSUNG_CHIPPING_TEST, &results, avago_hbm_default_timeout);
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test SAMSUNG CHIPPING: %s\n", rc == 0 ? "PASS" : "FAIL");
    if (rc != 0) {
      avago_hbm_print_operation_results(aapl, &results);
    }
  }

  /* PHY Loopback tests */
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_AWORD_ILB, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test AWORD ILB: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 0, "PHY");
  }

  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_DWORD_ILB, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test DWORD ILB: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 0, "DWORD_LOWER");
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 1, "DWORD_UPPER");
  }

  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_AERR_ILB, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test AERR ILB: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 0, "AERR_0");
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 1, "AERR_1");
  }

  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_DERR_ILB, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test DERR ILB: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 0, "PHY");
  }

  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_AWORD_SLB, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test AWORD SLB: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 0, "PHY");
  }

  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_DWORD_SLB, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test DWORD SLB: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 0, "DWORD_LOWER");
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 1, "DWORD_UPPER");
  }

  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_AERR_SLB, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test AERR SLB: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 0, "AERR_0");
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 1, "AERR_1");
  }

  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_DERR_SLB, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test DERR SLB: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 0, "PHY");
  }


  /* PHY-HBM 1500 Tests */
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_AWORD_TEST, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test AWORD: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, HBM_SEL, 0, "HBM");
  }

  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_AERR_TEST, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test AERR: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 0, "AERR_0");
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 1, "AERR_1");
  }

  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_DWORD_TEST, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test DWORD: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 0, "PHY");
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, HBM_SEL, 1, "HBM");
  }

  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_DERR_TEST, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test DERR: %s\n", rc ==  0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_read_lfsr_compare_sticky(aapl, spico_addr, PHY_SEL, 0, "PHY");
  }

  /* CATTRIP Test */
  if (fw_build_id == 0x2002 && fw_revision < 0x550) {
    /* skip CATTRIP */
  } else {
    rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_CATTRIP, &results, avago_hbm_default_timeout);
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test CATTRIP: %s\n", rc ==  0 ? "PASS" : "FAIL");
    if (rc != 0) {
      avago_hbm_print_operation_results(aapl, &results);
    }
  }

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO HBM RUN CTC DIAGNOSTICS */
/** */
/** @brief  Runs ctc diagnostics */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico or APC */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_run_ctc_diagnostics(Aapl_t *aapl, uint spico_addr, int do_reset, int do_init_nwl)
{
  int rc;
  Avago_hbm_device_id_t device_id;
  Avago_hbm_operation_results_t results;
  uint apc_addr;
  uint fw_build_id;
  uint fw_revision;
  Avago_addr_t addr_struct;


  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "AAPL_version: %s, compiled %s %s\n", AAPL_VERSION, __DATE__, __TIME__);

  /* Only run diagnostics if firmware is uploaded and running */
  if (avago_hbm_fw_check(aapl, spico_addr) != 0) {
    return -1;
  }

  /* Get the apc address */
  avago_hbm_get_apc_addr(aapl, spico_addr, &apc_addr);

  avago_addr_to_struct(spico_addr, &addr_struct);

  /* Get the build id */
  fw_revision =  avago_sbm_get_firmware_rev(aapl, spico_addr);
  fw_build_id = avago_sbm_get_firmware_build_id(aapl, spico_addr);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Firmware Revision: 0x%04x\n", fw_revision);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Firmware Build ID: 0x%04x\n", fw_build_id);


  /* Device ID */
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RESET, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test Reset: %s\n", rc == 0 ? "PASS" : "FAIL");

  rc = avago_hbm_read_device_id(aapl, spico_addr, &device_id);
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
  } else {
    avago_hbm_print_device_id(aapl, spico_addr);
  }

  /* Reset PHY / HBM */
  if (do_reset == 1) {
    avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RESET, &results, avago_hbm_default_timeout);
  }

  /* Initialize the NWL controller */
  if (do_init_nwl == 1) {
    rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_INITIALIZE_NWL_MCS, &results, avago_hbm_default_timeout);
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test INIT NWL: %s\n", rc == 0 ? "PASS" : "FAIL");
  }
  
  /* Pattern 0 - PRBS */
  avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_CTC_PATTERN_TYPE, 0);
  avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_START_CTC, &results, avago_hbm_default_timeout);
  ms_sleep(500);
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_STOP_CTC, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test CTC PRBS: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_print_ctc_results(aapl, apc_addr);
  }
  
  /* Pattern 1 - High Power Reads (0011 pattern) */
  avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_CTC_PATTERN_TYPE, 1);
  avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_START_CTC, &results, avago_hbm_default_timeout);
  ms_sleep(500);
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_STOP_CTC, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test CTC HIGH POWER: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_print_ctc_results(aapl, apc_addr);
  }
  
  if (fw_revision >= 0x55a) {
    /* Pattern 2 - High Power DBI Reads (modified 0011 pattern with DBI) */
    avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_CTC_PATTERN_TYPE, 2);
    avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_START_CTC, &results, avago_hbm_default_timeout);
    ms_sleep(500);
    rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_STOP_CTC, &results, avago_hbm_default_timeout);
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test CTC HIGH POWER DBI: %s\n", rc == 0 ? "PASS" : "FAIL");
    if (rc != 0) {
      avago_hbm_print_operation_results(aapl, &results);
      avago_hbm_print_ctc_results(aapl, apc_addr);
    }
  
    /* Pattern 3 - High Power PRBS  */
    avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_CTC_PATTERN_TYPE, 3);
    avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_START_CTC, &results, avago_hbm_default_timeout);
    ms_sleep(500);
    rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_STOP_CTC, &results, avago_hbm_default_timeout);
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test CTC HIGH POWER PRBS: %s\n", rc == 0 ? "PASS" : "FAIL");
    if (rc != 0) {
      avago_hbm_print_operation_results(aapl, &results);
      avago_hbm_print_ctc_results(aapl, apc_addr);
    }
  }
  
  avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RELEASE_CTC_CONTROL, &results, avago_hbm_default_timeout);

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO HBM MMT START */
/** */
/** @brief  Start the MMT running the requested pattern */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico or APC */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_mmt_start(Aapl_t *aapl, uint spico_addr, int pattern_type)
{
  int rc;
  Avago_hbm_device_id_t device_id;
  Avago_hbm_operation_results_t results;
  uint apc_addr;


  /* Get the apc address */
  avago_hbm_get_apc_addr(aapl, spico_addr, &apc_addr);

  /* Reset the HBM/PHY */
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RESET, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test Reset: %s\n", rc == 0 ? "PASS" : "FAIL");

  /* Device ID */
  rc = avago_hbm_read_device_id(aapl, spico_addr, &device_id);
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
  } else {
    avago_hbm_print_device_id(aapl, spico_addr);
  }

  /* Set the pattern type */
  avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_MMT_CONFIGURATION, pattern_type);

  /* Start running MMT */
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_START_CTC, &results, avago_hbm_default_timeout);
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
  }
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test MMT START: %s\n", rc == 0 ? "PASS" : "FAIL");


  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO HBM MMT STOP */
/** */
/** @brief  Stop the MMT running */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico or APC */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_mmt_stop(Aapl_t *aapl, uint spico_addr)
{
  int rc;
  Avago_hbm_operation_results_t results;
  uint apc_addr;

  /* Get the apc address */
  avago_hbm_get_apc_addr(aapl, spico_addr, &apc_addr);

  /* Stop the MMT test */
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_STOP_MMT, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test MMT STOP: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
  /*  avago_hbm_print_ctc_results(aapl, apc_addr); */
  }

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO HBM PRINT MMT RESULTS */
/** */
/** @brief  Prints MMT read/write/error results */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico or APC */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_print_mmt_results(Aapl_t *aapl, uint spico_addr, uint verbose)
{
  Avago_addr_t addr_struct;
  uint apc_addr;
  uint channel;


  /* Get APC address */
  avago_addr_to_struct(spico_addr, &addr_struct);
  apc_addr = avago_spico_int(aapl, spico_addr, 0x36, 0);
  apc_addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, apc_addr);

  /* Toggle MMT_CAPT_REG to update state variables */
  avago_sbus_wr(aapl, apc_addr, 0x55, 0);
  avago_sbus_wr(aapl, apc_addr, 0x55, 1);
  avago_sbus_wr(aapl, apc_addr, 0x55, 0);

  /* Read the MMT_CONFIG WDR for each channel */
  for (channel = 0; channel <= 7; channel++) {
    uint mmt_config_31_0;
    uint mmt_config_63_32;
    uint mmt_config_95_64;
    uint mmt_config_127_96;
    uint mmt_config_159_128;
    uint mmt_config_191_160;
    uint mmt_config_223_192;
    uint mmt_config_255_224;
    uint mmt_config_287_256;
    uint mmt_config_319_298;
    uint mmt_config_351_320;
    uint mmt_config_383_352;
    uint mmt_config_415_384;
    uint mmt_config_447_416;

    uint mmt_col_address;
    uint mmt_row_address;
    uint mmt_bank_address;
    uint mmt_stack_id;
    uint mmt_state;
    uint mmt_col_state;
    uint mmt_row_state;

    avago_hbm_wir_write_channel(aapl, apc_addr, PHY_SEL, channel, PHY_MMT_CONFIG);
    avago_hbm_wdr_read(aapl, apc_addr, 320, 0);
    avago_sbus_wr(aapl, apc_addr, 0x11, (1 << channel));  /* READ_CHANNEL */

    mmt_config_31_0    = avago_sbus_rd(aapl, apc_addr, 0x14);
    mmt_config_63_32   = avago_sbus_rd(aapl, apc_addr, 0x15);
    mmt_config_95_64   = avago_sbus_rd(aapl, apc_addr, 0x16);
    mmt_config_127_96  = avago_sbus_rd(aapl, apc_addr, 0x17);
    mmt_config_159_128 = avago_sbus_rd(aapl, apc_addr, 0x18);
    mmt_config_191_160 = avago_sbus_rd(aapl, apc_addr, 0x19);
    mmt_config_223_192 = avago_sbus_rd(aapl, apc_addr, 0x1a);
    mmt_config_255_224 = avago_sbus_rd(aapl, apc_addr, 0x1b);
    mmt_config_287_256 = avago_sbus_rd(aapl, apc_addr, 0x1c);
    mmt_config_319_298 = avago_sbus_rd(aapl, apc_addr, 0x1d);

    avago_hbm_wdr_read(aapl, apc_addr, 120, 1);
    mmt_config_351_320  = avago_sbus_rd(aapl, apc_addr, 0x14);
    mmt_config_383_352  = avago_sbus_rd(aapl, apc_addr, 0x15);
    mmt_config_415_384  = avago_sbus_rd(aapl, apc_addr, 0x16);
    mmt_config_447_416  = avago_sbus_rd(aapl, apc_addr, 0x17) & 0xffffff;

    mmt_col_address  = (mmt_config_191_160 >> 24) & 0x1f;   /* mmt_config[188:184] */
    mmt_row_address  = ((mmt_config_191_160 >> 29) & 0x07) | ((mmt_config_223_192 & 0x1fff) << 3); /* mmt_config[204:189] */
    mmt_bank_address = ((mmt_config_223_192 >> 13) & 0x0f); /* mmt_config[208:205] */
    mmt_stack_id     = ((mmt_config_223_192 >> 17) & 0x01); /* mmt_config[209] */
    mmt_state        = ((mmt_config_223_192 >> 18) & 0x1f); /* mmt_config[214:210] */
    mmt_col_state    = ((mmt_config_223_192 >> 23) & 0x0f); /* mmt_config[218:215] */
    mmt_row_state    = ((mmt_config_223_192 >> 27) & 0x0f); /* mmt_config[222:219] */

    /* Remove the state information and leave only the error counts */
    mmt_config_191_160 = mmt_config_191_160 & 0x00ffffff;
    mmt_config_223_192 = mmt_config_223_192 & 0x80000000;

    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Channel:%d MMT_CONFIG: 0x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x\n",
        channel,
        mmt_config_447_416,
        mmt_config_415_384,
        mmt_config_383_352,
        mmt_config_351_320,
        mmt_config_319_298,
        mmt_config_287_256,
        mmt_config_255_224,
        mmt_config_223_192,
        mmt_config_191_160,
        mmt_config_159_128,
        mmt_config_127_96,
        mmt_config_95_64,
        mmt_config_63_32,
        mmt_config_31_0
        );

    if (verbose == 1) {
      aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Channel:%d MMT_COL_ADDRESS : 0x%0x\n", channel, mmt_col_address);
      aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Channel:%d MMT_ROW_ADDRESS : 0x%0x\n", channel, mmt_row_address);
      aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Channel:%d MMT_BANK_ADDRESS: 0x%0x\n", channel, mmt_bank_address);
      aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Channel:%d MMT_STACK_ID    : 0x%0x\n", channel, mmt_stack_id);
      aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Channel:%d MMT_STATE       : 0x%0x\n", channel, mmt_state);
      aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Channel:%d MMT_COL_STATE   : 0x%0x\n", channel, mmt_col_state);
      aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Channel:%d MMT_ROW_STATE   : 0x%0x\n", channel, mmt_row_state);
    }

  }

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO HBM RUN MMT DIAGNOSTICS */
/** */
/** @brief  Runs MMT diagnostics */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico or APC */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_run_mmt_diagnostics(Aapl_t *aapl, uint spico_addr)
{
  int rc;
  Avago_hbm_device_id_t device_id;
  Avago_hbm_operation_results_t results;
  uint apc_addr;
  uint fw_build_id;
  uint fw_revision;
  Avago_addr_t addr_struct;

  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "AAPL_version: %s, compiled %s %s\n", AAPL_VERSION, __DATE__, __TIME__);

  /* Only run diagnostics if firmware is uploaded and running */
  if (avago_hbm_fw_check(aapl, spico_addr) != 0) {
    return -1;
  }

  /* Get the apc address */
  avago_hbm_get_apc_addr(aapl, spico_addr, &apc_addr);

  avago_addr_to_struct(spico_addr, &addr_struct);

  /* Get the build id */
  fw_revision =  avago_sbm_get_firmware_rev(aapl, spico_addr);
  fw_build_id = avago_sbm_get_firmware_build_id(aapl, spico_addr);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Firmware Revision: 0x%04x\n", fw_revision);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Firmware Build ID: 0x%04x\n", fw_build_id);


  /* Device ID */
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RESET, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test Reset: %s\n", rc == 0 ? "PASS" : "FAIL");

  rc = avago_hbm_read_device_id(aapl, spico_addr, &device_id);
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
  } else {
    avago_hbm_print_device_id(aapl, spico_addr);
  }

  /* Run all MMT patterns */
  avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_MMT_CONFIGURATION, 2);
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RUN_MMT, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test MMT ALL: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_print_mmt_results(aapl, spico_addr, 0);
  }

  /* Run pattern 2 in continuous mode */
  avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_MMT_CONFIGURATION, 2);
  avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_START_MMT, &results, avago_hbm_default_timeout);
  ms_sleep(2000);
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_STOP_MMT, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test MMT PRBS: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_print_mmt_results(aapl, spico_addr, 0);
  }

  /* Run pattern 3 in continuous mode */
  avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_MMT_CONFIGURATION, 3);
  avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_START_MMT, &results, avago_hbm_default_timeout);
  ms_sleep(2000);
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_STOP_MMT, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test MMT HP WR/RD: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_print_mmt_results(aapl, spico_addr, 0);
  }

  /* Run pattern 4 in continuous mode */
  avago_hbm_set_parameter(aapl, spico_addr, AVAGO_HBM_MMT_CONFIGURATION, 4);
  avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_START_MMT, &results, avago_hbm_default_timeout);
  ms_sleep(2000);
  rc = avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_STOP_MMT, &results, avago_hbm_default_timeout);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Test MMT HP READ: %s\n", rc == 0 ? "PASS" : "FAIL");
  if (rc != 0) {
    avago_hbm_print_operation_results(aapl, &results);
    avago_hbm_print_mmt_results(aapl, spico_addr, 0);
  }

  return aapl->return_code;
}

/*============================================================================= */
/* AVAGO HBM PRINT HARD LANE REPAIRS */
/** */
/** @brief  Print the hard repairs */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr   Sbus address of the spico or apc */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_print_hard_lane_repairs(Aapl_t *aapl, uint spico_addr)
{
  uint channel;
  uint apc_addr;
  Avago_hbm_operation_results_t results;

  /* Get the apc address */
  avago_hbm_get_apc_addr(aapl, spico_addr, &apc_addr);

  /* Only run diagnostics if firmware is uploaded and running */
  if (avago_hbm_fw_check(aapl, spico_addr) != 0) {
    return -1;
  }

  /* Hard lane repairs are applied to the PHY as sot lane repairs */
  avago_hbm_launch_operation(aapl, spico_addr, AVAGO_HBM_OP_RESET, &results, avago_hbm_default_timeout);

  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Hard Lane Repairs\n");

  for( channel = 0;  channel < 8; channel++ ) {
    uint repairs_31_0;
    uint repairs_63_32;
    uint repairs_95_64;

    avago_hbm_wir_write_channel(aapl, apc_addr, PHY_SEL, channel, PHY_SOFT_LANE_REPAIR);
    avago_hbm_wdr_read(aapl, apc_addr, PHY_SOFT_LANE_REPAIR_LENGTH, 0);
    avago_sbus_wr(aapl, apc_addr, 0x11, (1 << channel));  /* READ_CHANNEL */
    repairs_31_0  = avago_sbus_rd(aapl, apc_addr, 0x14);
    repairs_63_32 = avago_sbus_rd(aapl, apc_addr, 0x15);
    repairs_95_64 = avago_sbus_rd(aapl, apc_addr, 0x16) & 0xff;
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Channel:%d Repairs:0x%02x%08x%08x\n",
        channel, repairs_95_64, repairs_63_32, repairs_31_0);
  }

  return 0;
}


/*============================================================================= */
/* AVAGO HBM RUN TEMP DIAGNOSTICS */
/** */
/** @brief  Run hbm temperature diagnostics */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr   Sbus address of the spico */
/** @param  count        Times to loop. */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_run_temp_diagnostics(Aapl_t *aapl, uint spico_addr, int count)
{
  uint apc_addr;

  /* Get the apc address */
  avago_hbm_get_apc_addr(aapl, spico_addr, &apc_addr);

  do {
    uint temp_1500;
    uint temp_valid;
    uint temp_value;
    uint temp_cattrip;
    uint temp_dfi;
    uint cattrip;

    avago_hbm_wir_write_channel(aapl, apc_addr, HBM_SEL, 0, HBM_TEMP);
    avago_hbm_wdr_read(aapl, apc_addr, HBM_TEMP_LENGTH, 0);
    avago_sbus_wr(aapl, apc_addr, 0x11, 0);  /* READ_CHANNEL */
    temp_1500 = avago_sbus_rd(aapl, apc_addr, 0x14) & 0xff;
    temp_valid = temp_1500 >> 0x7;
    temp_value = temp_1500 & 0x7f;

    temp_cattrip = avago_sbus_rd(aapl, apc_addr, 0x2c);
    temp_dfi = temp_cattrip & 0x7;
    cattrip = temp_cattrip >> 3;

    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "temp_valid:%d temp_value:%d temp_dfi:%d cattrip:%d\n", 
        temp_valid, temp_value, temp_dfi, cattrip);

    if (count > 1) { count = count - 1; }
  } while (count > 1);

  return 0;
}

/*============================================================================= */
/* AVAGO HBM RUN TMRS */
/** */
/** @brief  Program a TMRS code */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr   Sbus address of the spico */
/** @param  tmrs_code    TMRS code */
/** @param  channel      Channel to apply code to */
/** @param  safety       Apply the safety bit to this code */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_run_tmrs(Aapl_t *aapl, uint spico_addr, const char *tmrs_code, uint channel, uint safety)
{
  uint die;
  uint cat;
  uint subcat;
  uint name;
  uint apc_addr;
  Avago_hbm_operation_results_t results;

  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "TMRS Code: %s\n", tmrs_code);
  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Safety: %d\n", safety);

  if (channel == 0xf) {
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Channel: all\n");
  } else {
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Channel: %d\n", channel);
  }

  if (safety > 1) {
    aapl_fail(aapl, __func__, __LINE__, "Illegal safety value %d.\n", safety);
    return aapl->return_code;
  }
  die = safety;

  if (toupper(tmrs_code[0]) == 'B') {
    die |= 0x8;
  } else if (toupper(tmrs_code[0]) == 'C') {
    die |= 0x6;
  } else {
    aapl_fail(aapl, __func__, __LINE__, "Illegal die code %c.\n", tmrs_code[0]);
  }

  cat    = tmrs_code[1] - '0';
  subcat = tmrs_code[2] - '0';
  name   = tmrs_code[3] - '0';

  /* Get the apc address */
  avago_hbm_get_apc_addr(aapl, spico_addr, &apc_addr);

  /* Write the TMRS code the APC SPARE regmsters */
  avago_sbus_wr(aapl, apc_addr, 0x49, ((die << 16) | cat));  /* SPARE_3 */
  avago_sbus_wr(aapl, apc_addr, 0x48, ((subcat << 16) | name));  /* SPARE_2 */

  /* Run firmware interrupt to load TMRS code from SPARE registers */
  avago_hbm_launch_channel_operation(aapl, spico_addr, AVAGO_HBM_OP_TMRS, &results, channel, avago_hbm_default_timeout);
  avago_hbm_print_operation_results(aapl, &results);

  return aapl->return_code;
}

/*============================================================================= */
/* AVAGO HBM PRINT SPARE RESULTS */
/** */
/** @brief  Prints the HBM spare results */
/** */
/** @param  aapl         Aapl_t struct */
/** @param  spico_addr   Sbus address of the spico */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_hbm_print_spare_results(Aapl_t *aapl, uint spico_addr)
{
  int spare;
  int rc;

  /* accepts either a spico or APC address */
  rc = aapl->return_code;
  spico_addr = avago_hbm_get_spico_address(aapl, spico_addr);
  if (aapl->return_code != rc) { return -1; }

  aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Spare Registers\n");
  for (spare=0; spare<=23; spare++) {
    int value;
    value = avago_spico_int(aapl, spico_addr, 0x32, 0x12+spare);
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   Spare%d: 0x%0x\n", spare, value);
  }

  return aapl->return_code;
}

#endif /* AAPL_ENABLE_HBM */

/** @} */
