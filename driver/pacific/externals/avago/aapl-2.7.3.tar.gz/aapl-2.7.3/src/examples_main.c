/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* MAIN program for the examples sub-command. */
/* */

/** Doxygen File Header */
/** @file */
/** @brief Launch wrapper for built-in examples. */
#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_MAIN && AAPL_ENABLE_EXAMPLES && AAPL_ENABLE_FILE_IO

static int serdes_init(Aapl_t *aapl, int addr, const char *firmware_file_path)
{
    Avago_serdes_init_config_t *config;
    int errors;

#if AAPL_ENABLE_FILE_IO
    /* Upload firmware to the SerDes slice */
    printf("Uploading firmware file: \"%s\"\n", firmware_file_path);
    if( avago_spico_upload_file(aapl, addr, TRUE, firmware_file_path) < 0 )
    {
        printf("SerDes initialization failed.\n");
        return 0;
    }
#endif /* AAPL_ENABLE_FILE_IO */

    /* Initialize the SerDes slice */
    config = avago_serdes_init_config_construct(aapl);

    /* Change any of the config struct values from their defaults: */
    config->tx_divider = 60;
    config->rx_divider = 60;

    errors = avago_serdes_init(aapl, addr, config);

    if( errors > 0 )
        printf("SerDes init complete for SerDes at addr %s; Errors in ILB: %d. \n", aapl_addr_to_str(addr), errors);
    if( errors == 0 && aapl_get_return_code(aapl) == 0 )
        printf("The SerDes at address %s is initialized.\n", aapl_addr_to_str(addr));

    avago_serdes_init_config_destruct(aapl, config);
    return 0;
}

#if AAPL_ENABLE_EYE_MEASUREMENT
static int eye_capture1(Aapl_t *aapl, int addr)
{
    Avago_serdes_eye_config_t *eye_config = avago_serdes_eye_config_construct(aapl);
    Avago_serdes_eye_data_t *eye_data = avago_serdes_eye_data_construct(aapl);

    /* Configure a fast, low resolution capture: */
    eye_config->ec_x_resolution   = 32;     /* Low x resolution */
    eye_config->ec_x_auto_scale   = FALSE;  /* Don't auto-scale x resolution */
    eye_config->ec_y_step_size    = 8;      /* Low y resolution, auto-scale */

    if( avago_serdes_eye_get(aapl, addr, eye_config, eye_data) < 0 )
    {
        avago_serdes_eye_data_destruct(aapl, eye_data);
        avago_serdes_eye_config_destruct(aapl, eye_config);
        return aapl_fail(aapl, __func__, __LINE__, "Eye capture failed.\n");
    }

    /* Print results: */
    avago_serdes_eye_plot_write(stdout, eye_data);

    avago_serdes_eye_data_destruct(aapl, eye_data);
    avago_serdes_eye_config_destruct(aapl, eye_config);
    return 0;
}

static int eye_capture2(Aapl_t *aapl, int addr)
{
    Avago_serdes_eye_config_t *eye_config = avago_serdes_eye_config_construct(aapl);
    Avago_serdes_eye_data_t *eye_data = avago_serdes_eye_data_construct(aapl);
    eye_config->ec_eye_type = AVAGO_EYE_HEIGHT;

    if( avago_serdes_eye_get(aapl, addr, eye_config, eye_data) < 0 )
    {
        avago_serdes_eye_data_destruct(aapl, eye_data);
        avago_serdes_eye_config_destruct(aapl, eye_config);
        return aapl_fail(aapl, __func__, __LINE__, "Eye capture failed.\n");
    }

    /* Print results: */
    printf("Avago SerDes at SBus %s has an eye height of %d mV.\n",
            aapl_addr_to_str(addr), eye_data->ed_height_mV);

    {
        int i;
        for( i = 0; i < eye_data->eye_count; i++ )
            avago_serdes_eye_vbtc_write(stdout, &eye_data->ed_vbtc[i]);
    }

    avago_serdes_eye_data_destruct(aapl, eye_data);
    avago_serdes_eye_config_destruct(aapl, eye_config);
    return 0;
}

static int eye_capture3(Aapl_t *aapl, int addr)
{
    Avago_serdes_eye_config_t *eye_config = avago_serdes_eye_config_construct(aapl);
    Avago_serdes_eye_data_t *eye_data = avago_serdes_eye_data_construct(aapl);
    eye_config->ec_eye_type = AVAGO_EYE_SIZE;

    if( avago_serdes_eye_get(aapl, addr, eye_config, eye_data) < 0 )
    {
        avago_serdes_eye_data_destruct(aapl, eye_data);
        avago_serdes_eye_config_destruct(aapl, eye_config);
        return aapl_fail(aapl, __func__, __LINE__, "Eye capture failed.\n");
    }

    /* Print results: */
    printf("Avago SerDes at SBus %s has an eye width of %d mUI.\n",
            aapl_addr_to_str(addr), eye_data->ed_width_mUI);

    {
        int i;
        for( i = 0; i < eye_data->eye_count; i++ )
            avago_serdes_eye_vbtc_write(stdout, &eye_data->ed_vbtc[i]);
        for( i = 0; i < eye_data->eye_count; i++ )
            avago_serdes_eye_hbtc_write(stdout, &eye_data->ed_hbtc[i]);
    }

    avago_serdes_eye_data_destruct(aapl, eye_data);
    avago_serdes_eye_config_destruct(aapl, eye_config);
    return 0;
}
#endif /* AAPL_ENABLE_EYE_MEASUREMENT */


#if AAPL_ENABLE_ESCOPE_MEASUREMENT

static int escope_capture1(Aapl_t *aapl, int addr)
{
    /* CM4 requires ELB operation for eye and escope capture for FW >= 0x1071. */
    BOOL cm4_elb = aapl_get_ip_type(aapl,addr) == AVAGO_M4 && aapl_check_firmware_rev(aapl,addr, __func__, __LINE__, FALSE, 1, 0x1071);
    Avago_serdes_escope_config_t *config = avago_serdes_escope_config_construct(aapl);
    Avago_serdes_escope_data_t   *data   = avago_serdes_escope_data_construct(  aapl);

    /* Configure SerDes appropriately for escope capture: */
    avago_serdes_set_tx_data_sel(      aapl, addr, AVAGO_SERDES_TX_DATA_SEL_PRBS7);
    avago_serdes_set_tx_invert(        aapl, addr, FALSE);
    avago_serdes_set_rx_input_loopback(aapl, addr, !cm4_elb);
    avago_serdes_set_rx_invert(        aapl, addr, FALSE);

    /* Capture a short, low resolution wave form: */
    config->sc_x_resolution = 32;
    config->sc_x_UI         =  5;
    config->sc_y_step_size  =  5;

    if( avago_serdes_escope_get(aapl, addr, config, data) < 0 )
    {
        avago_serdes_escope_data_destruct(  aapl, data);
        avago_serdes_escope_config_destruct(aapl, config);
        return aapl_fail(aapl, __func__, __LINE__, "Escope capture failed.\n");
    }

    /* Display results: */
    {
        int x_points = data->sd_waveform->x_points;
        Avago_plot_t *plot = avago_plot_construct(aapl, x_points, 17);
        int flags = data->sd_waveform->datapath_flags;
        fprintf(stdout,"# Escope wave (%d x %d):\n",plot->x_points,plot->y_points);
        if( flags )
            fprintf(stdout,"Data decoding: %s%s%s%s%s\n", flags&8?" swizzle":"", flags&2?" gray":"", flags&1 ? " invert" : "", flags &4 ? " precode" : "", flags==0?"normal":"");
        avago_plot_ascii_waveform(plot, data->sd_waveform);
        avago_plot_print_ascii(stdout, plot);
        avago_plot_destruct(aapl, plot);
    }

    avago_serdes_escope_data_destruct(  aapl, data);
    avago_serdes_escope_config_destruct(aapl, config);
    return 0;
}

static int escope_capture2(Aapl_t *aapl, int addr)
{
    /* CM4 requires ELB operation for eye and escope capture for FW >= 0x1071. */
    BOOL cm4_elb = aapl_get_ip_type(aapl,addr) == AVAGO_M4 && aapl_check_firmware_rev(aapl,addr, __func__, __LINE__, FALSE, 1, 0x1071);
    Avago_serdes_escope_config_t *config = avago_serdes_escope_config_construct(aapl);
    Avago_serdes_escope_data_t   *data   = avago_serdes_escope_data_construct(  aapl);

    /* Configure SerDes appropriately for escope capture: */
    avago_serdes_set_tx_data_sel(      aapl, addr, AVAGO_SERDES_TX_DATA_SEL_PRBS7);
    avago_serdes_set_tx_invert(        aapl, addr, FALSE);
    avago_serdes_set_rx_input_loopback(aapl, addr, !cm4_elb);
    avago_serdes_set_rx_invert(        aapl, addr, FALSE);

    printf("Capturing a medium-resolution escope trace into file \"escope.data\".\n");
    printf("This may take a few minutes...\n\n");

    config->sc_x_resolution =  32;  /* 64 for highest resolution at full data rate */
    config->sc_x_UI         = 127;
    config->sc_read_count   =   2;  /* 1 for highest resolution */
    if( avago_serdes_escope_get(aapl, addr, config, data) < 0 )
    {
        avago_serdes_escope_data_destruct(  aapl, data);
        avago_serdes_escope_config_destruct(aapl, config);
        return aapl_fail(aapl, __func__, __LINE__, "Escope capture failed.\n");
    }

    /* Write captured data to an output file: */
    avago_serdes_escope_write_file("escope.data", data);

    avago_serdes_escope_data_destruct(  aapl, data);
    avago_serdes_escope_config_destruct(aapl, config);
    return 0;
}
#endif /* AAPL_ENABLE_ESCOPE_MEASUREMENT */



static int show_examples_help()
{
    aapl_common_main_help(TRUE);
    printf(
"The initialization example uploads firmware to a SerDes and initializes it.\n"
"-serdes-init <firmware-file-path>\n"
"\n"
);
#if AAPL_ENABLE_EYE_MEASUREMENT
    printf(
"The eye examples do measurements on the existing SerDes RX signal.\n"
"-eye1           Do a low-resolution eye capture and plot.\n"
"-eye2           Capture and display eye height information.\n"
"-eye3           Capture and display eye size information.\n"
"\n"
);
#endif /* AAPL_ENABLE_EYE_MEASUREMENT */

#if AAPL_ENABLE_ESCOPE_MEASUREMENT
    printf(
"The escope examples configure the SerDes for waveform capture.\n"
"-escope1        Capture and display a short, low-resolution waveform.\n"
"-escope2        Capture a high-resolution waveform to file \"escope.data\".\n"
"\n"
);
#endif /* AAPL_ENABLE_ESCOPE_MEASUREMENT */

    return 1;
}


int aapl_examples_main(int argc, char *argv[], Aapl_t *aapl)
{
    /* Set default values: */
    uint        addr;
    Avago_addr_t addr_struct;

    int rc, index = 0;
    const char *firmware = 0;

    BOOL example_selected = FALSE;
#if AAPL_ENABLE_EYE_MEASUREMENT
    BOOL run_eye1 = FALSE;
    BOOL run_eye2 = FALSE;
    BOOL run_eye3 = FALSE;
#endif /* AAPL_ENABLE_EYE_MEASUREMENT */
#if AAPL_ENABLE_ESCOPE_MEASUREMENT
    BOOL run_escope1 = FALSE;
    BOOL run_escope2 = FALSE;
#endif /* AAPL_ENABLE_ESCOPE_MEASUREMENT */

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"serdes-init",     1, 0,  2 },
#if AAPL_ENABLE_EYE_MEASUREMENT
        {"eye1",            0, 0, 11 },
        {"eye2",            0, 0, 12 },
        {"eye3",            0, 0, 13 },
#endif /* AAPL_ENABLE_EYE_MEASUREMENT */
#if AAPL_ENABLE_ESCOPE_MEASUREMENT
        {"escope1",         0, 0, 21 },
        {"escope2",         0, 0 ,22 },
#endif /* AAPL_ENABLE_ESCOPE_MEASUREMENT */

        {0,                 0, NULL, 0}
    };

    avago_addr_to_struct(aapl_default_device_addr, &addr_struct);
    if( aapl_common_main_options(aapl, argc, argv, &addr_struct) < 0 )
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_examples_help();
    }
    addr = avago_struct_to_addr(&addr_struct);

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        /*const char *name = options[index].name; */
        switch( rc )
        {
        case  2 : firmware = optarg; example_selected = TRUE; break;
#if AAPL_ENABLE_EYE_MEASUREMENT
        case 11 : run_eye1 = example_selected = TRUE; break;
        case 12 : run_eye2 = example_selected = TRUE; break;
        case 13 : run_eye3 = example_selected = TRUE; break;
#endif /* AAPL_ENABLE_EYE_MEASUREMENT */
#if AAPL_ENABLE_ESCOPE_MEASUREMENT
        case 21 : run_escope1 = example_selected = TRUE; break;
        case 22 : run_escope2 = example_selected = TRUE; break;
#endif /* AAPL_ENABLE_ESCOPE_MEASUREMENT */

        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    if( !example_selected )
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_examples_help();
    }
        /*aapl_main_error("At least one example must be selected."); */

    if( addr == ~0U )
        aapl_main_error("The examples require a valid device address.");

/* Prepare a lower-level (back end) connection to forward commands for */
/* handling: */

    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
    aapl_get_ip_info(aapl,0);

    if( firmware    ) serdes_init (aapl, addr, firmware);
#if AAPL_ENABLE_ESCOPE_MEASUREMENT
    if( run_escope1 ) escope_capture1(aapl, addr);
    if( run_escope2 ) escope_capture2(aapl, addr);
#endif /* AAPL_ENABLE_ESCOPE_MEASUREMENT */
#if AAPL_ENABLE_EYE_MEASUREMENT
    if( run_eye1    ) eye_capture1(aapl, addr);
    if( run_eye2    ) eye_capture2(aapl, addr);
    if( run_eye3    ) eye_capture3(aapl, addr);
#endif /* AAPL_ENABLE_EYE_MEASUREMENT */

    rc = aapl->return_code != 0;
    avago_addr_delete(aapl, &addr_struct);
    return rc;
}

#endif /* AAPL_ENABLE_MAIN && AAPL_ENABLE_EXAMPLES && AAPL_ENABLE_FILE_IO */

