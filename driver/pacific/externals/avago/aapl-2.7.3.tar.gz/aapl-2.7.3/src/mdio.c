/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* AAPL (ASIC and ASSP Programming Layer) MDIO-related functions. */

/** Doxygen File Header */
/** @file */
/** @brief MDIO related functions. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#define AAPL_CORE_FILE
#include "aapl.h"

#if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO
#define AAPL_LOG_PRINT11 if( aapl->debug >= 11 ) aapl_log_printf
#define AAPL_LOG_PRINT8 if( aapl->debug >= 8 ) aapl_log_printf
#define AAPL_LOG_PRINT9 if( aapl->debug >= 9 ) aapl_log_printf

#define REG_SBUS_CMD         32768  /* SBus command, 7 bits. */
#define REG_SBUS_SA          32769  /* receiver/SerDes address, 7 bits. */
#define REG_SBUS_DA          32770  /* data address, 7 bits. */
#define REG_SBUS_DATA_IN_LO  32771  /* DATA_IN[15: 0]. */
#define REG_SBUS_DATA_IN_HI  32772  /* DATA_IN[31:16]. */
#define REG_SBUS_EXEC        32773  /* SBUS_EXECUTE is [0]. */
#define REG_SBUS_RESULT      32774  /* SBUS_RESULT[] is [2:0]. */
#define REG_SBUS_DATA_OUT_LO 32775  /* DATA_OUT[15: 0]. */
#define REG_SBUS_DATA_OUT_HI 32776  /* DATA_OUT[31:16]. */


#if AAPL_ALLOW_AACS

/** @cond INTERNAL */

/** @brief Execute an MDIO command using AACS. */
/** */
/** @return  Returns 0 on successful address or write command. */
/** @return  Returns data on successful read command. */
/** @return  Decrements aapl->return_code on failure. */
uint avago_aacs_mdio_fn(
    Aapl_t *aapl,
    Avago_mdio_cmd_t mdio_cmd,
    uint port_addr,
    uint dev_addr,
    uint reg_addr,
    uint data)
{
    /* When using AACS, send the command (which is in commandstr[]) via TCP. */
    /* Data is returned in (unsigned int) aapl->data. */
    /* All commands except wait and read can be buffered */
    uint recv_data_back = FALSE;
    char commandstr[64];
    (void) reg_addr;

    switch( mdio_cmd )
    {
    case AVAGO_MDIO_ADDR: snprintf(commandstr, 64, "mdio a %u %u 0x%x", port_addr, dev_addr, data); break;
    case AVAGO_MDIO_WRITE:snprintf(commandstr, 64, "mdio w %u %u 0x%x", port_addr, dev_addr, data); break;
    case AVAGO_MDIO_READ: snprintf(commandstr, 64, "mdio r %u %u",      port_addr, dev_addr);
                          recv_data_back = TRUE;
                          break;
    case AVAGO_MDIO_WAIT: snprintf(commandstr, 64, "mdio wait %u %u",   port_addr, dev_addr);
                          recv_data_back = TRUE;
                          break;
    }

    avago_aacs_send_command_options(aapl, commandstr, recv_data_back, /* strtol = */ 16); /* send the command and log it in the aapl->log buffer */
    return aapl->data;
}
/** @endcond */

#endif

/** @brief   Execute an MDIO command. */
/** */
/** @return  Returns 0 on successful address or write command. */
/** @return  Returns data on successful read command. */
/** @return  Decrements aapl->return_code on failure. */
uint avago_mdio(
    Aapl_t *aapl,               /**< [in] Pointer to AAPL structure */
    Avago_mdio_cmd_t mdio_cmd,  /**< [in] Command type */
    uint port_addr,             /**< [in] Physical port address (aka SBus address) */
    uint dev_addr,              /**< [in] Register address */
    uint data)                  /**< [in] Data to write, ignored for read. */
{
    if( aapl->debug >= AVAGO_DEBUG12 )
    {
        const char *cmd_str = mdio_cmd == AVAGO_MDIO_ADDR ? "ADDR" : mdio_cmd == AVAGO_MDIO_WRITE ? "WRITE" : mdio_cmd == AVAGO_MDIO_READ ? "READ" : "WAIT";
        aapl_log_printf(aapl, AVAGO_DEBUG12, __func__, __LINE__, "avago_mdio(aapl, %s, port=0x%x, dev=0x%x, data=0x%x)\n", cmd_str, port_addr, dev_addr, data);
    }
    if( mdio_cmd == AVAGO_MDIO_ADDR )
        aapl->last_mdio_addr[port_addr] = data; /* Remember last address so we can pass it to user_supplied_mdio_function */

    if( port_addr == AVAGO_BROADCAST )   /* is chip broadcast set? */
    {
        /* send this command to every chip we're connected to. */
        uint rc = 0, chip;
        for( chip = 0; chip < aapl->chips; chip ++ )
            rc = avago_mdio(aapl, mdio_cmd, chip, dev_addr, data);
        return rc; /* return data from last command */
    }

    /* Calls avago_aacs_mdio_fn(), avago_gpio_mdio_fn() or a user registered function. */
    return aapl->mdio_fn(aapl, mdio_cmd, port_addr + aapl->mdio_base_port_addr, dev_addr, aapl->last_mdio_addr[port_addr], data);
}

/** @brief  Execute an MDIO write operation. */
/** */
/** @return Returns 0 on success, aapl->return_code (< 0) on error. */
uint avago_mdio_wr(
    Aapl_t *aapl,       /**< [in] Pointer to AAPL structure */
    uint port_addr,     /**< [in] Physical port address */
    uint dev_addr,      /**< [in] Register address */
    uint reg_addr,      /**< [in] Address to which to write. */
    uint data)          /**< [in] Data to write */
{
    data &= 0xffff;
    AAPL_LOG_PRINT11(aapl, AVAGO_DEBUG11, __func__, __LINE__,
            "avago_mdio_wr(0x%x, 0x%x, 0x%04x <= 0x%04x)\n",
            port_addr, dev_addr, reg_addr, data);

           avago_mdio(aapl, AVAGO_MDIO_ADDR,  port_addr, dev_addr, reg_addr);
    return avago_mdio(aapl, AVAGO_MDIO_WRITE, port_addr, dev_addr, data);
}

/** @brief   Execute an MDIO read operation. */
/** @return  Return 32 bit data from reg_addr on port_addr. */
/**          Sets aapl->return_code and logs an error on failure. */
uint avago_mdio_rd(
    Aapl_t *aapl,       /**< [in] Pointer to AAPL structure */
    uint port_addr,     /**< [in] Physical port address */
    uint dev_addr,      /**< [in] Register address */
    uint reg_addr)      /**< [in] Address from which to read. */
{
    uint rc;
           avago_mdio(aapl, AVAGO_MDIO_ADDR, port_addr, dev_addr, reg_addr);
    rc =   avago_mdio(aapl, AVAGO_MDIO_READ, port_addr, dev_addr, 0);
    AAPL_LOG_PRINT11(aapl, AVAGO_DEBUG11, __func__, __LINE__,
            "avago_mdio_rd(0x%x, 0x%x, 0x%04x) => 0x%04x\n", port_addr, dev_addr, reg_addr, rc);
    return rc;
}

/** @cond INTERNAL */

/** @brief   Execute an sbus reset(00), write(01) or read(10) command */
/**          via the remote MDIO core interface. */
/** @return  Return 0 on write or reset, 32 bit data on read. */
/**          Sets aapl->return_code and logs an error on failure. */
uint avago_mdio_sbus_fn(
    Aapl_t *aapl,               /**< [in] Pointer to AAPL structure */
    uint sbus_addr,             /**< [in] SBus address of SerDes */
    unsigned char reg_addr,     /**< [in] SBus data register address */
    unsigned char command,      /**< [in] SBus command */
    uint *sbus_data)            /**< [in] 32 bit SBus data (if write command) */
{
/*////////////////////////////////////////////////////////////////////// */
/* The mdio interface is very labor intensive and inefficient with any */
/* read or write requiring an address to be set in advance of the */
/* transaction. The sbus-over-mdio has similar efficiency issues. The */
/* REG_SBUS_SA/DA/CMD etc... are all direct connections to the SBM */
/* core interface. Techincally, it's not required to rewrite all of */
/* these values for a single transaction if you have knowledge of their */
/* existing states. Reading the states doesn't actually save any time, */
/* but for a transaction dense function like eye capture (for example) */
/* it may be worthwhile to incorporate some of the hardware-server's */
/* MDIO efficieny improvements which involve maintaining shadow copies */
/* of the various settings and only updating what is necessary. This */
/* requires more overhead as it's possible for the user to cause resets */
/* or other actions that break the relationship between the shadow */
/* values and the actual core port values. This can be revisited at a */
/* later time. */
/*////////////////////////////////////////////////////////////////////// */

    int try_count = 0;
    int count = 0;
    int result = 0;
    int limit = aapl->sbus_mdio_timeout; /* includes done checks and rcv_valid checks in total */
    uint rc = TRUE;
    Avago_addr_t addr_struct;
    sbus_addr &= 0xffff;    /* Ignore lane */
    avago_addr_to_struct(sbus_addr,&addr_struct);

    /* Setup the sbus_rx addr, data reg addr and command */
    avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, REG_SBUS_SA, sbus_addr);       /* Set the REG_SBUS_SA to sbus_addr */
    avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, REG_SBUS_DA, reg_addr);        /* Set the REG_SBUS_DA to reg_addr */
    avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, REG_SBUS_CMD, command | 0x20); /* OR the command with 0x20, as the MDIO port is connected to the SBus core interface, set REG_SBUS_CMD */

    /* Setup the data_in word [31:0] only for a write command */
    if (command == 0x01)  /* Only execute these statements for a write transaction (command code 0x01) */
    {
        avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, REG_SBUS_DATA_IN_LO,  (*sbus_data & 0x0000ffff));        /* Skim off the lower 16 bits for DATA_IN_LO */
        avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, REG_SBUS_DATA_IN_HI, ((*sbus_data & 0xffff0000) >> 16)); /* Skim off the upper 16 bits for DATA_IN_HI */
    }

    do
    {
        int prev_result = 0;
        count = 0;

        /* Poll on the REG_SBUS_RESULT until JOB_DONE goes low */
        avago_mdio(aapl, AVAGO_MDIO_ADDR, addr_struct.chip, AVSP_DEVAD, REG_SBUS_RESULT);
        do
        {
            result = avago_mdio(aapl, AVAGO_MDIO_READ, addr_struct.chip, AVSP_DEVAD, 0); /* Poll on REG_SBUS_RESULT */
        } while ( (result & 1) == 1 && (++count <= limit)); /* monitor bit[0], SBUS_DONE, till it clears to match the EXEC request */

        /* Store the RCV_DATA_VALID bit from the SBUS_RESULT polling so we can check for a toggle later in the read case */
        prev_result = result & 0x02;

        /* Set the EXEC bit high while also setting the DATA_VALID_SEL bit to enforce RCV_DATA_VALID toggling */
        avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, REG_SBUS_EXEC, 0x3);  /* Set the EXEC bit high, DATA_VALID_SEL still set to 1 */

        /* Poll on the REG_SBUS_RESULT until JOB_DONE goes high */
        avago_mdio(aapl, AVAGO_MDIO_ADDR, addr_struct.chip, AVSP_DEVAD, REG_SBUS_RESULT);
        do
        {
            result = avago_mdio(aapl, AVAGO_MDIO_READ, addr_struct.chip, AVSP_DEVAD, 0); /* Poll on REG_SBUS_RESULT */
        } while ( (result & 1) == 0 && (++count <= limit)); /* Monitor bit[0], SBUS_DONE, till it is set to match the EXEC selection */

        if (command == 0x01 || command == 0x00) /* For a write or a reset command, we're all done */
        {
            /* Set the EXEC bit low while also setting the DATA_VALID_SEL bit to enforce RCV_DATA_VALID toggling */
            avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, REG_SBUS_EXEC, 0x2); /* Set the EXEC bit low, and use DATA_VALID_SEL = 1 */
            return rc;
        }

        /* We already have grabbed the REG_SBUS_RESULT for JOB_DONE checks, use that */
        /* same result for RCV_DATA_VALID check and continue polling if necessary */
        /* until the RCV_DATA_VALID toggles from its previous case */
        while( count <= limit )
        {
            /* Loop until we get a new result: */
            while( ((result & 2) == prev_result) && (++count <= limit) )  /* Monitor bit[1], RCV_DATA_VALID until it toggles */
            {
                result = avago_mdio(aapl, AVAGO_MDIO_READ, addr_struct.chip, AVSP_DEVAD, 0); /* Poll on REG_SBUS_RESULT */
            }
            if( (result & 0x1c) == 0x10 )   /* If a read result */
                break;  /* Success */

            /* If we get a write result, loop again looking for a read result. */
            AAPL_LOG_PRINT8(aapl, AVAGO_DEBUG8, __func__, __LINE__, "MDIO read did not receive a read complete result: 0x%x\n",result);
            prev_result = result & 2;
        }

        /* Set the EXEC bit low while also setting the DATA_VALID_SEL bit to enforce RCV_DATA_VALID toggling */
        avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, REG_SBUS_EXEC, 0x2); /* Set the EXEC bit low, and use DATA_VALID_SEL = 1 */

        /* If the read times out, it could be that we received a valid read, but due to timing with another write, the REC_DATA_VALID bit */
        /* toggled twice, so we didn't actually see it.  In which case, repeating the read will work. */
        /* If we are really timing out, this doubles the time that we hang. */
    } while( count > limit && ++try_count == 1 );

    /* Do some general checks on the result, did we timeout waiting for things */
    /* to complete or did we receive a non-valid read success code */
    if (count > limit)
    {
        aapl_fail(aapl, __func__, __LINE__, "SBus %s, MDIO response timed out after %d loops when reading address 0x%x, result = 0x%x.\n", aapl_addr_to_str(sbus_addr), count, reg_addr, result);
        rc = FALSE;
    }
    else
    {
        *sbus_data  =  avago_mdio_rd(aapl, addr_struct.chip, AVSP_DEVAD, REG_SBUS_DATA_OUT_LO) & 0xffff;
        *sbus_data |= (avago_mdio_rd(aapl, addr_struct.chip, AVSP_DEVAD, REG_SBUS_DATA_OUT_HI) & 0xffff) << 16;
    }
    AAPL_LOG_PRINT8(aapl, AVAGO_DEBUG8, __func__, __LINE__, "MDIO loop retries/count/limit = %d/%d/%d\n", try_count, count, limit);

    return rc;
}

/** @endcond */

#endif /* AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO */

