/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/** Doxygen File Header */
/** @file */
/** @brief PMRO device specific functions. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

/* On a fast system, it is possible to read the PMRO results before they are */
/* updated.  In this case, the read returns 0.  So, we re-do the read */
/* several times, inserting a 1ms sleep after three reads of 0. */
/* We timeout and return 0 after 2ms sleeping in the case where sbus reset */
/* is not implemented. */
static uint avago_sbus_rd_until_valid(Aapl_t *aapl, uint addr, int reg)
{
    int loop;
    uint total = 0;
    for( loop = 0; loop < 5; loop++ )
    {
        if( loop >= 3 )
            ms_sleep(1);
        if( (total = avago_sbus_rd(aapl, addr, reg)) != 0 )
            break;
    }
    if( loop > 0 )
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "loop = %d\n", loop);
    return total;
}

/** @brief   Measures process performance of the chip. */
/** @details The returned value is dependent on the reference clock frequency. */
/**          As a result, values obtained with different reference clock */
/**          frequencies cannot be meaningfully compared. */
/** @return  Returns a number indicating propagation delay through */
/**          a set of gates and interconnects. */
/**          A higher number indicates faster process performance. */
uint avago_pmro_get_metric(
    Aapl_t *aapl,        /**< [in] Pointer to AAPL structure */
    uint addr)           /**< [in] SBus address of SerDes */
{
    uint total;
    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 2, AVAGO_PMRO, AVAGO_PMRO2) )
        return 0;
    if( aapl->capabilities & AACS_SERVER_NO_CRC )
        return 0;

    avago_sbus_reset(aapl, addr, 0);
    avago_sbus_wr(aapl, addr, 0, 1);
    total = avago_sbus_rd_until_valid(aapl, addr, 6);
    if( total == 0 )    /* Perhaps soft SBus reset isn't implemented? */
    {
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Working around non-implemented soft SBus reset.\n");
        /* Explicitly reset all modifyable PMRO registers: */
        avago_sbus_wr(aapl, addr, 0, 0x00000000);
        avago_sbus_wr(aapl, addr, 1, 0x0000ffff);
        avago_sbus_wr(aapl, addr, 2, 0x0000ffff);
        avago_sbus_wr(aapl, addr, 3, 0x0000ffff);
        avago_sbus_wr(aapl, addr, 4, 0x0000ffff);
        avago_sbus_wr(aapl, addr, 5, 0x00fff000);
        avago_sbus_wr(aapl, addr, 6, 0x00000000);
        avago_sbus_wr(aapl, addr, 0, 1);
        total = avago_sbus_rd_until_valid(aapl, addr, 6);
    }
    return total;
}

#if AAPL_ENABLE_DIAG && AAPL_ENABLE_FLOAT_USAGE

#define AVAGO_PMRO_CNTL_ADDR        0xf8
#define AVAGO_PMRO_REFCLK_CNTR_ADDR 0xfd
#define AVAGO_PMRO_OSC_CNTR_ADDR    0xfe
const uint  pmro28_loop_addr[] = {0xf9, 0xfa, 0xfb, 0xfc};

static int run_loop(Aapl_t *aapl, uint addr, uint repetitions)
{
    /* Run a collection */
    uint start = 0xFFFFFF - repetitions;
    avago_sbus_wr(aapl, addr, AVAGO_PMRO_REFCLK_CNTR_ADDR, start);  /* set loops */
    avago_sbus_wr(aapl, addr, AVAGO_PMRO_OSC_CNTR_ADDR, 0);         /* clear old count */
    avago_sbus_wr(aapl, addr, AVAGO_PMRO_CNTL_ADDR, 1);             /* run */
    while( avago_sbus_rd(aapl, addr, AVAGO_PMRO_CNTL_ADDR) )
        continue;                                                   /* wait */
    return avago_sbus_rd(aapl, addr, AVAGO_PMRO_OSC_CNTR_ADDR);     /* return count */
}


const char *pmro28_loop_name[] = {"SVT", "HVT", "LVT", "ULVT"};
const char *pmro16_loop_name[] = {"SVT", "LVT", "ULVT", "WIRE"};
const uint  pmro28_print_ele[] = {1,0,0,0};
const uint  pmro16_print_ele[] = {1,0,0,1};

static const char *pmro_ele_path[] =
{ "Inverter",
  "NAND2 fastest input",
  "NAND2 slowest input",
  "NOR2  fastest input",
  "NOR2  slowest input",
  "XOR2  fastest input, invert",
  "XOR2  slowest input, invert",
  "XOR2  fastest input, non-invert",
  "XOR2  slowest input, non-invert",
  "NAND3 slowest input",
  "NOR3  slowest input",
  "AOI22 fastest input",
  "AOI22 2nd-fastest input",
  "AOI22 3rd-fastest input",
  "AOI22 slowest input",
  "Buffer"
};

static const char *pmro_wire_path[] =
{ "SVT  inv Vert",
  "SVT  inv Horz",
  "SVT  buf Vert",
  "SVT  buf Horz",
  "LVT  inv Vert",
  "LVT  inv Horz",
  "LVT  buf Vert",
  "LVT  buf Horz",
  "ULVT inv Vert",
  "ULVT inv Horz",
  "ULVT buf Vert",
  "ULVT buf Horz",
  "SVT  inv x3",
  "LVT  inv x3",
  "ULVT inv x3",
  "SVT  buf x1"
};

static const char **pmro28_ele_path2d[] =
      {pmro_ele_path,pmro_ele_path,pmro_ele_path,pmro_ele_path};
static const char **pmro16_ele_path2d[] =
      {pmro_ele_path,pmro_ele_path,pmro_ele_path,pmro_wire_path};

static Avago_pmro_loop_t *avago_pmro_loop_construct(Aapl_t *aapl)
{
    Avago_pmro_loop_t *config = (Avago_pmro_loop_t *)aapl_malloc(aapl, sizeof(Avago_pmro_loop_t), "Avago_pmro_loop_t");
    if( config )
        memset(config, 0, sizeof(Avago_pmro_loop_t));
    return config;
}

/** @brief Allocates and initializes an Avago_pmro_t structure. */
Avago_pmro_t *avago_pmro_construct(
    Aapl_t *aapl)       /**< [in] Pointer to Aapl_t structure. */
{
    Avago_pmro_t *config = (Avago_pmro_t *)aapl_malloc(aapl, sizeof(Avago_pmro_t), "Avago_pmro_t");

    if( config )
    {
        int i;
        memset(config, 0, sizeof(Avago_pmro_t));
        config->repetitions = 32767;
        config->clock_freq = 156.25;    /* MHz.  Default value. */

        for( i = 0; i < 4; i++ )
            config->loop[i] = avago_pmro_loop_construct(aapl);
    }
    return config;
}

/** @brief Frees memory associated with a Avago_pmro_t structure. */
void avago_pmro_destruct(
    Aapl_t *aapl,         /**< [in] Pointer to Aapl_t structure. */
    Avago_pmro_t *config) /**< [in] Structure to free. */
{
    int i;
    for( i = 0; i < 4; i++ )
        aapl_free(aapl, config->loop[i], "Avago_pmro_t->loop");
    aapl_free(aapl, config, "Avago_pmro_t");
}

static void run_ring(Aapl_t *aapl, uint sbus_addr, int ring_sel, Avago_pmro_t *config)
{
    /*int total; */
    /*double clock = config->clock_freq * 1e6; */
    /*double ele_tpd; */
    /*double tot_tpd; */
    int i;

    /* No rollover protection on counters, set max count */
    if( config->repetitions >= 0x7FFFFF )
        config->repetitions = 0x7FFFFF;

    /*aapl_buf_add(aapl, &buf, &buf_end, &size, "Repetitions %d\n", config->repetitions); */

    /* Disable all loops */
    for( i = 0; i < 4; i++ )
        avago_sbus_wr(aapl, sbus_addr, pmro28_loop_addr[i], 0);

    /* Include all elements */
    avago_sbus_wr(aapl, sbus_addr, pmro28_loop_addr[ring_sel], 0xFFFF);
    config->loop[ring_sel]->total_delay =  run_loop(aapl,sbus_addr,config->repetitions);
    /*total = config->loop[ring_sel]->total_delay; */
    /*tot_tpd = 0.5e12 / (clock * (double) total / config->repetitions); */
    /*aapl_buf_add(aapl, &buf, &buf_end, &size, "Ring %d: Entire loop: %d  %.1f\n",ring_sel, total, tot_tpd); */
    for( i = 0; i < 16; i++ )
    {
        /*int delay; */
        avago_sbus_wr(aapl, sbus_addr, pmro28_loop_addr[ring_sel], ~(1 << i) & 0xFFFF);
        config->loop[ring_sel]->delay[i] = run_loop(aapl,sbus_addr,config->repetitions);
        /*delay = config->loop[ring_sel]->delay[i]; */
        /*ele_tpd = 0.5e12 / (clock * (double) delay / config->repetitions); */
        /*aapl_buf_add(aapl, &buf, &buf_end, &size, "Ring %d: Without index %2d Count: %d Time/cell: %.1f  Delta %.1f\n",ring_sel, i, delay, ele_tpd, (tot_tpd-ele_tpd)/50); */
    }
}

/** @brief  Measures PMRO timing values. */
/** @return On success, writes timing values into config and returns 0. */
/** @return Returns -1 if addr does not select a PMRO device. */
int avago_pmro_get_results(
    Aapl_t *aapl,         /**< [in] Pointer to AAPL structure */
    uint addr,            /**< [in] SBus address of SerDes */
    Avago_pmro_t *config) /**< [in,out] Configuration parameters and placeholder for timing results */
{
    int i;
    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 2, AVAGO_PMRO, AVAGO_PMRO2) )
        return -1;

    for( i = 0; i < 4; i++ )
        if( !config->disable_loop[i] )
            run_ring(aapl, addr, i, config);

    return 0;
}

/** @brief   Displays the timing results collected by avago_pmro_get_results(). */
/** @details A text table is written to stdout. */
void avago_pmro_print_results(
    Aapl_t *aapl,         /**< [in] Pointer to AAPL structure */
    uint sbus_addr,       /**< [in] SBus address of SerDes */
    Avago_pmro_t *config) /**< [in] Timing results to display */
{
  double clock = config->clock_freq * 1e6;
  int    total = 0;
  double sum = 0;
  double total_column[4] = {0, 0, 0, 0};
  const uint   *print_ele;
  const char  **loop_name;
  const char  ***ele_path;
  int vt, i, j;
  char *buf = 0;
  char *buf_end = 0;
  int size = 0;
  int count = 0;
  int div;

  switch (aapl_get_process_id(aapl, sbus_addr) ) {
    case AVAGO_TSMC_07 : {loop_name  = pmro16_loop_name;
                          ele_path   = pmro16_ele_path2d;
                          print_ele  = pmro16_print_ele;
                          div        = 20;  /* Should be 20, but for compatibility for now... */
                          count      = 36;
                          break;}
    case AVAGO_TSMC_16 : {loop_name  = pmro16_loop_name;
                          ele_path   = pmro16_ele_path2d;
                          print_ele  = pmro16_print_ele;
                          div        = 50;  /* Should be 20, but for compatibility for now... */
                          count      = 36;
                          break;}
    default            : {loop_name  = pmro28_loop_name;
                          ele_path   = pmro28_ele_path2d;
                          print_ele  = pmro28_print_ele;
                          div        = 50;
                          count      = 0;
                          break;}
  }
  for (vt = 0; vt < 4; vt++) {
    total += (int) (0.5e12 / (clock * config->loop[vt]->total_delay / config->repetitions));
  }
  aapl_buf_add(aapl, &buf, &buf_end, &size, "\n");
  for(j=-4; j < 16; j++) {
    for(i=0; i < 4; i++) {
      if (print_ele[i]) {
        if (i > 0) aapl_buf_add(aapl, &buf, &buf_end, &size, "    ");
        switch (j) {
          case -4 :
          case -1 : aapl_buf_add(aapl, &buf, &buf_end, &size, "%-32s","--------------------------------"); break;
          case -3 : aapl_buf_add(aapl, &buf, &buf_end, &size, "%-30s",""); break;
          case -2 : aapl_buf_add(aapl, &buf, &buf_end, &size, "%-32s","Element"); break;
          default : aapl_buf_add(aapl, &buf, &buf_end, &size, "%-32s",ele_path[i][j]); break;
        }
      }
      switch (j) {
        case -4 :
        case -1 : aapl_buf_add(aapl, &buf, &buf_end, &size, "%-6s","------"); break;
        case -3 : if (print_ele[i]) aapl_buf_add(aapl, &buf, &buf_end, &size, "Tpd (ps)");
                  else              aapl_buf_add(aapl, &buf, &buf_end, &size, "        ");
                  break;
        case -2 : aapl_buf_add(aapl, &buf, &buf_end, &size, "%6s",loop_name[i]); break;
        default: {
                   double tot_tpd = 0.5e12 / (clock * config->loop[i]->total_delay / config->repetitions);
                   double ele_tpd = 0.5e12 / (clock * config->loop[i]->delay[j] / config->repetitions);
                   int divider = (j >= 12 || i != 3) ? 50 : div;
                   double value = (tot_tpd - ele_tpd)/divider;
                   aapl_buf_add(aapl, &buf, &buf_end, &size, "%6.1f", value);
                   sum += value;
                   total_column[i] += value;
                 }
      }
    }
    aapl_buf_add(aapl, &buf, &buf_end, &size, "\n");
  }
  aapl_buf_add(aapl, &buf, &buf_end, &size, "Sum for each column:             %5.1f %5.1f %5.1f %*s%5.1f\n", total_column[0], total_column[1], total_column[2], count," ", total_column[3]);
  aapl_buf_add(aapl, &buf, &buf_end, &size, "Sum of all individual delays:       %8.1f ps\n", sum);
  aapl_buf_add(aapl, &buf, &buf_end, &size, "One-way time through entire chain:  %6d   ps\n", total);

  total =  avago_pmro_get_metric(aapl, sbus_addr);
  aapl_buf_add(aapl, &buf, &buf_end, &size, "Simple PMRO metric:                 %6d (0x%x)\n", total, total);
  aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "%s", buf);
  aapl_free(aapl, buf, __func__);
}

#endif /* AAPL_ENABLE_DIAG && AAPL_ENABLE_FLOAT_USAGE */
