/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

/** Doxygen File Header */
/** @file */
/** @brief Functions for running repeated DFE tunings. */

#if AAPL_ENABLE_DIAG

/*============================================================================= */
/* SERDES GET ERRORS */
/** */
/** @brief Run repeated DFE tunings and log information for each run. */
/** @param aapl       aapl struct */
/** @param sbus_addr  SBus address of the SerDes */
/** @return  All information added to AAPL_LOG */
/** @details Parses the dfe_repeat struct to determine what to run */
/**          will run dfe_repeat->loop number of dfe tuning loops. */
void avago_serdes_dfe_repeat(Aapl_t *aapl, uint sbus_addr, Avago_serdes_dfe_repeat_t *config)
{
  uint i,j,k;
  uint error, dfe_status;
  int  delay_cal_pt;
  Avago_serdes_tx_eq_t tx_eq;
  int sdrev = aapl_get_sdrev(aapl,sbus_addr);
  BOOL is_cm4 = (sdrev == AAPL_SDREV_CM4) || (sdrev == AAPL_SDREV_CM4_16);

  if (!aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, TRUE, 2, AVAGO_SERDES, AVAGO_M4)) return;
  if (!aapl_check_process(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28)) return;
  if ( (config->rx_temp_addr > 0) && !aapl_check_ip_type(aapl, config->rx_temp_addr, __func__, __LINE__, TRUE, 1, AVAGO_THERMAL_SENSOR) ) return;


  /* In case some script using backdoors didn't clean up */
  avago_sbus_wr(aapl, sbus_addr, 0x01, 0x20000000); /* Clear Dmem overrides */
  avago_sbus_wr(aapl, sbus_addr, 0x20, 0x00000000); /* Clear BP enables */

  config->pmd_config->sbus_addr = sbus_addr;

  for(i=0; i<config->loops; i++) {
    uint dfe_status_last;
    /* Check if init to be run */
    if ( (config->init == AVAGO_DFE_REPEAT_INIT_ALL) ||
        ((config->init == AVAGO_DFE_REPEAT_INIT_ONCE) && i==0) ) {
      Avago_serdes_init_config_t * init_config = avago_serdes_init_config_construct(aapl);
      init_config->init_tx = config->init_tx;
      init_config->init_rx = config->init_rx;
      init_config->sbus_reset = TRUE;
      init_config->init_mode = AVAGO_PRBS31_ELB;
      init_config->tx_divider = config->divider;
      init_config->rx_divider = config->divider;
      init_config->rx_width = config->width_mode;
      init_config->tx_width = config->width_mode;
      init_config->tx_phase_cal = config->phase_cal;
      init_config->signal_ok_en = config->signal_ok_en;
      init_config->tx_encoding = config->encoding;
      init_config->rx_encoding = config->encoding;
      avago_serdes_init(aapl, sbus_addr, init_config);
      avago_serdes_init_config_destruct(aapl, init_config);
      avago_serdes_set_rx_term(aapl,sbus_addr,config->term);

      avago_serdes_set_tx_data_sel(aapl,sbus_addr,config->prbs);
      avago_serdes_set_rx_cmp_data(aapl,sbus_addr,(Avago_serdes_rx_cmp_data_t)(config->prbs));
      /*serdes_data_sel(aapl,sbus_addr,config->init_tx_rx, config->prbs, 0, SERDES_WR); */
      tx_eq.pre=config->pre; tx_eq.pre2=config->pre2; tx_eq.pre3=config->pre3;
      tx_eq.atten=config->atten; tx_eq.post=config->post;
      avago_serdes_set_tx_eq(aapl,sbus_addr,&tx_eq);
    }
    /* Print configuration */
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Server: %s ",aapl->aacs_server);
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"SBusRx: %s ",aapl_addr_to_str(sbus_addr));
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Channel: %s ",config->channel_name);
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0," Chip: %s-%s ",aapl_get_chip_name(aapl,sbus_addr),aapl_get_chip_rev_str(aapl,sbus_addr));
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"SerDes: %s ", avago_get_ip_info(aapl, sbus_addr)->rev_id_name);
    if (config->multi_line)
      aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"\n");

    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Volt: %0.2f V ",config->voltage);
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Temp: %3.1f C ",(float)config->temp);
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Encoding: %s", (config->encoding == AVAGO_SERDES_PAM4) ? "PAM4 " : "NRZ ");
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Rate: %.5f Gbaud (%d) ",config->refclk*config->divider*1e-9,config->divider);
    if (config->multi_line)
      aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"\n");

    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"BUILD: %04x ",avago_spico_int(aapl,sbus_addr,0x3f,0x00));
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"FIRMWARE_REVISION: %04x ",avago_spico_int(aapl,sbus_addr,0x00,0x00));
    if (config->multi_line)
      aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"\n");

    /* Tx Eq */
    avago_serdes_get_tx_eq(aapl,sbus_addr,&tx_eq); /* Read current Tx Eq setting */
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"TxPRE: %d TxATTEN: %d TxPOST: %d TxPRE2: %d TxPRE3: %d ",tx_eq.pre,tx_eq.atten,tx_eq.post,tx_eq.pre2,tx_eq.pre3);

    /* Rx TERM */
    switch(avago_serdes_get_rx_term(aapl,sbus_addr)) {
      case AVAGO_SERDES_RX_TERM_AVDD  : {aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"TERM: AVDD "); break;}
      case AVAGO_SERDES_RX_TERM_AGND  : {aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"TERM: AGND "); break;}
      case AVAGO_SERDES_RX_TERM_FLOAT : {aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"TERM: FLOAT "); break;}
      default: aapl_fail(aapl, __func__, __LINE__, "RX_TERM not supported\n");
    }
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"PMD_TRAIN: %d ",config->pmd_train);
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"PCIE_MODE: %d ",config->pcie_mode);
    if (config->multi_line)
      aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"\n");

    /* set dfe_tap_disable */
    if (!is_cm4)
    {
      if (config->dfe_tap_disable){
          k = config->dfe_tap_disable_mask;
          k >>= 1;
          for(j=1; j<AVAGO_DFE_TAP_COUNT+1; j++){
            if (k & 0x01)
              config->dfe_state->dfe_tap_disable[j] = TRUE;
            k >>= 1;
          }
      }
    }
    /* Check for PCIe mode */
    if (config->pcie_mode) {
      avago_spico_int(aapl,sbus_addr,0x0026,0x5201);
      avago_spico_int(aapl,sbus_addr,0x0024,0x0001);
    } else {
      /* Only tune if never flag is false */
      if (!config->tune_never) {
        /* If once flag and loop 0, then tune once, OR if once flag not set, tune everytime */
        if ( (config->tune_once && (i==0)) || !config->tune_once) {
          /* Launch Tuning */
          if (config->pmd_train)
            avago_serdes_pmd_train(aapl,config->pmd_config);
          else
            avago_serdes_dfe_tune(aapl,sbus_addr,config->dfe_state);
        }
      }
    }

    /* Do temperature measurement while tuning runs */
    if (config->rx_temp_addr > 0) { /* Check if thermal sensor address is defined */
      /* Check if configured to program thermal sensor and we've been given REFCLK frequency */
      if ( (config->rx_temp_configure) && (i==0) && (config->refclk > 0) ) {
        uint temp_divider = (int) (config->refclk / 2e6);
        avago_sbus_wr(aapl,config->rx_temp_addr,0x0,0x1);          /* Assert reset */
        avago_sbus_wr(aapl,config->rx_temp_addr,0x1,temp_divider); /* Set divider value */
        avago_sbus_wr(aapl,config->rx_temp_addr,0x0,0x0);          /* Clear reset */
      }
      for(j=0; j<config->temp_sensor_cnt; j++) {
        int temp = avago_sbm_get_temperature(aapl,config->rx_temp_addr,j);
        if ( (config->multi_line) && (j>0) && (j%4 == 0) )
          aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"\n");
        aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"TEMP_SENSOR%d: %3.3f ",j,(float)temp/1000.0);
      }
    }
    if (config->multi_line)
      aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"\n");

    /* Wait for iCal DFE tuning to complete */
    k = config->timeout;
    j = 1;
    dfe_status_last = 0x03;
    do {
      ms_sleep(1000);
      k--;
      dfe_status = avago_spico_int(aapl,sbus_addr , 0x126, (0 << 12) | (0xb << 8) );
      if (dfe_status_last == dfe_status)
        j = dfe_status != 0x80;
      dfe_status_last = dfe_status;
    } while (j && k);
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"TUNE_TIME : %d ",config->timeout-k);
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"EID_FAIL: %d ",(dfe_status & 0x200) == 0x200);
    dfe_status = avago_spico_int(aapl,sbus_addr , 0x126, (0 << 12) | (0xa << 8) ); /* get DFE state to debug where tuning timed out */
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"DFE_STATE: %d ",dfe_status);
    dfe_status = avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_LSB, 0x27);           /* Read o_core_status */
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"CORE_STATUS: %d ",dfe_status);
    if (k==0)
      aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"WARNING: DFE tuning timed out after %d seconds\n", config->timeout);
    /* Wait for KR/DFE tuning to complete */
    j = 0;
    do {
      uint x = avago_serdes_mem_rd(aapl,sbus_addr,AVAGO_LSB_DIRECT,AVSD_LSB_CORE_STATUS);
      if ( (x & 0x0010) || (x & 0x0001) ) /* end if signal_ok or training_failure are asserted */
        break;
      j++; /* breakout counter */
    } while (j < 10000);
    if (config->pmd_train) {
      Avago_serdes_pmd_debug_t *pmd_dbg;
      pmd_dbg = avago_serdes_pmd_debug_construct(aapl);
      /* Re-configure PRBS mode since KR sets it to CORE */
      avago_serdes_set_tx_data_sel(aapl, sbus_addr, AVAGO_SERDES_TX_DATA_SEL_PRBS31);
      avago_serdes_set_rx_cmp_data(aapl, sbus_addr, AVAGO_SERDES_RX_CMP_DATA_PRBS31);
      avago_serdes_set_rx_cmp_mode(aapl, sbus_addr, AVAGO_SERDES_RX_CMP_MODE_MAIN_PATGEN);
      avago_serdes_pmd_debug(      aapl, sbus_addr, pmd_dbg);
      avago_serdes_pmd_debug_print_repeat(aapl, pmd_dbg);
      avago_serdes_pmd_debug_destruct(aapl, pmd_dbg);
    }

    /* Print DFE results */
    avago_serdes_get_dfe_state(aapl,sbus_addr,config->dfe_state);

    /* Print out all debug information when doing repeat logs */
    j = aapl->debug;  /* Save current debug setting */
    aapl->debug = 1;  /* Set it to 1 */

    { /* local context for *buf */
        char * buf = avago_serdes_dfe_state_to_str(aapl,sbus_addr,config->dfe_state,!config->multi_line, 1, 1);
        if (buf)
        {
            aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0, "%s", buf);
            aapl_free(aapl, buf, __func__);
        }
        dfe_status = avago_spico_int(aapl,sbus_addr , 0x25, 0x200); /* Read PI setting */
        aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"PI: %d ",dfe_status);
        if (aapl_get_sdrev(aapl, sbus_addr) == AAPL_SDREV_16) {
          dfe_status = avago_serdes_mem_rd(aapl,sbus_addr,AVAGO_LSB_DIRECT,0x93);  /* Read Clock setting */
          aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"RX_CLKS: %d ",dfe_status);
          dfe_status = avago_serdes_mem_rd(aapl,sbus_addr,AVAGO_LSB_DIRECT,0xb7);  /* Read Delay clock setting */
          aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"RX_DLY_LINE: %d ",dfe_status);
          dfe_status = avago_serdes_mem_rd(aapl,sbus_addr,AVAGO_LSB_DIRECT,0xb3);  /* Read Delay line setting */
          aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"RX_DLY_VAL_DATA: %d ",dfe_status&0xFF);
          dfe_status = avago_serdes_mem_rd(aapl,sbus_addr,AVAGO_LSB_DIRECT,0xb4);  /* Read Delay line setting */
          aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"RX_DLY_VAL_TEST: %d ",(dfe_status>>8)&0xFF);
          aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"RX_DLY_VAL_EDGE: %d ",(dfe_status>>0)&0xFF);
        }
    }
    aapl->debug = j;  /* Restore back to original setting */
    if (0) {
#if AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT
    if ( i == 0 ) {/* only delay cal on first loop */
      int start, stop;
      avago_serdes_set_rx_cmp_data(aapl, sbus_addr, AVAGO_SERDES_RX_CMP_DATA_PRBS31);
      avago_serdes_set_rx_cmp_mode(aapl, sbus_addr, AVAGO_SERDES_RX_CMP_MODE_MAIN_PATGEN);
      delay_cal_pt = avago_serdes_delay_cal(aapl, sbus_addr, 0 /*pi mode*/, 1e8, &start, &stop);
      aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"DLY_CAL_START: %d DLY_CAL_STOP: %d ",start,stop);
    } else {
      aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"DLY_CAL_START: %d DLY_CAL_STOP: %d ",0,0);
    }
#endif
    aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"DLY_CAL_PT: %d ",delay_cal_pt);
    }
    /* DFE validation */
    /* Error count */
    if (config->enable_error_check) {
      double qvalue = 0.0;
      avago_spico_int_check(aapl, __func__, __LINE__, sbus_addr,0x0103,0x0000);
      avago_spico_int_check(aapl, __func__, __LINE__, sbus_addr,0x0203,0x0200);

      error = 0; /* error count sum */
      for(j=0; j<config->error_loops; j++) {
        avago_spico_int_check(aapl, __func__, __LINE__, sbus_addr,0x03,0x0203); /* Do an error count */
        avago_spico_int_check(aapl, __func__, __LINE__, sbus_addr,0x1d,0x0000); /* wait for error count to complete */
        error += avago_serdes_get_errors(aapl,sbus_addr,AVAGO_LSB,1); /* Get errors */
        if (error > config->error_threshold)
          break;
      }
#     if AAPL_ENABLE_EYE_MEASUREMENT
      qvalue = avago_qfuncinv((double)error/(double)((double)(j+1)*(double)0x02000000*(double)config->width_mode));
#     endif
      aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,
                      "ERROR: %16d %08x LOOPS: %d ERROR_COUNT_UI: %e BER_MEASURED: %e Q_MEASURED: %.4f ",
                      error,error,j,
                      (float)((j+1)*0x02000000*config->width_mode),
                      (float)error/(float)((j+1)*0x02000000*config->width_mode),
                      qvalue);
      if (config->multi_line) {
        aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"\n");
      }
      avago_spico_int_check(aapl, __func__, __LINE__, sbus_addr,0x03,0x0000); /* Free error counter */
    }
#       if AAPL_ENABLE_EYE_MEASUREMENT
        /* Bath-Tub Curve */
        if ( (config->btc_mode == AVAGO_DFE_REPEAT_BTC_ALL) ||
             (config->btc_mode == AVAGO_DFE_REPEAT_BTC_LAST) ||
             (config->btc_mode == AVAGO_DFE_REPEAT_BTC_FIRST) )
        {
            Avago_serdes_eye_config_t *eye_config = 0;
            Avago_serdes_eye_data_t   *eye_data = 0;
            if (config->btc_mode != AVAGO_DFE_REPEAT_BTC_NONE) {
                /* Bath-Tub Curve calculations enabled, create structs */
                eye_config = avago_serdes_eye_config_construct(aapl);
                eye_data   = avago_serdes_eye_data_construct(aapl);

                /* Do size mode only since we only want BTC info */
                eye_config->ec_eye_type = AVAGO_EYE_SIZE;
            }

            /* Doing or did a BTC */
            if ( (config->btc_mode == AVAGO_DFE_REPEAT_BTC_ALL) ||
            ( (config->btc_mode == AVAGO_DFE_REPEAT_BTC_FIRST) && (i==0)) ||
            ( (config->btc_mode == AVAGO_DFE_REPEAT_BTC_LAST ) && (i==(config->loops-1))) ) {
                if (is_cm4){
                  eye_data->ed_apply_vert_alpha = 0;
                } else {
                  /* Use the Eye height from DFE tuning to drive how many Y points we need */
                  eye_data->ed_apply_vert_alpha = 3; /* use TLEV array in firmware */
                  eye_config->ec_y_points = config->dfe_state->dataLEV[1] - config->dfe_state->dataLEV[0] + 20;
                }
                eye_config->ec_eye_type = AVAGO_EYE_SIZE;
                eye_config->ec_max_dwell_bits = config->btc_dwell;
                eye_config->ec_min_dwell_bits = config->btc_dwell;
                eye_config->ec_error_threshold = 30;
                avago_serdes_eye_get(aapl, sbus_addr, eye_config, eye_data);
                avago_spico_int_check(aapl, __func__, __LINE__, sbus_addr,0x03,0x0000); /* Free error counter */
            } else {
                eye_data->ed_y_points = 0;
                eye_data->ed_vbtc[0].Vmean = -999;
                eye_data->ed_vbtc[0].vert_eye_1e17 = -999;
                eye_data->ed_vbtc[0].height_0mV    = -999.9;
                eye_data->ed_hbtc[0].horz_eye_1e17 = -999;
                eye_data->ed_hbtc[0].width_0mUI    = -999.9;
            }
            /* Need to always print data if we ever printed it once */
            if (!is_cm4)
            {
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Vert_pts: %d ", eye_data->ed_y_points);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Vmean: %d ",    eye_data->ed_vbtc[0].Vmean);

              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Veye_1e03: %d "   ,eye_data->ed_vbtc[0].vert_eye_1e03);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Veye_1e04: %d "   ,eye_data->ed_vbtc[0].vert_eye_1e04);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Veye_1e05: %d "   ,eye_data->ed_vbtc[0].vert_eye_1e05);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Veye_1e06: %d "   ,eye_data->ed_vbtc[0].vert_eye_1e06);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Veye_1e17: %d "   ,eye_data->ed_vbtc[0].vert_eye_1e17);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Veye_0mV_Q: %.1f ",eye_data->ed_vbtc[0].height_0mV);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Vslope_bot: %.1f ",eye_data->ed_vbtc[0].bottom_slope);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Vintercept_bot: %.1f ",eye_data->ed_vbtc[0].bottom_intercept);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Vslope_top: %.1f ",eye_data->ed_vbtc[0].top_slope);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Vintercept_top: %.1f ",eye_data->ed_vbtc[0].top_intercept);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"V_rsquared_top: %.1f ",eye_data->ed_vbtc[0].top_R_squared);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"V_rsquared_bottom: %.1f ",eye_data->ed_vbtc[0].bottom_R_squared);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Heye_1e03: %d "   ,eye_data->ed_hbtc[0].horz_eye_1e03);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Heye_1e04: %d "   ,eye_data->ed_hbtc[0].horz_eye_1e04);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Heye_1e05: %d "   ,eye_data->ed_hbtc[0].horz_eye_1e05);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Heye_1e06: %d "   ,eye_data->ed_hbtc[0].horz_eye_1e06);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Heye_1e17: %d "   ,eye_data->ed_hbtc[0].horz_eye_1e17);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Heye_0mV_Q: %.1f ",eye_data->ed_hbtc[0].width_0mUI);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Hslope_left: %.1f ",eye_data->ed_hbtc[0].left_slope);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Hintercept_left: %.1f ",eye_data->ed_hbtc[0].left_intercept);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Hslope_right: %.1f ",eye_data->ed_hbtc[0].right_slope);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Hintercept_right: %.1f ",eye_data->ed_hbtc[0].right_intercept);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"H_rsquared_right: %.1f ",eye_data->ed_hbtc[0].right_R_squared);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"H_rsquared_left: %.1f ",eye_data->ed_hbtc[0].left_R_squared);

              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Combined_btc_BER: %4.2e\n", eye_data->ed_combined_btc_ber);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Combined_btc_Q: %5.2f\n", eye_data->ed_combined_btc_qval);
            }
            else
            {
              int i;
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Vert_pts: %d ", eye_data->ed_y_points);
              aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Vmean: %d ",    eye_data->ed_vbtc[0].Vmean);

              for( i = 0; i < AAPL_ARRAY_LENGTH(eye_data->ed_vbtc); i++ )
              {
                  const char *label;
                  if(      i == 0 ) label = "Le";
                  else if( i == 1 ) label = "Lo";
                  else if( i == 2 ) label = "Me";
                  else if( i == 3 ) label = "Mo";
                  else if( i == 4 ) label = "Ue";
                  else              label = "Uo";

                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Veye_1e03_%s: %d "           ,label,eye_data->ed_vbtc[i].vert_eye_1e03);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Veye_1e04_%s: %d "           ,label,eye_data->ed_vbtc[i].vert_eye_1e04);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Veye_1e05_%s: %d "           ,label,eye_data->ed_vbtc[i].vert_eye_1e05);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Veye_1e06_%s: %d "           ,label,eye_data->ed_vbtc[i].vert_eye_1e06);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Veye_1e17_%s: %d "           ,label,eye_data->ed_vbtc[i].vert_eye_1e17);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Veye_0mV_Q_%s: %.1f "        ,label,eye_data->ed_vbtc[i].height_0mV);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Vslope_bot_%s: %.1f "        ,label,eye_data->ed_vbtc[i].bottom_slope);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Vintercept_bot_%s: %.1f "    ,label,eye_data->ed_vbtc[i].bottom_intercept);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Vslope_top_%s: %.1f "        ,label,eye_data->ed_vbtc[i].top_slope);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Vintercept_top_%s: %.1f "    ,label,eye_data->ed_vbtc[i].top_intercept);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"V_rsquared_top_%s: %.1f "    ,label,eye_data->ed_vbtc[i].top_R_squared);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"V_rsquared_bottom_%s: %.1f " ,label,eye_data->ed_vbtc[i].bottom_R_squared);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Heye_1e03_%s: %d "           ,label,eye_data->ed_hbtc[i].horz_eye_1e06);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Heye_1e04_%s: %d "           ,label,eye_data->ed_hbtc[i].horz_eye_1e06);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Heye_1e05_%s: %d "           ,label,eye_data->ed_hbtc[i].horz_eye_1e06);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Heye_1e06_%s: %d "           ,label,eye_data->ed_hbtc[i].horz_eye_1e06);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Heye_1e17_%s: %d "           ,label,eye_data->ed_hbtc[i].horz_eye_1e17);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Heye_0mV_Q_%s: %.1f "        ,label,eye_data->ed_hbtc[i].width_0mUI);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Hslope_left_%s: %.1f "       ,label,eye_data->ed_hbtc[i].left_slope);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Hintercept_left_%s: %.1f "   ,label,eye_data->ed_hbtc[i].left_intercept);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Hslope_right_%s: %.1f "      ,label,eye_data->ed_hbtc[i].right_slope);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"Hintercept_right_%s: %.1f "  ,label,eye_data->ed_hbtc[i].right_intercept);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"H_rsquared_right_%s: %.1f "  ,label,eye_data->ed_hbtc[i].right_R_squared);
                  aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"H_rsquared_left_%s: %.1f "   ,label,eye_data->ed_hbtc[i].left_R_squared);
              }
            }
            /* Destroy Eye plot structs */
            avago_serdes_eye_config_destruct(aapl,eye_config);
            avago_serdes_eye_data_destruct(aapl,eye_data);
        }
#       endif /* AAPL_ENABLE_EYE_MEASUREMENT */
        aapl_log_printf(aapl,AVAGO_MEM_LOG,"",0,"\n"); /* Newline at end of every loop */
    }

#if AAPL_ENABLE_FILE_IO
    if(config->use_file)
    {
        FILE *file;
        const char *log_str;

        file = fopen(config->file_name, "w");
        if(file == NULL)
        {
            aapl_fail(aapl, __func__, __LINE__, "Cannot open file: %s", config->file_name);
            return;
        }

        log_str = aapl_log_get(aapl);
        fwrite(log_str, sizeof(char), strlen(log_str), file);
        fclose(file);
        aapl_log_clear(aapl);
    }
#endif /* AAPL_ENABLE_FILE_IO */

}

/*============================================================================= */
/* SERDES DFE REPEAT CONFIG CONSTRUCTOR */
/* */
/** @brief Creates a Avago_serdes_dfe_repeat_t struct */
/** @param aapl aapl struct */
/** @return Avago_serdes_dfe_repeat_t struct */
/** @details mallocs the memory for a Avago_serdes_dfe_repeat_t and returns a pointer */
/** to that memory location.  Sets default values for all members. */
Avago_serdes_dfe_repeat_t * avago_serdes_dfe_repeat_construct(Aapl_t *aapl)
{
    Avago_serdes_dfe_repeat_t * config;
    size_t bytes = sizeof(Avago_serdes_dfe_repeat_t);

    if (! (config = (Avago_serdes_dfe_repeat_t *) aapl_malloc(aapl, bytes, "Avago_serdes_dfe_repeat_t struct"))) return(NULL);

    config->loops        = 100;
    config->timeout      = 120;
    config->refclk       = 0.0;
    config->voltage      = 0.0;
    config->temp         = 999999;
    strcpy(config->channel_name , "UNKNOWN");

    config->disable_other_slices = FALSE;
    config->init                 = AVAGO_DFE_REPEAT_INIT_NEVER;
    config->init_tx              = TRUE;
    config->init_rx              = TRUE;
    config->width_mode           = 40;
    config->phase_cal            = FALSE;
    config->divider              = 10;
    config->signal_ok_en         = TRUE;
    config->prbs                 = AVAGO_SERDES_TX_DATA_SEL_PRBS31;
    config->term                 = AVAGO_SERDES_RX_TERM_AVDD;
    config->encoding             = AVAGO_SERDES_NRZ;

    config->pre   = 0;
    config->pre2  = 0;
    config->pre3  = 0;
    config->atten = 0;
    config->post  = 0;

    config->tune_once = FALSE;
    config->tune_never = FALSE;
    config->pcie_mode = FALSE;
    config->pmd_train = FALSE;
    config->pmd_config= avago_serdes_pmd_config_construct(aapl);
    config->dfe_tap_disable = FALSE;
    config->dfe_tap_disable_mask = 0;
    config->dfe_state = avago_serdes_dfe_state_construct(aapl);

    config->enable_error_check  = TRUE;
    config->error_loops         = 10;
    config->error_threshold     = 30;

    config->btc_mode = AVAGO_DFE_REPEAT_BTC_NONE;
    config->btc_dwell = 1000000;

    config->rx_temp_addr    = 0;
    config->temp_sensor_cnt = 0;

    config->multi_line = FALSE;
    config->use_file   = FALSE;
    config->file_name  = NULL;

    return(config);
}

/*============================================================================= */
/* SERDES DFE REPEAT DESTRUCTOR */
/* */
/** @brief Destroys the provided Avago_serdes_dfe_repeat_t struct. */
/** @param aapl aapl struct */
/** @param config struct to have it's memory usage freed */
/** @return void */
/** @details Frees the memory pointed to by the provided Avago_serdes_dfe_repeat_t struct. */
/** */
void avago_serdes_dfe_repeat_destruct( Aapl_t * aapl, Avago_serdes_dfe_repeat_t * config)
{
    if( config )
    {
        avago_serdes_pmd_config_destruct(aapl,config->pmd_config);
        avago_serdes_dfe_state_destruct(aapl,config->dfe_state);
        aapl_free(aapl, config, "Avago_serdes_dfe_repeat_t struct");
    }
}

#endif /* AAPL_ENABLE_DIAG */
