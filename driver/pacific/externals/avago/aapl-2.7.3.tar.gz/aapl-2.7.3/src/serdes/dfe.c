/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

/** Doxygen File Header */
/** @file */
/** @brief Functions related to the DFE. */

/** @cond INTERNAL */

/** @brief   Reads and summarizes the DFE status flags. */
/** @return  Returns 0 if DFE is complete. */
/** @return  Returns -1 if loss of signal and dfe did not complete. */
/** @return  Returns >0 (dfe_status flags) if DFE is in progress. */
int avago_serdes_interpret_dfe_status(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] SBus slice address. */
{
    int retval;
    int dfe_status = avago_serdes_get_dfe_status(aapl, addr);

    /* If 0 - 2 and 4 - 5 are low, DFE is complete. Return success: */
    if( dfe_status & 0x37 )
        retval = dfe_status & 0x37;
    else
        retval = 0;

    if( dfe_status & 0x200 )
    {
        aapl_fail(aapl, __func__, __LINE__, "DFE Loss of Signal.\n");
        retval = -1;
    }

    return retval;
}

/** @endcond */

/** @brief   Summarizes the DFE status flags for list. */
/** @details If return is greater than 0, it is the logical OR of all */
/**          <b>dfe_status</b> values, which are described in */
/**          avago_parallel_serdes_get_dfe_status(). */
/** @return  Returns 0 if DFE is complete in all SerDes in list. */
/** @return  Returns >0 if DFE is in progress or blocked in any SerDes. */
/** @return  Returns -1 and decrements aapl->return_code on error. */
/** @see     avago_parallel_serdes_get_dfe_status(). */
int avago_parallel_serdes_interpret_dfe_status(
    Aapl_t *aapl,            /**< [in] Pointer to Aapl_t structure. */
    Avago_addr_t *addr_list) /**< [in] List of addresses and dfe status results. */
{
    int combined_dfe_status = 0;
    Avago_addr_t *addr_struct;
    (void)aapl;
    for( addr_struct = addr_list; addr_struct; addr_struct = addr_struct->next )
        combined_dfe_status |= addr_struct->results;
    if( (combined_dfe_status & 0x337) == 0 )    /* If tuning complete on all SerDes. */
        return 0;
    return combined_dfe_status;
}

/** @brief Reads the dfe status flags into the results fields of addr_list. */
/** DFE status bit meanings: */
/** - dfe_status[0] iCal in_prog */
/** - dfe_status[1] pCal in_prog */
/** - dfe_status[2] vos  in_prog */
/** - dfe_status[4] run_ical */
/** - dfe_status[5] run_pcal */
/** - dfe_status[6] run_adaptive */
/** - dfe_status[7] VOS done */
/** - dfe_status[8] EI detected (loss of signal) */
/** - dfe_status[9] Rx not ready */
/** @return Returns 1 if dfe status is identical on all SerDes in list. */
/** @return Returns 0 if dfe status is not identical on all SerDes in list. */
/** @return Returns -1 if dfe status retrieval failed. */
/** @see    avago_parallel_serdes_interpret_dfe_status(). */
int avago_parallel_serdes_get_dfe_status(
    Aapl_t *aapl,                     /**< [in] Pointer to Aapl_t structure. */
    Avago_addr_t *addr_list)          /**< [in] List of addresses and [out] results. */
{
    uint interrupt_code;
    uint interrupt_data;
    uint first_addr = avago_struct_to_addr(addr_list);

    /* Do config checking: */
    if( !avago_parallel_verify_addr_list(aapl, addr_list) )
        return -1;

    switch( aapl_get_sdrev(aapl,first_addr) )
    {
    case AAPL_SDREV_P1:
        interrupt_code = 0x2026;
        interrupt_data = 0x2100;
        break;
    default:
        interrupt_code = 0x0126;
        interrupt_data = 0x0b00;
    }
    return avago_parallel_serdes_int(aapl, addr_list, interrupt_code, interrupt_data);
}

/** @brief  Reads the dfe status flags. */
/** @details The <b>dfe_status</b> values are described in */
/**          avago_parallel_serdes_get_dfe_status(). */
/** @return Returns the dfe status flags value, or -1 on error. */
/** @see    avago_parallel_serdes_get_dfe_status(). */
int avago_serdes_get_dfe_status(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] SBus slice address. */
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr, &addr_struct);
    if( avago_parallel_serdes_get_dfe_status(aapl, &addr_struct) >= 0 )
        return addr_struct.results;
    return -1;
}

/**@cond INTERNAL */

/** @brief Write or read a HAL value. */
static void hal_update_uint_value(
    Aapl_t *aapl,                /**< [in] Pointer to Aapl_t structure. */
    uint addr,                   /**< [in] SBus slice address. */
    BOOL enable_write,           /**< [in] TRUE to write values to SerDes, else read from SerDes. */
    Avago_serdes_hal_type_t hal, /**< [in] HAL register set selector */
    uint member,                 /**< [in] HAL register selector */
    uint *value)                 /**< [in,out] Address of value to update */
{
    if( enable_write )
    {
        avago_serdes_hal_set(aapl, addr, hal, member, *value);
        return;
    }
    *value = avago_serdes_hal_get(aapl, addr, hal, member);
}
static void hal_update_int_value(
    Aapl_t *aapl,                /**< [in] Pointer to Aapl_t structure. */
    uint addr,                   /**< [in] SBus slice address. */
    BOOL enable_write,           /**< [in] TRUE to write values to SerDes, else read from SerDes. */
    Avago_serdes_hal_type_t hal, /**< [in] HAL register set selector */
    uint member,                 /**< [in] HAL register selector */
    int *value)                  /**< [in,out] Address of value to update */
{
    if( enable_write )
    {
        avago_serdes_hal_set(aapl, addr, hal, member, *value);
        return;
    }
    *value = (short)avago_serdes_hal_get(aapl, addr, hal, member);
}

static void serdes_dfe_update_ctle_0x26(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, BOOL enable_write)
{
    uint int_code = enable_write ? 0x26 : aapl_get_ip_type(aapl, addr) == AVAGO_P1 ? 0x2026 : 0x126;
    const uint column = (AAPL_SDREV_P1 == aapl_get_sdrev(aapl,addr)) ? 3 : 2;  /* CTLE */

    dfe_state->hf = avago_spico_int(aapl, addr, int_code, (column << 12) | (0 << 8) | (dfe_state->hf & 0xffff));
    dfe_state->lf = avago_spico_int(aapl, addr, int_code, (column << 12) | (1 << 8) | (dfe_state->lf & 0xffff));
    dfe_state->dc = avago_spico_int(aapl, addr, int_code, (column << 12) | (2 << 8) | (dfe_state->dc & 0xffff));
    dfe_state->bw = avago_spico_int(aapl, addr, int_code, (column << 12) | (3 << 8) | (dfe_state->bw & 0xffff));
}
static void serdes_dfe_update_ctle_hal(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, BOOL enable_write)
{
    uint fixed = 0;
    uint unfixed = 0;
    int sdrev = aapl_get_sdrev(aapl, addr);
    fixed = avago_serdes_hal_get(aapl, addr, AVAGO_HAL_GLOBAL_TUNE_PARAMS, 8);
    if( dfe_state->fixed_dc == 1 ) fixed |= 1; else if( dfe_state->fixed_dc == 0 ) unfixed |= 1;
    if( dfe_state->fixed_lf == 1 ) fixed |= 2; else if( dfe_state->fixed_lf == 0 ) unfixed |= 2;
    if( dfe_state->fixed_hf == 1 ) fixed |= 4; else if( dfe_state->fixed_hf == 0 ) unfixed |= 4;
    if( dfe_state->fixed_bw == 1 ) fixed |= 8; else if( dfe_state->fixed_bw == 0 ) unfixed |= 8;
    fixed &= ~unfixed;  /* Clear the explicitly unfixed bits. */
    hal_update_uint_value(aapl, addr, enable_write, AVAGO_HAL_GLOBAL_TUNE_PARAMS, 8, &fixed);
    dfe_state->fixed_dc = !!(fixed & 1);
    dfe_state->fixed_lf = !!(fixed & 2);
    dfe_state->fixed_hf = !!(fixed & 4);
    dfe_state->fixed_bw = !!(fixed & 8);

    /* Write these only if fixed is set, else read: */
    hal_update_uint_value(aapl, addr, enable_write && !!(fixed & 1), AVAGO_HAL_RXEQ_CTLE, 2, &dfe_state->dc);
    hal_update_uint_value(aapl, addr, enable_write && !!(fixed & 2), AVAGO_HAL_RXEQ_CTLE, 1, &dfe_state->lf);
    hal_update_uint_value(aapl, addr, enable_write && !!(fixed & 4), AVAGO_HAL_RXEQ_CTLE, 0, &dfe_state->hf);
    hal_update_uint_value(aapl, addr, enable_write && !!(fixed & 8), AVAGO_HAL_RXEQ_CTLE, 3, &dfe_state->bw);
    if( sdrev == AAPL_SDREV_CM4 || sdrev == AAPL_SDREV_CM4_16 )
    {
        hal_update_uint_value(aapl, addr, enable_write, AVAGO_HAL_RXEQ_CTLE, 4, &dfe_state->gainshape1);
        hal_update_uint_value(aapl, addr, enable_write, AVAGO_HAL_RXEQ_CTLE, 5, &dfe_state->gainshape2);
        hal_update_uint_value(aapl, addr, enable_write, AVAGO_HAL_RXEQ_CTLE, 6, &dfe_state->short_channel_en);
    }
    if( enable_write && (fixed != 0 || unfixed != 0) )
        avago_serdes_hal_func(aapl, addr, AVAGO_HAL_RXEQ_CTLE_APPLY);
}
/** @brief Update the ctle values of the provided DFE struct. */
static void serdes_dfe_update_ctle(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, int int_code)
{
    BOOL enable_write = int_code == 0x26;
    switch( aapl_get_sdrev(aapl, addr) )
    {
        case AAPL_SDREV_OM4    :
        case AAPL_SDREV_CM4    :
        case AAPL_SDREV_CM4_16 : serdes_dfe_update_ctle_hal(aapl, addr, dfe_state, enable_write);
                                 break;
        default                : serdes_dfe_update_ctle_0x26(aapl, addr, dfe_state, enable_write);
                                 break;
    }
}


static void serdes_dfe_update_gain_0x26(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, BOOL enable_write)
{
    int sdrev = aapl_get_sdrev(aapl,addr);

    /* DFE gain is not mentioned in the Int 0x26 table for P1 */
    if( sdrev != AAPL_SDREV_P1 )
    {
        uint int_code = enable_write ? 0x26 : 0x126;
        uint mask = 0x0F;
        uint int_data = dfe_state->dfeGAIN & mask;
        uint data = avago_spico_int(aapl,addr,int_code, 0x3000 | int_data);
        dfe_state->dfeGAIN = data & mask;
        dfe_state->dfeGAIN2 = 0;    /* Unused in D6, set for test consistency */
    }
}
static void serdes_dfe_update_gain_hal(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, BOOL enable_write)
{
    hal_update_uint_value(aapl, addr, enable_write, AVAGO_HAL_RXEQ_DFE, 0, &dfe_state->dfeGAIN);
    hal_update_uint_value(aapl, addr, enable_write, AVAGO_HAL_RXEQ_DFE, 1, &dfe_state->dfeGAIN2);
    if( enable_write )
        avago_serdes_hal_func(aapl, addr, AVAGO_HAL_RXEQ_DFE_APPLY);
}
static void serdes_dfe_update_gain(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, BOOL enable_write)
{
    switch( aapl_get_sdrev(aapl, addr) )
    {
    case AAPL_SDREV_OM4   :
    case AAPL_SDREV_CM4   :
    case AAPL_SDREV_CM4_16: serdes_dfe_update_gain_hal(aapl, addr, dfe_state, enable_write); break;
    case AAPL_SDREV_D6_07 : if( (aapl_get_firmware_rev(aapl, addr) & 0xfff) > 0x91
                                 || ((aapl_get_firmware_rev(aapl, addr) & 0xfff) == 0x91
                                     && avago_firmware_get_engineering_id(aapl, addr) >= 0x014) )
                            {
                                serdes_dfe_update_gain_hal(aapl, addr, dfe_state, enable_write);
                                break;
                            }
                            /* Else fall through */
    default               : serdes_dfe_update_gain_0x26(aapl, addr, dfe_state, enable_write); break;
    case AAPL_SDREV_P1    : break;
    }
}

/** @brief  Reads the DFE state from a SerDes device. */
/** @return void. */
/** @see    avago_serdes_get_dfe_state_ext(). */
void avago_serdes_get_dfe_state(
    Aapl_t *aapl,                        /**< [in] Pointer to Aapl_t structure. */
    uint addr,                           /**< [in] SBus slice address. */
    Avago_serdes_dfe_state_t *dfe_state) /**< [out] Where to write state. */
{
    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus %s\n", aapl_addr_to_str(addr));
    avago_serdes_dfe_state_ext(aapl, addr, dfe_state, AVAGO_DFE_MODE_ALL, FALSE);
}



static void serdes_dfe_update_levels_0x26(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, uint int_code, int test_only)
{
    const uint column = 4; /* VOS_LEVELS */
    int row;
    int row_init;
    int row_end;
    switch (test_only)
    {
    case 1 : row_init = 8; row_end = 15; break; /* TEST */
    case 2 : row_init = 0; row_end = 7;  break; /* DATA */
    default: row_init = 0; row_end = 15; break; /* TEST & DATA */
    }
    for( row = row_init; row <= row_end; row++ )  /* Always update testLEV */
    {
        int data = avago_spico_int(aapl, addr, int_code, (column << 12) | (row << 8));
        if( data & 0x8000 )
            data = -1 * ( ( (data & 0xFFFF) ^ 0xFFFF) + 1);
        if( row >= 8 )
            dfe_state->testLEV[row-8] = data;
        else
            dfe_state->dataLEV[row] = data;
    }
}
static void serdes_dfe_update_levels_hal(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state)
{
    (void)aapl;
    (void)addr;
    (void)dfe_state;
 /* for( int row = 0; row < 6; row++ ) */
 /*     dfe_state->dataLEV[row] = (short)avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXEQ_LEVELS, row); */
}
/*============================================================================= */
/* SERDES DFE UPDATE LEVELS */
/* Update the level values of the provided DFE struct */
/* */
static void serdes_dfe_update_levels(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, uint int_code, int test_only)
{
    if( int_code == 0x26 )  /* READ ONLY */
        return;

    switch( aapl_get_sdrev(aapl, addr) )
    {
        case AAPL_SDREV_OM4    :
        case AAPL_SDREV_CM4    :
        case AAPL_SDREV_CM4_16 : serdes_dfe_update_levels_hal(aapl, addr, dfe_state);
                                 break;
        default                : serdes_dfe_update_levels_0x26(aapl, addr, dfe_state, int_code, test_only);
                                 break;
    }
}

/*============================================================================= */
/* SERDES DFE UPDATE HEIGHTS */
/* Update the level values of the provided DFE struct */
/* */
static void serdes_dfe_update_heights(Aapl_t *aapl, uint sbus_addr, Avago_serdes_dfe_state_t *dfe_state, BOOL enable_write)
{
    if( !enable_write && aapl_get_ip_type(aapl,sbus_addr) == AVAGO_M4 ) /* READ ONLY */
    {
        int row;
        for( row = 0; row <= 5; row++ )
        {
            int data = avago_serdes_hal_get(aapl, sbus_addr, AVAGO_HAL_PAM4_EYE, row);
            dfe_state->eyeHeights[row] = data;
        }
    }
}

static void serdes_dfe_update_vos_0x26(Aapl_t *aapl, uint addr, int column, Avago_serdes_dfe_state_t *dfe_state, uint int_code)
{
    uint row;
    uint read_only_int_code = aapl_get_ip_type(aapl, addr) == AVAGO_P1 ? 0x2026 : 0x126;
    for( row=0; row < 8; row++ )
    {
        uint code = (row >= 6) ? read_only_int_code : int_code; /* 6&7 are read-only */
        uint int_data = (code == 0x26) ?  dfe_state->vos[row] : 0;
        int data = avago_spico_int(aapl, addr, code, (column << 12) | (row << 8) | int_data);
        dfe_state->vos[row] = data;
    }
    if( int_code != 0x26 )  /* If read-only */
    {
        for( row = 9; row <= 14; row++ )
        {
            int data = avago_spico_int(aapl, addr, int_code, (column << 12) | (row << 8));
            dfe_state->vosMID[row-9] = data;
        }
    }
}
static void serdes_dfe_update_vos_hal(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, BOOL enable_write, uint entries)
{
    uint row;

    for( row = 0; row < entries; row++ )
        hal_update_int_value(aapl, addr, enable_write, AVAGO_HAL_DATA_CHANNEL_INPUTS, row, &dfe_state->vos[row]);

    for( row = 0; row < 4; row++ )
        hal_update_int_value(aapl, addr, enable_write, AVAGO_HAL_TEST_CHANNEL_INPUTS, row, &dfe_state->vos[row+entries]);

    if( enable_write )
    {
        avago_serdes_hal_func(aapl, addr, AVAGO_HAL_DATA_CHANNEL_APPLY);
        avago_serdes_hal_func(aapl, addr, AVAGO_HAL_TEST_CHANNEL_APPLY);
    }
    else
    {
        /* Read the vosMID values: */
        for( row = 0; row < entries; row++ )
            hal_update_uint_value(aapl, addr, FALSE, AVAGO_HAL_DATA_CHANNEL_CAL, row, &dfe_state->vosMID[row]);
        for( row = 0; row < 4; row++ )
            hal_update_uint_value(aapl, addr, FALSE, AVAGO_HAL_TEST_CHANNEL_CAL, row, &dfe_state->vosMID[row+entries]);
    }
}
/** @brief Update the vos values of the provided DFE struct */
static void serdes_dfe_update_vos(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, uint int_code)
{
    switch( aapl_get_sdrev(aapl, addr) )
    {
        case AAPL_SDREV_D6_07  : serdes_dfe_update_vos_hal(aapl, addr, dfe_state, int_code == 0x26, 4);
                                 break;
        case AAPL_SDREV_OM4    :
        case AAPL_SDREV_CM4    :
        case AAPL_SDREV_CM4_16 : serdes_dfe_update_vos_hal(aapl, addr, dfe_state, int_code == 0x26, 6);
                                 break;
        case AAPL_SDREV_P1     : serdes_dfe_update_vos_0x26(aapl, addr, 4, dfe_state, int_code);
                                 break;
        default                : serdes_dfe_update_vos_0x26(aapl, addr, 1, dfe_state, int_code);
                                 break;
    }
}

/** @brief   Overrides the DFE tap1 value. */
/** @details Sets the values from which DFE tap1 is calculated.  Note that any */
/**          DFE tune operation will override the values set by this function. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_serdes_set_dfe_tap1(
    Aapl_t *aapl,    /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,  /**< [in] Device address number. */
    int tap1)        /**< [in] DFE tap1 value. */
{
    /* Tap 1 doesn't exist for M4 */
    if( aapl_get_ip_type(aapl,sbus_addr) != AVAGO_M4 )
    {
        int return_code = aapl->return_code;
        const int column = 1;
        int data[4];
        int row;
        for( row=9; row < 13; row++ )
            data[row-9] = avago_spico_int(aapl,sbus_addr, 0x126, (column << 12) | (row << 8));
        data[0] += tap1;
        data[1] += tap1;
        data[2] -= tap1;
        data[3] -= tap1;
        for( row = 0; row < 4; row++ )
            if( data[row] < 0 || data[row] > 255 )
                return aapl_fail(aapl, __func__, __LINE__, "DFE Tap1 value (%d) is out of range.\n",tap1);
        for( row = 0; row < 4; row++ )
            avago_spico_int(aapl,sbus_addr, 0x26, (column << 12) | (row << 8) | (data[row] & 0xff));
        return aapl->return_code == return_code ? 0 : -1;
    }
    return 0;
}

/* INT 0x26 DFE array */
/*                    0x0       0x01  0x2   0x3     0x4 */
/*            0x0 - thresh_HF    d0e   HF  GAIN  dvos_d0e_lo* */
/*            0x1 - thresh_LF    d0o   LF    2*  dvos_d0e_hi* */
/*            0x2 - thresh_AGC   d1e   DC    3*  dvos_d0o_lo* */
/*            0x3 - err_cnt_lo   d1o   BW    4*  dvos_d0o_hi* */
/*            0x4 - err_cnt_hi   t1e   LB    5*  dvos_d1e_lo* */
/*            0x5 - gainDFE_lo   t1o         6*  dvos_d1e_hi* */
/*            0x6 - gainDFE_hi   t0e         7*  dvos_d1o_lo* */
/*            0x7 - agc_gain_bnd t0o         8*  dvos_d1o_hi* */
/*            0x8 - agc_eq_bnd   alpha       9*  tvos_d0e_lo* */
/*            0x9 - thresh_lev               A** tvos_d0e_hi* */
/*            0xA - dfe_state                B** tvos_d0o_lo* */
/*            0xB - dfe_status               C** tvos_d0o_hi* */
/*            0xC - d6_vos_only              D** tvos_d1e_lo* */
/*            0xD - ctle_only                    tvos_d1e_hi* */
/*            0xE - enable_dlev                  tvos_d1o_lo* */
/*            0xF - run_coarse                   tvos_d1o_hi* */
/* */
static void serdes_update_tap1(Aapl_t *aapl, uint sbus_addr, Avago_serdes_dfe_state_t *dfe_state, uint vos_updated)
{
    if( aapl_get_ip_type(aapl, sbus_addr) == AVAGO_SERDES )
    {
        /* cast to int as we need signed arithmetic for tap1: */
        int *vos = (int*)dfe_state->vos;
        int *mid = (int*)dfe_state->vosMID;

        if( !vos_updated )
            serdes_dfe_update_vos(aapl, sbus_addr, dfe_state, 0x126);      /* Update the vos levels */
        dfe_state->dfeTAP1 =  + (vos[0] - mid[0])
                              + (vos[1] - mid[1])
                              - (vos[2] - mid[2])
                              - (vos[3] - mid[3]);
        dfe_state->dfeTAP1 /= 4;
        if( dfe_state->dfeTAP1 < -127 ) dfe_state->dfeTAP1 = -127;
        if( dfe_state->dfeTAP1 >  127 ) dfe_state->dfeTAP1 =  127;
    }
    else    /* AVAGO_P1 or AVAGO_M4 */
    {
        /* Tap 1 doesn't exist: clear it */
        dfe_state->dfeTAP1 = 0;
    }
}

/* Read or update dfe values: */
static void serdes_dfe_update_dfe_0x26(Aapl_t *aapl, uint sbus_addr, Avago_serdes_dfe_state_t *dfe_state, uint int_code, uint vos_updated)
{
    int sdrev = aapl_get_sdrev(aapl,sbus_addr);

    /* DFE gain and DFE taps are not mentioned in the Int 0x26 table for P1 */
    if( sdrev != AAPL_SDREV_P1 )
    {
        uint int_data = 0;
        uint row, row_start = 1;
        uint column = 3; /* DFE */

        /* Update Tap1 */
        serdes_update_tap1(aapl,sbus_addr,dfe_state,vos_updated);
        /* Do Tap 2-N */
        for( row=row_start; row <= AVAGO_DFE_TAP_COUNT; row++ )
        {
            int data;
            uint int_sign = 0;
            if( int_code == 0x026 )
            {
                int_data = dfe_state->dfeTAP[row-row_start];
                if( int_data > 128 )  /* Convert signed value to sign magnitude for write */
                {
                    int_sign = 1;
                    int_data = (int_data * -1) & 0x0000FFFF;
                }
            }
            data = avago_spico_int(aapl,sbus_addr, int_code, (column << 12) | (row << 8) | (int_sign << 15) | (int_data));
            if( data > 128 )  /* Convert 16b values to signed int values */
                data = ((data ^ 0xFFFF) + 1) * -1;
            dfe_state->dfeTAP[row-row_start] = data;
        }
    }
}
static void serdes_dfe_update_dfe_hal(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, BOOL enable_write)
{
    int tap;

    dfe_state->dfeTAP1 = 0; /* Doesn't exist on M4 */
    for( tap = 2; tap <= 13; tap++ )
    {
        hal_update_int_value(aapl, addr, enable_write, AVAGO_HAL_RXEQ_DFE, tap, &dfe_state->dfeTAP[tap-2]);
        dfe_state->dfeTAP_o[tap-2] = dfe_state->dfeTAP[tap-2];  /* Duplicate main array */
    }

    if( aapl_get_sdrev(aapl, addr) == AAPL_SDREV_D6_07 )
    {
        BOOL vos_updated = dfe_state->vos[0] | dfe_state->vos[1]; /* Not a perfect test, but good enough. */
        serdes_update_tap1(aapl,addr,dfe_state,vos_updated);
        for( tap = 2; tap <= 13; tap++ )
            hal_update_int_value(aapl, addr, enable_write, AVAGO_HAL_RXEQ_DFE, tap+14, &dfe_state->dfeTAP_o[tap-2]);
    }
    /* Note: Apply happens in serdes_dfe_update_gain() call */
}
/** @brief Update the dfe tap values of the provided DFE struct. */
static void serdes_dfe_update_dfe(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, uint int_code, uint vos_updated)
{
    BOOL enable_write = int_code == 0x26;
    switch( aapl_get_sdrev(aapl, addr) )
    {
    case AAPL_SDREV_OM4   :
    case AAPL_SDREV_CM4   :
    case AAPL_SDREV_CM4_16: serdes_dfe_update_dfe_hal(aapl, addr, dfe_state, enable_write);
                            break;
    case AAPL_SDREV_D6_07 : if( (aapl_get_firmware_rev(aapl, addr) & 0xfff) > 0x91
                                 || ((aapl_get_firmware_rev(aapl, addr) & 0xfff) == 0x91
                                     && avago_firmware_get_engineering_id(aapl, addr) >= 0x014) )
                            {
                                serdes_dfe_update_dfe_hal(aapl, addr, dfe_state, enable_write);
                                break;
                            }
                            /* Else fall through. */
    default               : serdes_dfe_update_dfe_0x26(aapl, addr, dfe_state, int_code, vos_updated);
                            break;
    }
    serdes_dfe_update_gain(aapl, addr, dfe_state, enable_write);
}

/*============================================================================= */
/* SERDES DFE UPDATE FFE */
/* Update the ffe values of the provided DFE struct */
/* */
static void serdes_dfe_update_ffe(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, uint int_code)
{
    int sdrev = aapl_get_sdrev(aapl, addr);
    if( sdrev == AAPL_SDREV_CM4 || sdrev == AAPL_SDREV_CM4_16 ) /* Only valid for CM4, not OM4 */
    {
        BOOL enable_write = int_code == 0x26;
        int row;
        for( row = 0; row <= 6; row++ )
            hal_update_int_value(aapl, addr, enable_write, AVAGO_HAL_RXEQ_FFE, row, &dfe_state->rxFFE[row]);

        if( enable_write )
            avago_serdes_hal_func(aapl, addr, AVAGO_HAL_RXEQ_FFE_APPLY);
    }
}
/*============================================================================= */
/* SERDES DFE UPDATE VERNIER DELAY */
/* Update the vernier delay values of the provided DFE struct */
/* */
static void serdes_dfe_update_vernier(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, BOOL enable_write)
{
    int sdrev;

    /* Read only params */
    if( enable_write )
        return;

    /* Only valid for CM4: */
    if( aapl_get_ip_type(aapl,addr) != AVAGO_M4 )
        return;

    /* Opal 2 and Fermi only at this point: */
    sdrev = aapl_get_sdrev(aapl, addr);
    if( sdrev == AAPL_SDREV_CM4_16 || sdrev == AAPL_SDREV_OM4 ) /* Fermi || Opal 2 */
    {
        /* Version 2 of the HAL API: */
        dfe_state->vernierDelay[ 0] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT,  5); /* upper odd delay */
        dfe_state->vernierDelay[ 1] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT,  6); /* upper even */
        dfe_state->vernierDelay[ 2] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT,  7); /* middle odd */
        dfe_state->vernierDelay[ 3] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT,  8); /* middle even */
        dfe_state->vernierDelay[ 4] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT,  9); /* lower odd */
        dfe_state->vernierDelay[ 5] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 10); /* lower even */
        dfe_state->vernierDelay[ 6] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 11); /* test odd */
        dfe_state->vernierDelay[ 7] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 12); /* test even */
        dfe_state->vernierDelay[ 8] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 13); /* edge odd */
        dfe_state->vernierDelay[ 9] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 14); /* edge even */
        dfe_state->vernierDelay[10] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 15); /* tap delay */
        return;
    }

    /* Version 1 of the HAL API: */
    dfe_state->vernierDelay[0] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 9); /* edge */
    dfe_state->vernierDelay[1] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 7); /* lower */
    dfe_state->vernierDelay[2] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 5); /* middle delay */
    dfe_state->vernierDelay[3] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 6); /* upper */
 /* dfe_state->vernierDelay[4] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 8); // test */
}

static void serdes_dfe_update_param_0x26(Aapl_t *aapl, uint sbus_addr, Avago_serdes_dfe_state_t *dfe_state, uint int_code)
{
    uint row, dwell_low = 0; /* dwell_low must persist outside the loop */
    int sdrev = aapl_get_sdrev(aapl,sbus_addr);

    for( row=0; row <= 15; row++ )
    {
        uint  *data_ptr = NULL;
        int read_only = 0;

        if (sdrev == AAPL_SDREV_P1)
        {
            switch (row)
            {
            case 0 : { break;}    /*hf_hint */
            case 1 : { break;}    /*lf_hint */
            case 2 : { break;}    /*dc_hint */
            case 3 : { break;}    /*bw_hint */
            case 5 : { data_ptr = &(dfe_state->error_threshold);
                       if( dfe_state->error_threshold >= 0xffff )   /* Don't set if default (illegal) value. */
                           read_only = 1;
                           break;}
            case 6 : { break;}    /*Oversample */
            case 8 : { break;}    /*d6_vos_only */
            case 10: { break;}    /*pcal_loop_cnt */
            case 12: { break;}    /*rr_active */
            case 13: { break;}    /*rr_run_mode */
            case 14:
            case 15: { data_ptr = &(dfe_state->dwell_bits); read_only = 1; break; }
            default: { data_ptr = NULL;}
            }
        }
        else
        {
            switch(row)
            {
            case 0 : { data_ptr = &(dfe_state->seedHF); break;}
            case 1 : { data_ptr = &(dfe_state->seedLF); break;}
            case 2 : { data_ptr = &(dfe_state->seedDC); break;}
            case 3 :
            case 4 : { data_ptr = &(dfe_state->dwell_bits); read_only = 1; break; }
            case 5 : { data_ptr = &(dfe_state->dfeGAIN_min); break;}
            case 6 : { data_ptr = &(dfe_state->dfeGAIN_max); break;}
            case 7 : { data_ptr = &(dfe_state->state)/*not used*/; read_only = 1; break;}
            case 9 : { data_ptr = &(dfe_state->error_threshold);
                       if( dfe_state->error_threshold >= 0xffff )   /* Don't set if default (illegal) value. */
                           read_only = 1;
                       break;}
            case 10: { data_ptr = &(dfe_state->state);  read_only = 1; break;}
            default: { data_ptr = NULL;}
            }
        }
        if (data_ptr != NULL)  /* only access members we have entries for */
        {
            uint  data = 0;
            int i;
            const uint column = 0; /* PARAM */

            uint code = int_code | (read_only <<8); /* Force to read if read_only parameter */
            if( int_code == 0x026 ) /* Modify request (ignores read_only flag!): */
            {
                data = *data_ptr;
                if ( (row == 3) && dfe_state->dwell_bits != 0 ) /* Special case for updating the dwell_bits */
                    avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_BIG_REG_32, 7, data); /* Big-Reg Select 7, dwell_time */
                /* Access to write DFE TAP disable added in firmware revision 0x1045 */
                if ( (row == 7) &&
                    (aapl_check_firmware_rev(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, 0x1045)) )
                {
                    data = 0;
                    for(i=1; i<AVAGO_DFE_TAP_COUNT+1; i++)
                        data |= (dfe_state->dfe_tap_disable[i] ? 1 : 0) << i;
                    avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_BIG_REG_16, 8, data);  /* Big-Reg Select 8, dfe_tap_disable */
                }
            }
            data = avago_spico_int(aapl,sbus_addr, code, (column << 12) | (row << 8) | (data & 0x00FF));
            /* Special case for dwell time, 32b value, so 2 reads to get all the data */
            if (row == 3) { data = data & 0xFFFF; dwell_low = data;}
            if (row == 4) { data = ((data & 0xFFFF) << 16) + dwell_low; }
            /* Access to read DFE TAP disable added in firmware revision 0x1043 */
            if ( (row == 7) && aapl_check_firmware_rev(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, 0x1043) )
            {
                for(i=1; i<AVAGO_DFE_TAP_COUNT+1; i++)
                    dfe_state->dfe_tap_disable[i] = ((data >> i) & 0x1) ? TRUE : FALSE;
            }
            else
                *data_ptr = data;  /* Update struct entry with the read value */
        }
    }
}
static void serdes_dfe_update_param_hal(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, BOOL enable_write)
{
    if( enable_write ) /* Write */
    {
        /* Don't update these with constructed values: */
        if( dfe_state->error_threshold < 0xffff )
            avago_serdes_hal_set(aapl, addr, AVAGO_HAL_GLOBAL_TUNE_PARAMS, 0, dfe_state->error_threshold);
        if( dfe_state->dwell_bits > 0 )
        {
            if( avago_serdes_get_rx_line_encoding(aapl, addr) ) /* If in PAM4 mode: */
                avago_serdes_hal_set(aapl, addr, AVAGO_HAL_GLOBAL_TUNE_PARAMS, 4, log10(dfe_state->dwell_bits));
            else
                avago_serdes_hal_set(aapl, addr, AVAGO_HAL_GLOBAL_TUNE_PARAMS, 1, log10(dfe_state->dwell_bits));
        }
    }

    dfe_state->error_threshold = avago_serdes_hal_get(aapl, addr, AVAGO_HAL_GLOBAL_TUNE_PARAMS, 0);
    if( avago_serdes_get_rx_line_encoding(aapl, addr) ) /* If in PAM4 mode: */
        dfe_state->dwell_bits = pow(10,avago_serdes_hal_get(aapl, addr, AVAGO_HAL_GLOBAL_TUNE_PARAMS, 4));  /* pam4_ctle_dwell_1ex */
    else
        dfe_state->dwell_bits = pow(10,avago_serdes_hal_get(aapl, addr, AVAGO_HAL_GLOBAL_TUNE_PARAMS, 1));  /* nrz_ctle_dwell_1ex */

    /* Read only for state: */
    /* Doesn't have HAL interface: */
    dfe_state->state  = avago_spico_int(aapl, addr, 0x126, 0x0a00);
}
static void serdes_dfe_update_param_p1(Aapl_t *aapl, uint addr, Avago_serdes_dfe_state_t *dfe_state, BOOL enable_write)
{
    uint p1_ro_int_code = 0x2026;  /*state and status are RO */
    (void)enable_write;

    dfe_state->state  = avago_spico_int(aapl,addr, p1_ro_int_code, (2 << 12) | (0 << 8));
}
/*============================================================================= */
/* SERDES DFE UPDATE PARAMs */
/* Update the param values of the provided DFE struct */
/*   Loop through all 16 parameters */
/*   If we define it, then assign a ptr to the struct entry, otherwise set to NULL */
/*     and do no more operations. */
/*   If it's the dwell time, then there's a special loading method, so check if */
/*     we're writing and use the special method once. */
/*   Some params are read-only so force CODE[8] true for those so no write occurs */
/*   When it's the dwell_time save the low 16b value and then assign the full */
/*     dwell_bits value after you read the high bits, including the value of the low */
/*   Use the pointer to write the struct with the read data.  On writes the interrupt */
/*     returns the value of the internal state, same as if you did a read. */
static void serdes_dfe_update_param(Aapl_t *aapl, uint sbus_addr, Avago_serdes_dfe_state_t *dfe_state, uint int_code)
{
    BOOL enable_write = int_code == 0x26;
    switch(aapl_get_sdrev(aapl, sbus_addr))
    {
    case AAPL_SDREV_OM4   :
    case AAPL_SDREV_CM4   :
    case AAPL_SDREV_CM4_16: serdes_dfe_update_param_hal(aapl, sbus_addr, dfe_state, enable_write);
                            break;
    case AAPL_SDREV_P1    : serdes_dfe_update_param_p1(aapl, sbus_addr, dfe_state, enable_write);
                            /* Fall through: */
    default               : serdes_dfe_update_param_0x26(aapl, sbus_addr, dfe_state, int_code);
                            break;
    }
    dfe_state->status = avago_serdes_get_dfe_status(aapl, sbus_addr);
}

/*============================================================================= */
/* SERDES DFE UPDATE */
/* Read the DFE state from the provided SerDes address */
/* */
/** */
/** @brief Gets the current state of the Rx Eq settings or Sets the Rx Eq to */
/**        the values provided. */
/** @param aapl      aapl struct */
/** @param sbus_addr Sbus Address of the SerDes */
/** @param dfe_mode  Enumerator that allows the user to only set/get a portion */
/**                  of the DFE struct. */
/** @param dfe_state Avago_serdes_dfe_state_t struct that will be updated with the */
/**                  current state of the RxEq.  If setting, the values of this */
/**                  struct are loaded into the SerDes. */
/** @param write     Enumerator that controls whether a Set or Get is done. */
/** @returns dfe_state struct updated to match the SerDes when write == GET, NOTE: if */
/**          dfe_mode is not equal to ALL, then only a sub-set of the struct is updated. */
/** @details Causes the SerDes at sbus_addr and the provided Avago_serdes_dfe_state_t struct */
/** to be set to same values.  If write == SET, then the dfe_state values are copied */
/** into the AVAGO_SERDES, otherwise (write == GET) the dfe_state struct is updated with the */
/** current values of the SerDes.  The dfe_mode input is used to control if you only */
/** want to change a portion of the struct.  Using dfe_mode is useful to minimize the */
/** number of transactions done. */
/** */
void avago_serdes_dfe_state_ext(
    Aapl_t *aapl,                        /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,                      /**< [in] SBus slice address. */
    Avago_serdes_dfe_state_t *dfe_state, /**< [in/out] State to update. */
    Avago_serdes_dfe_mode_t mode,        /**< [in] Portion of state to update. */
    BOOL do_write)                       /**< [in] TRUE to write to SerDes. */
                                         /**<      FALSE to read from SerDes. */
{
    uint int_code = do_write ? 0x026 : (AAPL_SDREV_P1 == aapl_get_sdrev(aapl,sbus_addr)) ? 0x2026 : 0x126; /* Set interrupt mode based on selection. */

    if (!aapl_check_process(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28)) return;

    if (!aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1)) return;

    /* Only update the sections of the struct requested. */
    switch(mode)      /* Update the selected data */
    {
    case AVAGO_DFE_MODE_CTLE   : serdes_dfe_update_ctle(aapl,sbus_addr,dfe_state,int_code);     break;
    case AVAGO_DFE_MODE_DFE    : serdes_dfe_update_dfe(aapl,sbus_addr,dfe_state,int_code,0);    break;
    case AVAGO_DFE_MODE_VOS    : serdes_dfe_update_vos(aapl,sbus_addr,dfe_state,int_code);      break;
    case AVAGO_DFE_MODE_FFE    : serdes_dfe_update_ffe(aapl,sbus_addr,dfe_state,int_code);      break;
    case AVAGO_DFE_MODE_PARAM  : serdes_dfe_update_param(aapl,sbus_addr,dfe_state,int_code);    break;
    case AVAGO_DFE_MODE_TESTLEV: serdes_dfe_update_levels(aapl,sbus_addr,dfe_state,int_code,1); break;
    case AVAGO_DFE_MODE_DATALEV: serdes_dfe_update_levels(aapl,sbus_addr,dfe_state,int_code,2); break;
    case AVAGO_DFE_MODE_VERNIER: serdes_dfe_update_vernier(aapl,sbus_addr,dfe_state,do_write);  break;
    case AVAGO_DFE_MODE_CTLE_DFE:
        serdes_dfe_update_ctle(aapl,sbus_addr,dfe_state,int_code);
        serdes_dfe_update_dfe(aapl,sbus_addr,dfe_state,int_code,0);
        break;
    case AVAGO_DFE_MODE_CTLE_DFE_VOS:
        serdes_dfe_update_ctle(aapl,sbus_addr,dfe_state,int_code);
        serdes_dfe_update_dfe(aapl,sbus_addr,dfe_state,int_code,0);
        serdes_dfe_update_vos(aapl,sbus_addr,dfe_state,int_code);
        break;
    case AVAGO_DFE_MODE_ALL:
        serdes_dfe_update_ctle(aapl,sbus_addr,dfe_state,int_code);
        serdes_dfe_update_vos(aapl,sbus_addr,dfe_state,int_code);
        serdes_dfe_update_param(aapl,sbus_addr,dfe_state,int_code);
        serdes_dfe_update_levels(aapl,sbus_addr,dfe_state,int_code,0);
        serdes_dfe_update_dfe(aapl,sbus_addr,dfe_state,int_code,1);
        serdes_dfe_update_ffe(aapl,sbus_addr,dfe_state,int_code);
        serdes_dfe_update_heights(aapl, sbus_addr, dfe_state, do_write);
        serdes_dfe_update_vernier(aapl, sbus_addr, dfe_state, do_write);
        break;
    }
}
/**@endcond */

/** @brief   Reads the specified portion of the DFE state from a SerDes device. */
/** @return void. */
void avago_serdes_get_dfe_state_ext(
    Aapl_t *aapl,                        /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,                      /**< [in] SBus slice address. */
    Avago_serdes_dfe_state_t *dfe_state, /**< [in] Where to save SerDes DFE state. */
    Avago_serdes_dfe_mode_t mode)        /**< [in] Portion of state to read. */
{
    avago_serdes_dfe_state_ext(aapl, sbus_addr, dfe_state, mode, FALSE);
}

/** @brief   Writes the specified portion of the DFE state to a SerDes device. */
/** @return void. */
void avago_serdes_set_dfe_state_ext(
    Aapl_t *aapl,                        /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,                      /**< [in] SBus slice address. */
    Avago_serdes_dfe_state_t *dfe_state, /**< [in] State to write to SerDes. */
    Avago_serdes_dfe_mode_t mode)        /**< [in] Portion of state to write. */
{
    avago_serdes_dfe_state_ext(aapl, sbus_addr, dfe_state, mode, TRUE);
}

/** @brief   Writes all the DFE state to a SerDes device. */
/** @details To write less that all the state, see */
/**          avago_serdes_set_dfe_state_ext(). */
/** @return void. */
void avago_serdes_set_dfe_state(
    Aapl_t *aapl,                        /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,                      /**< [in] SBus slice address. */
    Avago_serdes_dfe_state_t *dfe_state) /**< [in] State to write. */
{
    avago_serdes_dfe_state_ext(aapl, sbus_addr, dfe_state, AVAGO_DFE_MODE_ALL, TRUE);
}

static char *print_signed_hex(int value, int width)
{
    static char buf[30];
    char *ptr = buf+10;
    strcpy(buf,"          ");
    if( value < 0 )
    {
        if( value < -0xff && width == 3 )
            value = -0xff;
        sprintf(ptr, "-%x", -value);
    }
    else
        sprintf(ptr, "%x", value);
    width -= strlen(ptr);
    if( width < 0 ) width = 0;
    return ptr - width;
}

static int vernier_decode(int reg)
{
    /* bit 0 has weight 1 */
    /* bit 1 has weight 2 */
    /* bit 2 has weight 4 */
    /* bit 3 has weight 4 */
    /* bit 4 has weight 4 */
    /* bit 5 has weight 4 */
    return (reg&7) + ((reg>>1)&4) + ((reg>>2)&4) + ((reg>>3)&4);
}


/** @brief Formats a DFE state structure as a string. */
/** @return A malloc'd string.  Call aapl_free() to release its memory. */
char *avago_serdes_dfe_state_to_str(
    Aapl_t *aapl,                        /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,                      /**< [in] SBus slice address. */
    Avago_serdes_dfe_state_t *dfe_state,
    BOOL single_line,
    int pass,
    BOOL header)
{
    int sdrev = aapl_get_sdrev(aapl, sbus_addr);
    char *buf = 0;
    char *buf_end = 0;
    int size = 0;
    BOOL is_cm4 = sdrev == AAPL_SDREV_CM4 || sdrev == AAPL_SDREV_CM4_16;
    BOOL is_m4  = is_cm4 || sdrev == AAPL_SDREV_OM4;
    BOOL is_p1  = sdrev == AAPL_SDREV_P1;
    BOOL is_d6_07 = sdrev == AAPL_SDREV_D6_07;
    (void)pass;

    if (single_line) {
        int i;
        aapl_buf_add(aapl, &buf, &buf_end, &size,"DC: %d ",dfe_state->dc);
        aapl_buf_add(aapl, &buf, &buf_end, &size,"LF: %d ",dfe_state->lf);
        aapl_buf_add(aapl, &buf, &buf_end, &size,"HF: %d ",dfe_state->hf);
        aapl_buf_add(aapl, &buf, &buf_end, &size,"BW: %d ",dfe_state->bw);
        for(i=0; i<8; i++)
            aapl_buf_add(aapl, &buf, &buf_end, &size,"VOS%d: %d ",i,dfe_state->vos[i]);
        if (!is_p1) {
          aapl_buf_add(aapl, &buf, &buf_end, &size,"DFEGAIN: %d ",dfe_state->dfeGAIN);
          if (is_m4 || is_d6_07)
              aapl_buf_add(aapl, &buf, &buf_end, &size,"DFEGAIN2: %d ",dfe_state->dfeGAIN2);
          else
          {
#if AAPL_ENABLE_FLOAT_USAGE
              aapl_buf_add(aapl, &buf, &buf_end, &size,"DFE1: %.1f ",dfe_state->dfeTAP1);
#else
              aapl_buf_add(aapl, &buf, &buf_end, &size,"DFE1: %d ",dfe_state->dfeTAP1);
#endif
          }
          for(i=0; i<AVAGO_DFE_TAP_COUNT; i++)
              aapl_buf_add(aapl, &buf, &buf_end, &size,"DFE%d: %d ",i+2,dfe_state->dfeTAP[i]);
          for(i=0; i<AVAGO_DFE_TAP_COUNT && is_d6_07; i++)
              aapl_buf_add(aapl, &buf, &buf_end, &size,"DFE_o%d: %d ",i+2,dfe_state->dfeTAP_o[i]);
        }
        for(i=0; i<4; i++) {
            aapl_buf_add(aapl, &buf, &buf_end, &size,"DVOS%d_LO: %d ",i,dfe_state->dataLEV[i*2]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"DVOS%d_HI: %d ",i,dfe_state->dataLEV[i*2+1]);
        }
        for(i=0; i<4; i++) {
            aapl_buf_add(aapl, &buf, &buf_end, &size,"TVOS%d_LO: %d ",i,dfe_state->testLEV[i*2]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"TVOS%d_HI: %d ",i,dfe_state->testLEV[i*2+1]);
        }
        if (is_m4)
        {
            aapl_buf_add(aapl, &buf, &buf_end, &size,"dhe_l: %d ",dfe_state->eyeHeights[0]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"dhe_m: %d ",dfe_state->eyeHeights[1]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"dhe_u: %d ",dfe_state->eyeHeights[2]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"dho_l: %d ",dfe_state->eyeHeights[3]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"dho_m: %d ",dfe_state->eyeHeights[4]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"dho_u: %d ",dfe_state->eyeHeights[5]);
        }
        else
        {
            aapl_buf_add(aapl, &buf, &buf_end, &size,"dh0e: %d ",dfe_state->dataLEV[1]-dfe_state->dataLEV[0]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"dh0o: %d ",dfe_state->dataLEV[3]-dfe_state->dataLEV[2]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"dh1e: %d ",dfe_state->dataLEV[5]-dfe_state->dataLEV[4]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"dh1o: %d ",dfe_state->dataLEV[7]-dfe_state->dataLEV[6]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"th0e: %d ",dfe_state->testLEV[1]-dfe_state->testLEV[0]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"th0o: %d ",dfe_state->testLEV[3]-dfe_state->testLEV[2]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"th1e: %d ",dfe_state->testLEV[5]-dfe_state->testLEV[4]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"th1o: %d ",dfe_state->testLEV[7]-dfe_state->testLEV[6]);
        }
        if (is_m4)
        {
            aapl_buf_add(aapl, &buf, &buf_end, &size,"dly_edge: %d ",dfe_state->vernierDelay[0]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"dly_data_l: %d ",dfe_state->vernierDelay[1]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"dly_data_m: %d ",dfe_state->vernierDelay[2]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"dly_data_u: %d ",dfe_state->vernierDelay[3]);
        }
        for(i=0; i<6; i++)
            aapl_buf_add(aapl, &buf, &buf_end, &size,"VOSMID%d: %d ",i,dfe_state->vosMID[i]);
        if (is_cm4) /* Not OM4 */
        {
            aapl_buf_add(aapl, &buf, &buf_end, &size,"PRE1: %d ",dfe_state->rxFFE[1]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"PRE2: %d ",dfe_state->rxFFE[0]);
            aapl_buf_add(aapl, &buf, &buf_end, &size,"POST1: %d ",dfe_state->rxFFE[2]);
        }
#if AAPL_ENABLE_FLOAT_USAGE
        if( !is_m4 )
            aapl_buf_add(aapl, &buf, &buf_end, &size,"BER: %8.2e ",(float) dfe_state->error_threshold/(dfe_state->dwell_bits*avago_serdes_get_rx_register_clock(aapl,sbus_addr)));
#endif
        if (aapl->debug && ( (sbus_addr & 0xFF) != 0) ) {
            /* Print debug info */
            uint read_only_int_code = aapl_get_ip_type(aapl, sbus_addr) == AVAGO_P1 ? 0x2026 : 0x126;
            for(i=0; i<16; i++) {
                aapl_buf_add(aapl, &buf, &buf_end, &size,"param_%d: %d ", i,avago_spico_int(aapl,sbus_addr, read_only_int_code, (0x0 << 12) | (i << 8)));
                aapl_buf_add(aapl, &buf, &buf_end, &size,"param2_%d: %d ",i,avago_spico_int(aapl,sbus_addr, read_only_int_code, (0x5 << 12) | (i << 8)));
                aapl_buf_add(aapl, &buf, &buf_end, &size,"dbg_%d: %d ",   i,avago_spico_int(aapl,sbus_addr, read_only_int_code, (0x6 << 12) | (i << 8)));
            }
        }
    } else {
        int i;
        if (header)
        {
            /* First Header Line: */
            aapl_buf_add(aapl, &buf, &buf_end, &size, "              CTLE         |       RxFFE         |                  VOS                  |            VERNIER             |            ");
            aapl_buf_add(aapl, &buf, &buf_end, &size, is_d6_07 ? "          DFE                                                                                  "
                                                               : "          DFE                      ");
            aapl_buf_add(aapl, &buf, &buf_end, &size, "|           Eye Height          | 1 /    |State/\n");

            /* Second Header Line: */
            aapl_buf_add(aapl, &buf, &buf_end, &size, "  Addr|DC LF HF BW G1 G2 SC|  1  2  3  4  5  6  7|         DATA          | TEST  |  CDR  |UO UE MO ME LO LE TO TE EO EE TP|G1 G2     1 ");
            aapl_buf_add(aapl, &buf, &buf_end, &size, is_d6_07 ? "   2       3       4       5       6       7       8       9       A       B       C       D   "
                                                               : " 2  3  4  5  6  7  8  9  A  B  C  D");
            aapl_buf_add(aapl, &buf, &buf_end, &size, "|                               | dwell  |Status");
            if( aapl->debug )
                aapl_buf_add(aapl, &buf, &buf_end, &size, "     |%-80s|%-80s","Parameters","Debug");
            aapl_buf_add(aapl, &buf, &buf_end, &size, "\n");

            /* Third Header Line: */
            aapl_buf_add(aapl, &buf, &buf_end, &size, "------+--------------------+---------------------+-----------------------+-------+-------+--------------------------------+------------");
            aapl_buf_add(aapl, &buf, &buf_end, &size, is_d6_07 ? "-----------------------------------------------------------------------------------------------"
                                                               : "-----------------------------------");
            aapl_buf_add(aapl, &buf, &buf_end, &size, "+-------------------------------+--------+------\n");
        }

        if (!sbus_addr) return buf;
        aapl_buf_add(aapl, &buf, &buf_end, &size, "%6s|%02x %02x %02x %02x ", aapl_addr_to_str(sbus_addr), dfe_state->dc&0xff,dfe_state->lf,dfe_state->hf,dfe_state->bw);
        if (is_cm4) /* Not OM4 */
        {
            aapl_buf_add(aapl, &buf, &buf_end, &size, "%02x ", dfe_state->gainshape1);
            aapl_buf_add(aapl, &buf, &buf_end, &size, "%02x ", dfe_state->gainshape2);
            aapl_buf_add(aapl, &buf, &buf_end, &size, "%02x|", dfe_state->short_channel_en);
            aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(dfe_state->rxFFE[0],3));
            aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(dfe_state->rxFFE[1],3));
            aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(dfe_state->rxFFE[2],3));
            aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(dfe_state->rxFFE[3],3));
            aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(dfe_state->rxFFE[4],3));
            aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(dfe_state->rxFFE[5],3));
            aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(dfe_state->rxFFE[6],3));
            aapl_buf_add(aapl, &buf, &buf_end, &size, "|");
        } else {
          aapl_buf_add(aapl, &buf, &buf_end, &size, "%2s %2s %2s|%3s%3s%3s%3s%3s%3s%3s|","","","","","","","","","","");
        }


        if( is_m4 )
        {
            for( i=0; i<10; i++ )
            {
                if( aapl->verbose >= 2 )
                {
                    if(i==0) aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0xef) & 0x1ff,3)); /* VD_LOSE */
                    if(i==1) aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0x95) & 0x1ff,3)); /* VD_LOSO */
                    if(i==2) aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0xf7) & 0x1ff,3)); /* VD_MOSE */
                    if(i==3) aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0x96) & 0x1ff,3)); /* VD_MOSO */
                    if(i==4) aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0x9a) & 0x1ff,3)); /* VD_UOSE */
                    if(i==5) aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0x99) & 0x1ff,3)); /* VD_UOSO */
                    if(i==6) aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0xee) & 0x1ff,3)); /* VT0OSE */
                    if(i==7) aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0x97) & 0x1ff,3)); /* VT0OSO */
                    if(i==8) aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0xf9) & 0x1ff,3)); /* VT1OSE */
                    if(i==9) aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0x98) & 0x1ff,3)); /* VT1OSO */
                }
                else aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(dfe_state->vos[i],3));

                if( i == 5 || i == 7 || i == 9 ) aapl_buf_add(aapl, &buf, &buf_end, &size, "|");
                else                             aapl_buf_add(aapl, &buf, &buf_end, &size, " ");
            }
        }
        else
        {
            for( i=0; i<8; i++ )
            {
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%3x",dfe_state->vos[i]&0xfff);
                if(      i == 3 )           aapl_buf_add(aapl, &buf, &buf_end, &size, " %3s %3s|","","");
                else if( i == 5 || i == 7 ) aapl_buf_add(aapl, &buf, &buf_end, &size, "|");
                else                        aapl_buf_add(aapl, &buf, &buf_end, &size, " ");
            }
        }

        if (is_m4)
        {
            if( aapl->verbose >= 2 )
            {
                /* Show decoded register values: */
                int val;
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%02x ", vernier_decode((val = avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0xaa))>>8));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%02x ", vernier_decode(val));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%02x ", vernier_decode((val = avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0xb7))>>8));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%02x ", vernier_decode(val));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%02x ", vernier_decode((val = avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0x91))>>8));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%02x ", vernier_decode(val));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%02x ", vernier_decode((val = avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0xac))>>8));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%02x ", vernier_decode(val));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%02x ", vernier_decode((val = avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0xab))>>8));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%02x ", vernier_decode(val));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%02x|", vernier_decode(      avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0xb3)));
            }
            else
            {
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%s ", print_signed_hex(dfe_state->vernierDelay[0],2));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%s ", print_signed_hex(dfe_state->vernierDelay[1],2));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%s ", print_signed_hex(dfe_state->vernierDelay[2],2));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%s ", print_signed_hex(dfe_state->vernierDelay[3],2));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%s ", print_signed_hex(dfe_state->vernierDelay[4],2));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%s ", print_signed_hex(dfe_state->vernierDelay[5],2));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%s ", print_signed_hex(dfe_state->vernierDelay[6],2));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%s ", print_signed_hex(dfe_state->vernierDelay[7],2));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%s ", print_signed_hex(dfe_state->vernierDelay[8],2));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%s ", print_signed_hex(dfe_state->vernierDelay[9],2));
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%s|", print_signed_hex(dfe_state->vernierDelay[10],2));
            }
        }
        else
            aapl_buf_add(aapl, &buf, &buf_end, &size, "%32s|", "");

        if (is_p1) /* No DFE in P1 */
            aapl_buf_add(aapl, &buf, &buf_end, &size, "%47s", "");
        else {
          if (is_m4 || is_d6_07)
            aapl_buf_add(aapl, &buf, &buf_end, &size, "%2x %2x",dfe_state->dfeGAIN,dfe_state->dfeGAIN2);
          else
            aapl_buf_add(aapl, &buf, &buf_end, &size, "%2x %2s",dfe_state->dfeGAIN,"");

          if (is_m4)
              aapl_buf_add(aapl, &buf, &buf_end, &size, " %5s",""); /* No predictive tap1 */
          else
#if AAPL_ENABLE_FLOAT_USAGE
              aapl_buf_add(aapl, &buf, &buf_end, &size, " %5.1f",dfe_state->dfeTAP1);
#else
              aapl_buf_add(aapl, &buf, &buf_end, &size, " %5d",dfe_state->dfeTAP1);
#endif
          for(i=0; i<AVAGO_DFE_TAP_COUNT; i++)
          {
              if (is_m4 && (i >= (AVAGO_DFE_TAP_COUNT - 2)))
                  aapl_buf_add(aapl, &buf, &buf_end, &size, " %2s","");
              else if( is_d6_07 )
              {
                  aapl_buf_add(aapl, &buf, &buf_end, &size, " %s", print_signed_hex(dfe_state->dfeTAP[i],3));
                  aapl_buf_add(aapl, &buf, &buf_end, &size, ",%-3s", print_signed_hex(dfe_state->dfeTAP_o[i],2));
              }
              else
                  aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", print_signed_hex(dfe_state->dfeTAP[i],3));
          }
        }
        aapl_buf_add(aapl, &buf, &buf_end, &size, "|");
        if (is_m4)
        {
            for(i=0; i<6; i++)
                aapl_buf_add(aapl, &buf, &buf_end, &size, " %4x",(dfe_state->eyeHeights[i]) & 0xfff);
            aapl_buf_add(aapl, &buf, &buf_end, &size, " ");

        }
        else
        {
            for(i=0; i<8; i+=2)
            {
                if( i != 0 ) aapl_buf_add(aapl, &buf, &buf_end, &size, " ");
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%3x",(dfe_state->dataLEV[i+1]-dfe_state->dataLEV[i]) & 0xfff);
            }
            aapl_buf_add(aapl, &buf, &buf_end, &size, "|");
            for(i=0; i<8; i+=2)
            {
                if( i != 0 ) aapl_buf_add(aapl, &buf, &buf_end, &size, " ");
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%3x",(dfe_state->testLEV[i+1]-dfe_state->testLEV[i]) & 0xfff);
            }
        }
#if AAPL_ENABLE_FLOAT_USAGE
        if( is_m4 )
            aapl_buf_add(aapl, &buf, &buf_end, &size, "|%8.0e",1.0 / (dfe_state->dwell_bits));
        else
            aapl_buf_add(aapl, &buf, &buf_end, &size, "|%8.2e",(float) dfe_state->error_threshold/(dfe_state->dwell_bits*avago_serdes_get_rx_register_clock(aapl,sbus_addr)));
#endif

        aapl_buf_add(aapl, &buf, &buf_end, &size, "|%02x %02x", dfe_state->state, dfe_state->status);

        if (aapl->debug && ( (sbus_addr & 0xFF) != 0) ) {
            /* Print debug info */
            uint read_only_int_code = aapl_get_ip_type(aapl, sbus_addr) == AVAGO_P1 ? 0x2026 : 0x126;
            aapl_buf_add(aapl, &buf, &buf_end, &size, "|");
            for(i=0; i<16; i++)
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%04x ",avago_spico_int(aapl,sbus_addr, read_only_int_code, (0x0 << 12) | (i << 8)));
            aapl_buf_add(aapl, &buf, &buf_end, &size, "|");
            for(i=0; i<16; i++)
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%04x ", avago_spico_int(aapl,sbus_addr, read_only_int_code, (0x5 << 12) | (i << 8)));
        }
        aapl_buf_add(aapl, &buf, &buf_end, &size, "\n");
    }
    return buf;
}

/** @brief Prints a sub-set of information from a Avago_serdes_dfe_state_t struct in a standard format. */
/** @return void */
void avago_serdes_print_dfe(
    Aapl_t *aapl,                        /**< [in] Pointer to Aapl_t structure. */
    uint addr,                           /**< [in] SBus slice address. */
    Avago_serdes_dfe_state_t *dfe_state, /**< [in] Structure to print information from. */
    BOOL single_line,                    /**< [in] When true print as a PARAM: Value list rather then 2 lines */
                                         /**<      of header and values.  This mode also prints data out in */
                                         /**<      decimal values rather then hex. */
    int pass)
{
    char *buf = avago_serdes_dfe_state_to_str(aapl, addr, dfe_state, single_line, pass, TRUE);
    if( buf )
    {
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%s\n", buf);
        aapl_free(aapl, buf, __func__);
    }
}


/*============================================================================= */
/* SERDES DFE STATE CONSTRUCTOR */
/* */
/** @brief Creates a Avago_serdes_dfe_state_t struct */
/** @return Avago_serdes_dfe_state_t struct */
/** @details mallocs the memory for a Avago_serdes_dfe_state_t and returns a pointer */
/** to that memory location.  The following non-zero values are set for */
/** the returned struct.  tune_mode=AVAGO_DFE_ICAL, DC=0x38, LF=0x0C, BW=0x0F, */
/** dfeGAIN_max=8. */
/** The illegal values dwell_bits=0 and error_threshold=0xffff are used to */
/** indicate to not write this value until changed by the caller. */
Avago_serdes_dfe_state_t *avago_serdes_dfe_state_construct(
    Aapl_t *aapl)   /**< [in] Pointer to Aapl_t structure. */
{
    int i;
    Avago_serdes_dfe_state_t * dfe_state;
    size_t bytes = sizeof(Avago_serdes_dfe_state_t);

    if (! (dfe_state = (Avago_serdes_dfe_state_t *) aapl_malloc(aapl, bytes, __func__)))
        return(NULL);
    memset(dfe_state, 0, sizeof(*dfe_state));         /* set all bytes to zero */

    /* Set default values for dfe tune control settings */
    dfe_state->fixed_dc =
    dfe_state->fixed_lf =
    dfe_state->fixed_hf =
    dfe_state->fixed_bw = -1;
    dfe_state->dfe_disable = 0;
    dfe_state->tune_mode=AVAGO_DFE_ICAL;

    /* Set default value for DC,LF,HF,BW in case someone does a create, launched fixed while only */
    /* setting the fixed settings he wants, we do a full CTLE update so let's make sure we load */
    /* something that is reasonable.  These defaults should match the firmware values */
    dfe_state->dc = 0x38; /* 56 */
    dfe_state->lf = 0x0C; /* 12 */
    dfe_state->hf = 0x00; /*  0 */
    dfe_state->bw = 0x0F; /* 15 */

    /* Set illegal values for these parameters. */
    /* Used to prevent writing unless changed by the caller. */
    dfe_state->dwell_bits      = 0;
    dfe_state->error_threshold = 0xffff;

    dfe_state->dfeGAIN_min = 0;
    dfe_state->dfeGAIN_max = 15;

    for (i = 0; i < AVAGO_DFE_TAP_COUNT+1; i++)
        dfe_state->dfe_tap_disable[i] = FALSE;

    return(dfe_state);
}
/*============================================================================= */
/* SERDES DFE STATE DESTRUCTOR */
/* */
/** @brief Destroys the provided Avago_serdes_dfe_state_t struct. */
/** @param aapl      aapl struct */
/** @param dfe_state struct to have it's memory usage freed */
/** @return void */
/** @details Frees the memory pointed to by the provided Avago_serdes_dfe_state_t struct. */
/** */
void avago_serdes_dfe_state_destruct(
    Aapl_t *aapl,                        /**< [in] Pointer to Aapl_t structure. */
    Avago_serdes_dfe_state_t *dfe_state) /**< [in] Struct to destruct/free. */
{
    aapl_free(aapl, dfe_state, __func__);
}

/** @brief   Launches and halts DFE tuning procedures in parallel on all SerDes in list. */
/** @details - Validates that the all addresses in list are of same type SerDes. */
/**          - Loads any fixed CTLE settings from mode_control into all SerDes in list. */
/**          - Loads the params settings from mode_control into all SerDes in list. */
/**          - Launches DFE tuning in parallel on all SerDes in list and then returns. */
/**          - DFE tuning continues to run in the background until it completes. */
/**          - Use avago_parallel_serdes_get_dfe_status() to query tuning status. */
/** @return  void */
/** @see     avago_parallel_serdes_get_dfe_status(). */
void avago_parallel_serdes_dfe_tune(
    Aapl_t *aapl,                              /**< [in] Pointer to Aapl_t structure. */
    Avago_addr_t *addr_list,                   /**< [in,out] List of addresses and results. */
    Avago_serdes_dfe_state_t *mode_control)    /**< [in] Setting to use for tuning. */
                                               /**< tune_mode member must be set. */
{
    uint int_data = 0;
    Avago_addr_t *addr_struct;
    uint first_addr = avago_struct_to_addr(addr_list);
    int sdrev = aapl_get_sdrev(aapl, first_addr);
    BOOL m4_serdes = sdrev == AAPL_SDREV_CM4 || sdrev == AAPL_SDREV_CM4_16;

    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, tune_mode %s\n",aapl_addr_to_str(first_addr), aapl_dfe_tune_mode_to_str(mode_control->tune_mode));

    /* Do config checking: */
    if( !avago_parallel_verify_addr_list(aapl, addr_list) )
        return;

    /* Configure data for interrupt based on what fixed tunings are requested */
    if( mode_control->dfe_disable   ) int_data |= 0x0040;
    if( mode_control->fixed_dc == 1 ) int_data |= 0x0080;
    if( mode_control->fixed_lf == 1 ) int_data |= 0x0100;
    if( mode_control->fixed_hf == 1 ) int_data |= 0x0200;
    if( mode_control->fixed_bw == 1 ) int_data |= 0x0400;
    if( mode_control->seeded_dc     ) int_data |= 0x0800;

    /* Check if BW tuning is supported and enable/disabled */
    if( !m4_serdes )
    {
        if( mode_control->bw_tune_en )
            avago_parallel_serdes_int(aapl, addr_list, 0x26, 0x5301);
        else
            avago_parallel_serdes_int(aapl, addr_list, 0x26, 0x5300);
    }
    else
        int_data &= ~0x3fc0; /* Clear seeded and fixed bits on M4 */

    /* Load any fixed CTLE settings: */
    if( mode_control->fixed_dc==1 || mode_control->fixed_lf==1 || mode_control->fixed_hf==1 || mode_control->fixed_bw==1 )
    {
        for( addr_struct = addr_list; addr_struct; addr_struct = addr_struct->next )
        {
            uint addr = avago_struct_to_addr(addr_struct);
            serdes_dfe_update_ctle(aapl,addr,mode_control,0x26);
        }
    }

    /* Configure the param values present in the struct */
    if( AAPL_SDREV_P1 != sdrev )
    {
        for( addr_struct = addr_list; addr_struct; addr_struct = addr_struct->next )
        {
            uint addr = avago_struct_to_addr(addr_struct);
            serdes_dfe_update_param(aapl,addr,mode_control,0x26);
        }
    }
    if( sdrev != AAPL_SDREV_CM4 && sdrev != AAPL_SDREV_P1 )
    {
        for( addr_struct = addr_list; addr_struct; addr_struct = addr_struct->next )
        {
            uint addr = avago_struct_to_addr(addr_struct);

            /* Add in the appropriate tuning to the interrupt data */
            int int_data2  = avago_spico_int(aapl, first_addr, 0x126, 0x5b00); /* Get current state of tune flags */
            int_data2 |= 0x5b00;
            if( mode_control->tune_mode == AVAGO_DFE_ICAL ) int_data2 &= 0xFFFe;
            else if( mode_control->tune_mode == AVAGO_DFE_ICAL_ONLY ) int_data2 |= 0x0001;

            avago_spico_int(aapl, addr, 0x26, int_data2); /* Disable/Enable auto-pCal */
        }
    }

    switch(mode_control->tune_mode)
    {
    case AVAGO_DFE_ICAL           : { int_data |= 0x0001; break; } /* Enable auto-pCal */
    case AVAGO_DFE_PCAL           : { int_data |= 0x0002; break; }
    case AVAGO_DFE_ICAL_ONLY      : { int_data |= 0x0001; break; } /* Disable auto-pCal */
    case AVAGO_DFE_ENABLE_RR      : { int_data |= 0x000A; break; }
    case AVAGO_DFE_START_ADAPTIVE : { int_data |= 0x0006; break; }
    case AVAGO_DFE_STOP_ADAPTIVE  : { int_data  = 0x0002; break; }
    case AVAGO_DFE_DISABLE_RR     : { int_data  = 0x0008; break; }
    }

    /* Launch tuning */
    avago_parallel_serdes_int_check(aapl, __func__, __LINE__, addr_list, 0x0a, int_data);
}


/** @brief  Launches and halts DFE tuning procedures */
/** @details Validates that the SBus address is a supported SerDes. */
/**          Loads any fixed CTLE settings from mode_control into the SerDes. */
/*           Loads the params settings from mode_control into the SerDes. */
/*           Launches DFE tuning on the SerDes and returns. */
/*           DFE tuning continues to run in the background until it completes. */
/** @return void */
/** @see avago_serdes_dfe_pause(), avago_serdes_tune(). */
void avago_serdes_dfe_tune(
    Aapl_t *aapl,                           /**< [in] Pointer to Aapl_t structure. */
    uint addr,                              /**< [in] SBus slice address. */
    Avago_serdes_dfe_state_t *mode_control) /**< [in] Setting to use for tuning. */
                                            /**< tune_mode member must be set. */
{
    uint int_data = 0, int_data2 = 0;
    int sdrev = aapl_get_sdrev(aapl, addr);
    BOOL m4_serdes = sdrev == AAPL_SDREV_CM4 || sdrev == AAPL_SDREV_CM4_16;

    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, tune_mode %s\n",aapl_addr_to_str(addr), aapl_dfe_tune_mode_to_str(mode_control->tune_mode));

    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) ) return;
    if( !aapl_check_process(aapl, addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28) ) return;

  /* API for Int 0x0a changed in firmware revision 0x1046 to add seeded tuning */
    if( aapl_check_firmware_rev(aapl, addr, __func__, __LINE__, FALSE, 1, 0x1046) )
    {
        /* Configure data for interrupt based on what fixed tunings are requested */
        if( mode_control->dfe_disable ) int_data |= 0x0040;
        if( mode_control->fixed_dc==1 ) int_data |= 0x0080;
        if( mode_control->fixed_lf==1 ) int_data |= 0x0100;
        if( mode_control->fixed_hf==1 ) int_data |= 0x0200;
        if( mode_control->seeded_dc )   int_data |= 0x0800;

        /* API for Int 0x0a changed in firmware revision 0x104D to add fixed_bw and drop seeded_lf and seeded_hf tuning. */
        if( aapl_check_firmware_rev(aapl, addr, __func__, __LINE__, FALSE, 1, 0x104D) )
        {
            if( mode_control->fixed_bw==1 ) int_data |= 0x0400;
        }
        else
        {
            if( mode_control->seeded_lf ) int_data |= 0x1000;
            if( mode_control->seeded_hf ) int_data |= 0x2000;
        }
    }
    else /* Really old firmware: */
    {
        if( (mode_control->tune_mode == AVAGO_DFE_ENABLE_RR) || (mode_control->tune_mode == AVAGO_DFE_DISABLE_RR) )
        {
            aapl_fail(aapl, __func__, __LINE__, "Round-Robin pCal not supported by currently loaded firmware revision 0x%04X.\n",aapl_get_firmware_rev(aapl,addr));
            return;
        }
        if( mode_control->seeded_dc || mode_control->seeded_lf || mode_control->seeded_hf )
            aapl_log_printf (aapl,AVAGO_WARNING, __func__, __LINE__, "firmware revision 0x%04X doesn't support seeded DFE tuning.  Ignoring seeded_tuning request.\n",aapl_get_firmware_rev(aapl,addr));
        /* Configure data for interrupt based on what fixed tunings are requested */
        if( mode_control->dfe_disable ) int_data |= 0x0040;
        if( mode_control->fixed_dc )    int_data |= 0x0010;
        if( mode_control->fixed_lf )    int_data |= 0x0100;
        if( mode_control->fixed_hf )    int_data |= 0x0200;
     }

    /* Check if BW tuning is supported and enable/disabled */
    if( ! m4_serdes )
    {
        if (aapl_check_firmware_rev(aapl, addr, __func__, __LINE__, FALSE, 1, 0x1048))
        {
            if (mode_control->bw_tune_en)
                avago_spico_int(aapl, addr, 0x26, 0x5301);
            else
                avago_spico_int(aapl, addr, 0x26, 0x5300);
        }
    }
    else
        int_data &= ~0x3fc0; /* Clear seeded and fixed bits on M4 */

    /* Load any fixed CTLE settings: */
    if( mode_control->fixed_dc==1 || mode_control->fixed_lf==1 || mode_control->fixed_hf==1 || mode_control->fixed_bw==1 )
        serdes_dfe_update_ctle(aapl,addr,mode_control,0x26);

    /* Configure the param values present in the struct */
    if( AAPL_SDREV_P1 != sdrev )
        serdes_dfe_update_param(aapl,addr,mode_control,0x26);

    /* Add in the appropriate tuning to the interrupt data */
    if( sdrev != AAPL_SDREV_CM4 && sdrev != AAPL_SDREV_P1 ) {
      int_data2  = avago_spico_int(aapl, addr, 0x126, 0x5b00); /* Get current state of tune flags */
      int_data2 |= 0x5b00;
    }
    switch(mode_control->tune_mode) {
      case AVAGO_DFE_ICAL           : { int_data |= 0x0001; int_data2 &= 0xFFFe; break; } /* Enable auto-pCal */
      case AVAGO_DFE_PCAL           : { int_data |= 0x0002; break; }
      case AVAGO_DFE_ICAL_ONLY      : { int_data |= 0x0001; int_data2 |= 0x0001; break; } /* Disable auto-pCal */
      case AVAGO_DFE_ENABLE_RR      : { int_data |= 0x000A; break; }
      case AVAGO_DFE_START_ADAPTIVE : { int_data |= 0x0006; break; }
      case AVAGO_DFE_STOP_ADAPTIVE  : { int_data = 0x0002; break; }
      case AVAGO_DFE_DISABLE_RR     : { int_data = 0x0008; break; }
    }
    if( sdrev != AAPL_SDREV_CM4 && sdrev != AAPL_SDREV_P1 )
      avago_spico_int(aapl, addr, 0x26, int_data2); /* Disable/Enable auto-pCal */
/*printf("avago_serdes_dfe_tune: fixed_dc=%x,dc=%x\n",mode_control->fixed_dc,mode_control->dc); */
    avago_spico_int_check(aapl, __func__, __LINE__, addr, 0x0a, int_data); /* Launch Tuning */
}

/** @brief   Tune selected SerDes in parallel. */
/** @details Starts a dfe tune on each specified SerDes. */
/**          If #dfe is NULL, performs a default iCal tune. */
/**          Once all tunes are started, */
/**          if #dfe selects an iCal or single pCal tune, then */
/**          wait #start_delay ms before */
/**          checking whether they have finished. */
/**          If not all finished, wait #loop_delay ms before checking again. */
/**          Returns after all tunes are complete, or the #timeout is reached. */
/** */
/**          If #dfe selects a continuous adaptive pCal operation, function */
/**          returns immediately after tuning is started. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_serdes_dfe_batch_tune(
    Aapl_t *aapl,                   /**< [in] Pointer to Aapl_t structure. */
    Avago_serdes_dfe_state_t *dfe,  /**< [in] DFE tuning settings to use. */
    int addr_cnt,                   /**< [in] The number of elements following. */
    uint *addrs,                    /**< [in] Array of SerDes addresses to tune. */
    int start_delay,                /**< [in] ms to wait before checking DFE status. */
    int loop_delay,                 /**< [in] ms to wait between polling checks. */
    int timeout)                    /**< [in] ms to wait for all to finish. */
{
    int wait_time = 0;
    char *tuning = (char *)aapl_malloc(aapl, addr_cnt, __func__);
    int todo_count = addr_cnt;
    int i;
    Avago_serdes_dfe_state_t *dfe_state = 0;

    if( dfe == 0 )
        dfe = dfe_state = avago_serdes_dfe_state_construct(aapl);

    /* Perform the dfe tune step on each Rx in list: */
    for( i = 0; i < addr_cnt; i++ )
    {
        avago_serdes_dfe_tune(aapl, addrs[i], dfe);
        tuning[i] = 1;
    }

    ms_sleep(start_delay);                      /* Wait for tune to complete */

    /* While any slices are iCal or pCal tuning and timeout not reached */
    while( dfe->tune_mode == AVAGO_DFE_ICAL || dfe->tune_mode == AVAGO_DFE_PCAL )
    {
        for( i = 0; i < addr_cnt; i++ )             /* Check each slice in turn */
        {
            if( tuning[i] && !avago_serdes_dfe_running(aapl, addrs[i]) )
            {
                tuning[i] = 0;      /* Clear status if the tune is complete */
                todo_count--;
            }
        }

        if( wait_time >= timeout || todo_count == 0 )
            break;

        ms_sleep(loop_delay);                       /* Wait a bit before checking again */
        wait_time += loop_delay;
    }

    if( dfe_state )
        avago_serdes_dfe_state_destruct(aapl,dfe_state);

    if( todo_count > 0 && aapl->debug > 0 )
    {
        for( i = 0; i < addr_cnt; i++ )
            if( tuning[i] )
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__,__LINE__,"SBus 0x%02x, Tuning failed on slice.\n",addrs[i]);
    }

    aapl_free(aapl, tuning, __func__);

    if( todo_count == 0 )
        return 0;   /* Success */

    return aapl_fail(aapl, __func__,__LINE__, "Tuning failed to complete for %d of %d slices.\n",todo_count, addr_cnt);
}

/** @brief   Monitors the status of tuning for all serdes which are part of parallel tuning. */
/** @details Updates data structure for respective serdes with the current status, */
/**          Starts tuning when queue is empty up to parallel limit defined, */
/**          Checks for EI detect everytime before initiating tuning, */
/**          Reports failure in case of EI detection or tuning failure. */
/** @return  Returns 1, when tuning completed for all serdes. */
/** @return  Returns -1, when tuning failed for any of the serdes. */
/** @return  Returns 0, when tuning is running/blocked for any of the serdes. */
/** @see     avago_serdes_dfe_batch_tune_launch(). */
int avago_serdes_dfe_batch_tune_poll(
    Aapl_t *aapl,
    Avago_serdes_dfe_state_t *dfe,                    /**< [in] DFE tuning settings to use. */
    Avago_serdes_batch_tune_work_t *tuning_status)    /**< [in] Updated data structure */
{
    int i = 0;
    int rc = 0;
    BOOL tx_en = FALSE, rx_en = FALSE;
    for( i = 0; i < tuning_status->total_serdes_count; i++ )
    {
        const char *addr_str = aapl_addr_to_str(tuning_status->serdes_status[i].addr);
        /* Update structure for only those serdes that are part of parallel tuning or blocked after tuning initiated */
        if( tuning_status->serdes_status[i].active.tuning_initiated || tuning_status->serdes_status[i].tuning_blocked )
        {
            /* if tuning is in progress */
            if( avago_serdes_dfe_running(aapl, tuning_status->serdes_status[i].addr) )
            {
                /* Decrement timeout count. */
                tuning_status->serdes_status[i].active.timeout_count --;
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Timeout count for %s: %d.\n", addr_str, tuning_status->serdes_status[i].active.timeout_count);

                /* Consider serdes as fail if timeout_count reaches to zero and tuning is not yet completed */
                if(tuning_status->serdes_status[i].active.timeout_count == 0)
                {
                    tuning_status->serdes_status[i].tuning_failed = TRUE;
                    tuning_status->serdes_status[i].active.tuning_initiated = FALSE;
                    tuning_status->failed_tuning_count++;
                    tuning_status->active_tuning_count--;
                    avago_spico_int_check(aapl, __func__, __LINE__, tuning_status->serdes_status[i].addr, 0x0a, 0xE);
                    aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Tuning failed due to timeout in tuning completion on serdes %s.\n", addr_str);
                }

                /* If tuning of blocked serdes is stared by firmware when signal detected */
                if( tuning_status->serdes_status[i].tuning_blocked )
                {
                    tuning_status->serdes_status[i].tuning_blocked = FALSE;
                    tuning_status->serdes_status[i].active.tuning_initiated = TRUE;
                    tuning_status->active_tuning_count++;
                    tuning_status->blocked_tuning_count--;
                    aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Tuning resumed on blocked serdes %s\n", addr_str);
                }
            }
            /* If tuning is successful remove it from the current active tuning list. */
            else if( !avago_serdes_dfe_los(aapl, tuning_status->serdes_status[i].addr) )
            {
                tuning_status->serdes_status[i].active.tuning_initiated = FALSE;
                tuning_status->serdes_status[i].tuning_completed        = TRUE;
                tuning_status->active_tuning_count--;
                tuning_status->completed_tuning_count++;

                /* If tuning of blocked serdes is completed by firmware when signal detected */
                if( tuning_status->serdes_status[i].tuning_blocked )
                {
                    tuning_status->serdes_status[i].tuning_blocked = FALSE;
                    tuning_status->blocked_tuning_count--;
                    aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Tuning completed on blocked serdes %s\n", addr_str);
                }
                else
                    aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Tuning completed on serdes %s\n", addr_str);
            }

            /* Loss of signal detected. */
            /* Halt tuning and resume when signal is available */
            else
            {
                if( !tuning_status->serdes_status[i].tuning_blocked )
                {
                    aapl_log_printf(aapl,AVAGO_INFO, __func__, __LINE__,"Tuning blocked on serdes %s because of signal loss\n", addr_str);

                    /* Block tuning */
                    tuning_status->serdes_status[i].tuning_blocked = TRUE;
                    tuning_status->serdes_status[i].active.tuning_initiated = FALSE;
                    tuning_status->active_tuning_count--;
                    tuning_status->blocked_tuning_count++;
                }

                /* Decrement count on loss of signal */
                if( tuning_status->serdes_status[i].los_count )
                {
                    tuning_status->serdes_status[i].los_count--;
                    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Loss of signal count for %s: %d.\n", addr_str, tuning_status->serdes_status[i].los_count);
                }
                else
                {
                    /* consider it as fail when EI detected since long time which is tracked by los_count */
                    tuning_status->serdes_status[i].tuning_blocked = FALSE;
                    tuning_status->serdes_status[i].active.tuning_initiated = FALSE;
                    tuning_status->failed_tuning_count++;
                    tuning_status->blocked_tuning_count--;
                    tuning_status->serdes_status[i].tuning_failed = TRUE;
                    aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Tuning failed due to timeout in detecting signal on serdes %s.\n", addr_str);
                }
            }
        }
    }

    i = 0;
    /* Loop to launch tuning when queue is empty if any of the serdes tuning is completed from the list of parallel tuning */
    while( (i < tuning_status->total_serdes_count) && (tuning_status->active_tuning_count < tuning_status->maximum_serdes_tune_limit) )
    {
        if(   !(tuning_status->serdes_status[i].tuning_completed       )
                && !(tuning_status->serdes_status[i].tuning_failed          )
                && !(tuning_status->serdes_status[i].active.tuning_initiated) )
        {
            /* Check minimum signal or Rx state before starting tuning */
            avago_serdes_get_tx_rx_ready(aapl, tuning_status->serdes_status[i].addr, &tx_en, &rx_en);
            tuning_status->serdes_status[i].rx_enable = rx_en;
            tuning_status->serdes_status[i].ei_detect = avago_serdes_get_electrical_idle(aapl, tuning_status->serdes_status[i].addr);

            if( tuning_status->serdes_status[i].rx_enable && !tuning_status->serdes_status[i].ei_detect )
            {
                /* Perform tuning */
                avago_serdes_dfe_tune(aapl, tuning_status->serdes_status[i].addr, dfe);
                tuning_status->active_tuning_count ++;
                tuning_status->serdes_status[i].active.tuning_initiated = TRUE;
                aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Tuning initiated on serdes 0x%0x\n", tuning_status->serdes_status[i].addr);
            }
            else
            {
                aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__,"Tuning fail to initiate on serdes %s. EI_detect: %d, rx_enable: %d\n",
                                                    aapl_addr_to_str(tuning_status->serdes_status[i].addr), tuning_status->serdes_status[i].ei_detect,
                                                    tuning_status->serdes_status[i].rx_enable);

                /* Decrement when loss of signal detected */
                if( tuning_status->serdes_status[i].los_count )
                    tuning_status->serdes_status[i].los_count--;
                else
                {
                    /* Consider it as fail when EI detected since long time which is tracked by los_count */
                    tuning_status->failed_tuning_count ++;
                    tuning_status->serdes_status[i].tuning_failed = TRUE;
                    aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Tuning failed on serdes %s\n", aapl_addr_to_str(tuning_status->serdes_status[i].addr));
                }
            }
        }
        i++;
    }
    /* Return final status of tuning */
    if( (tuning_status->completed_tuning_count + tuning_status->blocked_tuning_count + tuning_status->failed_tuning_count) == tuning_status->total_serdes_count )
    {
        if( tuning_status->failed_tuning_count )
            rc = -1;
        else if( tuning_status->blocked_tuning_count )
            rc = 0;
        else
            rc = 1;
    }
    return rc;
}

/** @brief   Launches tuning in parallel on fixed number of serdes. */
/** @details Creates and Initialize Data Structure, */
/**          Starts tuning for limited number of serdes, */
/**          Updates data structure for serdes whose tuning is started, */
/**          Sends message when tuning fail to start on respective serdes. */
/** @return  On success returns 0. */
/** @return  On failure returns -1. */
/** @see     avago_serdes_dfe_batch_tune_poll(). */
int avago_serdes_dfe_batch_tune_launch(
    Aapl_t *aapl,                                   /**< [in] Pointer to Aapl_t structure. */
    Avago_serdes_dfe_state_t *dfe,                  /**< [in] DFE tuning settings to use. */
    int addr_cnt,                                   /**< [in] The number of elements following. */
    uint *addrs,                                    /**< [in] Array of SerDes addresses to tune. */
    int limit,                                      /**< [in] How many serdes can tune in parallel. */
    int timeout_count,                              /**< [in] Counter to detect timeout. */
    Avago_serdes_batch_tune_work_t *tuning_status)  /**< [in] Data structure to initialize. */
{
    int i = 0;
    BOOL rx_en = FALSE, tx_en = FALSE;
    int return_code = aapl->return_code;
    /* Initialize data structure for all serdes */
    for( i=0; i<addr_cnt; i++ )
    {
        tuning_status->serdes_status[i].addr                    = addrs[i];
        tuning_status->serdes_status[i].rx_enable               = FALSE;
        tuning_status->serdes_status[i].ei_detect               = TRUE;
        tuning_status->serdes_status[i].active.tuning_initiated = FALSE;
        tuning_status->serdes_status[i].active.timeout_count    = timeout_count;
        tuning_status->serdes_status[i].tuning_completed        = FALSE;
        tuning_status->serdes_status[i].tuning_blocked          = FALSE;
        tuning_status->serdes_status[i].tuning_failed           = FALSE;
        tuning_status->serdes_status[i].los_count               = timeout_count;
    }
    tuning_status->total_serdes_count        = addr_cnt;
    tuning_status->active_tuning_count       = 0;
    tuning_status->completed_tuning_count    = 0;
    tuning_status->blocked_tuning_count      = 0;
    tuning_status->failed_tuning_count       = 0;
    tuning_status->maximum_serdes_tune_limit = limit;  /*maximum no of serdes that will be a part of parallel tuning */

    i = 0;
    /* Loop to launch tuning in parallel on fix no. of serdes. */
    while( (i < tuning_status->total_serdes_count) && (tuning_status->active_tuning_count < tuning_status->maximum_serdes_tune_limit) )
    {
        /* Check minimum signal or Rx state before starting tuning */
        avago_serdes_get_tx_rx_ready(aapl, tuning_status->serdes_status[i].addr, &tx_en, &rx_en);
        tuning_status->serdes_status[i].rx_enable = rx_en;
        tuning_status->serdes_status[i].ei_detect = avago_serdes_get_electrical_idle(aapl, tuning_status->serdes_status[i].addr);

        if( tuning_status->serdes_status[i].rx_enable && !tuning_status->serdes_status[i].ei_detect )
        {
            /* Perform tuning */
            avago_serdes_dfe_tune(aapl, tuning_status->serdes_status[i].addr, dfe);
            tuning_status->active_tuning_count ++;
            tuning_status->serdes_status[i].active.tuning_initiated = TRUE;
            aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Tuning initiated on serdes %s\n", aapl_addr_to_str(tuning_status->serdes_status[i].addr));
        }
        else
        {
            aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__,"Tuning fail to initiate on serdes %s. EI_detect: %d, rx_enable: %d\n",
                                                    aapl_addr_to_str(tuning_status->serdes_status[i].addr), tuning_status->serdes_status[i].ei_detect,
                                                    tuning_status->serdes_status[i].rx_enable);
            tuning_status->serdes_status[i].los_count--;
        }
        i++;
    }
    return (return_code == aapl->return_code) ? 0 : -1;
}

void avago_serdes_set_dfeTAP(Avago_serdes_dfe_state_t *ptr, int val, int bit) {
    ptr->dfeTAP[bit]=val;
}
void avago_serdes_set_vosVAL(Avago_serdes_dfe_state_t *ptr, int val, int bit) {
    ptr->vos[bit]=val;
}

static int find_mid_vos(Aapl_t *aapl, uint addr, uint reg, int start)
{
    int vos;
    int prev_ones = 0;
    for( vos = 0x68; vos < 0x9a; vos++ )
    {
        int i;
        int ones = 0;
        long data[4];
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, reg, vos);  /* DFE_VD0OSE */
        avago_serdes_get_rx_data(aapl, addr, data);
        for( i = start; i < 80; i+= 2 )
            if( data[i/20] & (1<<(i%20)) ) ones++;
/*      printf("%x %02x: %05x_%05x_%05x_%05x   ones = %d, start = %d\n", reg-0x95, vos, data[3], data[2], data[1], data[0], ones, start); */
        if( prev_ones > 20 && ones <= 20 )
        {
            if( prev_ones - 20 < 20 - ones )
                vos--;
            break;
        }
        if( prev_ones < 20 && ones >= 20 && prev_ones != 0 )
        {
            if( 20 - prev_ones < ones - 20 )
                vos--;
            break;
        }
        prev_ones = ones;
    }
    return vos;
}

/** @brief Calibrates the VOS values for DATA, TEST and EDGE samplers. */
/** @details Provided for use with the PON SerDes on the Franklin test chip. */
void avago_serdes_pon_vos_cal(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] SBus slice address. */
{
    int sdrev = aapl_get_sdrev(aapl, addr);
    if( sdrev == AAPL_SDREV_PON )
    {
        int i;
        int vos[8];

        int old_a0 = avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, 0xa0);  /* GAINTAP */
        int old_9f = avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, 0x9f);  /* GAINLB */
        int old_b8 = avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, 0xb8);  /* DFE_PD_CTL1 */
        int old_b9 = avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, 0xb9);  /* DFE_PD_CTL2 */
        int old_92 = avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, 0x92);  /* DFE_MISC_CTL1 */
        int old_2a = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x2a);  /* RX PRBS CONTROL */

        /* Configure for capture: */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0xa0, 0x0000);  /* GAINTAP = 0 */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0x9f, 0x0000);  /* GAINLB = 0 */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0xb8, 0x7575);  /* DFE_PD_CTL1 */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0xb9, 0x5555);  /* DFE_PD_CTL2 */

        /* Setup for data capture: */
        avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, 0x2a, 0x0000, 0x3000); /* RX_SEED_SEL = rx_data */

        /* Capture data, prev0 even */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0x99, 0x00ff);  /* DFE_VD0OSO */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0x96, 0x00ff);  /* DFE_VD1OSE */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0x9a, 0x00ff);  /* DFE_VD1OSO */
        vos[0] = find_mid_vos(aapl, addr, 0x95, 1);                 /* DFE_VD0OSE */

        /* Capture data, prev0 odd */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0x95, 0x00ff);  /* DFE_VD0OSE */
        vos[4] = find_mid_vos(aapl, addr, 0x99, 0);                 /* DFE_VD0OSO */

        /* Capture data, prev1 even */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0x95, 0x0000);  /* DFE_VD0OSE */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0x99, 0x0000);  /* DFE_VD0OSO */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0x9a, 0x0000);  /* DFE_VD1OSO */
        vos[1] = find_mid_vos(aapl, addr, 0x96, 1);                 /* DFE_VD1OSE */

        /* Capture data, prev1 odd */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0x96, 0x0000);  /* DFE_VD1OSE */
        vos[5] = find_mid_vos(aapl, addr, 0x9a, 0);                 /* DFE_VD1OSO */


        /* Setup for test capture: */
        avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, 0x2a, 0x1000, 0x3000);  /* RX_SEED_SEL = offset_data */

        /* Capture test, even */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0x9c, 0x00ff);  /* DFE_VT1OSO */
        vos[3] = find_mid_vos(aapl, addr, 0x98, 1);                 /* DFE_VT1OSE */

        /* Capture test, odd */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0x98, 0x00ff);  /* DFE_VT1OSE */
        vos[7] = find_mid_vos(aapl, addr, 0x9c, 0);                 /* DFE_VT1OSO */


        /* Setup for edge capture: */
        avago_serdes_mem_rmw(aapl, addr, AVAGO_ESB, 0x92, 0x0008, 0x000c);  /* Select Rx test capture */

        /* Capture edge, odd */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0x9b, 0x00ff);  /* DFE_VT0OSO */
        vos[2] = find_mid_vos(aapl, addr, 0x97, 1);                 /* DFE_VT1OSE */
        /* Capture edge, odd */
        avago_serdes_mem_wr( aapl, addr, AVAGO_ESB, 0x97, 0x00ff);  /* DFE_VT0OSE */
        vos[6] = find_mid_vos(aapl, addr, 0x9b, 0);                 /* DFE_VT1OSO */


        /* Restore original values: */
        avago_serdes_mem_wr(aapl, addr, AVAGO_LSB, 0x2a, old_2a);  /* Restore Rx capture */
        avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, 0x92, old_92);  /* DFE_MISC_CTL1 */
        avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, 0xa0, old_a0);  /* GAINTAP */
        avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, 0x9f, old_9f);  /* GAINLB */
        avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, 0xb8, old_b8);  /* DFE_PD_CTL1 */
        avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, 0xb9, old_b9);  /* DFE_PD_CTL2 */

        for( i = 0; i < 8; i++ )
        {
            avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, 0x95+i, vos[i]);
     /*     printf("vos[%i] = 0x%2x\n", i, vos[i]); */
        }

        /* Write DFE state to 0x1 */
        avago_spico_int(aapl, addr, 0x26, 0x0a01);
        /* Write DFE status to 0x80 */
        avago_spico_int(aapl, addr, 0x26, 0x0b80);
    }
}


