/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* AAPL (ASIC and ASSP Programming Layer) support for gathering eye diagram */
/* data from a SerDes slice (28nm only). */

/** @file */
/** @brief  Functions for eye capture. */
/** @defgroup Eye Eye Capture Functions */
/** @{ */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#define MEAN_EYE_FORCE_READ
 /*#define MEAN_EYE_FORCE_GATHER */
 /*#define MEAN_EYE_FORCE_WRITE */

#if AAPL_ENABLE_EYE_MEASUREMENT

#define ADJUST_CM4_PHASE_CENTER 1

#define SBM_INT             0x2F
#define EYE_READ_CAP        0x0000
#define EYE_READ_ADDR       0x0001
#define EYE_READ_START      0x0002
#define EYE_READ_POINTS     0x0003
#define EYE_READ_STEP       0x0004
#define EYE_READ_RESOLUTION 0x0006
#define EYE_READ_OPTIONS    0x0007
#define EYE_READ_CENTER     0x0008
#define EYE_READ_ROW_COL    0x000d
#define EYE_READ_PHASE      0x0026
#define EYE_SET_ADDR        0x1000
#define EYE_SET_START       0x2000
#define EYE_SET_POINTS      0x3000
#define EYE_SET_STEP        0x4000
#define EYE_SET_RESOLUTION  0x6000
#define EYE_SET_OPTIONS     0x7000
#define EYE_SET_THRESH      0x9000
#define EYE_GATHER_ROW      0xa000
#define EYE_GATHER_COLUMN   0xb000
#define EYE_GATHER_MISSION  0xc000

#define EQS(str1,str2) (0==strcmp(str1,str2))
#define AAPL_LOG_PRINT4 if((esp->aapl->debug & 0xf) >= AVAGO_DEBUG4) aapl_log_printf
#define AAPL_LOG_PRINT3 if((esp->aapl->debug & 0xf) >= AVAGO_DEBUG3) aapl_log_printf
#define AAPL_LOG_PRINT2 if((esp->aapl->debug & 0xf) >= AVAGO_DEBUG2) aapl_log_printf
#define AVAGO_EYE_SBM_DWELL_MAX_BITS (bigint)1e8

#define DEF_TRANS_DENSITY           (0.50000F)
#define DEF_DC_BALANCE              (0.50000F)

#define DEF_TRANS_DENSITY_M4        (0.09375F)    /* Lower/upper eyes */
#define DEF_TRANS_DENSITY_M4_MSB    (DEF_TRANS_DENSITY_M4 * 4.0F / 3.0F) /* Middle eye */
#define DEF_DC_BALANCE_M4           (0.06250F)

static Aapl_conv_table_t eye_type_table[] =
{
    { "EYE_SIZE",       AVAGO_EYE_SIZE },
    { "EYE_CROSS",      AVAGO_EYE_SIZE },
    { "EYE_HEIGHT",     AVAGO_EYE_HEIGHT },
    { "EYE_WIDTH",      AVAGO_EYE_WIDTH },
    { "EYE_FULL",       AVAGO_EYE_FULL },
    { "EYE_VDUAL",      AVAGO_EYE_SIZE_VDUAL },
    { "EYE_DVOS",       AVAGO_EYE_HEIGHT_DVOS },
    { 0,                0 }
};
/** @brief  Converts Avago_serdes_eye_type_t value into a display string. */
/** @return Returns the display string. */
const char *aapl_eye_type_to_str(Avago_serdes_eye_type_t value)
{
    Aapl_conv_table_t *table = eye_type_table;
    int index = value_to_index(table,value);
    return index >= 0 ? table[index].name : "unknown";
}
/** @brief  Converts name string to an Avago_serdes_eye_type_t variable. */
/** @return Returns TRUE on success, FALSE on error. */
BOOL aapl_str_to_eye_type(const char *name, Avago_serdes_eye_type_t *out)
{
    Aapl_conv_table_t *table = eye_type_table;
    int index = name_to_index(table,name,4);
    if( index >= 0 )
        *out = (Avago_serdes_eye_type_t)table[index].value;
    return index >= 0;
}

/** @cond INTERNAL */

/* GET MEMORY for results arrays: */
/* */
/* Note:  Order of operations here matters.  See comments about caller data */
/* sniffing of Avago_serdes_eye_data_t in serdes.h. */
/* */
int allocate_eye_arrays(Aapl_t *aapl, Avago_serdes_eye_data_t *datap)
{
    size_t bigint_bytes = datap->ed_x_points * datap->ed_y_points * sizeof(bigint);
    size_t float_bytes  = datap->ed_x_points * datap->ed_y_points * sizeof(float);

    bigint * errorsp = datap->ed_errorsp;
    float  * gradp   = datap->ed_gradp;
    float  * qvalp   = datap->ed_qvalp;
    bigint * bitsp   = datap->ed_bitsp;

    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Size: %u x %u\n", datap->ed_x_points, datap->ed_y_points);

    errorsp = (bigint *) aapl_realloc(aapl, errorsp, bigint_bytes, "Avago_serdes_eye_data_t.ed_errorsp array");
    gradp   = (float  *) aapl_realloc(aapl, gradp,    float_bytes, "Avago_serdes_eye_data_t.ed_gradp array");
    qvalp   = (float  *) aapl_realloc(aapl, qvalp,    float_bytes, "Avago_serdes_eye_data_t.ed_qvalp array");
    bitsp   = (bigint *) aapl_realloc(aapl, bitsp,   bigint_bytes, "Avago_serdes_eye_data_t.ed_bitsp array");
    if( !bitsp || !qvalp || !gradp || !errorsp )
    {
        if( bitsp   ) aapl_free(aapl, bitsp,   "bits");
        if( qvalp   ) aapl_free(aapl, qvalp,   "qvalp");
        if( gradp   ) aapl_free(aapl, gradp,   "gradp");
        if( errorsp ) aapl_free(aapl, errorsp, "errorsp");
        bitsp = errorsp = 0;
        gradp = qvalp = 0;
        return -1;
    }

    /* Initialize the data, even if reusing: */
    memset((void *) errorsp, 0, bigint_bytes);
    memset((void *) gradp,   0,  float_bytes);
    memset((void *) qvalp,   0,  float_bytes);
    memset((void *) bitsp,   0, bigint_bytes);

    memset((void *) datap->ed_mission_errors,  0, sizeof(datap->ed_mission_errors ));
    memset((void *) datap->ed_mission_bits,    0, sizeof(datap->ed_mission_bits   ));

    datap->ed_errorsp  = errorsp;
    datap->ed_gradp    = gradp;
    datap->ed_qvalp    = qvalp;
    datap->ed_bitsp    = bitsp; /* Set this last, trigger for arrays valid. */

    return 0;
}
/** @endcond */

/** @brief   Allocates and initializes an Avago_serdes_eye_config_t struct. */
/** @details Provides default values for capturing an eye. */
/** @return  Pointer to resulting struct. */
/** @return  On error, decrements aapl->return_code and returns NULL. */
Avago_serdes_eye_config_t *avago_serdes_eye_config_construct(Aapl_t *aapl)
{
    size_t bytes = sizeof(Avago_serdes_eye_config_t);
    Avago_serdes_eye_config_t *configp = (Avago_serdes_eye_config_t *) aapl_malloc(aapl, bytes, __func__);

    if( 0 == configp)
        return NULL;

/* Note:  Keep these defaults consistent with comments in serdes.h: */
    memset(configp, 0, sizeof(*configp));

    configp->ec_eye_type         = AVAGO_EYE_FULL;
    configp->ec_cmp_mode         = AVAGO_SERDES_RX_CMP_MODE_XOR;
    configp->ec_max_dwell_bits   = AVAGO_EYE_DEF_MAX_DWELL_BITS;
    configp->ec_min_dwell_bits   = AVAGO_EYE_DEF_DWELL_BITS;
    configp->ec_fast_dynamic     = 2;   /* Optimized for BTC required data */
    configp->ec_error_threshold  = 30;  /* Empirically determined... */
    configp->ec_x_UI             = 1;   /* One eye width */
    configp->ec_x_resolution     = 64;  /* Normal resolution for one eye. */
    configp->ec_y_center_point   = 0;   /* center of range, 0 == use default. */
    configp->ec_y_step_size      = 1;   /* highest resolution */
    configp->ec_y_points         = 129; /* centered around ec_y_center_point */
    configp->ec_dc_balance       = 0.0; /* 0.0 => Use device specific default */
    configp->ec_trans_density    = 0.0; /* 0.0 => Use device specific default */
    configp->ec_avdd             = 0.0; /* 0.0 => Use device specific default */
    configp->ec_x_auto_scale     = TRUE;
    configp->ec_y_auto_scale     = TRUE;
    configp->ec_x_shift          = 0;
    configp->ec_gather_mean      = FALSE;
    configp->ec_mean_threshold   = 0;
    configp->ec_no_sbm           = FALSE;

    avago_serdes_data_qual_init(&configp->ec_data_qual);
    configp->ec_real_time_plot   = FALSE;
    configp->ec_set_phase_center = 2;
    configp->ec_apply_vert_alpha = 3;

    return configp;
}

/** @brief   Deallocates an Avago_serdes_eye_config_t struct. */
/** @return  void */
void avago_serdes_eye_config_destruct(
    Aapl_t *aapl,                   /**< [in] */
    Avago_serdes_eye_config_t *configpp)    /**< [in] Object to destroy. */
{
    aapl_free(aapl, configpp, __func__);
}

static void avago_serdes_eye_data_init(Avago_serdes_eye_data_t *datap)
{
    if( datap )
    {
        int i;
        memset(datap, 0, sizeof(Avago_serdes_eye_data_t));
        for( i = 0; i < AAPL_ARRAY_LENGTH(datap->ed_hbtc); i++ )
            datap->ed_hbtc[i].data_row = AAPL_MAX_DAC_RANGE;
    }
}

/** @brief   Allocates and initializes an Avago_serdes_eye_data_t struct. */
/** @return  Pointer to resulting struct. */
/** @return  On error, decrements aapl->return_code and returns NULL. */
Avago_serdes_eye_data_t *avago_serdes_eye_data_construct(Aapl_t *aapl)
{
    size_t bytes = sizeof(Avago_serdes_eye_data_t);
    Avago_serdes_eye_data_t *datap = (Avago_serdes_eye_data_t *) aapl_malloc(aapl, bytes, __func__);

    avago_serdes_eye_data_init(datap);

    return datap;
}

static void avago_serdes_eye_data_deinit(Aapl_t *aapl, Avago_serdes_eye_data_t *datap)
{
    if( datap->ed_errorsp     ) aapl_free(aapl,datap->ed_errorsp,"ed_errorsp");
    if( datap->ed_gradp       ) aapl_free(aapl,datap->ed_gradp  ,"ed_gradp");
    if( datap->ed_qvalp       ) aapl_free(aapl,datap->ed_qvalp  ,"ed_qvalp");
    if( datap->ed_bitsp       ) aapl_free(aapl,datap->ed_bitsp  ,"ed_bitsp");
    if( datap->ed_hardware_log) aapl_free(aapl,datap->ed_hardware_log,"ed_hw_log");
    if( datap->ed_comment     ) aapl_free(aapl,datap->ed_comment,"ed_comment");
    if( datap->ed_phase_center_log ) aapl_free(aapl,datap->ed_phase_center_log,"ed_phase_center_log");
}

/** @brief   Deallocates an Avago_serdes_eye_data_t structure. */
/** @details Frees any allocated members as well as itself. */
/** @return  void */
void avago_serdes_eye_data_destruct(
    Aapl_t *aapl,                   /**< [in] Pointer to Aapl_t structure. */
    Avago_serdes_eye_data_t *datap) /**< [in] Object to destroy. */
{
    avago_serdes_eye_data_deinit(aapl, datap);
    aapl_free(aapl,datap,__func__);
}

static const bigint *get_bits_column(const Avago_serdes_eye_data_t *datap, int column)
{
    if( column < 0 && column >= -AAPL_ARRAY_LENGTH(datap->ed_mission_errors) )
        return datap->ed_mission_bits[-1-column];
    return &AVAGO_EYE_BITS_GET(*datap, column, 0);
}
static const bigint *get_errs_column(const Avago_serdes_eye_data_t *datap, int column)
{
    if( column < 0 && column >= -AAPL_ARRAY_LENGTH(datap->ed_mission_errors) )
        return datap->ed_mission_errors[-1-column];
    return &AVAGO_EYE_ERRORS_GET(*datap, column, 0);
}

/** @cond INTERNAL */

/* The Eye_state_t structure contains stuff it's nice to have available when */
/* gathering eye data; used much like the data members of a C++ class. */
typedef struct
{
    Aapl_t                          *aapl;
    uint                             addr;
    const Avago_serdes_eye_config_t *configp;
    Avago_serdes_eye_data_t         *datap;
    uint                             phase_mult;   /* virtual step size */

    int                              curr_clock_is_test; /* TRUE=test, FALSE=mission */
    Avago_serdes_rx_cmp_mode_t       cmp_mode;
    int                              threshold;
    bigint                           real_dwell;   /* actual setting */
    bigint                           curr_dwell;   /* virtual setting (partial eyes) */
    int                              dwell_scale;  /* for qualified eye gathering */
    BOOL                             sbm_eye_gather;
    BOOL                             enable_not_errors;
    BOOL                             default_gather;

    int                              curr_phase;   /* high-resolution phase */
    Avago_serdes_data_qual_t         dq;
    Avago_serdes_rx_data_qual_t      data_qual;
    int                              vert_alpha[6];

    uint                             orig_phase;
    Avago_serdes_data_qual_t         orig_data_qual;

    Avago_serdes_rx_cmp_mode_t       orig_cmp_mode;
    Avago_serdes_rx_cmp_data_t       orig_cmp_data;
    uint                             dfe_resume_status;
    uint                             timeout_count;
    Avago_serdes_rx_clock_t          data_clock;
    BOOL                             pd_pi;
 /* int                              v_offsets[3][4]; // [lower,middle,upper][odd,even] vertical offsets */
    BOOL                             gather_reverse;
} Eye_state_t;

typedef struct
{
    int which;
    int entries;
    int eye[2];          /* data_qual selection */
    int v_offset[2];     /* odd,even offsets */
    int h_index[2];      /* HAL table index to which to apply delay */
    int h_delay[2];      /* odd,even vernier delays */
} Gather_info_t;

static void init_gather_info(Eye_state_t *esp, int which, Gather_info_t *gather_info)
{
    gather_info->entries = 1;
    gather_info->which = which;
    gather_info->v_offset[0] = 0;
    gather_info->h_index[0] = -1; /* Ignore */
    gather_info->eye[0] = -1;

    if( !esp->default_gather )
        return;

    /* How to handle the default dwell for each device/mode: */
    switch( aapl_get_ip_type(esp->aapl, esp->addr) )
    {
    case AVAGO_M4:
        if( avago_serdes_get_rx_line_encoding(esp->aapl, esp->addr) )
        {
            gather_info->h_delay[0] = esp->datap->delay[which];
            gather_info->h_index[0] = 12 - (which&1);
            gather_info->eye[0] = which;
        }
        else
        {
            gather_info->eye[0] = 6; /* "xxx" */
        }
        break;

    default:
    case AVAGO_SERDES:
        /* Single, prev0/prev1 gather: */
        if( !esp->sbm_eye_gather )
        {
            gather_info->entries = 2;
            gather_info->eye[0] = 7; /* "0xx" */
            gather_info->eye[1] = 8; /* "1xx" */
            gather_info->v_offset[0] = esp->vert_alpha[0];
            gather_info->v_offset[1] = esp->vert_alpha[1];
            gather_info->h_index[0] =
            gather_info->h_index[1] = -1; /* Ignore */
            break;
        }

        /* SBM gather uses default values. */
        break;
    }
    AAPL_LOG_PRINT4(esp->aapl, AVAGO_DEBUG4, __func__, __LINE__, "which=%d; entries=%d; eye=%d,%d; v_offset=%d,%d; h_index=%d,%d; h_delay=%d,%d.\n",
                                gather_info->which, gather_info->entries,
                                gather_info->eye[0], gather_info->eye[1],
                                gather_info->v_offset[0], gather_info->v_offset[1],
                                gather_info->h_index[0], gather_info->h_index[1],
                                gather_info->h_delay[0], gather_info->h_delay[1]);
}

/** @endcond */

/** @brief   Determines the appropriate default AVDD value for this eye gather. */
/** @return  Returns the default AVDD in volts. */
float avago_serdes_eye_get_default_avdd(Aapl_t *aapl, uint addr)
{
    float avdd = 1.0;
    int sdrev = aapl_get_sdrev(aapl, addr);
    switch( sdrev )
    {
    case AAPL_SDREV_OM4:    avdd = 1.2; break; /* Optical M4 */
    case AAPL_SDREV_CM4:                       /* 28nm Copper M4 */
    case AAPL_SDREV_CM4_16: avdd = 1.1; break; /* 16nm Copper M4 */
    default:
    case AAPL_SDREV_HVD6:                      /* HVD6 variant */
    case AAPL_SDREV_D6:     avdd = 1.0; break; /* 28nm D6 */
    case AAPL_SDREV_16:     avdd = 0.9; break; /* 16nm D6 */
    case AAPL_SDREV_D6_07:  avdd = 0.9; break; /* 7nm D6 */
    case AAPL_SDREV_P1:
        if( aapl_get_process_id(aapl,addr) == AVAGO_TSMC_28 ) avdd = 0.9;
        else                                                  avdd = 0.8;
        break;
    }
    return avdd;
}
/** @brief  Calculates the DAC scaling. */
/** @return Returns milliVolts per DAC step. */
static float eye_get_dac_scale(Eye_state_t *esp)
{
    if( aapl_get_ip_type(esp->aapl, esp->addr) == AVAGO_M4
        && aapl_get_process_id(esp->aapl, esp->addr) == AVAGO_TSMC_16
        && aapl_get_ip_rev(esp->aapl, esp->addr) > 0x0a )
    {
        /* This clause applies only to 16nm CM4 rev 02 and newer: */
        if( avago_serdes_mem_rd(esp->aapl, esp->addr, AVAGO_ESB, 0xb1) & 1 )
            return 1454.545454 * esp->datap->ed_avdd / esp->datap->ed_y_resolution; /* CM4 sel_lowcm = 1 */
        return  800 * esp->datap->ed_avdd / esp->datap->ed_y_resolution; /* CM4 sel_lowcm = 0 */
    }
    /* Otherwise, use default: */
    return 1000 * esp->datap->ed_avdd / esp->datap->ed_y_resolution;
}


/** @brief   Sets the error timer and updates the internal state accordingly. */
/** @details If the internal state already matches the request, does nothing. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
static int eye_set_error_timer(Eye_state_t *esp, bigint new_dwell)
{
    int ret;
    bigint real_dwell = new_dwell * esp->dwell_scale;

    /* Increase real_dwell here to get to the desired effective dwell for */
    /*   partial eyes. */

    if( real_dwell == esp->real_dwell )
        return 0;

    ret = avago_serdes_set_error_timer(esp->aapl, esp->addr, real_dwell);
    if( ret == 0 )
    {
        esp->real_dwell = real_dwell;
        esp->curr_dwell = new_dwell;
    }
    return ret;
}


static BOOL eye_set_clock_source(Eye_state_t *esp, BOOL test_clock)
{
    if( esp->sbm_eye_gather )
        return TRUE;
    if( esp->curr_clock_is_test == test_clock )
        return TRUE;
    /* Previously we toggled test input between I and R clocks. */
    /* Now we want to toggle test input between whatever data clock is selecting and the R clock. */
    {
        Avago_serdes_rx_clock_t clock = test_clock ? AVAGO_SERDES_RX_CLOCK_R : esp->data_clock;
        if( !avago_serdes_set_rx_test_clock(esp->aapl, esp->addr, clock) )
            return FALSE;
    }
    esp->curr_clock_is_test = test_clock;
    return TRUE;
}

static int eye_set_dac(Eye_state_t *esp, int dac)
{
    BOOL full_resolution = FALSE;
    int errors = avago_serdes_set_dac2(esp->aapl, esp->addr, dac, full_resolution, TRUE);
    if( errors > esp->curr_dwell )
        aapl_log_printf(esp->aapl, AVAGO_WARNING, __func__, __LINE__, "avago_serdes_set_dac2(dac = %d) returned %d, which is greater than dwell of %s\n", dac, errors, aapl_bigint_to_str(esp->curr_dwell));
    return errors;
}

/** @brief   Steps the phase to the requested location. */
/** @return  Returns the errors gathered (when get_errors is true), else */
/**          0 on success. */
/** @return  On failure, decrements aapl->return_code and returns -1. */
static int eye_step_phase(Eye_state_t *esp, int target_phase, BOOL get_errors)
{
    if( target_phase == esp->curr_phase && !get_errors ) return 0;
    return avago_serdes_step_phase(esp->aapl, esp->addr, target_phase, &esp->curr_phase, get_errors);
}

/* FORWARD Declaration: */
static BOOL eye_set_data_qual_str(Eye_state_t *esp, const char *dq_str);

/** @brief   Sets the SerDes compare mode. */
/** @details Skips firmware call if esp->data_qual already equals data_qual. */
/**          Else updates esp->data_qual if firmware call succeeds. */
/** @return  Returns TRUE on success, FALSE otherwise. */
static BOOL eye_set_data_qual(Eye_state_t *esp, const Avago_serdes_data_qual_t dq)
{
    if( memcmp(&dq,&(esp->dq),sizeof(dq)) == 0 )
        return TRUE;

    /*printf("eye_set_data_qual = %s\n",aapl_data_qual_to_str(dq)); */
    if( esp->sbm_eye_gather && dq.d6_data_qual == AVAGO_SERDES_RX_DATA_QUAL_DEFAULT && !esp->datap->ed_apply_vert_alpha )
        eye_set_data_qual_str(esp, "xxx");

    if( dq.d6_data_qual == AVAGO_SERDES_RX_DATA_QUAL_DEFAULT ||
        avago_serdes_set_data_qual(esp->aapl, esp->addr, dq) == 0 )
    {
        esp->dq = dq;
        return TRUE;
    }
    return FALSE;
}

/** @brief Decodes dq_str and sets the Rx data qualification. */
static BOOL eye_set_data_qual_str(Eye_state_t *esp, const char *dq_str)
{
    Avago_serdes_data_qual_t dq;
    aapl_str_to_data_qual(dq_str, &dq);
    return eye_set_data_qual(esp, dq);
}

static void eye_select(Eye_state_t *esp, int selection)
{
    if( selection >= 0 )
    {
        const char *dq_str = 0;
        switch( selection )
        {
        case 0: dq_str = "x[01]x,lsb,even"; break;
        case 1: dq_str = "x[01]x,lsb,odd"; break;
        case 2: dq_str = "msb,even"; break;
        case 3: dq_str = "msb,odd"; break;
        case 4: dq_str = "x[23]x,lsb,even"; break;
        case 5: dq_str = "x[23]x,lsb,odd"; break;
        case 6: dq_str = "xxx"; break;
        case 7: dq_str = "0xx"; break;
        case 8: dq_str = "1xx"; break;
        default: return;
        }
        /*printf("set eye selection to %d (%s)\n", selection, dq_str); */
        eye_set_data_qual_str(esp, dq_str);
    }
}



/** @brief   Sets the compare mode and updates the internal state to match. */
/** @details If the internal state already matches the request, does nothing. */
static BOOL eye_set_compare_mode(Eye_state_t *esp, Avago_serdes_rx_cmp_mode_t cmp_mode)
{
    if( cmp_mode == esp->cmp_mode )
        return TRUE;

    if( esp->datap->ed_cmp_mode == AVAGO_SERDES_RX_CMP_MODE_TEST_PATGEN )
    {
        avago_serdes_set_rx_cmp_data(esp->aapl, esp->addr, esp->orig_cmp_data);         /* Momentarily enable PRBS to reseed */
        avago_spico_int(esp->aapl, esp->addr, 0x02, 0x0220 | (esp->orig_cmp_data & 7)); /* Disable reseed */
    }
    if( 0 == avago_serdes_set_rx_cmp_mode(esp->aapl, esp->addr, cmp_mode) )
    {
        aapl_str_to_data_qual("xxx",&esp->dq);
        esp->cmp_mode = cmp_mode;
        return TRUE;
    }
    return FALSE;
}

static int sbm_eye_get_point(Eye_state_t *esp, BOOL mission, int x, int y);

/* Find the DAC edge in the search range: */
static float find_edge(Eye_state_t *esp, int inner_dac, int outer_dac, int threshold)
{
    int inc = (outer_dac - inner_dac) / 2;
    int above_count = threshold, below_count = threshold;

    float interpolated_dac;
    while( inc != 0 && !aapl_get_async_cancel_flag(esp->aapl) )
    {
        int dac = inner_dac + inc;
        int errors;
        if( !esp->sbm_eye_gather )
            errors = eye_set_dac(esp, dac);
        else
            errors = sbm_eye_get_point(esp, TRUE, 0, dac - (esp->datap->ed_y_resolution-1) / 2);
        /*printf("dac = %d, errors = %d, inc = %d\n",dac,errors,inc); */
        inc /= 2;
        if( errors > threshold )
        {
            above_count = errors;
            outer_dac = dac;
            dac -= inc;
        }
        else
        {
            below_count = errors;
            inner_dac = dac;
            dac += inc;
        }
    }
    /*printf("DAC (%d,%d) (%d..%d)\n",inner_dac,outer_dac,below_count,above_count); */
    interpolated_dac = inner_dac + (float)1.0 * (outer_dac - inner_dac) * (threshold - below_count) / (above_count - below_count);

    /*printf("Interpolated DAC = %5.2f\n",interpolated_dac); */
    return interpolated_dac;
}


/* Search DAC offsets for where the error count matches the threshold and */
/* return the interpolated DAC offset from the DAC mid-point. */
static float find_y_edge(Eye_state_t *esp, int inc, int data_qual, int threshold)
{
    int mid_dac = (esp->datap->ed_y_resolution-1) / 2;
    float interpolated_dac = 0;

    Avago_serdes_data_qual_t dq = esp->dq;
    dq.d6_data_qual = (Avago_serdes_rx_data_qual_t)data_qual;
    if( avago_serdes_get_rx_line_encoding(esp->aapl, esp->addr) )
        aapl_str_to_data_qual("x[03]x",&dq);
    /*printf("find_y_edge(dq=%s (%x))\n",aapl_rx_data_qual_to_str(dq.d6_data_qual),data_qual); */
    if( eye_set_data_qual(esp, dq) )
        interpolated_dac = find_edge(esp, mid_dac, mid_dac+inc+inc, threshold) - mid_dac;

    /*printf("Interpolated DAC = %5.2f\n",interpolated_dac); */
    return interpolated_dac;
}

/* Directly measure the mean offsets for each of the 16 qualified patterns. */
static int measure_mean_vos(Eye_state_t *esp, float dvos[16])
{
    int dwell_bits = 1000000;
    uint mean = dwell_bits / 32;  /* Qualification matches 1/16th of possible patterns, want half that. */

    /* Set mission clock */
    if( !eye_set_clock_source(esp, /* test_clock = */ FALSE) ||
        !eye_set_compare_mode(esp, AVAGO_SERDES_RX_CMP_MODE_XOR) ||
        eye_set_error_timer(esp, dwell_bits) < 0 )
        return -1;

    dvos[0x0] = find_y_edge(esp,  64, 0x01 | AVAGO_SERDES_RX_DATA_QUAL_EVEN, mean);
    dvos[0x1] = find_y_edge(esp,  64, 0x02 | AVAGO_SERDES_RX_DATA_QUAL_EVEN, mean);
    dvos[0x2] = find_y_edge(esp,  64, 0x01 | AVAGO_SERDES_RX_DATA_QUAL_ODD , mean);
    dvos[0x3] = find_y_edge(esp,  64, 0x02 | AVAGO_SERDES_RX_DATA_QUAL_ODD , mean);
    dvos[0x4] = find_y_edge(esp, -64, 0x04 | AVAGO_SERDES_RX_DATA_QUAL_EVEN, mean);
    dvos[0x5] = find_y_edge(esp, -64, 0x08 | AVAGO_SERDES_RX_DATA_QUAL_EVEN, mean);
    dvos[0x6] = find_y_edge(esp, -64, 0x04 | AVAGO_SERDES_RX_DATA_QUAL_ODD , mean);
    dvos[0x7] = find_y_edge(esp, -64, 0x08 | AVAGO_SERDES_RX_DATA_QUAL_ODD , mean);
    dvos[0x8] = find_y_edge(esp,  64, 0x10 | AVAGO_SERDES_RX_DATA_QUAL_EVEN, mean);
    dvos[0x9] = find_y_edge(esp,  64, 0x20 | AVAGO_SERDES_RX_DATA_QUAL_EVEN, mean);
    dvos[0xa] = find_y_edge(esp,  64, 0x10 | AVAGO_SERDES_RX_DATA_QUAL_ODD , mean);
    dvos[0xb] = find_y_edge(esp,  64, 0x20 | AVAGO_SERDES_RX_DATA_QUAL_ODD , mean);
    dvos[0xc] = find_y_edge(esp, -64, 0x40 | AVAGO_SERDES_RX_DATA_QUAL_EVEN, mean);
    dvos[0xd] = find_y_edge(esp, -64, 0x80 | AVAGO_SERDES_RX_DATA_QUAL_EVEN, mean);
    dvos[0xe] = find_y_edge(esp, -64, 0x40 | AVAGO_SERDES_RX_DATA_QUAL_ODD , mean);
    dvos[0xf] = find_y_edge(esp, -64, 0x80 | AVAGO_SERDES_RX_DATA_QUAL_ODD , mean);

    return 0;
}

/* Measures the dvos values, from which we can calculate vert_alpha values. */
/* Since we are doing dac scans which are relatively slow, we only measure */
/*   those values relevant to the requested measurement. */
/* */
static int measure_vos(Eye_state_t *esp, float vos[8])
{
    int threshold = esp->threshold;
    /* TBD: These calculations must be updated..... */
    aapl_log_printf(esp->aapl, AVAGO_DEBUG3, __func__, __LINE__, "data qual = %s.\n",aapl_data_qual_to_str(esp->configp->ec_data_qual));

    /* Set mission clock */
    if( !eye_set_clock_source(esp, /* test_clock = */ FALSE) ||
        !eye_set_compare_mode(esp, AVAGO_SERDES_RX_CMP_MODE_XOR) ||
        eye_set_error_timer(esp, AVAGO_EYE_MIN_DWELL_BITS) < 0 )
        return esp->aapl->return_code;

    switch( esp->configp->ec_data_qual.d6_data_qual )
    {
    case AVAGO_SERDES_RX_DATA_QUAL_DEFAULT:
        vos[0] = find_y_edge(esp, -64, AVAGO_SERDES_RX_DATA_QUAL_PREV0E, threshold);
        vos[1] = find_y_edge(esp,  64, AVAGO_SERDES_RX_DATA_QUAL_PREV0E, threshold);
        vos[2] = find_y_edge(esp, -64, AVAGO_SERDES_RX_DATA_QUAL_PREV0O, threshold);
        vos[3] = find_y_edge(esp,  64, AVAGO_SERDES_RX_DATA_QUAL_PREV0O, threshold);
        vos[4] = find_y_edge(esp, -64, AVAGO_SERDES_RX_DATA_QUAL_PREV1E, threshold);
        vos[5] = find_y_edge(esp,  64, AVAGO_SERDES_RX_DATA_QUAL_PREV1E, threshold);
        vos[6] = find_y_edge(esp, -64, AVAGO_SERDES_RX_DATA_QUAL_PREV1O, threshold);
        vos[7] = find_y_edge(esp,  64, AVAGO_SERDES_RX_DATA_QUAL_PREV1O, threshold);
        break;
    case AVAGO_SERDES_RX_DATA_QUAL_PREV0 :
        vos[0] = find_y_edge(esp, -64, AVAGO_SERDES_RX_DATA_QUAL_PREV0E, threshold);
        vos[1] = find_y_edge(esp,  64, AVAGO_SERDES_RX_DATA_QUAL_PREV0E, threshold);
        vos[2] = find_y_edge(esp, -64, AVAGO_SERDES_RX_DATA_QUAL_PREV0O, threshold);
        vos[3] = find_y_edge(esp,  64, AVAGO_SERDES_RX_DATA_QUAL_PREV0O, threshold);
        break;
    case AVAGO_SERDES_RX_DATA_QUAL_PREV1 :
        vos[4] = find_y_edge(esp, -64, AVAGO_SERDES_RX_DATA_QUAL_PREV1E, threshold);
        vos[5] = find_y_edge(esp,  64, AVAGO_SERDES_RX_DATA_QUAL_PREV1E, threshold);
        vos[6] = find_y_edge(esp, -64, AVAGO_SERDES_RX_DATA_QUAL_PREV1O, threshold);
        vos[7] = find_y_edge(esp,  64, AVAGO_SERDES_RX_DATA_QUAL_PREV1O, threshold);
        break;
    case AVAGO_SERDES_RX_DATA_QUAL_PREV0E:
        vos[0] = find_y_edge(esp, -64, AVAGO_SERDES_RX_DATA_QUAL_PREV0E, threshold);
        vos[1] = find_y_edge(esp,  64, AVAGO_SERDES_RX_DATA_QUAL_PREV0E, threshold);
        break;
    case AVAGO_SERDES_RX_DATA_QUAL_PREV0O:
        vos[2] = find_y_edge(esp, -64, AVAGO_SERDES_RX_DATA_QUAL_PREV0O, threshold);
        vos[3] = find_y_edge(esp,  64, AVAGO_SERDES_RX_DATA_QUAL_PREV0O, threshold);
        break;
    case AVAGO_SERDES_RX_DATA_QUAL_PREV1E:
        vos[4] = find_y_edge(esp, -64, AVAGO_SERDES_RX_DATA_QUAL_PREV1E, threshold);
        vos[5] = find_y_edge(esp,  64, AVAGO_SERDES_RX_DATA_QUAL_PREV1E, threshold);
        break;
    case AVAGO_SERDES_RX_DATA_QUAL_PREV1O:
        vos[6] = find_y_edge(esp, -64, AVAGO_SERDES_RX_DATA_QUAL_PREV1O, threshold);
        vos[7] = find_y_edge(esp,  64, AVAGO_SERDES_RX_DATA_QUAL_PREV1O, threshold);
        break;
    default:
        if( esp->configp->ec_data_qual.d6_data_qual >= 256 || esp->configp->ec_data_qual.d6_data_qual == 0 )
            break;
        if( (esp->configp->ec_data_qual.d6_data_qual & 0xf0) == 0x00 )
        {
            vos[0] = vos[2] = find_y_edge(esp, -64, esp->configp->ec_data_qual.d6_data_qual, threshold);
            vos[1] = vos[3] = find_y_edge(esp,  64, esp->configp->ec_data_qual.d6_data_qual, threshold);
        }
        else if( (esp->configp->ec_data_qual.d6_data_qual & 0x0f) == 0x00 )
        {
            vos[4] = vos[6] = find_y_edge(esp, -64, esp->configp->ec_data_qual.d6_data_qual, threshold);
            vos[5] = vos[7] = find_y_edge(esp,  64, esp->configp->ec_data_qual.d6_data_qual, threshold);
        }
        /* else do nothing */
        break;
    }

    return esp->aapl->return_code;
}

/*============================================================================= */
/* G E T   V E R T   A L P H A */
/* */
/* Get the SerDes's vert_alpha values, representing the Y (DAC) offsets for */
/* the partial eyes, respectively:  prev0, prev1, prev0e, prev0o, prev1e, */
/* prev1o (matching 6 elements from Avago_serdes_rx_data_qual_t). */
/* */
/* If the SerDes has not calculated these levels, which is the case when */
/*  dfe tuning has not been ran, then we measure the values ourselves. */
/* */
static void get_vert_alpha(Eye_state_t *esp)
{
    Aapl_t *aapl = esp->aapl;
    int *vap = esp->vert_alpha;
    int sdrev = aapl_get_sdrev(aapl,esp->addr);

    /* Also see set_dac2 function which should have the same list: */
    BOOL invert_vos = sdrev == AAPL_SDREV_D6 || sdrev == AAPL_SDREV_HVD6 || sdrev == AAPL_SDREV_16 || sdrev == AAPL_SDREV_P1 || sdrev == AAPL_SDREV_D6_07;

    if( esp->sbm_eye_gather || aapl_get_ip_type(esp->aapl, esp->addr) != AVAGO_SERDES || !esp->datap->ed_apply_vert_alpha )
        return; /* Only for D6, without SBM acceleration */

    /* Calculate based on vos and mid values from firmware: */
    if( esp->datap->ed_apply_vert_alpha == 3 )
    {
        int *vos = (int*)esp->datap->ed_dfe_state.vos;
        int *mid = (int*)esp->datap->ed_dfe_state.vosMID;

        /* Calculate vert_alpha values as average of component levels: */
        vap[2] = vos[0] - mid[0];       /* prev0e */
        vap[3] = vos[1] - mid[1];       /* prev0o */
        vap[4] = vos[2] - mid[2];       /* prev1e */
        vap[5] = vos[3] - mid[3];       /* prev1o */

        vap[0] = (vap[2] + vap[3]) / 2; /* prev0 */
        vap[1] = (vap[4] + vap[5]) / 2; /* prev1 */

        if( invert_vos )
        {
            int i;
            for( i = 0; i < 6; i++ )
                vap[i] = -vap[i];
        }

        aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "SBus %s; vos[] = %d,%d,%d,%d; vosMID[] = %d,%d,%d,%d.\n",
            aapl_addr_to_str(esp->addr), vos[0], vos[1], vos[2], vos[3], mid[0], mid[1], mid[2], mid[3]);
    }

    if( esp->datap->ed_apply_vert_alpha == 4 ||
        esp->datap->ed_apply_vert_alpha == 1 ||
        esp->datap->ed_apply_vert_alpha == 2 )
    {
        float vos[8];
        int *dvos;
        int i;
        if( esp->datap->ed_apply_vert_alpha == 4 )
            dvos = esp->datap->ed_dfe_state.dataLEV;   /* for d0/1* values */
        else
            /* Use firmware measured testLEV edge offsets: */
            dvos = esp->datap->ed_dfe_state.testLEV;   /* for t0/1* values */

        for( i = 0; i < 8; i++ )
            vos[i] = invert_vos ? -dvos[i] : dvos[i];

        /* If explicit request, or test/data levels not set by dfe tuning: */
        if( esp->datap->ed_apply_vert_alpha == 2 )
            measure_vos(esp, vos);       /* measure test edges directly. */

        /* Calculate vert_alpha values as average of component levels: */
        vap[0] = aapl_iround((vos[0] + vos[1]           /* t0e_lo, t0e_hi. */
                            + vos[2] + vos[3]) / 4.0);  /* t0o_lo, t0o_hi. */
        vap[1] = aapl_iround((vos[4] + vos[5]           /* t1e_lo, t1e_hi. */
                            + vos[6] + vos[7]) / 4.0);  /* t1o_lo, t1o_hi. */

        vap[2] = aapl_iround((vos[0] + vos[1]) / 2.0);  /* t0e_lo, t0e_hi. */
        vap[3] = aapl_iround((vos[2] + vos[3]) / 2.0);  /* t0o_lo, t0o_hi. */
        vap[4] = aapl_iround((vos[4] + vos[5]) / 2.0);  /* t1e_lo, t1e_hi. */
        vap[5] = aapl_iround((vos[6] + vos[7]) / 2.0);  /* t1o_lo, t1o_hi. */

        aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "SBus %s; %sLEV[] = %.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f,%.1f.\n",
            aapl_addr_to_str(esp->addr), esp->datap->ed_apply_vert_alpha==2?"data":"test",
            vos[0], vos[1], vos[2], vos[3], vos[4], vos[5], vos[6], vos[7]);
    }

    /* Measure based on mean levels of 16 qualified patterns: */
    if( esp->datap->ed_apply_vert_alpha == 5 || esp->datap->ed_apply_vert_alpha == 6 )
    {
        float dvos[16];
        int i;

        /* Firmware measured from 16 qualified patterns: */
        if( esp->datap->ed_apply_vert_alpha == 5 )
        {
            for( i = 0; i < 16; i++ )
            {
                dvos[i] = (short)avago_serdes_mem_rd(aapl, esp->addr, AVAGO_DMEM, 0x2ee + i);
                if( invert_vos )
                    dvos[i] = -dvos[i];
            }
        }
        /* AAPL measured and interpolated from 16 qualified patterns: */
        if( esp->datap->ed_apply_vert_alpha == 6 || (dvos[0] == 0.0 && dvos[1] == 0.0) )
        {
            measure_mean_vos(esp,dvos);  /* Use 16 qualified patterns to calculate the offsets. */
        }

        /* Calculate vert_alpha values as average of measured means: */
        vap[0]  = aapl_iround((dvos[ 0] + dvos[ 1] + dvos[ 2] + dvos[ 3] +
                               dvos[ 4] + dvos[ 5] + dvos[ 6] + dvos[ 7]) / 8.0);
        vap[1]  = aapl_iround((dvos[ 8] + dvos[ 9] + dvos[10] + dvos[11] +
                               dvos[12] + dvos[13] + dvos[14] + dvos[15]) / 8.0);

        vap[2] = aapl_iround((dvos[ 0] + dvos[ 1] + dvos[ 4] + dvos[ 5]) / 4.0);
        vap[3] = aapl_iround((dvos[ 2] + dvos[ 3] + dvos[ 6] + dvos[ 7]) / 4.0);
        vap[4] = aapl_iround((dvos[ 8] + dvos[ 9] + dvos[12] + dvos[13]) / 4.0);
        vap[5] = aapl_iround((dvos[10] + dvos[11] + dvos[14] + dvos[15]) / 4.0);

        for( i = 0; i < 16; i++ )
            aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, 0, "mean vos[%2d] = %5.2f\n",i,dvos[i]);
    }

    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "SBus %s; vap[] = %d,%d,%d,%d,%d,%d.\n",
                aapl_addr_to_str(esp->addr), vap[0], vap[1], vap[2], vap[3], vap[4], vap[5]);
    return;
}

/** @brief   Sets ed_x_min, ed_x_max in datap for new center. */
/** datap inputs: ed_x_points, ed_x_step. */
static void set_x_center(Avago_serdes_eye_data_t *datap, int center)
{
    int offset = datap->ed_x_UI * datap->ed_x_resolution / 2 * datap->ed_x_step;
    datap->ed_x_min = center - offset;
    datap->ed_x_max = center + offset;
    if( !datap->ed_phase_table )
        datap->ed_phase_center = center;
}

/** @brief    Updates x values for new resolution. */
/** @details Sets datap fields ed_x_resolution, ed_x_points, ed_x_step, ed_x_min, ed_x_max. */
/** Implicit inputs: esp->phase_mult, datap->ed_x_UI */
static void set_x_resolution(Eye_state_t *esp, uint request_res)
{
#   define MIN_RESOLUTION 8
    Avago_serdes_eye_data_t *datap = esp->datap;
    uint full_res = 64 * esp->phase_mult;  /* Full hardware res */
    uint x_res = full_res;
    while( x_res > request_res && x_res > MIN_RESOLUTION )
        x_res /= 2;
    datap->ed_x_resolution = x_res;
    datap->ed_x_points     = x_res * datap->ed_x_UI + 1;
    datap->ed_x_step       = full_res / x_res;
    set_x_center(datap, (datap->ed_x_min + datap->ed_x_max) / 2); /* Do not change center */
}

static void set_y_points(Avago_serdes_eye_data_t *datap, uint y_points)
{
    datap->ed_y_points = y_points;
    datap->ed_y_min = datap->ed_y_center_point - (datap->ed_y_points - 1) / 2 * datap->ed_y_step;
}

/* Implicit inputs: esp->configp */
static BOOL initialize_eye_data(Eye_state_t *esp)
{
    int aapl_return_code = esp->aapl->return_code;
    const Avago_serdes_eye_config_t *configp = esp->configp;
    Avago_serdes_eye_data_t *datap = esp->datap;
    Aapl_t *aapl = esp->aapl;
    uint addr = esp->addr;

    /* These values are generated based on hardware: */
    if( esp->phase_mult == 0 )
        esp->phase_mult = configp->ec_eye_type == AVAGO_EYE_HEIGHT ? 1 : avago_serdes_get_phase_multiplier(aapl, addr);

    if( datap->ed_y_resolution == 0 )
        datap->ed_y_resolution = avago_serdes_get_dac_range(aapl, addr);

    /* These values come from the caller: */
    datap->ed_eye_type        = configp->ec_eye_type;
    datap->ed_cmp_mode        = configp->ec_cmp_mode;
    datap->ed_min_dwell_bits  = MAX(AVAGO_EYE_MIN_DWELL_BITS, configp->ec_min_dwell_bits);
    datap->ed_max_dwell_bits  = MAX(datap->ed_min_dwell_bits, configp->ec_max_dwell_bits);
    if( esp->sbm_eye_gather )
        datap->ed_min_dwell_bits  = MIN(datap->ed_min_dwell_bits, AVAGO_EYE_SBM_DWELL_MAX_BITS);
    else
        datap->ed_min_dwell_bits  = MIN(datap->ed_min_dwell_bits, AVAGO_EYE_ONE_DWELL_MAX_BITS);
    datap->ed_max_dwell_bits  = MAX(datap->ed_min_dwell_bits, datap->ed_max_dwell_bits);
    datap->ed_fast_dynamic    = configp->ec_fast_dynamic;
    datap->ed_error_threshold = configp->ec_error_threshold;
    datap->ed_mean_threshold  = configp->ec_mean_threshold;
    datap->ed_dc_balance      = configp->ec_dc_balance;
    datap->ed_trans_density   = configp->ec_trans_density;
    datap->ed_avdd            = configp->ec_avdd == 0.0 ? avago_serdes_eye_get_default_avdd(aapl, addr) : configp->ec_avdd;
    datap->ed_dac_scale       = eye_get_dac_scale(esp); /* Uses ed_avdd and ed_y_resolution. */
    datap->ed_centering_options = configp->ec_centering_options;
    datap->ed_set_phase_center  = configp->ec_set_phase_center;

    datap->ed_x_shift         = configp->ec_x_shift;
    if( datap->ed_eye_type == AVAGO_EYE_HEIGHT )
    {
        datap->ed_x_resolution = 1;
        datap->ed_x_points     = 1;
        datap->ed_x_step       = 1;
        datap->ed_x_UI         = 1;
        set_x_center(datap, 0);
    }
    else
    {
        datap->ed_x_UI = configp->ec_x_UI <= 1 ? 1 : configp->ec_x_UI;
        set_x_resolution(esp, configp->ec_x_resolution); /* Set other ed_x_* values. */
    }

    if( esp->datap->ed_cmp_mode == AVAGO_SERDES_RX_CMP_MODE_TEST_PATGEN )
        esp->orig_cmp_data = avago_serdes_get_rx_cmp_data(aapl,addr);

    datap->ed_y_center_point = configp->ec_y_center_point == 0 || configp->ec_y_center_point >= datap->ed_y_resolution ? (datap->ed_y_resolution-1) / 2 : configp->ec_y_center_point;
    datap->ed_y_step         = configp->ec_y_step_size > 0 ? configp->ec_y_step_size : 1;

    if( datap->ed_eye_type == AVAGO_EYE_WIDTH )
    {
        if( avago_serdes_get_rx_line_encoding(aapl, addr) )
            set_y_points(esp->datap, datap->ed_y_resolution);
        else
            set_y_points(esp->datap, 1);
    }
    else
    {
        uint y_points = datap->ed_y_center_point / datap->ed_y_step + (datap->ed_y_resolution - datap->ed_y_center_point - 1) / datap->ed_y_step + 1;
        if( configp->ec_y_points < y_points )
            y_points = configp->ec_y_points;
        set_y_points(esp->datap, y_points);
    }

    /*printf("%d: y_center=%d, step=%u, points=%u\n", __LINE__, datap->ed_y_center_point, datap->ed_y_step, datap->ed_y_points); */

    datap->ed_y_mission_points = datap->ed_y_resolution;
    datap->ed_y_mission_step   = 1;
    datap->ed_y_mission_min    = 0;
    datap->eye_count = 1;

    if( datap->ed_hardware_log) aapl_free(aapl,datap->ed_hardware_log,"ed_hw_log");
    datap->ed_hardware_log = avago_hardware_info_format(aapl, addr);

    if( avago_serdes_get_rx_line_encoding(aapl, addr) )
    {
        avago_serdes_data_channel_inputs_read(   aapl, addr, &datap->inputs);
        avago_serdes_data_channel_cal_read(      aapl, addr, &datap->cal);
        avago_serdes_data_channel_cal_delta_read(aapl, addr, &datap->delta);
        avago_serdes_test_channel_cal_read(      aapl, addr, &datap->test_cal);
        if( configp->ec_data_qual.d6_data_qual != AVAGO_SERDES_RX_DATA_QUAL_DEFAULT )
            datap->eye_count = 1;

        datap->delay[0] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 10);
        datap->delay[1] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT,  9);
        datap->delay[2] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT,  8);
        datap->delay[3] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT,  7);
        datap->delay[4] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT,  6);
        datap->delay[5] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT,  5);
        datap->delay[6] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 12);
        datap->delay[7] = (short) avago_serdes_hal_get(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 11);
        datap->eye_count = 6;
    }
    else
        datap->eye_count = 1;

    avago_serdes_get_dfe_state(aapl, addr, &datap->ed_dfe_state);
    datap->ed_data_qual        = configp->ec_data_qual;
    datap->ed_apply_vert_alpha = configp->ec_apply_vert_alpha;
    if( datap->ed_apply_vert_alpha )
    {
        uint build_id = aapl_get_firmware_build(aapl, addr);
        if( (build_id & 0x00e0) != 0x0040 )
            datap->ed_apply_vert_alpha = FALSE;
    }

    get_vert_alpha(esp); /* Calculate the vert_alpha values from dfe */

    return aapl->return_code == aapl_return_code;
}

static void init_default_balance_and_density(Aapl_t *aapl, uint addr, Avago_serdes_eye_data_t *datap)
{
    /* Provide device specific DC balance and transition density defaults: */
    if( datap->ed_dc_balance == 0.0 )
        datap->ed_dc_balance = avago_serdes_get_rx_line_encoding(aapl, addr) ? DEF_DC_BALANCE_M4 : DEF_DC_BALANCE;

    if( datap->ed_trans_density == 0.0 )
        datap->ed_trans_density = avago_serdes_get_rx_line_encoding(aapl, addr) ? DEF_TRANS_DENSITY_M4 : DEF_TRANS_DENSITY;
}

/* @brief Synchronizes the Eye_state_t structure with the SerDes state. */
static BOOL init_eye_state(
    Eye_state_t *esp,
    Aapl_t *aapl,
    uint addr,
    const Avago_serdes_eye_config_t *configp,
    Avago_serdes_eye_data_t *datap)
{
    memset(esp, 0, sizeof(Eye_state_t));  /* All fields set to zero/null. */
    esp->aapl      = aapl;
    esp->addr      = addr;
    esp->configp   = configp;
    esp->datap     = datap;

    /* Initialize the Eye_state_t cache values: */
    esp->curr_clock_is_test = TRUE;
    esp->orig_cmp_mode = /* Save value for restoring after eye gather. */
    esp->cmp_mode = avago_serdes_get_rx_cmp_mode(aapl, addr);
    esp->threshold  = configp->ec_error_threshold;
    esp->real_dwell = 0;    /* Force update on first use in eye_set_error_timer. */
    esp->curr_dwell = 0;
    esp->default_gather = TRUE;

    {
        Avago_serdes_rx_clocks_t clocks;
        avago_serdes_rx_clock_read(aapl, addr, &clocks);
        esp->data_clock = clocks.data;
        esp->curr_clock_is_test = clocks.test == AVAGO_SERDES_RX_CLOCK_R;
        esp->pd_pi = TRUE;
        if( clocks.data == AVAGO_SERDES_RX_CLOCK_R || clocks.edge == AVAGO_SERDES_RX_CLOCK_R || clocks.dfe == AVAGO_SERDES_RX_CLOCK_R )
            esp->pd_pi = FALSE;
    }
    initialize_eye_data(esp);

    /* Only restore low power mode if was in low power mode before eye capture. */
    esp->pd_pi &= avago_serdes_enable_low_power_mode(aapl, addr, FALSE);

    esp->dwell_scale = 1;
    esp->sbm_eye_gather = FALSE;

    esp->orig_phase = /* Save value for restoring after eye gather. */
    esp->curr_phase = avago_serdes_get_phase(aapl, addr);
    if( aapl_get_ip_type(aapl, addr) == AVAGO_SERDES && !configp->ec_no_sbm )
    {
        uint sbm_addr = avago_make_sbus_master_addr(addr);
        uint sbm_bld = aapl_get_firmware_build(aapl, sbm_addr);
        /* uint serdes_bld = aapl_get_firmware_build(aapl, addr); */
        if( (sbm_bld & 0xf0ff) != 0x0004 ) /* || serdes_bld != 0x0045 ) // Disallow use of SBM eye gather on AVSP firmware with swap builds. */
        {
            uint sbm_rev = aapl_get_firmware_rev(aapl, sbm_addr) & 0xff;
            if( sbm_rev > 0x1A || (sbm_rev == 0x1A && (sbm_bld & 0xf0ff) != 0x0004) )
            {
                uint serdes_fw_rev = aapl_get_firmware_rev(aapl, addr);
                if( (serdes_fw_rev & 0xff) >= 0x52 )
                {
                    int cap = avago_spico_int(aapl, sbm_addr, SBM_INT, EYE_READ_CAP);    /* Confirm that firmware has support */
                    int sdrev = aapl_get_sdrev(aapl, addr);
                    if( sdrev == AAPL_SDREV_D6_07 )
                        esp->sbm_eye_gather = (cap & 0x4);  /* V2 int 0x25 support with vert-alpha corrections, separately supports inverted VOS values */
                    else if( sdrev == AAPL_SDREV_PON )
                        esp->sbm_eye_gather = (cap & 0x2);  /* Basic V2 int 0x25 support */
                    else
                        esp->sbm_eye_gather = (cap & 0x1);  /* Basic D6 support. */
                }
            }
        }
    }

    if( aapl_get_ip_type(aapl, addr) == AVAGO_M4 && !configp->ec_no_sbm )
    {
        uint sbm_addr = avago_make_sbus_master_addr(addr);
        uint sbm_bld = aapl_get_firmware_build(aapl, sbm_addr);
        if( sbm_bld == 0x2001 ) /* Limit sbus master version. */
        {
            uint sbm_rev = aapl_get_firmware_rev(aapl, sbm_addr) & 0xff;
            if( sbm_rev >= 0x1C )
            {
                uint serdes_fw_rev = aapl_get_firmware_rev(aapl, addr);
                if( (serdes_fw_rev & 0xff) >= 0x52 )
                {
                    int cap = avago_spico_int(aapl, sbm_addr, SBM_INT, EYE_READ_CAP);    /* Confirm that firmware has support */
                    esp->sbm_eye_gather = (cap & 0x2);  /* Basic M4 support. */
                }
            }
        }
    }
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, 0, "SBM EYE GATHER = %s\n", aapl_bool_to_str(esp->sbm_eye_gather));
    esp->orig_data_qual = /* Save value for restoring after eye gather. */
    esp->dq = avago_serdes_get_data_qual(aapl, addr);
    esp->data_qual = esp->dq.d6_data_qual;
    if( esp->datap->ed_data_qual.d6_data_qual != AVAGO_SERDES_RX_DATA_QUAL_DEFAULT )
        esp->default_gather = FALSE;


    init_default_balance_and_density(aapl, addr, datap);

    return TRUE;
}

/* @brief Restores the SerDes to the "orig" cached state. */
static void restore_serdes_state(Eye_state_t *esp)
{
    Aapl_t *aapl = esp->aapl;
    uint    addr = esp->addr;

    avago_serdes_set_dac(aapl, addr, (esp->datap->ed_y_resolution - 1) / 2, /* get_errors = */ FALSE);
    eye_step_phase(esp, esp->datap->ed_x_center[0], /* get_errors = */ FALSE);
    avago_serdes_set_rx_test_clock(aapl, addr, esp->data_clock);    /* Don't use cached version case SBM is being used. */
    esp->curr_clock_is_test = FALSE;
    avago_serdes_set_rx_data_qual(aapl, addr, AVAGO_SERDES_RX_DATA_QUAL_UNLOCK);

    if( esp->datap->ed_cmp_mode == AVAGO_SERDES_RX_CMP_MODE_TEST_PATGEN )
        avago_serdes_set_rx_cmp_data(aapl, addr, esp->orig_cmp_data); /* Restore PRBS reseed on error. */

    avago_serdes_set_rx_cmp_mode(aapl, addr, esp->orig_cmp_mode);
    avago_serdes_get_errors(aapl, addr, AVAGO_LSB, TRUE);   /* Reset the error counter */

    if( esp->pd_pi )
        avago_serdes_enable_low_power_mode(aapl, addr, TRUE);   /* Also powers down PI. */
    else
        avago_serdes_power_down_phase_interpolator(aapl, addr); /* Always */

    /* Restore DFE tuning to previous state: */
    avago_serdes_dfe_resume(aapl, addr, esp->dfe_resume_status);
}

/* Determines if even and odd gathering is in play. */
static BOOL gather_separate_even_odd(const Avago_serdes_eye_data_t *datap)
{
    return datap->eye_count == 6;
}

/** @brief Returns middle of eye containing x_index. */
/** @details If separate even/odd gathering, then returns even or odd center.  Else overall center. */
static int get_eye_middle_x_index(const Avago_serdes_eye_data_t *datap, BOOL odd_gather)
{
    return datap->ed_x_points * (gather_separate_even_odd(datap) ? odd_gather ? 3 : 1 : 2) / 4; /* center odd, center even, center all */
}

/** @brief Calculates the gradient for a point which has */
/**        valid self, south and west data. */
/**        Skip points which are out of range or don't yet have data. */
static void calc_gradient_bit(Avago_serdes_eye_data_t *datap, uint x, uint y)
{
    uint x_points = gather_separate_even_odd(datap) ? datap->ed_x_points/2 : datap->ed_x_points;
    if( x > 0 && y > 0 && x < datap->ed_x_points && y < datap->ed_y_points && x != x_points )
    {
        bigint bits     = AVAGO_EYE_BITS_GET(*datap, x,   y  );
        bigint bits_s   = AVAGO_EYE_BITS_GET(*datap, x,   y-1);
        bigint bits_w   = AVAGO_EYE_BITS_GET(*datap, x-1, y  );
        if( bits > 0 && bits_s > 0 && bits_w > 0 )
        {
            bigint errors   = AVAGO_EYE_ERRORS_GET(*datap, x,   y  );
            bigint errors_s = AVAGO_EYE_ERRORS_GET(*datap, x,   y-1);
            bigint errors_w = AVAGO_EYE_ERRORS_GET(*datap, x-1, y  );
            float grad;
            bigint en, ew;
            if( bits == bits_s && bits == bits_w )
            {
                /* Avoid rounding errors when diffs are small: */
                /* Special case for denominators all the same. */
                en = errors - errors_s;
                ew = errors - errors_w;
            }
            else
            {
                /* Avoid rounding errors when diffs are small: */
                en = (errors * bits_s - errors_s * bits) / bits_s;
                ew = (errors * bits_w - errors_w * bits) / bits_w;
            }
            grad = (float)(2 * sqrt((double)(en*en + ew*ew)) / bits);
            AVAGO_EYE_GRAD_SET(*datap, x, y, grad);
        }
    }
    return;
}

/** @brief Update the gradient array from the current eye data. */
static void serdes_eye_calc_gradient(
    Avago_serdes_eye_data_t *datap) /**< [in,out] Eye data to act upon. */
{
    size_t bytes;
    uint x, y;

    /* Initialize the data, even if reusing: */
    bytes = datap->ed_x_points * datap->ed_y_points * sizeof(datap->ed_gradp[0]);
    memset((void *) datap->ed_gradp, 0, bytes);

    for( x = 1; x < datap->ed_x_points; x++ )
        for( y = 1; y < datap->ed_y_points; y++ )
            calc_gradient_bit(datap, x, y);
}

static void calc_qval_bit(Avago_serdes_eye_data_t *datap, uint x, uint y)
{
    if( x < datap->ed_x_points && y < datap->ed_y_points )
    {
        float qinv = 0;
        bigint bits = get_bits_column(datap, x)[y];
        if( bits > 0 )
        {
            bigint errs = get_errs_column(datap, x)[y];
            double BER = avago_calc_BER(errs, bits, datap->ed_dc_balance);
            qinv = (float)avago_qfuncinv(BER);
        }
        AVAGO_EYE_QVAL_SET(*datap, x, y, qinv);
    }
}

static int mod(int val, uint mod)
{
    if( val >= 0 ) return val % mod;
    return mod - (-val % mod);
}

/** @brief Converts x coordinate into milliUI. */
/** @return Returns milli-UI offset of x relative to the eye center. */
static double mui_from_index(const Avago_serdes_eye_data_t *datap, int x)
{
    int x_center_index = get_eye_middle_x_index(datap, x >= (int)datap->ed_x_points/2);
    int val = x - x_center_index;  /* translate relative to eye center */
    double mUI = (double) val * 1000.0 / datap->ed_x_resolution;    /* Convert to mUI */
    uint x_full_res = datap->ed_x_step * datap->ed_x_resolution;
    /*printf("points = %u; res = %u; x = %3d; x_center_index = %d; rel_val = %3d; mUI=%6.2f; \n", datap->ed_x_points, datap->ed_x_resolution, x, x_center_index, val, mUI); */

#if 1   /* Phase linearity corrections: */
    if( datap->ed_phase_table_len == 2 * x_full_res )   /* A quick sanity check on valid phase table */
    {
        int phase = datap->ed_x_min + x * datap->ed_x_step; /* Convert index into phase */

        /* Adjust mod_phase to the appropriate 128 step wide quadrant. */
        /*   In half rate (or slower) operation, we don't know which cycle */
        /*   the PI is in.  It can be 128 * n phase steps out of sync with that */
        /*   used for phase calibration.  So we align the center of the eye */
        /*   data with the center recorded in the phase calibration data. */
        int data_center = mod(datap->ed_x_min + x_center_index * datap->ed_x_step, 2 * x_full_res);
        int align = mod((int)datap->ed_phase_center - data_center + 64, 2 * x_full_res) / 128 * 128;

        int mod_phase = mod(phase + align, 2 * x_full_res);         /* Shift phase into correction range */
        int mod_center = mod(data_center + align, 2 * x_full_res);
        double mui_correction = datap->ed_phase_table[mod_phase];   /* Extract correction */

        double center_shift = ((double)mod_center - datap->ed_phase_center) * 1000.0 / x_full_res;
        double adjusted_mUI = mUI + mui_correction + center_shift;

      /*printf("x %3d => phase %3d + align %4d => initial_mUI %7.2f + correction[mod_phase=%3d] %6.2f + center_shift(%3d) %6.2f = final_mUI %7.2f\n", */
      /*            x, phase, align, mUI, mod_phase, mui_correction, mod_center, center_shift, adjusted_mUI); */
        mUI = adjusted_mUI;
      /*printf("center = %d, phase_center = %6.2f, x = %d, mUI = %6.2f\n", center, datap->ed_phase_center, x, mUI); */
    }
    /*else printf("ed_phase_table_len = %u, ed_x_resolution = %u\n", datap->ed_phase_table_len, datap->ed_x_resolution); */
#endif
    return mUI;
}

/** @brief Converts y coordinate into milliVolts. */
/** @return Returns milliVolt offset of y relative to the eye center. */
static double mv_from_index(
    const Avago_serdes_eye_data_t *datap, /**< [in] Eye data to act upon. */
    uint y_points,                        /**< [in] Array size, used only for finding the midpoint. */
    uint step,                            /**< [in] Array spacing in dac steps. */
    int y)                                /**< [in] Coordinate to convert to mV. */
{
    int y_mid = (y_points-1) / 2;
    double val = datap->ed_dac_scale * ((y - y_mid) * (int)step);
    /*printf("mv_from_index(%f,%u,%u,%d (%d)) -> %f\n",datap->ed_dac_scale,y_points,step,y,y-y_mid,val); */
    return val;
}

/* Convenience function for accessing the BER for a point: */
static double get_BER(const Avago_serdes_eye_data_t *datap, int x, int y, float density)
{
    const bigint *bits = get_bits_column(datap, x);
    const bigint *errs = get_errs_column(datap, x);
    return avago_calc_BER(errs[y], bits[y], density);
}

static void find_center_ui_edges(
    const Avago_serdes_eye_data_t *datap, /**< [in,out] Eye data to act upon. */
    uint data_row,                        /**< [in] Row to analyze */
    BOOL odd_gather,                      /**< [in] Hint. */
    uint *left,                           /**< [out] */
    uint *right)                          /**< [out] Range: [left..right] */
{
    if( datap->ed_x_points == 1 ) { *left = *right = 0; return; }
    if( datap->ed_x_points == 2 ) { *left = *right = odd_gather ? 1 : 0; return; }

    *left = (datap->ed_x_UI-1) * datap->ed_x_resolution / 2;
    if( odd_gather && gather_separate_even_odd(datap) )
        *left += datap->ed_x_points / 2;
    *right = *left + datap->ed_x_resolution;

    /* Blackhawk eyes are 63 points wide with resolution of 64.  Others are 2**n + 1 points wide. */
    if( datap->ed_x_points == 63 )  /* If Blackhawk */
        *right = *left + datap->ed_x_points - 1;

    /* If we have multiple UI, enable use of extra points in HBTC. */
    *left = *left > 3 ? *left - 3 : 0;
    if( datap->ed_x_points != 63 )  /* If not Blackhawk */
        *right = (*right <= datap->ed_x_UI * datap->ed_x_resolution - 3) ? (*right + 3) : (datap->ed_x_UI * datap->ed_x_resolution);
    /*printf("*left = %u, *right = %u\n", *left, *right); */

    if( AVAGO_EYE_BITS_GET(*datap,*left,data_row) <= 0 ||
        AVAGO_EYE_BITS_GET(*datap,*right,data_row) <= 0 )
    {
        /* Get here for WIDTH and SIZE gathers: */
        *left = *right = datap->ed_x_points / 2;
    }
}

/* Find centermost left and right indexes of a string of points with */
/*   non-zero errors, which should be the eye edges. */
static void find_horizontal_extrapolation_points(
    const Avago_serdes_eye_data_t *datap, /**< [in,out] Eye data to act upon. */
    uint data_row,                        /**< [in] Which data row index to analyze */
    BOOL odd_gather,                      /**< [in] Which eye to act upon. */
    uint *left,                           /**< [out] */
    uint *innerLeft,                      /**< [out] Range: [left..innerLeft] */
    uint *innerRight,                     /**< [out] */
    uint *right)                          /**< [out] Range: [innerRight..right] */
{
    int x_mid = get_eye_middle_x_index(datap, odd_gather);
    int x;
    bigint min_errors;

    if( x_mid < 2 )  /* If a height gather */
    {
        *left = *innerLeft = *innerRight = *right = x_mid;
        return;
    }
    find_center_ui_edges(datap, data_row, odd_gather, left, right);

    /* Find inner left point with errors > datap->ed_error_threshold: */
    *innerLeft = *left+3;
    min_errors = 0x7fffffff;
    for( x = *left+3; x < x_mid; x++ )
    {
        if( AVAGO_EYE_BITS_GET(*datap,x,data_row) > 0 )
        {
            bigint errors = AVAGO_EYE_ERRORS_GET(*datap,x,data_row);
            if( errors > datap->ed_error_threshold )
                *innerLeft = x;
            else
                break;
        }
    }

    /* Find inner right point with errors > datap->ed_error_threshold: */
    *innerRight = *right;
    min_errors = 0x7fffffff;
    for( x = *right-3; x > x_mid; x-- )
    {
        if( AVAGO_EYE_BITS_GET(*datap,x,data_row) > 0 )
        {
            bigint errors = AVAGO_EYE_ERRORS_GET(*datap,x,data_row);
            if( errors < min_errors )
            {
                min_errors = errors;
                if( errors > datap->ed_error_threshold )
                    *innerRight = x;
            }
        }
    }
    /*printf("Horizontal points[%u] = %u, %u, %u, %u\n", data_row, *left, *innerLeft, *innerRight, *right); */
}

/* Find centermost lower and upper indexes of a string of points with */
/*   non-zero errors, which should be the eye edges. */
static void find_vertical_extrapolation_points(
    const Avago_serdes_eye_data_t *datap, /**< [in,out] Eye data to act upon. */
    int column,                           /**< [in] Which data column index to analyze */
    int which,                            /**< [in] Which eye opening, 0=lower, 1=middle, 2=upper */
    uint *lower,                          /**< [out] */
    uint *innerLower,                     /**< [out] Range: [lower..innerLower] */
    uint *innerUpper,                     /**< [out] */
    uint *upper)                          /**< [out] Range: [innerUpper..upper] */
{
    uint y, y_mid;
    const bigint *bits = get_bits_column(datap, column);
    const bigint *errs = get_errs_column(datap, column);

    *lower = 0;
    *upper = (column < 0 ? datap->ed_y_mission_points : datap->ed_y_points) - 1;
    y_mid = (*upper + 1) / 2;

    if( column < 0 )    /* For mission columns -1 and -3, middle point is not sufficient: */
    {
#if 1
        y_mid = datap->ed_hbtc[-1-column].data_row;
        y_mid = y_mid * datap->ed_y_step + datap->ed_y_min;                   /* Convert from test array to dac coordinates */
        y_mid = (y_mid - datap->ed_y_mission_min) / datap->ed_y_mission_step; /* Convert from dac to mission array coordinates */
#else
        /* First, find vertical eye middle from which we look for lower and upper eye edges. */
        double ber_min = 1.0;
        for( y = *lower; y < *upper; y++ )
        {
            double ber;
            /* Skip points which have no data: */
            if( bits[y] <= 0 )
                continue;

            ber = 1.0 * errs[y] / bits[y];
            if( ber < ber_min )
            {
                y_mid = y + 1;
                ber_min = ber; /* Found a better starting point */
                if( errs[y] == 0 )
                    break;
            }
        }
#endif
        /*printf("column = %d, y_mid = %u\n", column, y_mid); */
    }
    else if( gather_separate_even_odd(datap) )
    {
        int odd = (column >= (int)datap->ed_x_points / 2) ? 1 : 0;
        if( which == 0 )
        {
            y_mid = datap->ed_hbtc[odd].data_row;
            *lower = 0;
            *upper = (y_mid + datap->ed_hbtc[2+odd].data_row) / 2;
        }
        else if( which == 1 )
        {
            y_mid = datap->ed_hbtc[2+odd].data_row;
            *lower = (y_mid + datap->ed_hbtc[0+odd].data_row) / 2;
            *upper = (y_mid + datap->ed_hbtc[4+odd].data_row) / 2;
        }
        else if( which == 2 )
        {
            y_mid = datap->ed_hbtc[4+odd].data_row;
            *lower = (y_mid + datap->ed_hbtc[2+odd].data_row) / 2;
            *upper = datap->ed_y_points-1;
        }
    }
    /* printf("%d: y_mid = %d, *lower = %d, *upper = %d\n", __LINE__, y_mid, *lower, *upper); */

    /* Find inner lower point with errors > datap->ed_error_threshold: */
    *innerLower = *lower;
    for( y = y_mid - 1; y_mid > 0 && y-- > *lower;         )
    {
        if( bits[y] > 0 && errs[y] > datap->ed_error_threshold )
        {
            *innerLower = y;
            break;
        }
    }

    /* Find inner upper point with errors > datap->ed_error_threshold: */
    *innerUpper = *upper;
    for( y = y_mid + 1; y_mid > 0 && y <= *upper; y++ )
    {
        if( bits[y] > 0 && errs[y] > datap->ed_error_threshold )
        {
            *innerUpper = y;
            break;
        }
    }
    /*printf("Vertical points[%d] = %u, %u, %u, %u\n", column, *lower, *innerLower, *innerUpper, *upper); */
}

#define LSR_POINTS (64)

/** @brief   Calculates the left and right mean where Q == 0. */
/** @details Updates BTC values in results. */
/**          Must call after get_horizontal_least_sqr(), which sets left and right index values. */
static void get_horizontal_means(
    const Avago_serdes_eye_data_t *datap, /**< [in] Eye data to act upon. */
    uint data_row,                        /**< [in] Row in datap to act upon. */
    BOOL odd_gather,                      /**< [in] Which eye to act upon. */
    float trans_density,                  /**< [in] Transition density to use for the calculations. */
    Avago_serdes_eye_hbtc_t *results)     /**< [out] Where partial results are stored. */
{
    Avago_least_sqr_point point, prev = {0.0, 0.0};
    int x;
    /* Blackhawk eyes are 63 points wide with resolution of 64.  Others are 65 points wide. */
    int half_ui    = datap->ed_x_points == 63 ? 31 : datap->ed_x_resolution / 2;
    int half_width = datap->ed_x_UI * half_ui;
    int center_index = get_eye_middle_x_index(datap, odd_gather);
    int left_edge_index = center_index - half_width;
    int right_edge_index = center_index + half_width;

    /* Left mean: */
    results->left_mean = mui_from_index(datap, center_index - half_ui);
    /*printf("for( x = %d; x >= %d; x-- )\n", results->left_index, left_edge_index); */
    for( x = results->left_index; x >= left_edge_index; x-- )
    {
        point.x = mui_from_index(datap, x);
        point.y = avago_qfuncinv(get_BER(datap, x, data_row, trans_density));
        /*printf("qval(%d, %6.2f) = %6.2f\n", x, point.x, point.y); */
        if( point.y < 0.0 )
        {
            results->left_mean = (float)avago_interpolate(&prev,&point);
            /*printf("left prevPoint=(%f,%f), myPoint=(%f,%f), mean = %f\n", prev.x,prev.y,point.x,point.y, results->left_mean); */
            break;
        }
        prev.x = point.x;
        prev.y = point.y;
    }

    results->right_mean = mui_from_index(datap, center_index + half_ui);
    /*printf("for( x = %d; x <= %d; x++ )\n", results->right_index, right_edge_index); */
    for( x = results->right_index; x <= right_edge_index; x++ )
    {
        point.x = mui_from_index(datap, x);
        point.y = avago_qfuncinv(get_BER(datap, x, data_row, trans_density));
        /*printf("qval(%d, %6.2f) = %6.2f\n", x, point.x, point.y); */
        if( point.y < 0.0 )
        {
            results->right_mean = (float)avago_interpolate(&prev,&point);
            /*printf("right prevPoint=(%f,%f), myPoint=(%f,%f), mean = %f\n", prev.x,prev.y,point.x,point.y, results->right_mean); */
            break;
        }
        prev.x = point.x;
        prev.y = point.y;
    }
}

/** @brief   Calculates least squares info for left and right sides of data row; */
/**          stores left and right index and point values into results. */
/** @details Also sets data_row field of results. */
/**          Does not update BTC info in results. */
static void get_horizontal_least_sqr(
    const Avago_serdes_eye_data_t *datap, /**< [in] Eye data to act upon. */
    uint data_row,                        /**< [in] Row in datap to act upon. */
    BOOL odd_gather,                      /**< [in] Which eye to act upon. */
    float trans_density,                  /**< [in] Transition density to use for the calculations. */
    Avago_serdes_eye_hbtc_t *results,     /**< [out] Where partial results are stored. */
    Avago_least_sqr_results *left_lsr,    /**< [out] Left side least squares fit. */
    Avago_least_sqr_results *right_lsr)   /**< [out] Right side least squares fit. */
{
    uint i, x, left, innerLeft, innerRight, right;
    Avago_least_sqr_point leftPoints[LSR_POINTS];
    Avago_least_sqr_point rightPoints[LSR_POINTS];
    double best_Rsqr = 0.0;
    uint  best_count = 0;

    find_horizontal_extrapolation_points(datap, data_row, odd_gather, &left, &innerLeft, &innerRight, &right);
    for( i = 0, x = innerLeft+1; i < AAPL_ARRAY_LENGTH(leftPoints) && x-- > left;     )
    {
        leftPoints[i].x = mui_from_index(datap,x);
        leftPoints[i].y = avago_qfuncinv(get_BER(datap,x,data_row,trans_density));

        if( ++i >= 3 )
        {
            avago_least_sqr(leftPoints, i, left_lsr);
            if( left_lsr->Rsqr >= best_Rsqr - 0.005 )
            {
                best_count = i;
                if( left_lsr->Rsqr > best_Rsqr )
                    best_Rsqr = left_lsr->Rsqr;
            }
            /*printf("left Rsqr(row %u, %u points) = %6.5f%s\n", data_row, i, left_lsr->Rsqr, best_count==i?"*":""); */
        }
    }
    avago_least_sqr(leftPoints, best_count, left_lsr);
    results->left_index = innerLeft;
    results->left_points = best_count;

    best_Rsqr = 0.0;
    best_count = 0;
    for( i = 0, x = innerRight; i < AAPL_ARRAY_LENGTH(rightPoints) && x <= right; x++ )
    {
        rightPoints[i].x = mui_from_index(datap,x);
        rightPoints[i].y = avago_qfuncinv(get_BER(datap,x,data_row,trans_density));

        if( ++i >= 3 )
        {
            avago_least_sqr(rightPoints, i, right_lsr);
            if( right_lsr->Rsqr >= best_Rsqr - 0.005 )
            {
                best_count = i;
                if( right_lsr->Rsqr >= best_Rsqr )
                    best_Rsqr = right_lsr->Rsqr;
            }
            /*printf("right Rsqr(row %u, %u points) = %6.5f%s\n", data_row, i, right_lsr->Rsqr, best_count==i?"*":""); */
        }
    }
    avago_least_sqr(rightPoints, best_count, right_lsr);
    results->right_index = innerRight;
    results->right_points = best_count;
    results->data_row = data_row;

#if 0
    printf("h points(row=%u) = %u, %u, %u, %u\n", data_row, left, innerLeft, innerRight, right);
    printf("left  Q = %7fx + %7f\n", left_lsr->slope * 1000, left_lsr->y_intercept);
    printf("right Q = %7fx + %7f\n", right_lsr->slope * 1000, right_lsr->y_intercept);
#endif

#if 0
    /* For dumping BTC data into csv file: */
    printf("left_mUI,left_Q\n");
    for( uint i = 0; i < results->left_points; i++ )
        printf("%.3f,%f\n",leftPoints[i].x,leftPoints[i].y);
    printf("right_mUI,right_Q\n");
    for( uint i = 0; i < results->right_points; i++ )
        printf("%.3f,%f\n",rightPoints[i].x,rightPoints[i].y);
#endif
#if 0
    printf("Row = %u\n",data_row);
    printf("%u left edge points: ", results->left_points);
    for( uint i = 0; i < results->left_points; i++ )
        printf(" (%.3f,%f)",leftPoints[i].x,leftPoints[i].y);
    printf("\n");
    printf("%u right edge points: ", results->right_points);
    for( uint i = 0; i < results->right_points; i++ )
        printf(" (%.3f,%f)",rightPoints[i].x,rightPoints[i].y);
    printf("\n");
#endif
}

/** @brief   Calculates least squares info for bottom and top eye edges in column; */
/**          stores top and bottom index and point values into results. */
/** @details Also sets data_column field of results. */
/**          Does not update BTC info in results. */
/** */
/**  For each column, extracts top and bottom points above threshold and in bounds. */
/**  Linear fits them to find the slope and intercept in Q space for both */
/**  bottom and top. */
static void get_vertical_least_sqr(
    const Avago_serdes_eye_data_t *datap, /**< [in] Eye data to act upon. */
    int which,                            /**< [in] Which PAM4 eye to analyze (0=lower, 1=middle, 2=upper) */
    int column,                           /**< [in] Column in datap to act upon. */
    Avago_serdes_eye_vbtc_t *results,     /**< [out] Where partial results are stored. */
    Avago_least_sqr_results *lower_lsr,   /**< [out] Bottom side least squares fit. */
    Avago_least_sqr_results *upper_lsr)   /**< [out] Top side least squares fit. */
{
    uint i, y, lower, inner_lower, inner_upper, upper;
    Avago_least_sqr_point lowerPoints[LSR_POINTS];
    Avago_least_sqr_point upperPoints[LSR_POINTS];
    int points = column < 0 ? datap->ed_y_mission_points : datap->ed_y_points;
    int step   = column < 0 ? datap->ed_y_mission_step   : datap->ed_y_step;
    double best_Rsqr = 0.0;
    uint  best_count = 0;

    find_vertical_extrapolation_points(datap, column, which, &lower, &inner_lower, &inner_upper, &upper);
    /*printf("%d: column=%d, which=%d, range_lower=%u..%u, range_upper=%u..%u\n", __LINE__, column, which, lower, inner_lower, inner_upper, upper); */
    for( i = 0, y = inner_lower; i < AAPL_ARRAY_LENGTH(lowerPoints) && y > lower; y-- )
    {
        double BER = get_BER(datap, column, y, datap->ed_dc_balance);
        if( BER >= 0.16 ) break;    /* Ignore Q values < 1.0 */

        lowerPoints[i].x = mv_from_index(datap, points, step, y);
        lowerPoints[i].y = avago_qfuncinv(BER);

        if( ++i >= 5 )
        {
            avago_least_sqr(lowerPoints, i, lower_lsr);
            if( lower_lsr->Rsqr >= best_Rsqr )
            {
                best_count = i;
                best_Rsqr = lower_lsr->Rsqr;
            }
          /*else if( lower_lsr->Rsqr >= best_Rsqr - 0.001 ) */
          /*    best_count = i; */
          /*printf("lower Rsqr(column %d, %u points) = %6.5f%s\n", column, i, lower_lsr->Rsqr, best_count==i?"*":""); */
        }
    }
    if( best_count == 0 )
        best_count = i;
    avago_least_sqr(lowerPoints, best_count, lower_lsr);
    results->bottom_index = inner_lower;
    results->bottom_points = best_count;

    best_Rsqr = 0.0;
    best_count = 0;

    for( i = 0, y = inner_upper; i < AAPL_ARRAY_LENGTH(upperPoints) && y <= upper; y++ )
    {
        double BER = get_BER(datap, column, y, datap->ed_dc_balance);
        if( BER >= 0.16 ) break;

        upperPoints[i].x = mv_from_index(datap, points, step, y);
        upperPoints[i].y = avago_qfuncinv(BER);

        if( ++i >= 5 )
        {
            avago_least_sqr(upperPoints, i, upper_lsr);
            if( upper_lsr->Rsqr >= best_Rsqr )
            {
                best_count = i;
                best_Rsqr = upper_lsr->Rsqr;
            }
          /*else if( upper_lsr->Rsqr >= best_Rsqr - 0.001 ) */
          /*    best_count = i; */
          /*printf("upper Rsqr(column %d, %u points) = %6.5f%s\n", column, i, upper_lsr->Rsqr, best_count==i?"*":""); */
        }
    }
    if( best_count == 0 )
        best_count = i;
    avago_least_sqr(upperPoints, best_count, upper_lsr);
    results->top_index = inner_upper;
    results->top_points = best_count;

#if 0
    printf("v points(col=%d) = %u, %u, %u, %u\n", column, lower, inner_lower, inner_upper, upper);
    printf("upperQ(%d) = %6.2fx + %6.2f mV/Q\n", column, 1.0 / upper_lsr->slope, upper_lsr->y_intercept);
    printf("lowerQ(%d) = %6.2fx + %6.2f mV/Q\n", column, 1.0 / lower_lsr->slope, lower_lsr->y_intercept);
    printf("column = %d, top/bottom_points = %u, %u\n", column, results->top_points, results->bottom_points);
#endif
#if 0
    printf("Top edge points (column = %d): ", column);
    for( i = 0; i < results->top_points; i++ )
        printf("(%f,%5.3f)",upperPoints[i].x,upperPoints[i].y);
    printf("\n");
    printf("Bottom edge points: ");
    for( i = 0; i < results->bottom_points; i++ )
        printf("(%f,%5.3f)",lowerPoints[i].x,lowerPoints[i].y);
    printf("\n");
#endif
}

/* For each row, extract left and right points above threshold and in bounds. */
/* Linear fit them to find the slope and intercept in Q space for each side. */
/* Extrapolate, from both sides, Q values for each point with zero errors. */
/* Choose min Q value for each point in line and save into qval array. */
static void extrapolate_horizontal_qvals(
    Avago_serdes_eye_data_t *datap) /**< [in,out] Eye data to act upon. */
{
    uint data_row;
    if( datap->ed_x_points < 8 ) return;    /* Can't run on height gathers. */
    for( data_row = 0; data_row < datap->ed_y_points; data_row++ )   /* For each row */
    {
        uint x;
        Avago_least_sqr_results left_lsr, right_lsr;
        Avago_serdes_eye_hbtc_t results;
        float trans_density = datap->ed_trans_density;
        int odd_gather;

        if( datap->eye_count == 6 )
        {
            uint lower_center_index = datap->ed_hbtc[0].data_row; /* + datap->ed_y_points / 2; */
            uint mid_center_index   = datap->ed_hbtc[2].data_row; /* + datap->ed_y_points / 2; */
            uint upper_center_index = datap->ed_hbtc[4].data_row; /* + datap->ed_y_points / 2; */
            uint upper_third = (mid_center_index + upper_center_index) / 2;
            uint lower_third = (mid_center_index + lower_center_index) / 2;
            if( data_row < upper_third && data_row > lower_third && fabsf(trans_density - DEF_TRANS_DENSITY_M4) < 0.01F )
                trans_density = DEF_TRANS_DENSITY_M4_MSB;
        }

        for( odd_gather = (gather_separate_even_odd(datap) ? 1 : 0); odd_gather >= 0; odd_gather-- )
        {
            get_horizontal_least_sqr(datap, data_row, odd_gather, trans_density, &results, &left_lsr, &right_lsr);
            /*printf("%d: data_row=%u; for( x = %u; x < %u; x++ ), trans_density = %f\n", __LINE__, data_row, results.left_index+1, results.right_index, trans_density); */
            for( x = results.left_index+1; x < results.right_index; x++ )
            {
                if( AVAGO_EYE_ERRORS_GET(*datap,x,data_row) == 0 )  /* Only update BER==0 locations */
                {
                    double x_val = mui_from_index(datap,x);
                    double qval_left  =  left_lsr.slope * x_val + left_lsr.y_intercept;
                    double qval_right = right_lsr.slope * x_val + right_lsr.y_intercept;
                    double qval       = MIN(qval_left, qval_right);
                    AVAGO_EYE_QVAL_SET(*datap, x, data_row, qval);
                    /*printf("hQval[%u, %u]: left, right = %7.4f, %7.4f, val = %7.4f\n", x, data_row, qval_left, qval_right, qval); */
                }
            }
        }
    }
    #if 0
    /* Verify that all values are updated: */
    for( data_row = 0; data_row < datap->ed_y_points; data_row++ )   /* For each row */
    {
        uint x;
        for( x = 0; x < datap->ed_x_points; x++ )
             if( AVAGO_EYE_QVAL_GET(*datap, x, data_row) == 0.0 )
                 printf("H extrapolation failed at %u, %u, qval = %f\n", x, data_row, AVAGO_EYE_QVAL_GET(*datap, x, data_row));
    }
    #endif
}

/* Extrapolate, from top and bottom, Q values for each point with 0 errors. */
/* Choose min Q value for each point. */
/* Convert to BER.  Convert value in qval array into BER and average them. */
/* Convert average into Q and update value in qval array. */
static void extrapolate_vertical_qvals(
    Avago_serdes_eye_data_t *datap) /**< [in,out] Eye data to act upon. */
{
    int which;

    for( which = 0; which < datap->eye_count; which++ )
    {
        uint left, right, column;

        find_center_ui_edges(datap, 0, which & 1, &left, &right);
        /*printf("%d: which = %d, left=%u, right = %u\n", __LINE__, which, left, right); */
        for( column = left; column <= right; column++ )   /* For each column */
        {
            uint y;
            Avago_serdes_eye_vbtc_t results;
            Avago_least_sqr_results lower_lsr, upper_lsr;

            get_vertical_least_sqr(datap, which/2, column, &results, &lower_lsr, &upper_lsr);
            /*printf("%d: which = %d, column = %u, bottom_index = %u, top_index = %u\n", __LINE__, which, column, results.bottom_index+1, results.top_index); */
            for( y = results.bottom_index+1; y < results.top_index; y++ )
            {
                if( AVAGO_EYE_ERRORS_GET(*datap,column,y) == 0 )  /* Only update 0 BER locations */
                {
                    double x_val = mv_from_index(datap, datap->ed_y_points, datap->ed_y_step, y);
                    double qval_lower = lower_lsr.slope * x_val + lower_lsr.y_intercept;
                    double qval_upper = upper_lsr.slope * x_val + upper_lsr.y_intercept;
                    double qval_v     = MIN(qval_lower, qval_upper);
                    double qval_h     = AVAGO_EYE_QVAL_GET(*datap, column, y);
#if 1               /* Combine horizontal and vertical values: */
                    double qval       = avago_qfuncinv((avago_qfunc(qval_v) + avago_qfunc(qval_h))/2.0);
#elif 1             /* Only save minimum of h & v values: */
                    double qval = MIN(qval_h, qval_v);
#else               /* Only save vertical value: */
                    double qval       = qval_v;
#endif
                    AVAGO_EYE_QVAL_SET(*datap, column, y, qval);
                }
            }
        }
    }
    /**< Save eye center Q value: */
    {
        int i;
        int combined_lsb_count = 0, combined_btc_count = 0;

        datap->ed_combined_btc_ber = datap->ed_combined_lsb_ber = 0.0;

        for( i = 0; i < datap->eye_count; i++ )
        {
            if( datap->ed_hbtc[i].data_row < datap->ed_y_points )
            {
                int center_x_index = get_eye_middle_x_index(datap, i & 1);
                float tmp_qval = AVAGO_EYE_QVAL_GET(*datap, center_x_index, datap->ed_hbtc[i].data_row);
                double ber = avago_qfunc(tmp_qval);

                datap->ed_combined_btc_ber += ber;
                combined_btc_count ++;

                if( datap->eye_count % 3 == 0 ) /* If PAM4 eyes: */
                {
                    if( (datap->eye_count == 6 && (i == 2 || i == 3)) || /* Double count the MSB BER as it determines twice the bits as each of the LSB samplers. */
                        (datap->eye_count == 3 && i == 1) )
                    {
                        datap->ed_combined_btc_ber += ber;
                        combined_btc_count ++;
                    }
                    else /* Only count outer PAM4 eyes for LSB. */
                    {
                        datap->ed_combined_lsb_ber += ber;
                        combined_lsb_count ++;
                    }
                }

                /*printf("BER[eye=%d] = %e, sum = %e\n", i, ber, datap->ed_combined_btc_ber); */
                /*printf("BER[eye=%d] = %e, sum = %e\n", i, ber, datap->ed_combined_lsb_ber); */
            }
        }
        if( combined_btc_count > 0 ) datap->ed_combined_btc_ber /= combined_btc_count;
        if( combined_lsb_count > 0 ) datap->ed_combined_lsb_ber /= combined_lsb_count;
        /*printf("Combined total BER = %.2e, combined lsb ber = %.2e\n", datap->ed_combined_btc_ber, datap->ed_combined_lsb_ber); */
    }
    datap->ed_combined_btc_qval = avago_qfuncinv(datap->ed_combined_btc_ber);
    datap->ed_combined_lsb_qval = avago_qfuncinv(datap->ed_combined_lsb_ber);
    if( datap->ed_combined_btc_qval > AVAGO_Q_CEILING )
    {
        datap->ed_combined_btc_qval = AVAGO_Q_CEILING;
        datap->ed_combined_btc_ber = avago_qfunc(datap->ed_combined_btc_qval);
    }
    if( datap->ed_combined_lsb_qval > AVAGO_Q_CEILING )
    {
        datap->ed_combined_lsb_qval = AVAGO_Q_CEILING;
        datap->ed_combined_lsb_ber = avago_qfunc(datap->ed_combined_lsb_qval);
    }
    /*printf("Combined total BER = %.2e, combined lsb ber = %.2e\n", datap->ed_combined_btc_ber, datap->ed_combined_lsb_ber); */
    /*printf("Combined total Qval = %.2f, combined lsb qval = %.2f\n", datap->ed_combined_btc_qval, datap->ed_combined_lsb_qval); */
}

static void serdes_eye_calc_qval(
    Aapl_t *aapl,                   /**< [in] */
    Avago_serdes_eye_data_t *datap) /**< [in,out] Eye data to act upon. */
{
    uint x, y;

    for( x = 0; x < datap->ed_x_points; x++ )
        for( y = 0; y < datap->ed_y_points; y++ )
            calc_qval_bit(datap, x, y);

    extrapolate_horizontal_qvals(datap); /* Replace 0 BER points with horizontal extrapolation */
    extrapolate_vertical_qvals(datap);   /* Replace 0 BER points with BER average of horizontal and vertical extrapolations */

    /* Write a high-resolution qval output for debugging purposes, but only if debug level is exactly 3: */
    if( (aapl->debug & 0xf) != AVAGO_DEBUG3 )
        return;

    for( y = datap->ed_y_points; y > 0;  )
    {
        y--;
        for( x = 0; x < datap->ed_x_points; x++ )
        {
            if( x == 0 )
                aapl_log_printf(aapl, AVAGO_DEBUG3, 0, 0, "%2u: %4.1f", y, AVAGO_EYE_QVAL_GET(*datap, x, y));
            else if( x == datap->ed_x_points / 2 )
                aapl_log_printf(aapl, AVAGO_DEBUG3, 0, 0, ",|%4.1f|", AVAGO_EYE_QVAL_GET(*datap, x, y));
            else
                aapl_log_printf(aapl, AVAGO_DEBUG3, 0, 0, ",%4.1f", AVAGO_EYE_QVAL_GET(*datap, x, y));
        }
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n");
    }
}

/** @brief   Updates the bits to dwell for a given eye point. */
/** @details Want to dwell enough to push errors above threshold without */
/**          wasting time getting it much above it. */
/**          Also caps total dwell at max_dwell bits. */
static BOOL update_dwell(Eye_state_t *esp, int x, uint y)
{
    /* TBD: Determine reasonable min_dwell dynamically at run-time. */
    bigint bits   = get_bits_column(esp->datap, x)[y];
    bigint errors = get_errs_column(esp->datap, x)[y];

    bigint new_dwell = esp->curr_dwell;
    if( new_dwell > bits )
        new_dwell = bits;
    if( errors <= esp->threshold / 100 )
        new_dwell *= 200;
    else if( errors <= esp->threshold / 20 )
        new_dwell *= 40;
    else if( errors <= esp->threshold / 5 )
        new_dwell *= 10;
    else if( errors <= esp->threshold * 2 / 3 )
        new_dwell *= 2;

    new_dwell = MAX(new_dwell, esp->datap->ed_min_dwell_bits);        /* Set minimum */
    new_dwell = MIN(new_dwell, esp->datap->ed_max_dwell_bits - bits); /* Cap total dwell */
    new_dwell = ((new_dwell+19) / 20) * 20;  /* Insure multiple of hw resolution */

    /* TBD: Dynamically modify the time out value based on dwell for more */
    /*      efficient eye gathering. Values up to 2e10 are supported by the hardware. */
    /*   To avoid time outs on 28nm for values greater than 1e8, */
    /*   it's necessary for serdes_set_error_timer to increase the */
    /*   timeout or accumulate at most 1e8 bits at a time. */
    /*   Be aware that some firmware (SBM, M4 HAL and PON at the moment) return */
    /*     floating point error counts, with a max representation of 134,201,344 */
    /*     so need to insure that returned error counts are below this. */

    if( esp->sbm_eye_gather )
        new_dwell = MIN(new_dwell, AVAGO_EYE_SBM_DWELL_MAX_BITS);   /* Hack until SBM code can be fixed. */
    else
        new_dwell = MIN(new_dwell, AVAGO_EYE_ONE_DWELL_MAX_BITS);
/*  new_dwell = MIN(new_dwell, 20000000000);    // 28nm D6 hardware limit */

    if( new_dwell == 0 )
    {
        esp->curr_dwell = 0;
        return TRUE;
    }
    if( eye_set_error_timer(esp, new_dwell) < 0 )
        return FALSE;
    aapl_log_printf(esp->aapl, AVAGO_DEBUG3, __func__, __LINE__, "update_dwell: x,y = %3d,%3u, errors,bits = %s,%s, new dwell = %s\n",
        x,y,
        aapl_bigint_to_str(errors),
        aapl_bigint_to_str(bits),
        aapl_bigint_to_str(esp->curr_dwell));
    return TRUE;
}

static BOOL sbm_eye_set_options(Eye_state_t *esp)
{
    Aapl_t *aapl = esp->aapl;
    uint addr = esp->addr;
    uint sbm_addr = avago_make_sbus_master_addr(addr);
    int options = 2;    /* External setting of compare mode and data qual (M4, P1, D6 in non-default gather mode). */
    int return_code = aapl->return_code;

    if( !esp->sbm_eye_gather )
        return TRUE;

    if( aapl_get_ip_type(aapl, addr) == AVAGO_SERDES )
    if( esp->default_gather && esp->datap->ed_apply_vert_alpha ) /* D6 default modes handled by SBM */
    {
        /* Only used for D6 default gathers: */
        /* 0==prev0/1 XOR, 1==prev0/1 Test-Patgen */
        options = (esp->datap->ed_cmp_mode == AVAGO_SERDES_RX_CMP_MODE_TEST_PATGEN) ? 1 : 0;
    }

    /* Check for V2 of eye gather interface: */
    if( aapl_get_interrupt_rev(aapl, addr, 0x25) == 2 )
    {
        int sdrev = aapl_get_sdrev(aapl, addr);
        if( sdrev == AAPL_SDREV_D6_07 )
        {
            options |= (1<<3);  /* Use external eye centering. */
            if( (options & 2) == 0 )  /* If D6 default gather */
                options |= (1<<6);    /* Invert vert-alpha corrections */
        }
        options |= 0x0010;  /* V2 of eye gather interface */
        if( aapl_get_sdrev(aapl, addr) == AAPL_SDREV_PON )
            options |= 0x0018;  /* V2 of eye gather, disable centering */
    }
    {
        /* Code for 16nm PCIe gen4 SerDes with Lane Margining hardware and associated firmware support: */
        int fw_rev   = aapl_get_firmware_rev(aapl, addr);
        int fw_eng   = avago_firmware_get_engineering_id(aapl, addr);
        int fw_build = aapl_get_firmware_build(aapl, addr);
        BOOL is_newer_16nm_pcie = fw_build == 0x2347 && ((fw_rev&0xff) > 0x83 || ((fw_rev&0xff) == 0x83 && fw_eng >= 2) || ((fw_rev&0xff) == 0x80 && fw_eng >= 0x50));
        if( is_newer_16nm_pcie )
        {
            options |= (1<<3);  /* Use external eye centering. */
            if( (options & 2) == 0 )  /* If D6 default gather */
                options |= (1<<6);    /* Invert vert-alpha corrections */
        }
    }
    if( esp->configp->ec_centering_options & 1 )
        options &= ~(1<<3); /* Ignore HW centering and center ourselves. */


    if( esp->enable_not_errors )
        options |= (1<<5);    /* Return min of errors and (bits-errors).  Used for column comparisons. */

    avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_OPTIONS    | (0x7ff & options));

    return return_code == aapl->return_code;
}

/** @brief Converts FW floating point error count into integer. */
static uint error_float_to_int(uint e)
{
    if( e == 0xffff ) return 4000000000U;    /* A large value, obviously wrong. */
    if( e & 0xe000 )
        e = (0x1000 | (e & 0x0fff)) << (((e >> 12) & 0x0f) - 1);
    else
        e &= 0x1fff;
    return e;
}

/* Internal function to gather row, column or single point error counts */
/* from the SBus Master eye output registers. */
/* Data is accumulated into the eye data structure. */
/* Note: step is always 1 except for row gathers. */
/** @return  On success, returns TRUE. */
/** @return  On error, decrements aapl->return_code and returns FALSE. */
static BOOL sbm_eye_gather_data(
    Eye_state_t *esp,   /**< [in] Eye state info */
    uint int_data,      /**< [in] Tell SBM type of eye gather */
    bigint *bits,       /**< [in] First location for saving bit counts */
    bigint *errors,     /**< [in] First location for saving error results */
    uint   step,        /**< [in] Offset for saving next result */
    uint   points)      /**< [in] Number of points to read */
{
    Aapl_t *aapl = esp->aapl;
    int return_code = aapl->return_code;
    uint sbm_addr = avago_make_sbus_master_addr(esp->addr);
    uint sbc_addr = avago_make_sbus_controller_addr(esp->addr);
    uint index, stop_index = points * step, read_index = 1;
    uint last_read = 0, rep_count = 0;

    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Points = %u, current_dwell = %s\n", points, aapl_bigint_to_str(esp->curr_dwell));
    /* Setup handshaking: */
    avago_sbus_wr(aapl, sbc_addr, 0x11, read_index);    /* Start read from beginning */
    avago_sbus_wr(aapl, sbc_addr, 0x12, 0);             /* Indicate no data available */
    avago_spico_int(aapl, sbm_addr, SBM_INT, int_data); /* Start data gathering */

    for( index = 0; index < stop_index;     )
    {
        unsigned char reg_addrs[] = { 0x12, 0x13, 0x16 };
        uint avail = 0, err_reg[3];
        uint loop_count = 0;
        const uint max_loop_count = aapl->serdes_int_timeout;
        uint errs[4];

        avago_sbus_wr(aapl, sbc_addr, 0x11, read_index);
        while( loop_count++ < max_loop_count )
        {
            /* Read all sbus registers in one TCP round-trip when using AACS. */
            avago_sbus_rd_array(aapl, sbc_addr, 3, reg_addrs, err_reg);
            avail = err_reg[0];
            if( avail >= read_index )
                break;
            /* if( aapl->debug & 0x100 ) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "avail = %u, expected >= %u\n", avail, read_index); */
            if( loop_count >= 50 )
                ms_sleep(loop_count >= 250 ? 10 : 1); /* Want to be sure we wait long enough... */
        }
        if( loop_count > 2 && aapl->debug & 0x100 ) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "loop_count = %u\n", loop_count);
        if( loop_count >= max_loop_count )
        {
            aapl_fail(aapl, __func__,__LINE__,"Timeout waiting for SBM eye data.\n");
            return FALSE;
        }

        if( (aapl->debug & 0x100) && (aapl->debug & 0xf) > AVAGO_DEBUG2 )
        {
            uint av = avail * 4;
            BOOL do_log = FALSE;
            /*aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Last read = %2u, curr_read = %2u, rep_count = %u\n", last_read, av-index, rep_count); */
            if( last_read == av - index )
            {
                do_log = av >= stop_index;
                rep_count++;
            }
            else
            {
                do_log = rep_count > 0;
            }
            if( do_log )
                aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "int_data = %x, read %2u entries x %3u = %3u\n", int_data, last_read, rep_count, last_read * rep_count);
            if( last_read != av - index ) rep_count = 1;
            last_read = av - index;
        }
        esp->timeout_count += err_reg[1]>>16 == 0xffff;
        if( bits ) bits[index] += esp->curr_dwell;
        errs[0] = error_float_to_int(err_reg[1] >> 16);
        errors[index] += errs[0];
        index += step;
        if( index < stop_index )
        {
            esp->timeout_count += (err_reg[1] & 0xffff) == 0xffff;
            if( bits ) bits[index] += esp->curr_dwell;
            errs[1] = error_float_to_int(err_reg[1]);
            errors[index] += errs[1];
            index += step;
            if( index < stop_index )
            {
                esp->timeout_count += err_reg[2]>>16 == 0xffff;
                if( bits ) bits[index] += esp->curr_dwell;
                errs[2] = error_float_to_int(err_reg[2] >> 16);
                errors[index] += errs[2];
                index += step;
                if( index < stop_index )
                {
                    esp->timeout_count += (err_reg[2] & 0xffff) == 0xffff;
                    if( bits ) bits[index] += esp->curr_dwell;
                    errs[3] = error_float_to_int(err_reg[2]);
                    errors[index] += errs[3];
                    index += step;
                }
            }
        }

        /* Handle repeating values: */
        while( avail*4*step > index && index < stop_index )
        {
            /*printf("avail = %2u, stop = %u, errors[%2u] = %s, errs[%d] = %u\n", avail, stop_index, index, aapl_bigint_to_str(errors[index]),index%4,errs[index%4]); */
            if( bits ) bits[index] += esp->curr_dwell;
            errors[index] += errs[index%4];
            index += step;
        }

        /* Request more data: */
        read_index = avail + 1;
    }
    return return_code == aapl->return_code;
}


static int sbm_adjust_dac(Eye_state_t *esp, int dac)
{
    if( aapl_get_ip_type(esp->aapl, esp->addr) == AVAGO_SERDES )
    {
     /* dac++;  // Pushes both level means down */
     /* dac--;  // Pushes both level means up */
        if( !aapl_check_firmware_rev(esp->aapl, esp->addr, 0, 0, FALSE, 1, 0x1065) )
            dac -= 2;
    }
    return dac;
}
/** @return  On success, returns TRUE. */
/** @return  On error, decrements aapl->return_code and returns FALSE. */
static BOOL sbm_set_dac_start(Eye_state_t *esp, const char *func, int line, int dac)
{
    uint sbm_addr = avago_make_sbus_master_addr(esp->addr);
    dac = sbm_adjust_dac(esp, dac);
    return avago_spico_int_check(esp->aapl, func, line, sbm_addr, SBM_INT, EYE_SET_START  | (dac & 0x7ff));
}

/** @brief   Performs once-per-eye device configuration. */
/** @details Configures values that need be set only once per eye gather. */
/** @return  Returns TRUE on success. */
static BOOL sbm_eye_setup_serdes(Eye_state_t *esp)
{
    Aapl_t *aapl = esp->aapl;
    uint addr = esp->addr;
    uint sbm_addr = avago_make_sbus_master_addr(addr);
    int return_code = aapl->return_code;
    uint fw_build = aapl_get_firmware_build(aapl, addr);
    bigint xx;
    if( !esp->sbm_eye_gather )
        return TRUE;

    AAPL_LOG_PRINT2(aapl, AVAGO_DEBUG2, __func__, __LINE__, "SerDes FW: 0x%04X_%04X  SBM FW: 0x%04X_%04X\n",
        aapl_get_firmware_rev(aapl,addr),
        fw_build,
        aapl_get_firmware_rev(aapl,sbm_addr),
        aapl_get_firmware_build(aapl,sbm_addr));

    avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_ADDR       | (0x0ff & addr));
    avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_RESOLUTION | (0x7ff & esp->phase_mult));
    sbm_eye_set_options(esp);

    /* Now that options are set, and before we change them later, */
    /* do a gather to force SBM vert-alpha and centering initialization. */
    sbm_set_dac_start(esp, __func__, __LINE__, 0);
    avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_POINTS | (1 & 0x7ff));
    avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_STEP   | (1 & 0x7ff));
    eye_set_compare_mode(esp, AVAGO_SERDES_RX_CMP_MODE_XOR);
    eye_set_data_qual_str(esp, "xxx,msb");
    sbm_eye_gather_data(esp, EYE_GATHER_MISSION, &xx, &xx, 1, 1);
    esp->datap->ed_x_sbm_center = (short)avago_spico_int(aapl, sbm_addr, SBM_INT, EYE_READ_CENTER);
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "SBM center: %hd\n", esp->datap->ed_x_sbm_center);

    /* Log the SBM phase center location: */
#   define AAPL_CENTER_PHASE_BUFLEN 40
    if( esp->datap->ed_phase_center_log ) aapl_free(aapl,esp->datap->ed_phase_center_log,"ed_phase_center_log");
    esp->datap->ed_phase_center_log = (char *)aapl_malloc(aapl, AAPL_CENTER_PHASE_BUFLEN, "sbm phase center");
    if( esp->datap->ed_phase_center_log )
        snprintf(esp->datap->ed_phase_center_log, AAPL_CENTER_PHASE_BUFLEN, "SBM center at phase %d", esp->datap->ed_x_sbm_center);

    return return_code == aapl->return_code;
}

/** @brief   Configures SBM for a column eye gather. */
/** @details The column parameter says the type of column. */
/**          - column < 0 means setup for mission data column */
/**          - column >= 0 means setup for test channel column */
static BOOL sbm_eye_setup_column(Eye_state_t *esp, int column)
{
    Aapl_t *aapl = esp->aapl;
    int return_code = aapl->return_code;
    uint sbm_addr = avago_make_sbus_master_addr(esp->addr);

    uint y_points, y_step;
    int  y_start;

    if( aapl_get_async_cancel_flag(aapl) ) return FALSE;

    if( column < 0 )    /* Mission data setup */
    {
        y_points  = esp->datap->ed_y_mission_points;
        y_step  = esp->datap->ed_y_mission_step;
        y_start = esp->datap->ed_y_mission_min;
    }
    else                /* Test channel setup */
    {
        y_points  = esp->datap->ed_y_points;
        y_step  = esp->datap->ed_y_step;
        y_start  = esp->datap->ed_y_min;
    }
    y_start -= (esp->datap->ed_y_resolution - 1 ) / 2;  /* Change to zero-center coordinates */
    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Points = %u; Start = %d, Step = %u, Column = %d\n", y_points, y_start, y_step, column);

    sbm_set_dac_start(esp, __func__, __LINE__, y_start);
    avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_POINTS | (y_points & 0x7ff));
    avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_STEP   | (y_step   & 0x7ff));
    return return_code == aapl->return_code;
}

/** @brief Configures SBM for a gather of a single point. */
/**        Note: The row and column are specified later. */
static BOOL sbm_eye_setup_point(Eye_state_t *esp)
{
    if( esp->sbm_eye_gather )
    {
        Aapl_t *aapl = esp->aapl;
        uint sbm_addr = avago_make_sbus_master_addr(esp->addr);
        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "\n");
        return !aapl_get_async_cancel_flag(esp->aapl)
            && avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_POINTS | 1);
    }
    return TRUE;
}

/* Calculate the actual phase location for a given eye array index. */
/* Value is in absolute terms, not relative to eye center. */
static int get_phase_for_x_index(Eye_state_t *esp, int x_index, int which)
{
    Avago_serdes_eye_data_t *datap = esp->datap;

    /* If even/odd eyes and index is on odd half, return phase for equivalent even half. */
    if( gather_separate_even_odd(datap) && x_index >= (int)datap->ed_x_points / 2 )
        x_index -= datap->ed_x_points / 2;

    return datap->ed_x_center[which] + (x_index - datap->ed_x_UI * datap->ed_x_resolution / 2) * datap->ed_x_step;
}

/* Calculate the dac setting for a given eye array index. */
/* Value assumes 0 V = dac 0. */
static int get_dac_for_y_index(const Avago_serdes_eye_data_t *datap, int y_index, BOOL mission)
{
    if( mission )
        return datap->ed_y_mission_min + y_index * datap->ed_y_mission_step;
    else
        return datap->ed_y_min + y_index * datap->ed_y_step;
}

/* Setup and gather the selected column. */
/* Columns are data array indexes for test, and -1 for mission. */
/* Data is accumulated into the eye data structure. */
static BOOL sbm_eye_gather_column(
    Eye_state_t *esp,   /* Eye state info */
    int x_index,        /* Data column to gather */
    uint y_begin,       /* First y index to store data. Usually 0. */
    uint y_end)         /* One past last y index to store data. */
{
    BOOL result;
    uint int_data;
    bigint *bits = (bigint *)get_bits_column(esp->datap, x_index) + y_begin;
    bigint *errs = (bigint *)get_errs_column(esp->datap, x_index) + y_begin;

    if( x_index < 0 )
    {
        int_data = EYE_GATHER_MISSION;
    }
    else
    {
        int sbm_phase = get_phase_for_x_index(esp, x_index, 0);
        int_data = EYE_GATHER_COLUMN | (sbm_phase & 0x7ff);
    }
    aapl_log_printf(esp->aapl, AVAGO_DEBUG2, __func__, __LINE__, "Column = %d, points = %u, int_data = 0x%x\n", x_index, y_end - y_begin, int_data);
    result = sbm_eye_gather_data(esp, int_data, bits, errs, 1, y_end - y_begin);
    if (esp->datap->ed_gather_mean && esp->datap->ed_mean_direction == 1)
    {
        /* need to reverse gathered column since SBM column gather inverted dac */
        uint i, count, total;

        total = y_end - y_begin;
        count = total/2;
        for (i = 0; i < count; i++)
        {
            bigint temp;
            temp = bits[i]; bits[i] = bits[total-1-i]; bits[total-1-i] = temp;
            temp = errs[i]; errs[i] = errs[total-1-i]; errs[total-1-i] = temp;
        }
    }
    return result;
}

/* Setup and gather all test columns */
/* Data is accumulated into the eye data structure. */
static BOOL sbm_eye_gather_nrz(Eye_state_t *esp)
{
    BOOL status = sbm_eye_setup_column(esp, 0);
    uint i;
    uint sbm_addr = 0;
    int options = 0;

    /* set for gather mean eye */
    if( esp->datap->ed_gather_mean )
    {
        int value;
        bigint thresh;
        sbm_addr = avago_make_sbus_master_addr(esp->addr);
        options = avago_spico_int(esp->aapl, sbm_addr, SBM_INT, EYE_READ_OPTIONS);

        if (esp->datap->ed_mean_direction > 0)
        {
            options &= (0x0003 << 9);
            options |= (esp->datap->ed_mean_direction << 9);
        }

        avago_spico_int_check(esp->aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_OPTIONS | (0x7ff & (options | 0x0100)));

#if 0
/* I think Ricks argument for threshold is incorrect, and Brian is correct */
        /* assume all samples are same */
        /* assume qualified pattern, so samples is 1/2 possible, */
        /* and we want 50% point or 1/2, so divide bits by 4 */
        thresh = (esp->datap->ed_min_dwell_bits) / 4;

        /* check if PAM4 and adjust threshold */
        if( aapl_get_ip_type(esp->aapl, esp->addr) == AVAGO_M4 )
        {
            if( avago_serdes_get_tx_line_encoding(esp->aapl, esp->addr) )
            {
                /* assume all samples are same */
                /* assume qualified pattern, so samples is 1/8 possible, */
                /* and we want 50% point or 1/2, so divide bits by 16 */
                thresh = (esp->datap->ed_min_dwell_bits) / 16;
            }
        }
#endif

        /* assume all samples are same */
        /* assume qualified pattern, so samples is 1/8 possible, */
        /* and we want 50% point or 1/2, so divide bits by 16 */
        thresh = (esp->datap->ed_min_dwell_bits) / 16;

        /* check for override */
        if (esp->datap->ed_mean_threshold > 0)
            thresh = esp->datap->ed_mean_threshold;

        aapl_log_printf(esp->aapl,AVAGO_INFO,0,0,"Mean Eye Threshold: %s\n", aapl_bigint_to_str(thresh));

        value = thresh & 0x000000ff;
        avago_spico_int_check(esp->aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_THRESH  | ((0<<8) | value));
        value = (thresh & 0x0000ff00) >>  8;
        avago_spico_int_check(esp->aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_THRESH  | ((1<<8) | value));
        value = (thresh & 0x00ff0000) >> 16;
        avago_spico_int_check(esp->aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_THRESH  | ((2<<8) | value));
        value = (thresh & 0xff000000) >> 24;
        avago_spico_int_check(esp->aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_THRESH  | ((3<<8) | value));
    }

    for( i = 0; status && i < esp->datap->ed_x_points; i++ )
    {
        status &= sbm_eye_gather_column(esp, i, 0, esp->datap->ed_y_points);
        if( aapl_get_async_cancel_flag(esp->aapl) ) return FALSE;
    }

    /* restore from gather mean eye */
    if( esp->datap->ed_gather_mean ) {
        avago_spico_int_check(esp->aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_OPTIONS | (0x7ff & options));
    }

    return status;
}

/** @brief   Gather column using configured dwell, data_qual and cmp_mode. */
/** @details Works OK on SBM/direct, Mission/Test */
/**          NOTE: Does not do prev0/prev1 gathers. */
/**          Set dwell, data_qual and cmp_mode before calling. */
/** @return  On success, returns TRUE. */
/** @return  On error, decrements aapl->return_code and returns FALSE. */
static BOOL gather_column_x(
    Eye_state_t *esp,
    BOOL mission,                        /**< Mission/phase clock */
    int phase,                           /**< Phase location of column */
    int dac_start,                       /**< First absolute DAC value for error reading */
    int dac_step,                        /**< Increment */
    int dac_end,                         /**< Just past last DAC value */
    bigint *errs,                        /**< Where to record error counts */
    bigint *bits)                        /**< Where to record bit counts */
{
    Aapl_t *aapl = esp->aapl;
    BOOL status = FALSE;

    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__,__LINE__, "mission %s; phase %d; dac {%d..%d..%d}, sbm_phase = %d, sbm_center = %d\n",
        aapl_bool_to_str(mission), phase, dac_start, dac_end, dac_step, phase, esp->datap->ed_x_sbm_center);

    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__,__LINE__, "dq = %s\n", aapl_data_qual_to_str(esp->dq));
    if( !esp->sbm_eye_gather )
    {
        int return_code = aapl->return_code;
        int dac, index;

        if( !eye_set_clock_source(esp, /* test_clock = */ !mission) )
            return FALSE;
        if( !mission && eye_step_phase(esp, phase, /* get_errors = */ FALSE) < 0 )
            return FALSE;

        for( dac = dac_start, index = 0; dac < dac_end; dac += dac_step, index++ )
        {
            int errors = eye_set_dac(esp, dac);
            errs[index] += errors;
            if( bits ) bits[index] += esp->curr_dwell;
        }
        return return_code == aapl->return_code;
    }

    {
        int col_len = (dac_end - dac_start) / dac_step;
        int sbm_phase = phase;
        uint int_data = (mission ? EYE_GATHER_MISSION : (EYE_GATHER_COLUMN | (sbm_phase & 0x7ff)));
        uint sbm_addr = avago_make_sbus_master_addr(esp->addr);
/*      printf("%d, col_len = %d, dac start/step/end = %d/%d/%d\n", __LINE__, col_len, dac_start, dac_step, dac_end); */
        dac_start -= (esp->datap->ed_y_resolution - 1) / 2; /* Change coordinates to 0 == middle of dac */
        sbm_set_dac_start(esp, __func__, __LINE__, dac_start);
        avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_POINTS | (0x7ff & col_len));
        avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_STEP   | (0x7ff & dac_step));
/*      sbm_eye_set_options(esp); */
        status = sbm_eye_gather_data(esp, int_data, bits, errs, 1, col_len);
    }
    return status;
}

 /** @brief   Updates the test channel delay. */
 /** @details Caches value to avoid no-op writes. */
static void eye_set_delay(Eye_state_t *esp, int index, int delay)
{
    if( index == 11 )   /* Test odd */
    {
        if( delay == esp->datap->delay[7] )
            return; /* Already set */
        esp->datap->delay[7] = delay;
    }
    else if( index == 12 ) /* Test even */
    {
        if( delay == esp->datap->delay[6] )
            return; /* Already set */
        esp->datap->delay[6] = delay;
    }
    else
        return; /* No action. */
    /*printf("Apply delay %d to HAL index %d.\n", delay, index); */
    avago_serdes_hal_set(esp->aapl, esp->addr, AVAGO_HAL_RXCLK_SELECT, index, delay);
    avago_serdes_hal_func(esp->aapl, esp->addr, AVAGO_HAL_RXCLK_VERNIER_APPLY);
}


static BOOL gather_column(
    Eye_state_t *esp,
    int which,
    BOOL mission,           /**< Mission/phase clock */
    int phase,              /**< Phase location of column */
    int dac_start,          /**< First DAC to read */
    int dac_step,           /**< Increment */
    int dac_end,            /**< Just past last DAC */
    bigint *errs,           /**< Where to record error counts */
    bigint *bits,           /**< Where to record bit counts */
    const char *dq_lower,   /**< Lower column data qual */
    const char *dq_upper)   /**< Upper column data qual */
{
    if( dq_lower == dq_upper ) /* Used for new comparator (NRZ and PAM4): */
    {
        Gather_info_t gather_info;

        init_gather_info(esp, which, &gather_info); /* Get eye specific delay values */

        if( gather_info.h_index[0] >= 0 )
            eye_set_delay(esp, gather_info.h_index[0], gather_info.h_delay[0]);

        eye_set_data_qual_str(esp, dq_lower);
        return gather_column_x(esp, mission, phase, dac_start, dac_step, dac_end, errs, bits);
    }
    else    /* Used for 28nm D6 with old comparator: */
    {
        int dac_mid = (dac_end + dac_start) / 2;
        int half = dac_mid - dac_start;

        eye_set_data_qual_str(esp, dq_lower);
        gather_column_x(esp, mission, phase, dac_start, dac_step, dac_mid, errs, bits);

        eye_set_data_qual_str(esp, dq_upper);
        return gather_column_x(esp, mission, phase, dac_mid, dac_step, dac_end, errs+half, bits+half);
    }
}

static uint find_m4_eye_center_offset(Eye_state_t *esp, int which)
{
    /* which: 0 == lower_e,  1 == lower_o, */
    /*        2 == middle_e, 3 == middle_o, */
    /*        4 == upper_e,  5 == upper_o */
    return ((short *)&esp->datap->inputs)[which];
}

/* Read row from firmware */
static uint find_tune_row(Eye_state_t *esp, int which)
{
    int ret = find_m4_eye_center_offset(esp, which);
    int row = aapl_iround((double)ret / esp->datap->ed_y_step) + (esp->datap->ed_y_points-1) / 2;

    /* Bound output in case user has requested too small an interval: */
    if( row < 0 )
        row = 0;
    else if( row >= (int)esp->datap->ed_y_points )
        row = esp->datap->ed_y_points - 1;

    aapl_log_printf(esp->aapl, AVAGO_DEBUG2, __func__, __LINE__, "vertical eye_center[%d] = %4d, y index = %4d\n",which,ret,row);
    return row;
}



/** @brief   Gathers eye column. */
/** @return  On success, returns TRUE. */
/** @return  On error, decrements aapl->return_code and returns FALSE. */
static BOOL eye_gather_column_x(
    Eye_state_t *esp,
    int phase,
    int which,
    int x_index,
    int y_begin,
    int y_end)  /* range y_begin..y_end-1 (excludes y_end) */
{
    BOOL status = TRUE;
    Gather_info_t gather_info;
    BOOL mission = x_index < 0;
    Avago_serdes_eye_data_t *datap = esp->datap;
    int i, gi_index;
    int dac_start = 0, dac_end = 0;
    int dac_step  = mission ? datap->ed_y_mission_step : datap->ed_y_step;
    bigint *bits = (bigint *)get_bits_column(datap, x_index);
    bigint *errs = (bigint *)get_errs_column(datap, x_index);

    /*printf("%d: eye_gather_column_x(esp, which %d, x_index %d, y_begin %d, y_end %d)\n", __LINE__, which, x_index, y_begin,  y_end); */
    init_gather_info(esp, which, &gather_info);

    /* Bound the range based on even/odd channel offsets: */
    for( i = 0; i < gather_info.entries; i++ )
    {
        while( (dac_start = get_dac_for_y_index(datap, y_begin, mission)) + gather_info.v_offset[i] < 0 )
            y_begin++;
        while( (dac_end = get_dac_for_y_index(datap, y_end-1, mission)) + gather_info.v_offset[i] >= (int)datap->ed_y_resolution )
            y_end--;
    }
    dac_end = get_dac_for_y_index(datap, y_end, mission);
    bits += y_begin;
    errs += y_begin;
    /*printf("Gather range: y_indices: [%d..%d), dac [%d..%d)\n", y_begin, y_end, dac_start, dac_end); */

    /* GATHER LOOP for column: */
    /* For each data qualification pattern in gather_info: */
    esp->gather_reverse = !esp->gather_reverse;
    for( gi_index = 0; gi_index < gather_info.entries && status; gi_index++ )
    {
        int i = esp->gather_reverse ? gather_info.entries - 1 - gi_index : gi_index;

        /* Configure for column gather: */
        eye_select(esp, gather_info.eye[i]);

        if( gather_info.h_index[i] >= 0 )
            eye_set_delay(esp, gather_info.h_index[i], gather_info.h_delay[i]);

        status &= gather_column_x(esp, mission, phase, dac_start + gather_info.v_offset[i], dac_step, dac_end + gather_info.v_offset[i], errs, bits);
        bits = 0;  /* Only accumulate on first gather in set. */
    }
    return status;
}

static void eye_get_pam4_y_levels(Eye_state_t *esp, BOOL gather_odd, int *y_level)
{
    Avago_serdes_eye_data_t *datap = esp->datap;
    int odd = gather_odd?1:0;
    uint lower_center_index = datap->ed_hbtc[0+odd].data_row;
    uint mid_center_index   = datap->ed_hbtc[2+odd].data_row;
    uint upper_center_index = datap->ed_hbtc[4+odd].data_row;

    y_level[0] = 0;
    y_level[1] = MIN(datap->ed_y_points, (lower_center_index + mid_center_index) / 2);
    y_level[2] = MIN(datap->ed_y_points, (upper_center_index + mid_center_index) / 2);
    y_level[3] = datap->ed_y_points;
    /*printf("LEVELS odd=%d: %d, %d, %d, %d\n", odd, y_level[0], y_level[1], y_level[2], y_level[3]); */
}

/** @brief   Gathers PAM4 non-mission column direct or through SBM. */
/** @details Used for default data qual full, height and size eye gathers. */
/** @return  On success, returns TRUE. */
/** @return  On error, decrements aapl->return_code and returns FALSE. */
static BOOL eye_gather_pam4_column(Eye_state_t *esp, int x_index)
{
    int return_code = aapl_get_return_code(esp->aapl);
    Avago_serdes_eye_data_t *datap = esp->datap;
    BOOL status = TRUE;

    if( x_index < 0 )
    {
        /* Do full resolution mission gather: */
        status &= eye_gather_column_x(esp, 0, 0, -1, 0                       ,datap->ed_y_resolution/2  );
        status &= eye_gather_column_x(esp, 0, 1, -2, 0                       ,datap->ed_y_resolution/2  );
        status &= eye_gather_column_x(esp, 0, 2, -3, datap->ed_y_resolution/4,datap->ed_y_resolution*3/4);
        status &= eye_gather_column_x(esp, 0, 3, -4, datap->ed_y_resolution/4,datap->ed_y_resolution*3/4);
        status &= eye_gather_column_x(esp, 0, 4, -5, datap->ed_y_resolution/2,datap->ed_y_resolution    );
        status &= eye_gather_column_x(esp, 0, 5, -6, datap->ed_y_resolution/2,datap->ed_y_resolution    );
    }
    else
    {
        /* Do requested resolution non-mission column gather: */
        int e_index = x_index;
        int o_index = x_index + datap->ed_x_points / 2;

        int which;
        int phase[6];
        int y_level_e[4];
        int y_level_o[4];

        eye_get_pam4_y_levels(esp, FALSE, y_level_e);
        eye_get_pam4_y_levels(esp, TRUE,  y_level_o);

        /* TODO: Does it still make sense to do separate eye centering? */
        for( which = 0; which < 6; which ++ )
            phase[which] = get_phase_for_x_index(esp, x_index, which);

        status &= eye_gather_column_x(esp, phase[0], 0, e_index, y_level_e[0], y_level_e[1]);
        status &= eye_gather_column_x(esp, phase[1], 1, o_index, y_level_o[0], y_level_o[1]);
        status &= eye_gather_column_x(esp, phase[2], 2, e_index, y_level_e[1], y_level_e[2]);
        status &= eye_gather_column_x(esp, phase[3], 3, o_index, y_level_o[1], y_level_o[2]);
        status &= eye_gather_column_x(esp, phase[4], 4, e_index, y_level_e[2], y_level_e[3]);
        status &= eye_gather_column_x(esp, phase[5], 5, o_index, y_level_o[2], y_level_o[3]);
    }
    return status && return_code == esp->aapl->return_code;
}

/** @brief   Gathers mission and all test PAM4 columns direct or through SBM. */
/** @details Use for default data qual full eye gather. */
/** @return  On success, returns TRUE. */
/** @return  On error, decrements aapl->return_code and returns FALSE. */
static BOOL eye_gather_pam4(Eye_state_t *esp)
{
    BOOL status = eye_set_error_timer(esp, esp->curr_dwell) == 0;
    int x_points = esp->datap->ed_x_UI * esp->datap->ed_x_resolution + 1;
    int x_index;

    /* Initial gather of mission and test columns: */
    /*printf("x_points = %d, ed_x_points = %u, ed_x_resolution = %u\n", x_points, esp->datap->ed_x_points, esp->datap->ed_x_resolution); */
    for( x_index = -1; x_index < x_points && status; x_index++ )
        status &= eye_gather_pam4_column(esp, x_index);

    return status;
}

/** @brief   Gathers NRZ column of data. */
/** @details Pass -1 to select the mission column. */
/** @return  On success, returns TRUE. */
/** @return  On error, decrements aapl->return_code and returns FALSE. */
static BOOL eye_gather_nrz_column(Eye_state_t *esp, int x_index)
{
    uint points = (x_index < 0) ? esp->datap->ed_y_resolution : esp->datap->ed_y_points;
    int phase = get_phase_for_x_index(esp, x_index, 0);

    return eye_gather_column_x(esp, phase, 0, x_index, 0, points);
}

/** @brief   Gathers mission and all test NRZ columns direct or through SBM. */
/** @details Use for all non-PAM4 full eye gathers. */
/** @return  On success, returns TRUE. */
/** @return  On error, decrements aapl->return_code and returns FALSE. */
static BOOL eye_gather_nrz(Eye_state_t *esp)
{
    Avago_serdes_eye_data_t *datap = esp->datap;
    int x_index;
    BOOL status = TRUE;

    if( datap->ed_gather_mean )
        return sbm_eye_gather_nrz(esp);

    /* Initial gather of mission and test columns: */
    for( x_index = -1; x_index < (int)datap->ed_x_points; x_index++ )
        status &= eye_gather_nrz_column(esp, x_index);

    return status;
}

/** @brief   Gathers full eye. */
/** @return  On success, returns TRUE. */
/** @return  On error, decrements aapl->return_code and returns FALSE. */
static BOOL gather_full_eye(Eye_state_t *esp)
{
    /*printf("gather_full_eye: data_qual = %s, rx_data_qual = %s\n",aapl_data_qual_to_str(esp->datap->ed_data_qual), aapl_rx_data_qual_to_str(esp->datap->ed_data_qual.d6_data_qual)); */
    if( esp->default_gather && avago_serdes_get_rx_line_encoding(esp->aapl, esp->addr) )
        return eye_gather_pam4(esp);

    return eye_gather_nrz(esp);
}

/** @brief   Performs initial pass eye height gather on center column. */
/** @details Gathers mission column.  If SIZE_VDUAL mode is selected, also gathers center test column. */
/** @return  On success, returns TRUE. */
/** @return  On error, decrements aapl->return_code and returns FALSE. */
static BOOL gather_eye_height(Eye_state_t *esp)
{
    Avago_serdes_eye_data_t *datap = esp->datap;
    BOOL status;

    if( esp->default_gather && avago_serdes_get_rx_line_encoding(esp->aapl, esp->addr) )
    {
        status = eye_gather_pam4_column(esp, -1); /* Gather mission column */

        if( datap->ed_eye_type == AVAGO_EYE_SIZE_VDUAL && status )
        {
            int x_mid = get_eye_middle_x_index(datap, FALSE);
            status = eye_gather_pam4_column(esp, x_mid);    /* Does both even and odd columns */
        }
        return status;
    }

    status = eye_gather_nrz_column(esp, -1); /* Gather mission column */

    /* Optionally gather the VDUAL column: */
    if( datap->ed_eye_type == AVAGO_EYE_SIZE_VDUAL && status )
    {
        int x_mid = datap->ed_x_points / 2;
        status = eye_gather_nrz_column(esp, x_mid); /* Center test column */
    }
    return status;
}

/** @brief Configures SBM for a row eye gather. */
static BOOL sbm_eye_setup_row(Eye_state_t *esp, int which)
{
    Avago_serdes_eye_data_t *datap = esp->datap;
    Aapl_t *aapl = esp->aapl;
    int return_code = aapl->return_code;
    uint sbm_addr = avago_make_sbus_master_addr(esp->addr);

    uint x_points  = datap->ed_x_points;
    uint x_step  = datap->ed_x_step;
    int  x_start = get_phase_for_x_index(esp, 0, which);

    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Columns: start = %d; total = %u; step = %u\n", x_start, x_points, x_step);

    avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_START  | (x_start  & 0x7ff));
    avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_POINTS | (x_points & 0x7ff));
    avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_STEP   | (x_step   & 0x7ff));
    return return_code == aapl->return_code;
}

/** @brief   Gathers eye data for a row. */
/** @return  On success, returns TRUE. */
/** @return  On error, decrements aapl->return_code and returns FALSE. */
static BOOL gather_row_x(
    Eye_state_t *esp,
    int which,          /**< Which eye, used for center adjustments. */
    int dac,            /**< Absolute DAC value for row gathering. */
    bigint *errs,       /**< Where to record error counts */
    bigint *bits,       /**< Where to record bit counts */
    int array_step)     /**< array entries between elements */
{
    Avago_serdes_eye_data_t *datap = esp->datap;
    int points = datap->ed_x_points;
    int int_data;

    (void ) which;

    if( gather_separate_even_odd(datap) )
        points /= 2;

    if( !esp->sbm_eye_gather )
    {
        int x_index;

        avago_serdes_set_dac2(esp->aapl, esp->addr, dac, FALSE, FALSE);

        for( x_index = 0; x_index < points; x_index++ )
        {
            int phase_new = get_phase_for_x_index(esp, x_index, which);

            *errs += eye_step_phase(esp, phase_new, TRUE);
            errs += array_step;

            if( bits )    /* Only accumulate bits during first pass. */
            {
                *bits += esp->curr_dwell;
                bits += array_step;
            }
        }
        return TRUE;
    }

    dac -= (datap->ed_y_resolution - 1) / 2; /* Change coordinates to 0 == middle of dac */
    int_data = EYE_GATHER_ROW | (sbm_adjust_dac(esp,dac) & 0x7ff);

    return sbm_eye_gather_data(esp, int_data, bits, errs, array_step, points);
}

/** @brief Gathers row at data array index for specified eye. */
static BOOL eye_gather_row(Eye_state_t *esp, int which, uint y_index)
{
    Avago_serdes_eye_data_t *datap = esp->datap;
    int i;
    Gather_info_t gather_info;
    BOOL status = TRUE;
    int base_dac = get_dac_for_y_index(datap,y_index,FALSE);
    int row_points = datap->ed_x_UI * datap->ed_x_resolution + 1;
    int row_start = ((which & 1) && gather_separate_even_odd(datap)) ? row_points : 0;
    bigint *errs = (bigint *)&get_errs_column(datap, row_start)[y_index];
    bigint *bits = (bigint *)&get_bits_column(datap, row_start)[y_index];

    init_gather_info(esp, which, &gather_info);

    if( esp->sbm_eye_gather )
        status &= sbm_eye_setup_row(esp, which);

    for( i = 0; i < gather_info.entries && status; i++ )
    {
        int dac = base_dac + gather_info.v_offset[i];

        eye_select(esp, gather_info.eye[i]);

        if( gather_info.h_index[i] >= 0 )
            eye_set_delay(esp, gather_info.h_index[i], gather_info.h_delay[i]);

        status &= gather_row_x(esp, which, dac, errs, bits, datap->ed_y_points);
        bits = 0;
    }
    return status;
}

/** @brief   Performs initial pass eye width gather on HBTC row. */
/** @details Gathers the three eye center rows in PAM4 mode. */
/** @return  On success, returns TRUE. */
/** @return  On error, decrements aapl->return_code and returns FALSE. */
static BOOL gather_eye_width(Eye_state_t *esp)
{
    Avago_serdes_eye_data_t *datap = esp->datap;
    int which;
    BOOL status = TRUE;
    status &= eye_set_clock_source(esp, /* test_clock = */ TRUE);
    for( which = 0; which < datap->eye_count; which++ )
        status &= eye_gather_row(esp, which, datap->ed_hbtc[which].data_row);
    return status;
}


static void update_qval_and_gradient_for_point(Avago_serdes_eye_data_t *datap, int column, uint y)
{
    /* Calculate the Qinv value and store it in the ed_qvalp array */
    calc_qval_bit(datap, column, y);

    /* Calculate any gradient bits affected by this point: */
    calc_gradient_bit(datap, column, y);    /* me */
    calc_gradient_bit(datap, column, y+1);  /* south neighbor */
    calc_gradient_bit(datap, column+1, y);  /* east  neighbor */
}

/** @brief  Performs gather at the indicated point. */
/** Does not store results. */
/** @return On success, returns measured error count for point. */
/** @return On failure, decrements aapl->return_code and returns -1. */
static int sbm_eye_get_point(
    Eye_state_t *esp, /**< Eye state info */
    BOOL mission,     /**< TRUE if mission column (sbm_phase ignored). */
    int sbm_phase,    /**< Column from which to gather (relative to eye-center). */
    int sbm_dac)      /**< Row from which to gather (relative to eye-center). */
{
    uint int_data;
    bigint bits = 0;
    bigint errors = 0;
    if( mission )
    {
        int_data = EYE_GATHER_MISSION;
        if( sbm_set_dac_start(esp, __func__, __LINE__, sbm_dac)
            && sbm_eye_gather_data(esp, int_data, &bits, &errors, 1, 1) )
            return (int)errors;
    }
    else
    {
        int_data = EYE_GATHER_COLUMN | (sbm_phase & 0x7ff);
        if( sbm_set_dac_start(esp, __func__, __LINE__, sbm_dac)
            && sbm_eye_gather_data(esp, int_data, &bits, &errors, 1, 1) )
            return (int)errors;
    }
    return -1;
}

/** @brief   Performs dynamic dwell at a point and saves results. */
/** @details Note: The caller decides which points to dwell upon. */
/** @return  Returns TRUE if dynamic dwell done successfully. */
/** @return  On failure, decrements aapl->return_code and returns FALSE. */
static BOOL eye_dynamic_dwell_bit(
    Eye_state_t *esp,
    int phase,
    int x_index,
    uint y_index,
    Gather_info_t *gather_info)
{
    BOOL status = TRUE;
    BOOL update = FALSE;
    Avago_serdes_eye_data_t *datap = esp->datap;
    bigint *bits = (bigint *)get_bits_column(datap, x_index);
    bigint *errs = (bigint *)get_errs_column(datap, x_index);
    int threshold = esp->threshold; /* Save */
    int sbm_phase = phase;
    int base_dac = get_dac_for_y_index(datap, y_index, x_index < 0);

    /*printf("%d: x_index = %d, phase = %d, sbm_phase = %d, y_index = %u, base_dac = %u\n", __LINE__, x_index, phase, sbm_phase, y_index, base_dac); */
    if( !esp->sbm_eye_gather )
    {
        if( eye_step_phase(esp, phase, /* get_errors = */ FALSE) < 0 )
            return FALSE;
    }

    if( esp->configp->ec_fast_dynamic == 2 ) esp->threshold = 1000;

    /*printf("errors[%3d,%3d] = %s; threshold = %d\n", x_index, y_index, aapl_bigint_to_str(errs[y_index]), esp->threshold); */

    while( errs[y_index] <= esp->threshold &&
           errs[y_index] >= 0 &&
           bits[y_index] < datap->ed_max_dwell_bits )
    {
        int gi_index, errors = 0;

        if( aapl_get_async_cancel_flag(esp->aapl) ) { status = FALSE; break; }

        /* Update esp->curr_dwell and call eye_set_error_timer() accordingly. */
        if( ! update_dwell(esp, x_index, y_index) ) { status = FALSE; break; }

        /* GATHER LOOP for dynamic dwell at a single point */
        esp->gather_reverse = !esp->gather_reverse;
        for( gi_index = 0; gi_index < gather_info->entries && status; gi_index++ )
        {
            int i = esp->gather_reverse ? gather_info->entries - 1 - gi_index : gi_index;
            int dac = base_dac + gather_info->v_offset[i];

            eye_select(esp, gather_info->eye[i]);

            if( gather_info->h_index[i] >= 0 )
                eye_set_delay(esp, gather_info->h_index[i], gather_info->h_delay[i]);

            if( !esp->sbm_eye_gather )
                errors += eye_set_dac(esp, dac);
            else
                errors += sbm_eye_get_point(esp, x_index < 0, sbm_phase, dac -= (datap->ed_y_resolution-1)/2);

            if( errors != 0 && esp->aapl->debug >= AVAGO_DEBUG4 )
                aapl_log_printf(esp->aapl, AVAGO_DEBUG4, 0, 0, "%d: i=%d: [%d,%d (%d,%d)] dwell = %s; %d errors from eye %d\n", __LINE__, i, x_index, y_index, sbm_phase, dac, aapl_bigint_to_str(esp->curr_dwell), errors, gather_info->eye[i]);
        }
        /*printf("errs[%3d,%3d] = %6s <= threshold = %4d, new errors = %5d; curr_dwell = %s\n",x_index,y_index,aapl_bigint_to_str(errs[y_index]),esp->threshold, errors, aapl_bigint_to_str(esp->curr_dwell)); */
        errs[y_index] += errors;
        bits[y_index] += esp->curr_dwell;

        update = TRUE;
      /*if( x_index >= 0 ) */
      /*printf("errs[x=%3d, y_index=%3u, base_dac=%u] = %3s+%d, bits[y_index] = %9s, dwell=%9s\n", x_index, y_index, base_dac, aapl_bigint_to_str(errs[y_index]-errors), errors, aapl_bigint_to_str(bits[y_index]),aapl_bigint_to_str(esp->curr_dwell)); */

        aapl_log_printf(esp->aapl, AVAGO_DEBUG3, __func__, __LINE__, "dynamic: errors = %s, bits = %s\n",
            aapl_bigint_to_str(errs[y_index]),
            aapl_bigint_to_str(bits[y_index]));
    }
    esp->threshold = threshold; /* Restore */

    if( update )
        update_qval_and_gradient_for_point(esp->datap, x_index, y_index);

    return status;
}

/** @return  On success, returns TRUE. */
/** @return  On failure, decrements aapl->return_code and returns FALSE. */
static BOOL eye_dynamic_dwell_column(
    Eye_state_t *esp,
    int which,
    int x_index,
    int y_begin,
    int y_end) /* One past end. */
{
    int neighbor_threshold = esp->configp->ec_fast_dynamic ? esp->threshold : 0;
    int y_index;
    bigint *errs = (bigint *)get_errs_column(esp->datap, x_index);
    bigint *bits = (bigint *)get_bits_column(esp->datap, x_index);
    Gather_info_t gather_info;
    int phase = get_phase_for_x_index(esp, x_index, which);

    init_gather_info(esp, which, &gather_info);

    aapl_log_printf(esp->aapl, AVAGO_DEBUG2, __func__, __LINE__, "x_index = %d, y_range = [%u..%u], neighbor_threshold = %d\n",x_index,y_begin,y_end, neighbor_threshold);

    /* Do dynamic dwell beginning to end: */
    for( y_index = y_begin; y_index < y_end-1; y_index++ )
    {
        /* If neighbor has enough errors, see if this point has enough errors: */
        if( errs[y_index] > neighbor_threshold )
        {
            if( !eye_dynamic_dwell_bit(esp, phase, x_index, y_index+1, &gather_info) )
                return FALSE;
        }
        else if( bits[y_index] > 0 ) /* Stop scanning if can't get enough errors */
        {
            aapl_log_printf(esp->aapl, AVAGO_DEBUG2, __func__, __LINE__, "STOP SCANNING column %d at %d\n", x_index, y_index);
            break;
        }
    }

    /* Do dynamic dwell end to beginning: */
    for( y_index = y_end-1; y_index > y_begin; y_index-- )
    {
        /* If neighbor has enough errors, see if this point has enough errors: */
        if( errs[y_index] > neighbor_threshold )
        {
            if( !eye_dynamic_dwell_bit(esp, phase, x_index, y_index-1, &gather_info) )
                return FALSE;
        }
        else if( bits[y_index] > 0 ) /* Stop scanning if can't get enough errors */
        {
            aapl_log_printf(esp->aapl, AVAGO_DEBUG2, __func__, __LINE__, "STOP SCANNING column %d at %d\n", x_index, y_index);
            break;
        }
    }
    return TRUE;
}

/** @brief   Perform dynamic dwell on given row of eye. */
/** @return  On success, returns TRUE. */
/** @return  On failure, decrements aapl->return_code and returns FALSE. */
static BOOL eye_dynamic_dwell_row(Eye_state_t *esp, int which, uint y_index)
{
    Avago_serdes_eye_data_t *datap = esp->datap;
    int neighbor_threshold = esp->configp->ec_fast_dynamic ? esp->threshold : 0;
    int x_index;
    int x_mid = get_eye_middle_x_index(datap, which & 1);
    int x_left  = MAX(x_mid - datap->ed_x_resolution / 2, 0); /* First index in range */
    int x_right = MIN(x_mid + datap->ed_x_resolution / 2, datap->ed_x_points-1);    /* Last index in range */
    int x_shift = 0;
    Gather_info_t gather_info;

    /* For limited y points, the btc row may be out of range. */
    if( y_index >= datap->ed_y_points )
        return TRUE;

    init_gather_info(esp, which, &gather_info);

    aapl_log_printf(esp->aapl,AVAGO_DEBUG2,__func__,__LINE__,"which = %d, x_range = [%d..%d], x_shift = %d, y_index = %d\n", which, x_left, x_right, x_shift, y_index);

    /* Left to right: */
    for( x_index = x_left+1; x_index <= x_right; x_index++ )
    {
        /* If neighbor has enough errors, see if this point has enough errors: */
        if( AVAGO_EYE_ERRORS_GET(*datap, x_index-1, y_index) > neighbor_threshold )
        {
            int phase = get_phase_for_x_index(esp, x_index, which);
            if( !eye_dynamic_dwell_bit(esp, phase, x_index, y_index, &gather_info) )
                return FALSE;
        }
        else /* Stop scanning if neighbor doesn't have enough errors */
            break;
    }

    /* Right to left: */
    for( x_index = x_right-1; x_index > x_left; x_index-- )
    {
        /* If neighbor has enough errors, see if this point has enough errors: */
        if( AVAGO_EYE_ERRORS_GET(*datap, x_index+1, y_index) > neighbor_threshold )
        {
            int phase = get_phase_for_x_index(esp, x_index, which);
            if( !eye_dynamic_dwell_bit(esp, phase, x_index, y_index, &gather_info) )
                return FALSE;
        }
        else /* Stop scanning if neighbor doesn't have enough errors */
            break;
    }

    return TRUE;
}

/** @brief   Performs dynamic dwell on BTC points. */
/** @details Works for all hardware and gather types. */
/** @return  On success, returns TRUE. */
/** @return  On failure, decrements aapl->return_code and returns FALSE. */
static BOOL eye_dynamic_dwell_btc(
    Eye_state_t *esp)
{
    Avago_serdes_eye_data_t *datap = esp->datap;
    BOOL status = TRUE;

    if( datap->ed_eye_type != AVAGO_EYE_WIDTH )
    {
        if( !eye_set_clock_source(esp, /* test_clock = */ FALSE) )
            return FALSE;

        if( datap->eye_count == 6 )
        {
            /* Upper, middle, lower full mission columns: */
            status &= eye_dynamic_dwell_column(esp,5,-6,datap->ed_y_resolution/2,datap->ed_y_resolution);
            status &= eye_dynamic_dwell_column(esp,4,-5,datap->ed_y_resolution/2,datap->ed_y_resolution);
            status &= eye_dynamic_dwell_column(esp,3,-4,datap->ed_y_resolution/4,datap->ed_y_resolution*3/4);
            status &= eye_dynamic_dwell_column(esp,2,-3,datap->ed_y_resolution/4,datap->ed_y_resolution*3/4);
            status &= eye_dynamic_dwell_column(esp,1,-2,0                       ,datap->ed_y_resolution/2);
            status &= eye_dynamic_dwell_column(esp,0,-1,0                       ,datap->ed_y_resolution/2);
        }
        else /* Dynamic dwell on full mission column: */
        {
            status &= eye_dynamic_dwell_column(esp, 0, -1, 0, datap->ed_y_resolution);
        }
    }

    if( datap->ed_eye_type != AVAGO_EYE_HEIGHT )
    {
        int which;
        if( !eye_set_clock_source(esp, /* test_clock = */ TRUE) )
            return FALSE;

        for( which = 0; which < datap->eye_count; which++ )
            status &= eye_dynamic_dwell_row(esp, which, datap->ed_hbtc[which].data_row);
    }

    return status;
}

/** @brief   Performs dynamic dwell on requested range of points. */
/** @details Works for all hardware and gather types. */
/** @return  On success, returns TRUE. */
/** @return  On failure, decrements aapl->return_code and returns FALSE. */
static BOOL eye_dynamic_dwell_range(
    Eye_state_t *esp,
    int which,
    uint y_begin,    /* First y index to scan */
    uint y_end)      /* One beyond last y index to scan */
{
    Avago_serdes_eye_data_t *datap = esp->datap;
    int neighbor_threshold = esp->configp->ec_fast_dynamic ? esp->threshold : 0;
    uint x_index;
    Gather_info_t gather_info;

    init_gather_info(esp, which, &gather_info);

    if( which != gather_info.which )
        return TRUE;                /* Requested eye isn't available or appropriate. */

    /* Scan from lower left to upper right: */
    for( x_index = 0; x_index < datap->ed_x_points; x_index++ )
    {
        uint y_index;
        int phase = get_phase_for_x_index(esp, x_index, which);
        for( y_index = y_begin; y_index < y_end; y_index++ )
        {
            if( (x_index != 0 && AVAGO_EYE_ERRORS_GET(*datap, x_index-1, y_index) > neighbor_threshold) ||
                (y_index != 0 && AVAGO_EYE_ERRORS_GET(*datap, x_index, y_index-1) > neighbor_threshold) )
            {
                if( ! eye_dynamic_dwell_bit(esp, phase, x_index, y_index, &gather_info) )
                    return FALSE;
            }
        }
    }
    /* Scan from upper right to lower left: */
    for( x_index = datap->ed_x_points; x_index > 0;    )
    {
        uint y_index;
        int phase = get_phase_for_x_index(esp, x_index, which);
        BOOL right_edge = (x_index == datap->ed_x_points);
        x_index--;
        for( y_index = y_end; y_index > y_begin;     )
        {
            BOOL bottom_edge = (y_index == datap->ed_y_points);
            y_index--;
            if( (!right_edge  && AVAGO_EYE_ERRORS_GET(*datap, x_index+1, y_index) > neighbor_threshold) ||
                (!bottom_edge && AVAGO_EYE_ERRORS_GET(*datap, x_index, y_index+1) > neighbor_threshold) )
            {
                if( ! eye_dynamic_dwell_bit(esp, phase, x_index, y_index, &gather_info) )
                    return FALSE;
            }
        }
    }
    return TRUE;
}

/** @brief   Performs dynamic dwell on full eye. */
/** @details Useful for more accurate full eye bathtub calcs without */
/**          performance cost of full dynamic dwell. */
/** @details Works for all hardware and gather types. */
/** */
/** Processes the eye to perform additional dwells on bits where: */
/**  * the error count is less than or equal to the error_threshold, and */
/**  * where a neighboring cell has some errors (> 0 for fast_dynamic==0, */
/**    > threshold for fast_dynamic == 1 or 2), and */
/**  * the current bit has > 0 dwells already. */
/** */
/** The goal is to increase the resolution of the BER on the edges */
/**    of the eye by doing additional dwells until the center edge */
/**    of the eye has zero errors even after max_dwell bits dwells. */
/** @return  On success, returns TRUE. */
/** @return  On failure, decrements aapl->return_code and returns FALSE. */
static BOOL eye_dynamic_dwell_all(
    Eye_state_t *esp)
{
    Avago_serdes_eye_data_t *datap = esp->datap;
    BOOL status = TRUE;

    if( !eye_set_clock_source(esp, /* test_clock = */ TRUE) )
        return FALSE;

    if( esp->default_gather && avago_serdes_get_rx_line_encoding(esp->aapl, esp->addr) )
    {
        int y_level[4];

        eye_get_pam4_y_levels(esp, FALSE, y_level);
        status &= eye_dynamic_dwell_range(esp, 0, y_level[0], y_level[1]);
        status &= eye_dynamic_dwell_range(esp, 1, y_level[1], y_level[2]);
        status &= eye_dynamic_dwell_range(esp, 2, y_level[2], y_level[3]);
    }
    else
    {
        status &= eye_dynamic_dwell_range(esp, 0, 0, datap->ed_y_points);
    }

    return status;
}

/** @brief   Performs requested dynamic dwell. */
/** @details Works for all hardware and gather types. */
/** @return  On success, returns TRUE. */
/** @return  On failure, decrements aapl->return_code and returns FALSE. */
static BOOL eye_dynamic_dwell(
    Eye_state_t *esp)
{
    BOOL status = TRUE;

    /* If dynamic dwell is selected */
    if( esp->datap->ed_min_dwell_bits < esp->datap->ed_max_dwell_bits )
    {
        status &= sbm_eye_setup_point(esp);         /* Set up for single point gathering. */

        status &= eye_dynamic_dwell_btc(esp);       /* Do dynamic dwell on BTC points. */

        if( esp->configp->ec_fast_dynamic < 2 )
            status &= eye_dynamic_dwell_all(esp);   /* Do dynamic dwell on full eye. */
    }
    return status;
}


/** @brief  Calculates the RJ (random jitter) from the slope. */
/** @return The calculated RJ value. */
static double calc_rj(const Avago_least_sqr_results *data)
{
    double ret;
    if( data->slope == 0.0 )
        return 1000.0;
    ret = 1.0 / data->slope;
    return ret > 0.0 ? ret : -ret;
}

static int get_Vmean(const Avago_serdes_eye_data_t *datap, int column, int y_mid, float *top, float *bottom)
{
    const bigint *bits = get_bits_column(datap, column);
    const bigint *errs = get_errs_column(datap, column);
    int points = column < 0 ? datap->ed_y_mission_points : datap->ed_y_points;
    int step   = column < 0 ? datap->ed_y_mission_step   : datap->ed_y_step;
    int threshold = datap->ed_error_threshold;
    int y;
    Avago_least_sqr_point point, prev = {0.0, 0.0};

    for( y = y_mid; y < points; y++ )
    {
        if( bits[y] < 0 ) continue; /* Skip points which have no data: */
        if( bits[y] == 0 ) break;   /* End of valid range */

        if( errs[y] > threshold )
        {
            /* Note x & y reversal here: */
            point.x = mv_from_index(datap, points, step, y);
            point.y = avago_qfuncinv(avago_calc_BER(errs[y],bits[y],datap->ed_dc_balance));

            /* Look for the location of the Q transition from positive to negative: */
            if( y > y_mid && point.y < 0 && prev.y >= 0 )
            {
                *top = (float)avago_interpolate(&prev,&point);
              /*printf("Top prevPoint=(%f,%f), myPoint=(%f,%f)\n", prev.x,prev.y,point.x,point.y); */
                break;
            }
            *top = point.x;
            prev.x = point.x;
            prev.y = point.y;
        }
    }

    for( y = y_mid; y >= 0; y-- )
    {
        if( bits[y] < 0 ) continue; /* Skip points which have no data: */
        if( bits[y] == 0 ) break;   /* End of valid range */

        /* If we start collecting data, and then find another point */
        /*  below the threshold, restart the collecting: */
        if( errs[y] > threshold )
        {
            /* Note x & y reversal here: */
            point.x = mv_from_index(datap, points, step, y);
            point.y = avago_qfuncinv(avago_calc_BER(errs[y],bits[y],datap->ed_dc_balance));

            /* Look for the location of the Q transition from positive to negative: */
            if( y < y_mid && point.y < 0 && prev.y >= 0 )
            {
                *bottom = (float)avago_interpolate(&prev,&point);
              /*printf("Bottom prevPoint=(%f,%f), myPoint=(%f,%f)\n", prev.x,prev.y,point.x,point.y); */
                break;
            }
            *bottom = point.x;
            prev.x = point.x;
            prev.y = point.y;
        }
    }

    /* If both sides have transition points available, avago_interpolate them to */
    /*   compute Vmean = height of actual (not extrapolated) opening at Q==0. */
    if( *top > 0.0 && *bottom < 0.0 )
    {
      /*printf("top = %f, bottom = %f\n",*top,*bottom); */
        return (int)(*top - *bottom); /* conservative versus round() */
    }
    return 0;
}

/** @cond INTERNAL */

const double q03 = 3.0902;
const double q04 = 3.7190;
const double q05 = 4.2649;
const double q06 = 4.74;
const double q10 = 6.36;
const double q12 = 7.03;
const double q15 = 7.94;
const double q17 = 8.49;

#define FIT (3)
/** @endcond */


/** @brief   Calculates best-fit extrapolation for the HBTC (horizontal bathtub curve). */
/** @details Uses the selected row of eye data and trans_density */
/**          to perform a standard set of error rate extrapolations. */
/** @return  Saves relevant results into the Avago_serdes_eye_hbtc_t structure. */
/** @see     avago_serdes_eye_vbtc_extrapolate(). */
void avago_serdes_eye_hbtc_extrapolate(
    const Avago_serdes_eye_data_t *datap,   /**< [in] Populated eye data. */
    BOOL odd,                               /**< [in] Which eye to analyze. */
    uint data_row,                          /**< [in] Row index in eye data to analyze. */
    float trans_density,                    /**< [in] Transition density to use for calculations. */
    Avago_serdes_eye_hbtc_t *results)       /**< [out] Where results are written. */
{
    Avago_least_sqr_results left, right;

    memset(results,0,sizeof(*results));

    /* These should always be initialized: */
    results->data_row = data_row;
    results->total_rows = datap->ed_y_points;
    results->trans_density = trans_density;
    results->data_millivolts = (uint)mv_from_index(datap, datap->ed_y_points, datap->ed_y_step, data_row);
    results->points = datap->ed_x_points;

    /* If data_row is out of range, or only a column gather: */
    if( data_row >= datap->ed_y_points || datap->ed_eye_type == AVAGO_EYE_HEIGHT )
        return; /* Invalid parameter. */

    /* Find the least square fits for left and right edges of eye: */
    /* Must be after data_row is set. */
    get_horizontal_least_sqr(datap, data_row, odd, results->trans_density, results, &left, &right);
    get_horizontal_means(    datap, data_row, odd, results->trans_density, results);

    /* Indicate that results are valid: */
    if( results->left_points < FIT || results->right_points < FIT )
    {
        results->left_points = results->right_points = 0;
        return; /* Not enough data points to extrapolate */
    }


    results->left_slope      = (float)left.slope * 1000;
    results->left_intercept  = (float)left.y_intercept;
    results->left_R_squared  = (float)left.Rsqr;
    results->left_rj         = (float)calc_rj(&left);

    if( left.slope != 0.0 )
        results->left_x_intercept = -left.y_intercept / left.slope;
    if( right.slope != 0.0 )
        results->right_x_intercept = -right.y_intercept / right.slope;
    results->dj = fabs(1000 - (results->right_x_intercept - results->left_x_intercept));

    results->right_slope     = (float)right.slope * 1000;
    results->right_intercept = (float)right.y_intercept;
    results->right_R_squared = (float)right.Rsqr;
    results->right_rj        = (float)calc_rj(&right);
    results->snr             = (float)(results->right_intercept * results->left_slope - results->left_intercept * results->right_slope) / (results->left_slope - results->right_slope);
    if( results->snr < 0 )
        results->snr = -results->snr;   /* Insure it is not negative. */

    /* Calculate the 0 and 100mUI eye opening bit error rates: */
    /* */
    {
    double y_int_diff = right.y_intercept - left.y_intercept;
    double slope_diff = left.slope - right.slope;
    double x_0mUI = y_int_diff / slope_diff * left.slope + left.y_intercept;
    double x_100mUI = (y_int_diff + (100 * right.slope)) / slope_diff * left.slope + left.y_intercept;
    if( x_0mUI > AVAGO_Q_CEILING )
        x_0mUI = AVAGO_Q_CEILING;
    if( x_100mUI > AVAGO_Q_CEILING )
        x_100mUI = AVAGO_Q_CEILING;
    results->horz_ber_0mUI = avago_qfunc(x_0mUI);
    results->horz_ber_100mUI = avago_qfunc(x_100mUI);
    results->width_0mUI = x_0mUI;
    results->width_100mUI = x_100mUI;
    }

    /* Calculate the eye openings at several bit error rates: */
    /* */
    results->horz_eye_1e03 = (int)((left.y_intercept - q03) / left.slope - (right.y_intercept - q03) / right.slope);
    results->horz_eye_1e04 = (int)((left.y_intercept - q04) / left.slope - (right.y_intercept - q04) / right.slope);
    results->horz_eye_1e05 = (int)((left.y_intercept - q05) / left.slope - (right.y_intercept - q05) / right.slope);
    results->horz_eye_1e06 = (int)((left.y_intercept - q06) / left.slope - (right.y_intercept - q06) / right.slope);
    results->horz_eye_1e10 = (int)((left.y_intercept - q10) / left.slope - (right.y_intercept - q10) / right.slope);
    results->horz_eye_1e12 = (int)((left.y_intercept - q12) / left.slope - (right.y_intercept - q12) / right.slope);
    results->horz_eye_1e15 = (int)((left.y_intercept - q15) / left.slope - (right.y_intercept - q15) / right.slope);
    results->horz_eye_1e17 = (int)((left.y_intercept - q17) / left.slope - (right.y_intercept - q17) / right.slope);
}

/** @brief Write the HBTC data to a string. */
/** @return A character string containing the formatted HBTC results. */
/**         The caller should AAPL_FREE the returned string. */
char *avago_serdes_eye_hbtc_format(
    const Avago_serdes_eye_hbtc_t *hbtcp) /**< Populated Avago_serdes_eye_hbtc_t pointer. */
{
    size_t buf_len = 1000;
    char *buf = (char *)AAPL_MALLOC(buf_len);
    char *end = buf + buf_len;
    char *ptr = buf;
    double td = hbtcp->trans_density;
    uint mid_row = ((int)hbtcp->total_rows-1) / 2;
    const char *eye_type = hbtcp->points/2 < hbtcp->left_index ? "odd " : hbtcp->points/2 > hbtcp->right_index ? "even " : "";
    if( buf == NULL )
        return buf;

    ptr += snprintf(ptr, end-ptr, "\n");
    ptr += snprintf(ptr, end-ptr, "# Horizontal Bathtub Curve for %seye at %+d mV (%+d rows) from center:\n", eye_type, hbtcp->data_millivolts, hbtcp->data_row - mid_row);
    if( hbtcp->left_points == 0 || hbtcp->right_points == 0 )
    {
        if( hbtcp->data_row < AAPL_MAX_DAC_RANGE )
            return strncat(ptr,"\nNOTE: Insufficient data to generate horizontal bathtub information.\n", end-ptr), buf;
        AAPL_FREE(buf);
        return NULL;    /* Don't print messages for non-initialized BTC structures */
    }

    if( hbtcp->left_R_squared < 0.95 || hbtcp->right_R_squared < 0.95 ||
        hbtcp->left_slope <= 0.0 || hbtcp->right_slope >= 0.0 )
        ptr += snprintf(ptr, end-ptr, "#\n# WARNING: This projection is based on measurements with poor correlation.\n#\n");

    ptr += snprintf(ptr, end-ptr, "BER/%.3g = Q at eye width of   0 mUI: %4.2e, %5.2f\n", td, hbtcp->horz_ber_0mUI, hbtcp->width_0mUI);
    ptr += snprintf(ptr, end-ptr, "BER/%.3g = Q at eye width of 100 mUI: %4.2e, %5.2f\n", td, hbtcp->horz_ber_100mUI, hbtcp->width_100mUI);
    ptr += snprintf(ptr, end-ptr, "Eye width at 1e-06 BER/%.3g = Q(%4.2f): %4d mUI\n", td, q06, hbtcp->horz_eye_1e06);
    ptr += snprintf(ptr, end-ptr, "Eye width at 1e-10 BER/%.3g = Q(%4.2f): %4d mUI\n", td, q10, hbtcp->horz_eye_1e10);
    ptr += snprintf(ptr, end-ptr, "Eye width at 1e-12 BER/%.3g = Q(%4.2f): %4d mUI\n", td, q12, hbtcp->horz_eye_1e12);
    ptr += snprintf(ptr, end-ptr, "Eye width at 1e-15 BER/%.3g = Q(%4.2f): %4d mUI\n", td, q15, hbtcp->horz_eye_1e15);
    ptr += snprintf(ptr, end-ptr, "Eye width at 1e-17 BER/%.3g = Q(%4.2f): %4d mUI\n", td, q17, hbtcp->horz_eye_1e17);
/*  ptr += snprintf(ptr, end-ptr, "Y-intercept left/right:   %7.1f,    %5.1f    Q\n", hbtcp->left_intercept, hbtcp->right_intercept); */
    ptr += snprintf(ptr, end-ptr, "X-intercept left/right:   %7.1f,    %5.1f  mUI\n", hbtcp->left_x_intercept, hbtcp->right_x_intercept);
/*  ptr += snprintf(ptr, end-ptr, "Slope left/right:         %7.1f,    %5.1f Q/UI\n", hbtcp->left_slope, hbtcp->right_slope); */
    ptr += snprintf(ptr, end-ptr, "Mean left/right:          %7.1f,    %5.1f  mUI (at Q==0)\n", hbtcp->left_mean, hbtcp->right_mean);
    ptr += snprintf(ptr, end-ptr, "Est RJrms left/right:     %7.1f,    %5.1f  mUI\n",  hbtcp->left_rj, hbtcp->right_rj);
    ptr += snprintf(ptr, end-ptr, "Est DJpp:                 %7.1f            mUI\n", hbtcp->dj);
    ptr += snprintf(ptr, end-ptr, "Est signal noise ratio:   %8.2f\n", hbtcp->snr);
    ptr += snprintf(ptr, end-ptr, "Transition density:       %11.5f\n", hbtcp->trans_density);
    ptr += snprintf(ptr, end-ptr, "R-squared fit left/right: %9.3f,    %5.3f\n", hbtcp->left_R_squared, hbtcp->right_R_squared);
    ptr += snprintf(ptr, end-ptr, "No. points left/right:    %5u, %8u\n",hbtcp->left_points, hbtcp->right_points);
    ptr += snprintf(ptr, end-ptr, "Indexes left/right:       %5u, %8u\n",hbtcp->left_index,hbtcp->right_index);
    return buf;
}

#if AAPL_ENABLE_FILE_IO
/** @brief Write the formatted HBTC data to a file using the */
/**        serdes_eye_hbtc_format() output. */
void avago_serdes_eye_hbtc_write(
    FILE *file,                           /**< [in] Where to write. */
    const Avago_serdes_eye_hbtc_t *hbtcp) /**< [in] Data to format and print. */
{
    char *hbtc_string = avago_serdes_eye_hbtc_format(hbtcp);
    if( hbtc_string )
    {
        fputs("\n",file);
        fputs(hbtc_string,file);
        AAPL_FREE(hbtc_string);
    }
}
#endif

/** @brief Write the formatted HBTC data to the log using the */
/**        serdes_eye_hbtc_format() output. */
void avago_serdes_eye_hbtc_log_print(
    Aapl_t *aapl,           /**< [in] */
    Aapl_log_type_t level,         /**< [in] Specify logging type. */
    const char *caller,     /**< [in] Typically __func__, may be 0. */
    int line,               /**< [in] Typically __LINE__, may be 0. */
    const Avago_serdes_eye_hbtc_t *hbtcp)    /**< [in] Data to format and print. */
{
    char *hbtc_string = avago_serdes_eye_hbtc_format(hbtcp);
    if( hbtc_string )
    {
        aapl_log_add(aapl, level, hbtc_string, caller, line);
        AAPL_FREE(hbtc_string);
    }
}


/** @brief Write the HBTC data to a string. */
/** @return A character string containing the formatted HBTC results. */
/**         The caller should AAPL_FREE the returned string. */
char *avago_serdes_eye_btc_format(
    const Avago_serdes_eye_data_t *datap) /**< [in] Populated eye data. */
{
    size_t buf_len = 450;
    char *buf = (char *)AAPL_MALLOC(buf_len);
    char *end = buf + buf_len;
    char *ptr = buf;
    if( buf == NULL )
        return buf;

    ptr += snprintf(ptr, end-ptr, "\n");
    if( datap->eye_count == 6 )
    {
        ptr += snprintf(ptr, end-ptr, "Level 3 even/odd means: %6.0f %6.0f mV\n", datap->level_vmean[0][3], datap->level_vmean[1][3]);
        ptr += snprintf(ptr, end-ptr, "Level 2 even/odd means: %6.0f %6.0f mV\n", datap->level_vmean[0][2], datap->level_vmean[1][2]);
        ptr += snprintf(ptr, end-ptr, "Level 1 even/odd means: %6.0f %6.0f mV\n", datap->level_vmean[0][1], datap->level_vmean[1][1]);
        ptr += snprintf(ptr, end-ptr, "Level 0 even/odd means: %6.0f %6.0f mV\n", datap->level_vmean[0][0], datap->level_vmean[1][0]);
        ptr += snprintf(ptr, end-ptr, "Level 3 even/odd DN:    %6.2f %6.2f mV\n", datap->level_dn[0][3], datap->level_dn[1][3]);
        ptr += snprintf(ptr, end-ptr, "Level 2 even/odd DN:    %6.2f %6.2f mV\n", datap->level_dn[0][2], datap->level_dn[1][2]);
        ptr += snprintf(ptr, end-ptr, "Level 1 even/odd DN:    %6.2f %6.2f mV\n", datap->level_dn[0][1], datap->level_dn[1][1]);
        ptr += snprintf(ptr, end-ptr, "Level 0 even/odd DN:    %6.2f %6.2f mV\n", datap->level_dn[0][0], datap->level_dn[1][0]);
        ptr += snprintf(ptr, end-ptr, "Level even/odd Comp:    %6.2f %6.2f dB\n", datap->level03_comp[0],datap->level03_comp[1]);
    }
    else if( datap->eye_count == 3 )
    {
        ptr += snprintf(ptr, end-ptr, "Level 3 mean: %5.0f mV\n", datap->level_vmean[0][3]);
        ptr += snprintf(ptr, end-ptr, "Level 2 mean: %5.0f mV\n", datap->level_vmean[0][2]);
        ptr += snprintf(ptr, end-ptr, "Level 1 mean: %5.0f mV\n", datap->level_vmean[0][1]);
        ptr += snprintf(ptr, end-ptr, "Level 0 mean: %5.0f mV\n", datap->level_vmean[0][0]);
        ptr += snprintf(ptr, end-ptr, "Level 3 DN:   %5.2f mV\n", datap->level_dn[0][3]);
        ptr += snprintf(ptr, end-ptr, "Level 2 DN:   %5.2f mV\n", datap->level_dn[0][2]);
        ptr += snprintf(ptr, end-ptr, "Level 1 DN:   %5.2f mV\n", datap->level_dn[0][1]);
        ptr += snprintf(ptr, end-ptr, "Level 0 DN:   %5.2f mV\n", datap->level_dn[0][0]);
        ptr += snprintf(ptr, end-ptr, "Level Comp:   %5.2f dB\n", datap->level03_comp[0]);
    }
    else
    {
        ptr += snprintf(ptr, end-ptr, "Level 1 mean: %5.0f mV\n", datap->level_vmean[0][1]);
        ptr += snprintf(ptr, end-ptr, "Level 0 mean: %5.0f mV\n", datap->level_vmean[0][0]);
        ptr += snprintf(ptr, end-ptr, "Level 1 DN:   %5.2f mV\n", datap->level_dn[0][1]);
        ptr += snprintf(ptr, end-ptr, "Level 0 DN:   %5.2f mV\n", datap->level_dn[0][0]);
    }


    ptr += snprintf(ptr, end-ptr, "Combined BTC BER/Q:  %4.2e, %5.2f\n", datap->ed_combined_btc_ber, datap->ed_combined_btc_qval);
    if( datap->ed_combined_lsb_ber != 0.0 )
        ptr += snprintf(ptr, end-ptr, "Combined LSB BER/Q:  %4.2e, %5.2f\n", datap->ed_combined_lsb_ber, datap->ed_combined_lsb_qval);

    return buf;
}

#if AAPL_ENABLE_FILE_IO
/** @brief Write the formatted BTC data to a file using the */
/**        serdes_eye_btc_format() output. */
void avago_serdes_eye_btc_write(
    FILE *file,                           /**< [in] Where to write. */
    const Avago_serdes_eye_data_t *datap) /**< [in] Populated eye data. */
{
    char *btc_string = avago_serdes_eye_btc_format(datap);
    if( btc_string )
    {
        fputs("\n",file);
        fputs(btc_string,file);
        AAPL_FREE(btc_string);
    }
}
#endif

/** @brief Write the formatted BTC data metric to the log using the */
/**        serdes_eye_btc_format() output. */
void avago_serdes_eye_btc_log_print(
    Aapl_t *aapl,                         /**< [in] */
    Aapl_log_type_t level,                /**< [in] Specify logging type. */
    const char *caller,                   /**< [in] Typically __func__, may be 0. */
    int line,                             /**< [in] Typically __LINE__, may be 0. */
    const Avago_serdes_eye_data_t *datap) /**< [in] Populated eye data. */
{
    char *btc_string = avago_serdes_eye_btc_format(datap);
    if( btc_string )
    {
        aapl_log_add(aapl, level, btc_string, caller, line);
        AAPL_FREE(btc_string);
    }
}

/** @brief   Calculate best-fit extrapolation for the VBTC (vertical bathtub curve). */
/** @details Uses the selected row of eye data, as well as datap->ed_dc_balance, */
/**          to perform a standard set of error rate extrapolations. */
/** @see     avago_serdes_eye_hbtc_extrapolate(). */
/** @return  Saves relevant results into the Avago_serdes_eye_vbtc_t structure. */
void avago_serdes_eye_vbtc_extrapolate(
    const Avago_serdes_eye_data_t *datap, /**< [in] Populated eye data. */
    int which,                            /**< [in] Which PAM4 eye to analyze [0..5] */
    int column,                           /**< [in] Column index in eye data to analyze. */
    Avago_serdes_eye_vbtc_t *results)     /**< [out] Where results are written. */
{
    Avago_least_sqr_results lower_lsr, upper_lsr;
    int data_column = column;

    memset(results,0,sizeof(*results));

    if( (which & 1) && column >= 0 ) /* Shift for odd-eye columns */
        data_column += datap->ed_x_points / 2;

    get_vertical_least_sqr(datap, which/2, data_column, results, &lower_lsr, &upper_lsr);

    results->data_column = column;
    results->total_columns = column < 0 ? 0 : datap->ed_x_UI * datap->ed_x_resolution + 1;
    results->eye_count = datap->eye_count;
    results->which = which;

    /* Indicate that results are valid: */
    results->points = MIN(results->bottom_points, results->top_points);

    /* Insure we have at least the number of points we expect: */
    if( results->bottom_points < FIT || results->top_points < FIT )
    {
        results->bottom_points = results->top_points = 0;
        return; /* Not enough data points to extrapolate */
    }

    results->Vmean = get_Vmean(datap, data_column, results->bottom_index + 1, &results->top_vmean, &results->bottom_vmean);
    results->dc_balance = datap->ed_dc_balance;
    results->avdd = datap->ed_avdd;

    results->top_rn           = (float)calc_rj(&upper_lsr);
    results->top_slope        = (float)1.0 / upper_lsr.slope;
    results->top_intercept    = (float)upper_lsr.y_intercept;
    results->top_vsig         = (float)-upper_lsr.y_intercept / upper_lsr.slope;
    results->top_R_squared    = (float)upper_lsr.Rsqr;

    results->bottom_rn        = (float)calc_rj(&lower_lsr);
    results->bottom_slope     = (float)1.0 / lower_lsr.slope;
    results->bottom_intercept = (float)lower_lsr.y_intercept;
    results->bottom_vsig      = (float)-lower_lsr.y_intercept / lower_lsr.slope;
    results->bottom_R_squared = (float)lower_lsr.Rsqr;
    results->snr              = (float)(results->top_intercept * results->top_slope - results->bottom_intercept * results->bottom_slope) / (results->top_slope - results->bottom_slope);
    if( results->snr < 0 )
        results->snr = -results->snr;   /* Insure it is not negative. */

    {
    /* Calculate the 0 and 25mV eye opening bit error rates: */
    /* */
    double proj_diff = upper_lsr.y_intercept * lower_lsr.slope - lower_lsr.y_intercept * upper_lsr.slope;
    double slope_diff = upper_lsr.slope - lower_lsr.slope;
    int sign = slope_diff > 0 ? +1 : -1;
    double y_0mV = 0.0 - proj_diff / slope_diff;
    double y_25mV = 0.0 - (proj_diff - (sign * 25) * lower_lsr.slope * upper_lsr.slope) / slope_diff;
    if( y_0mV > AVAGO_Q_CEILING )
        y_0mV = AVAGO_Q_CEILING;
    if( y_25mV > AVAGO_Q_CEILING )
        y_25mV = AVAGO_Q_CEILING;
    results->vert_ber_0mV = avago_qfunc(y_0mV);
    results->vert_ber_25mV = avago_qfunc(y_25mV);
    results->height_0mV  = (float)y_0mV;
    results->height_25mV = (float)y_25mV;

    /* Calculate the eye openings at several bit error rates: */
    /* */
    results->vert_eye_1e03 = (int)(sign * ((upper_lsr.y_intercept - q03) / upper_lsr.slope - (lower_lsr.y_intercept - q03) / lower_lsr.slope));
    results->vert_eye_1e04 = (int)(sign * ((upper_lsr.y_intercept - q04) / upper_lsr.slope - (lower_lsr.y_intercept - q04) / lower_lsr.slope));
    results->vert_eye_1e05 = (int)(sign * ((upper_lsr.y_intercept - q05) / upper_lsr.slope - (lower_lsr.y_intercept - q05) / lower_lsr.slope));
    results->vert_eye_1e06 = (int)(sign * ((upper_lsr.y_intercept - q06) / upper_lsr.slope - (lower_lsr.y_intercept - q06) / lower_lsr.slope));
    results->vert_eye_1e10 = (int)(sign * ((upper_lsr.y_intercept - q10) / upper_lsr.slope - (lower_lsr.y_intercept - q10) / lower_lsr.slope));
    results->vert_eye_1e12 = (int)(sign * ((upper_lsr.y_intercept - q12) / upper_lsr.slope - (lower_lsr.y_intercept - q12) / lower_lsr.slope));
    results->vert_eye_1e15 = (int)(sign * ((upper_lsr.y_intercept - q15) / upper_lsr.slope - (lower_lsr.y_intercept - q15) / lower_lsr.slope));
    results->vert_eye_1e17 = (int)(sign * ((upper_lsr.y_intercept - q17) / upper_lsr.slope - (lower_lsr.y_intercept - q17) / lower_lsr.slope));
    }
}

/** @brief Perform a standard set of error rate calculations using the horizontal */
/**         center row for each eye. */
static void hbtc_extrapolate(Avago_serdes_eye_data_t *datap)
{
    int which;
    for( which = 0; which < datap->eye_count; which++ )
    {
        float trans_density = datap->ed_trans_density;
        if( (datap->eye_count == 6 && (which == 2 || which == 3)) || /* Middle eye has greater trans_density than upper and lower eyes. */
            (datap->eye_count == 3 && which == 1) )
        {
            trans_density *= 4.0 / 3.0;
        }
        avago_serdes_eye_hbtc_extrapolate(datap, which&1, datap->ed_hbtc[which].data_row, trans_density, &datap->ed_hbtc[which]);
    }
}

/** @brief Perform a standard set of error rate calculations using the mission */
/**         data column of the eye data. */

static void vbtc_extrapolate_mission(Avago_serdes_eye_data_t *datap)
{
    int which;
    for( which = 0; which < datap->eye_count; which++ )
        avago_serdes_eye_vbtc_extrapolate(datap, which, -1-which, &datap->ed_vbtc[which]);

    /* PAM4: */
    if( datap->eye_count == 6 )
    {
        int i;
        for( i = 0; i < 2; i++ ) /* even, odd calculations */
        {
            datap->level_vmean[i][3] =  datap->ed_vbtc[4+i].top_vmean;
            datap->level_vmean[i][2] = (datap->ed_vbtc[2+i].top_vmean + datap->ed_vbtc[4+i].bottom_vmean) / 2.0;
            datap->level_vmean[i][1] = (datap->ed_vbtc[0+i].top_vmean + datap->ed_vbtc[2+i].bottom_vmean) / 2.0;
            datap->level_vmean[i][0] =                                  datap->ed_vbtc[0+i].bottom_vmean;

            datap->level_dn[i][3] = fabs(datap->ed_vbtc[4+i].top_vmean   - datap->ed_vbtc[4+i].top_vsig) * 2.0;
            datap->level_dn[i][2] = fabs(datap->ed_vbtc[4+i].bottom_vsig - datap->ed_vbtc[2+i].top_vsig);
            datap->level_dn[i][1] = fabs(datap->ed_vbtc[2+i].bottom_vsig - datap->ed_vbtc[0+i].top_vsig);
            datap->level_dn[i][0] = fabs(datap->ed_vbtc[0+i].bottom_vsig - datap->ed_vbtc[0+i].bottom_vmean) * 2.0;

            if( datap->level_vmean[i][3] > datap->level_vmean[i][0] )
                datap->level03_comp[i] = 20 * log10(3.0 * (datap->level_vmean[i][2] - datap->level_vmean[i][1]) / (datap->level_vmean[i][3] - datap->level_vmean[i][0]));
        }
    }
#if 1
    else if( datap->eye_count == 3 ) /* PAM4: */
    {
        datap->level_vmean[0][3] =  datap->ed_vbtc[2].top_vmean;
        datap->level_vmean[0][2] = (datap->ed_vbtc[1].top_vmean + datap->ed_vbtc[2].bottom_vmean) / 2.0;
        datap->level_vmean[0][1] = (datap->ed_vbtc[0].top_vmean + datap->ed_vbtc[1].bottom_vmean) / 2.0;
        datap->level_vmean[0][0] =                                datap->ed_vbtc[0].bottom_vmean;

        datap->level_dn[0][3] = fabs(datap->ed_vbtc[2].top_vmean   - datap->ed_vbtc[2].top_vsig) * 2.0;
        datap->level_dn[0][2] = fabs(datap->ed_vbtc[2].bottom_vsig - datap->ed_vbtc[1].top_vsig);
        datap->level_dn[0][1] = fabs(datap->ed_vbtc[1].bottom_vsig - datap->ed_vbtc[0].top_vsig);
        datap->level_dn[0][0] = fabs(datap->ed_vbtc[0].bottom_vsig - datap->ed_vbtc[0].bottom_vmean) * 2.0;

        if( datap->level_vmean[0][3] > datap->level_vmean[0][0] )
            datap->level03_comp[0] = 20 * log10(3.0 * (datap->level_vmean[0][2] - datap->level_vmean[0][1]) / (datap->level_vmean[0][3] - datap->level_vmean[0][0]));
    }
#endif
    else
    {
        datap->level_vmean[0][1] = datap->ed_vbtc[0].top_vmean;                                     /* NRZ */
        datap->level_vmean[0][0] = datap->ed_vbtc[0].bottom_vmean;
        datap->level_dn[0][1] = 2.0 * fabs(datap->ed_vbtc[0].top_vmean - datap->ed_vbtc[0].top_vsig);  /* NRZ */
        datap->level_dn[0][0] = 2.0 * fabs(datap->ed_vbtc[0].bottom_vsig - datap->ed_vbtc[0].bottom_vmean);
    }
}


/** @brief Write the VBTC data to a string. */
/** @return A character string containing the formatted VBTC results. */
/**         The caller should AAPL_FREE the returned string. */

char *avago_serdes_eye_vbtc_format(const Avago_serdes_eye_vbtc_t *vbtcp) /**< Populated VBTC structure pointer */
{
    size_t buf_len = 1000;
    char *buf = (char *)AAPL_MALLOC(buf_len);
    char *end = buf + buf_len;
    char *ptr = buf;
    double db = vbtcp->dc_balance;
    const char *even_odd = vbtcp->eye_count > 3 ? (vbtcp->which & 1) ? " odd" : " even" : "";
    int eye_base = vbtcp->which / (vbtcp->eye_count > 3 ? 2 : 1);
    if( buf == NULL )
        return buf;

    ptr += snprintf(ptr, end-ptr, "\n");
    if( vbtcp->data_column < 0 )  /* Mission channel: */
        ptr += snprintf(ptr, end-ptr, "# Vertical Bathtub Curve (mission data channel; %d..%d%s eye):\n", eye_base, eye_base+1, even_odd);
    else
        ptr += snprintf(ptr, end-ptr, "# Vertical Bathtub Curve (phase center %+d; %d..%d%s eye):\n", vbtcp->data_column - vbtcp->total_columns / 2, eye_base, eye_base+1, even_odd);
    if( vbtcp->top_points == 0 || vbtcp->bottom_points == 0 )
    {
        if( vbtcp->data_column >= -1 )
            return strncat(ptr,"\nNOTE: Insufficient data to generate vertical bathtub information.\n", end-ptr), buf;
        AAPL_FREE(buf);
        return NULL;    /* Don't print messages for columns -2 and -3. */
    }
    if( vbtcp->bottom_R_squared < 0.95 || vbtcp->top_R_squared < 0.95 ||
        vbtcp->bottom_slope <= 0.0 || vbtcp->top_slope >= 0.0 )
        ptr += snprintf(ptr, end-ptr, "#\n# WARNING: This projection is based on measurements with poor correlation.\n#\n");

    ptr += snprintf(ptr, end-ptr, "BER/%g = Q at eye height of  0 mV: %4.2e, %5.2f\n", db, vbtcp->vert_ber_0mV, vbtcp->height_0mV);
    ptr += snprintf(ptr, end-ptr, "BER/%g = Q at eye height of 25 mV: %4.2e, %5.2f\n", db, vbtcp->vert_ber_25mV, vbtcp->height_25mV);
    if( vbtcp->Vmean > 0 )
    ptr += snprintf(ptr, end-ptr, "Eye height (Vmean) at %g BER=Q(%4.2f): %4d mV\n",db,0.0,vbtcp->Vmean);
    ptr += snprintf(ptr, end-ptr, "Eye height at 1e-06 BER/%g = Q(%4.2f): %4d mV\n",db,q06,vbtcp->vert_eye_1e06);
    ptr += snprintf(ptr, end-ptr, "Eye height at 1e-10 BER/%g = Q(%4.2f): %4d mV\n",db,q10,vbtcp->vert_eye_1e10);
    ptr += snprintf(ptr, end-ptr, "Eye height at 1e-12 BER/%g = Q(%4.2f): %4d mV\n",db,q12,vbtcp->vert_eye_1e12);
    ptr += snprintf(ptr, end-ptr, "Eye height at 1e-15 BER/%g = Q(%4.2f): %4d mV\n",db,q15,vbtcp->vert_eye_1e15);
    ptr += snprintf(ptr, end-ptr, "Eye height at 1e-17 BER/%g = Q(%4.2f): %4d mV\n",db,q17,vbtcp->vert_eye_1e17);
/*  ptr += snprintf(ptr, end-ptr, "Slope bottom/top:           %6.1f,  %6.1f  mV/Q\n", vbtcp->bottom_slope, vbtcp->top_slope); */
/*  ptr += snprintf(ptr, end-ptr, "X-intercept bottom/top:     %6.1f,  %6.1f     Q\n", vbtcp->bottom_intercept, vbtcp->top_intercept); */
    ptr += snprintf(ptr, end-ptr, "Vsig bottom/top:            %6.1f,  %6.1f  mV\n", vbtcp->bottom_vsig, vbtcp->top_vsig);
    ptr += snprintf(ptr, end-ptr, "Vmean bottom/top:           %6.1f,  %6.1f  mV\n", vbtcp->bottom_vmean, vbtcp->top_vmean);
    ptr += snprintf(ptr, end-ptr, "Est RNrms bottom/top:       %6.1f,  %6.1f  mV\n", vbtcp->bottom_rn, vbtcp->top_rn);
    ptr += snprintf(ptr, end-ptr, "Voltage range:              %7.2f           V\n", vbtcp->avdd);
    ptr += snprintf(ptr, end-ptr, "Est signal noise ratio:     %7.2f\n", vbtcp->snr);
    ptr += snprintf(ptr, end-ptr, "DC balance:                 %9.4f\n", vbtcp->dc_balance);
    ptr += snprintf(ptr, end-ptr, "R-squared fit bottom/top:   %8.3f,%8.3f\n", vbtcp->bottom_R_squared, vbtcp->top_R_squared);
    ptr += snprintf(ptr, end-ptr, "No. points bottom/top:      %4u, %7u\n",vbtcp->bottom_points, vbtcp->top_points);
    ptr += snprintf(ptr, end-ptr, "Indexes bottom/top:         %4u, %7u\n",vbtcp->bottom_index,vbtcp->top_index);
    return buf;
}

/** @brief Write the formatted VBTC data to a file using the */
/**        serdes_eye_vbtc_format() output. */

#if AAPL_ENABLE_FILE_IO
void avago_serdes_eye_vbtc_write(FILE *file, const Avago_serdes_eye_vbtc_t *vbtcp)
{
    char *vbtc_string = avago_serdes_eye_vbtc_format(vbtcp);
    if( vbtc_string )
    {
        fputs("\n",file);
        fputs(vbtc_string,file);
        AAPL_FREE(vbtc_string);
    }
}
#endif

/** @brief Write the formatted VBTC data to the log using the */
/**        serdes_eye_vbtc_format() output. */

void avago_serdes_eye_vbtc_log_print(
    Aapl_t *aapl,           /**< [in] */
    Aapl_log_type_t level,         /**< [in] Specify logging type. */
    const char *caller,     /**< [in] Typically __func__, may be 0. */
    int line,               /**< [in] Typically __LINE__, may be 0. */
    const Avago_serdes_eye_vbtc_t *vbtcp)    /**< [in] Data to format and print. */
{
    char *vbtc_string = avago_serdes_eye_vbtc_format(vbtcp);
    if( vbtc_string )
    {
        aapl_log_add(aapl, level, vbtc_string, caller, line);
        AAPL_FREE(vbtc_string);
    }
}

static void calc_height(Aapl_t *aapl, Avago_serdes_eye_data_t *datap, int column)
{
    /* Note: Height calculated from the mission data: */
    int height = 0;
    const bigint *bits   = get_bits_column(datap, column);
    const bigint *errors = get_errs_column(datap, column);
    const int dac_resolution = datap->ed_y_resolution;
    uint column_points = column < 0 ? datap->ed_y_mission_points : datap->ed_y_points;
    uint column_step = column < 0 ? datap->ed_y_mission_step : datap->ed_y_step;
    uint y_point;
    for( y_point = 0; y_point < column_points; ++y_point )
    {
        bigint e = errors[y_point];
        if( e <= datap->ed_error_threshold && e >= 0 && bits[y_point] > 0 )
            height++;
    }
    datap->ed_height = height * column_step;

    /* TBD: Use measured voltage rather than assume full range of 1000 mV: */
    datap->ed_height_mV = (1000 * datap->ed_height + dac_resolution/2) / dac_resolution;
    vbtc_extrapolate_mission(datap);

    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__,"height = %u, height_mV = %u\n", datap->ed_height, datap->ed_height_mV);
    if( (aapl->debug & 0xf) >= AVAGO_DEBUG2 )
    {
        avago_serdes_eye_vbtc_log_print(aapl, AVAGO_DEBUG2, __func__, __LINE__, &datap->ed_vbtc[0]);
        if( datap->ed_vbtc[1].top_points > 0 && datap->ed_vbtc[1].bottom_points > 0 )
            avago_serdes_eye_vbtc_log_print(aapl, AVAGO_DEBUG2, __func__, __LINE__, &datap->ed_vbtc[1]);
        if( datap->ed_vbtc[2].top_points > 0 && datap->ed_vbtc[2].bottom_points > 0 )
            avago_serdes_eye_vbtc_log_print(aapl, AVAGO_DEBUG2, __func__, __LINE__, &datap->ed_vbtc[2]);
    }
}

/* Eye width and height are calculated by scanning the middle lines of the eye. */
/* Measure longest sequence of non-errors (errors <= threshold). */

/* Width scan may find multiple eyes, so use longest sequence. */
/* Sequences are separated by at least 4 bits (arbitrary value) that exceed threshold. */
static void calc_width(Aapl_t *aapl, Avago_serdes_eye_data_t *datap)
{
    int pi_resolution = datap->ed_x_resolution * datap->ed_x_step;
    int width = 0, w = 0, out = 0;
    uint y_mid = (datap->ed_y_points-1) / 2;
    uint x_point;
    for( x_point = 0; x_point < datap->ed_x_points; ++x_point )
    {
        bigint e = AVAGO_EYE_ERRORS_GET(*datap, x_point, y_mid);
        if( e <= datap->ed_error_threshold && e >= 0 )
        {
            if( out >= 4 )
            {
                width = MAX(w,width);
                w = 0;
            }
            w++;
            out = 0;
        }
        else
            out++;
    }
    datap->ed_width = MAX(w,width) * datap->ed_x_step;
    datap->ed_width_mUI = (1000 * datap->ed_width + pi_resolution/2) / pi_resolution;
    hbtc_extrapolate(datap);

    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__,"width = %u, width_mUI = %u\n", datap->ed_width, datap->ed_width_mUI);
    if( (aapl->debug & 0xf) >= AVAGO_DEBUG2 )
    {
        avago_serdes_eye_hbtc_log_print(aapl, AVAGO_DEBUG2, __func__, __LINE__, &datap->ed_hbtc[0]);
        if( datap->ed_hbtc[1].data_row < datap->ed_y_points )
            avago_serdes_eye_hbtc_log_print(aapl, AVAGO_DEBUG2, __func__, __LINE__, &datap->ed_hbtc[1]);
        if( datap->ed_hbtc[2].data_row < datap->ed_y_points )
            avago_serdes_eye_hbtc_log_print(aapl, AVAGO_DEBUG2, __func__, __LINE__, &datap->ed_hbtc[2]);
    }
}


/* Measure needed width on test channel, then adjust */
/* ed_x_points, ed_x_step and ed_x_resolution accordingly. */
static void adjust_x_scale(Eye_state_t *esp)
{
    Aapl_t *aapl = esp->aapl;
    uint    addr = esp->addr;

    int left = 0, right = 0, inside = 0;
    uint x, x_res = esp->phase_mult * 64;
    int margin = 0;

    if( !esp->configp->ec_set_phase_center )
        return; /* No horizontal scaling if not centering: */

    if( esp->phase_mult * 64 == esp->datap->ed_x_resolution )
        return; /* Already at max resolution. */

    aapl_log_printf(esp->aapl,AVAGO_DEBUG2,__func__,__LINE__,"SBus %s, BEFORE: x_resolution=%d\n",
            aapl_addr_to_str(addr), esp->datap->ed_x_resolution);

    if( !eye_set_compare_mode(esp, AVAGO_SERDES_RX_CMP_MODE_XOR)
     || avago_serdes_set_dac(aapl, addr, (esp->datap->ed_y_resolution-1)/2, /* get_errors = */ FALSE) < 0
     || !eye_set_clock_source(esp, /* test_clock = */ TRUE)
     || eye_set_error_timer(esp, AVAGO_EYE_MIN_DWELL_BITS) < 0 )
    {
        return; /* Failure */
    }

    sbm_eye_setup_point(esp);

    /* See how many points we find on each edge: */
    for( x = 0; x <= x_res && !aapl_get_async_cancel_flag(esp->aapl); x++ )
    {
        int errors;
        if( !esp->sbm_eye_gather )
            errors = eye_step_phase(esp, esp->datap->ed_x_min + x, /* get_errors = */ TRUE);
        else
        errors = sbm_eye_get_point(esp, FALSE, x - x_res/2, 0);
        /*printf("errors[%d] = %d\n",x,errors); */
        if( errors >= (int)esp->datap->ed_error_threshold )
        {
            if( inside == 0 )
                left++;
            else
                right++;
        }
        else if( inside == 0 )
        {
            x = x_res - left - 2;
            inside++;
        }
    }
    aapl_log_printf(aapl, AVAGO_DEBUG3, __func__,__LINE__,"left,inside,right = %d,%d,%d\n",left,inside,right);
    margin = MIN(left,right);
    while( esp->datap->ed_x_resolution < x_res )
    {
        aapl_log_printf(aapl, AVAGO_DEBUG4, __func__,__LINE__, "resolution,margin = %u,%d\n",x_res,margin);
        if( margin < 6 )
            break;
        x_res /= 2;
        margin /= 2;
    }
    set_x_resolution(esp, x_res);

    aapl_log_printf(esp->aapl,AVAGO_DEBUG2,__func__,__LINE__,"SBus %s, AFTER: x_resolution=%d\n",
            aapl_addr_to_str(addr), esp->datap->ed_x_resolution);
}

/* Returns point just inside the eye: */
static void find_y_edges(Eye_state_t *esp, int *upper, int *lower)
{
    if( !esp->sbm_eye_gather )
    {
        int vert_adjust = 0;
        int res = esp->datap->ed_y_resolution;
        int mid_dac = res / 2;
        eye_set_clock_source(esp, /* test_clock = */ TRUE);
        eye_set_clock_source(esp, /* test_clock = */ FALSE);

        if( esp->default_gather || esp->dq.d6_data_qual == 0xff )
        {
#if 1
            int qres = res / 4;
            int threshold = esp->threshold;
            vert_adjust = esp->vert_alpha[0] + esp->vert_alpha[1];
            *upper  = find_y_edge(esp,  qres, AVAGO_SERDES_RX_DATA_QUAL_PREV0, threshold) + mid_dac;
            *lower  = find_y_edge(esp, -qres, AVAGO_SERDES_RX_DATA_QUAL_PREV0, threshold) + mid_dac;
            *lower += find_y_edge(esp, -qres, AVAGO_SERDES_RX_DATA_QUAL_PREV1, threshold) + mid_dac;
            *upper += find_y_edge(esp,  qres, AVAGO_SERDES_RX_DATA_QUAL_PREV1, threshold) + mid_dac;
            *upper /= 2;
            *lower /= 2;
#else
            /*l,h,0,1,e,o */
            int *dvos = esp->datap->ed_dfe_state.testLEV;   /* for t0/1* values */
            *upper = (dvos[1] + dvos[3] + dvos[5] + dvos[7]) / 4 + mid_dac;
            *lower = (dvos[0] + dvos[2] + dvos[4] + dvos[6]) / 4 + mid_dac;
#endif
        }
        else
        {
#if 1
            int qres = res / 4;
            int threshold = esp->threshold;
            *upper = (int)(find_y_edge(esp,  qres, esp->dq.d6_data_qual, threshold) + mid_dac);
            *lower = (int)(find_y_edge(esp, -qres, esp->dq.d6_data_qual, threshold) + mid_dac);
            /*printf("upper, lower = %d,%d\n", *upper, *lower); */
#else
            int *dvos = esp->datap->ed_dfe_state.testLEV;   /* for t0/1* values */
            *upper = (dvos[1] + dvos[3] + dvos[5] + dvos[7]) / 4 + mid_dac;
            *lower = (dvos[0] + dvos[2] + dvos[4] + dvos[6]) / 4 + mid_dac;
#endif
            if(      esp->dq.d6_data_qual == AVAGO_SERDES_RX_DATA_QUAL_PREV0  ) vert_adjust = esp->vert_alpha[0];
            else if( esp->dq.d6_data_qual == AVAGO_SERDES_RX_DATA_QUAL_PREV1  ) vert_adjust = esp->vert_alpha[1];
            else if( esp->dq.d6_data_qual == AVAGO_SERDES_RX_DATA_QUAL_PREV0E ) vert_adjust = esp->vert_alpha[2];
            else if( esp->dq.d6_data_qual == AVAGO_SERDES_RX_DATA_QUAL_PREV0O ) vert_adjust = esp->vert_alpha[3];
            else if( esp->dq.d6_data_qual == AVAGO_SERDES_RX_DATA_QUAL_PREV1E ) vert_adjust = esp->vert_alpha[4];
            else if( esp->dq.d6_data_qual == AVAGO_SERDES_RX_DATA_QUAL_PREV1O ) vert_adjust = esp->vert_alpha[5];
            else if( (esp->dq.d6_data_qual & 0xf0) == 0x00 )
                vert_adjust = esp->vert_alpha[0];
            else if( (esp->dq.d6_data_qual & 0x0f) == 0x00 )
                vert_adjust = esp->vert_alpha[1];
        }
        if( esp->datap->ed_apply_vert_alpha )
        {
            *upper -= vert_adjust;
            *lower -= vert_adjust;
        }
    }
    else
    {
        int res = esp->datap->ed_y_resolution;
        if( sbm_eye_setup_point(esp) )
        {
            int upper_center_dac = res/2;
            int lower_center_dac = res/2;
            if( avago_serdes_get_rx_line_encoding(esp->aapl, esp->addr) )
            {
                upper_center_dac = find_m4_eye_center_offset(esp, 4) + 255;
                lower_center_dac = find_m4_eye_center_offset(esp, 0) + 255;

                eye_select(esp, 4);
                *upper  = (int)find_edge(esp, upper_center_dac, res, esp->threshold);
                eye_select(esp, 0);
                *lower  = (int)find_edge(esp, lower_center_dac,   0, esp->threshold);
            }
            else
            {
                *upper  = (int)find_edge(esp, upper_center_dac, res, esp->threshold);
                *lower  = (int)find_edge(esp, lower_center_dac,   0, esp->threshold);
            }
        }
        else
            *upper = *lower = 0;
    }
    aapl_log_printf(esp->aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, adjusted: upper=%d, lower=%d\n",
            aapl_addr_to_str(esp->addr), *upper, *lower);
}

/* Measure needed height on mission channel, then adjust */
/* ed_y_points and ed_y_step accordingly. */
static void adjust_y_scale(Eye_state_t *esp)
{
    int dac_top = 255, dac_bot = 0;
    uint dac_range = esp->datap->ed_y_resolution;
    uint dac_mid = dac_range / 2;
    uint max_range = dac_range - 1;
    uint y_points;
    int dac_half_span;

    if( !eye_set_compare_mode(esp, AVAGO_SERDES_RX_CMP_MODE_XOR)
        || !eye_set_clock_source(esp, /* test_clock = */ FALSE) )
            return;
    if( eye_set_error_timer(esp, AVAGO_EYE_MIN_DWELL_BITS) < 0 )
        return;

    aapl_log_printf(esp->aapl,AVAGO_DEBUG2,__func__,__LINE__,"BEFORE: y_points=%d, y_step=%d\n",esp->datap->ed_y_points,esp->datap->ed_y_step);

    find_y_edges(esp, &dac_top, &dac_bot); /* returns points just inside the eye */

    /* Get point farthest from center: */
    dac_half_span = dac_top - dac_mid > dac_mid - dac_bot ? (dac_top-dac_mid) : (dac_mid-dac_bot);
    /*printf("dac_half_span = %d\n", dac_half_span); */
    max_range -= abs(esp->vert_alpha[0]) + abs(esp->vert_alpha[1]);
    while( TRUE )
    {
        /* Add FIT points outside the eye, double for top and bottom halves and add center point: */
        y_points = (dac_half_span / esp->datap->ed_y_step + FIT + FIT) * 2 + 1;
        if( !esp->default_gather )
            y_points += 2 * FIT;

        /*printf("y_points = %u, max_range = %u, top = %d, bottom = %d\n",y_points, max_range, dac_top, dac_bot); */

        /* Verify that we are still in range.  If not, increase resolution: */
        if( esp->datap->ed_y_step == 1 || (y_points-1) * esp->datap->ed_y_step < max_range )
            break;
        esp->datap->ed_y_step--;
    }
    if( y_points > max_range )
        y_points = max_range;
    set_y_points(esp->datap, y_points); /* Also sets ed_y_min */

    aapl_log_printf(esp->aapl,AVAGO_DEBUG2,__func__,__LINE__,"AFTER:  y_points=%d (%d..%d), y_step=%d\n",
            esp->datap->ed_y_points,
            dac_mid-esp->datap->ed_y_points/2*esp->datap->ed_y_step,
            dac_mid+esp->datap->ed_y_points/2*esp->datap->ed_y_step,
            esp->datap->ed_y_step);

    avago_serdes_set_dac(esp->aapl, esp->addr, esp->configp->ec_y_center_point, FALSE);
}


/* Do an eye height measurement based on testLEV values. */
/* The average eye height of all the samplers will be used. */
/* Store calculated eye height into datap->ed_height. */
/* Return aapl->return_code. */

static int serdes_get_dvos_height(Aapl_t *aapl, uint addr, Avago_serdes_eye_data_t *datap)
{
    const int dac_resolution = datap->ed_y_resolution;
    int i;
    Avago_serdes_dfe_state_t *dfe = avago_serdes_dfe_state_construct(aapl);
    avago_serdes_get_dfe_state_ext(aapl, addr, dfe, AVAGO_DFE_MODE_TESTLEV);

    for( i = 0; i < 8; i++ )
        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "dfe->testLEV[%d] = %d\n", i, dfe->testLEV[i]);

    datap->ed_height = ( abs(dfe->testLEV[1] - dfe->testLEV[0])
                       + abs(dfe->testLEV[3] - dfe->testLEV[2])
                       + abs(dfe->testLEV[5] - dfe->testLEV[4])
                       + abs(dfe->testLEV[7] - dfe->testLEV[6]) + 2) / 4;

    /* TBD: Use measured voltage rather than assume full range of 1000 mV: */
    datap->ed_height_mV = (1000 * datap->ed_height + dac_resolution/2) / dac_resolution;

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "EYE_HEIGHT_DVOS: height = %u\n", datap->ed_height);
    avago_serdes_dfe_state_destruct(aapl, dfe);
    return aapl->return_code;
}

static float compare_columns(float *data_col, float *test_col, uint col_len)
{
/*  const float threshold_error = 8.0; */
    float sum_mse = 0.0;
    uint i;
    for( i = 0; i < col_len; i++ )
    {
        float diff = test_col[i] - data_col[i];
        sum_mse += diff * diff;

        #if 0
        float test = test_col[i];
        float data = data_col[i];

        if( data < threshold_error && test < threshold_error )
            diff = data - test;
        else if( data > threshold_error && test > threshold_error )
            diff = 0.0;
        else if( i > 1 && data > threshold_error && data_col[i-1] < threshold_error && data_col[i-2] < threshold_error )
            diff = 2 * data_col[i-1] - test - data_col[i-2];
        else if( i > 1 && test > threshold_error && test_col[i-1] < threshold_error && test_col[i-2] < threshold_error )
            diff = data - 2 * test_col[i-1] + test_col[i-2];
        else if( i > 0 && data > threshold_error && data_col[i-1] < threshold_error )
            diff = data_col[i-1] - test;
        else if( i > 0 && test > threshold_error && test_col[i-1] < threshold_error )
            diff = data - test_col[i-1];
        else if( i < col_len-2 && data > threshold_error && data_col[i+1] < threshold_error && data_col[i+2] < threshold_error )
            diff = 2 * data_col[i+1] - test - data_col[i+2];
        else if( i < col_len-2 && test > threshold_error && test_col[i+1] < threshold_error && test_col[i+2] < threshold_error )
            diff = data - 2 * test_col[i+1] + test_col[i+2];
        else if( i < col_len-1 && data > threshold_error && data_col[i+1] < threshold_error )
            diff = data_col[i+1] - test;
        else if( i < col_len-1 && test > threshold_error && test_col[i+1] < threshold_error )
            diff = data - test_col[i+1];
        else if( (test >= threshold_error && data <  threshold_error)
              || (test <  threshold_error && data >= threshold_error) )
            diff = 2.0;
        else
            diff = 0.0;
        #endif
    }
    return sum_mse;
}

static BOOL avago_serdes_invert_compare(Aapl_t *aapl, uint addr, BOOL invert)
{
    int value, reg_invert, invert_bit;
    Avago_serdes_mem_type_t mem_type = AVAGO_LSB;

    switch( aapl_get_sdrev(aapl,addr) )
    {
    /* Believe to be broken, but not confirmed: */
/*  case AAPL_SDREV_HVD6: reg_invert = 0x24; invert_bit = 1<<15; break; // RX_POLARITY_INVERT_COMPARE */
/*  case AAPL_SDREV_OM4: */
/*  case AAPL_SDREV_CM4_16: */
/*  case AAPL_SDREV_CM4: reg_invert = 0x18; invert_bit = 1<<2; break; // CMP_POLARITY_INV */
/*  case AAPL_SDREV_P1:  reg_invert = 0xec; invert_bit = 1<<15; break; // RX_POLARITY_INVERT */

    case AAPL_SDREV_16:
    default: return FALSE; /* Broken because new comparator doesn't support inversion of cmp input separate from overall invert. */

    /* Verified operation: */
    case AAPL_SDREV_D6:  reg_invert = 0x60; invert_bit = 1<<2; mem_type = AVAGO_ESB; break; /* RX_OFFSET_POLARITY_INVERT */
    }

    if( avago_serdes_get_rx_invert(aapl, addr) ) invert = !invert;

    value = avago_serdes_mem_rd(aapl, addr, mem_type, reg_invert);
    avago_serdes_mem_rmw(aapl, addr, mem_type, reg_invert, invert ? ~0 : 0, invert_bit);
/*printf("old = 0x%x, new = 0x%x\n", value, avago_serdes_mem_rd(aapl, addr, mem_type, reg_invert)); */
    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus %s, invert=%s\n", aapl_addr_to_str(addr), aapl_onoff_to_str(value & invert_bit));
    return TRUE;
}

static BOOL get_qval_column_any(
    Eye_state_t *esp,
    int which,
    BOOL mission,
    int phase,
    uint dac_begin,
    uint dac_step,
    uint dac_end,
    const char *dq_lower,
    const char *dq_upper,
    bigint dwell_bits,
    float *qval_col,
    uint col_len)
{
    Aapl_t *aapl = esp->aapl;
    uint alloc_size = sizeof(bigint) * col_len;
    bigint *bits = (bigint *)memset(aapl_malloc(aapl, alloc_size, "bits"), 0, alloc_size);
    bigint *errs = (bigint *)memset(aapl_malloc(aapl, alloc_size, "errs"), 0, alloc_size);
    bigint *ners = 0;
    uint reg_prbs = aapl_get_ip_type(aapl,esp->addr) == AVAGO_P1 ? 0xf2 : 0x2a;
    uint old_prbs = avago_serdes_mem_rmw(aapl, esp->addr, AVAGO_LSB, reg_prbs, 0x0, 1<<5);  /* Disable RX_PRBS_AUTO_SEED_CORRECT */
    BOOL status = FALSE, invert_compare;

    if( !bits || !errs ) goto cleanup_qval_column_any;

    memset(bits, 0, alloc_size);
    memset(errs, 0, alloc_size);

    /* Enable special mode gathering that avoids compounding of errors when comparing large error counts with differing bits compared counts. */
    esp->enable_not_errors = aapl_get_sdrev(aapl, esp->addr) != AAPL_SDREV_D6;

    status = gather_column(esp, which, mission, phase, dac_begin, dac_step, dac_end, errs, bits, dq_lower, dq_upper);

    invert_compare = avago_serdes_invert_compare(aapl, esp->addr, TRUE);

    if( status && invert_compare )    /* If functionality is supported */
    {
        ners = (bigint *)aapl_malloc(aapl, alloc_size, "ners");
        if( !ners ) goto cleanup_qval_column_any;
        memset(ners, 0, alloc_size);
        status = gather_column(esp, which, mission, phase, dac_begin, dac_step, dac_end, ners, bits, dq_lower, dq_upper);
        avago_serdes_invert_compare(aapl, esp->addr, FALSE);
    }
    esp->enable_not_errors = FALSE;


    if( old_prbs & (1<<5) ) /* Restore RX_PRBS_AUTO_SEED_CORRECT value: */
        avago_serdes_mem_wr(aapl, esp->addr, AVAGO_LSB, reg_prbs, old_prbs);

    /* printf("curr_dwell = %s\n", aapl_bigint_to_str(esp->curr_dwell)); */
    /* printf("Invert Compare = %d\n", invert_compare); */
    if( status )
    {
        double d_bits = dwell_bits;
        uint i;
        /* printf("dwell_bits = %s, curr_dwell=%s\n", aapl_bigint_to_str(dwell_bits), aapl_bigint_to_str(esp->curr_dwell)); */
        for( i = 0; i < col_len; i++ )
        {
            double BER;
            if( !invert_compare || errs[i] <= ners[i] )
            {
                if(      errs[i] == 0              ) errs[i] = 1;
                else if( errs[i] >  dwell_bits*4/5 ) errs[i] = dwell_bits - 1;
                BER = errs[i] / d_bits;
                qval_col[i] = avago_qfuncinv(BER);
              /*aapl_log_printf(aapl, AVAGO_DEBUG0, 0, __LINE__, "%3d: %6s/%s = %f = %6.2f Q\n", i, aapl_bigint_to_str(errs[i]), aapl_bigint_to_str(bits[i]), BER, qval_col[i]); */
            }
            else
            {
                if(      ners[i] == 0              ) ners[i] = 1;
                else if( ners[i] >  dwell_bits*4/5 ) ners[i] = dwell_bits*4/5;
                BER = ners[i] / d_bits;
                qval_col[i] = - avago_qfuncinv(BER);
              /*printf("%3d: [%6s|%6s]/%s = %f = %6.2f Q\n", i, aapl_bigint_to_str(errs[i]), aapl_bigint_to_str(ners[i]), aapl_bigint_to_str(bits[i]), BER, qval_col[i]); */
            }
        }
    }

cleanup_qval_column_any:
    if( ners ) aapl_free(aapl, ners, "ners");
    if( errs ) aapl_free(aapl, errs, "errs");
    if( bits ) aapl_free(aapl, bits, "bits");
    return status;
}

/** @brief  Gathers modified Q values for a column. */
/** @return TRUE on success, FALSE on failure. */
static BOOL get_qval_column_nrz(
    Eye_state_t *esp,
    BOOL mission,
    int phase,
    float *qval_col,
    uint col_len)
{
    int dac_begin = esp->datap->ed_y_center_point - col_len / 2;
    int dac_step = 1;
    int dac_end = dac_begin + col_len;
    BOOL rx_inverted = avago_serdes_get_rx_invert(esp->aapl, esp->addr);
    const char *dq_lower = rx_inverted ? "110" : "001";
    const char *dq_upper = rx_inverted ? "100" : "011";
    bigint dwell_bits = esp->curr_dwell / 4;
    if( aapl_get_sdrev(esp->aapl, esp->addr) != AAPL_SDREV_D6 )
        dq_lower = dq_upper = "0x1";
    return get_qval_column_any(esp, 0, mission, phase, dac_begin, dac_step, dac_end, dq_lower, dq_upper, dwell_bits, qval_col, col_len);
}

#define MAX_CENTER_SHIFT (20)
#define PRINT_TABLE 1
#define STOP_PAST (2)
#define TABLE_DEBUGN AVAGO_DEBUG2

#if ADJUST_CM4_PHASE_CENTER
static BOOL get_qval_column_m4(
    Eye_state_t *esp,
    BOOL mission,
    int phase,
    int which,
    float *qval_col,
    uint col_len)
{
    int dac_begin = esp->datap->ed_y_center_point + find_m4_eye_center_offset(esp,which) - col_len / 2;
    int dac_step = 1;
    int dac_end = dac_begin + col_len;
    const char *dq_str;
    bigint dwell_bits = esp->curr_dwell / 32;
    BOOL rx_inverted = avago_serdes_get_rx_invert(esp->aapl, esp->addr);

    switch( which )
    {
    case 5: dq_str = rx_inverted ? "0[01]3,lsb,odd"  : "3[23]0,lsb,odd";  break;
    case 4: dq_str = rx_inverted ? "0[01]3,lsb,even" : "3[23]0,lsb,even"; break;
    case 3: dq_str = rx_inverted ? "3[12]0,msb,odd"  : "0[12]3,msb,odd";  break;
    case 2: dq_str = rx_inverted ? "3[12]0,msb,even" : "0[12]3,msb,even"; break;
    case 1: dq_str = rx_inverted ? "3[23]0,lsb,odd"  : "0[01]3,lsb,odd";  break;
    case 0: dq_str = rx_inverted ? "3[23]0,lsb,even" : "0[01]3,lsb,even"; break;
    default: return FALSE;
    }
    aapl_log_printf(esp->aapl, AVAGO_DEBUG2, __func__, __LINE__, "phase = %d, which = %d, {%d..%d..%d}, dq_str = %s\n", phase, which, dac_begin, dac_step, dac_end, dq_str);

    return get_qval_column_any(esp, which, mission, phase, dac_begin, dac_step, dac_end, dq_str, dq_str, dwell_bits, qval_col, col_len);
}

static int find_m4_column_alignment(Eye_state_t *esp, int which)
{
    Aapl_t *aapl         = esp->aapl;
    int save_dwell_scale = esp->dwell_scale;
    int eye_shift        = 0;
    int direction        = (AVAGO_M4 == aapl_get_ip_type(esp->aapl, esp->addr)) ? 1 : -1;
    int orig_direction   = direction;
    int stop             = STOP_PAST;
    int tunerow2         = find_tune_row(esp, 4);
    int tunerow1         = find_tune_row(esp, 2);
    int tunerow0         = find_tune_row(esp, 0);
    int col_len          = (tunerow2 - tunerow0) * (int)esp->datap->ed_y_step * 3 / 5;
    int phase_center     = esp->datap->ed_x_center[which];
    float least_error    = 1000000.0;  /* A very large value */
    float *data_col, *test_col;
    uint i;
#if PRINT_TABLE
    int min_test_col = MAX_CENTER_SHIFT, max_test_col = MAX_CENTER_SHIFT;
    uint test_size = col_len * sizeof(float) * (MAX_CENTER_SHIFT * 2 + 1);
#else
    uint test_size = col_len * sizeof(float);
#endif

    if( esp->configp->ec_set_phase_center <= 1 )
        return 0;

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "col_len = %d, %d, %d, %d\n", col_len, tunerow0, tunerow1, tunerow2);

    if( col_len <= 10 ) return 0;

    esp->dwell_scale = 2;
    if( !eye_set_compare_mode(esp, AVAGO_SERDES_RX_CMP_MODE_XOR)
        || eye_set_error_timer(esp, AVAGO_EYE_DEF_DWELL_BITS) < 0 )
        return 0;

    /* Adjust test delay to match corresponding data sampler's delay: */
    eye_set_delay(esp, 0x0c - (which&1), esp->datap->delay[which]);

    /* Gather the mission data: */
    data_col = (float *)aapl_malloc(aapl, col_len * sizeof(float), "data_col");
    test_col = (float *)aapl_malloc(aapl, test_size, "test_col");
    if( !get_qval_column_m4(esp, TRUE, 0, which, data_col, col_len) )
        return 0;

    /* Iterate over the test data until we find the "best" match: */
    for( i = 0; i < MAX_CENTER_SHIFT; i++ )
    {
        int offset = i * direction;
        int phase = phase_center + offset;
        float error;
#if PRINT_TABLE
        int column = MAX_CENTER_SHIFT + offset;
        if(      min_test_col > column )
                 min_test_col = column;
        else if( max_test_col < column )
                 max_test_col = column;

#else
        const uint column = 0;
#endif

        /* Gather test column: */
        if( !get_qval_column_m4(esp, FALSE, phase, which, &test_col[column * col_len], col_len) )
            break;

        /* Compare test and data columns: */
        error = compare_columns(data_col, &test_col[column * col_len], col_len);

        /* Evaluate: */
        if( error < least_error )
        {
            least_error = error;
            eye_shift = offset;
            stop = STOP_PAST + (offset > 0 ? offset : -offset);
        }
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Error = %6.2f @ %2d\n", error, offset);

        if( offset * direction == stop )
        {
            i = 0;
            direction *= -1;
            if( stop > STOP_PAST || direction == orig_direction )
                break;
            stop = STOP_PAST;
        }
    }

#if PRINT_TABLE
    if( (aapl->debug & 0xf) >= TABLE_DEBUGN )
    {
        int y;
        const char *eye_position = which == 0 ? "lower" : which == 1 ? "middle" : "upper";
        int dac_begin = esp->datap->ed_y_center_point + find_m4_eye_center_offset(esp,which) - col_len / 2;
        aapl_log_printf(aapl,TABLE_DEBUGN,__func__,__LINE__,"Columns: Mission Test[%d..%d]; selected = %d, for %s eye, y=[%d..%d].\n", phase_center + (min_test_col - MAX_CENTER_SHIFT), phase_center + (max_test_col - MAX_CENTER_SHIFT), phase_center + eye_shift, eye_position, dac_begin, dac_begin+col_len-1);
        for( y = 0; y < col_len; y++ )
        {
            int i;
            aapl_log_printf(aapl,TABLE_DEBUGN,__func__,__LINE__,"%3u: %6.2f", y, data_col[y]);
            for( i = min_test_col; i <= max_test_col; i++ )
                aapl_log_printf(aapl,TABLE_DEBUGN,0,0," %6.2f", test_col[i*col_len + y]);
            aapl_log_printf(aapl,TABLE_DEBUGN,0,0,"\n");
        }
    }
#endif

    aapl_free(aapl, test_col, "test_col");
    aapl_free(aapl, data_col, "data_col");

    esp->dwell_scale = save_dwell_scale;
    eye_set_error_timer(esp, AVAGO_EYE_MIN_DWELL_BITS);
    esp->datap->ed_x_center[which] += eye_shift;
    aapl_log_printf(esp->aapl, AVAGO_DEBUG1, __func__, __LINE__, "EYE CENTER[%d] = %d + %d = %d  Least Square Error = %6.2f\n", which, phase_center, eye_shift, esp->datap->ed_x_center[which], least_error);
    return eye_shift;
}

static int avago_serdes_adjust_phase_center_m4(Eye_state_t *esp)
{
    int i, sum;
    for( i = 0, sum = 0; i < 6; i++ )
        sum += find_m4_column_alignment(esp, i);
    return sum / 6;
}
#endif /* ADJUST_CM4_PHASE_CENTER */

static int avago_serdes_adjust_phase_center_nrz(Eye_state_t *esp)
{
    Aapl_t *aapl         = esp->aapl;
    int save_dwell_scale = esp->dwell_scale;
    int eye_shift        = 0;
    int direction        = (AVAGO_M4 == aapl_get_ip_type(esp->aapl, esp->addr)) ? 1 : -1;
    int orig_direction   = direction;
    int stop             = STOP_PAST;
    uint col_len         = esp->datap->ed_y_resolution * 5 / 6;
    int phase_center     = (esp->datap->ed_x_min + esp->datap->ed_x_max) / 2;
    float least_error    = 1000000.0;  /* A very large value */
    float *data_col, *test_col;
    int i;
#if PRINT_TABLE
    int min_test_col = MAX_CENTER_SHIFT, max_test_col = MAX_CENTER_SHIFT;
    uint test_size = col_len * sizeof(float) * (MAX_CENTER_SHIFT * 2 + 1);
#else
    uint test_size = col_len * sizeof(float);
#endif

    if( esp->configp->ec_set_phase_center <= 1 )
        return 0;

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "col_len = %u\n", col_len);

    esp->dwell_scale = 2;
    data_col = (float *)aapl_malloc(aapl, col_len * sizeof(float), "data_col");
    test_col = (float *)aapl_malloc(aapl, test_size, "test_col");

    if( !eye_set_compare_mode(esp, AVAGO_SERDES_RX_CMP_MODE_XOR)
        || eye_set_error_timer(esp, AVAGO_EYE_DEF_DWELL_BITS) < 0 )
        goto phase_center_nrz_cleanup;

    /* Gather the mission data: */
    if( !get_qval_column_nrz(esp, TRUE, phase_center, data_col, col_len) )
        goto phase_center_nrz_cleanup;


    /* Iterate over the test data until we find the "best" match: */
    for( i = 0; i < MAX_CENTER_SHIFT; i++ )
    {
        int offset = i * direction;
        int phase = phase_center + offset;
        float error;
#if PRINT_TABLE
        int column = MAX_CENTER_SHIFT + offset;
        if(      min_test_col > column )
                 min_test_col = column;
        else if( max_test_col < column )
                 max_test_col = column;

#else
        const uint column = 0;
#endif

        /* Gather test column: */
        if( !get_qval_column_nrz(esp, FALSE, phase, &test_col[column * col_len], col_len) )
            break;

        /* Compare test and data columns: */
        error = compare_columns(data_col, &test_col[column * col_len], col_len);

        /* Evaluate: */
        if( error < least_error )
        {
            least_error = error;
            eye_shift = offset;
            stop = STOP_PAST + i;
        }
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Error = %6.2f @ %2d\n", error, offset);

        if( i == stop )
        {
            if( direction != orig_direction || i >= STOP_PAST*2 )
                break;
            direction *= -1;
            i = 0;
            stop = STOP_PAST;
        }
    }

#if PRINT_TABLE
    if( (aapl->debug & 0xf) >= TABLE_DEBUGN )
    {
        uint y;
        aapl_log_printf(aapl,TABLE_DEBUGN,__func__,__LINE__,"Columns: Mission Test[%d..%d]; selected = %d\n", phase_center + (min_test_col - MAX_CENTER_SHIFT), phase_center + (max_test_col - MAX_CENTER_SHIFT), phase_center + eye_shift);
        for( y = 0; y < col_len; y++ )
        {
            int i;
            aapl_log_printf(aapl,TABLE_DEBUGN,__func__,__LINE__,"%3u: %6.2f", y, data_col[y]);
            for( i = min_test_col; i <= max_test_col; i++ )
                aapl_log_printf(aapl,TABLE_DEBUGN,0,0," %6.2f", test_col[i*col_len + y]);
            aapl_log_printf(aapl,TABLE_DEBUGN,0,0,"\n");
        }
    }
#endif


phase_center_nrz_cleanup:
    if( test_col ) aapl_free(aapl, test_col, "test_col");
    if( data_col ) aapl_free(aapl, data_col, "data_col");


    esp->dwell_scale = save_dwell_scale;
    eye_set_error_timer(esp, AVAGO_EYE_MIN_DWELL_BITS);
    esp->datap->ed_x_center[0] = phase_center + eye_shift;
    aapl_log_printf(esp->aapl, AVAGO_DEBUG1, __func__, __LINE__, "EYE CENTER = %d + %d = %d  Least Square Error = %6.2f\n", phase_center, eye_shift, esp->datap->ed_x_center[0], least_error);
    return eye_shift;
}

/** @brief   Measures relative alignment of test and data channel. */
/** @details Routine phase centering determines the rclk clock eye edges and */
/**          assumes the eye center is midway between them.  However, due to */
/**          non-linearities in the rclk, clock signal delays and circuit */
/**          variations, the rclk driven test sampler center may be somewhat */
/**          offset from the data sampler. */
/** @return  Returns the offset of the data channel center from the test center in phase steps. */
static int avago_serdes_adjust_phase_center(Eye_state_t *esp)
{
    int sdrev = aapl_get_sdrev(esp->aapl, esp->addr);

    if( sdrev == AAPL_SDREV_P1 || sdrev == AAPL_SDREV_PON )
        return 0;   /* Auto centered. */

    if( esp->datap->eye_count % 3 == 0 )    /* PAM4 */
        return avago_serdes_adjust_phase_center_m4(esp);

    return avago_serdes_adjust_phase_center_nrz(esp);
}


/** @brief  Verifies valid parameters are passed in and SerDes is in state to gather an eye. */
/** @return Returns 0 on success, < 0 on failure. */
static int verify_eye_parameters(
    Aapl_t *aapl,                             /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                /**< [in] SBus slice address. */
    const Avago_serdes_eye_config_t *configp) /**< [in] Configuration parameters for how to gather the eye. */
{
    /* Warn if error state exists on entrance: */
    int ret = aapl_get_return_code(aapl);
    if( ret < 0 )
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "found aapl->return_code negative (%d) implying a prior error; value cleared\n",ret);

    if( configp->ec_gather_mean && (configp->ec_mean_direction > 0) && configp->ec_no_sbm )
        return aapl_fail(aapl, __func__, __LINE__,
            "SBus %s, Mean eye measurement with direction requires a SBus Master support\n",
            aapl_addr_to_str(addr));

    /* Check for supported process and slice types: */
    if( !(   aapl_check_process(aapl, addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28)
          && aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1)) )
    {
        return -1;
    }

    /* If pre-0x1049 firmware revision, must have a xx4x build: */
    if( !aapl_check_firmware_rev(aapl, addr, __func__, __LINE__, FALSE, 1, 0x1049) )
    {
        uint build_id = aapl_get_firmware_build(aapl, addr);
        if( 0 == (build_id & 0x0040) )
            return aapl_fail(aapl, __func__, __LINE__,
                "SBus %s, Eye measurement requires a _xx4x build in pre-0x1049 firmware, current is 0x%04X_%04X\n",
                aapl_addr_to_str(addr), aapl_get_firmware_rev(aapl, addr), build_id);
    }

    if( configp->ec_cmp_mode == AVAGO_SERDES_RX_CMP_MODE_TEST_PATGEN
        && aapl_get_ip_type(aapl, addr) == AVAGO_M4
        && avago_serdes_get_rx_line_encoding(aapl, addr) )
    {
        aapl_log_printf(aapl, AVAGO_WARNING, __func__,__LINE__, "TEST_PATGEN compare mode is not supported for all PAM4 data path configurations.\n");
    }

    if( configp->ec_eye_type > AVAGO_EYE_HEIGHT_DVOS )
    {
        return aapl_fail(aapl, __func__, __LINE__,
            "Avago_serdes_eye_config_t->ec_eye_type value (%d) is out-of-range.\n",
            configp->ec_eye_type);
    }
    {
        Avago_serdes_rx_clocks_t clocks;
        avago_serdes_rx_clock_read(aapl, addr, &clocks);
        if( clocks.data == AVAGO_SERDES_RX_CLOCK_R || clocks.edge == AVAGO_SERDES_RX_CLOCK_R || clocks.dfe == AVAGO_SERDES_RX_CLOCK_R )
        {
            if( configp->ec_eye_type != AVAGO_EYE_HEIGHT )
                return aapl_fail(aapl, __func__,__LINE__,"Can only capture eye height when rclk is used for data or edge detection.\n");

            /* This clause may not be necessary if SBM firmware can be told to skip centering, which is possible starting with 0x101F. */
            if( !configp->ec_no_sbm )  /* SBM will use rotated clock, which we don't want to disturb */
                return aapl_fail(aapl, __func__,__LINE__,"Cannot use SBM acceleration when rclk is used for data or edge detection.\n");
        }
        if( aapl_get_ip_type(aapl,addr) == AVAGO_M4 && aapl_check_firmware_rev(aapl,addr, __func__, __LINE__, FALSE, 1, 0x1071) && avago_serdes_get_rx_input_loopback(aapl, addr) )
            return aapl_fail(aapl, __func__,__LINE__,"Cannot capture eye on CM4 in ILB mode with firmware >= 0x1071.\n");
    }
    aapl_log_printf(aapl, AVAGO_DEBUG3, __func__,__LINE__,"returning success\n");
    return 0;
}

/** @brief Moves SBM, if being used, to center of eye (from its perspective), */
/**        then moves the phase to be (outside of the SBM knowledge) to the read center phase location. */
/**        Effectively this sets the SBM center to the FW determined center. */
static void sync_phase(Eye_state_t *esp)
{
    Aapl_t *aapl = esp->aapl;
    uint addr    = esp->addr;

    if( esp->sbm_eye_gather )
    {
        /* Set phase to what SBM believes it is: */
        bigint xx;
        sbm_eye_gather_data(esp, EYE_GATHER_COLUMN, &xx, &xx, 1, 1);    /* Position SBM to center of eye. */
        {
        int sbm_phase = (short)avago_spico_int(aapl, avago_make_sbus_master_addr(addr), 0x2F, 0x26);
        esp->curr_phase = avago_serdes_get_phase(aapl, addr);   /* Sync local state with changes made by SBM. */
        eye_step_phase(esp, sbm_phase, FALSE);
        }
    }
}

/** @brief Sets ed_x_min and ed_x_max for the eye center. */
static void set_eye_center(Eye_state_t *esp)
{
    Avago_serdes_eye_data_t *datap = esp->datap;
    Aapl_t *aapl = esp->aapl;
    uint    addr = esp->addr;
    int i, eye_center = 0;
    BOOL adjust_center = TRUE;
    int sdrev = aapl_get_sdrev(aapl, addr);

    (void ) addr;
    (void ) adjust_center;

    if( esp->configp->ec_eye_type == AVAGO_EYE_HEIGHT )
        return; /* Centering not needed */

    if( esp->configp->ec_set_phase_center )
    {
        int fw_rev   = aapl_get_firmware_rev(aapl, addr);
        int fw_eng   = avago_firmware_get_engineering_id(aapl, addr);
        int fw_build = aapl_get_firmware_build(aapl, addr);
        BOOL is_newer_16nm_pcie = fw_build == 0x2347 && ((fw_rev&0xff) > 0x83 || ((fw_rev&0xff) == 0x83 && fw_eng >= 2) || ((fw_rev&0xff) == 0x80 && fw_eng >= 0x50));
        if( !esp->sbm_eye_gather || sdrev == AAPL_SDREV_D6_07 || is_newer_16nm_pcie )
        {
            if( sdrev == AAPL_SDREV_D6_07 )
            {
                int pi = 0x84a;
                eye_set_clock_source(esp, FALSE);
                eye_set_clock_source(esp, TRUE);
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Absolute Center:  %3d\n", (short)avago_spico_int(aapl, addr, 0x125, 0x2000));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Virtual Center:   %3d\n", (short)avago_spico_int(aapl, addr, 0x025, 0x2000));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi (0x%3x)      = %3d\n", pi,(short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+0));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_temp         = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+1));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_center       = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+2));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_total        = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+3));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_two_ui_range = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+4));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_step         = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+5));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_ui           = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+6));
                avago_spico_int(aapl, addr, 0x25, 0x4000);  /* Set phase to center of eye */
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Absolute Center:  %3d\n", (short)avago_spico_int(aapl, addr, 0x125, 0x2000));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Virtual Center:   %3d\n", (short)avago_spico_int(aapl, addr, 0x25, 0x2000));
            }
            /* Code for 16nm PCIe gen4 SerDes with Lane Margining hardware and associated firmware support: */
            else if( is_newer_16nm_pcie )
            {
                int pi = 0x1e6;
                eye_set_clock_source(esp, FALSE);
                eye_set_clock_source(esp, TRUE);
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Absolute Center:  %3d\n", (short)avago_spico_int(aapl, addr, 0x125, 0x0200));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Virtual Center:   %3d\n", (short)avago_spico_int(aapl, addr, 0x025, 0x0200));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi (0x%3x)      = %3d\n", pi, (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_temp         = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, ++pi));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_center       = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, ++pi));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_total        = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, ++pi));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_two_ui_range = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, ++pi));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_step         = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, ++pi));
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_ui           = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, ++pi));
            }

            if( !esp->sbm_eye_gather && ((esp->configp->ec_centering_options & 1) || (!is_newer_16nm_pcie && sdrev != AAPL_SDREV_D6_07)) )
                eye_center = avago_serdes_find_phase_center(aapl, addr, &datap->ed_phase_center_log);
            else
                eye_center = 0; /* Use a virtual center. */

            /* Synchronize state with firmware: */
            esp->curr_phase = avago_serdes_get_phase(aapl, addr);
            esp->cmp_mode = avago_serdes_get_rx_cmp_mode(aapl, addr);
            aapl_str_to_data_qual("xxx,msb", &esp->dq);
            avago_serdes_set_error_timer(aapl, addr, esp->real_dwell);

            /* Force sync of clock state: */
            esp->curr_clock_is_test = !esp->curr_clock_is_test;
            eye_set_clock_source(esp, !esp->curr_clock_is_test);
        }

        /* If we have centering in FW/HW, then we need to synchronize */
        if( sdrev == AAPL_SDREV_D6_07 || is_newer_16nm_pcie )
        {
            sync_phase(esp);
            eye_step_phase(esp, 0, FALSE);
            if( is_newer_16nm_pcie )
            {
                /*adjust_center = FALSE; */
                datap->ed_x_sbm_center = (short)avago_spico_int(aapl, addr, 0x0125, 0x0200);    /* V1 get center phase */
            }
            else
            {
                /*adjust_center = FALSE; */
                datap->ed_x_sbm_center = (short)avago_spico_int(aapl, addr, 0x0125, 0x2000);    /* V2 get center phase */
            }
        }
    }

    for( i = 0; i < datap->eye_count; i++ )
        datap->ed_x_center[i] = eye_center + datap->ed_x_shift;
    for( i = datap->eye_count; i < AAPL_ARRAY_LENGTH(datap->ed_x_center); i++ )
        datap->ed_x_center[i] = 0;

    if( adjust_center )
    {
        set_x_center(datap, eye_center);
        eye_center += avago_serdes_adjust_phase_center(esp);
    }

    set_x_center(datap, eye_center + datap->ed_x_shift);
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__,__LINE__,"eye_center = %d, curr_phase = %d, hw_phase = %d\n", (datap->ed_x_min + datap->ed_x_max) / 2, esp->curr_phase, avago_serdes_get_phase(aapl, addr));
}

/** return 0 on success, < 0 on failure. */
static int initialize_for_eye_gather(
    Aapl_t *aapl,                             /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                /**< [in] SBus slice address. */
    Eye_state_t *esp,                         /**< [in,out] Eye gathering state structure. */
    const Avago_serdes_eye_config_t *configp, /**< [in] Configuration parameters for how to gather the eye. */
    Avago_serdes_eye_data_t *datap)           /**< [out] Where to save the gathered eye data. */
{
    /* Save DFE state and pause DFE tuning, then wait on any in progress tune: */
    uint dfe_resume_status = 0;
    if( avago_serdes_dfe_pause(aapl, addr, &dfe_resume_status) == -1 && avago_serdes_dfe_wait(aapl, addr) == 0 )
        return aapl_fail(aapl,__func__,__LINE__,"EYE coordination with running DFE failed.\n");

    if( !init_eye_state(esp, aapl, addr, configp, datap) )
        return aapl_fail(aapl, __func__, __LINE__, "Error initializing hardware: returning %d\n",aapl->return_code);

    esp->dfe_resume_status = dfe_resume_status; /* Can't set until after initialization above */

    if( 0 != eye_set_error_timer(esp, AVAGO_EYE_DEF_DWELL_BITS) )
        return -1;

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Centering in: SBus %s, x_UI=%u, x_points=%u, x_step=%u, x_res=%d, x_min=%d; x_center=%d, y_points=%u, y_step=%u, y_min=%d; y_center=%d\n",
            aapl_addr_to_str(addr), datap->ed_x_UI, datap->ed_x_points, datap->ed_x_step, datap->ed_x_resolution, datap->ed_x_min, (datap->ed_x_min+datap->ed_x_max)/2,
            datap->ed_y_points, datap->ed_y_step, datap->ed_y_min, datap->ed_y_center_point);

    /* Do this before eye centering and after above vars are set: */
    sbm_eye_setup_serdes(esp);  /* Do this once */
    set_eye_center(esp);

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Centering out:SBus %s, x_UI=%u, x_points=%u, x_step=%u, x_res=%d, x_min=%d; x_center=%d, y_points=%u, y_step=%u, y_min=%d; y_center=%d\n",
            aapl_addr_to_str(addr), datap->ed_x_UI, datap->ed_x_points, datap->ed_x_step, datap->ed_x_resolution, datap->ed_x_min, (datap->ed_x_min+datap->ed_x_max)/2,
            datap->ed_y_points, datap->ed_y_step, datap->ed_y_min, datap->ed_y_center_point);

    eye_set_compare_mode(esp, datap->ed_cmp_mode);
    eye_set_data_qual(esp, datap->ed_data_qual);

    if( configp->ec_y_auto_scale && configp->ec_eye_type != AVAGO_EYE_WIDTH )
        adjust_y_scale(esp);
    if( configp->ec_x_auto_scale && configp->ec_eye_type != AVAGO_EYE_HEIGHT )
        adjust_x_scale(esp);

    eye_set_compare_mode(esp, datap->ed_cmp_mode);
    eye_set_data_qual(esp, datap->ed_data_qual);

    /* Find the eye centers: */
    if( datap->eye_count == 6 ) /* Only for M4, for now. */
    {
        int i;
        for( i = 0; i < datap->eye_count; i++ )
            datap->ed_hbtc[i].data_row = find_tune_row(esp,i);
        datap->ed_x_points = datap->ed_x_points * 2;    /* Double for even/odd gathers. */
    }
    else
        datap->ed_hbtc[0].data_row = (datap->ed_y_points-1) / 2;

    if( allocate_eye_arrays(aapl, datap) < 0 )
        return -1;

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "AutoScale out:SBus %s, x_UI=%u, x_points=%u, x_step=%u, x_res=%d, x_min=%d; x_center=%d, y_points=%u, y_step=%u, y_min=%d; y_center=%d\n",
            aapl_addr_to_str(addr), datap->ed_x_UI, datap->ed_x_points, datap->ed_x_step, datap->ed_x_resolution, datap->ed_x_min, (datap->ed_x_min+datap->ed_x_max)/2,
            datap->ed_y_points, datap->ed_y_step, datap->ed_y_min, datap->ed_y_center_point);

    if( aapl->return_code < 0 )
        return -1;

    return 0;
}

static int force_mean_eye_points(Avago_serdes_eye_data_t *datap)
{
/* moved ifdef here and commented out calling ifdefs to make test_aapl_defines.sh happy */
#if defined(MEAN_EYE_FORCE_GATHER) || defined(MEAN_EYE_FORCE_READ)
    /* process test channel data: */
    if( datap->ed_x_points > 1 )
    {
        uint x;
        for( x = 0; x < datap->ed_x_points; ++x )
        {
            /* for each column, find points that bracket the 50% error point */
            uint y;
            uint y1;
            bigint last_diff;

            const bigint *errs = get_errs_column(datap, x);
            const bigint *bits = get_bits_column(datap, x);

            /* assume all samples are same */
            /* assume qualified pattern, so samples is 1/8 possible, */
            /* and we want 50% point or 1/2, so divide bits by 16 */
            bigint thresh = bits[0] / 16;

            /* find points around 50% error */
            y1 = 0;
            last_diff = errs[0] - thresh;
            for( y = 1; y < datap->ed_y_points; ++y ) {
                BOOL sign_change = FALSE;
                bigint this_diff;

                this_diff = errs[y] - thresh;
                if (this_diff > 0 && last_diff < 0) sign_change = TRUE;
                if (this_diff < 0 && last_diff > 0) sign_change = TRUE;
                /*printf("%3u, %3u, %8s, %8s:  %8s, %8s - %d\n", x, y, aapl_bigint_to_str(errs[y]), aapl_bigint_to_str(bits[y]), aapl_bigint_to_str(thresh), aapl_bigint_to_str(this_diff), sign_change); */

                if (sign_change) {
                    /* found a 50% set, clear previous points up to this set */
                    for( ; y1 < (y-1); ++y1 ) {
                            AVAGO_EYE_ERRORS_SET(*datap,x,y1,0);
                    }
                    y1 += 2; /* skip ahead of 50% set */
                }
                last_diff = this_diff;
            }

            /* clear rest points */
            for(  ; y1 < datap->ed_y_points; ++y1 ) {
                AVAGO_EYE_ERRORS_SET(*datap,x,y1,0);
            }
        }
    }
#endif /* MEAN_EYE_FORCE_GATHER || MEAN_EYE_FORCE_READ */
    return 0;
}

/** @brief Copy from mission[which] to x_mid,ystart..y_end. */
static void copy_mission_column_to_data(Avago_serdes_eye_data_t *datap, int which, int x_mid, int y_start, int y_end)
{
    int y;
    /*printf("%d: which=%d; x_mid = %d, y_start = %d, y_end = %d, y_points = %u\n", __LINE__, which, x_mid, y_start, y_end, datap->ed_y_points); */
    for( y = y_start; y < y_end; y++ )
    {
        uint dac = get_dac_for_y_index(datap, y, FALSE);
        uint y_mission = (dac - datap->ed_y_mission_min) / datap->ed_y_mission_step;
        bigint my_errs = AVAGO_EYE_ERRORS_GET(*datap,x_mid,y);
        bigint my_bits = AVAGO_EYE_BITS_GET(  *datap,x_mid,y);
        bigint mission_errs = datap->ed_mission_errors[which][y_mission];
        bigint mission_bits = datap->ed_mission_bits  [which][y_mission];
        bigint merged_errs, merged_bits;
        if( my_bits == 0 )  /* Initial copy */
        {
            merged_errs = mission_errs;
            merged_bits = mission_bits;
        }
        else if( my_bits == mission_bits )   /* If bit counts are same, save lower error count */
        {
            merged_errs = MIN(my_errs, mission_errs);
            merged_bits = my_bits;
        }
        else  /* Save smaller BER values: */
        {
            double my_ber = avago_calc_BER(my_errs, my_bits, 0.5);
            double mission_ber = avago_calc_BER(mission_errs, mission_bits, 0.5);
            if( my_ber <= mission_ber )
            {
                merged_errs = my_errs;
                merged_bits = my_bits;
            }
            else
            {
                merged_errs = mission_errs;
                merged_bits = mission_bits;
            }
        }
        AVAGO_EYE_ERRORS_SET(*datap,x_mid,y,merged_errs);
        AVAGO_EYE_BITS_SET(  *datap,x_mid,y,merged_bits);
    }
}

static void copy_mission_to_data(Avago_serdes_eye_data_t *datap)
{
    if( datap->ed_eye_type == AVAGO_EYE_SIZE || datap->ed_eye_type == AVAGO_EYE_HEIGHT )
    {
        /* Copy mission data into test structure; convert coordinates as needed. */
        int x_mide = get_eye_middle_x_index(datap, FALSE);

        /* NRZ copy: */
        copy_mission_column_to_data(datap, 0, x_mide, 0, datap->ed_y_points);

        if( datap->eye_count == 6 )
        {
            int x_mido = get_eye_middle_x_index(datap, TRUE);
            int y_mid  = (datap->ed_y_points-1) / 2 + 1;

            /* Copy lower odd data: */
            copy_mission_column_to_data(datap, 1, x_mido, 0, y_mid);

            /* Copy upper even & odd data: overwrites half the data copied for the NRZ case. */
            copy_mission_column_to_data(datap, 4, x_mide, y_mid, datap->ed_y_points);
            copy_mission_column_to_data(datap, 5, x_mido, y_mid, datap->ed_y_points);

            /* Merge middle eye data:  Note, this overwrites the middle half of the gathers. */
            copy_mission_column_to_data(datap, 2, x_mide, y_mid/2, datap->ed_y_points * 3 / 4);
            copy_mission_column_to_data(datap, 3, x_mido, y_mid/2, datap->ed_y_points * 3 / 4);
        }
    }
}

/*============================================================================= */
/* S E R D E S   E Y E   G E T */
/* */
/** @brief   Gathers eye diagram measurements from a SerDes slice. */
/** @details See Avago_serdes_eye_config_t and Avago_serdes_eye_data_t for */
/**          descriptions of configuration and return data values. */
/**          Before returning, restores key SerDes values to original states. */
/** @return Returns 0 on success. */
/** @return Returns 1 if eye gather is canceled asynchronously. */
/** @return Returns -1 and decrements aapl->return_code on error. */
int avago_serdes_eye_get(
    Aapl_t *aapl,                             /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                /**< [in] SBus slice address. */
    const Avago_serdes_eye_config_t *configp, /**< [in] Configuration parameters for how to gather the eye. */
    Avago_serdes_eye_data_t *datap)           /**< [out] Where to save the gathered eye data. */
{
    Eye_state_t es;
    Eye_state_t *esp = &es;

    if( aapl_get_async_cancel_flag(aapl) )
        return 1;

    /* Verify all eye parameters: */
    if( 0 != verify_eye_parameters(aapl, addr, configp) )
        return -1;

    if( aapl_get_async_cancel_flag(aapl) )
        return 1;

    if( configp->ec_eye_type == AVAGO_EYE_HEIGHT_DVOS )
    {
        init_eye_state( esp, aapl, addr, configp, datap);
        return serdes_get_dvos_height(aapl, addr, datap);
    }

    {
        BOOL tx_ready = 0, rx_ready = 0;
        if( avago_serdes_get_tx_rx_ready(aapl, addr, &tx_ready, &rx_ready) != 0 || !rx_ready )
            return aapl_fail(aapl, __func__, __LINE__,
                "SBus %s, Eye measurement requires that the Rx be enabled and ready.\n", aapl_addr_to_str(addr));
    }

    /* Initialize for eye gathering: */
    /* + Cache state info */
    /* + Find the eye center, if requested */
    /* + Scale the X resolution, if requested */
    /* + Scale the Y points/resolution, if requested */
    if( 0 != initialize_for_eye_gather(aapl, addr, esp, configp, datap) )
        return -1;

    if( aapl_get_async_cancel_flag(aapl) )
        goto SEG_Reset;

    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "orig_phase = %d, curr_phase = %d, phase_min = %d, vert_alpha[] = %d,%d,%d,%d,%d,%d.\n",
                    esp->orig_phase, es.curr_phase, datap->ed_x_min,
                    es.vert_alpha[0], es.vert_alpha[1], es.vert_alpha[2], es.vert_alpha[3], es.vert_alpha[4], es.vert_alpha[5]);
    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "original data_qual = %s\n", aapl_data_qual_to_str(esp->orig_data_qual));

    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "original cmp_mode = %s, phase_mult = %d, dac_min/step/points = %u,%u,%u\n",
                    aapl_cmp_mode_to_str(esp->orig_cmp_mode), esp->phase_mult, datap->ed_y_min, datap->ed_y_step, datap->ed_y_points);


/* SET DWELL TIME: */
/* */
/* The vision is that when max_dwell > min_dwell: */
/* */
/* - initially use min_dwell bits at each eye pixel (which we force to */
/*   be at least the empirically derived minimum AVAGO_EYE_MIN_DWELL_BITS). */
/* */
/* - if errors <= threshold, don't just accumulate many times (max_dwell bits */
/*   divided by, say, AVAGO_EYE_MIN_DWELL_BITS), instead set the actual dwell time (for */
/*   this eye pixel) to a smart value somewhere in between, perhaps based on */
/*   how many errors were read the first time (zero, or some fraction of */
/*   threshold) */
/* */
/* - after gathering another sample, if threshold isn't reached, perhaps modify */
/*   the dwell time again, etc */
/* */
/* - in all cases the final numerator = error count and denominator = total */
/*   dwell bits, for each eye pixel (data point), is stored in Avago_serdes_eye_data_t */
/*   for the caller to use to calculate BER. */
/* */

    /* Synchronize hardware and eye state dwell time: */
    if( eye_set_error_timer(&es, es.datap->ed_min_dwell_bits) < 0 )
        goto SEG_Reset;



/* GATHER EYE DATA: */
/* */

    /* Gather data as simply and efficiently as possible. */
    if( configp->ec_eye_type == AVAGO_EYE_FULL )
    {
        if( !gather_full_eye(esp) )
            goto SEG_Reset;
    }
    else
    {
        /* Gather width if selecting EYE_WIDTH or EYE_SIZE or EYE_SIZE_VDUAL: */
        if( configp->ec_eye_type != AVAGO_EYE_HEIGHT && !gather_eye_width(esp) )
            goto SEG_Reset;

        /* Gather height if selecting EYE_HEIGHT or EYE_SIZE or EYE_SIZE_VDUAL: */
        if( configp->ec_eye_type != AVAGO_EYE_WIDTH && !gather_eye_height(esp) )
            goto SEG_Reset;
    }

    /* Make another pass to update any values where additional detail is desired. */
    eye_dynamic_dwell(esp);

    copy_mission_to_data(datap);    /* If size or height gathers, copy mission arrays into data. */

/*#ifdef MEAN_EYE_FORCE_GATHER */
    if ( configp->ec_gather_mean )
        force_mean_eye_points(datap);
/*#endif // MEAN_EYE_FORCE_GATHER */

    serdes_eye_calc_gradient(esp->datap);
    serdes_eye_calc_qval(esp->aapl,esp->datap);

    /* Calculate the eye width, height and BTCs if we have the data to do so. */
    calc_width(esp->aapl, datap);
    if( configp->ec_eye_type != AVAGO_EYE_WIDTH ) calc_height(esp->aapl, datap, -1);

    avago_serdes_eye_plot_log_print(aapl, AVAGO_DEBUG2, __func__, __LINE__, datap);

/* RESET/RESTORE: */
/* */
/* Come here upon abort or normal exit to reset cmp_mode and eye center (if */
/* original values are defined) before returning. */
    if( esp->timeout_count > 0 )
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "SBus %s, %u timeouts detected during eye gather.\n", aapl_addr_to_str(addr), esp->timeout_count);

goto SEG_Exit;

SEG_Reset:
    if( aapl_get_async_cancel_flag(aapl) )
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__,"SBus %s, Eye exit due to cancel request.\n", aapl_addr_to_str(addr));
    else
        aapl_fail(aapl, __func__, __LINE__,"SBus %s, Eye abnormal exit.\n",aapl_addr_to_str(addr));

SEG_Exit:
    restore_serdes_state(esp);
    return aapl_get_async_cancel_flag(aapl) ? 1 : aapl->return_code < 0 ? -1 : 0;

} /* avago_serdes_eye_get() */

/** @brief  Displays a num line with numeric labels every 5th character. */
static char *print_num_header(char *ptr, const Avago_serdes_eye_data_t *datap)
{
    ptr += sprintf(ptr, "UI/%-3d ", datap->ed_x_resolution);
    if(      datap->ed_x_points == 1 ) ptr += sprintf(ptr, "0");
    else if( datap->ed_x_points == 2 ) ptr += sprintf(ptr, "00");
    else
    {
        int eye;
        int max_eye = 2 - (datap->eye_count & 1);
        int x_center = datap->ed_x_points / 2 / max_eye;
        for( eye = 0; eye < max_eye; eye++ )
        {
            int i;
            int skip = (x_center-2)%5;
            for( i = 0; i < skip; i++ )              ptr += sprintf(ptr, " ");
            for( i = -(x_center-2)/5; i < -1; i++  ) ptr += sprintf(ptr, "%4d ", i*5);
                                                     ptr += sprintf(ptr, " -5    0    5 ");
            for( i = 2; i <= (x_center-1)/5; i++  )  ptr += sprintf(ptr, "%5d", i*5);
            if( max_eye == 2 && eye == 0 )
            {
                skip = (x_center-1) % 5;
                for( i = 0; i < skip; i++ ) ptr += sprintf(ptr, " ");
            }
        }
    }
    ptr += sprintf(ptr, "\n");
    return ptr;
}

/** @brief  Displays a tic line with vertical bars every 5th character. */
static char *print_tic_header(char *ptr, const Avago_serdes_eye_data_t *datap)
{
    int eye;
    int max_eye = 2 - (datap->eye_count & 1);
    int x_center = datap->ed_x_points / 2 / max_eye;
    ptr += sprintf(ptr, "       ");
    for( eye = 0; eye < max_eye; eye++ )
    {
        int i;
        for( i = -x_center; i <= x_center; i++ )
        {
            if( i % 5 == 0 ) ptr += sprintf(ptr,"|");
            else             ptr += sprintf(ptr,"-");
        }
    }
    ptr += sprintf(ptr, "\n");
    return ptr;
}

#define        ROW_DELIM ':'
#define CENTER_ROW_DELIM '='

/** @brief  Create a simple ascii text eye. */
/** @return A string containing the eye or NULL upon allocation error. */
/**         The caller should AAPL_FREE the returned string. */
char *avago_serdes_eye_plot_format(
    const Avago_serdes_eye_data_t *datap)   /**< Eye data to display */
{
    const uint threshold1 = datap->ed_error_threshold;
    const uint threshold2 = threshold1 * 10;
    const uint threshold3 = threshold2 * 10;
    const uint threshold4 = threshold3 * 10;
    uint x_points = gather_separate_even_odd(datap) ? datap->ed_x_points/2 : datap->ed_x_points;
    uint y = datap->ed_y_points;
    uint upper_threshold = MIN(datap->ed_y_points, (datap->ed_hbtc[2].data_row + datap->ed_hbtc[4].data_row) / 2);
    uint lower_threshold = MIN(datap->ed_y_points, (datap->ed_hbtc[0].data_row + datap->ed_hbtc[2].data_row) / 2);
    uint alloc_size = (datap->ed_x_points+15)*(datap->ed_y_points+4) + 80;
    char *buf = (char *)AAPL_MALLOC(alloc_size);
    char *ptr = buf;
    if( !buf ) return 0;    /* malloc failed */

    ptr += sprintf(ptr,"\nEye Plot");
    if( gather_separate_even_odd(datap) ) ptr += sprintf(ptr," (even on the left, odd on the right)");
    *ptr++ = '\n';

    if( !datap->ed_errorsp || !datap->ed_bitsp )
        return *buf = '\0',buf;

    ptr = print_num_header(ptr, datap);
    ptr = print_tic_header(ptr, datap);

    while( y-- > 0 )
    {
        BOOL print_line = FALSE;
        uint x;
        int y_odd = y;
        int y_even = y;
        int even_row, odd_row;
        BOOL center_row = FALSE;
        BOOL row_delim = ROW_DELIM;
        int step = 1;

#if 1   /* Disable this if..endif to disable eye center alignment. */
        if( gather_separate_even_odd(datap) )
        {
            /* Shift odd eye to align centers with even eye: */
            if( y >= upper_threshold )
                y_odd = y + datap->ed_hbtc[5].data_row - datap->ed_hbtc[4].data_row;
            else if( y >= lower_threshold )
                y_odd = y + datap->ed_hbtc[3].data_row - datap->ed_hbtc[2].data_row;
            else
                y_odd = y + datap->ed_hbtc[1].data_row - datap->ed_hbtc[0].data_row;

            /* Bound y_odd value within range: */
            if( y_odd >= (int)datap->ed_y_points ) y_odd = datap->ed_y_points - 1;
            else if( y_odd < 0 ) y_odd = 0;

            step = 2;
        }
#endif
        even_row = get_dac_for_y_index(datap, y_even, FALSE) - datap->ed_y_center_point;
        odd_row = get_dac_for_y_index(datap, y_odd, FALSE) - datap->ed_y_center_point;

        /* Verify that we have data on line before printing it. */
        for( x = 0; x < datap->ed_x_points; x++ )
        {
            int e_o = x < x_points ? 0 : 1;
            uint y_index = e_o ? y_odd : y_even;
            bigint bits = get_bits_column(datap, (int)x)[y_index];
            if( bits > 0 )
            {
                print_line = TRUE;
                break;
            }
        }
        if( !print_line ) continue;

        for( x = 0; x < datap->ed_x_points; x++ )
        {
            int e_o = x < x_points ? 0 : 1;
            uint y_index = e_o ? y_odd : y_even;
            bigint bits = get_bits_column(datap, (int)x)[y_index];
            bigint errs = get_errs_column(datap, (int)x)[y_index];

            if( x == 0 || x == x_points )
            {
                int e_o = x == 0 ? 0 : 1;
                if( datap->ed_hbtc[0*step+e_o].data_row == y_index ||
                    datap->ed_hbtc[1*step+e_o].data_row == y_index ||
                    datap->ed_hbtc[2*step+e_o].data_row == y_index )
                {
                    center_row = TRUE;
                    row_delim = CENTER_ROW_DELIM;
                }
                if( x == 0 )
                    ptr += sprintf(ptr,"%4d %c ", even_row, row_delim);
            }

            if( bits <= 0 )
                ptr[x] = '-';
            else if( errs == 0 )
            {
                char row_char, col_char;
                if( x == x_points / 2 || x == x_points + x_points / 2 )
                     { row_char = '+'; col_char = '!'; } /* Center column chars */
                else { row_char = '-'; col_char = ' '; } /* Non-center column chars */

                ptr[x] = center_row ? row_char : col_char;
            }
            else if( errs <= threshold1 )
                ptr[x] = '.';
            else if( errs <= threshold2 )
                ptr[x] = '+';
            else if( errs <= threshold3 )
                ptr[x] = '*';
            else if( x == x_points / 2 || x == x_points + x_points / 2 ) /* If center column */
                ptr[x] = '|';
            else if( center_row )
                ptr[x] = '=';
            else if( errs <= threshold4 )
                ptr[x] = '@';
            else
                ptr[x] = '#';
        }
        ptr += datap->ed_x_points;
        if( x_points != datap->ed_x_points ) ptr += sprintf(ptr," %c %4d", row_delim, odd_row);
        *ptr++ = '\n';
    }
    ptr = print_tic_header(ptr, datap);
    ptr = print_num_header(ptr, datap);
    *ptr = '\0';
    /*printf("buf_len = %ld, allocated length = %u, margin = %ld\n", ptr + 1 - buf, alloc_size, alloc_size - (ptr + 1 - buf)); */
    return buf;
}

/** @brief  Create a simple text gradient eye. */
/** @return A string containing the eye or NULL upon allocation error. */
/**         The caller should AAPL_FREE the returned string. */
char *avago_serdes_eye_gradient_plot_format(
    const Avago_serdes_eye_data_t *datap)   /**< Eye data to display */
{
    /* 0.0100, 0.0300, 0.1000 and 0.2000 work OK */
    /* 0.0005, 0.0010, 0.0100 and 0.1000 work OK too. */
    const float threshold1 = 0.0001; /* .0001 */
    const float threshold2 = 0.0040; /* threshold1 * 3; // .0040 */
    const float threshold3 = 0.0140; /* threshold2 * 3; // .0140 */
    const float threshold4 = 0.0300; /* threshold3 * 3; // .0300 */
    const float threshold5 = 0.1000; /* threshold4 * 3; // .1000 */
    uint x_points = gather_separate_even_odd(datap) ? datap->ed_x_points/2 : datap->ed_x_points;
    uint y = datap->ed_y_points;
    uint upper_threshold = MIN(datap->ed_y_points, (datap->ed_hbtc[2].data_row + datap->ed_hbtc[4].data_row) / 2);
    uint lower_threshold = MIN(datap->ed_y_points, (datap->ed_hbtc[0].data_row + datap->ed_hbtc[2].data_row) / 2);
    uint alloc_size = (datap->ed_x_points+15)*(datap->ed_y_points+4) + 80;
    char *buf = (char *)AAPL_MALLOC(alloc_size);
    char *ptr = buf;
    if( !buf ) return 0;    /* malloc failed */

    ptr += sprintf(ptr,"\nEye Gradient Plot");
    if( datap->eye_count == 6 ) ptr += sprintf(ptr," (even on the left, odd on the right)");
    *ptr++ = '\n';

    if( !datap->ed_errorsp || !datap->ed_bitsp )
        return *buf = '\0',buf;

    ptr = print_num_header(ptr, datap);
    ptr = print_tic_header(ptr, datap);

    while( y-- > 1 )
    {
        uint x;
        int y_odd = y;
        int y_even = y;
        int even_row, odd_row;
        BOOL center_row = FALSE;
        char row_delim = ROW_DELIM;
        int step = 1;

#if 1   /* Disable this if..endif to disable eye center alignment. */
        if( gather_separate_even_odd(datap) )
        {
            /* Shift odd eye to align centers with even eye: */
            if( y >= upper_threshold )
                y_odd = y + datap->ed_hbtc[5].data_row - datap->ed_hbtc[4].data_row;
            else if( y >= lower_threshold )
                y_odd = y + datap->ed_hbtc[3].data_row - datap->ed_hbtc[2].data_row;
            else
                y_odd = y + datap->ed_hbtc[1].data_row - datap->ed_hbtc[0].data_row;

            /* Bound y_odd value within range: */
            if( y_odd >= (int)datap->ed_y_points ) y_odd = datap->ed_y_points - 1;
            else if( y_odd < 0 ) y_odd = 0;

            step = 2;
        }
#endif
        even_row = get_dac_for_y_index(datap, y_even, FALSE) - datap->ed_y_center_point;
        odd_row = get_dac_for_y_index(datap, y_odd, FALSE) - datap->ed_y_center_point;

        for( x = 0; x < datap->ed_x_points; x++ )
        {
            int e_o = x < x_points ? 0 : 1;
            uint y_index = e_o ? y_odd : y_even;
            bigint bits = AVAGO_EYE_BITS_GET(*datap,x,y_index);
            float grad = AVAGO_EYE_GRAD_GET(*datap,x,y_index);

            if( x == 0 || x == x_points )
            {
                int e_o = x == 0 ? 0 : 1;
                if( datap->ed_hbtc[0*step+e_o].data_row == y_index ||
                    datap->ed_hbtc[1*step+e_o].data_row == y_index ||
                    datap->ed_hbtc[2*step+e_o].data_row == y_index )
                {
                    center_row = TRUE;
                    row_delim = CENTER_ROW_DELIM;
                }
                if( x == 0 )
                    ptr += sprintf(ptr,"%4d %c ", even_row, row_delim);
            }

            if( bits <= 0 )
                ptr[x] = '-';
            else if( grad < threshold1 )
            {
                char row_char, col_char;
                if( x == x_points / 2 || x == x_points + x_points / 2 )
                     { row_char = '+'; col_char = '!'; } /* Center column chars */
                else { row_char = '-'; col_char = ' '; } /* Non-center column chars */

                ptr[x] = center_row ? row_char : col_char;
            }
            else if( grad < threshold2 )
                ptr[x] = '.';
            else if( grad < threshold3 )
                ptr[x] = ':';
            else if( grad < threshold4 )
                ptr[x] = '+';
            else if( x == x_points / 2 || x == x_points + x_points / 2 ) /* If center column */
                ptr[x] = '|';
            else if( center_row )
                ptr[x] = '=';
            else if( grad < threshold5 )
                ptr[x] = '*';
            else
                ptr[x] = '#';
        }
        ptr += datap->ed_x_points;
        if( x_points != datap->ed_x_points ) ptr += sprintf(ptr," %c %4d", row_delim, odd_row);
        *ptr++ = '\n';
    }
    ptr = print_tic_header(ptr, datap);
    ptr = print_num_header(ptr, datap);
    *ptr = '\0';
    /*printf("buf_len = %ld, allocated length = %u, margin = %ld\n", ptr + 1 - buf, alloc_size, alloc_size - (ptr + 1 - buf)); */
    return buf;
}


/** @brief  Create a simple text qval contour eye. */
/** @return A string containing the eye or NULL upon allocation error. */
/**         The caller should AAPL_FREE the returned string. */
char *avago_serdes_eye_contour_plot_format(
    const Avago_serdes_eye_data_t *datap)   /**< Eye data to display */
{
#if AAPL_ALLOW_ANSI_COLORS
    const char *color = "\x1B[1m"; /* {1=bold,3X=fg,4x=bg,5=flash,7=invert} X={black=0,red,green,yellow,blue,magenta,cyan,white=7} */
    const char *end_color = "\x1B[0m";
#else
    const char *color = "";
    const char *end_color = "";
#endif
    uint y = datap->ed_y_points;
    uint x_points = gather_separate_even_odd(datap) ? datap->ed_x_points/2 : datap->ed_x_points;
    uint upper_threshold = MIN(datap->ed_y_points, (datap->ed_hbtc[2].data_row + datap->ed_hbtc[4].data_row) / 2);
    uint lower_threshold = MIN(datap->ed_y_points, (datap->ed_hbtc[0].data_row + datap->ed_hbtc[2].data_row) / 2);
    uint alloc_size = (datap->ed_x_points+31)*(datap->ed_y_points+4) + 80;
    char *buf = (char *)AAPL_MALLOC(alloc_size);
    char *ptr = buf;
    if( !buf ) return 0;    /* malloc failed */

    ptr += sprintf(ptr,"\nEye Q-value Contour Plot");
    if( datap->eye_count == 6 ) ptr += sprintf(ptr," (even on the left, odd on the right)");
    *ptr++ = '\n';

    if( !datap->ed_errorsp || !datap->ed_bitsp )
        return *buf = '\0',buf;

    ptr = print_num_header(ptr, datap);
    ptr = print_tic_header(ptr, datap);

    ptr += sprintf(ptr,"%s",end_color); /* Don't color non-center rows. */
    while( y-- > 0 )
    {
        uint x;
        int y_odd = y;
        int y_even = y;
        int even_row, odd_row;
        BOOL center_row = FALSE;
        char row_delim = ROW_DELIM;
        int step = 1;

#if 1   /* Disable this if..endif to disable eye center alignment. */
        if( gather_separate_even_odd(datap) )
        {
            /* Shift odd eye to align centers with even eye: */
            if( y >= upper_threshold )
                y_odd = y + datap->ed_hbtc[5].data_row - datap->ed_hbtc[4].data_row;
            else if( y >= lower_threshold )
                y_odd = y + datap->ed_hbtc[3].data_row - datap->ed_hbtc[2].data_row;
            else
                y_odd = y + datap->ed_hbtc[1].data_row - datap->ed_hbtc[0].data_row;

            /* Bound y_odd value within range: */
            if( y_odd >= (int)datap->ed_y_points ) y_odd = datap->ed_y_points - 1;
            else if( y_odd < 0 ) y_odd = 0;

            step = 2;
        }
#endif
        even_row = get_dac_for_y_index(datap, y_even, FALSE) - datap->ed_y_center_point;
        odd_row = get_dac_for_y_index(datap, y_odd, FALSE) - datap->ed_y_center_point;

        /* ptr += sprintf(ptr,"%4d : ", get_dac_for_y_index(datap, y, FALSE) - (datap->ed_y_resolution-1)/2); */
        for( x = 0; x < datap->ed_x_points; x++ )
        {
            int e_o = x < x_points ? 0 : 1;
            uint y_index = e_o ? y_odd : y_even;
            float qval = AVAGO_EYE_QVAL_GET(*datap,x,y_index);
            BOOL center_column = x_points / 2 == x || x_points + x_points / 2 == x;
            BOOL color_column;

            if( x == 0 || x == x_points )
            {
                int e_o = x == 0 ? 0 : 1;
                if( center_row )
                {
                    ptr += sprintf(ptr,"%s",end_color);  /* End color center row */
                    center_row = FALSE;
                }
                if( datap->ed_hbtc[0*step+e_o].data_row == y_index ||
                    datap->ed_hbtc[1*step+e_o].data_row == y_index ||
                    datap->ed_hbtc[2*step+e_o].data_row == y_index )
                {
                    ptr += sprintf(ptr,"%s",color); /* Color eye center row(s) */
                    center_row = TRUE;
                    row_delim = CENTER_ROW_DELIM;
                }
                if( x == 0 )
                    ptr += sprintf(ptr,"%4d %c ", even_row, row_delim);
            }
            color_column = center_column && !center_row;

            if( color_column ) ptr += sprintf(ptr,"%s",color); /* Color center column */
            if( qval >= 10.0 ) /* if( qval >= AVAGO_Q_CEILING ) */
            {
                if(      center_column ) *ptr++ = '|';
                else if( center_row    ) *ptr++ = '-';
                else                     *ptr++ = ' ';
            }
#if AAPL_ALLOW_ANSI_COLORS
            else if( qval >= 1.0 )
                *ptr++ = '0' + (int)qval % 10;
#else
            else if( qval >= 1.0 )
            {
                char c = '0' + (int)qval % 10;
                if(      !(c & 1) && center_column ) *ptr++ = '|';
                else if( !(c & 1) && center_row    ) *ptr++ = '-';
                else                                 *ptr++ = c;
            }
            else if( center_column )
                *ptr++ = '|';
            else if( center_row )
                *ptr++ = '=';
#endif
            else
                *ptr++ = '0';
            if( color_column ) ptr += sprintf(ptr,"%s",end_color);  /* End color center column */
        }
        if( x_points != datap->ed_x_points ) ptr += sprintf(ptr," %c %4d", row_delim, odd_row);
        if( center_row                     ) ptr += sprintf(ptr,"%s",end_color);  /* End color center row */
        *ptr++ = '\n';
    }
    ptr = print_tic_header(ptr, datap);
    ptr = print_num_header(ptr, datap);
    *ptr = '\0';
    /*printf("buf_len = %ld, allocated length = %u, margin = %ld\n", ptr + 1 - buf, alloc_size, alloc_size - (ptr + 1 - buf)); */
    return buf;
}

/** @brief  Write a simple text eye to a log file. */
void avago_serdes_eye_plot_log_print(
    Aapl_t *aapl,                       /**< [in] */
    Aapl_log_type_t level,              /**< [in] Specify logging type. */
    const char *caller,                 /**< [in] Typically __func__, may be 0. */
    int line,                           /**< [in] Typically __LINE__, may be 0. */
    const Avago_serdes_eye_data_t *datap)   /**< [in] Data to format and print. */
{
    if(( (aapl->debug & 0xf) >= (uint)level ) || (level >= AVAGO_MEM_LOG ))
    {
        char *eye_text = avago_serdes_eye_plot_format(datap);
        if( eye_text )
        {
            aapl_log_add(aapl, level, eye_text, caller, line);
            AAPL_FREE(eye_text);
        }
    }
}

#if AAPL_ENABLE_FILE_IO

/** @brief Write a simple ascii text eye to a file. */
void avago_serdes_eye_plot_write(
    FILE *file,                             /**< Where to print the eye */
    const Avago_serdes_eye_data_t *datap)   /**< Eye data to print */
{
    char *eye_text = avago_serdes_eye_plot_format(datap);
    if( eye_text )
    {
        fputs(eye_text,file);
        AAPL_FREE(eye_text);
    }
}

/** @brief Write a simple text gradient eye to a file. */
void avago_serdes_eye_gradient_plot_write(
    FILE *file,                             /**< Where to print the eye */
    const Avago_serdes_eye_data_t *datap)   /**< Eye data to print */
{
    char *eye_text = avago_serdes_eye_gradient_plot_format(datap);
    if( eye_text )
    {
        fputs(eye_text,file);
        AAPL_FREE(eye_text);
    }
}

/** @brief Write a simple text gradient eye to a file. */
void avago_serdes_eye_contour_plot_write(
    FILE *file,                             /**< Where to print the eye */
    const Avago_serdes_eye_data_t *datap)   /**< Eye data to print */
{
    char *eye_text = avago_serdes_eye_contour_plot_format(datap);
    if( eye_text )
    {
        fputs(eye_text,file);
        AAPL_FREE(eye_text);
    }
}


/* Write phase data as a tagged string.  Writes nothing if no phase data. */
static void write_phase_data(FILE *file, const Avago_serdes_eye_data_t *datap)
{
    if( datap->ed_phase_table )
    {
        uint i;
        /*printf("TABLE: CENTER = %f\n", datap->ed_phase_center); */
        fprintf(file, "phase_data: %d,1,%.2f", datap->ed_phase_table_len, datap->ed_phase_center);
        for( i = 0; i < datap->ed_phase_table_len; i++ )
            fprintf(file, ", %.2f", datap->ed_phase_table[i]);
        fprintf(file, "\n");
        fprintf(file, "phase_inl: %u", datap->ed_x_points);
        for( i = 0; i < datap->ed_x_points; i++ )
            fprintf(file, ", %.2f", mui_from_index(datap, i));
        fprintf(file, "\n");
    }
}
/* Extract int value, return length to skip past next comma. */
static int read_float(const char *str, float *arg)
{
    const char *ptr;
    if( 1 == sscanf(str,"%9f",arg) && (ptr = strchr(str,',')) != 0 )
        return ptr-str+1;
    return strlen(str);
}
/* Extract float value, return length to skip past next comma. */
static uint read_uint(const char *str, uint *arg)
{
    const char *ptr;
    if( 1 == sscanf(str,"%9u",arg) && (ptr = strchr(str,',')) != 0 )
        return ptr-str+1;
    return strlen(str);
}
/* Parses phase data string (without the leading tag): */
/* Return TRUE on success. */
static BOOL parse_phase_data(Aapl_t *aapl, Avago_serdes_eye_data_t *datap, const char *str)
{
    /* Format is "%d,%f,%f[,%f]*" */
    uint i = 0;
    uint extra_items;
    const char *ptr;
    str += read_uint(str, &datap->ed_phase_table_len);
    str += read_uint(str, &extra_items);

    /* Read / skip extra parameters: */
    str += read_float(str, &datap->ed_phase_center);  /* First expected extra parameter */
    extra_items -= 1;   /* One expected extra parameter */
    while( extra_items-- > 0 && (ptr = strchr(str,',')) != 0 ) str = ptr + 1;   /* Skip unexpected extra parameters */

    /* Read table data: */
    datap->ed_phase_table = (float *)aapl_realloc(aapl, datap->ed_phase_table, datap->ed_phase_table_len * sizeof(datap->ed_phase_table[0]), "phase_table");
    if( datap->ed_phase_table )
    {
        int len;
        while( i < datap->ed_phase_table_len && (len = read_float(str, &datap->ed_phase_table[i])) > 0 )
        {
            str += len;
            i++;
        }
    }
    return i == datap->ed_phase_table_len;
}

static void avago_update_hal_field(
    Avago_serdes_eye_data_t *datap,
    const char *name,
    int value)
{
    if(      EQS(name,"hal.t_u_o") )   datap->inputs.upper_o  = value;
    else if( EQS(name,"hal.t_u_e") )   datap->inputs.upper_e  = value;
    else if( EQS(name,"hal.t_m_o") )   datap->inputs.mid_o    = value;
    else if( EQS(name,"hal.t_m_e") )   datap->inputs.mid_e    = value;
    else if( EQS(name,"hal.t_l_o") )   datap->inputs.lower_o  = value;
    else if( EQS(name,"hal.t_l_e") )   datap->inputs.lower_e  = value;
    else if( EQS(name,"hal.c_u_o") ) { datap->cal.upper_o     = value; datap->delta.upper_o = 0; }
    else if( EQS(name,"hal.c_u_e") ) { datap->cal.upper_e     = value; datap->delta.upper_e = 0; }
    else if( EQS(name,"hal.c_m_o") ) { datap->cal.mid_o       = value; datap->delta.mid_o   = 0; }
    else if( EQS(name,"hal.c_m_e") ) { datap->cal.mid_e       = value; datap->delta.mid_e   = 0; }
    else if( EQS(name,"hal.c_l_o") ) { datap->cal.lower_o     = value; datap->delta.lower_o = 0; }
    else if( EQS(name,"hal.c_l_e") ) { datap->cal.lower_e     = value; datap->delta.lower_e = 0; }
    else if( EQS(name,"hal.c_t_o") )   datap->test_cal.test_o = value;
    else if( EQS(name,"hal.c_t_e") )   datap->test_cal.test_e = value;
    else if( EQS(name,"hal.c_e_o") )   datap->test_cal.edge_o = value;
    else if( EQS(name,"hal.c_e_e") )   datap->test_cal.edge_e = value;
}

static void avago_write_hal_state(
    FILE *file,
    const Avago_serdes_eye_data_t *datap)
{
    fprintf(file,"hal.t_u_o: %12d # Tune centers\n", datap->inputs.upper_o);
    fprintf(file,"hal.t_u_e: %12d\n", datap->inputs.upper_e);
    fprintf(file,"hal.t_m_o: %12d\n", datap->inputs.mid_o);
    fprintf(file,"hal.t_m_e: %12d\n", datap->inputs.mid_e);
    fprintf(file,"hal.t_l_o: %12d\n", datap->inputs.lower_o);
    fprintf(file,"hal.t_l_e: %12d\n", datap->inputs.lower_e);

    fprintf(file,"hal.c_u_o: %12d # Dac offsets\n", datap->cal.upper_o + datap->delta.upper_o);
    fprintf(file,"hal.c_u_e: %12d\n", datap->cal.upper_e + datap->delta.upper_e);
    fprintf(file,"hal.c_m_o: %12d\n", datap->cal.mid_o   + datap->delta.mid_o);
    fprintf(file,"hal.c_m_e: %12d\n", datap->cal.mid_e   + datap->delta.mid_e);
    fprintf(file,"hal.c_l_o: %12d\n", datap->cal.lower_o + datap->delta.lower_o);
    fprintf(file,"hal.c_l_e: %12d\n", datap->cal.lower_e + datap->delta.lower_e);
    fprintf(file,"hal.c_t_o: %12d\n", datap->test_cal.test_o);
    fprintf(file,"hal.c_t_e: %12d\n", datap->test_cal.test_e);
    fprintf(file,"hal.c_e_o: %12d\n", datap->test_cal.edge_o);
    fprintf(file,"hal.c_e_e: %12d\n", datap->test_cal.edge_e);
}

/** @brief Write eye data to a file. */
void avago_serdes_eye_data_write(
    FILE *file,                             /**< where to write the data */
    const Avago_serdes_eye_data_t *datap)   /**< data to write */
{
    char time_str[40];
    aapl_local_strftime(time_str,sizeof(time_str),"%Y-%m-%d %H:%M:%S");

    fprintf(file,"# EYE DIAGRAM DATA\n");
    fprintf(file,"\n");
    fprintf(file,"file_format:    7\n");
    fprintf(file,"AAPL_version:   " AAPL_VERSION ", compiled %s %s\n",__DATE__,__TIME__);
    fprintf(file,"capture_date:   %s\n", time_str);
    if( datap->ed_comment )
        fprintf(file,"user_comment:   %s\n",datap->ed_comment);
    fprintf(file,"\n");
    if( datap->ed_hardware_log )
        fprintf(file,"%s\n", datap->ed_hardware_log);

    fprintf(file,"eye_type:       %s\n", aapl_eye_type_to_str(datap->ed_eye_type));
    fprintf(file,"data_qual:      %s\n", aapl_data_qual_to_str(datap->ed_data_qual));
    fprintf(file,"compare_mode:   %s\n", aapl_cmp_mode_to_str(datap->ed_cmp_mode));
    fprintf(file,"\n");

    if( datap->eye_count > 0 )
        fprintf(file,"eye_count:        %3d\n", datap->eye_count);
    fprintf(file,"x.UI:             %3d\n",datap->ed_x_UI);
    fprintf(file,"x.resolution:     %3d  # Steps per UI\n",datap->ed_x_resolution);
    fprintf(file,"x.points:         %3d  # Data array dimension\n",datap->ed_x_points);
    fprintf(file,"x.min:            %3d\n",datap->ed_x_min);
    fprintf(file,"x.max:            %3u\n",datap->ed_x_max);
    fprintf(file,"x.step:           %3d\n",datap->ed_x_step);
    fprintf(file,"x.sbm_center:     %3d\n",datap->ed_x_sbm_center);
    fprintf(file,"x.adj_center:     %3d  # Relative to sbm_center; before any manual shift\n",(datap->ed_x_min + datap->ed_x_max) / 2 - datap->ed_x_shift);
    fprintf(file,"x.center:         %3d", datap->ed_x_center[0]);
    if( datap->ed_hbtc[1].data_row < datap->ed_y_points )
    {
        int i;
        for( i = 1; i < datap->eye_count; i++ )
            fprintf(file,", %3d", datap->ed_x_center[i]);
    }
    switch( datap->eye_count )
    {
    case 3:  fprintf(file, " # Eye center phase (l, m, u)\n"); break;
    case 6:  fprintf(file, " # Eye center phase (le, lo, me, mo, ue, uo)\n"); break;
    default: fprintf(file, " # Eye center phase\n");
    }
    fprintf(file,"x.shift:          %3d  # Manual adjustment\n",datap->ed_x_shift);
    fprintf(file,"x.width:          %3d\n",datap->ed_width);
    fprintf(file,"x.width_mUI:      %3d\n",datap->ed_width_mUI);
    fprintf(file,"\n");

    fprintf(file,"y.resolution:     %3d  # DAC range\n",datap->ed_y_resolution);
    fprintf(file,"y.points:         %3d  # Data array dimension\n",datap->ed_y_points);
    fprintf(file,"y.step:           %3d\n",datap->ed_y_step);
    fprintf(file,"y.min:            %3d  # DAC for y=0\n",datap->ed_y_min);
    fprintf(file,"y.mission_points: %3d\n",datap->ed_y_mission_points);
    fprintf(file,"y.mission_step:   %3d\n",datap->ed_y_mission_step);
    fprintf(file,"y.mission_min:    %3d  # DAC for y=0\n",datap->ed_y_mission_min);
    fprintf(file,"y.center_row:     %3d", datap->ed_hbtc[0].data_row);
    if( datap->ed_hbtc[1].data_row < datap->ed_y_points )
    {
        int i;
        for( i = 1; i < datap->eye_count; i++ )
            fprintf(file,", %3d", datap->ed_hbtc[i].data_row);
    }
    switch( datap->eye_count )
    {
    case 3:  fprintf(file, " # Eye center y indices (l, m, u)\n"); break;
    case 6:  fprintf(file, " # Eye center y indices (le, lo, me, mo, ue, uo)\n"); break;
    default: fprintf(file, " # Eye center y index\n");
    }
    fprintf(file,"y.center:         %3d  # DAC middle\n", get_dac_for_y_index(datap, (datap->ed_y_points-1) / 2, FALSE));
    fprintf(file,"y.height:         %3d\n",datap->ed_height);
    fprintf(file,"y.height_mV:      %3d\n",datap->ed_height_mV);
    fprintf(file,"\n");

    fprintf(file,"dc_balance:         %g\n", datap->ed_dc_balance);
    fprintf(file,"trans_density:      %g\n", datap->ed_trans_density);
    fprintf(file,"avdd:               %-.2f     # V\n", datap->ed_avdd);
    fprintf(file,"dac_scale:          %g  # mV/step\n", datap->ed_dac_scale);
    fprintf(file,"\n");
    fprintf(file,"error_threshold: %8d\n",  datap->ed_error_threshold);
    fprintf(file,"min_dwell_bits:  %8g\n",  datap->ed_min_dwell_bits*1.0);
    fprintf(file,"max_dwell_bits:  %8g\n",  datap->ed_max_dwell_bits*1.0);
    fprintf(file,"fast_dynamic:    %8d\n",  datap->ed_fast_dynamic);
    if( datap->ed_centering_options )
        fprintf(file,"center_options:  %8d\n",  datap->ed_centering_options);
    if( datap->ed_set_phase_center )
        fprintf(file,"set_center:      %8d\n",  datap->ed_set_phase_center);
    fprintf(file,"vert_alpha:      %8d\n",  datap->ed_apply_vert_alpha);
    if( datap->ed_phase_center_log )
        fprintf(file,"\ncenter_data:  %s\n\n", datap->ed_phase_center_log);
    write_phase_data(file, datap);
    avago_write_dfe_state(file, &datap->ed_dfe_state);
    if( datap->inputs.upper_e != 0 || datap->inputs.lower_o != 0 )
        avago_write_hal_state(file, datap);
    fprintf(file,"\n");

    fprintf(file,"# Phase index, DAC index, Errors, Bits\n");
    /* First print mission channel data: */
    if( datap->ed_y_mission_points > 1 )
    {
        int x;
        if( datap->eye_count == 6 )
            fprintf(file,"# Mission data (-6=uo, -5=ue, -4=mo, -3=me, -2=lo, -1=le\n");
        else if( datap->eye_count == 3 )
            fprintf(file,"# Mission data (-3=upper, -2=middle, -1=lower)\n");
        else
            fprintf(file,"# Mission data:\n");
        for( x = -datap->eye_count; x < 0; x++ )
        {
            const bigint *errs = get_errs_column(datap, x);
            const bigint *bits = get_bits_column(datap, x);
            uint y;
            for( y = 0; y < datap->ed_y_mission_points; y++ )   /* Check all points for data */
                if( bits[y] != 0 )
                {
                    fprintf(file,"%3d, %3u, %6s, %13s", x, y, aapl_bigint_to_str(errs[y]), aapl_bigint_to_str(bits[y]));
                    fprintf(file," %9f", avago_serdes_eye_qval_get(0,datap,x,y));
                    if( y > 0 ) fprintf(file," %9f", avago_serdes_eye_qval_get(0,datap,x,y-1) - avago_serdes_eye_qval_get(0,datap,x,y));
                    fprintf(file,"\n");
                }
        }
    }
    /* Then print test channel data: */
    if( datap->ed_x_points >= 1 )
    {
        uint x;
        fprintf(file,"# Test channel data:\n");
        for( x = 0; x < datap->ed_x_points; ++x )
        {
            const bigint *errs = get_errs_column(datap, x);
            const bigint *bits = get_bits_column(datap, x);
            uint y;
            for( y = 0; y < datap->ed_y_points; ++y )
                if( bits[y] != 0 )
                {
#ifdef MEAN_EYE_FORCE_WRITE
                    if ( datap->ed_gather_mean && errs[y] == 0 ) continue;
#endif /* MEAN_EYE_FORCE_WRITE */
                    fprintf(file,"%3u, %3u, %6s, %13s", x, y, aapl_bigint_to_str(errs[y]), aapl_bigint_to_str(bits[y]));
                    fprintf(file," %9f", avago_serdes_eye_qval_get(0,datap,x,y));
                    if( y > 0 ) fprintf(file," %9f", avago_serdes_eye_qval_get(0,datap,x,y-1) - avago_serdes_eye_qval_get(0,datap,x,y));
                    if( x > 0 ) fprintf(file," %9f", avago_serdes_eye_qval_get(0,datap,x-1,y) - avago_serdes_eye_qval_get(0,datap,x,y));
                    fprintf(file,"\n");
                }
        }
    }

    /* Output default BTC structures, if we have data for them: */
    {
        int i;
        for( i = 0; i < datap->eye_count; i++ )
        {
            int which = datap->eye_count == 6 ? (i%2) + 2 * (2 - i/2) : datap->eye_count-1-i; /* Order PAM4 output */
            avago_serdes_eye_vbtc_write(file, &datap->ed_vbtc[which]);
        }
        for( i = 0; i < datap->eye_count; i++ )
        {
            int which = datap->eye_count == 6 ? (i%2) + 2 * (2 - i/2) : datap->eye_count-1-i; /* Order PAM4 output */
            avago_serdes_eye_hbtc_write(file, &datap->ed_hbtc[which]);
        }
        avago_serdes_eye_btc_write(file, datap);
    }

#if 0
    /* Output the calculated phase center BTC if we have data for it: */
    {
    Avago_serdes_eye_vbtc_t vbtc_calc;
    avago_serdes_eye_vbtc_extrapolate(datap, datap->ed_x_points / 2, &vbtc_calc);
    avago_serdes_eye_vbtc_write(file, &vbtc_calc);
    fputs("\n", file);
    }
#endif
}

/** @brief Write the captured data and meta data to a file. */
/** */
/** @return 0 on success, -1 on failure. */
/** @see avago_serdes_eye_data_read_file(). */
int avago_serdes_eye_data_write_file(
    const char *file_name,                  /**< Filename to write the data. */
    const Avago_serdes_eye_data_t *datap)   /**< Data to write. */
{
    FILE *fp = fopen(file_name,"w");
    if( fp )
    {
        avago_serdes_eye_data_write(fp, datap);
        return fclose(fp);
    }
    fprintf(stderr,"Error opening file \"%s\" for writing: %s.\n", file_name, strerror(errno));
    return -1;
}

static int split(char *line, const char *delim, char *argv[])
{
    int argc = 0;
    char *tok_state;
    argv[argc] = aapl_strtok_r(line,delim,&tok_state);
    while( argv[argc] )
        argv[++argc] = aapl_strtok_r(NULL,delim,&tok_state);
    return argc;
}

static int getint(const char *str)
{
    return (int) aapl_strtol(str,0,0);
}

static bigint getbigint(const char *str)
{
#ifdef _MSC_VER
    return (bigint) _strtoi64(str,0,0);
#else
    return (bigint) strtoll(str,0,0);
#endif
}

/** @brief   Reads a name and value from buf. */
/** @details Buf contains a name value pair separated by one or more white */
/**          space, colon and equal sign characters. */
/**          Locates and nul terminates the name, and */
/**          stores any integer value into *value. */
/**          Comments (starting with a '#') and extra fields are ignored. */
/** @return  The number of fields found: 0 for blank or comment lines, 1 for */
/**          only a name, 2 for name and value. */
static int get_name_value_pair(
    char *buf,              /**< [in] Line to parse. */
    char **name,            /**< [out] Pointer to name in buf. */
    char **value_string,    /**< [out] Pointer to value string in buf. */
    bigint *value)          /**< [out] Pointer to value. */
{
    const char *seps = ": \t\r\n=";
    char *ptr;
    *value = 0;
    buf += strspn(buf,seps);        /* Skip separators */
    if( *buf == '\0' ) return 0;

    *name = buf;
    buf += strcspn(buf,seps);       /* Skip over name */
    if( *buf == '\0' ) return 1;
    *buf++ = '\0';

    buf += strspn(buf,seps+1);        /* Skip separators */
    if( *buf == '#' || *buf == '\0' ) return 1;

    *value_string = buf;
    *value = aapl_strtol(*value_string,&ptr,0);    /* Parse value */
    buf += strcspn(buf,"\r\n");       /* Skip over value */
    while( buf > *value_string && (buf[-1] == ' ' || buf[-1] == '\t') )
        buf--;
    *buf = '\0';

    if( **name == '#' ) return 0;
    return 2;
}

/** @brief Parse string for an array of integers, extracting and storing up to count integers into array. */
/** @return Return the number of integers stored. */
static int read_int_array(const char *string, int count, int *array)
{
    const char *seps = ", ";
    int i;
    for( i = 0; i < count; i++ )
    {
        char *ptr;
        string += strspn(string,seps);        /* Skip separators */
        array[i] = strtol(string,&ptr,0);
        if( ptr == string ) break;
        string = ptr;
    }
    return i;
}

/** @brief   Loads phase data from a file. */
/** @details Does not require AAPL connection to any hardware. */
/** @return  Returns 0 on success, non-zero on error, and logs specific problem. */
int avago_serdes_eye_data_read_phase(
    Aapl_t *aapl,                   /**< Pointer to Aapl_t structure. */
    const char *filename,           /**< Name of file containing phase data */
    Avago_serdes_eye_data_t *datap) /**< Where to save phase data */
{
    int ret = -1;
    char *buf = aapl_read_file(aapl, filename);
    if( buf )
    {
        char *ptr = strstr(buf,"phase_data:");
        if( ptr )
        {
            ret = parse_phase_data(aapl, datap, ptr + 11);
#if 0
            printf("center=%f, table=", datap->ed_phase_center);
            for( uint i = 0; i < datap->ed_phase_table_len; i++ )
                printf(",%6.2f", datap->ed_phase_table[i]);
            printf("\n");
#endif
        }
        else
            ret = aapl_fail(aapl, __func__, __LINE__, "Can't find \"phase_data:\" in file \"%s\"\n", filename);

        aapl_free(aapl, buf, "phase_data");
    }
    else
        ret = aapl_fail(aapl, __func__, __LINE__, "Can't open \"%s\": %s\n", filename, strerror(errno));
    return ret;
}

/** @brief   Loads eye data from a file. */
/** @details Does not require AAPL connection to any hardware. */
/** @return  Returns 0 on success, non-zero on error, and logs specific problem. */
/** @see     avago_serdes_eye_data_write_file(). */
int avago_serdes_eye_data_read_file(
    Aapl_t *aapl,                   /**< Pointer to Aapl_t structure. */
    const char *filename,           /**< name of file containing eye data */
    Avago_serdes_eye_data_t *datap) /**< eye data structure to fill in */
{
    char line[4096];
    int linenum = 0;
    FILE *file = fopen(filename,"r");
    BOOL in_header = TRUE;
    char *ptr;
    float avdd = datap->ed_avdd;

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "%s\n",filename);

    if( !file )
        return aapl_fail(aapl, __func__, __LINE__, "ERROR opening file %s\n",filename);

    ptr = (char *)aapl_malloc(aapl,300,__func__);
    if( ptr == 0 )
    {
        fclose(file);
        return -1;
    }
    *ptr = '\0';
    avago_serdes_eye_data_deinit(aapl, datap);
    avago_serdes_eye_data_init(datap);
    datap->ed_hardware_log = ptr;

    datap->ed_error_threshold = 30;    /* Default */
    datap->ed_width = 0;
    datap->ed_height = 0;
    datap->ed_x_points = 64;
    datap->ed_y_points = 64;
    datap->ed_data_qual.d6_data_qual = AVAGO_SERDES_RX_DATA_QUAL_DEFAULT;
    datap->ed_cmp_mode = AVAGO_SERDES_RX_CMP_MODE_XOR;
    datap->ed_y_resolution = 256;
    datap->ed_y_mission_points = 0;
    datap->ed_y_mission_step = 0;
    datap->ed_y_mission_min = 0;
    datap->eye_count = 1;

    /* Parse file contents for various fields: */
    /* */
    while( fgets(line, sizeof(line), file) )
    {
        linenum++;

        if( in_header )
        {
            char *name = 0, *str_val = 0;
            bigint value;
            int count = get_name_value_pair(line,&name,&str_val,&value);
            float dval;

            if( count > 1 || (name && (*name == '#')) )
            aapl_log_printf(aapl,AVAGO_DEBUG4,__func__,__LINE__,"count=%d, name=\"%s\", str_val=\"%s\", value=%ld\n",count,name,str_val,value);

            if( count == 0 && str_val && 0 == strncmp(str_val,"Phase", 5) && 0!=strstr(str_val+6,"index") )
            {
                allocate_eye_arrays(aapl, datap);
                in_header = FALSE;
            }
            if( count != 2 ) continue;  /* blank or comment lines */

/*          else if( EQS(name,"# EYE DIAGRAM DATA\n"); */
/*          else if( EQS(name,"capture_date"    ) ) time_str); */

            if     ( EQS(name,"eye_count"       ) ) datap->eye_count = (uint)value;
            else if( EQS(name,"x.width"         ) ) datap->ed_width = (uint)value;
            else if( EQS(name,"y.height"        ) ) datap->ed_height = (uint)value;

            else if( EQS(name,"x.width_mUI"     ) ) datap->ed_width_mUI = (uint)value;
            else if( EQS(name,"y.height_mV"     ) ) datap->ed_height_mV = (uint)value;

            else if( EQS(name,"x.UI"            ) ) datap->ed_x_UI = (uint)value;
            else if( EQS(name,"x.points"        ) ) datap->ed_x_points = MIN((uint)value, 8193U);   /* 8 UI at 1/16 rate. */
            else if( EQS(name,"x.step"          ) ) datap->ed_x_step = (uint)value;
            else if( EQS(name,"x.resolution"    ) ) datap->ed_x_resolution = (uint)value;

            else if( EQS(name,"x.min"           ) ) datap->ed_x_min = (int)value;
            else if( EQS(name,"x.max"           ) ) datap->ed_x_max = (int)value;
            else if( EQS(name,"x.shift"         ) ) datap->ed_x_shift = (int)value;
            else if( EQS(name,"x.sbm_center"    ) ) datap->ed_x_sbm_center = (int)value;
            else if( EQS(name,"x.center2-3"     ) ) datap->ed_x_center[2] = (int)value;
            else if( EQS(name,"x.center1-2"     ) ) datap->ed_x_center[1] = (int)value;
            else if( EQS(name,"x.center0-1"     ) ) datap->ed_x_center[0] = (int)value;
            else if( EQS(name,"x.center"        ) ){ int i, values[6], n = read_int_array(str_val, 6, values);
                                                     for( i = 0; i < n; i++ )
                                                        datap->ed_x_center[i] = values[i];
                                                   }

            else if( EQS(name,"y.resolution"    ) ) datap->ed_y_resolution = (uint)value;
            else if( EQS(name,"y.center_row"    ) ){ int i, values[6], n = read_int_array(str_val, 6, values);
                                                     for( i = 0; i < n; i++ )
                                                        datap->ed_hbtc[i].data_row = values[i];
                                                   }
            else if( EQS(name,"y.center2-3"     ) ){datap->ed_hbtc[2].data_row = (uint)value; if( value != -1 ) datap->eye_count = 3; }
            else if( EQS(name,"y.center1-2"     ) ) datap->ed_hbtc[1].data_row = (uint)value;
            else if( EQS(name,"y.center0-1"     ) ) datap->ed_hbtc[0].data_row = (uint)value;
            else if( EQS(name,"y.points"        ) ) datap->ed_y_points = MIN((uint)value, AAPL_MAX_DAC_RANGE);
            else if( EQS(name,"y.step"          ) ) datap->ed_y_step = (uint)value;
            else if( EQS(name,"y.min"           ) ) datap->ed_y_min = (uint)value;
            else if( EQS(name,"y.mission_points") ) datap->ed_y_mission_points = MIN((uint)value, (uint)AAPL_ARRAY_LENGTH(datap->ed_mission_errors[0]));
            else if( EQS(name,"y.mission_step"  ) ) datap->ed_y_mission_step = (uint)value;
            else if( EQS(name,"y.mission_min"   ) ) datap->ed_y_mission_min = (uint)value;

            else if( EQS(name,"SBus_address"    ) ) ptr += sprintf(ptr,"%s:%*s%s\n",name,(int)(15-strlen(name))," ",str_val);
            else if( EQS(name,"JTAG_ID"         ) ) ptr += sprintf(ptr,"%s:%*s%s\n",name,(int)(15-strlen(name))," ",str_val);
            else if( EQS(name,"Process_ID"      ) ) ptr += sprintf(ptr,"%s:%*s%s\n",name,(int)(15-strlen(name))," ",str_val);
            else if( EQS(name,"SBus_master"     ) ) ptr += sprintf(ptr,"%s:%*s%s\n",name,(int)(15-strlen(name))," ",str_val);
            else if( EQS(name,"SerDes"          ) ) ptr += sprintf(ptr,"%s:%*s%s\n",name,(int)(15-strlen(name))," ",str_val);

            else if( EQS(name,"center_data"     ) ) datap->ed_phase_center_log = aapl_strdup(str_val);
            else if( EQS(name,"phase_data"      ) ) parse_phase_data(aapl, datap, str_val);
            else if( EQS(name,"data_qual"       ) ) aapl_str_to_data_qual(str_val,&datap->ed_data_qual);
            else if( EQS(name,"vert_alpha"      ) ) datap->ed_apply_vert_alpha = getint(str_val);
            else if( 0==strncmp(name,"dfe.",4   ) ) avago_update_dfe_field(&datap->ed_dfe_state, name, value, str_val);
            else if( 0==strncmp(name,"hal.",4   ) ) avago_update_hal_field(datap, name, value);
            else if( EQS(name,"set_center"      ) ) datap->ed_set_phase_center  = getint(str_val);
            else if( EQS(name,"user_comment"    ) ) datap->ed_comment          = aapl_strdup(str_val);

            else if( EQS(name,"eye_type"        ) ) aapl_str_to_eye_type (str_val,&datap->ed_eye_type);
            else if( EQS(name,"compare_mode"    ) ) aapl_str_to_cmp_mode (str_val,&datap->ed_cmp_mode);
            else if( EQS(name,"fast_dynamic"    ) ) datap->ed_fast_dynamic     = getint(str_val);
            else if( EQS(name,"center_options"  ) ) datap->ed_centering_options = getint(str_val);
            else if( EQS(name,"error_threshold" ) ) datap->ed_error_threshold = (uint)value;

            /* Floating point values: */
            else if( EQS(name,"dc_balance"      ) ) sscanf(str_val, "%20f",&datap->ed_dc_balance);
            else if( EQS(name,"trans_density"   ) ) sscanf(str_val, "%20f",&datap->ed_trans_density);
            else if( EQS(name,"avdd"            ) ) sscanf(str_val, "%20f",&datap->ed_avdd);
            else if( EQS(name,"dac_scale"       ) ) sscanf(str_val, "%20lf",&datap->ed_dac_scale);
            else if( EQS(name,"min_dwell_bits"  ) ) sscanf(str_val, "%20g",&dval),datap->ed_min_dwell_bits = (bigint)dval;
            else if( EQS(name,"max_dwell_bits"  ) ) sscanf(str_val, "%20g",&dval),datap->ed_max_dwell_bits = (bigint)dval;
        }
        else /* In data: */
        {
            char *argv[20];
            int argc = split(line, " ,\t", argv);
            if( argv[0][0] == '#' && EQS(argv[1],"BATHTUB") )
                break;  /* Skip rest of file */
            if( argv[0][0] == '#' && EQS(argv[1],"Horizontal") )
                break;  /* Skip rest of file */
            if( argv[0][0] == '#' && EQS(argv[1],"Vertical") )
                break;  /* Skip rest of file */
            if( argc >= 3 && argv[0][0] != '#' )
            {
                 int x = MIN((int)datap->ed_x_points-1,MAX(-AAPL_ARRAY_LENGTH(datap->ed_mission_errors),getint(argv[0])));
                uint y = MIN((uint)getint(argv[1]),datap->ed_y_resolution-1);
                bigint *errorsp = (bigint *)&get_errs_column(datap, x)[y];
                bigint *bitsp   = (bigint *)&get_bits_column(datap, x)[y];
                bigint errs = getbigint(argv[2]);
                bigint bits;

                if( errs < 0 )       bits = 0;
                else if( argc >= 4 ) bits = getbigint(argv[3]);
                else                 bits = datap->ed_max_dwell_bits;

                if( x >= -datap->eye_count && x < (int)datap->ed_x_points && ((x >= 0 && y < datap->ed_y_points) || y < datap->ed_y_resolution) )
                {
                    *errorsp = errs;
                    *bitsp   = bits;
                }
                else
                {
                    aapl_log_printf(aapl,AVAGO_WARNING,__func__,__LINE__,"Warning: Data index out of range at [%d,%u]\n",x,y);
                }
            }
        }
    }
    datap->ed_y_center_point = get_dac_for_y_index(datap, (datap->ed_y_points - 1) / 2, FALSE);

    if( datap->ed_avdd      == 0.0 ) datap->ed_avdd = 1.0;
    if( datap->ed_dac_scale == 0.0 ) datap->ed_dac_scale = 1000.0 * datap->ed_avdd / datap->ed_y_resolution;
    if( avdd > 0.0 )
    {
        datap->ed_dac_scale *= avdd / datap->ed_avdd;
        datap->ed_avdd = avdd;
    }

    /*printf("%d: y_center=%d, step=%u, points=%u\n", __LINE__, datap->ed_y_center_point, datap->ed_y_step, datap->ed_y_points); */

    /* If mission values not specified, assume they match test data: */
    if( datap->ed_y_mission_points == 0 ) datap->ed_y_mission_points = datap->ed_y_points;
    if( datap->ed_y_mission_step   == 0 ) datap->ed_y_mission_step   = datap->ed_y_step;
    if( datap->ed_y_mission_points == 0 ) datap->ed_y_mission_min    = datap->ed_y_min;
    copy_mission_to_data(datap);

/*#ifdef MEAN_EYE_FORCE_READ */
    if ( datap->ed_gather_mean )
        force_mean_eye_points(datap);
/*#endif // MEAN_EYE_FORCE_READ */

    serdes_eye_calc_gradient(datap);
    serdes_eye_calc_qval(aapl,datap);
    vbtc_extrapolate_mission(datap);
    hbtc_extrapolate(datap);

    if( *datap->ed_hardware_log == '\0' )
    {
        aapl_free(aapl, datap->ed_hardware_log,__func__);
        datap->ed_hardware_log = 0;
    }

    fclose(file);
    if( aapl->debug >= 4 ) { uint x; for( x = 0; x < datap->ed_x_points; x++ ) { aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "mUI[%u] = %f\n", x, mui_from_index(datap,x)); } }
    return aapl->return_code;
}
#endif /* AAPL_ENABLE_FILE_IO */


/* Functions to access low-level data: */

static int serdes_eye_range_check(Aapl_t *aapl, const Avago_serdes_eye_data_t *datap,
        uint x_point, uint y_point, const char *field)
{
    if( y_point >= datap->ed_y_points )
    {
        aapl_fail(aapl, __func__, __LINE__,
            "Y coordinate (%u) beyond number of points in %u (%u).", field, y_point, datap->ed_y_points);
        return 0;
    }
    if( x_point >= datap->ed_x_points )
    {
        aapl_fail(aapl, __func__, __LINE__,
            "X coordinate (%u) beyond number of points in %u (%u).", field, x_point, datap->ed_x_points);
        return 0;
    }
    return 1;
}

/** @brief    Accessor function to retrieve one error count from */
/**           Avago_serdes_eye_data_t, which must contain non-null ed_errorsp field. */
/** @details  (If linking from C, use AVAGO_EYE_ERRORS_GET() macro instead for */
/**           possibly better performance.) */
/** @return   Error count at this coordinate; -2 means X/Y error. */
/** @see      avago_serdes_eye_bits_get(), avago_serdes_eye_grad_get(), avago_serdes_eye_qval_get(). */
bigint avago_serdes_eye_errors_get(
    Aapl_t *aapl,                           /**< Pointer to Aapl_t structure. */
    const Avago_serdes_eye_data_t *datap,   /**< Eye data pointer. */
    uint x_point,                           /**< X (phase) coordinate. */
    uint y_point)                           /**< Y (DAC) coordinate. */
{
    if( !serdes_eye_range_check(aapl,datap,x_point,y_point,"ed_errorsp") )
        return -2;
    return AVAGO_EYE_ERRORS_GET(*datap, x_point, y_point);
}

/** @brief    Accessor function to retrieve one bit (RX dwell) count from */
/**           Avago_serdes_eye_data_t, which must contain non-null ed_bitsp. */
/** @details  If linking from C, use AVAGO_EYE_BITS_GET() macro instead for */
/**           possibly better performance. */
/** @return   Bit (dwell) count at this coordinate; 0 means no data yet */
/**           at this point; -2 means X/Y error. */
/** @see      avago_serdes_eye_errors_get(). */
bigint avago_serdes_eye_bits_get(
    Aapl_t *aapl,                           /**< Pointer to Aapl_t structure. */
    const Avago_serdes_eye_data_t *datap,   /**< Eye data pointer. */
    uint x_point,                           /**< X (phase) coordinate. */
    uint y_point)                           /**< Y (DAC) coordinate. */
{
    if( !serdes_eye_range_check(aapl,datap,x_point,y_point,"ed_bitsp") )
        return -2;
    return AVAGO_EYE_BITS_GET(*datap, x_point, y_point);
}

/** @brief    Accessor function to retrieve gradient for one bit from */
/**           Avago_serdes_eye_data_t, which must contain non-null ed_gradp. */
/**           Note also that the gradient is only calculated for x and y > 0. */
/** @details  If linking from C, use AVAGO_EYE_GRAD_GET() macro instead for */
/**           possibly better performance. */
/** @return   Gradient value at this coordinate; -2 means X/Y range error. */
/** @see      avago_serdes_eye_errors_get(), avago_serdes_eye_bits_get(). */
float avago_serdes_eye_grad_get(
    Aapl_t *aapl,                           /**< Pointer to Aapl_t structure. */
    const Avago_serdes_eye_data_t *datap,   /**< Eye data pointer. */
    uint x_point,                           /**< X (phase) coordinate. */
    uint y_point)                           /**< Y (DAC) coordinate. */
{
    if( !serdes_eye_range_check(aapl,datap,x_point,y_point,"ed_gradp") )
        return -2;
    return AVAGO_EYE_GRAD_GET(*datap, x_point, y_point);
}

/** @brief    Accessor function to retrieve Q value for one bit from */
/**           Avago_serdes_eye_data_t, which must contain non-null ed_qvalp. */
/** @details  If linking from C, use AVAGO_EYE_QVAL_GET() macro instead for */
/**           possibly better performance. */
/** @return   Q value at this coordinate; -100 means X/Y range error. */
/** @see      avago_serdes_eye_errors_get(), avago_serdes_eye_bits_get(). */
float avago_serdes_eye_qval_get(
    Aapl_t *aapl,                           /**< Pointer to Aapl_t structure. */
    const Avago_serdes_eye_data_t *datap,   /**< Eye data pointer. */
     int x_point,                           /**< X (phase) coordinate. */
    uint y_point)                           /**< Y (DAC) coordinate. */
{
    /* If a mission value request, calculate it. */
    if( x_point >= -AAPL_ARRAY_LENGTH(datap->ed_mission_errors) && x_point < 0 && y_point < AAPL_ARRAY_LENGTH(datap->ed_mission_errors[0]) )
    {
        bigint errors = get_errs_column(datap, x_point)[y_point];
        bigint bits   = get_bits_column(datap, x_point)[y_point];
        double BER = avago_calc_BER(errors, bits, datap->ed_dc_balance);
        return (float)avago_qfuncinv(BER);
    }

    /* If not a mission value request, verify it is in range and then look it up: */
    if( aapl && !serdes_eye_range_check(aapl,datap,x_point,y_point,"ed_qvalp") )
        return -100;
    return AVAGO_EYE_QVAL_GET(*datap, x_point, y_point);
}

/** @cond INTERNAL */

int sbm_eye_gather(
    Aapl_t *aapl,
    uint addr,
    bigint dwell,
    int eye_start,
    uint eye_points,
    uint eye_step,
    uint eye_gather,
    uint options)
{
    uint sbm_addr = avago_make_sbus_master_addr(addr);
    bigint bits[512];
    bigint errs[512];
    Eye_state_t es;
    Eye_state_t *esp = &es;
    uint i;
    int row, col;

    Avago_serdes_eye_config_t *configp = avago_serdes_eye_config_construct(aapl);
    Avago_serdes_eye_data_t   *datap   = avago_serdes_eye_data_construct(aapl);
    memset(bits,0,sizeof(bits));
    memset(errs,0,sizeof(errs));

    aapl_log_printf(aapl,AVAGO_INFO,0,0,"EYE_GATHER(SBus %s; dwell %s; %d..%u..%u; 0x%x\n", aapl_addr_to_str(addr), aapl_bigint_to_str(dwell), eye_start, eye_points, eye_step, eye_gather);

    init_eye_state(esp, aapl, addr, configp, datap);

    eye_points = MIN(eye_points,512);
    eye_set_error_timer(esp, dwell);

    /* avago_serdes_set_error_timer(aapl, addr, dwell); */
    if( 0 == (options & 1) )
    avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_ADDR       | (0x0ff & addr));
    avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_RESOLUTION | (0x7ff & avago_serdes_get_phase_multiplier(aapl, addr)));
    avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_START      | (0x7ff & eye_start));
    avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_POINTS     | (0x7ff & eye_points));
    avago_spico_int_check(aapl, __func__, __LINE__, sbm_addr, SBM_INT, EYE_SET_STEP       | (0x7ff & eye_step));
    sbm_eye_set_options(esp);
    sbm_eye_gather_data(esp, eye_gather, bits, errs, 1, eye_points);

    aapl_log_printf(aapl,AVAGO_INFO,0,0,"SBM Phase center: %d\n", (short)avago_spico_int(aapl, sbm_addr, SBM_INT, EYE_READ_CENTER));
    aapl_log_printf(aapl,AVAGO_INFO,0,0,"Phase             %d\n", (short)avago_spico_int(esp->aapl, sbm_addr, SBM_INT, EYE_READ_PHASE));
    for( i = 0; i < eye_points; i++ )
    {
        if( (eye_gather&0xf000) == 0xa000 ) /* row */
        {
            row = eye_gather & 0x7ff;
            col = i * eye_step + eye_start;
            if( row & 0x400 )
                row = (short)(row | 0xf800);
        }
        else if( (eye_gather&0xf000) == 0xb000 ) /* col */
        {
            row = i * eye_step + eye_start;
            col = eye_gather & 0x7ff;
            if( col & 0x400 )
                col = (short)(col | 0xf800);
        }
        else
        {
            row = i;
            col = -1;   /* Mission */
        }
        aapl_log_printf(aapl,AVAGO_INFO,0,0,"BER[%4d,%4d] = %10s / %7s\n", col, row, aapl_bigint_to_str(errs[i]), aapl_bigint_to_str(bits[i]));
    }
    return 0;
}

/** @endcond */

/** @} */

#endif /* AAPL_ENABLE_EYE_MEASUREMENT */
