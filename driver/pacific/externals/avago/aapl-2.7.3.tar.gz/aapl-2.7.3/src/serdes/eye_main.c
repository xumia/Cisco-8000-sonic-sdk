/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* MAIN program for the eye command. */
/* */

/** Doxygen File Header */
/** @file */
/** @brief Launch wrappers for eye plotting. */
/** @defgroup Eye Eye Capture Functions */
/** @{ */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS

#include "aapl.h"


/*============================================================================= */
/* EYE_MAIN */

#if AAPL_ENABLE_MAIN && AAPL_ENABLE_EYE_MEASUREMENT

static int show_eye_help()
{
    aapl_common_main_help(TRUE);
printf(
"-select <type>            Full (default), size, height, width, vdual or dvos.\n"
"-cmp-mode <XOR|Test_PatGen>   Set RX compare mode; default = XOR\n"
"-data-qual <qual>         Qualified eye gather. Omit for default gather.\n"
);
printf(
"-min-dwell <int>          Minimum RX bits to gather errors at any one eye\n"
"                            pixel (data point); default = 1e6.\n"
"-max-dwell <int>          Maximum RX bits to gather errors at any one eye\n"
"                            pixel (data point); default = 1e6.\n"
"-error-threshold <int>    Set the error count threshold for ending dynamic\n"
"                            dwell on a point; default = 30.\n"
);
printf(
"-fast-dynamic <0|1|2>     Set dynamic dwell mode; default = 2.\n"
"                            2 dwells only on points useful for BTC calcs.\n"
"                            1 dwells if a neighbor error count is above error-threshold.\n"
"                            0 dwells if a neighbor error count is above 0.\n"
);
printf(
"-x-UI <int>               Number of UI to scan; default = 1.\n"
"-x-resolution <int>       Points to gather per UI; default = auto; min = 8.\n"
"                            Value is rounded down to the nearest power of 2.\n"
"-x-shift <int>            Phase steps to shift UI center.\n"
"-y-step-size <int>        Set DAC scan resolution; default = 1.\n"
);
printf(
"-y-points <int>           Points to gather over the Y range; default = auto.\n"
"                            y-points will be adjusted to keep the product\n"
"                            of y-points * y-step-size in range.\n"
);
printf(
"-gather-mean              Gather only points that bracket 50 percent mean point.  Zero rest of data.\n"
"-mean-threshold           (Optional) Gather mean threshold of calculated 50 percent value.\n"
);
printf(
"-mean-direction           (Optional) Set direction of mean eye gather.\n"
"                            2 scan bottom-up and servo around first 50 percent mean point (ie. bottom of full eye).\n"
"                            1 scan top-down  and servo around first 50 percent mean point (ie. top    of full eye).\n"
"                            0 auto, find all 50 percent mean points (ie. full eye). Default.\n"
"-nosbm                    Disable SBM firmware assist (debug);  default = false.\n"
);
printf(
"-print-ascii-eye          Write an ascii eye plot to stdout.\n"
"-print-gradient-eye       Write an ascii gradient plot to stdout.\n"
"-print-contour-eye        Write an ascii Q value contour plot to stdout.\n"
"-print-btc                Short-cut for '-print-vbtc -print-hbtc'.\n"
"-print-vbtc               Print the eye height and VBTC info.\n"
"-print-hbtc               Print the eye width and HBTC info.\n"
);
printf(
"-print-column-vbtc <col>  Print the VBTC for column (+/- columns from center).\n"
"-print-row-hbtc    <row>  Print the HBTC for row (+/- rows from center).\n"
"-print-all-column-vbtc    Print VBTCs for all columns.\n"
"-print-all-row-hbtc       Print HBTCs for all rows.\n"
);
printf(
"-read-file eye_data.txt   Read an eye data file.\n"
"-write-file eye_data.txt  Write an eye data file.\n"
"-phase-file phase.txt     Read phase corrections file.\n"
"-comment <comment>        Add <comment> string to the data file.\n"
);
printf(
"-dc-balance <float>       Override the default DC balance of 0.5.\n"
"-trans-density <float>    Override the default transition density of 0.5.\n"
"-avdd <float>             Set the voltage (in Volts) for the VBTC calculations.\n"
"-vert-alpha <0|1>         Disable/enable (default) vert-alpha correction.\n"
);
printf(
"-centering-options <int>  Set flags to control eye centering.\n"
"                              Bit 0 = disable HW centering.\n"
"-set-phase-center <0|1|2> Disable/enable waveform centering; default = 2.\n"
"                              1 = basic centering only.\n"
"\n"
);

    return 1;
}

const int out_of_range = 999999;
const int all_range = 500;

void print_column_vbtc(Aapl_t *aapl, Avago_serdes_eye_data_t *datap, int column)
{
    int i;
    for( i = 0; i < datap->eye_count; i++ )
    {
        int which = datap->eye_count == 6 ? (i%2) + 2 * (2 - i/2) : i; /* Order PAM4 output */
        Avago_serdes_eye_vbtc_t vbtc_calc;
        avago_serdes_eye_vbtc_extrapolate(datap, which, column, &vbtc_calc);
        avago_serdes_eye_vbtc_log_print(aapl, AVAGO_INFO, 0, 0, &vbtc_calc);
    }
}

/** @brief  Invokes the command line interface to eye gathering. */
/** @return Returns 0 on success, >0 if any errors. */
int aapl_eye_main(int argc, char *argv[], Aapl_t *aapl)
{
/* Prepare AAPL API: */

    Avago_serdes_eye_config_t *configp = 0;
    Avago_serdes_eye_data_t   *datap   = 0;

/* Parse options: */

    int         return_status = 1, rc, index = 0;
#if AAPL_ENABLE_FILE_IO
    const char *phase_file = 0;
    int         write_file_count = 0;
#endif /* AAPL_ENABLE_FILE_IO */
    const char *read_file_name = 0;
    const char *write_file_name = 0;
    BOOL        print_ascii_eye = FALSE;
    BOOL        print_gradient_eye = FALSE;
    BOOL        print_contour_eye = FALSE;
    BOOL        print_hbtc = FALSE;
    BOOL        print_vbtc = FALSE;
    int         row_hbtc    = out_of_range; /* Any out of range value */
    int         column_vbtc = out_of_range; /* Any out of range value */
    BOOL        have_user_option = FALSE;
    BOOL st;
    Avago_addr_t addr_struct, start, stop, next;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"cmp-mode",         1, NULL, 'P'},  /* ec_cmp_mode (AVAGO_SERDES_RX_CMP_MODE_XOR) */
        {"data-qual",        1, NULL, 'q'},  /* ec_data_qual (AVAGO_SERDES_RX_DATA_QUAL_DEFAULT) */
        {"dc-balance",       1, NULL, 'B'},  /* ec_dc_balance. */
        {"error-threshold",  1, NULL, 'E'},  /* ec_error_threshold */
        {"fast-dynamic",     1, NULL, 'f'},  /* ec_fast_dynamic */
        {"read-file",        1, NULL, 'F'},  /* <eye data file name> */
        {"load-file",        1, NULL, 'F'},  /* <eye data file name> */
        {"phase-file",       1, NULL, 'p'},  /* <phase adjustments file name> */
        {"max-dwell",        1, NULL, 'N'},  /* ec_max_dwell_bits. */
        {"min-dwell",        1, NULL, 'm'},  /* ec_min_dwell_bits. */
        {"real-time",        1, NULL, 'r'},  /* ec_real_time_plot. */
        {"print-ascii-eye",  0, NULL, 'Q'},  /* print_ascii_eye */
        {"print-gradient-eye",0,NULL, 'G'},  /* print_gradient_eye */
        {"print-contour-eye",0, NULL, 'R'},  /* print_contour_eye */
        {"print-btc",        0, NULL,  6 },  /* print vbtc and hbtc info */
        {"print-vbtc",       0, NULL, 'V'},  /* print vbtc and height info */
        {"print-hbtc",       0, NULL, 'H'},  /* print hbtc and width info */
        {"centering-options",     1, NULL,  1 },  /* 1 == ignore HW centering. */
        {"print-column-vbtc",     1, NULL,  2 }, /* Print vbtc for given column */
        {"print-row-hbtc",        1, NULL,  3 }, /* Print hbtc for given row */
        {"print-all-column-vbtc", 0, NULL,  4 }, /* Print vbtc for all columns */
        {"print-all-row-hbtc",    0, NULL,  5 }, /* Print hbtc for all rows */
        {"write-file",       1, NULL, 'w'},  /* <eye data file name> */
        {"comment",          1, NULL, 'C'},  /* Add comment to eye data file. */
        {"select",           1, NULL, 'T'},  /* ec_eye_type. */
        {"set-phase-center", 1, NULL, 'c'},  /* ec_set_phase_center. */
        {"trans-density",    1, NULL, 't'},  /* ec_trans_density. */
        {"vert-alpha",       1, NULL, 'v'},  /* ec_apply_vert_alpha. */
        {"x-UI",             1, NULL, 'x'},  /* ec_x_UI. */
        {"x-resolution",     1, NULL, 'X'},  /* ec_x_resolution. */
        {"x-shift",          1, NULL, 'S'},  /* ec_x_shift. */
        {"y-center-point",   1, NULL, 'y'},  /* ec_y_center_point. */
        {"y-points",         1, NULL, 'Y'},  /* ec_y_points. */
        {"y-step-size",      1, NULL, 'z'},  /* ec_y_step_size. */
        {"gather-mean",      0, NULL, 10},   /* ec_gather_mean. */
        {"mean-threshold",   1, NULL, 11},   /* ec_mean_threshold */
        {"mean-direction",   1, NULL, 12},   /* ec_mean_direction */
        {"nosbm",            0, NULL, 13 },  /* ec_no_sbm */
        {"no-sbm",           0, NULL, 13 },  /* ec_no_sbm */
        {"avdd",             1, NULL, 14 },  /* ec_avdd and ed_avdd */
        {NULL,               0, NULL, 0  },  /* sentinel entry. */
    };

    avago_addr_to_struct(aapl_default_device_addr, &addr_struct);
    if( aapl_common_main_options(aapl, argc, argv, &addr_struct) < 0 )
    {
        show_eye_help();
        goto eye_cleanup_and_exit;
    }
    configp = avago_serdes_eye_config_construct(aapl);
    datap   = avago_serdes_eye_data_construct(  aapl);

    if( aapl->return_code < 0 ) goto eye_cleanup_and_exit;  /* assume anomalies already reported. */

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        have_user_option = TRUE;
        switch( rc )
        {
        case  1 : configp->ec_centering_options= aapl_num_from_str(optarg, name, 0); break;
        case  2 : column_vbtc                  = aapl_num_from_str(optarg, name, 0); break;
        case  3 : row_hbtc                     = aapl_num_from_str(optarg, name, 0); break;
        case  4 : column_vbtc                  = all_range; break; /* special value to indicate all columns */
        case  5 : row_hbtc                     = all_range; break; /* special value to indicate all rows */
        case 'T': if( !aapl_str_to_eye_type(optarg, &configp->ec_eye_type) )
                  {
                      aapl_main_print_error("-%s option requires a valid eye type; got: \"%s\".", name, optarg);
                      goto eye_cleanup_and_exit;
                  }
                  break;

        case 'r': aapl_main_print_error("-%s option is no longer supported.", name); break;

        case 'c': configp->ec_set_phase_center = aapl_num_from_str(optarg, name, 0);   break;
        case 'E': configp->ec_error_threshold  = aapl_num_from_str(optarg, name, 0);   break;
        case 'S': configp->ec_x_shift          = aapl_num_from_str(optarg, name, 0);   break;
        case 'f': configp->ec_fast_dynamic     = aapl_num_from_str(optarg, name, 0);   break;
        case 'm': configp->ec_min_dwell_bits   = aapl_nume_from_str(optarg, name);     break;
        case 'N': configp->ec_max_dwell_bits   = aapl_nume_from_str(optarg, name);     break;
        case 'q': configp->ec_data_qual        = aapl_data_qual_from_str(optarg,name); break;
        case 'P': configp->ec_cmp_mode         = aapl_cmp_mode_from_str( optarg,name); break;
        case 'B': sscanf(optarg, "%10f",&configp->ec_dc_balance); break;
        case 't': sscanf(optarg, "%10f",&configp->ec_trans_density); break;
        case 'v': configp->ec_apply_vert_alpha = aapl_num_from_str(optarg, name, 0);  break;
        case 'x': configp->ec_x_UI             = aapl_num_from_str( optarg, name, 0); break;
        case 'X': configp->ec_x_resolution     = aapl_num_from_str( optarg, name, 0);
                  configp->ec_x_auto_scale     = FALSE;
                  break;
        case 'y': configp->ec_y_center_point   = aapl_num_from_str( optarg, name, 0); break;
        case 'Y': configp->ec_y_points         = aapl_num_from_str( optarg, name, 0);
                  if( configp->ec_y_points != 0 ) configp->ec_y_auto_scale = FALSE;
                  break;
        case 'z': configp->ec_y_step_size      = aapl_num_from_str( optarg, name, 0); break;
#if AAPL_ENABLE_FILE_IO
        case 'F': read_file_name = optarg; break;
        case 'p': phase_file = optarg; break;
        case 'w': write_file_name = optarg; break;
#endif /* AAPL_ENABLE_FILE_IO */
        case 'C': datap->ed_comment = optarg; break;
        case 'Q': print_ascii_eye = TRUE; break;
        case 'G': print_gradient_eye = TRUE; break;
        case 'R': print_contour_eye = TRUE; break;
        case 'H': print_hbtc = TRUE; break;
        case 'V': print_vbtc = TRUE; break;
        case  6 : print_hbtc = print_vbtc = TRUE; break;
        case 10 : configp->ec_gather_mean   = TRUE; break;
        case 11 : configp->ec_mean_threshold  = aapl_nume_from_str(optarg, name);     break;
        case 12 : configp->ec_mean_direction  = aapl_num_from_str( optarg, name, 0); break;
        case 13 : configp->ec_no_sbm        = TRUE; break;
        case 14 : sscanf(optarg, "%10f",&configp->ec_avdd);
                  datap->ed_avdd = configp->ec_avdd;    /* To override voltage in .ebert file. */
                  break;
        case '?':
        default:
            if( (rc & 0xf000) != 0xf000 )
            {
                aapl_main_print_error("Run with -h for a usage summary.");
                goto eye_cleanup_and_exit;
            }
            break;
        }
    }

    if( !have_user_option )
    {
        show_eye_help();
        goto eye_cleanup_and_exit;
    }
    if( !read_file_name )
    {
        /* Must call before aapl_broadcast_first() for proper P1 traversal: */
        aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) goto eye_cleanup_and_exit;
        aapl_get_ip_info(aapl,0);
    }

    /* No args are allowed beyond options: */
    if( optind < argc )
    {
        aapl_main_unexpected_arg(argv[optind]);
        goto eye_cleanup_and_exit;
    }

    /* update >ed_gather_mean from ec_gather_mean (NOTE: slight hack to avoid changing params to read/write file) */
    datap->ed_gather_mean    = configp->ec_gather_mean;
    datap->ed_mean_threshold = configp->ec_mean_threshold;
    datap->ed_mean_direction = configp->ec_mean_direction;

    if( !write_file_name && aapl->debug == 0 && column_vbtc == out_of_range && row_hbtc == out_of_range && !print_ascii_eye && !print_contour_eye && !print_gradient_eye && !print_vbtc && !print_hbtc && configp->ec_eye_type != AVAGO_EYE_HEIGHT_DVOS )
    {
        aapl_main_print_error("No output selected: At least one of -write-file, -print-*, or -debug is required.");
        goto eye_cleanup_and_exit;
    }

    if( (configp->ec_cmp_mode & 0x0F00) != 0x0100 && (configp->ec_cmp_mode & 0x00F0) != 0x0010 )
    {
        aapl_main_print_error("Illegal compare mode selected:  one of XOR or TEST_PATGEN required.");
        goto eye_cleanup_and_exit;
    }

#if AAPL_ENABLE_FILE_IO
    if( phase_file )
        avago_serdes_eye_data_read_phase(aapl, phase_file, datap);
#endif /* AAPL_ENABLE_FILE_IO */

    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, 0);
         st;
         st = aapl_broadcast_next(aapl, &next, &start, &stop, 0) && !read_file_name )   /* If read_file_name, only do this once. */
    {
        uint addr = avago_struct_to_addr(&next);

#if AAPL_ENABLE_FILE_IO
        if( read_file_name )
        {
            if( (rc = avago_serdes_eye_data_read_file(aapl, read_file_name, datap)) < 0 )
                goto eye_cleanup_and_exit;
            return_status = 0;
        }
        else
#endif /* AAPL_ENABLE_FILE_IO */
        {
            if( aapl_get_ip_type(aapl, addr) != AVAGO_SERDES &&
                aapl_get_ip_type(aapl, addr) != AVAGO_P1 &&
                aapl_get_ip_type(aapl, addr) != AVAGO_M4 )
                continue; /* don't call lower level functions unless they are SerDes */

            /* Do eye data gathering: */
            if( ! (rc = (configp && datap && (avago_serdes_eye_get(aapl, addr, configp, datap) >= 0))) )
                goto eye_cleanup_and_exit;
            return_status = 0;
        }

#if AAPL_ENABLE_FILE_IO
        if( write_file_name )
        {
            write_file_count++;
            if( 0 == strcmp(write_file_name,"-") )
                avago_serdes_eye_data_write(stdout, datap);
            else if( write_file_count == 1 && addr_struct.next == 0 )
            {
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Writing eye data file %s\n", write_file_name);
                avago_serdes_eye_data_write_file(write_file_name, datap);
            }
            else    /* Multiple eyes, so write to unique file names */
            {
                uint name_len = strlen(write_file_name);
                uint buf_len = name_len + 12;
                char *name_buf = (char *)aapl_malloc(aapl, buf_len, "write_file_name_buffer");
                const char *suffix = strchr(write_file_name,'.');       /* Look for an extention on the name. */
                char *ptr;

                if( !suffix ) suffix = "\0";                            /* Set null suffix if no extension. */
                strcpy(name_buf, write_file_name);
                ptr = strchr(name_buf,'.');                             /* Set pointer to end of base name. */
                if( !ptr ) ptr = name_buf + name_len;                   /* If no extension, set to end of name. */
                snprintf(ptr, buf_len - (ptr-name_buf), "-sd%s%s", aapl_addr_to_str(addr), suffix);
#if defined __MINGW32__ || defined WIN32
                aapl_str_rep(name_buf,':','-');
#endif
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Writing eye data file %s\n", name_buf);
                avago_serdes_eye_data_write_file(name_buf, datap);
            }
        }

        if( print_ascii_eye && (aapl->debug & 0xf) < AVAGO_DEBUG2 )
            avago_serdes_eye_plot_write(stdout, datap);
        if( print_gradient_eye )
            avago_serdes_eye_gradient_plot_write(stdout, datap);
        if( print_contour_eye )
            avago_serdes_eye_contour_plot_write(stdout, datap);
#endif /* AAPL_ENABLE_FILE_IO */
        if( print_vbtc || print_hbtc )
            printf("\n");
        if( print_vbtc || configp->ec_eye_type == AVAGO_EYE_HEIGHT_DVOS )
            printf("SerDes at SBus %s has an eye height of %3d mV.\n",
                aapl_addr_to_str(addr), datap->ed_height_mV);
        if( print_vbtc )
        {
            int i;
            for( i = 0; i < datap->eye_count; i++ )
            {
                int which = datap->eye_count == 6 ? (i%2) + 2 * (2 - i/2) : datap->eye_count-1-i; /* Order PAM4 output */
                avago_serdes_eye_vbtc_log_print(aapl, AVAGO_INFO, 0, 0, &datap->ed_vbtc[which]);
            }

            if( configp->ec_eye_type == AVAGO_EYE_SIZE_VDUAL )
                print_column_vbtc(aapl, datap, datap->ed_x_UI * datap->ed_x_resolution / 2);
        }
        {
            int center = datap->ed_x_UI * datap->ed_x_resolution / 2;
            int start = column_vbtc == all_range ? -center : column_vbtc;
            int stop  = column_vbtc == all_range ?  center : column_vbtc;
            for( column_vbtc = start; column_vbtc <= stop; column_vbtc++ )
                if( column_vbtc >= -center && column_vbtc <= center )
                    print_column_vbtc(aapl, datap, column_vbtc + center);
        }
        if( print_hbtc )
        {
            int i;
            printf("\n");
            printf("SerDes at SBus %s has an eye width of %4d mUI.\n",
                    aapl_addr_to_str(addr), datap->ed_width_mUI);
            for( i = 0; i < datap->eye_count; i++ )
            {
                int which = datap->eye_count == 6 ? (i%2) + 2 * (2 - i/2) : datap->eye_count-1-i; /* Order PAM4 output */
                avago_serdes_eye_hbtc_log_print(aapl, AVAGO_INFO, 0, 0, &datap->ed_hbtc[which]);
            }
        }
        {
            int start = row_hbtc == all_range ? -(int)datap->ed_y_points/2 : row_hbtc;
            int stop  = row_hbtc == all_range ?  (int)datap->ed_y_points/2 : row_hbtc;
            for (row_hbtc = start; row_hbtc <= stop; row_hbtc++)
                if( row_hbtc > -(int)datap->ed_y_points/2 && row_hbtc < ((int)datap->ed_y_points-1)/2 )
                {
                    Avago_serdes_eye_hbtc_t btc;
                    avago_serdes_eye_hbtc_extrapolate(datap, 0, row_hbtc + datap->ed_y_points/2, datap->ed_trans_density, &btc);
                    avago_serdes_eye_hbtc_log_print(aapl, AVAGO_INFO, 0, 0, &btc);
                    avago_serdes_eye_hbtc_extrapolate(datap, 1, row_hbtc + datap->ed_y_points/2, datap->ed_trans_density, &btc);
                    avago_serdes_eye_hbtc_log_print(aapl, AVAGO_INFO, 0, 0, &btc);
                }
        }
        if( print_hbtc || print_vbtc )
            avago_serdes_eye_btc_log_print(aapl, AVAGO_INFO, 0, 0, datap);
    }

eye_cleanup_and_exit:
    if( !read_file_name )
        aapl_close_connection(aapl);
    /* Finish up and exit: */
    if( configp ) avago_serdes_eye_config_destruct(aapl, configp);
    if( datap   ) avago_serdes_eye_data_destruct(  aapl, datap);
    avago_addr_delete(aapl, &addr_struct);

    return return_status;
}

#endif /* AAPL_ENABLE_MAIN && AAPL_ENABLE_EYE_MEASUREMENT */

/** @} */
