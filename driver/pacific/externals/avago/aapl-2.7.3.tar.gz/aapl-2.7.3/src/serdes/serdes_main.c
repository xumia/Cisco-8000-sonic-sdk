/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* MAIN program for the serdes sub-command. */
/* */

/** Doxygen File Header */
/** @file */
/** @brief Launch wrappers for SerDes sub-commands. */


#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_MAIN

static Avago_serdes_rx_term_t term_from_str(const char *str, const char *opt)
{
    Avago_serdes_rx_term_t value;
    if( !aapl_str_to_term(str, &value) )
        aapl_main_error("-%s option must be AVDD, AGND or FLOAT; got: \"%s\".",opt,str);
    return value;
}

static Avago_serdes_rx_cmp_data_t cmp_data_from_str(const char *str, const char *opt)
{
    Avago_serdes_rx_cmp_data_t value;
    if( !aapl_str_to_cmp_data(str, &value) )
        aapl_main_error("-%s option must be PRBS{7|9|11|13|15|23|31}|SELF_SEED|OFF; got %s\n",opt,str);
    return value;
}

static Avago_serdes_tx_data_sel_t data_sel_from_str(const char *str, const char *opt)
{
    Avago_serdes_tx_data_sel_t value;
    if( !aapl_str_to_data_sel(str, &value) )
        aapl_main_error("-%s option must be CORE|PRBS{7|9|11|13|15|23|31}|USER|LOOPBACK; got %s\n",opt,str);
    return value;
}

static Avago_serdes_spico_clk_t spico_clk_from_str(const char *str, const char *opt)
{
    Avago_serdes_spico_clk_t value;
    if( !aapl_str_to_spico_clk(str, &value) )
        aapl_main_error("-%s option must be {REFCLK|PCIE_CORE_CLK|TX_F{10|40}}[_DIV2]|TX_F{20|80}; got %s\n",opt,str);
    return value;
}

static Avago_serdes_tx_pll_clk_t tx_pll_clk_from_str(const char *str, const char *opt)
{
    Avago_serdes_tx_pll_clk_t value;
    if( !aapl_str_to_pll_clk(str, &value) )
        aapl_main_error("-%s option must be REFCLK|RX_DIVX|OFF|PCIE_CORE_CLK|PCIE_CORE_CLK_DIV2; got %s\n",opt,str);
    return value;
}

static Avago_serdes_pcs_fifo_clk_t pcs_fifo_clk_from_str(const char *str, const char *opt)
{
    Avago_serdes_pcs_fifo_clk_t value;
    if( !aapl_str_to_pcs_fifo_clk(str, &value) )
        aapl_main_error("-%s option must be F66|F50|F60|F70|F80|F90|F100|F110|F120; got %s\n",opt,str);
    return value;
}

static int show_serdes_help(uint verbose)
{
    (void) verbose;
    aapl_common_main_help(TRUE);
    printf(
"-ip-type <D6|M4|P1>       Filter SerDes type to which to apply the command.\n"
);
    printf(
"-upload                   Upload firmware to SerDes. Use -rev and -build\n"
"                            to specify specific versions.\n"
"-rev <rev>                Firmware revision to upload. Default = %s.\n"
"-build <build>            Firmware build number to upload.\n"
"                            Default <build> varies by SerDes type.\n"
"                            <rev> and <build> are case sensitive.\n"
"-firmware-file <path>     Path of firmware file to upload.\n"
, aapl_default_firmware_rev);
    printf(
"-interrupt <int> <data>   Invoke <int> with <data>.\n"
"-binary                   Return interrupt data also in binary format\n"
"-mem-rd  <ESB|LSB|DMEM|IMEM|LSB_DIRECT|ESB_DIRECT> <addr>[-<addr>]\n"
"                          Read SerDes memory addresses.\n"
"-mem-wr  <ESB|LSB|DMEM|IMEM|LSB_DIRECT|ESB_DIRECT> <addr> <val>[,val]...\n"
"                          Write values to SerDes memory, starting at <addr>.\n"
);
    printf(
"-mem-rmw <ESB|LSB|DMEM|IMEM|LSB_DIRECT|ESB_DIRECT> <addr> <val> <mask>\n"
"                          Write <val> to <addr>, updating only bits in <mask>.\n"
);
    printf(
"-tx-enable <0|1>          Disable/enable the transmitter.\n"
"-tx-user <pattern>        Set the TX USER pattern. Must be 20 binary bits.\n"
"                          May repeat option 4 times.\n"
"-tx-data-sel <CORE|PRBS{7|9|11|13|15|23|31}|USER|LOOPBACK>\n"
"                          Set the TX data source.\n"
);
    printf(
"-encoding      <2|4>      Set the TX and RX serial transmission encoding.\n"
"-tx-encoding   <2|4>      Set the TX serial transmission encoding.\n"
"-rx-encoding   <2|4>      Set the RX serial transmission encoding.\n"
);

    printf(
"-width-mode    <10|16|20|32|40|64|80>  Set the TX and RX width modes.\n"
"-tx-width-mode <10|16|20|32|40|64|80>  Set the TX width mode.\n"
"-rx-width-mode <10|16|20|32|40|64|80>  Set the RX width mode.\n"
);

    printf(
"-tx-invert <0|1>          Disable/enable the TX inverter.\n"
"-tx-output-enable <0|1>   Disable/enable the TX output.\n"
);

    printf(
"-pre <number>             Set TX EQ pre-cursor value.\n"
"-atten <number>           Set TX EQ attenuation value.\n"
"-deep-post <0|1>          Select deep-post mode for CM4 NRZ.\n"
"-post <number>            Set TX EQ post-cursor value.\n"
);
    printf(
"-amp <number>             Set TX EQ amp value.\n"
"-pre-lsb <number>         Set TX EQ pre-cursor lsb value.\n"
"-pre-msb <number>         Set TX EQ pre-cursor msb value.\n"
"-pre2-lsb <number>        Set 2nd TX EQ pre-cursor lsb value.\n"
"-pre2-msb <number>        Set 2nd TX EQ pre-cursor msb value.\n"
);
    printf(
"-t2 <number>              Set TX EQ T2 value\n"
"-atten-lsb <number>       Set TX EQ attenuation lsb value.\n"
"-atten-msb <number>       Set TX EQ attenuation msb value.\n"
"-post-lsb <number>        Set TX EQ post-cursor lsb value.\n"
"-post-msb <number>        Set TX EQ post-cursor msb value.\n"
);
    printf(
"-slew <number>            Set TX EQ slew value.\n"
"-pre2 <number>            Set 2nd TX EQ pre-cursor value.\n"
"-pre3 <number>            Set 3rd TX EQ pre-cursor value.\n"
"-vert <number>            Set TX EQ vert value.\n"
"-tx-eq-limits             Display the TX EQ limits for the SerDes.\n"
"                          Note: These values depend on the SerDes type.\n"
);
    printf(
"-rx-enable <0|1>          Disable/enable the receiver.\n"
"-rx-input-sel <0|1>       Select external signal (0) or internal loopback (1).\n"
"-rx-invert <0|1>          Disable/enable the RX inverter.\n"
"-rx-term <AGND|AVDD|FLOAT>  Set the RX termination.\n"
"-rx-read-live-data        Sample 20 bits from Rx (does not stop comparator).\n"
"-rx-read-data             Sample 80 bits from Rx (stops comparator).\n"
);

    printf(
"-rx-int-gain <number>     Set Rx PLL int gain value(Not for PON SerDes).\n"
"-rx-bb-gain  <number>     Set Rx PLL bb gain value(Not for PON SerDes).\n"
"-rx-kp-gain  <number>     Set Rx kp gain value(only for PON SerDes).\n"
"-rx-ki-gain  <number>     Set Rx ki gain value(only for PON SerDes).\n"
"-get-rx-gain              Get Rx PLL gains.\n"
);

    printf(
"-rx-mode  <PRBS{7|9|11|13|15|23|31}|SELF_SEED>\n"
"                          Sets the compare data, compare mode, and\n"
"                          qualification mode automatically.\n"
);
    printf(
"-cmp-mode <MAIN_PATGEN|TEST_PATGEN|XOR>    Set the received data compare mode.\n"
"-cmp-data <PRBS{7|9|11|13|15|23|31}|SELF_SEED>\n"
"                          Set the compare data for PatGen compare modes.\n"
"-data-qual <val>          Filter/qualify the data that is compared.\n"
"-tx-inject-error <val>    Invert <val> bits in the TX data stream.\n"
"-rx-inject-error <val>    Invert <val> bits in the RX data stream.\n"
);
    printf(
"-error                    Print the error counter's value/\n"
"-error-reset              Resets the error counter and error flag.\n"
"-error-flag-reset         Resets the error flag only.\n"
);
    printf(
"-aux-start                Start the auxiliary PRBS error counter.\n"
"-aux-reset                Alias for -aux-start.\n"
"-aux-error                Read the auxiliary PRBS error counter.\n"
"-aux-disable              Disable the auxiliary PRBS error counter.\n"
);

#if AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG
    printf(
"-ber                      Gives a quick BER measurement.\n"
"                          Use -error-reset to reset error count beforehand, if desired.\n"
"-ber-aux                  Gives a quick BER measurement using the aux error counter.\n"
"                          Use -error-reset to reset the aux error count beforehand, if desired.\n"
"-ber-dwell                Number of seconds over which to compute BER. Default is 1 second.\n"
"-refclk <Hz>              Specify reference clock frequency. Else it is estimated.\n"
);
    printf(
"-start-async-ber          Starts BER measurements and records the starting states in async-filename.\n"
"-read-async-ber           Displays the results of the asynchronous BER measurement.\n"
"                          This may be ran periodically to monitor the channels.\n"
"-async-filename <file>    Sets the name of the asynchronous BER measurement state file.\n"
"                          If omitted, a default name in the current directory will be used.\n"
);
    printf(
"-tune-vernier             Tunes CM4 verniers based on BER\n"
);

if (verbose)
{
    printf(
"-param-sweep              Allow user to sweep a specific parameter.\n"
"-param-mem-addr <addr-to-sweep>.\n"
"-param-min-range <min-range>. Default 0\n"
"-param-max-range <max-range>. Default 0xff.\n"
"-param-step-size <step-size>. Default 0.\n");
    printf(
"-param-pi                 Sweep PI instead of memory address.\n"
"-param-center             When sweep is complete set to center of 0 error window.\n"
"-param-enable-qual        Enable 6 eye data qualification testing.\n"
"-param-no-timer           Use raw error count rather than timer for measurements.\n"
"-param-latch-test         Perform test with and without latches enabled.\n");
    printf(
"-param-latch-mask         Position of latch bit.\n");
}

#endif /* AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG */

#ifdef AAPL_ENABLE_DIAG
    printf(
"-phase-cal-diag <param>   Sweep clocks to measure margin on timing domain transfers."
"                          [2] TX core -> LSB, [1] TX LSB -> ESB, [0] RX ESB -> LSB\n");
#endif /* AAPL_ENABLE_DIAG */

#if AAPL_ENABLE_FLOAT_USAGE
    printf(
"-count-errors <dwell>     Counts errors for <dwell> bits.\n"
);
#endif
    printf(
"-signal-ok <threshold>    Enable signal OK detection. Threshold range [0-15].\n"
"-get-ei-thres             Get Elecrical idle threshold value.\n"
);
    printf(
"-spico-clk {REFCLK|PCIE_CORE_CLK|TX_F{10|40}}[_DIV2]|TX_F{20|80}  Set Spico clock source.\n"
"-pcs-fifo-clk {F66|F50|F60|F70|F80|F90|F100|F110|F120}            Set PCS FIFO clock divider.\n"
"-tx-pll-clk {REFCLK|RX_DIVX|OFF|PCIE_CORE_CLK|PCIE_CORE_CLK_DIV2} Set TX PLL clock source.\n"
);
    printf(
"-pattern-capture <length> Capture a repeating pattern of the given length.\n"
"                          Use a value of 0 to try to autodetect the pattern\n"
"                          length (up to 10,000)\n"
"-pattern-repeat <num>     How many repetitions of the above pattern to capture.\n"
"                          Default = 1.\n"
);
#if AAPL_ENABLE_DIAG && (AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT)
    printf(
"-delay-cal <mode>         Run delay cal. Default mode is 0.\n"
"                          Mode 0 = PI, Mode 1 = delay_vernier. Mode 2 = disable\n"
"                          Mode 3 = PI on main data channel.\n"
"-delay-cal-dwell <dwell_time> Delay call dwell time. Default is 1e9.\n"
);
#endif /* AAPL_ENABLE_DIAG */

    printf(
"-invert     <0|1>         Disable/enable invert in the Tx and Rx datapaths.\n"
"-rx-invert  <0|1>         Disable/enable invert in the Rx datapath.\n"
"-tx-invert  <0|1>         Disable/enable invert in the Tx datapath.\n"
"-gray       <0|1>         Disable/enable Gray coding/decoding in Tx and Rx datapaths.\n"
"-rx-gray    <0|1>         Disable/enable Gray decoding in Rx datapath.\n"
"-tx-gray    <0|1>         Disable/enable Gray encoding in Tx datapath.\n"
);
      printf(
"-precode    <0|1>         Disable/enable precoding/predecoding in Tx and Rx datapaths.\n"
"-tx-precode <0|1>         Disable/enable precoding in Tx datapath.\n"
"-rx-precode <0|1>         Disable/enable predecoding in Rx datapath.\n"
"-swizzle    <0|1>         Disable/enable swizzle encoding in Tx and Rx datapaths.\n"
"-tx-swizzle <0|1>         Disable/enable swizzle encoding in Tx datapath.\n"
"-rx-swizzle <0|1>         Disable/enable swizzle encoding in Rx datapath.\n"
);
      printf(
"-get-burst-mode           Get Burst mode status. Burst mode is only supported in PON SerDes.\n"
"-rate-sel   <number>      Rx rate select. Rx rate selection is only valid for PON SerDes.\n"
"                          0 = Quarter rate, 1 = Full rate, 2 = Eighth rate, 3 = Half rate.\n"
"-get-rate-sel             Get configured rate select value of PON SerDes.\n"
);

   printf(
"-launch-ei-cal    <0|1>   Disable/enable Elecrical idle calibration. Supported for PON and 7nm D6 SerDes.\n"
"-set-ei-cal-thres <value> Set Elecrical idle calibration threshold. Supported for PON and 7nm D6 SerDes.\n"
"-get-ei-cal-thres         Get Elecrical idle calibration threshold. Supported for PON and 7nm D6 SerDes.\n"
"-get-ei-cal-status        Get Elecrical idle calibration status. Supported for PON and 7nm D6 SerDes.\n"
);

#if AAPL_ENABLE_FILE_IO && AAPL_ENABLE_DIAG
   printf(
"-restore <file>           Restore SerDes to state stored in 'aapl diag' output stored in <file>.\n"
);
#endif /* AAPL_ENABLE_FILE_IO && AAPL_ENABLE_DIAG */

    printf(
"-display                  Display the SerDes state.\n"

"-dump                     Call aapl_print_struct() before exiting.\n\n"
"-cont                     Performs command continuosly (until ctrl-c).\n"
);

   printf(
"-enter-low-power          Sets SerDes into low power production mode.\n"
"-exit-low-power           Sets SerDes into normal power development mode.\n"
);

    return 1;
}


static int reverse_bits(int bits, int len)
{
    int i, rev = 0;
    for( i = 0; i < len; i++ )
        if( bits & (1 << i) )
            rev |= 1 << (len-i-1);
    return rev;
}
static void print_tx_eq_values(const char *str, int min, int max, int step)
{
    if( min == max ) return;
    printf(" %s: [%d-%d]", str, min, max);
    if( step > 1 ) printf(" by %d;", step);
    else printf(";");
}

int aapl_serdes_main(int argc, char *argv[], Aapl_t *aapl)
{
    /* Set default values: */
    Avago_addr_t addr_struct;
    int         dump        = 0;
    int         upload      = 0;
    int         deep_post   = -1;

    int rc, index = 0;
    Avago_addr_t start, stop, next; BOOL st;
    Avago_ip_type_t type = (Avago_ip_type_t) 0;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"ip-type",         1, NULL, 't'}, /* Filter by SerDes type */
        {"upload",          0, NULL, 'U'}, /* Upload SBM SPICO firmware file */
        {"dump",            0, NULL, 'D'}, /* Call aapl_print_struct() before exit */
        {"interrupt",       0, NULL, 'i'}, /* Execute interrupt. */
        {"binary",          0, NULL, 'B'}, /* Execute interrupt. */
        {"mem-rd",          0, NULL, 'r'}, /* Read memory. */
        {"mem-wr",          0, NULL, 'w'}, /* Write memory. */
        {"mem-rmw",         0, NULL, 'm'}, /* Read-Modify-Write memory. */

        {"tx-enable",       1, NULL,  1 }, /* Set TX enable state. */
        {"tx-user-data",    1, NULL,  2 }, /* Set TX user data pattern. */
        {"tx-data-sel",     1, NULL,  3 }, /* Set TX data select */
        {"tx-inject-error", 1, NULL,  5 }, /* Inject TX errors */
        {"pre",             1, NULL,  6 }, /* Set TX EQ pre value */
        {"pre-lsb",         1, NULL, 'a'}, /* Set TX EQ pre lsb value */
        {"pre-msb",         1, NULL, 'b'}, /* Set TX EQ pre msb value */
        {"t2",              1, NULL, 'T'}, /* Disable/enable Tx EQ t2 */
        {"atten",           1, NULL,  7 }, /* Set TX EQ attenuation value */
        {"atten-lsb",       1, NULL, 'c'}, /* Set TX EQ attenuation lsb value */
        {"atten-msb",       1, NULL, 'd'}, /* Set TX EQ attenuation msb value */
        {"deep-post",       1, NULL, 29 }, /* Set deep-post mode (affects CM4 NRZ operation) */
        {"post",            1, NULL,  8 }, /* Set TX EQ post value */
        {"post-lsb",        1, NULL, 'e'}, /* Set TX EQ post lsb value */
        {"post-msb",        1, NULL, 'f'}, /* Set TX EQ post msb value */
        {"slew",            1, NULL, 25 }, /* Set TX EQ slew value */
        {"pre2",            1, NULL, 26 }, /* Set TX EQ pre2 value */
        {"pre2-lsb",        1, NULL, 'g'}, /* Set TX EQ pre2 lsb value */
        {"pre2-msb",        1, NULL, 'h'}, /* Set TX EQ pre2 msb value */
        {"pre3",            1, NULL, 27 }, /* Set TX EQ pre3 value */
        {"vert",            1, NULL, 28 }, /* Set TX EQ vert value */
        {"amp",             1, NULL, 'A'}, /* Set TX EQ vert value */
        {"tx-output-enable",1, NULL,  9 }, /* Set TX enable state. */
        {"tx-eq-limits",    0, NULL, 10 }, /* Print tx_eq limits. */

        {"rx-enable",       1, NULL, 11 }, /* Set RX enable state. */
        {"rx-input-sel",    1, NULL, 12 }, /* Set RX loopback internal/external. */
        {"rx-term",         1, NULL, 13 }, /* Set RX termination */
        {"rx-inject-error", 1, NULL, 15 }, /* Inject RX errors. */
        {"rx-mode",         1, NULL,152 }, /* Set RX compare data, mode and qualification */
        {"rx-int-gain",     1, NULL,155 }, /* Set RX PLL int gain */
        {"rx-bb-gain",      1, NULL,156 }, /* Set RX PLL bb gain */
        {"get-rx-gain",     0, NULL,157 }, /* Get RX PLL gains */
        {"rx-kp-gain",      1, NULL,161 }, /* set RX PLL kp gain of PON SerDes */
        {"rx-ki-gain",      1, NULL,162 }, /* set RX PLL ki gain of PON SerDes */
        {"cmp-data",        1, NULL, 16 }, /* Set RX compare data */
        {"cmp-mode",        1, NULL, 17 }, /* Set RX compare mode */
        {"data-qual",       1, NULL, 18 }, /* Set RX data qual filter */
        {"error",           0, NULL, 19 }, /* Get the error counter */
        {"error-reset",     0, NULL, 20 }, /* Reset the error flag and counter */
        {"aux-reset",       0, NULL,220 }, /* Alias for -aux-start */
        {"aux-start",       0, NULL,220 }, /* Enable/restart the auxiliary PRBS error counter */
        {"aux-error",       0, NULL,221 }, /* Read the auxiliary PRBS error counter */
        {"aux-disable",     0, NULL,222 }, /* Stop/disable the auxiliary PRBS error counter */
        {"enter-low-power-mode", 0, NULL,223 }, /* Set SerDes to low power mode */
        {"exit-low-power-mode",  0, NULL,224 }, /* Set SerDes to normal power mode */
        {"error-flag-reset",     0, NULL,145 }, /* Reset the error flag only */
        {"count-errors",         1, NULL,163 }, /* Count errors for number of bits */
#if AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG
        {"refclk",          1, NULL,165 }, /* Give reference clock frequency. */
        {"ber",             0, NULL,166 }, /* Measure quick BER */
        {"ber-aux",         0, NULL,174 }, /* Measure quick BER */
        {"ber-dwell",       1, NULL,167 }, /* Set dwell time for -ber measurement */
        {"tune-vernier",    0, NULL,168 }, /* Run BER based vernier tuning */
        {"start-async-ber", 0, NULL,170 }, /* Start async BER measurement */
        {"read-async-ber",  0, NULL,171 }, /* Read async BER results */
        {"async-filename",  1, NULL,172 }, /* Set async BER state file */

        {"param-sweep",      0, NULL,0x1000 }, /* Sweep a given serdes memory address */
        {"param-mem-addr",   1, NULL,0x1001 },
        {"param-min-range",  1, NULL,0x1002 },
        {"param-max-range",  1, NULL,0x1003 },
        {"param-step-size",  1, NULL,0x1004 },
        {"param-center",     0, NULL,0x1005 },
        {"param-latch-test", 0, NULL,0x1006 },
        {"param-enable-qual",0, NULL,0x1007 },
        {"param-latch-mask", 1, NULL,0x1008 },
        {"param-no-timer",   0, NULL,0x1009 },
        {"param-pi",         0, NULL,0x100a },
#endif
        {"display",         0, NULL, 21 }, /* Display the SerDes state. */
        {"width-mode",      1, NULL, 22 }, /* Set TX and RX width modes. */
        {"tx-width-mode",   1, NULL,215 }, /* Set TX width modes. */
        {"rx-width-mode",   1, NULL,216 }, /* Set RX width modes. */
        {"rx-read-data",    0, NULL, 23 }, /* Sample Rx data */
        {"rx-read-live-data",0,NULL, 24 }, /* Sample Rx data */

        {"spico-clk",       1, NULL,130 }, /* Set spico clock source */
        {"tx-pll-clk",      1, NULL,131 }, /* Set TX PLL clock source */
        {"pcs-fifo-clk",    1, NULL,132 }, /* Set PCS FIFO clock source */
        {"rev",             1, NULL,133 }, /* Load specific firmware revision */
        {"build",           1, NULL,134 }, /* Load specific firmware build */
        {"firmware-file",   1, NULL,135 }, /* Load full firmware file path */
        {"signal-ok",       1, NULL,136 }, /* Enable signal OK with EI threshold */
        {"signal-status",   0, NULL,154 }, /* Get signal_ok, lock, and EI */
        {"encoding",        1, NULL,137 }, /* Encoding mode for Tx and Rx */
        {"tx-encoding",     1, NULL,213 }, /* Encoding mode for Tx */
        {"rx-encoding",     1, NULL,214 }, /* Encoding mode for Rx */
#if AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT
        {"pattern-capture", 1, NULL,138 }, /* Capture data bits from the rx */
        {"pattern-repeat",  1, NULL,139 }, /* How many cycles of the pattern to capture */
#endif
        {"display-ei",      0, NULL,140 }, /* Display electrical idle status */
        {"display-ffl",     0, NULL,141 }, /* Display fine frequency lock status */
        {"display-signal-ok",0,NULL,142 }, /* Display signal OK status */

#if AAPL_ENABLE_DIAG && (AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT)
        {"delay-cal",       1, NULL,143 }, /* Run delay_cal */
        {"delay-cal-dwell", 1, NULL,144 }, /* Adjust delay_cal dwell time */
#endif

        {"invert",          1, NULL, 201}, /* Set the value of Tx and Rx inversion */
        {"rx-invert",       1, NULL, 202}, /* Set the value of Rx inversion */
        {"tx-invert",       1, NULL, 203}, /* Set the value of Tx inversion */
        {"gray",            1, NULL, 204}, /* Set the value of TX and RX Gray encoding */
        {"rx-gray",         1, NULL, 205}, /* Set the value of Rx Gray encoding */
        {"tx-gray",         1, NULL, 206}, /* Set the value of Tx Gray encoding */
        {"precode",         1, NULL, 207}, /* Set the value of Tx and Tx Precode */
        {"rx-precode",      1, NULL, 208}, /* Set the value of RX Precode */
        {"tx-precode",      1, NULL, 209}, /* Set the value of Tx Precode encoding */
        {"swizzle",         1, NULL, 210}, /* Set the value of Tx and Rx swizzle coding */
        {"rx-swizzle",      1, NULL, 211}, /* Set the value of Rx swizzle coding */
        {"tx-swizzle",      1, NULL, 212}, /* Set the value of Tx swizzle coding */

        {"launch-ei-cal",     1, NULL, 180}, /* Launch Elecrical idle calibration */
        {"set-ei-cal-thres",  1, NULL, 181}, /* Set Elecrical idle calibration threshold */
        {"get-ei-cal-thres",  0, NULL, 182}, /* Get Elecrical idle calibration threshold */
        {"get-ei-thres",      0, NULL, 183}, /* Get Elecrical idle threshold */
        {"get-ei-cal-status", 0, NULL, 184}, /* Get Elecrical idle calibration status */
        {"get-burst-mode",    0, NULL, 185}, /* Get Burst mode */
        {"rate-sel",          1, NULL, 186}, /* Set Rx rate selection */
        {"get-rate-sel",      0, NULL, 187}, /* Get configured rate selection valu valuee */
#if AAPL_ENABLE_DIAG
        {"phase-cal-diag",    1, NULL, 189}, /* Run phase cal diagnostics */
#endif /* AAPL_ENABLE_DIAG */
#if AAPL_ENABLE_FILE_IO && AAPL_ENABLE_DIAG
        {"restore",           1, NULL, 188}, /* Restore a serdes from a diag dump */
#endif /* AAPL_ENABLE_FILE_IO && AAPL_ENABLE_DIAG */

        {"cont",            0, NULL, 53}, /* issue command continuously (until ctrl-c) */
        {0,                 0, NULL, 0}
    };

    /* RX Control: */
    BOOL set_rx_term      = FALSE;
    BOOL set_rx_cmp_data  = FALSE;
    BOOL set_rx_mode      = FALSE;
    BOOL set_rx_cmp_mode  = FALSE;
    BOOL set_rx_data_qual = FALSE;
    BOOL rx_read_data     = FALSE;
    BOOL rx_read_live_data= FALSE;
    BOOL display_ei       = FALSE;
    BOOL display_ffl      = FALSE;
    BOOL display_signal_ok= FALSE;
    BOOL get_signal_status= FALSE;
    BOOL cont             = FALSE;
    BOOL enter_low_power_mode = FALSE;
    BOOL exit_low_power_mode = FALSE;

#if AAPL_ENABLE_DIAG && (AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT)
    int  delay_cal        = -1;
    long  delay_cal_dwell = 1e9;
#endif
#if AAPL_ENABLE_DIAG
    uint phase_cal_diag = 0;
#endif

    /* RX Variables: */
    int                   rx_enable = -1;
    int                   rx_loopback = -1;
    int                   rx_inject_err = 0;
    Avago_serdes_rx_term_t      rx_term = AVAGO_SERDES_RX_TERM_AGND;
    Avago_serdes_data_qual_t    rx_data_qual;
    Avago_serdes_rx_cmp_data_t  rx_cmp_data = AVAGO_SERDES_RX_CMP_DATA_PRBS7;
    Avago_serdes_rx_cmp_mode_t  rx_cmp_mode = AVAGO_SERDES_RX_CMP_MODE_XOR;

    /* TX Control: */
    BOOL set_tx_data_sel = FALSE;
    int  set_tx_eq    = 0;
    BOOL set_tx_eq_t2 = 0;

    Avago_serdes_datapath_t rx_datapath, tx_datapath;
    /* TX Variables: */
    int                  tx_enable = -1;
    int                  tx_output_enable = -1;
    int                  tx_inject_err = 0;
    Avago_serdes_tx_data_sel_t tx_data_sel = AVAGO_SERDES_TX_DATA_SEL_PRBS7;
    int                  tx_user_index = 0;
    long                 tx_user[4];
    Avago_serdes_tx_eq_t       tx_eq = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

    /* Other variables: */
    Avago_serdes_spico_clk_t    spico_clk = AVAGO_SERDES_SPICO_REFCLK;
    Avago_serdes_tx_pll_clk_t   tx_pll_clk = AVAGO_SERDES_TX_PLL_REFCLK;
    Avago_serdes_pcs_fifo_clk_t pcs_fifo_clk = AVAGO_SERDES_PCS_FIFO_F66;
    int tx_data_width = 0;
    int rx_data_width = 0;

    /* Other Control: */
    BOOL ei_cal = FALSE;
    BOOL launch_cal = FALSE;
    BOOL get_ei_cal_thres = FALSE;
    BOOL set_ei_cal_thres = FALSE;
    int set_ei_cal_threshold = 0;
    BOOL get_ei_thres = FALSE;
    BOOL get_ei_cal_status = FALSE;
    BOOL get_burst_mode = FALSE;
    BOOL rate_select = FALSE;
    BOOL get_rate_select = FALSE;
    uint rate_sel = 0;
    int call_tx_eq_limits = 0;
    int display_serdes_state = 0;
    int call_interrupt = 0;
    int read_mem = 0;
    int write_mem = 0;
    int rmw_mem = 0;
    uint bit_field_shift = 0;
    uint bit_field_bits = 0;
    BOOL binary = FALSE;
    const char *mem_name = 0;
    BOOL set_spico_clk = FALSE;
    BOOL set_tx_pll_clk = FALSE;
    BOOL set_pcs_fifo_clk = FALSE;
    BOOL get_error_counter = FALSE;
    BOOL aux_read = FALSE, aux_start = FALSE, aux_disable = FALSE;
    BOOL get_ber = FALSE;
#if AAPL_ENABLE_FLOAT_USAGE
    bigint count_errors = 0;
#endif
#if AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG
# if AAPL_ENABLE_FILE_IO
    char *async_filename = 0;
    BOOL start_async_ber = FALSE;
    BOOL read_async_ber = FALSE;
# endif
    BOOL get_ber_aux = FALSE;
    char *temp = getenv("SERDES_REFCLK");
    uint refclk = temp && *temp ? aapl_nume_from_str(temp, "env") : 0; /* If no env var, default to estimate rate */
    int ber_dwell = 1;
    BOOL tune_vernier = FALSE;
    BOOL run_param_sweep = FALSE;
    Avago_serdes_param_sweep_t param_sweep;
#endif /* AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG */
    BOOL clear_error_counter = FALSE;
    BOOL clear_error_flag = FALSE;
    BOOL have_user_option = FALSE;
    int  ei_threshold = -1;
    int tx_encoding = 0;
    int rx_encoding = 0;
    uint set_int_gain = 0, get_int_gain = 0;
    uint set_bb_gain = 0, get_bb_gain = 0;
    BOOL get_rx_pll_gain = FALSE;
    uint set_kp_gain = 0, set_ki_gain = 0;
    uint get_kp_gain = 0, get_ki_gain = 0;
    BOOL set_kp_ki_gain = FALSE;
#if AAPL_ENABLE_FILE_IO && AAPL_ENABLE_DIAG
    char *restore_file_ptr = 0;
#endif /* AAPL_ENABLE_FILE_IO && AAPL_ENABLE_DIAG */
#if AAPL_ENABLE_FILE_IO
    char firmware_file[512];
    const char *fw_build = 0;
    const char *firmware_file_ptr = 0;
#endif /* AAPL_ENABLE_FILE_IO */
#if AAPL_ENABLE_ESCOPE_MEASUREMENT || AAPL_ENABLE_PHASE_CALIBRATION
    int pattern_capture = -1;
    int pattern_repeat = 1;
#endif

#if AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG
    memset(&param_sweep, 0, sizeof(param_sweep));
    param_sweep.max_range = 0xff; /* command line default */
    param_sweep.latch_mask = 0x200; /* default for 16nm CM4 */
#endif
    memset(&tx_datapath, 0, sizeof(tx_datapath));
    memset(&rx_datapath, 0, sizeof(rx_datapath));
    avago_addr_to_struct(aapl_default_device_addr, &addr_struct);
    if (aapl_common_main_options(aapl, argc, argv, &addr_struct) < 0)
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_serdes_help(aapl->verbose);
    }
    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        have_user_option = TRUE;
        switch( rc )
        {
        case 'D': dump = 1; break;
        case 'i': call_interrupt = 1; break;
        case 'B': binary = TRUE; break;
        case 'r': read_mem  = 1; mem_name = name; break;
        case 'w': write_mem = 1; mem_name = name; break;
        case 'm': rmw_mem   = 1; mem_name = name; break;
        case 't': if( aapl_strcasecmp(optarg,"M4") ) type = AVAGO_M4;
             else if( aapl_strcasecmp(optarg,"P1") ) type = AVAGO_P1;
             else if( aapl_strcasecmp(optarg,"D6") ) type = AVAGO_SERDES;
             else fprintf(stderr,"Unrecognized type specifier: '%s'\n",optarg);
             break;

        case 1: tx_enable = aapl_bool_from_str(optarg,name); break;
        case 2: if( tx_user_index < 4 )
                {
                    int radix = (strspn(optarg,"01") == strlen(optarg)) ? 2 : 0;
                    tx_user[tx_user_index++] = reverse_bits(aapl_num_from_str(optarg,name,radix),20);
                }
                break;
        case 3: tx_data_sel = data_sel_from_str(optarg,name); set_tx_data_sel=TRUE; break;
        case 5: tx_inject_err    = aapl_num_from_str(optarg,name,0); break;
        case 6  : tx_eq.pre      = aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x1; break;
        case 'a': tx_eq.pre_lsb  = aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x2; break;
        case 'b': tx_eq.pre_msb  = aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x4; break;
        case 7  : tx_eq.atten    = aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x8; break;
        case 'c': tx_eq.atten_lsb= aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x10; break;
        case 'd': tx_eq.atten_msb= aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x20; break;
        case 8  : tx_eq.post     = aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x40; break;
        case 'e': tx_eq.post_lsb = aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x80; break;
        case 'f': tx_eq.post_msb = aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x100; break;
        case 25 : tx_eq.slew     = aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x200; break;
        case 26 : tx_eq.pre2     = aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x400; break;
        case 'g': tx_eq.pre2_lsb = aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x800; break;
        case 'h': tx_eq.pre2_msb = aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x1000; break;
        case 29 : deep_post      = aapl_bool_from_str(optarg,name); break;
        case 28 : tx_eq.vert     = aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x2000; break;
        case 27 : tx_eq.pre3     = aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x4000; break;
        case 'A': tx_eq.amp      = aapl_num_from_str(optarg,name,10); set_tx_eq |= 0x8000; break;
        case 'T': tx_eq.t2       = aapl_num_from_str(optarg,name,10); set_tx_eq_t2 = 1; break;
        case 9 : tx_output_enable = aapl_bool_from_str(optarg,name); break;
        case 10: call_tx_eq_limits = 1; break;

        case  11: rx_enable = aapl_bool_from_str(optarg,name); break;
        case  12: rx_loopback = aapl_bool_from_str(optarg,name); break;
        case  13: rx_term = term_from_str(optarg,name); set_rx_term=TRUE; break;
        case  15: rx_inject_err = aapl_num_from_str(optarg,name,0); break;
        case  16: rx_cmp_data = cmp_data_from_str(optarg,name); set_rx_cmp_data = TRUE; break;
        case 152: rx_cmp_data = cmp_data_from_str(optarg,name); set_rx_mode = TRUE; break;
        case  17: rx_cmp_mode = aapl_cmp_mode_from_str(optarg,name); set_rx_cmp_mode = TRUE; break;
        case  18: rx_data_qual = aapl_data_qual_from_str(optarg,name); set_rx_data_qual=TRUE; break;
        case  19: get_error_counter = TRUE; break;
        case  20: clear_error_counter = TRUE; break;
        case 220: aux_start = TRUE; break;
        case 221: aux_read = TRUE; break;
        case 222: aux_disable = TRUE; break;
        case 223: enter_low_power_mode = TRUE; break;
        case 224: exit_low_power_mode = TRUE; break;
        case 145: clear_error_flag = TRUE; break;
#if AAPL_ENABLE_DIAG
        case 189: phase_cal_diag = aapl_num_from_str(optarg,name,10); break;
#endif
#if AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG
        case 165: refclk = aapl_nume_from_str(optarg,name); break;
        case 166: get_ber = TRUE; break;
        case 174: get_ber = TRUE; get_ber_aux = TRUE; break;
        case 167: ber_dwell = aapl_num_from_str(optarg,name,0); break;
        case 168: tune_vernier = 1; break;

# if AAPL_ENABLE_FILE_IO
        case 170: start_async_ber = TRUE; break;
        case 171: read_async_ber = TRUE; break;
        case 172: async_filename = optarg; break;
# endif
        case 0x1000: run_param_sweep = TRUE; break;
        case 0x1001: param_sweep.mem_addr = aapl_num_from_str(optarg,name,0); break;
        case 0x1002: param_sweep.min_range = aapl_num_from_str(optarg,name,0); break;
        case 0x1003: param_sweep.max_range = aapl_num_from_str(optarg,name,0); break;
        case 0x1004: param_sweep.step_size = aapl_num_from_str(optarg,name,0); break;
        case 0x1005: param_sweep.center = TRUE; break;
        case 0x1006: param_sweep.latch_test = TRUE; break;
        case 0x1007: param_sweep.enable_qual = TRUE; break;
        case 0x1008: param_sweep.latch_mask = aapl_num_from_str(optarg,name,0); break;
        case 0x1009: param_sweep.no_timer = TRUE; break;
        case 0x100a: param_sweep.pi = TRUE; break;
#endif /* AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG */
        case  21: display_serdes_state = 1; break;
        case  22: tx_data_width = rx_data_width = aapl_num_from_str(optarg,name,10); break;
        case 215: tx_data_width = aapl_num_from_str(optarg,name,10); break;
        case 216: rx_data_width = aapl_num_from_str(optarg,name,10); break;
        case  23: rx_read_data = TRUE; break;
        case  24: rx_read_live_data = TRUE; break;

        case 130: spico_clk    = spico_clk_from_str(optarg,name);    set_spico_clk    = TRUE; break;
        case 131: tx_pll_clk   = tx_pll_clk_from_str(optarg,name);   set_tx_pll_clk   = TRUE; break;
        case 132: pcs_fifo_clk = pcs_fifo_clk_from_str(optarg,name); set_pcs_fifo_clk = TRUE; break;

        case 'U': upload = 1; break;
        case 133: aapl_default_firmware_rev   = optarg; break;
#if AAPL_ENABLE_FILE_IO
        case 134: fw_build = optarg; break;
        case 135: upload = 1; firmware_file_ptr = optarg; break;
#endif /* AAPL_ENABLE_FILE_IO */
#if AAPL_ENABLE_FILE_IO && AAPL_ENABLE_DIAG
        case 188: restore_file_ptr = optarg; break;
#endif /* AAPL_ENABLE_FILE_IO && AAPL_ENABLE_DIAG */
        case 136: ei_threshold = aapl_num_from_str(optarg,name,10); break;
        case 137: tx_encoding = rx_encoding = aapl_num_from_str(optarg,name,10); break;
        case 213: tx_encoding = aapl_num_from_str(optarg,name,10); break;
        case 214: rx_encoding = aapl_num_from_str(optarg,name,10); break;
#if AAPL_ENABLE_ESCOPE_MEASUREMENT || AAPL_ENABLE_PHASE_CALIBRATION
        case 138: pattern_capture = aapl_num_from_str(optarg,name,10); break;
        case 139: pattern_repeat = aapl_num_from_str(optarg,name,10); break;
#endif
        case 140: display_ei = TRUE; break;
        case 141: display_ffl = TRUE; break;
        case 142: display_signal_ok = TRUE; break;

#if AAPL_ENABLE_DIAG && (AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT)
        case 143: delay_cal = aapl_num_from_str(optarg,name,16); break;
        case 144: delay_cal_dwell = aapl_num_from_str(optarg,name,10); break;
#endif

        case 201: rx_datapath.polarity_invert=
                  tx_datapath.polarity_invert= aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x01; rx_datapath.mask |= 0x01; break;
        case 202: rx_datapath.polarity_invert= aapl_bool_from_str(optarg,name); rx_datapath.mask |= 0x01; break;
        case 203: tx_datapath.polarity_invert= aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x01; break;
        case 204: rx_datapath.gray_enable    =
                  tx_datapath.gray_enable    = aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x02; rx_datapath.mask |= 0x02; break;
        case 205: rx_datapath.gray_enable    = aapl_bool_from_str(optarg,name); rx_datapath.mask |= 0x02; break;
        case 206: tx_datapath.gray_enable    = aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x02; break;
        case 207: rx_datapath.precode_enable =
                  tx_datapath.precode_enable = aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x04; rx_datapath.mask |= 0x04; break;
        case 208: rx_datapath.precode_enable = aapl_bool_from_str(optarg,name); rx_datapath.mask |= 0x04; break;
        case 209: tx_datapath.precode_enable = aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x04; break;
        case 210: rx_datapath.swizzle_enable =
                  tx_datapath.swizzle_enable = aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x08; rx_datapath.mask |= 0x08; break;
        case 211: rx_datapath.swizzle_enable = aapl_bool_from_str(optarg,name); rx_datapath.mask |= 0x08; break;
        case 212: tx_datapath.swizzle_enable = aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x08; break;

        case  53: cont = TRUE; break;
        case 154: get_signal_status = TRUE; break;
        case 155: set_int_gain = aapl_num_from_str(optarg,name,10); break;
        case 156: set_bb_gain  = aapl_num_from_str(optarg,name,10); break;
        case 157: get_rx_pll_gain  = TRUE; break;

        case 161: set_kp_gain = aapl_num_from_str(optarg,name,10); set_kp_ki_gain = TRUE; break;
        case 162: set_ki_gain = aapl_num_from_str(optarg,name,10); set_kp_ki_gain = TRUE; break;
#if AAPL_ENABLE_FLOAT_USAGE
        case 163: count_errors = aapl_nume_from_str(optarg, name); break;
#endif
        case 180: ei_cal = aapl_bool_from_str(optarg,name);  launch_cal = TRUE; break;
        case 181: set_ei_cal_thres = TRUE; set_ei_cal_threshold = aapl_num_from_str(optarg,name,0); break;
        case 182: get_ei_cal_thres = TRUE; break;
        case 183: get_ei_thres = TRUE; break;
        case 184: get_ei_cal_status = TRUE; break;
        case 185: get_burst_mode = TRUE; break;
        case 186: rate_sel = aapl_num_from_str(optarg,name,10); rate_select = TRUE; break;
        case 187: get_rate_select = TRUE; break;

        case '?':
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }
    rc = 2;

    if( !have_user_option )
    {
        show_serdes_help(aapl->verbose);
        goto cleanup_and_exit;
    }
#if AAPL_ENABLE_ESCOPE_MEASUREMENT || AAPL_ENABLE_PHASE_CALIBRATION
    if (pattern_repeat <= 0)
    {
        aapl_fail(aapl, 0, 0, "Pattern_repeat must be >= 1.");
        goto cleanup_and_exit;
    }
#endif

    if( rmw_mem && (argc-optind) != 4 )
    {
        aapl_fail(aapl, 0, 0, "The -mem-rmw command requires four parameters:\n"
                              "    -mem-rmw <type> <addr> <value> <mask>\n");
        goto cleanup_and_exit;
    }
    if( write_mem && (argc-optind) != 3 )
    {
        aapl_fail(aapl, 0, 0, "The -mem-wr command requires three parameters:\n"
                              "    -mem-wr <type> <addr> <value>\n");
        goto cleanup_and_exit;
    }
    if( (call_interrupt && (argc-optind) != 2 ) )
    {
        aapl_fail(aapl, 0, 0, "The -interrupt command require two parameters:\n"
                              "    -interrupt <int_num> <int_data>\n");
        goto cleanup_and_exit;
    }
    if ((read_mem && ((argc-optind) != 2 && (argc-optind) !=3)))
    {
        aapl_fail(aapl, 0, 0, "The -mem-rd command require two or three parameters:\n"
                              "    -mem-rd <type> <addr> [[bit] | [high:low]]\n");
        goto cleanup_and_exit;
    }
    rc = 0;

    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
    aapl_get_ip_info(aapl,0);

    if( upload && avago_struct_to_addr(&addr_struct) == aapl_default_device_addr ) /* in case no address is provided by user */
    {
        /* Construct an address list for all SerDes: */
        aapl_addr_list_from_str(aapl, &addr_struct, "*:*:ff,*:*:ee,*:*:ed");
    }

    /* If given a single, invalid address that isn't a useful type, complain: */
    if( addr_struct.next == 0
        && !aapl_check_ip_type(aapl, avago_struct_to_addr(&addr_struct), __func__, __LINE__, TRUE, 7,
                                AVAGO_SPICO,    /* For -interrupt support only */
                                AVAGO_SERDES, AVAGO_SERDES_D6_BROADCAST,
                                AVAGO_M4,     AVAGO_SERDES_M4_BROADCAST,
                                AVAGO_P1,     AVAGO_SERDES_P1_BROADCAST) )
        goto cleanup_and_exit; /* prevents invalid addresses from silently doing nothing */

    avago_group_expand_broadcast(aapl, &addr_struct);

#if AAPL_ENABLE_FILE_IO
    if( upload ) avago_serdes_upload_firmware(aapl, &addr_struct, fw_build, firmware_file_ptr, firmware_file, sizeof(firmware_file));
    if( upload ) goto cleanup_and_exit;
#endif /* AAPL_ENABLE_FILE_IO */

    do
    {
    aapl_sigint_check(aapl);

    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, AAPL_BROADCAST_NO_ITER_LANE);
         st;
         st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_NO_ITER_LANE) )
    {
        uint addr = avago_struct_to_addr(&next);
        Avago_ip_type_t ip_type = aapl_get_ip_type(aapl, addr);
        if( type && type != ip_type ) continue;  /* check for ip type filter */

        /* don't call (most) lower level functions unless they are serdes */
        if( !aapl_check_ip_type(aapl, addr, __func__,__LINE__,FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) )
            if( aapl_get_ip_type(aapl, addr) != AVAGO_SPICO || !call_interrupt)
                continue;

#if AAPL_ENABLE_FILE_IO && AAPL_ENABLE_DIAG
        if ( restore_file_ptr ) avago_serdes_restore(aapl, addr, restore_file_ptr);
#endif /* AAPL_ENABLE_FILE_IO && AAPL_ENABLE_DIAG */

        if( call_interrupt )
        {
            char *ptr0, *ptr1;
            int ret;
            int int_num  = aapl_strtol(argv[optind  ],&ptr0,0);
            int int_data = aapl_strtol(argv[optind+1],&ptr1,0);
            if( *ptr0 != '\0' && *ptr0 != 0xd)
                aapl_fail(aapl, 0, 0, "Extra characters in -interrupt parameter 1: %s\n",argv[optind]);
            if( *ptr1 != '\0' && *ptr1 != 0xd)
                aapl_fail(aapl, 0, 0, "Extra characters in -interrupt parameter 2: %s\n",argv[optind+1]);
            ret = avago_spico_int(aapl, addr, int_num, int_data);
            aapl_hex_2_bin(aapl->data_char, ret, 1, 16);
            printf("Interrupt 0x%04x (%d), 0x%04x (%d) executed on SBus address %s -> 0x%x (%d) %s\n",
                    int_num, int_num, int_data, int_data, aapl_addr_to_str(addr), ret, ret, binary ? aapl->data_char : "");
            continue;
        }

        if( tx_data_width || rx_data_width || tx_encoding || rx_encoding )
        {
            Avago_serdes_line_encoding_t tx_line_encoding, rx_line_encoding;
            int tx;
            int rx;
            tx_line_encoding = rx_line_encoding = AVAGO_SERDES_NRZ;
            avago_serdes_get_tx_rx_width(aapl, addr, &tx, &rx);
            if( tx_data_width ) tx = tx_data_width;
            if( rx_data_width ) rx = rx_data_width;

            if( avago_serdes_get_tx_line_encoding(aapl, addr) ) tx_line_encoding = AVAGO_SERDES_PAM4;
            if( avago_serdes_get_rx_line_encoding(aapl, addr) ) rx_line_encoding = AVAGO_SERDES_PAM4;

            if( tx_encoding )
            {
                if( (tx_encoding <= 2) || (tx < 20) )
                    tx_line_encoding = AVAGO_SERDES_NRZ;
                else
                    tx_line_encoding = AVAGO_SERDES_PAM4;
            }

            if( rx_encoding )
            {
                if( (rx_encoding <= 2) || (rx < 20) )
                    rx_line_encoding = AVAGO_SERDES_NRZ;
                else
                    rx_line_encoding = AVAGO_SERDES_PAM4;
            }

            avago_serdes_set_tx_rx_width_pam(aapl, addr, tx, rx, tx_line_encoding, rx_line_encoding);
        }
    }

    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, 0);
         st && !call_interrupt;
         st = aapl_broadcast_next(aapl, &next, &start, &stop, 0) )
    {
        uint addr = avago_struct_to_addr(&next);
        Avago_ip_type_t ip_type = aapl_get_ip_type(aapl, addr);
        if( type && type != ip_type ) continue;  /* check for ip type filter */

        /* don't call (most) lower level functions unless they are serdes */
        if( !aapl_check_ip_type(aapl, addr, __func__,__LINE__,FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) )
            continue;

        if( exit_low_power_mode  ) avago_serdes_enable_low_power_mode(aapl, addr, FALSE);

        /* Process memory operations: */
        if( read_mem || write_mem || rmw_mem )
        {
            Avago_serdes_mem_type_t type = aapl_mem_type_from_str(argv[optind], mem_name);
            int start = 0, stop = 0, mem_addr;

            if (*argv[optind+1] > '9')
            {
                aapl_str_to_mem_addr(aapl, addr, argv[optind+1], &start, &bit_field_bits, &bit_field_shift);
                stop = start;
                if (start < 0) aapl_fail(aapl, 0, 0, "Could not find address for: %s\n",argv[optind+1]);
            }
            else if( !aapl_parse_range(argv[optind+1],&start,&stop) || (!read_mem && start != stop) )
                aapl_fail(aapl, 0, 0, "Invalid address or address range in parameter 2: %s\n",argv[optind+1]);

            if( rmw_mem )
            {
                int mask = 0;
                int prev = 0;
                int value = aapl_num_from_str(argv[optind+2],"<value>",0);
                if (argv[optind+3][0] == '[') /* user supplied a bit field (ie [7:4]) instead of a mask (ie 0xf0) */
                {
                    aapl_bit_field_from_str(argv[optind+3], "<bits>", &bit_field_bits, &bit_field_shift, 0);
                    mask = (int) (pow(2, bit_field_bits) - 1) << bit_field_shift;
                    value <<= bit_field_shift;
                }
                else mask = aapl_num_from_str(argv[optind+3],"<mask>",0);
                prev = avago_serdes_mem_rmw(aapl, addr, type, start, value, mask);
                printf("avago_serdes_mem_rmw(aapl, %s, %s, 0x%x, 0x%x, 0x%x) = 0x%04x\n",
                        aapl_addr_to_str(addr), argv[optind], start, value, mask, prev);
            }
            if( write_mem )
            {
                const char *separators = ", ;";
                char *data = argv[optind+2];
                /* Validate the values to write: */
                while( *data )
                {
                    char *ptr;
                    aapl_strtol(data,&ptr,0);
                    if( data == ptr )
                    {
                        aapl_fail(aapl, __func__, __LINE__, "Invalid value: %s\n", ptr);
                        goto cleanup_and_exit;
                    }
                    data = ptr + strspn(ptr, separators);
                }
                /* Now do the action: */
                data = argv[optind+2];
                while( *data )
                {
                    int value = aapl_strtol(data,&data,0);
                    data += strspn(data, separators);
                    avago_serdes_mem_wr(aapl, addr, type, stop, value);
                    printf("avago_serdes_mem_wr (aapl, %s, %s, 0x%x, 0x%x)\n",
                        aapl_addr_to_str(addr), argv[optind], stop, value);
                    stop++;
                }
                stop--;
            }
            /* check for bit field present for memory reads (bit field for rmw is handled above). Bit field for mem-write is not supported (as you have to do a rmw for that to make sense) */
            if( !(rmw_mem || write_mem) && ((argc-optind) == 3) ) aapl_bit_field_from_str(argv[optind+2], "<bits>", &bit_field_bits, &bit_field_shift, 0);

            for( mem_addr = start; mem_addr <= stop; mem_addr++ )
            {
                char str[128];
                int ret = avago_serdes_mem_rd(aapl, addr, type, mem_addr);
                aapl_mem_addr_to_str(aapl, addr, mem_addr, str);
                printf("avago_serdes_mem_rd (aapl, %s, %s, 0x%x) \"%-20.20s\" = 0x%04x (%5d)",
                    aapl_addr_to_str(addr), argv[optind], mem_addr, str, ret, ret);

                if (bit_field_bits) /* did the user ask for a bitfield? */
                {
                    char *ptr = str;
                    aapl_mem_addr_bitfield_to_str(aapl, addr, mem_addr, bit_field_bits, bit_field_shift, str);
                    if (strlen(str) > 20) ptr += strlen(str) - 20; /* if there are too many characters truncate the beginning of the string */
                    printf("   \"%-20.20s\"  [%d:%u]: 0x%04x (%5d)", ptr, bit_field_shift + bit_field_bits - 1, bit_field_shift,
                        (ret >> bit_field_shift) & (int) (pow(2, bit_field_bits) - 1),
                        (ret >> bit_field_shift) & (int) (pow(2, bit_field_bits) - 1));
                }
                printf("\n");
            }
            printf("\n");
            continue;
        }

        /* No args are allowed beyond options for the following: */
        if( optind < argc )
            aapl_exit_on_unexpected_arg(argv[optind]);

        if( ei_threshold >= 0 )
            avago_serdes_initialize_signal_ok(aapl, addr, ei_threshold);

/* Setup the TX: */
/* */
        /* Logic to skip setting user pattern if none given, */
        /*  and to expand user pattern if 20 or 40 bits given. */
        switch( tx_user_index )
        {
        case 0: break;
        case 1: tx_user[1] = tx_user[0];    /* fall through */
        case 2: tx_user[2] = tx_user[0];    /* fall through */
        case 3: tx_user[3] = tx_user[1];    /* fall through */
        default: avago_serdes_set_tx_user_data(aapl, addr, tx_user); break;
        }
        if( set_tx_data_sel ) avago_serdes_set_tx_data_sel(aapl, addr, tx_data_sel);
        if( deep_post >= 0 )
            avago_serdes_tx_eq_deep_post_enable(aapl, addr, deep_post);
        if( set_tx_eq || set_tx_eq_t2)
        {
            Avago_serdes_tx_eq_t new_tx_eq;
            memset(&new_tx_eq, 0 , sizeof(new_tx_eq));

            if( set_tx_eq != 0xffff )    /* If not all values given, read current values */
                avago_serdes_get_tx_eq(aapl, addr, &new_tx_eq);
            if( set_tx_eq & 0x1    )
            {
                new_tx_eq.pre       = tx_eq.pre;
                new_tx_eq.pre_lsb   = tx_eq.pre;
                new_tx_eq.pre_msb   = tx_eq.pre;
            }
            if( set_tx_eq & 0x2    ) new_tx_eq.pre_lsb   = tx_eq.pre_lsb;
            if( set_tx_eq & 0x4    ) new_tx_eq.pre_msb   = tx_eq.pre_msb;
            if( set_tx_eq & 0x8    )
            {
                new_tx_eq.atten       = tx_eq.atten;
                new_tx_eq.atten_lsb   = tx_eq.atten;
                new_tx_eq.atten_msb   = tx_eq.atten;
            }
            if( set_tx_eq & 0x10   ) new_tx_eq.atten_lsb = tx_eq.atten_lsb;
            if( set_tx_eq & 0x20   ) new_tx_eq.atten_msb = tx_eq.atten_msb;
            if( set_tx_eq & 0x40   )
            {
                new_tx_eq.post       = tx_eq.post;
                new_tx_eq.post_lsb   = tx_eq.post;
                new_tx_eq.post_msb   = tx_eq.post;
            }
            if( set_tx_eq & 0x80   ) new_tx_eq.post_lsb  = tx_eq.post_lsb;
            if( set_tx_eq & 0x100  ) new_tx_eq.post_msb  = tx_eq.post_msb;
            if( set_tx_eq & 0x200  ) new_tx_eq.slew      = tx_eq.slew;
            if( set_tx_eq & 0x400  )
            {
                new_tx_eq.pre2       = tx_eq.pre2;
                new_tx_eq.pre2_lsb   = tx_eq.pre2;
                new_tx_eq.pre2_msb   = tx_eq.pre2;
            }
            if( set_tx_eq & 0x800  ) new_tx_eq.pre2_lsb  = tx_eq.pre2_lsb;
            if( set_tx_eq & 0x1000 ) new_tx_eq.pre2_msb  = tx_eq.pre2_msb;
            if( set_tx_eq & 0x2000 ) new_tx_eq.vert      = tx_eq.vert;
            if( set_tx_eq & 0x4000 ) new_tx_eq.pre3      = tx_eq.pre3;
            if( set_tx_eq & 0x8000 ) new_tx_eq.amp       = tx_eq.amp;
            if( set_tx_eq_t2       ) new_tx_eq.t2        = tx_eq.t2;

            avago_serdes_set_tx_eq(aapl, addr, &new_tx_eq);
        }
        /* Set the device enable state: */
        if( rx_enable != -1 || tx_enable != -1 )
        {
            if( rx_enable == -1 || tx_enable == -1 )
            {
                BOOL tx, rx;
                avago_serdes_get_tx_rx_ready(aapl, addr, &tx, &rx);
                if( tx_enable == -1 ) tx_enable = tx;
                if( rx_enable == -1 ) rx_enable = rx;
            }
            if( tx_output_enable == -1 )
                tx_output_enable = avago_serdes_get_tx_output_enable(aapl, addr);
            avago_serdes_set_tx_rx_enable(aapl, addr, tx_enable, rx_enable, tx_output_enable);
        }
        else if( tx_output_enable != -1 )
            avago_serdes_set_tx_output_enable(aapl, addr, tx_output_enable);

        if( tx_datapath.mask )
            avago_serdes_set_tx_datapath(aapl, addr, &tx_datapath);
        if( rx_datapath.mask )
            avago_serdes_set_rx_datapath(aapl, addr, &rx_datapath);

/* Setup the RX: */
/* */
        if( set_rx_term      ) avago_serdes_set_rx_term(     aapl, addr, rx_term);
        if( rx_loopback >= 0 )
        {
                avago_serdes_set_rx_input_loopback(aapl, addr, rx_loopback);
        }
        if( set_rx_mode )
        {
            if (rx_cmp_data == AVAGO_SERDES_RX_CMP_DATA_OFF)
            {
                avago_serdes_set_rx_cmp_mode( aapl, addr, AVAGO_SERDES_RX_CMP_MODE_OFF);
                avago_serdes_dfe_resume(aapl, addr, 0);
            }
            else
            {
                Avago_serdes_data_qual_t qual;
                avago_serdes_dfe_pause(aapl, addr, NULL);
                avago_serdes_data_qual_init(&qual);
                qual.d6_data_qual = AVAGO_SERDES_RX_DATA_QUAL_UNQUAL;
                avago_serdes_set_data_qual  ( aapl, addr, qual);
                avago_serdes_set_rx_cmp_mode( aapl, addr, AVAGO_SERDES_RX_CMP_MODE_MAIN_PATGEN);
                avago_serdes_set_rx_cmp_data( aapl, addr, rx_cmp_data);
                avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, 0xd, 0x8, 0x8); /* set force_active bit to ensure error counter is enabled */
                avago_serdes_mem_wr(aapl, addr, AVAGO_LSB, 0x13, 0x0); /* make sure error timer is not running */
                avago_serdes_error_reset(aapl, addr);
            }
        }
        if( set_rx_cmp_data   ) avago_serdes_set_rx_cmp_data( aapl, addr, rx_cmp_data );
        if( set_rx_cmp_mode   ) avago_serdes_set_rx_cmp_mode( aapl, addr, rx_cmp_mode );
        if( set_rx_data_qual  ) avago_serdes_set_data_qual  ( aapl, addr, rx_data_qual);


        if( set_int_gain || set_bb_gain )
        {
            avago_serdes_get_rx_pll_gain(aapl, addr, &get_bb_gain, &get_int_gain);
            if( !set_bb_gain  ) set_bb_gain  = get_bb_gain;
            if( !set_int_gain ) set_int_gain = get_int_gain;
            avago_serdes_set_rx_pll_gain(aapl, addr, set_bb_gain, set_int_gain);
        }

        if( get_rx_pll_gain )
        {
            if( aapl_get_sdrev(aapl, addr) == AAPL_SDREV_PON )
            {
                avago_serdes_get_rx_pll_gain(aapl, addr, &get_kp_gain, &get_ki_gain);
                printf("SBus %s, kp_gain: %u, ki_gain: %u.\n", aapl_addr_to_str(addr), get_kp_gain, get_ki_gain);
            }
            else
            {
                avago_serdes_get_rx_pll_gain(aapl, addr, &get_bb_gain, &get_int_gain);
                printf("SBus %s, int_gain: %u, bb_gain: %u.\n", aapl_addr_to_str(addr), get_int_gain, get_bb_gain);
            }
        }

        if( set_kp_ki_gain )
        {
            if( aapl_get_sdrev(aapl, addr) == AAPL_SDREV_PON )
            {
                avago_serdes_get_rx_pll_gain(aapl, addr, &get_kp_gain, &get_ki_gain);
                if( !set_kp_gain ) set_kp_gain = get_kp_gain;
                if( !set_ki_gain ) set_ki_gain = get_ki_gain;
                avago_serdes_set_rx_pll_gain(aapl, addr, set_kp_gain, set_ki_gain);
            }
            else
                aapl_fail(aapl, __func__, __LINE__, "SBus %s, Kp/Ki gains are only valid for PON SerDes.\n", aapl_addr_to_str(addr));
        }

        if( launch_cal )
            avago_serdes_launch_ei_calibration(aapl, addr, ei_cal);

        if( set_ei_cal_thres )
            avago_serdes_set_ei_calibration_threshold(aapl, addr, set_ei_cal_threshold);

        if( get_ei_cal_thres )
            printf("SBus %s, Elecrical idle calibration threshold: %d.\n", aapl_addr_to_str(addr),
                             avago_serdes_get_ei_calibration_threshold(aapl, addr));

        if( get_ei_thres )
            printf("SBus %s, Elecrical idle threshold: %d.\n", aapl_addr_to_str(addr),
                             avago_serdes_get_signal_ok_threshold(aapl, addr));

        if( get_ei_cal_status )
            printf("SBus %s, Electrical idle calibration status: 0x%X.\n", aapl_addr_to_str(addr),
                             avago_serdes_get_ei_calibration_status(aapl, addr));

        if( get_burst_mode )
            printf("SBus %s, Burst mode: %s.\n", aapl_addr_to_str(addr),
                             aapl_onoff_to_str(avago_serdes_get_burst_mode(aapl, addr)));

        if( get_rate_select )
            printf("SBus %s, Configured rate select: %d.\n", aapl_addr_to_str(addr),
                             avago_serdes_pon_get_rate_select(aapl, addr));

        if( rate_select )
            avago_serdes_pon_set_rate_select(aapl, addr, rate_sel);

        if (get_signal_status)
        {
            char buf[64];
            BOOL signal_ok1   = avago_serdes_get_signal_ok(aapl, addr, TRUE);
            BOOL signal_ok2   = avago_serdes_get_signal_ok(aapl, addr, TRUE);
            BOOL freq_lock    = avago_serdes_get_frequency_lock(aapl, addr);
            if (!avago_serdes_get_signal_ok_enable(aapl, addr))    snprintf(buf, sizeof(buf), "Dis");
            else if (avago_serdes_get_electrical_idle(aapl, addr)) snprintf(buf, sizeof(buf), "1");
            else                                                   snprintf(buf, sizeof(buf), "0");
            printf("%6s EI thresh: %3s   Latched signal_ok: %x   Current signal_ok: %x   Freq lock: %x\n", aapl_addr_to_str(addr), buf, signal_ok1, signal_ok2, freq_lock);
        }

/* Set the clocks: */
        if( set_spico_clk )
            avago_serdes_set_spico_clk_src(aapl, addr, spico_clk);
        if( set_tx_pll_clk )
            avago_serdes_set_tx_pll_clk_src(aapl, addr, tx_pll_clk);
        if( set_pcs_fifo_clk )
            avago_serdes_set_pcs_fifo_clk_div(aapl, addr, pcs_fifo_clk);

        /* Should be after clock setup: */

        if( aux_start ) avago_serdes_aux_counter_start(aapl, addr);
        if (clear_error_counter && !get_ber)         avago_serdes_error_reset(aapl, addr); /* if BER was also called, then it already cleared the error flag */
        if (clear_error_counter || clear_error_flag) avago_serdes_error_flag_reset(aapl, addr);

        if( tx_inject_err ) avago_serdes_tx_inject_error(aapl, addr, tx_inject_err);
        if( rx_inject_err ) avago_serdes_rx_inject_error(aapl, addr, rx_inject_err);

        if( aux_read )
        {
            uint errors = avago_serdes_aux_counter_read(aapl, addr);
            printf("%s Auxiliary counter errors = %u\n", aapl_addr_to_str(addr), errors);
        }
        if( get_error_counter )
        {
            uint errors = avago_serdes_get_errors(aapl, addr, AVAGO_LSB, FALSE);
            printf("%s Errors = %u\n", aapl_addr_to_str(addr), errors);
        }
        if( aux_disable ) avago_serdes_aux_counter_disable(aapl, addr);

        if( rx_read_live_data )
        {
            char buf[21];
            int data = avago_serdes_get_rx_live_data(aapl, addr);
            int i;
            for( i = 0; i < 16; i++ )
                buf[i] = (data & (1 << i)) ? '1' : '0';
            buf[16] = '\0';
            printf("%s Rx live data: %s\n", aapl_addr_to_str(addr), buf);
        }
        if( rx_read_data )
        {
            int i;
            char buf[81];
            long data[4];
            avago_serdes_get_rx_data(aapl, addr, data);
            for( i = 0; i < 80; i++ )
                buf[i] = (data[i/20] & (1 << (i%20))) ? '1' : '0';
            buf[80] = '\0';
            printf("%s Rx Data: %s\n", aapl_addr_to_str(addr), buf);
        }

#if AAPL_ENABLE_ESCOPE_MEASUREMENT || AAPL_ENABLE_PHASE_CALIBRATION
        if (pattern_capture != -1)
        {
            char * pattern = 0;
            if (!pattern_capture) pattern_repeat = 1;

            pattern = avago_serdes_pattern_capture(aapl, addr, pattern_capture * pattern_repeat);
            if (pattern)
            {
                int cmp; /* compare flag */
                char *buf = 0; /* buffer for segments */
                int buf_loc = 0;
                int len = strlen(pattern);
                int segment_len = len/pattern_repeat;
                int number_len = ceil(log(len)/log(10));
                if (pattern_repeat > 1)
                {
                    buf = (char *) aapl_malloc(aapl, sizeof(char) * segment_len+1, __func__);
                    printf("Total length: %d Segment length: %d\n", len, segment_len);
                }

                while (buf_loc < len)
                {
                    if (pattern_repeat > 1) 
                    {
                        snprintf(buf, segment_len+1, "%s", pattern+buf_loc);
                        buf[segment_len] = 0; /* shouldn't be needed, but this fails on windows without */
                    }
                    buf_loc += segment_len;
                    if (pattern_repeat == 1)
                        printf("Bits: %d-%d: %s\n", 0, segment_len-1, pattern);
                    else if (buf_loc-segment_len == 0)
                        printf("         Bits: %*d-%*d: %s\n",       number_len, buf_loc-segment_len, number_len, buf_loc-1, buf);
                    else
                    {
                        cmp = strncmp(buf, pattern, segment_len-1);
                        printf("Match: %1d Bits: %*d-%*d: %s\n", !cmp, number_len, buf_loc-segment_len, number_len, buf_loc-1, buf);
                    }
                }

                aapl_free(aapl, pattern, __func__);
                if (buf) aapl_free(aapl, buf, __func__);
            }
        }
#endif /* AAPL_ENABLE_ESCOPE_MEASUREMENT || AAPL_ENABLE_PHASE_CALIBRATION */

#if AAPL_ENABLE_DIAG
        if (phase_cal_diag) avago_serdes_phase_cal_diag(aapl, addr, phase_cal_diag);
#endif
#if AAPL_ENABLE_DIAG && (AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT)
        if (delay_cal > -1)
            avago_serdes_delay_cal(aapl, addr, delay_cal, delay_cal_dwell, 0, 0);
#endif

        if( enter_low_power_mode ) avago_serdes_enable_low_power_mode(aapl, addr, TRUE);

#if AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG
        if (run_param_sweep) avago_serdes_param_sweep(aapl, addr, &param_sweep);
#endif

/* Display requested info: */
/* */
        if( call_tx_eq_limits )
        {
            Avago_serdes_tx_eq_limits_t limits;
            if( avago_serdes_get_tx_eq_limits(aapl, addr, &limits) == 0 )
            {
                const char *pre = limits.pre2_min == limits.pre2_max ? "pre" : "pre1";
                printf("%s TX_EQ_Limits:", aapl_addr_to_str(addr));
                print_tx_eq_values("pre3" ,limits.pre3_min ,limits.pre3_max ,0);
                print_tx_eq_values("pre2" ,limits.pre2_min ,limits.pre2_max ,0);
                print_tx_eq_values(pre    ,limits.pre_min  ,limits.pre_max  ,limits.pre_step);
                print_tx_eq_values("atten",limits.atten_min,limits.atten_max,limits.atten_step);
                print_tx_eq_values("post" ,limits.post_min ,limits.post_max ,limits.post_step);
                print_tx_eq_values("vert" ,limits.vert_min ,limits.vert_max ,0);
                print_tx_eq_values("amp"  ,limits.amp_min  ,limits.amp_max ,0);
                print_tx_eq_values("slew" ,limits.slew_min ,limits.slew_max, 0);
                print_tx_eq_values("t2" ,limits.t2_min ,limits.t2_max, 0);
                printf(" total: %d\n", limits.total_eq);
            }
        }

        if( display_serdes_state )
            avago_serdes_state_dump(aapl, addr);

        if( dump )
            aapl_print_struct(aapl, 1, 0xffff, (Avago_ip_type_t) 0);

        if( display_ei )
            printf("SBus %6s       EI  = %s\n", aapl_addr_to_str(addr), aapl_bool_to_str(avago_serdes_get_electrical_idle(aapl, addr)));
        if( display_ffl )
            printf("SBus %6s       FFL = %s\n", aapl_addr_to_str(addr), aapl_bool_to_str(avago_serdes_get_frequency_lock(aapl, addr)));
        if( display_signal_ok )
            printf("SBus %6s Signal-OK = %s\n", aapl_addr_to_str(addr), aapl_bool_to_str(avago_serdes_get_signal_ok(aapl, addr, TRUE)));
#if AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG
        if (tune_vernier) avago_serdes_tune_vernier(aapl, addr);
#endif
    }

    /* NOTE: The following function(s) accept an address list, and therefore don't need to be in the above for loop. */

#if AAPL_ENABLE_FLOAT_USAGE
    if( count_errors && avago_serdes_parallel_count_errors(aapl, &addr_struct, count_errors) )
    {
        Avago_addr_t *ptr;
        for( ptr = &addr_struct; ptr != NULL; ptr = ptr->next )
        {
            uint addr = avago_struct_to_addr(ptr);
            bigint errors = ptr->bigint_results;
            printf("%6s  %12.5g errors in %12g bits.   Approximate BER %.2e\n", aapl_addr_to_str(addr), (double)errors, (double)count_errors, ((double)errors) / count_errors);
        }
    }
#endif

#if AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG
# if AAPL_ENABLE_FILE_IO
    if( start_async_ber ) avago_serdes_async_ber_start(aapl, &addr_struct, refclk, async_filename);
# endif
    if( get_ber         ) avago_serdes_get_ber(aapl, &addr_struct, ber_dwell, refclk, TRUE, clear_error_counter, get_ber_aux);
# if AAPL_ENABLE_FILE_IO
    if( read_async_ber  ) avago_serdes_async_ber_read(aapl, &addr_struct, refclk, async_filename);
# endif /* AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG */
#endif

    } while (cont);

cleanup_and_exit:
    if( aapl->return_code && !rc ) printf("ERROR\n");
    if( !rc && aapl->return_code != 0 ) rc = 1;
    avago_addr_delete(aapl, &addr_struct);
    return rc;
}

#endif /* AAPL_ENABLE_MAIN */
