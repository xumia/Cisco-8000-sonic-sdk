/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* AAPL (ASIC and ASSP Programming Layer) support for gathering eye diagram */
/* data from a SerDes slice (28nm only). */

/** Doxygen File Header */
/** @file */
/** @brief Functions for SerDes waveform capture. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_ESCOPE_MEASUREMENT

/** @brief  Constructs a plot object for a graph of the given size. */
/** @returns Returns a pointer to an allocated and initialized plot object. */
/**          The caller should pass this pointer to avago_plot_destruct() when finished with the returned object. */
Avago_plot_t *avago_plot_construct(
    Aapl_t *aapl,   /**< Pointer to Aapl_t structure. */
    uint x,         /**< The horizontal size of the graph. */
    uint y)         /**< The vertical size of the graph. */
{
    size_t bytes = sizeof(Avago_plot_t) + x * y * sizeof(char);
    Avago_plot_t *plot = (Avago_plot_t *) aapl_malloc(aapl, bytes, __func__);
    memset(plot,0,bytes);
    plot->x_points = x;
    plot->y_points = y;
    /* Note: points refs the bytes after the struct (single alloc for both) */
    plot->points = (char *)plot + sizeof(Avago_plot_t);
    return plot;
}

/** @brief   Destroys and releases the plot object. */
/** @returns void. */
void avago_plot_destruct(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    Avago_plot_t *plot)     /**< Plot object to destruct. */
{
    if( plot ) aapl_free(aapl,plot,__func__);
}

#if AAPL_ENABLE_FILE_IO
/** @brief Writes an ascii graph of the plot object to file. */
/** @returns void. */
void avago_plot_print_ascii(
    FILE *file,                 /**< File pointer into which to write the plot. */
    const Avago_plot_t *plot)   /**< Plot object to graph. */
{
    uint y;
    char *buf = (char *)AAPL_MALLOC(plot->x_points + 2);
    for( y = 0; y < plot->y_points; y ++ )
    {
        int last_index = -1;
        uint x;
        /* Convert points to an ascii buffer to print: */
        for( x = 0; x < plot->x_points; x++ )
        {
            buf[x] = AVAGO_PLOT_GET(*plot,x,y);
            if( buf[x] != ' ' )
                last_index = x;
        }

        /* Trim trailing spaces from buffer: */
        strcpy(&buf[last_index+1],"\n");

        fputs(buf,file);
    }
    AAPL_FREE(buf);
}
#endif

#if 0
int avago_plot_get_point(const Avago_plot_t *plot, int x, int y)
{
    return AVAGO_PLOT_GET(*plot,x,y);
}

int avago_serdes_escope_get_point(const Avago_serdes_escope_data_t *datap, int x, int dac)
{
    return AVAGO_ESCOPE_ONES_GET(*datap,x,dac);
}
#endif

static Avago_waveform_t *escope_waveform_construct(Aapl_t *aapl, const Avago_serdes_escope_data_t *datap)
{
    uint x = datap->sd_x_points;
    uint x_res = datap->sd_x_resolution;
    size_t bytes = sizeof(Avago_waveform_t) + x * sizeof(Avago_wavepoint_t);
    Avago_waveform_t *wave = (Avago_waveform_t *) aapl_malloc(aapl, bytes, __func__);
    wave->x_points = x;
    wave->x_resolution = x_res;
    wave->bits_per_ui = datap->sd_bits_per_ui;
    wave->datapath_flags = datap->sd_datapath_flags;
    wave->y_center = datap->sd_y_center;
    wave->y_step   = datap->sd_y_step;
    /* Note: points is allocated bigger than actually declared: */
    memset(wave->points, 0, x * sizeof(Avago_wavepoint_t));
    return wave;
}

static Avago_waveform_t *escope_pulsewave_construct(Aapl_t *aapl, const Avago_waveform_t *escope_wave, int pulse_width)
{
    uint x = pulse_width * escope_wave->x_resolution;
    size_t bytes = sizeof(Avago_waveform_t) + x * sizeof(Avago_wavepoint_t);
    Avago_waveform_t *wave = (Avago_waveform_t *) aapl_malloc(aapl, bytes, __func__);
    if( wave )
    {
        wave->x_points = x;
        wave->x_resolution = escope_wave->x_resolution;
        wave->y_center = 0;
        wave->y_step   = 1;
        wave->bits_per_ui = 0;
        wave->datapath_flags = escope_wave->datapath_flags;
        /* Note: points is allocated bigger than actually declared: */
        memset(wave->points, 0, x * sizeof(Avago_wavepoint_t));
    }
    return wave;
}

static void avago_escope_waveform_destruct(Aapl_t *aapl, Avago_waveform_t *waveform)
{
    if( waveform ) aapl_free(aapl,waveform,__func__);
}

/* Find the min, max and eye sample points: */
static void find_mids(const Avago_waveform_t *wave, float *min, float *max, int *lo, int *mid, int *hi)
{
    float min_dac = 512.0;
    float max_dac = 0.0;
    uint x;
    int tune[512];
    memset(tune,0,sizeof(tune));
    for( x = 0; x < wave->x_points; x++ )
    {
        uint mod = x % wave->x_resolution;
        BOOL mid_ui = mod == wave->x_resolution / 2;
        float dac = wave->points[x].dac_mean;
        if( min_dac > dac )
            min_dac = dac;
        if( max_dac < dac )
            max_dac = dac;
        if( mid_ui && dac < AAPL_ARRAY_LENGTH(tune) && dac >= 0 )
            tune[(int)dac] = 1;
    }
    *max = max_dac;
    *min = min_dac;
    *hi  = max_dac/2 + 64;
    *mid = (max_dac + min_dac) / 2;
    *lo  = *min/2 + 64;
    if( min_dac < 0 ) return;

    if( max_dac < AAPL_ARRAY_LENGTH(tune) )
    {
        uint lo_opening = 0, mid_opening = 0, hi_opening = 0;
        int start = 0, end = 0;
        for( x = *min+1; x <= *max; x++ )
        {
            if(  tune[x-1] && !tune[x] ) { start = x; end = 0; }
            if( !tune[x-1] &&  tune[x] ) end = x - 1;
            if( start && end )
            {
                uint opening = end - start + 1;
                uint center = (end + start) / 2;
                /*printf("start = %d, end = %d, center = %u, opening = %u\n", start, end, center, opening); */
                if(      center < (wave->y_center-32) && opening > lo_opening  ) { *lo  = center; lo_opening  = opening; }
                else if( center > (wave->y_center+32) && opening > hi_opening  ) { *hi  = center; hi_opening  = opening; }
                else if( center < (wave->y_center+32) && center > (wave->y_center-32) && opening > mid_opening ) { *mid = center; mid_opening = opening; }
            }
        }
#if 0
        /*for( x = *min; x <= *max; x++ ) printf("%d", tune[x]); printf("\n"); */
        if( wave->bits_per_ui > 1 )
            printf("min = %f, max = %f, lo = %d(%d..%d), mid = %d(%d..%d), hi = %d(%d..%d)\n",*min, *max,
                    *lo,  *lo -( lo_opening-1)/2,*lo + lo_opening/2,
                    *mid, *mid-(mid_opening-1)/2,*mid+mid_opening/2,
                    *hi,  *hi -( hi_opening-1)/2,*hi + hi_opening/2);
        else
            printf("min = %f, max = %f, mid = %d(%d..%d)\n",*min, *max, *mid, *mid-(mid_opening-1)/2,*mid+mid_opening/2);
#endif
    }
}

#if 1

/* Generate encoded PRBS sequence. */
/* If precode is selected, precode_prev is used as the initial previous symbol. */
static BOOL gen_encoded_prbs(char *prbs, uint nbits, uint p1, uint p2, uint p3, uint p4, int flags, int precode_prev)
{
    uint i;
    int prev = precode_prev;
    int step = (flags & 0xe) ? 2 : 1;

    memset(prbs, '1', p1);
    prbs[nbits] = '\0';
    for( i = p1; i < nbits; i++ )
        prbs[i] = '0' + (prbs[i-p1] ^ prbs[i-p2] ^ prbs[i-p3] ^ prbs[i-p4]);
 /* printf("ORIGINAL PRBS: %s\n", prbs); */
    for( i = 0; i < nbits; i += step )
    {
        if( step == 2 )
        {
            int value = 2 * (prbs[i+1]-'0') + (prbs[i]-'0');
            if( flags & 8 ) if( value == 2 || value == 1 ) value = 3 - value;   /* Swizzle */
            if( flags & 2 ) if( value == 3 || value == 2 ) value = 5 - value;   /* Gray encode */
            if( flags & 1 ) value = 3 - value;                                  /* Invert */
            if( flags & 4 ) { value = (4+value-prev)%4; prev = value; }         /* Precode */
            prbs[i] = (value & 1) + '0';
            prbs[i+1] = ((value >> 1) & 1) + '0';
        }
        else if( flags & 1 )
            prbs[i] = '1' - prbs[i] + '0';
    }
    return TRUE;
}

static uint find_fit(char *bits, uint nbits, char *prbs, uint gen_bits)
{
    uint i, min_errors = nbits, best_offset = 0;
    char *temp = (char *)AAPL_MALLOC(nbits+1);

    for( i = 0; i < gen_bits; i++ )
    {
        uint j, errors = 0;
        for( j = 0; j < nbits; j++ )
        {
            if( prbs[(i+j)%gen_bits] != bits[j] )
            {
                if( ++errors >= min_errors )
                    break;
            }
        }
        if( errors < min_errors )
        {
            min_errors = errors;
            best_offset = i;
        }
    }
 /* printf("Best offset at %u\n", best_offset); */
    for( i = 0; i < nbits; i++ )
        temp[i] = prbs[(i+best_offset)%gen_bits];

    memcpy(prbs, temp, nbits+1);
    AAPL_FREE(temp);
    return min_errors;
}

/* Input is assumed to be a full-length prbs pattern. */
static BOOL check_prbs(char *bits, uint nbits, uint p1, uint p2, uint p3, uint p4, BOOL correct_prbs, int flags)
{
    uint gen_bits = nbits * 4;
    char *prbs = (char *)AAPL_MALLOC(gen_bits+1);
    uint min_errors = nbits, best_prefix = 0, prefix;

    /*printf("check_prbs: nbits = %u, p1=%u, p2=%u, p3=%u, p4=%u, correct_prbs=%d\n",nbits,p1,p2,p3,p4,correct_prbs); */

    for( prefix = 0; prefix < 4 && min_errors > 0; prefix++ )
    {
        uint errors;
        gen_encoded_prbs(prbs, gen_bits, p1, p2, p3, p4, flags, prefix);
        errors = find_fit(bits, nbits, prbs, gen_bits);
        if( errors < min_errors )
        {
            best_prefix = prefix;
            min_errors = errors;
        }
    }
    if( min_errors > 0 && best_prefix != 3 )
    {
        gen_encoded_prbs(prbs, gen_bits, p1, p2, p3, p4, flags, best_prefix);
        find_fit(bits, nbits, prbs, gen_bits);
    }

 /* printf("ORIGINAL BITS: %s\n", bits); */
 /* printf("ENCODED  PRBS: %s\n", prbs); */
    if( correct_prbs )
        memcpy(bits, prbs, nbits);
 /* printf("NEW      BITS: %s\n", bits); */
 /* printf("Minimum errors of %u at prefix of %u\n", min_errors, best_prefix); */
    AAPL_FREE(prbs);
    return min_errors * 10 < nbits;
}

/** @cond INTERNAL */

/** @brief   Sets bits to the data pattern of the waveform. */
/** @details If the input is an exact-length prbs pattern, and correct_prbs is set, bits will return a corrected version of the input. */
/** @return  Returns TRUE if input is a full-length PRBS pattern, FALSE if not. */
BOOL avago_extract_prbs(
    const Avago_waveform_t *wave,   /**< [in] Waveform to evaluate */
    BOOL correct_prbs,              /**< [in] Flag to modify action of function. */
    uint len,                       /**< [in] Length of bits array. */
    char *bits)                     /**< [out] Returns extracted data. */
{
    float min_dac, max_dac;
    int lt, mt, ht;
    uint x;
    uint ui = wave->x_points / wave->x_resolution;
    uint nbits = ui * wave->bits_per_ui;
    uint bit = 0;
    int flags = wave->datapath_flags;

    /* printf("Extract PRBS: ui=%u, nbits=%u, len=%u, flags=0x%x\n",ui,nbits,len,flags); */

    if( len - 1 < nbits )
        nbits = len - 1;

    memset(bits, '0', nbits);
    bits[nbits] = '\0';

    find_mids(wave, &min_dac, &max_dac, &lt, &mt, &ht);

    for( x = wave->x_resolution/2; x < wave->x_points && bit < nbits; x += wave->x_resolution )
    {
        const float dac_mean = wave->points[x].dac_mean;

        if( wave->bits_per_ui > 1 ) /* PAM4 */
        {
            int value;
            if( dac_mean > mt )
                value = (dac_mean > ht) ? 3 : 2;
            else
                value = (dac_mean < lt) ? 0 : 1;

            bits[bit++] += (value >> 0) & 1;
            if( bit < nbits )
                bits[bit++] += (value >> 1) & 1;
        }
        else    /* NRZ */
        {
            int value = dac_mean > mt ? 1 : 0;
            bits[bit++] += value;
        }
    }
 /* printf("UI: %u, nbits: %u\n", ui, nbits); */
 /* printf("Waveform BITS: %s\n", bits); */

    {
        BOOL prbs_match = FALSE;
        switch( ui )
        {
        case   127: prbs_match = check_prbs(bits, nbits,  7,  6, 0, 0, correct_prbs, flags); break;
        case   511: prbs_match = check_prbs(bits, nbits,  9,  5, 0, 0, correct_prbs, flags); break;
        case  2047: prbs_match = check_prbs(bits, nbits, 11,  9, 0, 0, correct_prbs, flags); break;
        case  8091: prbs_match = check_prbs(bits, nbits, 13, 12, 2, 1, correct_prbs, flags); break;
        case 32767: prbs_match = check_prbs(bits, nbits, 15, 14, 0, 0, correct_prbs, flags); break;
        }
        return prbs_match;
    }
}
/** @endcond */
#endif

/** @brief  Plots the waveform onto the ASCII plot object. */
void avago_plot_ascii_waveform(
    Avago_plot_t *plot,             /**< [out] A constructed plot object to be written to. */
    const Avago_waveform_t *wave)   /**< [in] An escope waveform object. */
{
    uint y;
    float min_dac, max_dac;
    int lt, mt, ht;
    double y_step, dac_range_high;
    int flags = wave->datapath_flags;

    find_mids(wave, &min_dac, &max_dac, &lt, &mt, &ht);

    y_step = (max_dac - min_dac) / (plot->y_points-1) + 0.00001;

    /*printf("Plot ASCII Waveform: %d points, min=%g, max=%g, step=%g\n",wave->x_points,min_dac,max_dac,y_step); */

    /* Horizontal ascii plot: */
    dac_range_high = max_dac;
    for( y = 0; y < plot->y_points; y++, dac_range_high -= y_step )
    {
        int prev = 0;
        char bitvalue0 = '-', bitvalue1 = '-';
        float dac_range_low = dac_range_high - y_step;
        int mid_y = wave->y_center < dac_range_high && wave->y_center >= dac_range_low;
        uint x;
        for( x = 0; x < wave->x_points; x++ )
        {
            const float dac_mean = wave->points[x].dac_mean;
            BOOL match = dac_mean <= dac_range_high && dac_mean > dac_range_low;
            uint mod = x % wave->x_resolution;
            BOOL mid_ui = mod == wave->x_resolution / 2;
            BOOL mid_ui_plus = mod == wave->x_resolution / 2 + 1;
            char symbol;
            if( mid_y && mid_ui && wave->bits_per_ui > 0 )
            {
                if( wave->bits_per_ui > 1 ) /* PAM4 */
                {
                    int value;
                    if( dac_mean > mt )
                        value = (dac_mean > ht) ? 3 : 2;
                    else
                        value = (dac_mean < lt) ? 0 : 1;

                    if( flags & 4 ) { int p = value; value = (prev+p)%4; prev = p; }    /* De-precode */
                    if( flags & 1 ) value = 3 - value;                                  /* De-Invert */
                    if( flags & 2 ) if( value == 3 || value == 2 ) value = 5 - value;   /* De-Gray encode */
                    if( flags & 8 ) if( value == 2 || value == 1 ) value = 3 - value;   /* De-Swizzle */
                    bitvalue0 = '0' + ((value>>0) & 1);
                    bitvalue1 = '0' + ((value>>1) & 1);
                }
                else    /* NRZ */
                {
                    int value = dac_mean > dac_range_high ? 1 : 0;
                    if( flags & 1 ) value = 1 - value;                                  /* De-Invert */
                    bitvalue0 = '0' + value;
                }
            }

            /* Symbol priority: 0/1, '^', '*', '+', '-', ' '. */
            symbol = match
                        ? (mid_ui ? '^' : '*')  /* Waveform characters */
                        : mid_y                 /* Else background characters */
                            ? (mod == 0 ? '+' : '-')    /* Center line */
                            : ' ';                      /* Spaces */

            /* Overlay UI value decoding (if not pulse response): */
            /* If mid_y && mid_ui and escope wave (not pulse response) */
            if( mid_y && mid_ui      && wave->bits_per_ui > 0 ) symbol = bitvalue0;
            if( mid_y && mid_ui_plus && wave->bits_per_ui > 1 ) symbol = bitvalue1;

            AVAGO_PLOT_SET(*plot,x,y,symbol);
        }
    }
}


/** @brief Plots all escope UI onto a one UI plot. */
void avago_plot_ascii_eye(
    Avago_plot_t *plot,             /**< [out] A constructed plot object to be written to. */
    const Avago_waveform_t *wave)   /**< [in] An escope waveform object. */
{
    float min_dac = 512.0;
    float max_dac = 0.0;
    float y_step;
    uint x;

    memset(plot->points,' ', plot->x_points * plot->y_points * sizeof(*plot->points));
    /* Find extremes for auto-ranging plot: */
    for( x = 0; x < wave->x_points; x++ )
    {
        float dac = wave->points[x].dac_mean;
        if( min_dac > dac )
            min_dac = dac;
        if( max_dac < dac )
            max_dac = dac;
    }

    y_step = (max_dac - min_dac) / (plot->y_points-1) + 0.00001;

    for( x = 0; x < wave->x_points; x++ )
    {
        int y = (int) plot->y_points - 1 - ((wave->points[x].dac_mean - min_dac) / y_step);
        int x_mod = x % wave->x_resolution;
        const char value = '#';
        AVAGO_PLOT_SET(*plot,x_mod,y,value);
        if( x_mod == 0 )
            AVAGO_PLOT_SET(*plot,wave->x_resolution,y,value);
    }
}


/** @brief  Allocates and initializes Avago_serdes_escope_config_t structure. */
/** @details The returned object should be passed to avago_serdes_escope_config_destruct() when its use is complete. */
/** @return Pointer to resulting struct.  In case of error, decrements */
/**         aapl->return_code and returns NULL. */
Avago_serdes_escope_config_t *avago_serdes_escope_config_construct(
    Aapl_t *aapl)                   /**< [in] Pointer to Aapl_t structure. */
{
    size_t bytes = sizeof(Avago_serdes_escope_config_t);
    Avago_serdes_escope_config_t *configp = (Avago_serdes_escope_config_t *) aapl_malloc(aapl, bytes, __func__);

    if( 0 == configp )
        return NULL;

    memset(configp, 0, bytes);

    /* Set default values */
    configp->sc_x_UI = 80;
    configp->sc_x_pattern_length = 127;
    configp->sc_x_resolution = 64;
    configp->sc_y_step_size = 1;
    configp->sc_read_count = 1;
    configp->sc_set_phase_center = 1;
    return configp;
}


/** @brief  Deallocates a Avago_serdes_escope_config_t structure. */
/** */
/** @return void */
void avago_serdes_escope_config_destruct(
    Aapl_t *aapl,                   /**< [in] Pointer to Aapl_t structure. */
    Avago_serdes_escope_config_t *configp)  /**< [in] data to free */
{
    if( configp ) aapl_free(aapl,configp,__func__);
}


/** @brief  Allocates and initializes an Avago_serdes_escope_data_t structure. */
/** @return Pointer to resulting struct.  In case of error, modifies aapl and */
/**         returns NULL. */
Avago_serdes_escope_data_t *avago_serdes_escope_data_construct(
    Aapl_t *aapl)                   /**< [in] Pointer to Aapl_t structure. */
{
    size_t bytes = sizeof(Avago_serdes_escope_data_t);
    Avago_serdes_escope_data_t *datap = (Avago_serdes_escope_data_t *) aapl_malloc(aapl, bytes, __func__);

    if( 0 == datap )
        return NULL;

    memset(datap, 0, bytes);
    datap->sd_bits_per_ui = 1;
    return datap;
}

/** @brief   Deallocates a Avago_serdes_escope_data_t structure. */
/** @details Frees any allocated members as well as itself. */
/** @return  void. */
void avago_serdes_escope_data_destruct(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    Avago_serdes_escope_data_t *datap)  /**< [in] data to free */
{
    if( !datap )
        return;

    if( datap->sd_onesp           ) aapl_free(aapl,datap->sd_onesp,           __func__);
    if( datap->sd_hardware_log    ) aapl_free(aapl,datap->sd_hardware_log,    __func__);
    if( datap->sd_phase_center_log) aapl_free(aapl,datap->sd_phase_center_log,__func__);
    if( datap->sd_comment         ) aapl_free(aapl,datap->sd_comment         ,__func__);
    avago_escope_waveform_destruct(aapl, datap->sd_waveform4);
    avago_escope_waveform_destruct(aapl, datap->sd_waveform3);
    avago_escope_waveform_destruct(aapl, datap->sd_waveform2);
    avago_escope_waveform_destruct(aapl, datap->sd_waveform);
    avago_escope_waveform_destruct(aapl, datap->sd_pulse4);
    avago_escope_waveform_destruct(aapl, datap->sd_pulse3);
    avago_escope_waveform_destruct(aapl, datap->sd_pulse2);
    avago_escope_waveform_destruct(aapl, datap->sd_pulse);
    aapl_free(aapl,datap,__func__);
}

/* GET MEMORY for results arrays: */
/* */
/* Note:  Order of operations here matters.  See comments about caller data */
/* sniffing of Avago_serdes_escope_data_t in where???? */

static int allocate_escope_arrays(Aapl_t *aapl, Avago_serdes_escope_data_t *datap)
{
    Avago_waveform_t *wave = escope_waveform_construct(aapl, datap);
    size_t data_bytes = datap->sd_x_points * datap->sd_y_points * sizeof(*datap->sd_onesp);
    char *data = (char *)aapl_malloc(aapl, data_bytes, "Avago_serdes_escope_data_t.sd_onesp");
    if( !data || !wave )
    {
        if( data ) aapl_free(aapl, data,    "sd_onesp");
        if( wave ) avago_escope_waveform_destruct(aapl, wave);
        data = 0;
        wave = 0;
    }
    else
    {
        memset(data, 0, data_bytes);
    }

    datap->sd_onesp = data;
    datap->sd_waveform = wave;

    return aapl->return_code;
}


/** Format the 8, 10 bit words in data into an 80 character output. */
/**        The buffer "output" must be at least 81 characters long. */

static char *big_reg_format(short data[8], char *output, int bit_count)
{
    const char bits[3] = "01";
    int bit;

    for( bit = 0; bit < bit_count; bit++ )
    {
        int data_word = bit / 10;
        int data_bit  = bit % 10;
        output[bit] = bits[ (data[data_word] >> data_bit) & 0x1 ];
    }
    output[bit] = '\0';

    return output;
}

/* Log 80-bit register reads: */
static void log_data_read(Aapl_t *aapl, Aapl_log_type_t level, const char *func, int line, int window, int phase, int y, short data[8], Avago_serdes_escope_data_t *datap)
{
    (void)datap;
    if( aapl->debug >= (uint)level )
    {
        char output[81];
        int width = MIN(80, (datap->sd_x_points - window) / datap->sd_x_resolution);
        big_reg_format(data,output,width);
        aapl_log_printf(aapl, level, func, line, "%d,%3d,%3d: %s\n",window,phase,y,output);
    }
}


/* The heartbeat uses a count down timer, and we are loading into */
/*   almost_done_counter the value at which to stop the capture. */

/* Window is start of which 80 bit window of the pattern to capture. */
/* */
static int setup_capture_window(Aapl_t *aapl, uint sbus_addr, int window, Avago_serdes_escope_data_t *datap)
{
    return avago_meas_setup_data_capture(aapl, sbus_addr, datap->sd_x_pattern_length, datap->sd_x_UI, window);
}


typedef struct
{
    int base_compare_register;  /* Base AVSD_LSB_COMPARE register value */
                                /* Used to avoid reading this in the inner loop */
    int current_phase;          /* Current PI */
    int left_phase;             /* PI for left edge of UI */
    int syms_per_heartbeat;     /* AKA register clock */
    int ui_window_width;        /* UI per window */

} ESCOPE_STATE;


/* Here we try to locate the dac value for column x that most accurately */
/*   represents the dac value where half the time we would read a 0 and */
/*   half the time we would read a 1. */
/* We expect that dac values below this will read more zeros than ones, */
/*  and dac values above this will read more ones than zeros. */
/* */
/* Algorithm: */
/*  For each rising transition from less than 50% ones, to 50% or more ones, */
/*  interpolate the 50% dac value.  If we have multiple such transitions, */
/*  average them to determine our result. */

static float find_dac_mean(Aapl_t *aapl, Avago_serdes_escope_data_t *datap, int x)
{
    int dac_min = datap->sd_y_center % datap->sd_y_step;
    float result = 0.0;
    int prev_ones_count = AVAGO_ESCOPE_ONES_GET(*datap,x,0);
    int mid_count = 0;
    int rising_count = 0;
    int falling_count = 0;
    uint y;
    for( y = 1; y < datap->sd_y_points; y++ )
    {
        Avago_least_sqr_point points[2];
        double prev_ratio, curr_ratio;
        int curr_ones_count = AVAGO_ESCOPE_ONES_GET(*datap, x, y);
        if( prev_ones_count == curr_ones_count )
            continue;

        prev_ratio = 1.0 * prev_ones_count / datap->sd_read_count;
        curr_ratio = 1.0 * curr_ones_count / datap->sd_read_count;
        points[0].y = (y-1) * datap->sd_y_step + dac_min;
        points[1].y = y * datap->sd_y_step + dac_min;

        /* Process only rising or only falling edges, whichever we see first: */
        if( rising_count == 0 && prev_ratio > 0.5 && curr_ratio <= 0.5 ) /* Falling */
            falling_count++;
        if( falling_count == 0 && prev_ratio < 0.5 && curr_ratio >= 0.5 ) /* Rising (rare) */
            rising_count++;

        if( falling_count + rising_count != mid_count )
        {
            Avago_least_sqr_results lsqr_out;
            points[0].x = avago_qfuncinv(prev_ratio);
            points[1].x = avago_qfuncinv(curr_ratio);

            avago_least_sqr(points, 2, &lsqr_out);

            /* printf("%g,%g :: %g,%g -> 0.0,%g\n",points[0].x,points[0].y,points[1].x,points[1].y,lsqr_out.y_intercept); */

            result += lsqr_out.y_intercept;
            mid_count++;
        }
        prev_ones_count = curr_ones_count;
    }
    if( mid_count == 0 ) /* We found no transition */
    {
        if( prev_ones_count * 2 < datap->sd_read_count )
            result = 0.0;
        else
            result = datap->sd_y_center * 2 - 1;
    }
    else /* average values for the multiple transitions: */
        result /= mid_count;
    if( mid_count != 1 )
        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "x = %d, dac = %g, transitions = %d\n",x,result,mid_count);
    return result;
}

/* Calculate the standard deviation of the calculated dac transition point. */
/* */
/* Algorithm: */
/*   dac_mean = calculated 50% transition dac value */
/*   interval = each unit change in a dac */
/*   i_mid = dac mid-point value of each interval (eg, 183.5, 184.5, ...) */
/*   i_slope = change in ones count over each interval */
/*   read_count = number of samples read == max ones count */
/* */
/*   stddev = sqr_root ( sum( (i_mid - dac_mean)^2 * i_slope ) / read_count); */

static float find_stddev(Aapl_t *aapl, Avago_serdes_escope_data_t *datap, int x)
{
    float sum = 0.0;
    float dac_mean = datap->sd_waveform->points[x].dac_mean;
    int prev_ones_count = AVAGO_ESCOPE_ONES_GET(*datap, x, 0);
    uint y;
    (void)aapl;
    for( y = 1; y < datap->sd_y_points; y++ )
    {
        int curr_ones_count = AVAGO_ESCOPE_ONES_GET(*datap, x, y);
        if( prev_ones_count != curr_ones_count )
        {
            /* skip if slope == 0 */
            int slope = curr_ones_count - prev_ones_count;
            float dac = (y - 0.5) * datap->sd_y_step;
            float dac_delta = dac - dac_mean;
            sum += dac_delta * dac_delta * abs(slope);

            prev_ones_count = curr_ones_count;
        }
    }
    sum /= datap->sd_read_count;
    return sqrtf(sum);
}

/* Save data register values to Avago_serdes_escope_data_t */
static void save_data(short data[8], uint window, int phase, int y, Avago_serdes_escope_data_t *datap)
{
    int bit;
    uint result_bit = window;
    for( bit = 0; bit < 80; bit += datap->sd_waveform->bits_per_ui )
    {
        int word = bit / 10;
        int word_bit = bit % 10;
        if( result_bit >= datap->sd_x_UI )
            return;    /* skip if past bits of interest */
        if( (data[word] >> word_bit) & 0x01 )  /* If bit is set, increment counter */
                AVAGO_ESCOPE_ONES_ADD3(*datap, result_bit, phase, y, 1);
        result_bit++;
    }
}

static BOOL is_all_same(Avago_serdes_escope_data_t *datap, int window, int phase, int y)
{
    int val = AVAGO_ESCOPE_ONES_GET3(*datap,window,phase,y);
    int end = MIN(datap->sd_x_UI, window + 80 / datap->sd_waveform->bits_per_ui);
    int bit;
    for( bit = window; bit < end; bit++ )
        if( AVAGO_ESCOPE_ONES_GET3(*datap, bit, phase, y) != val )
            return FALSE;
    return TRUE;
}

static void extrapolate(Avago_serdes_escope_data_t *datap, int window, int phase, int row, int step, int yend)
{
    int end = MIN(datap->sd_x_UI, window + 80 / datap->sd_waveform->bits_per_ui);
    int bit;
  /*printf("EXTRAPOLATE %d %d..x %d %d..%d, %d\n",phase,row,step,window,end, AVAGO_ESCOPE_ONES_GET3(*datap, window, phase, row)); */
    for( bit = window; bit < end; bit++ )
    {
        int count = AVAGO_ESCOPE_ONES_GET3(*datap, bit, phase, row);
        if( count > 0 )
        {
            int y;
            for( y = row + step; y != yend; y += step )
                AVAGO_ESCOPE_ONES_SET3(*datap, bit, phase, y, count);
        }
    }
}

static int get_escope_column(Aapl_t *aapl, uint sbus_addr, int window, int phase, ESCOPE_STATE *esp, Avago_serdes_escope_data_t *datap)
{
    int dac, i, phase_base;
    int all_same_count = 0;
    int bits = MIN(datap->sd_x_UI - window, 80U / datap->sd_bits_per_ui);
    int data_bits = bits;
    if( datap->sd_bits_per_ui > 1 )
        bits *= 2;

    /* Capture from DAC center up: */
    for( dac = datap->sd_y_center; dac < (int)datap->sd_y_center*2; dac += datap->sd_y_step )
    {
        short data[8]; /* Data capture buffer */
        int y = dac / datap->sd_y_step;
        for( i = 0; i < datap->sd_read_count; i++ )
        {
            avago_serdes_set_dac(aapl, sbus_addr, dac, FALSE);
            avago_meas_capture_and_read(aapl, sbus_addr, esp->base_compare_register, bits, data);
            save_data(data, window, phase, y, datap);
        }
        log_data_read(aapl, AVAGO_DEBUG2, __func__, __LINE__, window, phase, y, data, datap);
        if( is_all_same(datap, window, phase, y) )
        {
            if( ++all_same_count >= 2 )
            {
                aapl_log_printf(aapl,AVAGO_DEBUG1,__func__,__LINE__,"SBus %s; window %d, phase %d; extrapolating dac [%d..255] to 0\n",aapl_addr_to_str(sbus_addr),window,phase,dac);
                extrapolate(datap, window, phase, y, +1, datap->sd_y_points);
                break;
            }
        }
        else
            all_same_count = 0;
    }
    /* Capture from DAC center down: */
    for( dac = datap->sd_y_center - datap->sd_y_step; dac >= 0; dac -= datap->sd_y_step )
    {
        short data[8]; /* Data capture buffer */
        int y = dac / datap->sd_y_step;
        for( i = 0; i < datap->sd_read_count; i++ )
        {
            avago_serdes_set_dac(aapl, sbus_addr, dac, FALSE);
            avago_meas_capture_and_read(aapl, sbus_addr, esp->base_compare_register, bits, data);
            save_data(data, window, phase, y, datap);
        }
        log_data_read(aapl, AVAGO_DEBUG2, __func__, __LINE__, window, phase, y, data, datap);
        if( is_all_same(datap, window, phase, y) )
        {
            if( ++all_same_count >= 2 )
            {
                aapl_log_printf(aapl,AVAGO_DEBUG1,__func__,__LINE__,"SBus %s, window %d; phase %d; extrapolating dac [%d..0] to 1\n",aapl_addr_to_str(sbus_addr),window,phase,dac);
                extrapolate(datap, window, phase, y, -1, -1);
                break;
            }
        }
        else
            all_same_count = 0;
    }

    /* Incrementally extract the waveform so it can be incrementally */
    /*   displayed as it is gathered. */
    phase_base = datap->sd_x_resolution * window + phase;
    for( i = 0; i < data_bits; i++ )
    {
        int x = phase_base + i * datap->sd_x_resolution;
        datap->sd_waveform->points[x].dac_mean = find_dac_mean(aapl, datap, x);
        datap->sd_waveform->points[x].dac_stddev = find_stddev(aapl, datap, x);
    }
    return aapl->return_code;
}

static int capture(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,             /**< [in] SBus slice address. */
    ESCOPE_STATE *esp,
    Avago_serdes_escope_data_t *datap)
{
    uint ui;
    datap->sd_waveform->bits_per_ui = datap->sd_bits_per_ui;
    for( ui = 0; ui < datap->sd_x_UI; ui += esp->ui_window_width )
    {
        uint phase;
        setup_capture_window(aapl, sbus_addr, ui, datap);

        for( phase = 0; phase < datap->sd_x_resolution; phase++ )
        {
            int new_phase = phase * datap->sd_x_step + esp->left_phase;
            avago_serdes_step_phase(aapl, sbus_addr, new_phase, &esp->current_phase, FALSE);
            get_escope_column(aapl, sbus_addr, ui, phase, esp, datap);
        }
    }
    return aapl->return_code;
}



/*============================================================================= */
/* S E R D E S  E S C O P E  G E T */
/* */
/** @brief  Gathers escope data (measurements) from a SerDes slice. */
/** */
/** @return Returns 0 on success, -1 and decrements aapl->return_code on error. */

int avago_serdes_escope_get(
    Aapl_t *aapl,                          /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,                        /**< [in] SBus slice address. */
    const Avago_serdes_escope_config_t *configp,   /**< [in] Configuration parameters for how to run escope */
    Avago_serdes_escope_data_t *datap)             /**< [out] Where to save the gathered escope data. */
{
    ESCOPE_STATE es;
    ESCOPE_STATE *esp = &es;
    uint dfe_resume_status = 0;
    Avago_serdes_rx_cmp_mode_t orig_cmp_mode;
    Avago_serdes_rx_cmp_data_t orig_cmp_data;
    Avago_serdes_rx_data_qual_t orig_data_qual;
    int max_resolution, original_phase, phase_center;
    uint res;
    BOOL restore_low_power_mode = FALSE;

/* Warn if error state exists on entrance: */
    int ret = aapl_get_return_code(aapl);
    if( ret < 0 )
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "found aapl->return_code negative (%d) implying a prior error; value cleared\n",ret);

/* Check for supported process and slice types: */

    if( !(   aapl_check_process(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28)
          && aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1)) )
    {
        return -1;
    }

    /* If pre-0x1049 firmware revision, must have a xx4x build: */
    if( !aapl_check_firmware_rev(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, 0x1049) )
    {
        uint build_id = avago_firmware_get_build_id(aapl, sbus_addr);
        if( 0 == (build_id & 0x0040) )
            return aapl_fail(aapl, __func__, __LINE__,
                "SBus %s, Escope requires a _xx4x build in pre-0x1049 firmware, current is 0x%04x_%04x\n",
                aapl_addr_to_str(sbus_addr), aapl_get_firmware_rev(aapl, sbus_addr), build_id);
    }

    {
        BOOL tx_ready = 0, rx_ready = 0;
        if( avago_serdes_get_tx_rx_ready(aapl, sbus_addr, &tx_ready, &rx_ready) != 0 || !rx_ready )
            return aapl_fail(aapl, __func__, __LINE__,
                "SBus %s, Escope measurement requires that the Rx be enabled and ready.\n", aapl_addr_to_str(sbus_addr));
    }

    {
        Avago_serdes_rx_clocks_t clocks;
        avago_serdes_rx_clock_read(aapl, sbus_addr, &clocks);
        if( clocks.data == AVAGO_SERDES_RX_CLOCK_R || clocks.edge == AVAGO_SERDES_RX_CLOCK_R || clocks.dfe == AVAGO_SERDES_RX_CLOCK_R )
            return aapl_fail(aapl, __func__,__LINE__,"Cannot run eScope when rclk is used for data or edge detection.\n");
    }
    if( aapl_get_ip_type(aapl,sbus_addr) == AVAGO_M4 && aapl_check_firmware_rev(aapl,sbus_addr, __func__, __LINE__, FALSE, 1, 0x1071) && avago_serdes_get_rx_input_loopback(aapl,sbus_addr) )
        return aapl_fail(aapl, __func__,__LINE__,"Cannot run eScope on CM4 in ILB mode with firmware >= 0x1071.\n");

    /* Save DFE state and pause DFE tuning, then wait on any in progress tune: */
    if( avago_serdes_dfe_pause(aapl, sbus_addr, &dfe_resume_status) < 0 &&
        avago_serdes_dfe_wait(aapl, sbus_addr) == 0 )
    {
        return aapl_fail(aapl,__func__,__LINE__,"Escope coordination with running DFE failed.\n");
    }

    /* Only restore low power mode if was in low power mode before escope capture. */
    restore_low_power_mode = avago_serdes_enable_low_power_mode(aapl, sbus_addr, FALSE);

/* The phase multiplier is a power of 2, in range 1 to 32: */
/* 64 times this value is the number of real phase interpolator steps per eye. */

    max_resolution = avago_serdes_get_phase_multiplier(aapl, sbus_addr) * 64;
    if( max_resolution < 0 )
        return -1;

/* Get the current SerDes phase interpolator setting, treated as the eye */
/* center, which is always in the range 0..127 (7 AVAGO_LSB only), as a basis for */
/* later stepping. */

    orig_cmp_mode = avago_serdes_get_rx_cmp_mode(aapl, sbus_addr);
    orig_cmp_data = avago_serdes_get_rx_cmp_data(aapl, sbus_addr);
    orig_data_qual = avago_serdes_get_rx_data_qual(aapl, sbus_addr);
    original_phase = avago_serdes_get_phase(aapl, sbus_addr);

    if( aapl_get_ip_type(aapl, sbus_addr) == AVAGO_P1 )
    {
        phase_center = avago_serdes_get_phase(aapl, sbus_addr);
    }
    else
    {
        phase_center = max_resolution / 2;
        if( configp->sc_set_phase_center )
            phase_center = avago_serdes_find_phase_center(aapl, sbus_addr, &datap->sd_phase_center_log);
    }

    datap->sd_hardware_log = avago_hardware_info_format(aapl, sbus_addr);
    avago_serdes_get_dfe_state(aapl, sbus_addr, &datap->sd_dfe_state);

    /* Create escope state to reuse for optimizing calls to SerDes: */
    esp->current_phase = avago_serdes_get_phase(aapl, sbus_addr);
    esp->left_phase = phase_center - max_resolution / 2;

    /* We read the base value here so that, in the inner loop, */
    /*   we only need to write, instead of doing a slow read-modify-write. */
    esp->base_compare_register = avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_LSB, (aapl_get_sdrev(aapl,sbus_addr) == AAPL_SDREV_P1) ? 0x00e1 : 0x0017);
    datap->sd_bits_per_ui  = avago_serdes_get_rx_line_encoding(aapl,sbus_addr) ? 2 : 1;
    esp->syms_per_heartbeat = avago_serdes_get_rx_register_clock(aapl, sbus_addr);
    esp->ui_window_width = esp->syms_per_heartbeat * (80/datap->sd_bits_per_ui/esp->syms_per_heartbeat);
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "sd_bits_per_ui = %d; syms_per_heartbeat = %d; ui_window_width = %d\n", datap->sd_bits_per_ui, esp->syms_per_heartbeat, esp->ui_window_width);

/* Validate and initialize the sd_x_* and sd_y_* values: */

#   define MIN_RESOLUTION 8
    res = max_resolution;  /* Always a power of 2 */
    while( configp->sc_x_resolution < res && res > MIN_RESOLUTION )
        res /= 2;

    if( configp->sc_flags & 4 ) /* 4x gather for P1 */
    {
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "SBus %s, Experimental option 4: hw_res %d.\n", aapl_addr_to_str(sbus_addr), max_resolution);
        max_resolution *= 4;
        res *= 4;
    }
    if( configp->sc_flags & 1 )
    {
        int tx_width, rx_width;
        avago_serdes_get_tx_rx_width(aapl, sbus_addr, &tx_width, &rx_width);
        esp->left_phase -= (max_resolution + rx_width) / 4 + 2;
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "SBus %s, Experimental option 1: hw_res %d; rx_width %d; shift %d steps.\n", aapl_addr_to_str(sbus_addr), max_resolution, rx_width, esp->left_phase);
        max_resolution *= 2;
        res *= 2;
    }

    datap->sd_flags             = configp->sc_flags;
    datap->sd_x_pattern_length  = configp->sc_x_pattern_length;
    datap->sd_x_UI              = configp->sc_x_UI; /* UI to capture */
    datap->sd_x_resolution      = res; /* Set to power of 2 <= requested resolution */
    datap->sd_x_points          = configp->sc_x_UI * res;   /* Total points */
    datap->sd_x_step            = max_resolution / res;
    datap->sd_x_min             = esp->left_phase;

    datap->sd_y_step       = MIN(16,configp->sc_y_step_size);
    datap->sd_y_center     = avago_serdes_get_dac_range(aapl, sbus_addr) / 2;
    datap->sd_y_points     = datap->sd_y_center / datap->sd_y_step + (datap->sd_y_center-1) / datap->sd_y_step + 1;
    datap->sd_read_count   = configp->sc_read_count;

    datap->sd_datapath_flags = 0;
    {
        Avago_serdes_datapath_t datapath;
        avago_serdes_get_rx_datapath(aapl, sbus_addr, &datapath);
        if( datapath.polarity_invert ) datap->sd_datapath_flags |= 1;
        if( datapath.gray_enable     ) datap->sd_datapath_flags |= 2;
        if( datapath.precode_enable  ) datap->sd_datapath_flags |= 4;
        if( datapath.swizzle_enable  ) datap->sd_datapath_flags |= 8;
    }

    if( allocate_escope_arrays(aapl, datap) < 0 )
        return -1;

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "SBus %s, x_UI,pat_len,points,res,step = %u,%u,%u,%u,%u; y_points,step = %u,%u.\n", aapl_addr_to_str(sbus_addr), datap->sd_x_UI, datap->sd_x_pattern_length, datap->sd_x_points, datap->sd_x_resolution, datap->sd_x_step, datap->sd_y_points, datap->sd_y_step);


    avago_meas_setup_heartbeat(aapl, sbus_addr, datap->sd_x_pattern_length, TRUE);
    avago_serdes_set_rx_test_chan_rclk(aapl, sbus_addr, TRUE);    /* Setup test clock */
    capture(aapl, sbus_addr, esp, datap);

    if( configp->sc_flags & 4 ) /* 4x gather for P1 */
    {
        uint i;
        /* Data is in datap->sd_waveform, but needs to be distributed into 4 bins. */
        datap->sd_x_resolution /= 4;
        datap->sd_x_points     /= 4;
        datap->sd_waveform->x_points     = datap->sd_x_points;      /* reduce scale on existing waveform */
        datap->sd_waveform->x_resolution = datap->sd_x_resolution;

        datap->sd_waveform2 = escope_waveform_construct(aapl, datap);
        datap->sd_waveform3 = escope_waveform_construct(aapl, datap);
        datap->sd_waveform4 = escope_waveform_construct(aapl, datap);

        for( i = 0; i < datap->sd_x_UI; i++ )
        {
            uint j;
            Avago_waveform_t *wave = datap->sd_waveform;
            uint from = datap->sd_x_resolution * 4 * i;
            uint to   = datap->sd_x_resolution * 4 * (i/4);
            switch( i & 3 )
            {
            case 0: wave = datap->sd_waveform ; break;
            case 1: wave = datap->sd_waveform2; break;
            case 2: wave = datap->sd_waveform3; break;
            case 3: wave = datap->sd_waveform4; break;
            }

            for( j = 0; j < datap->sd_x_resolution * 4; j++ )
            {
                wave->points[to+j].dac_mean   = datap->sd_waveform->points[from+j].dac_mean;
                wave->points[to+j].dac_stddev = datap->sd_waveform->points[from+j].dac_stddev;
            }
        }
    }

    /* Restore state: (as best we can): */
    avago_serdes_set_rx_cmp_data(aapl, sbus_addr, orig_cmp_data);
    avago_serdes_set_rx_data_qual(aapl, sbus_addr, orig_data_qual);
    avago_serdes_set_dac(aapl, sbus_addr, datap->sd_y_center, FALSE);
    avago_serdes_step_phase(aapl, sbus_addr, original_phase, &esp->current_phase, FALSE);
    avago_serdes_set_rx_test_chan_rclk(aapl, sbus_addr, FALSE);   /* Setup mission clock */
    avago_serdes_set_rx_data_qual(aapl, sbus_addr, AVAGO_SERDES_RX_DATA_QUAL_UNLOCK);

    avago_serdes_set_rx_cmp_mode(aapl, sbus_addr, orig_cmp_mode);
    avago_serdes_get_errors(aapl, sbus_addr, AVAGO_LSB, TRUE);   /* Reset the error counter */

    if( restore_low_power_mode )
        avago_serdes_enable_low_power_mode(aapl, sbus_addr, TRUE);
    avago_serdes_power_down_phase_interpolator(aapl, sbus_addr); /* Always */

    /* Restore DFE tuning to previous state: */
    avago_serdes_dfe_resume(aapl, sbus_addr, dfe_resume_status);

    return aapl->return_code == 0 ? 0 : -1;

} /* End of serdes_escope_get */

/** @brief   Extracts the pulse and error responses from the measured PRBS signal. */
/** @details If error_response is NULL, it will be skipped. */
/** @return  Returns TRUE and fills in the pulse and error response waveforms on success, returns FALSE on failure. */
static BOOL avago_serdes_escope_extract_pulse_response_wave(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    Avago_waveform_t *waveform,         /**< [in] Waveform input */
    int pulse_ui,                       /**< [in] Total UI of pulse response output */
    int delay,                          /**< [in] UI before pulse will start */
    Avago_waveform_t **pulse_response,  /**< [out] Calculated pulse response. */
    Avago_waveform_t **error_response)  /**< [out] Calculated error response. */
{
    /* Tasks: */
    /*  1. Extract input PRBS pattern from pattern-length and data (add to waveform). */
    uint i;
    uint ui    = waveform->x_points / waveform->x_resolution;
    uint nbits = ui * waveform->bits_per_ui;
    uint len   = nbits + 1;
    char *prbs = (char *)AAPL_MALLOC(len);
    BOOL ret = avago_extract_prbs(waveform, TRUE, len, prbs);
    Avago_matrix_t *X = NULL; /* Really X1 */
    Avago_matrix_t *Y = NULL;
    Avago_matrix_t *P = NULL;

    if( !ret )
    {
        aapl_log_printf(aapl, AVAGO_WARNING, 0, 0, "ERROR: PRBS pattern not detected, cannot extract pulse response.\n");
        AAPL_FREE(prbs);
        return FALSE;
    }
    avago_escope_waveform_destruct(aapl, *pulse_response);
    *pulse_response = escope_pulsewave_construct(aapl, waveform, pulse_ui);
    if( !*pulse_response )
    {
        AAPL_FREE(prbs);
        return FALSE;
    }
    if( error_response )
    {
        avago_escope_waveform_destruct(aapl, *error_response);
        *error_response = escope_pulsewave_construct(aapl, waveform, pulse_ui);
        if( !*error_response )
        {
            AAPL_FREE(prbs);
            avago_escope_waveform_destruct(aapl, *pulse_response);
            *pulse_response = 0;
            return FALSE;
        }
        (*error_response)->bits_per_ui = 0;    /* Always */
        (*error_response)->y_step = 1;
    }

    (*pulse_response)->bits_per_ui = 0;    /* Always */

    /* Convert the PRBS '0'/'1' output pattern to DAC levels. */
    /* Note: For PAM output, prbs is twice the length of sd_x_UI: */
    for( i = 0; i < ui; i++ )
    {
        if( waveform->bits_per_ui == 2 )
            prbs[i] = prbs[2*i] - '0' + (prbs[2*i+1] - '0') * 2;
        else
            prbs[i] -= '0';
    }

    /*  2. Generate matrixes. */
    /*      prbs -> N x N matrix "X" */
    /*      sd_waveform -> M x N matrix "Y" with measured DAC values */

    /* Construct and load the X1 matrix from the PRBS input pattern: */
    {
        int r;

        X = avago_matrix_construct(pulse_ui + 1, ui);

        for( r = 0; r < X->nrows; r++ )
        {
            int c;
            for( c = 0; c < X->ncols; c++ )
            {
                if( waveform->bits_per_ui == 2 )
                    X->matrix[r][c] = (prbs[(ui + delay - r + c) % ui] * 2 - 3) / 3.0;
                else
                    X->matrix[r][c] = (prbs[(ui + delay - r + c) % ui] * 2 - 1);
            }
            /* Last row is all ones: */
            for( c = 0; c < X->ncols; c++ )
                X->matrix[pulse_ui][c] = 1.0;
        }
    }
    AAPL_FREE(prbs);
  /*printf("X Matrix:\n"); avago_matrix_print(stdout, X); */

    /* Construct and load the Y matrix from the escope data: */
    {
        int c, w = 0;

        Y = avago_matrix_construct(waveform->x_resolution, ui);

        for( c = 0; c < Y->ncols; c++ )
        {
            int r;
            for( r = 0; r < Y->nrows; r++ )
            {
                double value = waveform->points[w++].dac_mean;
                Y->matrix[r][c] = value;
            }
        }
    }
  /*printf("Y Matrix:\n"); avago_matrix_print(stdout, Y); */


    /*  3. Calculate */
    /*      P = Y * Xt * inv( X * Xt )  # Pulse response */
    /*      E = P * X - Y               # Difference from theory */

    {
        Avago_matrix_t *Xt = avago_matrix_transpose(X);
        Avago_matrix_t *YXt;
        Avago_matrix_t *XXtI;

        /*printf("Xt Matrix:\n"); avago_matrix_print(stdout, Xt); */

        YXt = avago_matrix_multiply(Y, Xt);
        /*printf("Y*Xt Matrix:\n"); avago_matrix_print(stdout, YXt); */
        avago_matrix_destruct(Xt);

        XXtI = avago_matrix_construct_prbs_inverse(pulse_ui + 1, ui, waveform->bits_per_ui);
        /*printf("Inv(X*Xt) Matrix:\n"); avago_matrix_print(stdout, XXtI); */

        P = avago_matrix_multiply(YXt, XXtI);
        avago_matrix_destruct(XXtI);
        avago_matrix_destruct(YXt);
        if( P )
        {
            /* Save pulse response matrix to pulse waveform. */
            int r, c;
            uint w = 0;
            /*printf("P Matrix:\n"); avago_matrix_print(stdout, P); */
            for( c = 0; c < P->ncols-1; c++ )   /*  Ignore extra "ones" column */
            for( r = 0; r < P->nrows; r++ )
                (*pulse_response)->points[w++].dac_mean = P->matrix[r][c];
        }
    }

    if( P && error_response )
    {
        Avago_matrix_t *E;
        Avago_matrix_t *PX = avago_matrix_multiply(P, X);
        /* printf("PX Matrix:\n"); avago_matrix_print(stdout, PX); */

        E = avago_matrix_subtract(PX, Y);
        avago_matrix_destruct(PX);
        if( E )
        {
            /* Save error response matrix to error waveform. */
            int r, c;
            uint w = 0;
            /*printf("E Matrix:\n"); avago_matrix_print(stdout, E); */
            for( c = 0; c < E->ncols-1; c++ )   /*  Ignore extra "ones" column */
            for( r = 0; r < E->nrows; r++ )
                (*error_response)->points[w++].dac_mean = E->matrix[r][c];
            avago_matrix_destruct(E);
        }
    }
    avago_matrix_destruct(P);
    avago_matrix_destruct(Y);
    avago_matrix_destruct(X);
    return TRUE;
}

static void get_pulse_response(Aapl_t *aapl, Avago_waveform_t *wave, int width, int delay, Avago_waveform_t **pulse, Avago_waveform_t **error)
{
    if( wave )
        avago_serdes_escope_extract_pulse_response_wave(aapl, wave, width, delay, pulse, error);
}
/** @brief   Calculates the pulse response for each available waveform. */
/** @details Analyzes the datap->sd_waveform* fields in datap, and calculates */
/**          the pulse response waveforms for any full-length PRBS captures. */
/** @return  Stores outputs into the datap->sd_pulse* structures and returns 0. */
int avago_serdes_escope_extract_pulse_response(
    Aapl_t *aapl,                      /**< [in] Pointer to Aapl_t structure. */
    Avago_serdes_escope_data_t *datap, /**< [in,out] Input and output waveforms. */
    int pulse_width,                   /**< [in] How many UI of pulse to calculate. */
    int delay)                         /**< [in] How many UI to place before the pulse. */
{
    get_pulse_response(aapl, datap->sd_waveform , pulse_width, delay, &datap->sd_pulse , NULL);
    get_pulse_response(aapl, datap->sd_waveform2, pulse_width, delay, &datap->sd_pulse2, NULL);
    get_pulse_response(aapl, datap->sd_waveform3, pulse_width, delay, &datap->sd_pulse3, NULL);
    get_pulse_response(aapl, datap->sd_waveform4, pulse_width, delay, &datap->sd_pulse4, NULL);
    return 0;
}


#if AAPL_ENABLE_FILE_IO
/** @brief Writes the raw escope data to a file stream. */
void avago_serdes_escope_dump_raw_data(
    FILE *file,                                 /**< where to write the data */
    const Avago_serdes_escope_data_t *datap)    /**< data to write */
{
    fprintf(file,"# UI.phase, DAC, val\n");
    if( datap->sd_onesp )
    {
        uint x;
        for( x = 0; x < datap->sd_x_points; x++ )
        {
            uint y;
            for( y = 0; y < datap->sd_y_points; y++ )
                fprintf(file, "%f, %u, %d\n",
                    (float)x / datap->sd_x_resolution, y,
                    AVAGO_ESCOPE_ONES_GET(*datap,x,y));
        }
    }
}

static void avago_serdes_escope_write_waveform_data(
    FILE *file,                   /**< [in] Where to write the data. */
    const char *label,            /**< [in] Waveform description. */
    const Avago_waveform_t *wave) /**< [in] Data to write. */
{
    if( wave )
    {
        uint x;
        fprintf(file,"\n");
        if( label ) fprintf(file,"# %s\n",label);
        fprintf(file,"# UI.phase, DAC mean, DAC standard deviation\n");
        for( x = 0; x < wave->x_points; x++ )
            fprintf(file, "%f, %6.2f, %6.2f\n",
                (float)x / wave->x_resolution,
                wave->points[x].dac_mean,
                wave->points[x].dac_stddev);
    }
}

/** @brief Writes escope data and meta data to a FILE stream. */
/** */
/** @return void. */

void avago_serdes_escope_write_data(
    FILE *file,                         /**< [in] Where to write the data. */
    const Avago_serdes_escope_data_t *datap)    /**< [in] Data to write. */
{
    char time_str[40];
    aapl_local_strftime(time_str,sizeof(time_str),"%Y-%m-%d %H:%M:%S");

    fprintf(file,"# ESCOPE DATA\n");
    fprintf(file,"\n");
    fprintf(file,"file_format:    1\n");
    fprintf(file,"AAPL_version:   " AAPL_VERSION ", compiled %s %s\n",__DATE__,__TIME__);
    fprintf(file,"capture_date:   %s\n", time_str);
    if( datap->sd_comment )
        fprintf(file,"user_comment:   %s\n",datap->sd_comment);
    fprintf(file,"\n");

    if( datap->sd_hardware_log )
        fprintf(file,"%s\n", datap->sd_hardware_log);

    fprintf(file,"x.pattern_length: %5d\n",datap->sd_x_pattern_length);
    fprintf(file,"x.UI:             %5d\n",datap->sd_x_UI);
    fprintf(file,"x.resolution:     %5d\n",datap->sd_x_resolution);
    fprintf(file,"x.points:         %5d\n",datap->sd_x_points);
    fprintf(file,"x.min:            %5d\n",datap->sd_x_min);
    fprintf(file,"x.max:            %5d\n",datap->sd_x_min + datap->sd_x_resolution * datap->sd_x_step);
    fprintf(file,"x.step:           %5d\n",datap->sd_x_step);
    fprintf(file,"x.center:         %5d\n",datap->sd_x_min + (datap->sd_x_resolution * datap->sd_x_step)/2);

    fprintf(file,"y.points:         %5d\n",datap->sd_y_points);
    fprintf(file,"y.step:           %5d\n",datap->sd_y_step);
    fprintf(file,"y.center:         %5d\n",datap->sd_y_center);

    fprintf(file,"flags:            %5d\n",datap->sd_flags);
    fprintf(file,"datapath_flags:    0x%02x # [3] swizzle; [2] precode; [1] gray; [0] invert\n",datap->sd_datapath_flags);
    fprintf(file,"read_count:       %5d\n",datap->sd_read_count);
    fprintf(file,"bits_per_ui:      %5d\n",datap->sd_bits_per_ui);
    fprintf(file,"\n");
    if( datap->sd_phase_center_log )
        fprintf(file,"center_data:  %s\n\n", datap->sd_phase_center_log);

    fprintf(file,"\n");
    avago_write_dfe_state(file, &datap->sd_dfe_state);

    avago_serdes_escope_write_waveform_data(file,"Escope waveform:"               ,datap->sd_waveform);
    avago_serdes_escope_write_waveform_data(file,"Escope waveform from sampler 2:",datap->sd_waveform2);
    avago_serdes_escope_write_waveform_data(file,"Escope waveform from sampler 3:",datap->sd_waveform3);
    avago_serdes_escope_write_waveform_data(file,"Escope waveform from sampler 4:",datap->sd_waveform4);
    avago_serdes_escope_write_waveform_data(file,"Pulse waveform:"               ,datap->sd_pulse);
    avago_serdes_escope_write_waveform_data(file,"Pulse waveform from sampler 2:",datap->sd_pulse2);
    avago_serdes_escope_write_waveform_data(file,"Pulse waveform from sampler 3:",datap->sd_pulse3);
    avago_serdes_escope_write_waveform_data(file,"Pulse waveform from sampler 4:",datap->sd_pulse4);
}


/** @brief Writes escope data to a file. */
/** */
/** @return TRUE if file written successfully, FALSE otherwise. */

BOOL avago_serdes_escope_write_file(
    const char *write_file_name,        /**< Filename to write the data. */
    const Avago_serdes_escope_data_t *datap)    /**< Data to write. */
{
    FILE *fp = fopen(write_file_name,"w");
    if( fp )
    {
        avago_serdes_escope_write_data(fp, datap);
        return 0 == fclose(fp);
    }
    return FALSE;
}

/** @brief   Reads a name and value from buf. */
/** @details Buf contains a name value pair separated by white space */
/**          and an equals sign.  Locate and nul terminate the name, and */
/**          store the value into *value. */
/**          Comments (starting with a '#') and extra fields are ignored. */
/** @return  The number of fields found: 0 for blank or comment lines, 1 for */
/**          only a name, 2 for name and value. */
static int get_name_value_pair(
    char *buf,              /**< [in] Line to parse. */
    char **name,            /**< [out] Pointer to name in buf. */
    char **value_string,    /**< [out] Pointer to value string in buf. */
    bigint *value)          /**< [out] Pointer to value. */
{
    const char *seps = ": \t\r\n=";
    char *ptr;
    *value = 0;
    buf += strspn(buf,seps);        /* Skip separators */
    if( *buf == '\0' ) return 0;

    *name = buf;
    buf += strcspn(buf,seps);       /* Skip over name */
    if( *buf == '\0' ) return 1;
    *buf++ = '\0';

    buf += strspn(buf,seps+1);        /* Skip separators */
    if( *buf == '#' || *buf == '\0' ) return 1;

    *value_string = buf;
    *value = aapl_strtol(*value_string,&ptr,0);    /* Parse value */
    buf += strcspn(buf,"\r\n");       /* Skip over value */
    *buf = '\0';

    if( **name == '#' ) return 0;
    return 2;
}

static int split(char *line, const char *delim, char *argv[], int argv_length)
{
    int argc = 0;
    char *tok_state;
    argv[argc] = aapl_strtok_r(line,delim,&tok_state);
    while( argv[argc] && ++argc < argv_length )
        argv[argc] = aapl_strtok_r(NULL,delim,&tok_state);
    return argc;
}

#define EQS(str1,str2) (0==strcmp(str1,str2))

/** @brief   Loads escope data from a file. */
/** @details Does not require AAPL connection to any hardware. */
/** @return  Returns TRUE on success. */
/** @return  Returns FALSE on error, and logs specific problem. */
BOOL avago_serdes_escope_read_file(
    Aapl_t *aapl,                      /**< Pointer to Aapl_t structure. */
    const char *filename,              /**< name of file containing eye data */
    Avago_serdes_escope_data_t *datap) /**< [out] escope data structure to fill in. */
{
    char line[4096];
    int linenum = 0;
    FILE *file = fopen(filename,"r");
    BOOL in_header = TRUE;
    float fudge = 0.001;

    Avago_waveform_t *wave = 0;
    int file_format = 0;
    char *ptr = datap->sd_hardware_log = (char *)aapl_malloc(aapl,300,__func__);
    *ptr = '\0';

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "%s\n",filename);

    if( !file )
        return aapl_fail(aapl, __func__, __LINE__, "ERROR opening file %s\n",filename), FALSE;

    /* Parse file contents for various fields: */
    /* */
    while( fgets(line, sizeof(line), file) )
    {
        linenum++;

        if( in_header )
        {
            char *name = 0, *str_val = 0;
            bigint value;
            int count = get_name_value_pair(line,&name,&str_val,&value);

            if( count > 1 || (name && (*name == '#')) )
                aapl_log_printf(aapl,AVAGO_DEBUG4,__func__,__LINE__,"count=%d, name=\"%s\", str_val=\"%s\", value=%ld\n",count,name,str_val,value);

            if( count == 0 && str_val && 0 == strncmp(str_val,"UI.phase,", 9) )
            {
                allocate_escope_arrays(aapl, datap);
                wave = datap->sd_waveform;
                fudge = 0.5 / datap->sd_x_resolution;
                in_header = FALSE;
            }
            if( count != 2 ) continue;  /* blank or comment lines */

/*          else if( EQS(name,"capture_date"    ) ) time_str); */

            if(      EQS(name,"file_format"     ) ) file_format = value;

            else if( EQS(name,"x.UI"            ) ) datap->sd_x_UI = value;
            else if( EQS(name,"x.pattern_length") ) datap->sd_x_pattern_length = value;
            else if( EQS(name,"x.points"        ) ) datap->sd_x_points = value;
            else if( EQS(name,"x.step"          ) ) datap->sd_x_step = value;
            else if( EQS(name,"x.resolution"    ) ) datap->sd_x_resolution = value;
            else if( EQS(name,"x.min"           ) ) datap->sd_x_min = value;

            else if( EQS(name,"y.points"        ) ) datap->sd_y_points = value;
            else if( EQS(name,"y.step"          ) ) datap->sd_y_step = value;
            else if( EQS(name,"y.center"        ) ) datap->sd_y_center = value;

            else if( EQS(name,"flags"           ) ) datap->sd_flags = value;
            else if( EQS(name,"datapath_flags"  ) ) datap->sd_datapath_flags = value;
            else if( EQS(name,"read_count"      ) ) datap->sd_read_count = value;
            else if( EQS(name,"bits_per_ui"     ) ) datap->sd_bits_per_ui = value;

            else if( EQS(name,"center_data"     ) ) datap->sd_phase_center_log = aapl_strdup(str_val);
            else if( 0==strncmp(name,"dfe.",4   ) ) avago_update_dfe_field(&datap->sd_dfe_state, name, value, str_val);
            else if( EQS(name,"user_comment"    ) ) datap->sd_comment = aapl_strdup(str_val);

            else if( EQS(name,"SBus_address"    ) ) ptr += sprintf(ptr,"%s:%*s%s\n",name,(int)(15-strlen(name))," ",str_val);
            else if( EQS(name,"JTAG_ID"         ) ) ptr += sprintf(ptr,"%s:%*s%s\n",name,(int)(15-strlen(name))," ",str_val);
            else if( EQS(name,"Process_ID"      ) ) ptr += sprintf(ptr,"%s:%*s%s\n",name,(int)(15-strlen(name))," ",str_val);
            else if( EQS(name,"SBus_master"     ) ) ptr += sprintf(ptr,"%s:%*s%s\n",name,(int)(15-strlen(name))," ",str_val);
            else if( EQS(name,"SerDes"          ) ) ptr += sprintf(ptr,"%s:%*s%s\n",name,(int)(15-strlen(name))," ",str_val);

            else if( file_format == 0 ) continue;   /* No op statement to satisfy checkers. */

        }
        else /* In data: */
        {
            char *argv[6];
            int argc = split(line, " ,", argv, AAPL_ARRAY_LENGTH(argv));
            if( argc >= 3 && argv[0][0] != '#' )
            {
                uint x;
                float position, dac_mean, dac_stddev;
                sscanf(argv[0], "%12f", &position);
                sscanf(argv[1], "%12f", &dac_mean);
                sscanf(argv[2], "%12f", &dac_stddev);

                /* "fudge" compensates for rounding errors on output: */
                x = position * datap->sd_x_resolution + fudge;
                if( x < wave->x_points )
                {
                    wave->points[x].dac_mean = dac_mean;
                    wave->points[x].dac_stddev = dac_stddev;
                }
            }
            /* "# Escope waveform from sampler #:" */
            else if( argc > 5 && argv[0][0] == '#' && 0 == strcmp(argv[4],"sampler") )
            {
                switch( argv[5][0] )
                {
                case '2': wave = datap->sd_waveform2 = escope_waveform_construct(aapl, datap); break;
                case '3': wave = datap->sd_waveform3 = escope_waveform_construct(aapl, datap); break;
                case '4': wave = datap->sd_waveform4 = escope_waveform_construct(aapl, datap); break;
                }
            }
            else if( argc >= 3 && argv[0][0] == '#' && 0 == strcmp(argv[1],"Pulse") )
                break;  /* Skip reading the rest of the file */
        }
    }

    return fclose(file) == 0;
}
#endif

#endif /* AAPL_ENABLE_ESCOPE_MEASUREMENT */
