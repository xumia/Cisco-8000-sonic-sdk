/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* MAIN program for the escope command. */
/* */

/** Doxygen File Header */
/** @file */
/** @brief Launch wrapper for eSCOPE function. */


#include "aapl.h"

#if AAPL_ENABLE_MAIN && AAPL_ENABLE_ESCOPE_MEASUREMENT

/*============================================================================= */
/* ESCOPE_MAIN */

static int show_escope_help()
{
    aapl_common_main_help(TRUE);
    printf(
"-set-phase-center <0|1>   Disable/enable waveform centering; default = 1.\n"
"-pattern-length <int>     Length of the repeating pattern to be measured.\n"
"-x-UI <int>               Number of UI (bits) to read from the pattern.\n"
"                            May be larger than pattern-length.\n"
"-x-resolution <int>       Points to gather per UI; default = 64; min = 8.\n"
"                            Value is rounded down to the nearest power of 2.\n"
);

    printf(
"-y-step-size <int>        Set DAC scan resolution; default = 1.\n"
"-max-dwell <int>          Maximum number of times to read each point; default = 1.\n"
"-print-ascii-wave         Write ascii escope waveform to stdout.\n"
"-print-ascii-eye          Write ascii overlay of waveform to stdout.\n"
"-print-raw-data           Write raw escope data to stdout.\n"
"-ascii-y-points           Height of ascii plot output; default = 33 lines.\n"
);

    printf(
"-read-file <escope.txt>   Read an escope data file.\n"
"-write-file <filename>    Write an escope data file.\n"
"-comment <string>         Add comment string to the escope data file.\n"
);
    printf(
"\n"
"-print-pulse-wave         Selects and displays pulse response.\n"
"-pulse                    Output impulse response waveform.\n"
"                            Forces x-UI to match pattern-length.\n"
"-pulse-delay <delay>      Select UI of delay before pulse.\n"
"-pulse-UI <ui>            Select total UI of pulse output.\n"
);
    return 1;
}

#if AAPL_ENABLE_FILE_IO
static void print_wave(Aapl_t *aapl, const char *label, Avago_waveform_t *wave, uint ascii_y_points)
{
    if( wave )
    {
        int flags = wave->datapath_flags;
        Avago_plot_t *plot = avago_plot_construct(aapl, wave->x_points, ascii_y_points);
        fprintf(stdout,"# %s (%d x %d):\n",label,plot->x_points,plot->y_points);
        fprintf(stdout,"Data decoding: %s%s%s%s%s\n", flags&8?" swizzle":"", flags&2?" gray":"", flags&1 ? " invert" : "", flags &4 ? " precode" : "", flags==0?"normal":"");
        avago_plot_ascii_waveform(plot, wave);
        avago_plot_print_ascii(stdout, plot);
        avago_plot_destruct(aapl, plot);
    }
}
#endif /* AAPL_ENABLE_FILE_IO */

/* Main program for a standalone escope program, instead of a library call on a */
/* pre-existing process/thread.  Exits with 0 for success or 1 for error. */

int aapl_escope_main(int argc, char ** argv, Aapl_t *aapl)
{
/* Prepare AAPL API: */

    Avago_serdes_escope_config_t *configp = 0;
    Avago_serdes_escope_data_t   *datap   = 0;

/* Parse options: */

    uint        addr;
    Avago_addr_t addr_struct;
    int         rc, index = 0;
    uint        ascii_y_points = 33;
    BOOL        print_ascii_wave = 0;
    BOOL        print_pulse_wave = 0;
    BOOL        print_ascii_eye = 0;
    BOOL        print_raw_data = 0;
    const char *read_file_name = 0;
    const char *write_file_name = 0;
    BOOL        have_user_option = FALSE;
    int         pulse_delay = 3;
    int         pulse_width = 20;
    BOOL        get_pulse_response = FALSE;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"read-file",        1, NULL, 'F'},  /* <escope data file name> */
        {"write-file",       1, NULL, 'w'},  /* <escope data file name> */
        {"set-phase-center", 1, NULL, 'c'},  /* sc_set_phase_center. */
        {"pattern-length",   1, NULL, 'l'},  /* sc_x_pattern_length */
        {"max-dwell",        1, NULL, 'N'},  /* sc_read_count = accumulation count */
        {"x-UI",             1, NULL, 'x'},  /* sc_x_UI = bits to capture */
        {"x-resolution",     1, NULL, 'X'},  /* sc_x_resolution. */
        {"y-step-size",      1, NULL, 'z'},  /* sc_y_step_size. */
        {"print-ascii-wave", 0, NULL, 'A'},  /* print_ascii_wave */
        {"print-ascii-eye",  0, NULL, 'E'},  /* print_ascii_eye */
        {"print-raw-data",   0, NULL, 'R'},  /* print_raw_data */
        {"ascii-y-points",   1, NULL, 'Y'},  /* vertical points in ascii output */
        {"comment",          1, NULL, 'C'},  /* Add comment to escope data file. */
        {"exp",              1, NULL,  1 },  /* Experimental options */
        {"pulse-delay",      1, NULL,  2 },  /* Set pulse delay in UI */
        {"pulse-UI",         1, NULL,  3 },  /* Set pulse width in UI */
        {"pulse",            0, NULL,  4 },  /* Calculate pulse response */
        {"print-pulse-wave", 0, NULL,  5 },  /* Print pulse response wave */
        {NULL,               0, NULL, 0  }   /* sentinel entry. */
    };

    avago_addr_to_struct(aapl_default_device_addr, &addr_struct);
    if( aapl_common_main_options(aapl, argc, argv, &addr_struct) < 0 )
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_escope_help();
    }
    addr = avago_struct_to_addr(&addr_struct);

    if( aapl->return_code < 0 ) return 1;  /* EXIT, assume anomalies already reported. */

    configp = avago_serdes_escope_config_construct(aapl);
    datap   = avago_serdes_escope_data_construct(  aapl);

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        have_user_option = TRUE;
        switch (rc)
        {
        case 1  : configp->sc_flags            = aapl_num_from_str( optarg, name, 0); break;
        case 'c': configp->sc_set_phase_center = aapl_bool_from_str(optarg, name);    break;
        case 'l': configp->sc_x_pattern_length = aapl_num_from_str( optarg, name, 0); break;
        case 'N': configp->sc_read_count       = aapl_num_from_str( optarg, name, 0); break;
        case 'x': configp->sc_x_UI             = aapl_num_from_str( optarg, name, 0); break;
        case 'X': configp->sc_x_resolution     = aapl_num_from_str( optarg, name, 0); break;
        case 'z': configp->sc_y_step_size      = aapl_num_from_str( optarg, name, 0); break;
        case 'Y': ascii_y_points               = aapl_num_from_str( optarg, name, 0); break;
        case  2 : pulse_delay                  = aapl_num_from_str( optarg, name, 0); break;
        case  3 : pulse_width                  = aapl_num_from_str( optarg, name, 0); break;
        case  4 : get_pulse_response = 1;                                             break;
        case  5 : get_pulse_response = 1; print_pulse_wave = TRUE;                    break;
        case 'C': datap->sd_comment = optarg; break;
        case 'w': write_file_name = optarg; break;
        case 'F': read_file_name = optarg; break;
        case 'A': print_ascii_wave = TRUE; break;
        case 'E': print_ascii_eye = TRUE; break;
        case 'R': print_raw_data = TRUE; break;

        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    if( !have_user_option )
    {
        avago_serdes_escope_data_destruct(  aapl, datap);
        avago_serdes_escope_config_destruct(aapl, configp);
        avago_addr_delete(aapl, &addr_struct);
        return show_escope_help();
    }

    if( get_pulse_response )
        configp->sc_x_UI = configp->sc_x_pattern_length;

/* No args are allowed beyond options: */

    if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    if( !read_file_name )
    {
        aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) return 1; /* EXIT */
        aapl_get_ip_info(aapl,0);
    }

    if( !write_file_name && !print_raw_data && !print_ascii_wave && !print_ascii_eye && !print_pulse_wave )
        aapl_main_error("No output selected: At least one of -write-file, -print-raw-data, -print-pulse-wave, -print-ascii-wave and -print-ascii-eye is required.");

#if AAPL_ENABLE_FILE_IO
    if( read_file_name )
    {
        if( !avago_serdes_escope_read_file(aapl, read_file_name, datap) )
            return 1;   /* EXIT */
    }
    else
#endif /* AAPL_ENABLE_FILE_IO */
    {
        /* Do escope data gathering: */

        if( configp->sc_read_count > 127 )
            aapl_main_error("max_dwell is too large, max is 127.\n");

        if( configp->sc_x_pattern_length == 0 )
            aapl_main_error("pattern_length is a required parameter.");

        if( avago_serdes_escope_get(aapl, addr, configp, datap) < 0 )
        {
            /* return 1; // EXIT */
        }

#if AAPL_ENABLE_FILE_IO
        if( print_raw_data )
            avago_serdes_escope_dump_raw_data(stdout, datap);
#endif /* AAPL_ENABLE_FILE_IO */
    }
    if( get_pulse_response )
    {
        if( configp->sc_x_UI != configp->sc_x_pattern_length )
            aapl_main_error("pulse response error: x-UI must match pattern-length\n");
        avago_serdes_escope_extract_pulse_response(aapl, datap, pulse_width, pulse_delay);
    }
    ascii_y_points = MIN(datap->sd_y_points, ascii_y_points);   /* range check */
#if AAPL_ENABLE_FILE_IO
    if( write_file_name )
        avago_serdes_escope_write_file(write_file_name, datap);

    if( print_ascii_eye && datap->sd_waveform )
    {
        Avago_plot_t *plot = avago_plot_construct(aapl, datap->sd_x_resolution+1, ascii_y_points);
        fprintf(stdout,"# Escope eye (%d x %d):\n",plot->x_points,plot->y_points);
        avago_plot_ascii_eye(plot, datap->sd_waveform);
        avago_plot_print_ascii(stdout, plot);
        avago_plot_destruct(aapl, plot);
    }
    if( print_ascii_wave )
    {
        print_wave(aapl, "Escope wave:"  , datap->sd_waveform , ascii_y_points);
        print_wave(aapl, "Escope wave 2:", datap->sd_waveform2, ascii_y_points);
        print_wave(aapl, "Escope wave 3:", datap->sd_waveform3, ascii_y_points);
        print_wave(aapl, "Escope wave 4:", datap->sd_waveform4, ascii_y_points);
    }
    if( print_pulse_wave )
    {
        print_wave(aapl, "Pulse wave:"  , datap->sd_pulse,  ascii_y_points);
        print_wave(aapl, "Pulse wave 2:", datap->sd_pulse2, ascii_y_points);
        print_wave(aapl, "Pulse wave 3:", datap->sd_pulse3, ascii_y_points);
        print_wave(aapl, "Pulse wave 4:", datap->sd_pulse4, ascii_y_points);
    }
#endif /* AAPL_ENABLE_FILE_IO */

/* Cleanup and exit: */

    {
    int ret = aapl->return_code < 0 ? 1 : 0;
    avago_serdes_escope_data_destruct(  aapl, datap);
    avago_serdes_escope_config_destruct(aapl, configp);
    avago_addr_delete(aapl, &addr_struct);

    return ret;
    }
}

#endif /* AAPL_ENABLE_MAIN && AAPL_ENABLE_ESCOPE_MEASUREMENT */
