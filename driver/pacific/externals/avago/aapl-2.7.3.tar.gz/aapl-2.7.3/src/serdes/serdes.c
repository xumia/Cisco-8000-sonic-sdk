/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* Support for AAPL (ASIC and ASSP Programming Layer) generic handling of */
/* SerDes (Serializer/Deserializer) slices on ASIC SBus rings. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS

#include "aapl.h"

/** @file   serdes.c */
/** @brief  Generic SerDes functions. */
/** @defgroup SerDes Generic SerDes API */
/** @{ */

#define AAPL_LOG_PRINT0 aapl_log_printf
#define AAPL_LOG_PRINT5 if(aapl->debug >= 5) aapl_log_printf
#define AAPL_LOG_PRINT6 if(aapl->debug >= 6) aapl_log_printf

/** @brief   Validate the TX equalization values. */
/** @details Retrieves limit of all values and validate parameters within that range. */
/** @return  On success, returns 0. */
/** @return  On error, returns -1. */
/** @see     avago_serdes_set_tx_eq(), avago_serdes_get_tx_eq_limits(). */
int avago_serdes_validate_tx_eq(
    Aapl_t *aapl,                  /**< [in] Pointer to Aapl_t structure. */
    uint addr,                     /**< [in] Device address number. */
    Avago_serdes_tx_eq_t *tx_eq)   /**< [in] New set of values */
{
    int total = 0, total_lsb = 0, total_msb = 0;
    int sdrev = aapl_get_sdrev(aapl, addr);

    /* Get limits of all Tx EQ parameters for respective serdes. */
    Avago_serdes_tx_eq_limits_t limits; /* = (Avago_serdes_tx_eq_limits_t *) aapl_malloc(aapl, sizeof(Avago_serdes_tx_eq_limits_t), __func__); */
    avago_serdes_get_tx_eq_limits(aapl, addr, &limits);

    /* Validate parameter values of tx_eq structure for respective serdes. */
    switch( sdrev )
    {
    case AAPL_SDREV_D6_07:
    case AAPL_SDREV_P1:
        if( ( tx_eq->pre   < limits.pre_min    || tx_eq->pre   > limits.pre_max  ) ||
            ( tx_eq->post  < limits.post_min   || tx_eq->post  > limits.post_max ) ||
            ( tx_eq->atten < limits.atten_min  || tx_eq->atten > limits.atten_max) ||
            ( tx_eq->pre       % limits.pre_step   ) ||
            ( tx_eq->atten     % limits.atten_step ) ||
            ( tx_eq->post      % limits.post_step  ) )

            return aapl_fail(aapl, __func__, __LINE__, "SBus %s Invalid range for Tx EQ parameter.\n"
                              "  Valid ranges: pre[%d..%d..%d], atten[%d..%d..%d], post[%d..%d..%d]\n"
                              "  Requested: %10d, %15d, %14d\n",
                              aapl_addr_to_str(addr),
                              limits.pre_min,   limits.pre_max,   limits.pre_step,
                              limits.atten_min, limits.atten_max, limits.atten_step,
                              limits.post_min,  limits.post_max,  limits.post_step,
                              tx_eq->pre, tx_eq->atten, tx_eq->post);

        /* validating summation of EQ parameters */
        total = abs(tx_eq->pre) + abs(tx_eq->post) + abs(tx_eq->atten);
        if( total > limits.total_eq )
            return aapl_fail(aapl, __func__, __LINE__, "Total of Tx EQ parameters exceeds limit: Max total value : %d.\n", limits.total_eq);

        break;

    case AAPL_SDREV_CM4:
    case AAPL_SDREV_CM4_16:
        if( ( tx_eq->pre3      < limits.pre3_min   || tx_eq->pre3      > limits.pre3_max ) ||

#if 1 /* Post 0x1065 CM4 FW will not support setting separate values for msb and lsb: */
            ( tx_eq->pre       < limits.pre_min    || tx_eq->pre       > limits.pre_max  ) ||
            ( tx_eq->pre2      < limits.pre2_min   || tx_eq->pre2      > limits.pre2_max ) ||
            ( tx_eq->atten     < limits.atten_min  || tx_eq->atten     > limits.atten_max) ||
            ( tx_eq->post      < limits.post_min   || tx_eq->post      > limits.post_max ) ||
            ( tx_eq->pre       % limits.pre_step   ) ||
            ( tx_eq->atten     % limits.atten_step ) ||
            ( tx_eq->post      % limits.post_step  )
#else
            ( tx_eq->pre_lsb   < limits.pre_min    || tx_eq->pre_lsb   > limits.pre_max  ) ||
            ( tx_eq->pre_msb   < limits.pre_min    || tx_eq->pre_msb   > limits.pre_max  ) ||
            ( tx_eq->pre2_lsb  < limits.pre2_min   || tx_eq->pre2_lsb  > limits.pre2_max ) ||
            ( tx_eq->pre2_msb  < limits.pre2_min   || tx_eq->pre2_msb  > limits.pre2_max ) ||
            ( tx_eq->post_lsb  < limits.post_min   || tx_eq->post_lsb  > limits.post_max ) ||
            ( tx_eq->post_msb  < limits.post_min   || tx_eq->post_msb  > limits.post_max ) ||
            ( tx_eq->atten_lsb < limits.atten_min  || tx_eq->atten_lsb > limits.atten_max) ||
            ( tx_eq->atten_msb < limits.atten_min  || tx_eq->atten_msb > limits.atten_max) ||
            ( tx_eq->pre_lsb   % limits.pre_step   || tx_eq->pre_msb   % limits.pre_step ) ||
            ( tx_eq->post_lsb  % limits.post_step  || tx_eq->post_msb  % limits.post_step)
#endif
            )
        {
            return aapl_fail(aapl, __func__, __LINE__, "SBus %s Invalid range for Tx EQ parameter.\n"
                              "  Valid ranges: pre[%d..%d..%d], pre2[%d..%d], pre3[%d..%d], atten[%d..%d..%d], post[%d..%d..%d]\n"
                              "  Requested: %10d, %16d, %13d, %12d, %14d\n",
                              aapl_addr_to_str(addr),
                              limits.pre_min,   limits.pre_max,   limits.pre_step,
                              limits.pre2_min,  limits.pre2_max,
                              limits.pre3_min,  limits.pre3_max,
                              limits.atten_min, limits.atten_max, limits.atten_step,
                              limits.post_min,  limits.post_max,  limits.post_step,
                              tx_eq->pre, tx_eq->pre2, tx_eq->pre3, tx_eq->atten, tx_eq->post);
        }

        /* validating summation of EQ parameters */
        total = abs(tx_eq->pre) + abs(tx_eq->pre2) + abs(tx_eq->pre3) + abs(tx_eq->atten) + abs(tx_eq->post);
        if( total > limits.total_eq )
            return aapl_fail(aapl, __func__, __LINE__, "Total of Tx EQ parameters exceeds limit: Max total value: %d.\n", limits.total_eq);
        break;

    case AAPL_SDREV_OM4:
        if( ( tx_eq->pre_lsb   < limits.pre_min    || tx_eq->pre_lsb   > limits.pre_max  ) ||
            ( tx_eq->pre_msb   < limits.pre_min    || tx_eq->pre_msb   > limits.pre_max  ) ||
            ( tx_eq->post_lsb  < limits.post_min   || tx_eq->post_lsb  > limits.post_max ) ||
            ( tx_eq->post_msb  < limits.post_min   || tx_eq->post_msb  > limits.post_max ) ||
            ( tx_eq->atten_lsb < limits.atten_min  || tx_eq->atten_lsb > limits.atten_max) ||
            ( tx_eq->atten_msb < limits.atten_min  || tx_eq->atten_msb > limits.atten_max) ||
            ( tx_eq->t2        < limits.t2_min     || tx_eq->t2        > limits.t2_max   ) ||
            ( tx_eq->vert      < limits.vert_min   || tx_eq->vert      > limits.vert_max ) )

            return aapl_fail(aapl, __func__, __LINE__, "SBus %s Invalid range for Tx EQ parameter.\n"
                              "  Valid ranges: pre[%d..%d..%d], vert[%d..%d], atten[%d..%d..%d], post[%d..%d..%d], t2[%d..%d]\n"
                              "  Requested msb/lsb  %3d/%3d %13d, %13d/%3d, %12d/%3d, %5d\n",
                              aapl_addr_to_str(addr),
                              limits.pre_min,   limits.pre_max,   limits.pre_step,
                              limits.vert_min,  limits.vert_max,
                              limits.atten_min, limits.atten_max, limits.atten_step,
                              limits.post_min,  limits.post_max,  limits.post_step,
                              limits.t2_min,    limits.t2_max,
                              tx_eq->pre_msb, tx_eq->pre_lsb, tx_eq->vert, tx_eq->atten_msb, tx_eq->atten_lsb, tx_eq->post_msb, tx_eq->post_lsb, tx_eq->t2);

        /* validating summation of EQ parameters */
        total_lsb = abs(tx_eq->pre_lsb) + abs(tx_eq->post_lsb) + abs(tx_eq->atten_lsb) + abs(tx_eq->vert);
        total_msb = abs(tx_eq->pre_msb) + abs(tx_eq->post_msb) + abs(tx_eq->atten_msb) + abs(tx_eq->vert);
        if( total_lsb > limits.total_eq || total_msb > limits.total_eq )
            return aapl_fail(aapl, __func__, __LINE__, "Total of Tx EQ parameters exceeds limit: Max total value : %d.\n", limits.total_eq);
        break;

    case AAPL_SDREV_HVD6:
        if( ( tx_eq->pre   < limits.pre_min    || tx_eq->pre   > limits.pre_max  ) ||
            ( tx_eq->post  < limits.post_min   || tx_eq->post  > limits.post_max ) ||
            ( tx_eq->atten < limits.atten_min  || tx_eq->atten > limits.atten_max) ||
            ( tx_eq->amp   < limits.amp_min    || tx_eq->amp   > limits.amp_max  ) ||
            ( tx_eq->slew  < limits.slew_min   || tx_eq->slew  > limits.slew_max ) )

            return aapl_fail(aapl, __func__, __LINE__, "SBus %s Invalid range for Tx EQ parameter.\n"
                              "  Valid ranges: pre[%d..%d], amp[%d..%d], slew[%d..%d], atten[%d..%d], post[%d..%d]\n"
                              "  Requested: %10d, %10d, %11d, %11d, %11d\n",
                              aapl_addr_to_str(addr), limits.pre_min  ,limits.pre_max,
                              limits.amp_min, limits.amp_max, limits.slew_min, limits.slew_max,
                              limits.atten_min, limits.atten_max, limits.post_min, limits.post_max,
                              tx_eq->pre, tx_eq->amp, tx_eq->slew, tx_eq->atten, tx_eq->post);
        /* validating summation of EQ parameters */
        total = abs(tx_eq->pre) + abs(tx_eq->post) + abs(tx_eq->atten) + abs(tx_eq->amp);
        if( total > limits.total_eq )
            return aapl_fail(aapl, __func__, __LINE__, "Total of Tx EQ parameters exceeds limit: Max total value : %d.\n", limits.total_eq);
        break;
    case AAPL_SDREV_PON:
    case AAPL_SDREV_D6:
    case AAPL_SDREV_16:
        if( ( tx_eq->pre   < limits.pre_min    || tx_eq->pre   > limits.pre_max  ) ||
            ( tx_eq->post  < limits.post_min   || tx_eq->post  > limits.post_max ) ||
            ( tx_eq->atten < limits.atten_min  || tx_eq->atten > limits.atten_max) ||
            ( tx_eq->slew  < limits.slew_min   || tx_eq->slew  > limits.slew_max ) )

            return aapl_fail(aapl, __func__, __LINE__, "SBus %s Invalid range for Tx EQ parameter.\n"
                              "  Valid ranges: pre[%d..%d], slew[%d..%d], atten[%d..%d], post[%d..%d]\n"
                              "  Requested: %10d, %12d, %11d, %11d\n",
                              aapl_addr_to_str(addr), limits.pre_min  ,limits.pre_max, limits.slew_min,
                              limits.slew_max, limits.atten_min, limits.atten_max, limits.post_min, limits.post_max,
                              tx_eq->pre, tx_eq->slew, tx_eq->atten, tx_eq->post);

        /* validating summation of EQ parameters */
        total = abs(tx_eq->pre) + abs(tx_eq->post) + abs(tx_eq->atten);
        if( total > limits.total_eq )
            return aapl_fail(aapl, __func__, __LINE__, "Total of Tx EQ parameters exceeds limit: Max total value : %d.\n", limits.total_eq);
        break;

    default:
        break;
    }
    return 0;
}

/** @brief   Populates a structure with the limits for the Tx Eq settings. */
/** @details Returns values based on the specific SerDes specified. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_serdes_get_tx_eq(), avago_serdes_set_tx_eq(). */
int avago_serdes_get_tx_eq_limits(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    uint addr,                          /**< [in] Device address number. */
    Avago_serdes_tx_eq_limits_t *limits) /**< [out] Address of struct to populate. */
{
    /* Make sure addr points to a 28nm SerDes */
    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 3, AVAGO_SERDES,  AVAGO_M4, AVAGO_P1) ||
        !aapl_check_process(aapl, addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28) )
        return -1;

    /* Initialize the data struct to all zeros */
    memset(limits, 0, sizeof(*limits));

    limits->total_eq      = 32; /* Default maximum EQ setting */
    limits->pre_step      =
    limits->post_step     =
    limits->atten_step    = 1;
    switch( aapl_get_sdrev(aapl,addr) )
    {
    case AAPL_SDREV_P1: /* All P1s are the same (for now) */
    #if 0 /* The P1 hardware supports negative values, but the firmware does not (as of 0x105D). */
        if( aapl_get_ip_rev(aapl,addr) == 0x06 )    /* Tesla P1 */
        {
            limits->pre_min   = -23; limits->pre_max   = 23; /* [1,2,4,8,8] */
            limits->post_min  = -23; limits->post_max  = 23; /* [1,2,4,8,8] */
            limits->atten_min =   0; limits->atten_max = 16; limits->atten_step = 8; /* [8,8] */
            limits->total_eq  =  32;
        }
        else
    #endif
        {
            limits->pre_min   =  0; limits->pre_max   = 23; /* [1,2,4,8,8] */
            limits->post_min  =  0; limits->post_max  = 23; /* [1,2,4,8,8] */
            limits->atten_min =  0; limits->atten_max = 16; limits->atten_step = 8; /* [8,8] */
            limits->total_eq  = 32;
        }
        break;
    case AAPL_SDREV_OM4 :
            limits->pre_min   = -23; limits->pre_max      =  23;
            limits->atten_min =   0; limits->atten_max    =  31;
            limits->post_min  = -15; limits->post_max     =  15;
            limits->vert_min  =   0; limits->vert_max     =  11;
            limits->t2_min    =   0; limits->t2_max       =  1;
            limits->total_eq  = 32;
            break;
    case AAPL_SDREV_CM4 :
    case AAPL_SDREV_CM4_16 :
            /* Derived off the Tx Eq spreadsheets. */
#if 0       /* HW supports this, but FW does not yet allow it: */
            if( !avago_serdes_get_tx_line_encoding(aapl, addr) ) /* NRZ */
            {
                limits->pre3_min  =   0; limits->pre3_max     =   0;
                limits->pre2_min  =   0; limits->pre2_max     =   0;
                limits->pre_min   =   0; limits->pre_max      =  30;
                limits->atten_min =   0; limits->atten_max    =  45;
                limits->post_min  =   0; limits->post_max     =  78;
                limits->pre_step  =   2; limits->pre_feature  =  AVAGO_TX_EQ_FEATURE_EVEN_VALUES_ONLY;
                limits->total_eq  =  78;
            }
            else /* PAM4 */
#endif
            {
                limits->pre3_min  =  -1; limits->pre3_max     =   1;
                limits->pre2_min  = -15; limits->pre2_max     =  15;
                limits->pre_min   = -10; limits->pre_max      =  10;
                limits->atten_min =   0; limits->atten_max    =  26;
                limits->post_min  = -18; limits->post_max     =  18;
                limits->post_step =   2; limits->post_feature =  AVAGO_TX_EQ_FEATURE_EVEN_VALUES_ONLY;
                limits->pre_step  =   2; limits->pre_feature  =  AVAGO_TX_EQ_FEATURE_EVEN_VALUES_ONLY;
                limits->total_eq  =  32;
            }
            if( avago_serdes_tx_eq_deep_post_active(aapl, addr) )
            {
                /* If deep post option is active, then pre2 is disabled and post limits are extended. */
                /* The HW implementation is that the pre2 setting increases post in deep post mode. */
                limits->pre3_min  =   0; limits->pre3_max     =   0;
                limits->pre2_min  =   0; limits->pre2_max     =   0;
                limits->post_min  = -31; limits->post_max     =  31;
                limits->post_step =   1; limits->post_feature =  AVAGO_TX_EQ_FEATURE_NONE;
            }
        break;
    case AAPL_SDREV_HVD6 : /* HVD6 Serdes */
        limits->amp_min = 0; limits->amp_max = 15;  /* Only available on HVD6 */
        /* fall through */
    case AAPL_SDREV_PON:   /* 16nm PON SerDes */
    case AAPL_SDREV_16 :   /* 16nm D6 Serdes */
    case AAPL_SDREV_D6 :   /* 28nm D6 SerDes */
        /* Assume all other slices support both extended atten and positive pre&post */
        limits->pre_min = -7; limits->atten_min =  0; limits->post_min = -31; limits->slew_min = 0;
        limits->pre_max = 15; limits->atten_max = 31; limits->post_max =  31; limits->slew_max = 3;
        switch( aapl_get_ip_rev(aapl,addr) )
        {
        /* txhs_02 and txhs_03 don't have positive precur */
        /* txhs_04 does */
        case 0xA7 : /* sd28C_txhs_rxd6_02 - Denali-B */
        case 0xAA : /* sd28C_str_txhs_rxd6_01 - Gearbox1.0 */
        case 0xAC : /* sd28C_hf_txhs_rxd6_01 - Denali-B */
        case 0xB0 : /* sd28C_txhs_rxd6_03 - McKinley */
        case 0xB2 : /* sd28C_txhs_rxd6_gb2_03 - Vortex2.0 */
        case 0xB4 : /* sd28C_str_txhs_rxd6_03 - ???? */
        case 0xEF : /* sd28C_pcie_sas_sata_hvd6_02 - Academy */
        case 0xF0 : /* sd28C_pcie_16b_02 - Academy */
        case 0x0C : /* sd16C_pcie_ns_02 - Simba */
        case 0x11 : /* sd16C_pcie_shrt_ns_03 - Tesla */
        case 0x25 : /* sd16C_pcie_gen4_ns_01 - Fermi */
            limits->pre_min = 0;
            limits->post_min= 0;
            break;
        case 0xB7 : /* sd28C_vlp_txc_rxd6e_01 - VLP slice */
            limits->pre_min = 0; limits->atten_min = 0; limits->post_min = 0;
            limits->pre_max = 0; limits->atten_max = 5; limits->post_max =23;
            limits->total_eq = 30;
            break;
        }
        /* PCIE builds support only non-negative pre and post: */
        {
            int build = aapl_get_firmware_build(aapl, addr);
            if( build == 0x2447 || build == 0x2347 || build == 0x2147 || build == 0x00C1 )
            {
                limits->pre_min = 0;
                limits->post_min= 0;
            }
        }

        /* Pre-0x1043 FW doesn't support negative pre and post, even if HW does... */
        if( !aapl_check_firmware_rev(aapl, addr, __func__, __LINE__, FALSE, 1, 0x1043) )
            limits->pre_min = limits->post_min = 0;
        break;
    case AAPL_SDREV_D6_07:
        limits->pre_min =  0; limits->atten_min =  0; limits->post_min =   0;
        limits->pre_max = 19; limits->atten_max = 31; limits->post_max =  31;
        break;
    default:
        break;
    }
    return 0;
}


/** @brief  Gets the RX data qual filter setting. */
/** */
/** @return Returns the RX data qual filter value. */
/** @return On error, decrements aapl->return_code. */
/** @see     avago_serdes_set_rx_data_qual(). */
Avago_serdes_rx_data_qual_t avago_serdes_get_rx_data_qual(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr)          /**< [in] Device address number. */
{
    int mode, reg_compare, reg_compare_data_compare_en_0;
    Avago_serdes_rx_data_qual_t ret = AVAGO_SERDES_RX_DATA_QUAL_UNQUAL;
    int bits = 0;
    BOOL read_even_odd = FALSE;

    switch( aapl_get_sdrev(aapl,addr) )
    {
    case AAPL_SDREV_P1: reg_compare = 0xe1; reg_compare_data_compare_en_0 = 0xe5; break;
    case AAPL_SDREV_D6: reg_compare = 0x17; reg_compare_data_compare_en_0 = 0x1a; break;
    default:
    case AAPL_SDREV_CM4:
    case AAPL_SDREV_CM4_16: read_even_odd = TRUE; /* Fall through */
    case AAPL_SDREV_OM4:
    case AAPL_SDREV_HVD6:
    case AAPL_SDREV_D6_07:
    case AAPL_SDREV_16: reg_compare = 0x17; reg_compare_data_compare_en_0 = 0x63; break;
    }
    mode = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, reg_compare);
    if( (mode & 0x3800) == 0 )  /* If qualify select == all */
    {
        bits = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, reg_compare_data_compare_en_0) & 0xff;
        if( bits == 0xff ) bits = 0;
    }
    if( read_even_odd )
    {
        int mask = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x62);
        if(      mask == 0x3333 || mask == 0x2222 || mask == 0x1111 ) bits |= 1 << 14;   /* ODD */
        else if( mask == 0xcccc || mask == 0x8888 || mask == 0x4444 ) bits |= 2 << 14;   /* EVEN */
    }
    bits |= mode & 0xf800;
    ret = (Avago_serdes_rx_data_qual_t)bits;
    {
    Avago_serdes_data_qual_t dq;
    avago_serdes_data_qual_init(&dq);
    dq.d6_data_qual = ret;
    AAPL_LOG_PRINT5(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus %s, data_qual=%s (0x%x)\n", aapl_addr_to_str(addr), aapl_data_qual_to_str(dq), mode);
    }
    return ret;
}
/** @brief   Sets the RX data qual value. */
/** @details The data_qual value filters the bits that are compared. */
/**          For example, AVAGO_SERDES_RX_DATA_QUAL_PREV0 causes only those bits */
/**          to be compared for which the previous bit had a 0 value. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_serdes_get_rx_data_qual(). */
/* Note: Find data qual fields in gen2_data_compare_config sections of SerDes documentation. */
int avago_serdes_set_rx_data_qual(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    uint addr,                          /**< [in] Device address number. */
    Avago_serdes_rx_data_qual_t qual)   /**< [in] New data qual selection. */
{
    Avago_serdes_data_qual_t dq;
    int return_code = aapl->return_code;
    int mode = 0;
    int bits = 0;

    avago_serdes_data_qual_init(&dq);
    dq.d6_data_qual = qual;
    AAPL_LOG_PRINT5(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus %s, data_qual=%s\n", aapl_addr_to_str(addr), aapl_data_qual_to_str(dq));

    if( qual != AVAGO_SERDES_RX_DATA_QUAL_UNLOCK )
    {
        Avago_serdes_rx_cmp_mode_t cmp_mode = avago_serdes_get_rx_cmp_mode(aapl, addr);
        mode = (int) cmp_mode | 0x0003; /* Enable bits, always on */
        if( cmp_mode == AVAGO_SERDES_RX_CMP_MODE_XOR && aapl_get_ip_type(aapl, addr) == AVAGO_M4 ) mode |= 0x0150;
        /* Handle all data qual modes, even those not in enum: */
        mode |= qual & 0xf800;
        bits  = qual & 0x00ff;          /* Set using dma after interrupt call */
    }
    avago_spico_int_check(aapl, __func__, __LINE__, addr, 0x03, mode);

    if( bits ) /* Set data_qual values that interrupt doesn't support: */
    {
        switch( aapl_get_sdrev(aapl,addr) )
        {
        case AAPL_SDREV_P1: avago_serdes_mem_wr(aapl, addr, AVAGO_LSB, 0xe5, bits & 0xff); break;
        case AAPL_SDREV_D6: avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, 0x1a, bits, 0xff); break;
        default:
        case AAPL_SDREV_CM4:
        case AAPL_SDREV_CM4_16:
        case AAPL_SDREV_OM4:
        case AAPL_SDREV_HVD6:
        case AAPL_SDREV_D6_07:
        case AAPL_SDREV_16: avago_serdes_mem_wr(aapl, addr, AVAGO_LSB, 0x63, bits & 0xff); break;
        }
    }
    if( return_code != aapl->return_code )
        return aapl_fail(aapl,__func__,__LINE__,"SBus %s, data_qual=%s\n",aapl_addr_to_str(addr),aapl_data_qual_to_str(dq));
    return 0;
}

/** @brief  Initialize the extended data qualification structure. */
/** @return void */
/** @see    avago_serdes_set_data_qual(). */
void avago_serdes_data_qual_init(
    Avago_serdes_data_qual_t *qual)
{
    memset(qual,0xff,sizeof(*qual));
    qual->d6_data_qual = AVAGO_SERDES_RX_DATA_QUAL_DEFAULT;
    qual->pam = FALSE;
    qual->select = 0;
    qual->cmp_valid_pre = 0;
    qual->cmp_valid_post = 0;
}

/** @cond INTERNAL */

/** @brief  Constructs D6 value from new registers. */
void aapl_construct_d6_data_qual(Avago_serdes_data_qual_t *dq)
{
    /* Convert PAM4 compare_enable bits to NRZ compare_enable bits: */
    int bits10 = AAPL_BITS_GET(dq->cmp_data_compare_en[0],2,0);
    int bits32 = AAPL_BITS_GET(dq->cmp_data_compare_en[0],2,4);
    int bits54 = AAPL_BITS_GET(dq->cmp_data_compare_en[1],2,0);
    int bits76 = AAPL_BITS_GET(dq->cmp_data_compare_en[1],2,4);
    int nrz_bits = bits76 << 6 | bits54 << 4 | bits32 << 2 | bits10;
    int dq_value;
    switch( nrz_bits )
    {
    case 0x0f: dq_value = AVAGO_SERDES_RX_DATA_QUAL_PREV0; break;
    case 0xf0: dq_value = AVAGO_SERDES_RX_DATA_QUAL_PREV1; break;
    case 0xff: dq_value = AVAGO_SERDES_RX_DATA_QUAL_UNQUAL; break;
    default:   dq_value = nrz_bits; break;
    }
    dq_value |= AAPL_BITS_GET(dq->select, 2, 0) << 14;  /* all/odd/even */
 /* printf("nrz_bits = 0x%x, all/odd/even bits = %d, dq_value = 0x%x\n", nrz_bits, AAPL_BITS_GET(dq->select,2,0), dq_value); */
    dq->d6_data_qual = (Avago_serdes_rx_data_qual_t)dq_value;
}
/** @endcond */

/** @brief  Gets the extended RX data qualification filter setting. */
/** @return Returns the extended RX data qualification filter value. */
/** @return On error, decrements aapl->return_code. */
/** @see     avago_serdes_set_data_qual(), avago_serdes_set_rx_data_qual(). */
Avago_serdes_data_qual_t avago_serdes_get_data_qual(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr)          /**< [in] Device address number. */
{
    Avago_serdes_data_qual_t dq;
    avago_serdes_data_qual_init(&dq);
    switch( aapl_get_sdrev(aapl,addr) )
    {
    case AAPL_SDREV_D6:
        dq.d6_data_qual = avago_serdes_get_rx_data_qual(aapl,addr);
        dq.select = (dq.d6_data_qual >> 14) & 3;
        break;
    default:
    case AAPL_SDREV_D6_07:
    case AAPL_SDREV_HVD6:
    case AAPL_SDREV_16: {
        int reg = avago_serdes_mem_rd(aapl,addr,AVAGO_LSB,0x18);
        dq.cmp_valid_pre  = (reg >>  8) & 0xf;
        dq.cmp_valid_post = (reg >> 12) & 0xf;
        dq.d6_data_qual = avago_serdes_get_rx_data_qual(aapl,addr);
        dq.select = (dq.d6_data_qual >> 14) & 3;
        break;
        }
    case AAPL_SDREV_P1: {
        int reg = avago_serdes_mem_rd(aapl,addr,AVAGO_LSB,0xe2);
        dq.cmp_valid_pre      = (reg >>  8) & 0xf;
        dq.cmp_valid_post     = (reg >> 12) & 0xf;
        dq.d6_data_qual = avago_serdes_get_rx_data_qual(aapl,addr);
        dq.select = (dq.d6_data_qual >> 14) & 3;
        break;
        }
    case AAPL_SDREV_CM4:
    case AAPL_SDREV_CM4_16:
    case AAPL_SDREV_OM4: {
        Avago_serdes_line_encoding_t tx, rx;
        int reg = avago_serdes_mem_rd(aapl,addr,AVAGO_LSB,0x18);
        int even_odd = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x62);
        dq.cmp_valid_pre  = (reg >>  8) & 0xf;
        dq.cmp_valid_post = (reg >> 12) & 0xf;
        dq.cmp_data_compare_en[0] = avago_serdes_mem_rd(aapl,addr,AVAGO_LSB,0x63);
        dq.cmp_data_compare_en[1] = avago_serdes_mem_rd(aapl,addr,AVAGO_LSB,0x64);
        dq.cmp_data_compare_en[2] = avago_serdes_mem_rd(aapl,addr,AVAGO_LSB,0x65);
        dq.cmp_data_compare_en[3] = avago_serdes_mem_rd(aapl,addr,AVAGO_LSB,0x66);
        reg = avago_serdes_mem_rd(aapl,addr,AVAGO_LSB,0x0d);
        dq.select = (reg >> 10) & 0x0c; /* ERROR_SELECT0 */
        if(      even_odd == 0x3333 || even_odd == 0x2222 || even_odd == 0x1111 ) dq.select |= 1;   /* ODD */
        else if( even_odd == 0xcccc || even_odd == 0x8888 || even_odd == 0x4444 ) dq.select |= 2;   /* EVEN */
        if( avago_serdes_get_tx_rx_line_encoding(aapl, addr, &tx, &rx) == 0 && rx == AVAGO_SERDES_NRZ )
        {
            /*printf("GET NRZ QUAL BEFORE = ?.%04x_%04x_%04x_%04x.?\n",dq.cmp_data_compare_en[3],dq.cmp_data_compare_en[2],dq.cmp_data_compare_en[1],dq.cmp_data_compare_en[0]); */
            if( dq.cmp_data_compare_en[0] & (1 <<  3) ) dq.cmp_data_compare_en[0] |= 1 << 1;
            if( dq.cmp_data_compare_en[0] & (1 << 12) ) dq.cmp_data_compare_en[0] |= 1 << 4;
            if( dq.cmp_data_compare_en[0] & (1 << 15) ) dq.cmp_data_compare_en[0] |= 1 << 5;
            if( dq.cmp_data_compare_en[3] & (1 <<  0) ) dq.cmp_data_compare_en[1] |= 1 << 0;
            if( dq.cmp_data_compare_en[3] & (1 <<  3) ) dq.cmp_data_compare_en[1] |= 1 << 1;
            if( dq.cmp_data_compare_en[3] & (1 << 12) ) dq.cmp_data_compare_en[1] |= 1 << 4;
            if( dq.cmp_data_compare_en[3] & (1 << 15) ) dq.cmp_data_compare_en[1] |= 1 << 5;
            dq.cmp_data_compare_en[0] &= 0x0033;
            dq.cmp_data_compare_en[1] &= 0x0033;
            dq.cmp_data_compare_en[2] = dq.cmp_data_compare_en[3] = 0;
            if( dq.cmp_valid_pre  == 0xb ) dq.cmp_valid_pre  = 9;
            if( dq.cmp_valid_post == 0xb ) dq.cmp_valid_post = 9;
            dq.pam = FALSE;
            aapl_construct_d6_data_qual(&dq);
            /*printf("GET NRZ QUAL AFTER = ?.%04x_%04x_%04x_%04x.?\n",dq.cmp_data_compare_en[3],dq.cmp_data_compare_en[2],dq.cmp_data_compare_en[1],dq.cmp_data_compare_en[0]); */
        }
        else
        {
            dq.pam = TRUE;
            dq.d6_data_qual = AVAGO_SERDES_RX_DATA_QUAL_UNQUAL;
        }
        break;
        }
    }
    AAPL_LOG_PRINT5(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus %s, data_qual=%s (0x%x)\n", aapl_addr_to_str(addr), aapl_data_qual_to_str(dq), dq.d6_data_qual);
    return dq;
}
/** @brief   Sets the extended RX data qualification value. */
/** @details The data qualification value selects the bits that are compared */
/**          by the error counter. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_serdes_get_data_qual(), avago_serdes_get_rx_data_qual(). */
int avago_serdes_set_data_qual(
    Aapl_t *aapl,                         /**< [in] Pointer to Aapl_t structure. */
    uint addr,                            /**< [in] Device address number. */
    Avago_serdes_data_qual_t qual)        /**< [in] New data qual selection. */
{
    int return_code = aapl->return_code;

    AAPL_LOG_PRINT5(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus %s, data_qual=%s\n", aapl_addr_to_str(addr), aapl_data_qual_to_str(qual));

    switch( aapl_get_sdrev(aapl,addr) )
    {
    case AAPL_SDREV_D6:
        avago_serdes_set_rx_data_qual(aapl,addr,qual.d6_data_qual);
        break;
    case AAPL_SDREV_D6_07:
    case AAPL_SDREV_PON:
    case AAPL_SDREV_16:
    case AAPL_SDREV_HVD6:
        avago_serdes_set_rx_data_qual(aapl,addr,qual.d6_data_qual);
        avago_serdes_mem_rmw(aapl,addr,AVAGO_LSB,0x18,(qual.cmp_valid_pre << 8) | (qual.cmp_valid_post << 12),0xff00);
        break;
    case AAPL_SDREV_P1:
        avago_serdes_set_rx_data_qual(aapl,addr,qual.d6_data_qual);
        avago_serdes_mem_rmw(aapl,addr,AVAGO_LSB,0xe2,(qual.cmp_valid_pre << 8) | (qual.cmp_valid_post << 12),0xff00);
        break;
    default:
    case AAPL_SDREV_CM4:
    case AAPL_SDREV_CM4_16:
    case AAPL_SDREV_OM4: {
        Avago_serdes_line_encoding_t tx, rx;
        Avago_serdes_rx_cmp_mode_t cmp_mode = avago_serdes_get_rx_cmp_mode(aapl, addr);
        int mode = (int) cmp_mode | 0x0003; /* Enable bits, always on */
        if( cmp_mode == AVAGO_SERDES_RX_CMP_MODE_XOR && aapl_get_ip_type(aapl, addr) == AVAGO_M4 ) mode |= 0x0150;
        mode |= qual.d6_data_qual & 0xc000; /* Add even/odd bits */
        if( (qual.d6_data_qual & 0x3000) == 0x2000 )
            mode |= qual.d6_data_qual & 0x3800;
        /*printf("DQ Setting: avago_spico_int(0x03, 0x%x)\n", mode); */
        avago_spico_int_check(aapl, __func__, __LINE__, addr, 0x03, mode);
        if( avago_serdes_get_tx_rx_line_encoding(aapl, addr, &tx, &rx) == 0 && rx == AVAGO_SERDES_NRZ )
        {
            /* Convert PAM4 patterns into bit duplicated NRZ patterns by */
            /*  converting ones in the input pattern to threes, and by */
            /*  clearing all invalid pattern selections. */
            /*printf("M4: Convert PAM4 patterns into bit duplicated NRZ patterns.\n"); */
            /*printf("SET NRZ QUAL BEFORE = ?.%04x_%04x_%04x_%04x.?\n",qual.cmp_data_compare_en[3],qual.cmp_data_compare_en[2],qual.cmp_data_compare_en[1],qual.cmp_data_compare_en[0]); */
            if( qual.cmp_data_compare_en[0] & (1 << 1) ) qual.cmp_data_compare_en[0] |= 1 << 3;
            if( qual.cmp_data_compare_en[0] & (1 << 4) ) qual.cmp_data_compare_en[0] |= 1 << 12;
            if( qual.cmp_data_compare_en[0] & (1 << 5) ) qual.cmp_data_compare_en[0] |= 1 << 15;
            if( qual.cmp_data_compare_en[1] & (1 << 0) ) qual.cmp_data_compare_en[3] |= 1 << 0;
            if( qual.cmp_data_compare_en[1] & (1 << 1) ) qual.cmp_data_compare_en[3] |= 1 << 3;
            if( qual.cmp_data_compare_en[1] & (1 << 4) ) qual.cmp_data_compare_en[3] |= 1 << 12;
            if( qual.cmp_data_compare_en[1] & (1 << 5) ) qual.cmp_data_compare_en[3] |= 1 << 15;
            qual.cmp_data_compare_en[1] = qual.cmp_data_compare_en[2] = 0;
            qual.cmp_data_compare_en[0] &= 0x9009;
            qual.cmp_data_compare_en[3] &= 0x9009;
            if( qual.cmp_valid_pre  == 9 ) qual.cmp_valid_pre  = 0xb;
            if( qual.cmp_valid_post == 9 ) qual.cmp_valid_post = 0xb;
            /*printf("SET NRZ QUAL AFTER = ?.%04x_%04x_%04x_%04x.?\n",qual.cmp_data_compare_en[3],qual.cmp_data_compare_en[2],qual.cmp_data_compare_en[1],qual.cmp_data_compare_en[0]); */
        }

        avago_serdes_mem_rmw(aapl,addr,AVAGO_LSB,0x0d, 0x300 | (qual.select & 0x0c) << 10, 0xff00); /* Setup total/lsb/msb counting */
        avago_serdes_mem_wr(aapl,addr,AVAGO_LSB,0x63,qual.cmp_data_compare_en[0]);                  /* Setup 64 patterns selections */
        avago_serdes_mem_wr(aapl,addr,AVAGO_LSB,0x64,qual.cmp_data_compare_en[1]);
        avago_serdes_mem_wr(aapl,addr,AVAGO_LSB,0x65,qual.cmp_data_compare_en[2]);
        avago_serdes_mem_wr(aapl,addr,AVAGO_LSB,0x66,qual.cmp_data_compare_en[3]);
        /* Set up any pre/post qualification: */
        avago_serdes_mem_rmw(aapl,addr,AVAGO_LSB,0x18,(qual.cmp_valid_pre << 8) | (qual.cmp_valid_post << 12),0xff00);
        break;
        }
    }
    if( return_code != aapl->return_code )
        return aapl_fail(aapl,__func__,__LINE__,"SBus %s, data_qual=%s\n",aapl_addr_to_str(addr),aapl_data_qual_to_str(qual));
    return 0;
}

/** @brief   Gets the PCS FIFO clock source. */
/** @details */
/** @return  Returns the PCS FIFO clock source. */
/** @return  On error, decrements aapl->return_code. */
/** @see     avago_serdes_set_pcs_fifo_clk_div(), avago_serdes_get_pcs_fifo_clk_div(), avago_serdes_get_tx_pll_clk_src(). */
Avago_serdes_pcs_fifo_clk_t avago_serdes_get_pcs_fifo_clk_div(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr)          /**< [in] Device address number. */
{
    Avago_serdes_pcs_fifo_clk_t ret = AVAGO_SERDES_PCS_FIFO_F66;
    int pcs_architecture = aapl_get_pcs_architecture(aapl,addr);
    if( pcs_architecture == 1 )
    {
        ret = (Avago_serdes_pcs_fifo_clk_t)aapl_serdes_get_int30_bits(aapl, addr, 0x0f00);
        AAPL_LOG_PRINT5(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus %s, pcs_fifo_clk %s\n",aapl_addr_to_str(addr),aapl_pcs_fifo_clk_to_str(ret));
    }
    if( pcs_architecture == 2 )
    {
        /*                       F50,  F68,  F33,  F66            F50,  F68,  F33,  F66 */
        /* Opal2 OM4  : Rx 0xc0(0c76, 1464, 1c5a, 1c35), Tx 0xe4(0c76, 1464, 1c5a, 1c35) */
        /* Fermi CM4  : Rx 0xfb(08ed, 10c9, 18b5, 186b), Tx 0xa9(0c76, 1464, 1c5a, 1c35) */
        /* Tesla CM4  : Rx 0xc1(08ed, 10c9, 18b5, 186b), Tx 0xa9(0c76, 1464, 1c5a, 1c35) */
        /* Fermi D6   : Rx 0xfb(18ec, 28c8, 38b4, 386a), Tx 0xec(0c76, 1464, 1c5a, 1c35) */
        /* 28nm HVD6  : Rx 0xc0(0c76, 1464, 1c5a, 1c35), Tx 0xec(0c76, 1464, 1c5a, 1c35) */

        int reg_tx_div_misc3_ctl;
        uint reg;

        switch( aapl_get_sdrev(aapl, addr) )
        {
        case AAPL_SDREV_CM4_16:
        case AAPL_SDREV_CM4:    reg_tx_div_misc3_ctl = 0xa9;  break;
        case AAPL_SDREV_PON:
        case AAPL_SDREV_16:     reg_tx_div_misc3_ctl = 0xec;  break;
        case AAPL_SDREV_OM4:
        case AAPL_SDREV_HVD6:   reg_tx_div_misc3_ctl = 0xe4;  break;
        case AAPL_SDREV_D6_07:  reg_tx_div_misc3_ctl = 0x44d; break;
        default:                reg_tx_div_misc3_ctl = 0;     return ret;
        }

        reg = avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,reg_tx_div_misc3_ctl); /* TX_DIV_MISC3_CTL */
        if(      reg == 0x0c76 ) ret = AVAGO_SERDES_PCS_FIFO_F50;
        else if( reg == 0x1464 ) ret = AVAGO_SERDES_PCS_FIFO_F68;
        else if( reg == 0x1c5a ) ret = AVAGO_SERDES_PCS_FIFO_F33;
        else if( reg == 0x1c35 ) ret = AVAGO_SERDES_PCS_FIFO_F66;
        AAPL_LOG_PRINT5(aapl,AVAGO_DEBUG5,__func__,__LINE__,"ESB reg 0x%X = 0x%X, ret = %s\n", reg_tx_div_misc3_ctl, reg, aapl_pcs_fifo_clk_to_str(ret));

    }
    return ret;
}

/** @brief   Sets the SerDes's PCS FIFO clock source. */
/** @details */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_serdes_get_pcs_fifo_clk_div(), avago_serdes_set_spico_clk_src(), avago_serdes_set_tx_pll_clk_src(). */
int avago_serdes_set_pcs_fifo_clk_div(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    uint addr,                          /**< [in] Device address number. */
    Avago_serdes_pcs_fifo_clk_t src)    /**< [in] New clock source. */
{
    int return_code = aapl->return_code;
    int mask = 0;
    int pcs_architecture = aapl_get_pcs_architecture(aapl,addr);

    AAPL_LOG_PRINT5(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus %s, pcs_fifo=%s\n",aapl_addr_to_str(addr),aapl_pcs_fifo_clk_to_str(src));
    if( pcs_architecture == 1 )
    {
        /* Architecture 1 pcs clock divider design: */
        mask = aapl_serdes_get_int30_bits(aapl, addr, ~0x0f00) | src;
        AAPL_LOG_PRINT5(aapl,AVAGO_DEBUG5,__func__,__LINE__,"Calling int(aapl, addr, 0x30, 0x%x)\n", mask);
    }
    else if( pcs_architecture == 2 )
    {
        /* Architecture 2 pcs clock divider design: */
        mask = (src == AVAGO_SERDES_PCS_FIFO_F50) ? 0x0200 : src;
        mask |= aapl_serdes_get_int30_bits(aapl, addr, 0x0070);
        mask |= 0xc008;
        AAPL_LOG_PRINT5(aapl,AVAGO_DEBUG5,__func__,__LINE__,"Calling int(aapl, addr, 0x30, 0x%x)\n", mask);
    }
    else /* pcs_architecture == 0 */
        return 0;
    avago_spico_int_check(aapl, __func__, __LINE__, addr, 0x30, mask);
    return return_code == aapl->return_code ? 0 : -1;
}

/*============================================================================= */
/* F2 Divider Lookup */
/* Used to determine the divider value based on reading the AVAGO_ESB values */
/* NOTE: Value returned is scaled consistently with the pll_const_* values so */
/*       they cancel in the final divide, but still preserve needed precision. */
static uint f2divider_lookup(uint data)
{
    uint divider;
    switch(data & 0x1F)
    {
        /* divide by 1000 for rate: */
        case 0x1C : {divider = 24000; break; }
        case 0x04 : {divider = 16000; break; }
        case 0x1B : {divider = 12000; break; }
        case 0x03 : {divider =  8000; break; }
        case 0x1A : {divider =  6000; break; }
        case 0x02 : {divider =  4000; break; }
        case 0x19 : {divider =  3000; break; }
        case 0x01 : {divider =  2000; break; }
        case 0x18 : {divider =  1500; break; }
        case 0x00 : {divider =  1000; break; }
        default   : {divider =     0; break; }
    }
    return divider;
}
/*============================================================================= */
/* Divider Lookup - 28nm */
/* Used to determine the divider value based on reading the AVAGO_ESB values */
static uint divider_lookup28nm(uint data)
{
    uint divider;
    switch( data & 0xFF )
    {
    case 0x00 : {divider = 1;  break;}
    case 0x01 : {divider = 2;  break;}
    case 0x03 : {divider = 3;  break;}
    case 0x07 : {divider = 4;  break;}
    case 0x06 : {divider = 5;  break;}
    case 0x0E : {divider = 6;  break;}
    case 0x0C : {divider = 7;  break;}
    case 0x1E : {divider = 7;  break;}
    case 0x3E : {divider = 8;  break;}
    case 0x3C : {divider = 9;  break;}
    case 0x38 : {divider = 10; break;}
    case 0x78 : {divider = 11; break;}
    case 0xF8 : {divider = 12; break;}
    case 0xF0 : {divider = 13; break;}
    default   : {divider = 0;  break;}
    }
    switch( (data>>8) & 0x0007 )
    {
    case 0x0 : {divider *= 10; break;}
    case 0x1 : {divider *= 5;  break;}
    case 0x2 : {divider *= 6;  break;}
    case 0x3 : {divider *= 2;  break;}
    case 0x4 : {divider *= 4;  break;}
    case 0x5 : {divider *= 8;  break;}
    default  : {divider *= 0;  break;}
    }
    switch( (data>>11) & 0x0007 )
    {
    case 0x0 : {divider *= 1;  break;}
    case 0x1 : {divider *= 2;  break;}
    case 0x3 : {divider *= 3;  break;}
    case 0x2 : {divider *= 4;  break;}
    case 0x6 : {divider *= 5;  break;}
    default  : {divider *= 0;  break;}
    }
    return divider;
}

/*============================================================================= */
/* Divider Lookup - 16nm */
/* Used to determine the divider value based on reading the AVAGO_ESB values */
static uint divider_lookup16nm(Aapl_t *aapl, uint divx_cntl, uint divx2_cntl)
{
    uint divx_pre;
    uint divider;

    /* parse divx_cntl */
    uint divx_hs_sel  = (divx_cntl & 0x8000) >> 15;
    uint divx_hs_half = (divx_cntl & 0x4000) >> 14;
    uint divx_hs_hi   = (divx_cntl & 0x3f00) >> 8;
    uint divx_hs_lo   = (divx_cntl & 0x003f);

    /* parse divx2_cntl */
    uint divx_in_cntl = (divx2_cntl & 0x0300) >> 8;
    uint divx_ls_half = (divx2_cntl & 0x0080) >> 7;
    uint divx_ls_hi   = (divx2_cntl & 0x0070) >> 4;
    uint divx_ls_div1 = (divx2_cntl & 0x0008) >> 3;
    uint divx_ls_lo   = (divx2_cntl & 0x0007);
    (void)aapl;

    /* get divx_pre from div_in_cntl */
    switch (divx_in_cntl) {
        case 0: divx_pre = 2; break;
        case 1: divx_pre = 2; break;
        case 2: divx_pre = 4; break;
        case 3: divx_pre = 5; break;
        default: divx_pre = 0; break;
    }

    /* original equation: */
     /*    tb_divx_divider = (!divx_hs_sel & divx_ls_div1) ? (2 * divx_pre) : (divx_pre * (divx_half + (2 * (divx_hi + divx_lo)))); */

    if (divx_hs_sel == 0)
    {
        if (divx_ls_div1 == 1)
        {
            divider = 2 * divx_pre;
            /*AAPL_LOG_PRINT6(aapl, AVAGO_DEBUG6, __func__, __LINE__, "%d = 2 * %d\n", divider, divx_pre); */
        }
        else
        {
            divider = divx_pre * (divx_ls_half + (2 * (divx_ls_hi + divx_ls_lo)));
            /*AAPL_LOG_PRINT6(aapl, AVAGO_DEBUG6, __func__, __LINE__, "%d = %d * (%d + 2 * (%d + %d))\n", divider, divx_pre, divx_ls_half, divx_ls_hi, divx_ls_lo); */
        }
    }
    else
    {
        divider = divx_pre * (divx_hs_half + (2 * (divx_hs_hi + divx_hs_lo)));
        /*AAPL_LOG_PRINT6(aapl, AVAGO_DEBUG6, __func__, __LINE__, "%d = %d * (%d + 2 * (%d + %d))\n", divider, divx_pre, divx_hs_half, divx_hs_hi, divx_hs_lo); */
    }
    /* TODO-16NM check this */
    return divider/2;
}
static uint ones_count(uint data)
{
    uint i;
    uint cf=0;
    for( i = 0; i < 15; i++ )
    {
        if ((data >> i) & 0x1)  /* Count the number of ones set */
            cf += 1;
    }
    return cf;
}


/** @brief   Gathers status for a Tx SerDes PLL. */
/** @details Fills in the Avago_serdes_pll_state_t struct with the current */
/**          values from the SerDes slice. */
/** */
/**          NOTE: The est_rate field is an estimate of the SerDes line rate based on */
/**          where the PLL calibrated to. */
/**          PVT variations affect the accuracy of this value. */
/** @see     avago_serdes_get_rx_pll_state(). */
void avago_serdes_get_tx_pll_state(
    Aapl_t *aapl,                       /**< [in] Pointer to AAPL structure */
    uint addr,                          /**< [in] SBus address of SerDes */
    Avago_serdes_pll_state_t *status)   /**< [out] Struct to populate */
{
    int sdrev = aapl_get_sdrev(aapl,addr);
    bigint center_freq = avago_get_ip_info(aapl,addr)->center_freq; /* center_freq is in Mhz */
    bigint pll_const_3 = 0;
    bigint pll_const_2 = 0;
    bigint pll_const_1 = 0;
    bigint pll_center  = 0;
    int reg_gain, data, gain_shift, reg_thrm_cal, reg_bin_cal, reg_f2div, reg_div_ctl = 0;
    int reg_divx_ctl1 = 0, reg_divx_ctl2 = 0;
    BOOL tx_ready, rx_ready;

    if( !aapl_check_ip_type(aapl,addr,__func__,__LINE__,TRUE,3,AVAGO_SERDES, AVAGO_M4, AVAGO_P1) ||
        !aapl_check_process(aapl,addr,__func__,__LINE__,TRUE,3,AVAGO_TSMC_07,AVAGO_TSMC_16,AVAGO_TSMC_28) )
        return;

    /* Equations: */
    /* divider = pre-scale * var_divx * divx */
    /* cal_cf  = ones_count(cal_therm) * 8 + cal_bin */

    switch( sdrev )
    {
    case AAPL_SDREV_D6:   reg_gain = 0x201; gain_shift = 5; reg_thrm_cal = 0x202; reg_bin_cal = 0x203; reg_f2div = 0x204; reg_div_ctl = 0x220; break;
    case AAPL_SDREV_HVD6: reg_gain = 0x009; gain_shift = 5; reg_thrm_cal = 0x00a; reg_bin_cal = 0x00b; reg_f2div = 0x00c; reg_div_ctl = 0x0d8; break;
    case AAPL_SDREV_P1:
                 if( aapl_get_process_id(aapl, addr) == AVAGO_TSMC_28 )
                        { reg_gain = 0x111; gain_shift = 8; reg_thrm_cal = 0x112; reg_bin_cal = 0x113; reg_f2div = 0x11c; reg_div_ctl = 0x119; }                          /* Borah Peak */
                 else   { reg_gain = 0x111; gain_shift = 8; reg_thrm_cal = 0x11b; reg_bin_cal = 0x11c; reg_f2div = 0x119; reg_divx_ctl1 = 0x114; reg_divx_ctl2 = 0x115; } /* Tesla */
                 break;
    default:
    case AAPL_SDREV_CM4:
    case AAPL_SDREV_CM4_16:
    case AAPL_SDREV_OM4:
    case AAPL_SDREV_PON:
    case AAPL_SDREV_16:   reg_gain = 0x0d2; gain_shift = 8; reg_thrm_cal = 0x0d3; reg_bin_cal = 0x0d4; reg_f2div = 0x0d5; reg_divx_ctl1 = 0x0d8; reg_divx_ctl2 = 0x0f5; break;
    case AAPL_SDREV_D6_07:reg_gain = 0x42c; gain_shift = 8; reg_thrm_cal = 0x42d; reg_bin_cal = 0x42e; reg_f2div = 0x42f; reg_divx_ctl1 = 0x432; reg_divx_ctl2 = 0x433; break;
    }

    avago_serdes_get_tx_rx_ready(aapl,addr,&tx_ready,&rx_ready);
    data = avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,reg_gain);

    status->ready = tx_ready;
    status->intGAIN = (data >> gain_shift) & 0x01F;
    status->bbGAIN  = (data >> 0) & 0x01F;
    status->cal_code = 8 * ones_count( avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,reg_thrm_cal) & 0x7fff );
    status->cal_code +=  avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,reg_bin_cal) & 0x007;

    if( sdrev == AAPL_SDREV_P1 )
    {
        int p1_pll_f2_divider_lookup[] = { 2000, 1000, 4000, 1000, 8000, 1000, 6000, 1000 };
        status->line_rate_div = p1_pll_f2_divider_lookup[avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,reg_f2div)&7];
    }
    else
    {
        status->line_rate_div = f2divider_lookup(avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,reg_f2div));
    }

    if( reg_div_ctl )
        status->divider = divider_lookup28nm(avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,reg_div_ctl));
    else /* 16nm & 10nm PLL */
    {
        /* Read the divider value: */
        uint data1 = avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,reg_divx_ctl1);
        uint data2 = avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,reg_divx_ctl2);
        status->divider  = divider_lookup16nm(aapl, data1, data2);
    }

    /* We scale the pll_const_* values up by 1000 from the floating point */
    /*    originals to preserve precision. */
    /* Note: the f2divider_lookup_28nm scaling must be consistent with this */
    /*    scaling so they cancel in the final divide. */
    if( center_freq > AAPL_CONST_INT64(10000) ) /* 10 Gig */
    {
        /*printf("TX 25G\n"); */
        pll_const_3 = AAPL_CONST_INT64(       2099064); /* 1.58528981e+03; */
        pll_const_2 = AAPL_CONST_INT64(      11920630); /* 3.91640759e+04; */
        pll_const_1 = AAPL_CONST_INT64(   32006816300); /* 2.71066035e+07; */
        /*pll_center =  AAPL_CONST_INT64(10000000000000); // 10.0e+009 */
        if (aapl_get_process_id(aapl,addr) == AVAGO_TSMC_07) pll_center  = (center_freq * 1000000) *         1000 * 95 / 100;
        else                                                 pll_center  = (center_freq * 1000000) * 4 / 5 * 1000 * 89 / 100;
    }
    else if( center_freq > AAPL_CONST_INT64(8000) ) /* 8 Gig */
    {
        /*printf("TX 18G\n"); */
        pll_const_3 = AAPL_CONST_INT64(       1204015); /* 1.20401528e+03; */
        pll_const_2 = AAPL_CONST_INT64(      29600752); /* 2.96007521e+04; */
        pll_const_1 = AAPL_CONST_INT64(   20276116300); /* 2.02761163e+07; */
        pll_center =  AAPL_CONST_INT64( 6702616100000); /* 6.70261610e+09 */
    }
    else
    {
        /*printf("TX 15G\n"); */
        pll_const_3 = AAPL_CONST_INT64(        740023); /* 7.40022612e+002; */
        pll_const_2 = AAPL_CONST_INT64(      14792725); /* 1.47927250e+004; */
        pll_const_1 = AAPL_CONST_INT64(   13379447000); /* 1.33794470e+007; */
        /*pll_center =  AAPL_CONST_INT64( 5000000000000); // 5.0e+009 */
        pll_center  = (center_freq * 1000000) * 4 / 5 * 1000 * 89 /100;
    }
    AAPL_LOG_PRINT6(aapl, AVAGO_DEBUG6, __func__, __LINE__, "pll_const3: %s, pll_const2: %s, pll_const1: %s, pll_center: %s\n",
                    aapl_bigint_to_str(pll_const_3), aapl_bigint_to_str(pll_const_2), aapl_bigint_to_str(pll_const_1), aapl_bigint_to_str(pll_center));

    /* Line_rate = (const_3 * cf^3 - const_2 * cf^2 + const_1 * cf + (center_freq * 1000000)) / F2div */
    if( status->line_rate_div != 0 && center_freq > 0)
        status->est_rate = (pll_const_3 * (status->cal_code * status->cal_code * status->cal_code)
                          - pll_const_2 * (status->cal_code * status->cal_code)
                          + pll_const_1 * (status->cal_code) + pll_center) / (status->line_rate_div / 2);
    else status->est_rate = 0;
}

/** @cond INTERNAL */

/** @brief   Enables or disables the SerDes Rx fine frequency lock functionality. */
/** @return  On success, returns 0. */
/** @return  On error, returns -1. */
/** @see     avago_serdes_get_fine_frequency_lock(). */
int avago_serdes_set_fine_frequency_lock(
    Aapl_t *aapl,                          /**< [in] Pointer to AAPL structure */
    uint addr,                             /**< [in] SBus address of SerDes */
    BOOL enable)                           /**< [in] bit to enable/disable DISABLE_RX_FINE_FLOCK_CHECKS */
{
    int return_code = aapl->return_code;
    avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, 0x1c, (!enable << 14), 0x4000);
    return (return_code == aapl->return_code) ? 0 : -1;
}

/** @brief   Retrieves the Rx fine frequency lock enabled status. */
/** @return  Returns TRUE if SerDes Rx fine frequency lock is enabled, false otherwise. */
/** @see     avago_serdes_set_fine_frequency_lock(). */
BOOL avago_serdes_get_fine_frequency_lock(
    Aapl_t *aapl,                          /**< [in] Pointer to AAPL structure */
    uint addr)                             /**< [in] SBus address of SerDes */
{
    BOOL flock_check = !((0x4000 & avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x1c)) >> 14);
    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, freq lock check=%d\n", aapl_addr_to_str(addr), flock_check);
    return flock_check;
}
/** @endcond */

/** @brief   Provides PLL gain register address and bit shift value. */
/** @details Provides register address and bit shift values to perform read/write of Rx SerDes PLL gains. */
/** @return  On success, returns 0. */
/** @return  On error, returns -1. */
/** @see     avago_serdes_get_rx_pll_gain(), avago_serdes_set_rx_pll_gain(). */
static int avago_serdes_get_rx_pll_gain_reg(
    Aapl_t *aapl,                        /**< [in]  Pointer to AAPL structure */
    uint addr,                           /**< [in]  SBus address of SerDes */
    uint *gain_reg,                      /**< [out] Holds address of Rx SerDes PLL gain ESB register */
    uint *bb_gain_mask,                  /**< [out] Bit mask value for register field */
    uint *int_gain_shift,                /**< [out] Bit shift value to read int_gain */
    uint *int_gain_mask)                 /**< [out] Bit mask value for int_gain */
{
    int return_code = aapl->return_code;
    uint sdrev = aapl_get_sdrev(aapl, addr);

    *int_gain_shift = 8;
    *int_gain_mask = 0x0f;
    *bb_gain_mask = 0x0f;

    switch(sdrev)
    {
    case AAPL_SDREV_D6:
    case AAPL_SDREV_HVD6:    *gain_reg = 0x01; *int_gain_shift = 5; *int_gain_mask = 31; break;
    default:
    case AAPL_SDREV_CM4:
    case AAPL_SDREV_CM4_16:
    case AAPL_SDREV_OM4:
    case AAPL_SDREV_16:      *gain_reg = 0x81; *int_gain_shift = 8; *int_gain_mask = 31; break;
    case AAPL_SDREV_PON:     *gain_reg = 0x143;*int_gain_shift = 8;  *bb_gain_mask =  7; break;
    case AAPL_SDREV_D6_07:   *gain_reg = 0x401;*int_gain_shift = 8;                      break;
    case AAPL_SDREV_P1:      *gain_reg = 0xc1; *int_gain_shift = 12;                     break;
    }
    return (return_code == aapl->return_code) ? 0 : -1;
}

/** @brief   Sets Rx PLL gain values. */
/** @details Performs validation of Rx PLL gains and writes them to the respective ESB register. */
/** @return  On success, returns 0. */
/** @return  On error, returns -1. */
/** @see     avago_serdes_get_rx_pll_gain(), avago_serdes_get_rx_pll_gain_reg(). */
int avago_serdes_set_rx_pll_gain(
    Aapl_t *aapl,               /**< [in] Pointer to AAPL structure */
    uint addr,                  /**< [in] SBus address of SerDes */
    uint bb_gain,               /**< [in] value of Rx PLL bb_gain/kp_gain to set */
    uint int_gain)              /**< [in] value of Rx PLL int_gain/ki_gain to set */
{
    int return_code = aapl->return_code;
    uint int_gain_reg = 0, int_gain_shift = 0;
    uint bb_gain_mask, int_gain_mask;
    uint sdrev = aapl_get_sdrev(aapl, addr);

    /* get Rx PLL gain register adddress and bit shift value to write gains */
    avago_serdes_get_rx_pll_gain_reg(aapl, addr, &int_gain_reg, &bb_gain_mask, &int_gain_shift, &int_gain_mask);

    /* Validate Rx PLL gains */
    if( bb_gain > bb_gain_mask || int_gain > int_gain_mask )
    {
        if( sdrev == AAPL_SDREV_PON )
            return aapl_fail(aapl, __func__, __LINE__, "Sbus %s Invalid value of parameter.\n"
                                   "Range:     kp_gain:[0..%d], ki_gain:[0..%d].\n"
                                   "requested: kp_gain: %6d, ki_gain: %6d.\n",
                                   aapl_addr_to_str(addr), bb_gain_mask, int_gain_mask, bb_gain, int_gain);

        else
            return aapl_fail(aapl, __func__, __LINE__, "Sbus %s Invalid value of parameter.\n"
                                   "Range:     bb_gain:[0..%d], int_gain:[0..%d].\n"
                                   "requested: bb_gain: %6d, int_gain: %6d.\n",
                                   aapl_addr_to_str(addr), bb_gain_mask, int_gain_mask, bb_gain, int_gain);
    }

    if( sdrev == AAPL_SDREV_PON )
        aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, Set Rx PLL kpGAIN: %d and kiGAIN: %d.\n",
                        aapl_addr_to_str(addr), bb_gain, int_gain);
    else
        aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, Set Rx PLL bbGAIN: %d and intGAIN: %d.\n",
                        aapl_addr_to_str(addr), bb_gain, int_gain);

    if( sdrev == AAPL_SDREV_P1 )
    {
        avago_serdes_mem_rmw(aapl, addr, AVAGO_ESB, int_gain_reg, ((int_gain & int_gain_mask) << int_gain_shift), (int_gain_mask << int_gain_shift));
        avago_serdes_mem_rmw(aapl, addr, AVAGO_ESB, 0xc3,     ((bb_gain & bb_gain_mask) << 12), (bb_gain_mask << 12));
    }
    else if( sdrev == AAPL_SDREV_PON )
        avago_serdes_mem_rmw(aapl, addr, AVAGO_ESB, int_gain_reg, ((bb_gain & bb_gain_mask) << 12) | ((int_gain & int_gain_mask) << int_gain_shift),
                                                               (bb_gain_mask << 12) | (int_gain_mask << int_gain_shift));
    else
        avago_serdes_mem_rmw(aapl, addr, AVAGO_ESB, int_gain_reg, (bb_gain & bb_gain_mask) | ((int_gain & int_gain_mask) << int_gain_shift),
                             bb_gain_mask | (int_gain_mask << int_gain_shift));

    return (return_code == aapl->return_code) ? 0 : -1;
}

/** @brief   Gets Rx PLL gains. */
/** @details Reads rx PLL gains from ESB register. */
/** @return  On success, returns 0. */
/** @return  On error, returns -1. */
/** @see     avago_serdes_set_rx_pll_gain(), avago_serdes_get_rx_pll_gain_reg(). */
int avago_serdes_get_rx_pll_gain(
    Aapl_t *aapl,                /**< [in]  Pointer to AAPL structure */
    uint addr,                   /**< [in]  SBus address of SerDes */
    uint *bb_gain,               /**< [out] Read value of Rx PLL bb_gain/kp_gain */
    uint *int_gain)              /**< [out] Read value of Rx PLL int_gain/ki_gain */
{
    int return_code = aapl->return_code;
    uint data = 0;
    uint int_gain_reg, bb_gain_mask, int_gain_shift, int_gain_mask;
    uint sdrev = aapl_get_sdrev(aapl, addr);

    /* get Rx PLL gain register adddress and bit shift values and masks to read gains */
    avago_serdes_get_rx_pll_gain_reg(aapl, addr, &int_gain_reg, &bb_gain_mask, &int_gain_shift, &int_gain_mask);

    data = avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, int_gain_reg);
    *int_gain = (data >> int_gain_shift ) & int_gain_mask;

    if( sdrev == AAPL_SDREV_P1 )
    {
        data = avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,0xc3);
        *bb_gain = (data >> 12) & bb_gain_mask;
    }
    else if( sdrev == AAPL_SDREV_PON )
        *bb_gain = (data >> 12) & bb_gain_mask;
    else
        *bb_gain = (data >>  0) & bb_gain_mask;

    if( sdrev == AAPL_SDREV_PON )
        aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, Get Rx PLL kpGAIN: %d and kiGAIN: %d.\n",
                        aapl_addr_to_str(addr), *bb_gain, *int_gain);
    else
        aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, Get Rx PLL bbGAIN: %d and intGAIN: %d.\n",
                        aapl_addr_to_str(addr), *bb_gain, *int_gain);

    return (return_code == aapl->return_code) ? 0 : -1;
}

/** @brief   Gathers status for a Rx SerDes PLL */
/** @details Fills in the Avago_serdes_pll_state_t struct with the current */
/**          values from the SerDes slice. */
/** */
/**          NOTE: est_rate is an estimate of the SerDes line rate based on */
/**          where the PLL calibrated to. */
/**          PVT variations affect the accuracy of this value. */
/** @see     avago_serdes_get_tx_pll_state(). */
void avago_serdes_get_rx_pll_state(
    Aapl_t *aapl,                       /**< [in] Pointer to AAPL structure */
    uint addr,                          /**< [in] SBus address of SerDes */
    Avago_serdes_pll_state_t *status)   /**< [out] Struct to populate */
{
    int sdrev = aapl_get_sdrev(aapl,addr);
    bigint center_freq = avago_get_ip_info(aapl,addr)->center_freq; /* center_freq is in Mhz */
    bigint pll_const_3 = 0;
    bigint pll_const_2 = 0;
    bigint pll_const_1 = 0;
    bigint pll_center  = 0;
    int reg_f2div, reg_cal_therm, reg_cal_bin;
    BOOL tx_ready, rx_ready;

    if( !aapl_check_ip_type(aapl,addr,__func__,__LINE__,TRUE,3,AVAGO_SERDES, AVAGO_M4, AVAGO_P1) ||
        !aapl_check_process(aapl,addr,__func__,__LINE__,TRUE,3,AVAGO_TSMC_07,AVAGO_TSMC_16,AVAGO_TSMC_28) )
        return;

    if( sdrev == AAPL_SDREV_P1 ) /* P1 does not use the standard calculation for the calibration code */
    {
        /* Many of the P1 values are the same for RX and TX, get the TX */
        /* parameters and then change as necessary. */
        int reg_cal_r2r = 0;
        avago_serdes_get_tx_pll_state(aapl,addr,status);

        /* Set the intGAIN, bbGAIN, cal_code, and ready for the P1 RX */
        avago_serdes_get_rx_pll_gain(aapl, addr, &(status->bbGAIN), &(status->intGAIN));
        status->cal_code =  (avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,reg_cal_r2r) & 0x3ff);

        avago_serdes_get_tx_rx_ready(aapl,addr,&tx_ready,&rx_ready);
        status->ready = rx_ready;
        return;
    }
    if( sdrev == AAPL_SDREV_PON )
    {
        int data = 0;
        Avago_serdes_pll_state_t tx_status;
        memset(&tx_status, 0, sizeof(tx_status));

        /* Get Tx PLL parameters to calculate some of the Rx PLL parameters */
        avago_serdes_get_tx_pll_state(aapl,addr,&tx_status);

        /* ESB register CDR_CNTL_3[1:0] provides line_rate_div value */
        data = avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, 0x146) & 0x03;
        status->line_rate_div = (data == 0) ? 4000 : (data == 1) ? 1000 : (data == 2) ? 8000 : 2000;

        /* divider = (divider at full rate) / line_rate_div */
        /* As divider calculation is based on REFCLK, currently calculated using TxPLL parameters */
        status->divider = ( tx_status.divider  * (tx_status.line_rate_div / 2000) ) / ( status->line_rate_div / 1000);

        /* RxF1clk is VCO frequency which is estimated rate of Tx at full rate (about 10GHz) */
        status->rxF1clk = tx_status.est_rate * ( tx_status.line_rate_div / 2000 );  /* in Hz */

        /* estimated rate = RxF1clk / line_rate_divider; */
        status->est_rate = status->rxF1clk / (status->line_rate_div / 1000 );  /* in bps */

        /* Get Kp Gain and Ki Gain */
        avago_serdes_get_rx_pll_gain(aapl, addr, &(status->kpGAIN), &(status->kiGAIN));
        avago_serdes_get_tx_rx_ready(aapl,addr,&tx_ready,&rx_ready);
        status->ready = rx_ready;
        return;
    }
    /* Equations: */
    /* divider = pre-scale * var_divx * divx */
    /* cal_cf  = ones_count(cal_therm) * 8 + cal_bin */

    if( sdrev == AAPL_SDREV_HVD6 )
        status->divider = divider_lookup28nm(avago_serdes_mem_rd(aapl,addr, AVAGO_ESB, 0x0ca) & 0x3fff);
    else if( sdrev == AAPL_SDREV_D6 )
    {
        /* Read 0x070 and 0x073 for divider setting  (16nm: Read 0xca and 0xcb) */
        /* Read 0x003 and 0x002 for cal_cf           (16nm: Read 0x84 and 0x83) */
        /* Read 0x001 for int,bb gain settings       (16nm: Read 0x81) */
        /* 0x073 -  7:5 pre-scale */
        /* 0x070 - 10:8 var_divx */
        /*          7:0 divx */
        uint data     = avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,0x070) & 0x07FF;
        uint data_pre = ( avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,0x073) << 6) & 0x3800;
        status->divider  = divider_lookup28nm(data|data_pre);
    }
    else
    {
        int reg_pll_divx_ctl, reg_pll_divx2_ctl;
        uint data1, data2;

        if( sdrev == AAPL_SDREV_D6_07 )
             { reg_pll_divx_ctl = 0x408; reg_pll_divx2_ctl = 0x409; }
        else
             { reg_pll_divx_ctl = 0xca; reg_pll_divx2_ctl = 0xcb; }

        data1 = avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,reg_pll_divx_ctl);
        data2 = avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,reg_pll_divx2_ctl);
        status->divider  = divider_lookup16nm(aapl, data1, data2);
    }

    switch( sdrev )
    {
    default:
    case AAPL_SDREV_D6:
    case AAPL_SDREV_HVD6: reg_f2div = 0x04; reg_cal_therm = 0x02; reg_cal_bin = 0x03; break;
    case AAPL_SDREV_CM4:
    case AAPL_SDREV_CM4_16:
    case AAPL_SDREV_OM4:
    case AAPL_SDREV_16:   reg_f2div = 0x86; reg_cal_therm = 0x83; reg_cal_bin = 0x84; break;
    case AAPL_SDREV_D6_07:reg_f2div = 0x406; reg_cal_therm = 0x403; reg_cal_bin = 0x404; break;
    }
    status->line_rate_div = f2divider_lookup(avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,reg_f2div));

    avago_serdes_get_rx_pll_gain(aapl, addr, &(status->bbGAIN), &(status->intGAIN));
    status->cal_code = 8 * ones_count( avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,reg_cal_therm) ) ;
    status->cal_code +=  avago_serdes_mem_rd(aapl,addr,AVAGO_ESB,reg_cal_bin) & 0x007;

    avago_serdes_get_tx_rx_ready(aapl,addr,&tx_ready,&rx_ready);
    status->ready = rx_ready;

    /* Set the constants for Estimating the Line Rate */

    /* We scale the pll_const_* values up by 1000 from the floating point */
    /*    originals to preserve precision. */
    /* Note: the f2divider_lookup scaling must be consistent with this */
    /*    scaling so they cancel in the final divide. */
    if( center_freq > AAPL_CONST_INT64(10000) ) /* 10 Gig */
    {
        /*printf("RX 25G\n"); */
        pll_const_3 = AAPL_CONST_INT64(       1639157); /* 1.63915681e+03; */
        pll_const_2 = AAPL_CONST_INT64(      44628330); /* 4.46283305e+04; */
        if (aapl_get_process_id(aapl,addr) == AVAGO_TSMC_07) pll_const_1 = AAPL_CONST_INT64(   52381792700); /* 2.73817927e+07; */
        else pll_const_1 = AAPL_CONST_INT64(   27381792700); /* 2.73817927e+07; */
        pll_center  = AAPL_CONST_INT64(10000000000000); /* 10.0e+09 */
    }
    else if( center_freq > AAPL_CONST_INT64(8000) ) /* 8 Gig */
    {
        /*printf("RX 18G\n"); */
        pll_const_3 = AAPL_CONST_INT64(       1192566); /* 1.19256631e+003; */
        pll_const_2 = AAPL_CONST_INT64(      24452538); /* 2.44525385e+004; */
        pll_const_1 = AAPL_CONST_INT64(   20250157300); /* 2.02501573e+007; */
        pll_center  = AAPL_CONST_INT64( 6730018950000); /* 6.73001895e+009 */
    }
    else
    {
        /*printf("RX 15G\n"); */
        pll_const_3 = AAPL_CONST_INT64(        742274); /* 7.42274285e+002; */
        pll_const_2 = AAPL_CONST_INT64(      18702920); /* 1.87029201e+004; */
        pll_const_1 = AAPL_CONST_INT64(   13510666700); /* 1.35106667e+007; */
        pll_center  = AAPL_CONST_INT64( 5000000000000); /* 5.0e+009 */
    }
    AAPL_LOG_PRINT6(aapl, AVAGO_DEBUG6, __func__, __LINE__, "pll_const3: %s, pll_const2: %s, pll_const1: %s, pll_center: %s\n",
                    aapl_bigint_to_str(pll_const_3), aapl_bigint_to_str(pll_const_2), aapl_bigint_to_str(pll_const_1), aapl_bigint_to_str(pll_center));

    /* Line_rate = (const_3 * cf^3 - const_2 * cf^2 + const_1 * cf + (center_freq * 1000000) / F2div */
    if( status->line_rate_div != 0 && center_freq > 0)
        status->est_rate = (pll_const_3 * (status->cal_code * status->cal_code * status->cal_code)
                          - pll_const_2 * (status->cal_code * status->cal_code)
                          + pll_const_1 * (status->cal_code) + pll_center) / (status->line_rate_div / 2);
    else status->est_rate = 0;
}


/** @brief   Check if bitrate #divider is a valid value. */
/** @details This function is valid for the 28nm SerDes architecture. */
/** @return  TRUE if the #divider value is valid for this device, FALSE if not. */
BOOL avago_serdes_is_valid_divider(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr,          /**< [in] SBus address of SerDes */
    uint divider)       /**< [in] Integer divider ratio of bitrate to REFCLK */
{
    int n;
    /* Table valid for 28nm SerDes architecture: */
    const unsigned char valid_dividers[] =
    {   2,  4,  5,  6,  8, 10, 12, 14, 15, 16, 18, 20, 22, 24, 25, 26,
       28, 30, 32, 35, 36, 40, 42, 44, 45, 48, 50, 52, 54, 55, 56, 60,
       64, 65, 66, 70, 72, 75, 78, 80, 84, 88, 90, 96,100,104,105,108,
      110,112,120,125,126,128,130,132,135,140,144,150,156,160,162,165,
      /* These are out-of-range, but can be useful with a */
      /* slow reference clock: */
      168,175,176,180,192,195,198,200,208,210,216,220,224,225,234,240,250
    };
    (void)aapl;
    (void)addr;

    for( n = 0; n < AAPL_ARRAY_LENGTH(valid_dividers); n++ )
        if( divider == valid_dividers[n] )
            return TRUE;
    return FALSE;
}

/** @} */

#if 0       /* Unsupported in AAPL */
/** @cond INTERNAL */

/*============================================================================= */
/* SERDES SET GROUP BROADCAST LIST */

/** @brief  Joins SerDes to supplied group broadcast address. */
/** @details SerDes can be joined to 2 group broadcast addresses */
/**  (given by addr_sel, which should be 1 or 2). */
/** This will overwrite any previous group broadcast address applied. */
void avago_serdes_set_group_broadcast_list(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    int broadcast_addr,     /**< [in] Address to use for the group broadcast. */
    int addr_sel,           /**< [in] Group select: either 1 or 2. */
    int n,                  /**< [in] number of parameters following. */
    ...)                    /**< [in] addresses to set as the group. */
{
    int addr_array[256];
    int x;

    va_list addr;
    va_start(addr, n);

    if( n > 256 )
        return;

    for (x = 0; x<n; x++) addr_array[x] = va_arg(addr, uint);

    avago_serdes_set_group_broadcast_array(aapl, broadcast_addr, addr_sel, n, addr_array);

    va_end(addr);
}

/*============================================================================= */
/* SERDES SET GROUP BROADCAST ARRAY */

/** @brief  Joins SerDes to supplied group broadcast address. */
/** @details SerDes can be joined to 2 group broadcast addresses */
/**  (given by addr_sel, which should be 1 or 2). */
/** This will overwrite any previous group broadcast address applied. */
void avago_serdes_set_group_broadcast_array(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    int broadcast_addr, /**< [in] Address to use for the group broadcast. */
    int addr_sel,       /**< [in] Group select: either 1 or 2. */
    int n,              /**< [in] number of entries in addr_array. */
    int *addr_array)    /**< [in] Array of sbus addresses to set as the group. */
{
    /* 40nm: */
    /* ADDR  252  sbus_clk   ADDR_252 fc */
    /* REG   0    0  RW  IGNORE_BROADCAST_CNTL                 Set to '1' for SBus Rx to ignore broadcast commands */
    /* REG   11:4  0  RW  BROADCAST_INV_CNTL                   Alternative standard SerDes broadcast address -- inverted. When set to all '0's, the standard SerDes broadcast addres */
    /* REG   23:16  0  RW  BROADCAST_INV_2_CNTL                Second alternative standard SerDes broadcast address -- inverted */

    /* 28nm: */
    /* ADDR 253 sbus_clk   Broadcast Control */
    /* REG  0      0    RW  IGNORE_BROADCAST     Ignores all commands sent to broadcasat or group broadcast addresses */
    /* REG  11:4   0xFF RW  BROADCAST_GROUP_1    Address for 2nd broadcast address */
    /* REG  23:16  0xFF RW  BROADCAST_GROUP_2    Address for 3rd broadcast address */

    uint mask;
    int x;
    broadcast_addr &= 0xff; /* mask out 8 bits */

    if      (addr_sel == 1)
    {
        broadcast_addr = broadcast_addr << 4;
        mask = 0xff << 4;
    }
    else if (addr_sel == 2)
    {
        broadcast_addr = broadcast_addr << 16;
        mask = 0xff << 16;
    }
    else
    {
        aapl_fail(aapl, __func__, __LINE__, "Invalid addr_sel (%d).\n", addr_sel);
        return;
    }

    for (x = 0; x<n; x++)
    {
        uint addr = addr_array[x];

        if (!aapl_check_ip_type(aapl, addr, __func__, __LINE__, FALSE, 1, AVAGO_SERDES)) continue;              /* If this isn't the correct type, move to the next item in the array */
        if (!aapl_check_process(aapl, addr, __func__, __LINE__, FALSE, 2, AVAGO_TSMC_16, AVAGO_TSMC_28)) continue;

        else if (aapl_get_process_id(aapl,addr) == AVAGO_TSMC_28) avago_sbus_rmw(aapl, addr, 0xfd, broadcast_addr, mask);
        else if (aapl_get_process_id(aapl,addr) == AVAGO_TSMC_16) avago_sbus_rmw(aapl, addr, 0xfd, broadcast_addr, mask);
    }
}
/** @endcond */
#endif


/** @brief   Allocates and initializes a Avago_serdes_link_init_config_t struct. */
/** @details The return value should be released using */
/**          avago_serdes_link_init_config_destruct() after use. */
/** @return  On success, returns a pointer to the initialized structure. */
/** @return  On failure, returns NULL. */
/** @see     avago_serdes_link_init_config_destruct(), avago_serdes_init(). */
Avago_serdes_link_init_config_t *avago_serdes_link_init_config_construct(
    Aapl_t *aapl_a, /**< [in] Pointer to Aapl_t structure for SerDes B. */
    uint addr_a,    /**< [in] Address for SerDes A. */
    Aapl_t *aapl_b, /**< [in] Pointer to Aapl_t structure for SerDes A. */
    uint addr_b)    /**< [in] Address for SerDes B. */
{
    size_t bytes = sizeof(Avago_serdes_link_init_config_t);
    Avago_serdes_link_init_config_t *config;

    if( ! (config = (Avago_serdes_link_init_config_t *) aapl_malloc(aapl_a, bytes, "Avago_serdes_link_init_config_t struct")) )
        return NULL;
    memset(config, 0, sizeof(*config));         /* set all bytes to zero */

    config->aapl_a = aapl_a;
    config->addr_a = addr_a;
    config->aapl_b = aapl_b;
    config->addr_b = addr_b;
    config->info = TRUE;
    config->dfe_tune = TRUE;
    config->serdes_config_a = avago_serdes_init_config_construct(aapl_a);
    config->serdes_config_b = avago_serdes_init_config_construct(aapl_b);
    config->serdes_dfe_config_a = avago_serdes_dfe_state_construct(aapl_a);
    config->serdes_dfe_config_b = avago_serdes_dfe_state_construct(aapl_b);

    return config;
}


/** @brief   Releases a Avago_serdes_link_init_config_t struct. */
/** */
/** @return  None. */
/** @see     avago_serdes_link_init_config_construct(), avago_serdes_link_init(). */
void avago_serdes_link_init_config_destruct(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    Avago_serdes_link_init_config_t *config) /**< [in] Pointer to struct to release. */
{
    aapl_free(aapl, config->serdes_config_a, "Avago_serdes_link_init_config_t->serdes_a struct");
    aapl_free(aapl, config->serdes_config_b, "Avago_serdes_link_init_config_t->serdes_b struct");
    aapl_free(aapl, config->serdes_dfe_config_a, "Avago_serdes_link_init_config_t->dfe_config_a struct");
    aapl_free(aapl, config->serdes_dfe_config_b, "Avago_serdes_link_init_config_t->dfe_config_b struct");
    aapl_free(aapl, config, "Avago_serdes_link_init_config_t struct");
}


/** @brief   Brings up a duplex link between 2 serdes. */
/** @details avago_serdes_init() will be called on both serdes, */
/**          followed by optional DFE tuning and eye measurements */
/**          for each receiver. */
/** @return  Returns TRUE or FALSE indicating whether or not the link is error free. */
/** @see     avago_serdes_link_init_config_construct(), avago_serdes_init(). */
BOOL avago_serdes_link_init_quick(Aapl_t *aapl_a, uint addr_a, uint div_a, Aapl_t *aapl_b, uint addr_b, uint div_b)
{
    BOOL result;
    Avago_serdes_link_init_config_t *config = avago_serdes_link_init_config_construct(aapl_a, addr_a, aapl_b, addr_b);

    config->serdes_config_a->tx_divider = div_a;
    config->serdes_config_a->rx_divider = div_a;
    config->serdes_config_b->tx_divider = div_b;
    config->serdes_config_b->rx_divider = div_b;

    result = avago_serdes_link_init(config);
    avago_serdes_link_init_config_destruct(aapl_a, config);
    return result;
}


/** @brief   Brings up a duplex link between 2 serdes. */
/** @details avago_serdes_init() will be called on both serdes, */
/**          followed by optional DFE tuning and eye measurements */
/**          for each receiver. */
/** @return  Returns TRUE or FALSE indicating whether or not the link is error free. */
/** @see     avago_serdes_link_init_config_construct(), avago_serdes_init(). */
BOOL avago_serdes_link_init(Avago_serdes_link_init_config_t *config)
{
    Aapl_t *aapl_a = config->aapl_a;
    Aapl_t *aapl_b = config->aapl_a;
    BOOL result = TRUE;
    uint errors_a, errors_b;

    if (aapl_check_broadcast_address(aapl_a, config->addr_a, __func__, __LINE__, TRUE)) return -1;
    if (aapl_check_broadcast_address(aapl_b, config->addr_b, __func__, __LINE__, TRUE)) return -1;
    if (!aapl_check_ip_type(aapl_a, config->addr_a, __func__, __LINE__, FALSE, 1, AVAGO_SERDES)) return -1;
    if (!aapl_check_ip_type(aapl_b, config->addr_b, __func__, __LINE__, FALSE, 1, AVAGO_SERDES)) return -1;
    if (!aapl_check_process(aapl_a, config->addr_a, __func__, __LINE__, FALSE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28)) return -1;
    if (!aapl_check_process(aapl_b, config->addr_b, __func__, __LINE__, FALSE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28)) return -1;

    if (config->info || aapl_a->debug || aapl_b->debug)
        aapl_log_printf(aapl_a, AVAGO_INFO, __func__, __LINE__, "Running SerDes Link Init.            SerDes A: %s div %d/%d, SerDes B: %s div %d/%d\n",
            aapl_addr_to_str(config->addr_a), config->serdes_config_a->tx_divider, config->serdes_config_a->rx_divider,
            aapl_addr_to_str(config->addr_a), config->serdes_config_b->tx_divider, config->serdes_config_b->rx_divider);

    /* Force ELB mode for SerDes init -- NOTE: Changes passed in config struct */
    config->serdes_config_a->init_mode = AVAGO_PRBS31_ELB;
    config->serdes_config_b->init_mode = AVAGO_PRBS31_ELB;

    errors_a = avago_serdes_init(aapl_a, config->addr_a, config->serdes_config_a);
    errors_b = avago_serdes_init(aapl_b, config->addr_b, config->serdes_config_b);

    if (config->info || aapl_a->debug || aapl_b->debug)
        aapl_log_printf(aapl_a, AVAGO_INFO, __func__, __LINE__, "SerDes init complete. Errors in ILB: SerDes A: %d, Serdes B: %d.\n", errors_a, errors_b);

    if (errors_a || errors_b) return FALSE; /* failed due to errors in ILB */

    if (config->info || aapl_a->debug || aapl_b->debug)
    {
        avago_serdes_get_errors(aapl_a, config->addr_a, AVAGO_LSB, 1);    /* To clear */
        avago_serdes_get_errors(aapl_b, config->addr_b, AVAGO_LSB, 1);    /* To clear */
        errors_a  = avago_serdes_get_errors(aapl_a, config->addr_a, AVAGO_LSB, 1);    /* To read */
        errors_b  = avago_serdes_get_errors(aapl_b, config->addr_b, AVAGO_LSB, 1);    /* To read */
        aapl_log_printf(aapl_a, AVAGO_INFO, __func__, __LINE__, "Errors after loopback disabled.      SerDes A: %d. Serdes B: %d.\n", errors_a, errors_b);
    }

    if (config->dfe_tune) /* Start DFE tuning, then wait for it to complete */
    {
        avago_serdes_dfe_tune(aapl_a, config->addr_a, config->serdes_dfe_config_a);
        avago_serdes_dfe_tune(aapl_b, config->addr_b, config->serdes_dfe_config_b);
        avago_serdes_dfe_wait(aapl_a, config->addr_a);
        avago_serdes_dfe_wait(aapl_b, config->addr_b);
    }

    avago_serdes_set_rx_cmp_mode(aapl_a, config->addr_a, AVAGO_SERDES_RX_CMP_MODE_MAIN_PATGEN); /* reset patgen and enable error counter after DFE tuning */
    avago_serdes_set_rx_cmp_mode(aapl_b, config->addr_b, AVAGO_SERDES_RX_CMP_MODE_MAIN_PATGEN);

    avago_serdes_get_errors(aapl_a, config->addr_a, AVAGO_LSB, 1);    /* To clear */
    avago_serdes_get_errors(aapl_b, config->addr_b, AVAGO_LSB, 1);    /* To clear */
    errors_a  = avago_serdes_get_errors(aapl_a, config->addr_a, AVAGO_LSB, 1);    /* To read */
    errors_b  = avago_serdes_get_errors(aapl_b, config->addr_b, AVAGO_LSB, 1);    /* To read */

    if (errors_a) /* if errors, try enabling polarity inversion */
    {
        avago_serdes_set_rx_invert(aapl_a, config->addr_a, TRUE);
        avago_serdes_get_errors(aapl_a, config->addr_a, AVAGO_LSB, 1);    /* To clear */
        errors_a = avago_serdes_get_errors(aapl_a, config->addr_a, AVAGO_LSB, 1);    /* To read */
        if (errors_a) avago_serdes_set_rx_invert(aapl_a, config->addr_a, FALSE);
    }
    if (errors_b) /* if errors, try enabling polarity inversion */
    {
        avago_serdes_set_rx_invert(aapl_b, config->addr_b, TRUE);
        avago_serdes_get_errors(aapl_b, config->addr_b, AVAGO_LSB, 1);    /* To clear */
        errors_b = avago_serdes_get_errors(aapl_b, config->addr_b, AVAGO_LSB, 1);    /* To read */
        if (errors_b) avago_serdes_set_rx_invert(aapl_b, config->addr_b, FALSE);
    }

    if (config->info || aapl_a->debug || aapl_b->debug)
        aapl_log_printf(aapl_a, AVAGO_INFO, __func__, __LINE__, "Final error count.                   SerDes A: %d. Serdes B: %d.\n", errors_a, errors_b);

    if (errors_a || errors_b) result = FALSE; /* failed due to errors in ELB. Don't return, as the errors may be due to a problem with the interconnect */

#   if AAPL_ENABLE_EYE_MEASUREMENT
    if (config->eye)
    {
        Avago_serdes_eye_config_t *eye_config = avago_serdes_eye_config_construct(aapl_a);
        Avago_serdes_eye_data_t *eye_data = avago_serdes_eye_data_construct(aapl_a);

        eye_config->ec_eye_type = AVAGO_EYE_SIZE;
        avago_serdes_eye_get(aapl_a, config->addr_a, eye_config, eye_data);

        avago_serdes_eye_vbtc_log_print(aapl_a, AVAGO_INFO, __func__, __LINE__, &eye_data->ed_vbtc[0]);
        avago_serdes_eye_hbtc_log_print(aapl_a, AVAGO_INFO, __func__, __LINE__, &eye_data->ed_hbtc[0]);
        /*avago_serdes_eye_plot_log_print(aapl_a, AVAGO_INFO, __func__, __LINE__, eye_data); */

        avago_serdes_eye_get(aapl_a, config->addr_b, eye_config, eye_data);

        avago_serdes_eye_vbtc_log_print(aapl_b, AVAGO_INFO, __func__, __LINE__, &eye_data->ed_vbtc[0]);
        avago_serdes_eye_hbtc_log_print(aapl_b, AVAGO_INFO, __func__, __LINE__, &eye_data->ed_hbtc[0]);
        /*avago_serdes_eye_plot_log_print(aapl_a, AVAGO_INFO, __func__, __LINE__, eye_data); */

        avago_serdes_eye_config_destruct(aapl_a, eye_config);
        avago_serdes_eye_data_destruct(aapl_a, eye_data);
    }
#   endif /* AAPL_ENABLE_EYE_MEASUREMENT */

    return result;
}

