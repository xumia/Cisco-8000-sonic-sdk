/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* MAIN program for the dfe command. */

/** Doxygen File Header */
/** @file */
/** @brief Launch wrapper for DFE functions. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS

#include "aapl.h"

#if AAPL_ENABLE_MAIN

static int show_dfe_help()
{
    aapl_common_main_help(TRUE);
    printf(
"-display       Display DFE state information.\n"
"-status        Display DFE status value.\n"
"-table         Display full DFE table.\n"
"-get-row-col <row>,<col>  Display given row/column of DFE table.\n"
"                      May repeat option up to 10 times.\n"
"-set-row-col <row>,<col>,<val>  Set given row/column of DFE table to <val>.\n"
"                      May repeat option up to 10 times.\n"
"-set-tap1 <int>       Set tap1 value; range [-100..100].\n"
"-get-eye-metric       Get a simple eye metric. Requires tuning first.\n"
"\n");
    printf(
"-set-all-dfe <str>    Set DFE values from the output of device-info or AAPL\n"
"                      diag. Paste entire line in quotes.\n");
    printf(
"-rr-enable     Enable round-robin pCal participation.\n"
"-rr-disable    Disable round-robin pCal participation.\n"
"-rr-run        Trigger a round-robin pCal execution.\n"
"-rr-status     Display the round-robin pCal participation status.\n"
"\n");
    printf(
"-tune                 Start a default initial tune (iCal and perhaps pCal).\n"
"-ical-tune            Start an iCal.\n"
"-mini-ical            Start a mini iCal.\n"
"-pcal-tune            Start a single shot pCal.\n"
"-start-adaptive       Start adaptive periodic calibration.\n"
"-stop-adaptive        Stop adaptive periodic calibration.\n"
"-dwell-time <bits>    Set DFE tuning dwell time, in bits.\n"
"\n");
    printf(
"-pause-dfe               Pause DFE operations.  Waits for any current action to complete.\n"
"-resume-dfe              Enable running of new DFE iterations.\n"
"-wait                    Wait a default amount of time for DFE to complete.\n"
"-wait-timeout <seconds>  Wait <seconds> amount of time for DFE to complete.\n"
"\n"
);
#if AAPL_ENABLE_DIAG
    printf(
"-fixed-dc <num>       Set DC to num and set fixed_dc tune flag.\n"
"-fixed-lf <num>       Set LF to num and set fixed_lf tune flag.\n"
"-fixed-hf <num>       Set HF to num and set fixed_hf tune flag.\n"
"-fixed-bw <num>       Set BW to num and set fixed_bw tune flag.\n"
"                      Set num = -1 to disable fixed setting.\n"
"                      Must be combined with a tune request.\n"
);
    printf(
"-repeat <num>         Calls the dfe_repeat function iterating <num> times.\n"
"-logger <name>        Calls the dfe logger function with given firmware table file.\n"
);
    printf(
"-sas-logger <name>    Calls the sas logger function with given firmware table file.\n"
"-sas-mhz              Set SAS mhz (default=100, or 300).\n"
"-sas-pre              Set SAS pre value.\n"
"-sas-post             Set SAS post value.\n"
"-sas-debug-log-type   Set SAS DEBUG log_type: 0-none, 1-dfe_logger, 2-sas single step. (0 - default)\n"
"-sas-debug-log-iter   Set SAS DEBUG log_iter: iteration of sas_logger to invoke sub-logging (-1 none, default).\n"
);
    printf(
"-sas-debug-log-steps  Set SAS DEBUG log_steps: number of single steps.(0 - default)\n"
"                        default: log_type=0 (none),        log_iter=-1,                                     log_steps=0\n"
"                        example: log_type=1 (dfe),         log_iter=12 (from experiment, PMD_RX_ICAL),      log_steps=0\n"
"                        example: log_type=2 (single step), log_iter=11 (from experiment, PMD_RX_POST_INIT), log_steps=1000\n"
);
    printf(
"-hal-get table,index        Read table[index].\n"
"-hal-set table,index,value  Set table[index] to value.\n"
);
#endif /* AAPL_ENABLE_DIAG */
    return 1;
}

#if AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO
typedef enum
{
    AVAGO_SAS_COEFF_REF1,
    AVAGO_SAS_COEFF_REF2,
    AVAGO_SAS_COEFF_NOEQ,
    AVAGO_SAS_COEFF_NA
    /* If new enums are added here, add them to serdes/str_conv.c as well! */
} Avago_sas_coeff_t;

static int run_sas_logger(Aapl_t *aapl,
                          uint addr,
                          const char *sas_logger,
                          int sas_mhz,
                          int sas_pre,
                          int sas_post,
                          int sas_debug_log_type,
                          int sas_debug_log_iter,
                          int sas_debug_log_steps,
                          Avago_sas_coeff_t at_start,
                          Avago_sas_coeff_t at_training)
{
    int i;
    int result = 0;
    int sas_tune_cmd = 0x2;
    int sas_refclk_ratio = 0;
    int sas_iterations = 200;

    /* for test mode */
    BOOL test_data = (at_start != AVAGO_SAS_COEFF_NA && at_training != AVAGO_SAS_COEFF_NA);
    int ref1_km1;
    int ref2_km1;
    int noeq_km1;
    int ref1_k0;
    int ref2_k0;
    int noeq_k0;
    int ref1_kp1;
    int ref2_kp1;
    int noeq_kp1;
    int pmd_km1;
    int pmd_k0;
    int pmd_kp1;

    avago_serdes_sas_addrs( aapl,
                            sas_logger,
                            &ref1_km1,
                            &ref2_km1,
                            &noeq_km1,
                            &ref1_k0,
                            &ref2_k0,
                            &noeq_k0,
                            &ref1_kp1,
                            &ref2_kp1,
                            &noeq_kp1,
                            &pmd_km1,
                            &pmd_k0,
                            &pmd_kp1);

    printf("Running SAS training on SBus address :%s\n", aapl_addr_to_str(addr));

    if (!test_data) {
        /* Get Chip data */
        aapl_get_ip_info(aapl, 0);
        aapl_print_struct(aapl, 1, 0xffff, AVAGO_UNKNOWN_IP);
    }

    /* Cleanup any overrides/breakpoints that may not have been cleared */
    avago_sbus_wr(aapl, addr, 1, 0x20000000);
    avago_sbus_wr(aapl, addr, 0x20, 0);

    /*NOTE: from logger script, not enabled here */
    /*avago_serdes_set_rx_input_loopback(aapl, addr, FALSE); */
    /*avago_serdes_set_rx_term(aapl, addr, AVAGO_SERDES_RX_TERM_FLOAT); */

    /* expect user to have run aapl serdes-init to set -ilb or -elb */
    /* sas_mhz = 100 requires hw refclk = 100.00 via aacs (not sure how this can be done with aview) */
    /* sas_mhz = 300 requires hw refclk = 156.25 via aacs (not sure how this can be done with aview) */

    /* from DCSG, EnterBypass */
    if (sas_mhz == 100) sas_refclk_ratio = 0x0078; /* Sas100MHz - 12G / 100M = 120 -> 'h78 */
    if (sas_mhz == 300) sas_refclk_ratio = 0x0028; /* Sas300MHz - 12G / 300M = 40 -> 'h28 */
    avago_spico_int(aapl, addr, 0x01, 0x0000); /* serdes disable */
    avago_spico_int(aapl, addr, 0x20, 0x0000); /* enable bypass mode (disable PCIe mode) */

    /* Redmine 2903 required clearing TX_ELEC_IDLE_GATE for HVD6/DCSG, but when using Pikes, this breaks */
    /* SAS training evaluation in ELB.  The following work around re-sets that bit. */
    /* Alternatively, we could have skipped Spico Int 0x20 above which resets bypass mode, since */
    /* this hardware never changed to PCIE mode. */
    avago_serdes_mem_rmw(aapl, addr, AVAGO_DMEM, 0x21, 0x0080, 0x0080); /* tx_data, bit[7] is TX_ELEC_IDLE_GATE */

    avago_spico_int(aapl, addr, 0x14, 0x0033); /* Tx width & Rx width set to 40-bit */
    avago_spico_int(aapl, addr, 0x0c,0x0100); /* enable f66 autoslip */
    avago_spico_int(aapl, addr, 0x0b,0x0000); /* disable phase cal (beacon) */

    /* expect user to have run aapl serdes-init to set -ilb or -elb */
    /*avago_spico_int(aapl, addr, 0x08, 0x0101); // ILB */
    /*avago_spico_int(aapl, addr, 0x08, 0x0100); // ELB */

    avago_spico_int(aapl, addr, 0x05, (0x9100|sas_refclk_ratio)); /* apply to Tx and Rx, set serdes as reflclk master, refclk ratio */
    avago_spico_int(aapl, addr, 0x30, 0x0000); /* spico set to refclk */
    avago_spico_int(aapl, addr, 0x0d, 0x8000); /* tx phase slip - based on physical layout (STA) */
    avago_spico_int(aapl, addr, 0x0e, 0x8000); /* rx phase slip */
    avago_spico_int(aapl, addr, 0x20, 0x0020); /* enable RX Idle Detector */
    avago_spico_int(aapl, addr, 0x27, 0x0000); /* disable core_to_cntl rx_en and tx_en */
    avago_spico_int(aapl, addr, 0x11, 0x0000); /* disable PLL recal when rx/tx_en re-asserted */
    avago_spico_int(aapl, addr, 0x21, 0x0000); /* PCIe_GEN3_DeEmphasis_Preset */
    avago_spico_int(aapl, addr, 0x15, 0x0000); /* TX_EQ_Control */
    avago_spico_int(aapl, addr, 0x3d, 0x0000); /* PMD_Config - reset all parameters */

    if (test_data) {
        /*use Spico Int 0x3d to set defaults for REF1/REF2/NOEQ */
        /*   DATA[15:12]- Select */
        /*         0x09-0xC - Update "goto" setting */
        /*                   DATA[15:12] */
        /*                          0x9 - Change pre-cursor */
        /*                          0xA - Change cursor */
        /*                          0xB - Change post-cursor */
        /*                          0xC - Change All (pre,curosr,post) */
        /*                   DATA[11:10] : */
        /*                          0x0 - Intialize/REF1 */
        /*                          0x1 - REF2 (only used in SAS/SATA mode) */
        /*                          0x2 - Preset/No Eq */
        /*                    DATA[7:0] Value */
        avago_spico_int(aapl, addr, 0x3d, 0x9001); /* ref1_km1 */
        avago_spico_int(aapl, addr, 0x3d, 0x9404); /* ref2_km1 */
        avago_spico_int(aapl, addr, 0x3d, 0x9807); /* noeq_km1 */
        avago_spico_int(aapl, addr, 0x3d, 0xa002); /* ref1_k0 */
        avago_spico_int(aapl, addr, 0x3d, 0xa405); /* ref2_k0 */
        avago_spico_int(aapl, addr, 0x3d, 0xa808); /* noeq_k0 */
        avago_spico_int(aapl, addr, 0x3d, 0xb003); /* ref1_kp1 */
        avago_spico_int(aapl, addr, 0x3d, 0xb406); /* ref2_kp1 */
        avago_spico_int(aapl, addr, 0x3d, 0xb809); /* noeq_kp1 */
        sas_iterations = 5; /* only look for transition from start to training */

        /*use Spico Int 0x3d to select which to initialize with REF1/REF2/NOEQ */
        /*   DATA[15:12]- Select */
        /*         0x02 - PMD Training behavior */
        /*                DATA[0] - Reseed Enable      - (default 0/off) */
        /*                DATA[1] - Random Seed Enable - (default 0/off) */
        /*                DATA[2] - Respond MAX on k0 tran to 0                      - (default 0/off) */
        /*                DATA[3] - Respond MIN on max_eq transition to max_total_eq - (default 0/off) */
        /*              GEN2 only */
        /*                DATA[5:4] TxEq setting transmitter used at training startup. - */
        /*                          0-INITIALIZE/REF1 (default) */
        /*                          1-REF2 */
        /*                          2-PRESET/NoEq */
        /*                DATA[9:8] TxEq setting requested by firmware at startup - */
        /*                          0-PRESET/NoEq (default) */
        /*                          1-REF2 */
        /*                          2-INITIAL/REF1 */
        i = 0x2800;
        switch (at_start) {
            case AVAGO_SAS_COEFF_REF2: i |= 0x0010; break; /* 4/5/6 -> */
            case AVAGO_SAS_COEFF_NOEQ: i |= 0x0020; break; /* 7/8/9 -> */
            case AVAGO_SAS_COEFF_REF1:
            default:                   i |= 0x0000; break; /* 1/2/3 -> */
        }
        switch (at_training) {
            case AVAGO_SAS_COEFF_REF2: i |= 0x0900; break; /*        -> 4/5/6 */
            case AVAGO_SAS_COEFF_REF1: i |= 0x0a00; break; /*        -> 1/2/3 */
            case AVAGO_SAS_COEFF_NOEQ:
            default:                   i |= 0x0000; break; /*        -> 7/8/9 */
        }
        /*printf("%d %d 0x%04x\n", at_start, at_training, i); */
        avago_spico_int(aapl, addr, 0x3d, i);
    }

    avago_spico_int(aapl, addr, 0x3d, 0x1800); /* PMD_Config - enable SAS/SATA mode */
    avago_spico_int(aapl, addr, 0x01, 0x0007); /* SerDes_Enable - TxEn[0] / RxEn[1] / OutputEn[3] */

    sas_tune_cmd = 0x0002;
    sas_tune_cmd |= (sas_pre & 0xF) << 8;
    sas_tune_cmd |= (sas_post & 0xF) << 12;

    avago_serdes_sas_logger(aapl, addr, sas_tune_cmd, sas_logger, sas_iterations, sas_debug_log_type, sas_debug_log_iter, sas_debug_log_steps);

    /*avago_serdes_sas_logger(aapl, addr, sas_tune_cmd, sas_logger, sas_iterations, */
    /*                        0,           // log_type: 0-none, 1-dfe_logger, 2-sas single step */
    /*                        -1,          // log_iter: iteration of sas_logger to invoke sub-logging (-1 none) */
    /*                        0);          // log_steps: number of single steps */

    /*DEBUG example */
    /*avago_serdes_sas_logger(aapl, addr, sas_tune_cmd, sas_logger, sas_iterations, */
    /*                        2,           // sas single step */
    /*                        11,          // from experiment, PMD_RX_POST_INIT */
    /*                        100000); */

    /*DEBUG example */
    /*avago_serdes_sas_logger(aapl, addr, sas_tune_cmd, sas_logger, sas_iterations, */
    /*                        1,           // dfe log */
    /*                        12,          // from experiment, PMD_RX_ICAL */
    /*                        0); */

    if (test_data) {
        /* dump and validate */
        i = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, ref1_km1); printf("%10s: %04x\n","ref1_km1", i );
        if (i != 1) { printf ("ERROR: does not match test data\n"); result = 1; }
        i = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, ref2_km1); printf("%10s: %04x\n","ref2_km1", i );
        if (i != 4) { printf ("ERROR: does not match test data\n"); result = 1; }
        i = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, noeq_km1); printf("%10s: %04x\n","noeq_km1", i );
        if (i != 7) { printf ("ERROR: does not match test data\n"); result = 1; }
        i = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, ref1_k0);  printf("%10s: %04x\n","ref1_k0", i );
        if (i != 2) { printf ("ERROR: does not match test data\n"); result = 1; }
        i = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, ref2_k0);  printf("%10s: %04x\n","ref2_k0", i );
        if (i != 5) { printf ("ERROR: does not match test data\n"); result = 1; }
        i = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, noeq_k0);  printf("%10s: %04x\n","noeq_k0", i );
        if (i != 8) { printf ("ERROR: does not match test data\n"); result = 1; }
        i = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, ref1_kp1); printf("%10s: %04x\n","ref1_kp1", i );
        if (i != 3) { printf ("ERROR: does not match test data\n"); result = 1; }
        i = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, ref2_kp1); printf("%10s: %04x\n","ref2_kp1", i );
        if (i != 6) { printf ("ERROR: does not match test data\n"); result = 1; }
        i = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, noeq_kp1); printf("%10s: %04x\n","noeq_kp1", i );
        if (i != 9) { printf ("ERROR: does not match test data\n"); result = 1; }
        printf("\n");
        i = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pmd_km1);  printf("%10s: %04x\n","pmd_km1", i );
        switch (at_training) {
            case AVAGO_SAS_COEFF_REF2: if (i != 4) { printf ("ERROR: does not match, expect 4\n"); result = 1; } break;
            case AVAGO_SAS_COEFF_REF1: if (i != 1) { printf ("ERROR: does not match, expect 1\n"); result = 1; } break;
            case AVAGO_SAS_COEFF_NOEQ:
            default:                   if (i != 7) { printf ("ERROR: does not match, expect 7\n"); result = 1; } break;
        }
        i = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pmd_k0);   printf("%10s: %04x\n","pmd_k0", i );
        switch (at_training) {
            case AVAGO_SAS_COEFF_REF2: if (i != 5) { printf ("ERROR: does not match, expect 5\n"); result = 1; } break;
            case AVAGO_SAS_COEFF_REF1: if (i != 2) { printf ("ERROR: does not match, expect 2\n"); result = 1; } break;
            case AVAGO_SAS_COEFF_NOEQ:
            default:                   if (i != 8) { printf ("ERROR: does not match, expect 8\n"); result = 1; } break;
        }
        i = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pmd_kp1);  printf("%10s: %04x\n","pmd_kp1", i );
        switch (at_training) {
            case AVAGO_SAS_COEFF_REF2: if (i != 6) { printf ("ERROR: does not match, expect 6\n"); result = 1; } break;
            case AVAGO_SAS_COEFF_REF1: if (i != 3) { printf ("ERROR: does not match, expect 3\n"); result = 1; } break;
            case AVAGO_SAS_COEFF_NOEQ:
            default:                   if (i != 9) { printf ("ERROR: does not match, expect 9\n"); result = 1; } break;
        }
        printf("\n");
    }

    if (!test_data) {
        Avago_serdes_pmd_debug_t *sas_dbg = avago_serdes_pmd_debug_construct(aapl);
        avago_serdes_pmd_debug(aapl, addr, sas_dbg);
        avago_serdes_pmd_debug_print(aapl, sas_dbg);
        avago_serdes_pmd_debug_destruct(aapl, sas_dbg);
    }
    return result;
}
#endif /* AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO */

static int parse_comma_ints(char *optarg, const char *name, int *v1, int *v2, int *v3)
{
    char *sep, *ptr = optarg;
    sep = strchr(ptr,',');
    if( sep ) *sep++ = '\0';
    *v1 = aapl_num_from_str(ptr, name, 0);
    if( !sep ) return 1;

    sep = strchr(ptr = sep,',');
    if( sep ) *sep++ = '\0';
    *v2 = aapl_num_from_str(ptr, name, 0);
    if( !sep ) return 2;

    sep = strchr(ptr = sep,',');
    if( sep ) *sep++ = '\0';
    *v3 = aapl_num_from_str(ptr, name, 0);
    return 3;
}

int aapl_dfe_main(int argc, char *argv[], Aapl_t *aapl)
{
    uint         addr;
    Avago_addr_t addr_struct;
    BOOL         have_user_selection = FALSE;
    int rc, index = 0, i;
    uint dfe_status = 0;
#if AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO
    int repeat = 0;
    const char *logger = 0;
    const char *sas_logger = 0;
    int sas_mhz = 100;
    int sas_pre = 0;
    int sas_post = 0;
    int sas_debug_log_type = 0;
    int sas_debug_log_iter = -1;
    int sas_debug_log_steps = 0;
    BOOL btc = FALSE;
    BOOL pcie = FALSE;
    BOOL kr = FALSE;
    BOOL mini_ical = FALSE;
#endif /* AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO */
    int fixed_dc = -2;
    int fixed_lf = -2;
    int fixed_hf = -2;
    int fixed_bw = -2;
    char *hal_get = 0;
    char *hal_set = 0;

    Avago_serdes_dfe_tune_t tune_control;
    BOOL ical_tune = FALSE, pcal_tune = FALSE;
    BOOL adaptive_start = FALSE, adaptive_stop = FALSE;
    BOOL rr_enable = FALSE, rr_disable = FALSE, rr_run = FALSE;
    BOOL rr_status = FALSE;
    BOOL get_table = FALSE;
    BOOL display = FALSE, status = FALSE;
    BOOL pause = FALSE, wait = FALSE, resume = FALSE;
    int wait_timeout = 0;
    BOOL get_eye_metric = FALSE;
    int rd_table[10], rd_table_cnt = 0;
    int wr_table[10], wr_table_cnt = 0;
    int new_tap1 = -1000;
    char * set_all_dfe = 0;
    uint dwell = 0;
    Avago_addr_t start, stop, next; BOOL st;
    BOOL vos_cal = FALSE;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"display",              0, NULL,  1 },
        {"status",               0, NULL,  2 },
        {"get-row-col",          1, NULL,  3 },
        {"set-row-col",          1, NULL,  4 },
        {"table",                0, NULL,  5 },
        {"set-tap1",             1, NULL,  6 },
        {"get-eye-metric",       0, NULL,  7 },

        {"pause-dfe",            0, NULL, 14 },
        {"resume-dfe",           0, NULL, 15 },
        {"wait",                 0, NULL, 16 },
        {"wait-dfe",             0, NULL, 16 },
        {"wait-timeout",         1, NULL, 17 },
        {"set-all-dfe",          1, NULL, 18 },

        {"rr-enable",            0, NULL, 21 },
        {"rr-disable",           0, NULL, 22 },
        {"rr-run",               0, NULL, 23 },
        {"rr-status",            0, NULL, 24 },

        {"tune",                 0, NULL, 30 },
        {"ical-tune",            0, NULL, 31 },
        {"pcal-tune",            0, NULL, 32 },
        {"start-adaptive",       0, NULL, 33 },
        {"stop-adaptive",        0, NULL, 34 },
        {"dwell-time",           1, NULL, 35 },

#if AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO
        {"repeat",               1, NULL, 40 },
        {"logger",               1, NULL, 41 },  /* TODO: port dfe parameters from AAPL/ruby/lib/logger parameters */
                                                 /* TODO: port kr logger and parameters from AAPL/ruby/lib/logger parameters */
                                                 /* TODO: port pcie logger and parameters from AAPL/ruby/lib/logger parameters */
        {"sas-logger",           1, NULL, 42 },
        {"sas-mhz",              1, NULL, 43 },
        {"sas-pre",              1, NULL, 44 },
        {"sas-post",             1, NULL, 45 },
        {"sas-debug-log-type",   1, NULL, 46 },
        {"sas-debug-log-iter",   1, NULL, 47 },
        {"sas-debug-log-steps",  1, NULL, 48 },
        {"pcie",                 0, NULL, 49 },
        {"btc",                  0, NULL, 54 },
        {"mini-ical",            0, NULL, 55 },
        {"kr",                   0, NULL, 58 },
#endif /* AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO */
        {"fixed-dc",             1, NULL, 50 },
        {"fixed-lf",             1, NULL, 51 },
        {"fixed-hf",             1, NULL, 52 },
        {"fixed-bw",             1, NULL, 53 },
        {"hal-get",              1, NULL, 56 },
        {"hal-set",              1, NULL, 57 },
        {"vos-cal",              0, NULL,130 },

        {0,                      0, NULL,  0 }
    };

    avago_addr_to_struct(aapl_default_device_addr, &addr_struct);
    if (aapl_common_main_options(aapl, argc, argv, /*sbus_addr*/ &addr_struct) < 0)
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_dfe_help();
    }
    addr = avago_struct_to_addr(&addr_struct);

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        have_user_selection = TRUE;
        switch( rc )
        {
        case  1 : display = TRUE; break;
        case  2 : status  = TRUE; break;
        case  3 :
        if( rd_table_cnt >= 10 )
            aapl_main_error("Too many -get-row-col options\n");
        {
            int row, col;
            char *sep = strchr(optarg,',');
            if( !sep || !sep[1] || sep == optarg )
                aapl_main_error("Invalid -get-row-col option, must be <row>,<col>. Got: \"%s\".\n", optarg);
            *sep = '\0';
            sep++;
            row = aapl_num_from_str(optarg, name, 0);
            col = aapl_num_from_str(sep   , name, 0);
            rd_table[rd_table_cnt++] = row << 8 | col << 12;
            break;
        }
        case  4:
        if( wr_table_cnt >= 10 )
            aapl_main_error("Too many -set-row-col options\n");
        {
            int row, col, val;
            char *sep = strchr(optarg,',');
            char *sep2 = strrchr(optarg,',');
            if( !sep || !sep[1] || sep == optarg || sep == sep2 || !sep2[1] )
                aapl_main_error("Invalid -set-row-col option, must be <row>,<col>,<val>. Got: \"%s\".\n", optarg);
            *sep++ = '\0';
            *sep2++ = '\0';
            row = aapl_num_from_str(optarg, name, 0);
            col = aapl_num_from_str(sep   , name, 0);
            val = aapl_num_from_str(sep2  , name, 0);
            if ( (val < 0) && (col == 3) && (row > 0) ) { /* only dfe taps support neg values */
              val *= -1; /* convert to sign magnitude */
              col |=  8; /* set sign bit */
            }
            wr_table[wr_table_cnt++] = row << 8 | col << 12 | (val & 0xff);
            break;
        }
        case  5: get_table = TRUE; break;
        case  6: new_tap1 = aapl_num_from_str(optarg, name, 0); break;
        case  7: get_eye_metric = TRUE; break;

        case 14: pause   = TRUE; break;
        case 15: resume  = TRUE; break;
        case 16: wait    = TRUE; break;
        case 17: wait    = TRUE; wait_timeout = aapl_num_from_str(optarg, name, 0); break;
        case 18:
        {
            set_all_dfe = (char *)aapl_realloc(aapl, set_all_dfe, strlen(optarg)+1,__func__);
            strncpy(set_all_dfe, optarg, strlen(optarg)+1);
        }
        break;
        case 21: rr_enable  = TRUE; break;
        case 22: rr_disable = TRUE; break;
        case 23: rr_run     = TRUE; break;
        case 24: rr_status  = TRUE; break;

        case 30: ical_tune = pcal_tune = TRUE; break;
        case 31: ical_tune      = TRUE; break;
        case 32: pcal_tune      = TRUE; break;
        case 33: adaptive_start = TRUE; break;
        case 34: adaptive_stop  = TRUE; break;
        case 35: dwell = aapl_num_from_str(optarg, name, 0); break;

#if AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO
        case 40: repeat = aapl_num_from_str(optarg, name, 0); break;
        case 41: logger = optarg; break;

        case 42: sas_logger = optarg; break;
        case 43: sas_mhz    = aapl_num_from_str(optarg, name, 0);
                 if (sas_mhz != 100 && sas_mhz != 300)
                     aapl_main_error("sas-mhz must be 100 or 300.");
                 break;
        case 44: sas_pre              = aapl_num_from_str(optarg, name, 0); break;
        case 45: sas_post             = aapl_num_from_str(optarg, name, 0); break;
        case 46: sas_debug_log_type   = aapl_num_from_str(optarg, name, 0); break;
        case 47: sas_debug_log_iter   = aapl_num_from_str(optarg, name, 0); break;
        case 48: sas_debug_log_steps  = aapl_num_from_str(optarg, name, 0); break;
        case 49: pcie = TRUE; break;
        case 54: btc = TRUE; break;
        case 55: mini_ical = TRUE; break;
        case 58 : kr = TRUE; break;
#endif /* AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO */
        case 50: fixed_dc = aapl_num_from_str(optarg, name, 0); break;
        case 51: fixed_lf = aapl_num_from_str(optarg, name, 0); break;
        case 52: fixed_hf = aapl_num_from_str(optarg, name, 0); break;
        case 53: fixed_bw = aapl_num_from_str(optarg, name, 0); break;
        case 56 : hal_get = optarg; break;
        case 57 : hal_set = optarg; break;
        case 130: vos_cal = TRUE; break;

        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    /* No args are allowed beyond options: */
    if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    if( !have_user_selection )
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_dfe_help();
    }

/* Prepare a connection to the device: */
/* */
    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
    aapl_get_ip_info(aapl,0);
    if( aapl_get_return_code(aapl) < 0 )
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "aapl_get_ip_info returned a negative value.\n");


    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, 0); st; st = aapl_broadcast_next(aapl, &next, &start, &stop, 0) )
    {
        addr = avago_struct_to_addr(&next);
        if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, FALSE, 6,
                                    AVAGO_SERDES, AVAGO_SERDES_D6_BROADCAST,
                                    AVAGO_M4,     AVAGO_SERDES_M4_BROADCAST,
                                    AVAGO_P1,     AVAGO_SERDES_P1_BROADCAST) ) continue;
        avago_serdes_tune_init(aapl, &tune_control);

        if(      fixed_dc >=  0 ) { tune_control.fixed[0] = 1; tune_control.value[0] = fixed_dc; }
        else if( fixed_dc == -1 )   tune_control.fixed[0] = 0;
        if(      fixed_lf >=  0 ) { tune_control.fixed[1] = 1; tune_control.value[1] = fixed_lf; }
        else if( fixed_lf == -1 )   tune_control.fixed[1] = 0;
        if(      fixed_hf >=  0 ) { tune_control.fixed[2] = 1; tune_control.value[2] = fixed_hf; }
        else if( fixed_hf == -1 )   tune_control.fixed[2] = 0;
        if(      fixed_bw >=  0 ) { tune_control.fixed[3] = 1; tune_control.value[3] = fixed_bw; }
        else if( fixed_bw == -1 )   tune_control.fixed[3] = 0;

        if( vos_cal )
            avago_serdes_pon_vos_cal(aapl, addr);

        if( set_all_dfe )
        {
            char *end;
            char *ptr = set_all_dfe;
            int x = 0;
            aapl_str_to_addr(ptr, &end, &addr);

            ptr = end;
            end = 0;
            for (x=0; x<=25; x++)
            {
                /*Addr DC LF HF BW |d0e 0o 1e 1o|t1e 1o 0e 0o|DFE     1  2  3  4  5  6  7  8  9  A  B  C  D| data height| test height|BER     |Status */
                /*  :a 48 0f 00 00 | 7e 7d 73 7b| 7a 87 7b 76| 7   -1.8 -d -7 -5 -4 -4 -3 -3 -3  0 -3  0  3| 6e 6c 74 73| 36 37 36 36|3.05e-06|0f 80 */
                /* x=   0  1  2  3    4  5  6  7   8  9 10 11  12    13 14 15 16 17 18 19 20 21 22 23 24 25  26 27 28 29  30 31 32 33 */
                int value = aapl_strtol(ptr, &end, 16);
                if (value < 0) value = (value * -1) | 0x8000;

                if      (x == 0) avago_spico_int(aapl, addr, 0x26, 0x2200 | value);
                else if (x == 1) avago_spico_int(aapl, addr, 0x26, 0x2100 | value);
                else if (x == 2) avago_spico_int(aapl, addr, 0x26, 0x2000 | value);
                else if (x == 3) avago_spico_int(aapl, addr, 0x26, 0x2300 | value);
                else if (x <= 11) avago_spico_int(aapl, addr, 0x26, 0x1000 | ((x-4) <<8) | value);
                else if (x == 12) avago_spico_int(aapl, addr, 0x26, 0x3000 | ((x-12)<<8) | value);
                /* tap 1 is set via DVOS settings */
                else if (x <= 25) avago_spico_int(aapl, addr, 0x26, 0x3000 | ((x-13)<<8) | value);

                while (end[0] == '|' || end[0] == ' ') end++; /* move past blanks and "|" characters */
                ptr = end;
            }
        }
        if( hal_set )
        {
            int v1, v2, v3 = 0;
            if( 3 == parse_comma_ints(hal_set, "hal-set", &v1, &v2, &v3) )
            {
                int value = avago_serdes_hal_set(aapl, addr, (Avago_serdes_hal_type_t) v1, v2, v3);
                printf("hal_set(%s, 0x%02x, 0x%02x, 0x%04x); old_value= 0x%04x new_value= 0x%04x\n",
                        aapl_addr_to_str(addr), v1, v2, v3, value, avago_serdes_hal_get(aapl, addr, (Avago_serdes_hal_type_t)v1, v2) );
            }
        }
        else if( hal_get )
        {
            int v1, v2, v3 = 0;
            if( 2 == parse_comma_ints(hal_get, "hal-get", &v1, &v2, &v3) )
            {
                int value = avago_serdes_hal_get(aapl, addr, (Avago_serdes_hal_type_t) v1, v2);
                printf("hal_get(%s,0x%02x,0x%02x) = 0x%04x\n", aapl_addr_to_str(addr), v1, v2, value);
            }
        }
        if( rr_disable )
        {
            tune_control.tune_mode = AVAGO_DFE_DISABLE_RR;
            if( avago_serdes_tune(aapl, addr, &tune_control) )
                printf("SBus %-3s RR pCal participation disabled.\n", aapl_addr_to_str(addr));
            else
                printf("SBus %-3s RR disable failed.\n", aapl_addr_to_str(addr));
        }
        if( rr_run )
        {
            if( 0x0a == avago_spico_int(aapl, addr, 0x0a, 0x04) )
                printf("SBus %-3s RR pCal started\n", aapl_addr_to_str(addr));
            else
                printf("SBus %-3s RR execution failed, RR pCal may be disabled.\n", aapl_addr_to_str(addr));
        }
        if( rr_enable )
        {
            tune_control.tune_mode = AVAGO_DFE_ENABLE_RR;
            if( avago_serdes_tune(aapl, addr, &tune_control) )
                printf("SBus %-3s RR pCal participation enabled.\n", aapl_addr_to_str(addr));
            else
                printf("SBus %-3s RR enable failed.\n", aapl_addr_to_str(addr));
        }
        if( rr_status )
        {
            rc = avago_spico_int(aapl, addr, 0x126, 0x5400);
            printf(" RR enabled = %s (0x%x)\n", aapl_bool_to_str(rc), rc);
        }

        if( dwell )
        {
            Avago_serdes_dfe_state_t dfe_state;
            memset(&dfe_state,0,sizeof(dfe_state));
            avago_serdes_get_dfe_state(aapl, addr, &dfe_state);
            dfe_state.dwell_bits = dwell;
            avago_serdes_dfe_state_ext(aapl, addr, &dfe_state, AVAGO_DFE_MODE_PARAM, TRUE);
#if AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT
            avago_serdes_set_error_timer(aapl, addr, dwell);
#endif /* AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT */
        }

        if( ical_tune && pcal_tune )    /* Start an initial default tune (iCal and perhaps pCal) */
        {
            tune_control.tune_mode = AVAGO_DFE_ICAL;
            if( avago_serdes_tune(aapl, addr, &tune_control) )
                printf("SBus %-3s Initial calibration started.\n", aapl_addr_to_str(addr));
        }
        else if( ical_tune )            /* Start an initial iCal tune w/o pCal */
        {
            tune_control.tune_mode = AVAGO_DFE_ICAL_ONLY;
            if( avago_serdes_tune(aapl, addr, &tune_control) )
                printf("SBus %-3s Initial calibration (iCal only) started.\n", aapl_addr_to_str(addr));
        }
        else if( pcal_tune )            /* Start a one-shot pCal */
        {
            tune_control.tune_mode = AVAGO_DFE_PCAL;
            if( avago_serdes_tune(aapl, addr, &tune_control) )
                printf("SBus %-3s One-time periodic calibration (pCal) started.\n", aapl_addr_to_str(addr));
        }
        else if( adaptive_start )       /* Start continuous adaptive pCal */
        {
            tune_control.tune_mode = AVAGO_DFE_START_ADAPTIVE;
            if( avago_serdes_tune(aapl, addr, &tune_control) )
                printf("SBus %-3s Continuous adaptive tuning started.\n", aapl_addr_to_str(addr));
        }
        else if( adaptive_stop )        /* Stop continuous adaptive pCal */
        {
            tune_control.tune_mode = AVAGO_DFE_STOP_ADAPTIVE;
            if( avago_serdes_tune(aapl, addr, &tune_control) )
                printf("SBus %-3s Continuous adaptive tuning stopped.\n", aapl_addr_to_str(addr));
        }

        if( pause )
        {
            avago_serdes_dfe_pause(aapl, addr, &dfe_status);
            printf("SBus %-3s DFE paused\n", aapl_addr_to_str(addr));
        }
        if( wait )
        {
            if( (wait_timeout == 0 && 1 == avago_serdes_dfe_wait(aapl, addr)) ||
                (wait_timeout  > 0 && 1 == avago_serdes_dfe_wait_timeout(aapl, addr, wait_timeout * 1000)) )
                printf("SBus %-3s DFE complete\n", aapl_addr_to_str(addr));
        }
        if( resume )
        {
            avago_serdes_dfe_resume(aapl, addr, dfe_status);
            printf("SBus %-3s DFE resumed\n", aapl_addr_to_str(addr));
        }

        if( new_tap1 > -128 && new_tap1 < 128 )
        {
            if( 0 == avago_serdes_set_dfe_tap1(aapl, addr, new_tap1) )
                printf("SBus %-3s dfe_tap1 set to %d\n", aapl_addr_to_str(addr), new_tap1);
        }

        if( get_eye_metric )
        {
            uint metric = avago_serdes_eye_get_simple_metric(aapl, addr);
            printf("SBus %-3s Simple eye metric = %u\n", aapl_addr_to_str(addr), metric);
        }

        if( display )
        {
            Avago_serdes_dfe_state_t dfe_state;
            memset(&dfe_state,0,sizeof(dfe_state));
            avago_serdes_get_dfe_state(aapl, addr, &dfe_state);
            avago_serdes_print_dfe(aapl, addr, &dfe_state, FALSE, 1);
#if AAPL_ENABLE_FILE_IO
            avago_write_dfe_state(stdout, &dfe_state);
#endif /* AAPL_ENABLE_FILE_IO */
        }
        if( get_table )
        {
            int r;
            printf("SBus %s\n", aapl_addr_to_str(addr));
            if( aapl_get_ip_type(aapl, addr) == AVAGO_M4 ) {
              printf("Row    Parm    FFE     CTLE    Parm4   EyeH    Parm6   Debug\n");
            } else {
              printf("Row    Parm    VOS     CTLE    TAPS    LEVS    Parm    Debug\n");
            }

            for( r = 0; r < 16; r++ )
            {
                int c;
                printf("%2d: ",r);
                for( c = 0; c < 7; c++ )
                {
                    int int_data = r << 8 | c << 12;
                    int val = avago_spico_int(aapl, addr, 0x126, int_data);
                    if( val & 0x8000 ) /* value is negative */
                        printf(" -0x%04x",  ( ( (val & 0xFFFF) ^ 0xFFFF) + 1));
                    else
                        printf("  0x%04x", val);
                }
                printf("\n");
            }
        }

        for( i = 0; i < rd_table_cnt; i++ )
        {
            int val = avago_spico_int(aapl, addr, 0x126, rd_table[i]);
            printf("SBus %-3s DFE_TABLE[%x,%x] = 0x%x (%d)\n", aapl_addr_to_str(addr),
                (rd_table[i]>> 8)&0xf, (rd_table[i]>>12)&0xf, val, val);
        }
        for( i = 0; i < wr_table_cnt; i++ )
        {
            int val = avago_spico_int(aapl, addr, 0x26, wr_table[i]);
            printf("SBus %-3s DFE_TABLE[%x,%x] = 0x%x (%d)\n", aapl_addr_to_str(addr),
                (wr_table[i]>> 8)&0xf, (wr_table[i]>>12)&0xf, val, val);
        }


#if AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO
        if (repeat)
        {
            Avago_serdes_dfe_repeat_t *config = avago_serdes_dfe_repeat_construct(aapl);
            config->loops = 1; /* do looping here, not in dfe_repeat() */
            if (dwell) config->dfe_state->dwell_bits = dwell;
            if (btc)   config->btc_mode= AVAGO_DFE_REPEAT_BTC_ALL;
            if (ical_tune)  config->dfe_state->tune_mode = AVAGO_DFE_ICAL_ONLY;
            config->pcie_mode = pcie;
            config->pmd_train = kr;

            if(      fixed_dc >=  0 ) { config->dfe_state->fixed_dc = 1; config->dfe_state->dc = fixed_dc; }    /* Set fixed value */
            else if( fixed_dc == -1 )   config->dfe_state->fixed_dc = 0;    /* Unfix value */
        /*  else                        config->dfe_state->fixed_dc = -1;   // Don't change fixed state or value */
            if(      fixed_lf >=  0 ) { config->dfe_state->fixed_lf = 1; config->dfe_state->lf = fixed_lf; }
            else if( fixed_lf == -1 )   config->dfe_state->fixed_lf = 0;
        /*  else                        config->dfe_state->fixed_lf = -1; */
            if(      fixed_hf >=  0 ) { config->dfe_state->fixed_hf = 1; config->dfe_state->hf = fixed_hf; }
            else if( fixed_hf == -1 )   config->dfe_state->fixed_hf = 0;
        /*  else                        config->dfe_state->fixed_hf = -1; */
            if(      fixed_bw >=  0 ) { config->dfe_state->fixed_bw = 1; config->dfe_state->bw = fixed_bw; }
            else if( fixed_bw == -1 )   config->dfe_state->fixed_bw = 0;
        /*  else                        config->dfe_state->fixed_bw = -1; */

            for(i=0; i< repeat; i++)
            {
                avago_serdes_dfe_repeat(aapl, addr, config);
                printf("%s", aapl_log_get(aapl));
                aapl_log_clear(aapl);
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "");
            }
            avago_serdes_dfe_repeat_destruct(aapl, config);
        }
        if( logger )
        {
            if (pcie)
                avago_serdes_pcie_logger(aapl, addr, 1, logger);
            else
            {
                int int_data = 1;
                if( mini_ical )
                    int_data |= 0x10;
                if( !ical_tune && pcal_tune )
                    int_data  = 2;
                if( fixed_dc >= 0 )
                {
                   avago_spico_int(aapl, addr, 0x26, 0x2200 | (fixed_dc & 0xff)); /* DC */
                   int_data |= 0x0080;
                }
                if( fixed_lf >= 0 )
                 {
                   avago_spico_int(aapl, addr, 0x26, 0x2100 | (fixed_lf & 0x0f)); /* LF */
                   int_data |= 0x0100;
                }
                if( fixed_hf >= 0 )
                {
                   avago_spico_int(aapl, addr, 0x26, 0x2000 | (fixed_hf & 0x0f)); /* HF */
                   int_data |= 0x0200;
                }
                if( fixed_bw >= 0 )
                {
                   avago_spico_int(aapl, addr, 0x26, 0x2300 | (fixed_bw & 0x0f)); /* BW */
                   int_data |= 0x0400;
                }
                avago_serdes_dfe_logger(aapl, addr, int_data, logger);
            }
        }
        if (sas_logger)
        {
          run_sas_logger(aapl,
                         addr,
                         sas_logger,
                         sas_mhz,
                         sas_pre,
                         sas_post,
                         sas_debug_log_type,
                         sas_debug_log_iter,
                         sas_debug_log_steps,
                         AVAGO_SAS_COEFF_NA,
                         AVAGO_SAS_COEFF_NA);
    /*This code is toward an automated test for SAS coeff parameters */
    /*TODO: need clean way to reset serdes between each test */
    /*      run_sas_logger(aapl, addr, sas_logger, sas_mhz, sas_pre, sas_post, AVAGO_SAS_COEFF_REF1, AVAGO_SAS_COEFF_NOEQ); // (default)  1/2/3  -> 7/8/9 */
    /*      run_sas_logger(aapl, addr, sas_logger, sas_mhz, sas_pre, sas_post, AVAGO_SAS_COEFF_REF1, AVAGO_SAS_COEFF_REF2); //            1/2/3  -> 4/5/6 */
    /*      run_sas_logger(aapl, addr, sas_logger, sas_mhz, sas_pre, sas_post, AVAGO_SAS_COEFF_REF1, AVAGO_SAS_COEFF_REF1); //            1/2/3  -> 1/2/3 */
    /*      run_sas_logger(aapl, addr, sas_logger, sas_mhz, sas_pre, sas_post, AVAGO_SAS_COEFF_REF2, AVAGO_SAS_COEFF_NOEQ); //            4/5/6  -> 7/8/9 */
    /*      run_sas_logger(aapl, addr, sas_logger, sas_mhz, sas_pre, sas_post, AVAGO_SAS_COEFF_REF2, AVAGO_SAS_COEFF_REF2); //            4/5/6  -> 4/5/6 */
    /*      run_sas_logger(aapl, addr, sas_logger, sas_mhz, sas_pre, sas_post, AVAGO_SAS_COEFF_REF2, AVAGO_SAS_COEFF_REF1); //            4/5/6  -> 1/2/3 */
    /*      run_sas_logger(aapl, addr, sas_logger, sas_mhz, sas_pre, sas_post, AVAGO_SAS_COEFF_NOEQ, AVAGO_SAS_COEFF_NOEQ); //            7/8/9  -> 7/8/9 */
    /*      run_sas_logger(aapl, addr, sas_logger, sas_mhz, sas_pre, sas_post, AVAGO_SAS_COEFF_NOEQ, AVAGO_SAS_COEFF_REF2); //            7/8/9  -> 4/5/6 */
    /*      run_sas_logger(aapl, addr, sas_logger, sas_mhz, sas_pre, sas_post, AVAGO_SAS_COEFF_NOEQ, AVAGO_SAS_COEFF_REF1); //            7/8/9  -> 1/2/3 */
        }
#endif /* AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO */

        if( status )
        {
            Avago_serdes_dfe_state_t dfe_state;
            avago_serdes_get_dfe_state(aapl, addr, &dfe_state);
            printf("SBus %-3s dfe_status: 0x%x (%s)\n",aapl_addr_to_str(addr),dfe_state.status, aapl_dfe_status_to_str(dfe_state.status));
        }
        if (set_all_dfe) aapl_free(aapl, set_all_dfe, __func__);
    }

    avago_addr_delete(aapl, &addr_struct);
    return 0;
}

#endif /* AAPL_ENABLE_MAIN */
