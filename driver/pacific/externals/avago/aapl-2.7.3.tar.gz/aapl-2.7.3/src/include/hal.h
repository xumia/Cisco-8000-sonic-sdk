/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* SerDes HAL types and functions. */

/** Doxygen File Header */
/** @file */
/** @brief AAPL interface to the SerDes HAL interrupt */

#ifndef AAPL_SERDES_HAL_H_
#define AAPL_SERDES_HAL_H_

#include "aapl.h"

/**@brief CTLE parameters */
typedef struct
{
    short hf;                  /**< High-frequency setting */
    short lf;                  /**< Low-frequency setting */
    short dc;                  /**< DC-restore value */
    short bw;                  /**< Band-width setting */
    short gainshape1;          /**< Gainshape1 setting */
    short gainshape2;          /**< Gainshape2 setting */
    short short_channel_en;    /**< Short channel enable setting */
    short hf_min;
    short hf_max;
    short lf_min;
    short lf_max;

} Avago_serdes_ctle_t;

/**@brief valid limit of CTLE parameters */
typedef struct
{
    short hf_max;                 /**< Maximum high-Frequency value */
    short lf_max;                 /**< Maximum low-Frequency value */
    short dc_max;                 /**< Maximum dC-Restore value */
    short dc_min;                 /**< Minimum dC-Restore value */
    short bw_max;                 /**< Maximum band-width value */
    short gainshape1_max;         /**< Maximum gainshape1 value */
    short gainshape2_max;         /**< Maximum gainshape2 value */
    short short_channel_en_max;   /**< Maximum short channel enable value */

} Avago_serdes_ctle_limits_t;

EXT int avago_serdes_ctle_get_limits(Aapl_t *aapl, uint addr, Avago_serdes_ctle_limits_t *limits);

EXT int   avago_serdes_ctle_apply(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_ctle_t *ctle);
EXT char *avago_serdes_ctle_print(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_ctle_t *ctle);
EXT int   avago_serdes_ctle_read( Aapl_t *aapl, uint addr,            Avago_serdes_ctle_t *ctle);
EXT int   avago_serdes_ctle_write(Aapl_t *aapl, uint addr,            Avago_serdes_ctle_t *ctle);

#ifdef AAPL_ENABLE_INTERNAL_FUNCTIONS
EXT int avago_serdes_ctle_validate(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_ctle_t *ctle);
#endif

/**@brief RxFFE parameters */
typedef struct
{
    short pre2;              /**< Pre2-cursor setting */
    short pre1;              /**< Pre1-cursor setting */
    short post1;             /**< Post-cursor setting */
    short bflf;              /**< Low-frequency setting */
    short bfhf;              /**< High-frequency setting */
    short datarate;          /**< Datarate setting */
    short short_channel_en;  /**< Short channel enable setting */
    short pre1_min;          /**< */
    short pre1_max;          /**< */
    short pre2_min;          /**< */
    short pre2_max;          /**< */
    short bflf_ical;         /**< */
    short post1_min;         /**< 12 */
    short post1_max;         /**< 13 */
} Avago_serdes_rxffe_t;

/**@brief valid limits of RxFFE parameters */
typedef struct
{
    short pre2_min;               /**< Minimum pre2-cursor value */
    short pre2_max;               /**< Maximum pre2-cursor value */
    short pre1_max;               /**< Maximum pre1-cursor value */
    short post1_min;              /**< Minimum post1-cursor value */
    short post1_max;              /**< Maximum post1-cursor value */
    short bflf_max;               /**< Maximum low-frequency value */
    short bfhf_max;               /**< maximum high-frequency value */
    short datarate_max;           /**< Maximum datarate value */
    short short_channel_en_max;   /**< Maximum Short channel enable value */
} Avago_serdes_rxffe_limits_t;

EXT int avago_serdes_rxffe_get_limits(Aapl_t *aapl, uint addr, Avago_serdes_rxffe_limits_t *limits);

EXT int   avago_serdes_rxffe_apply(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_rxffe_t *rxffe);
EXT char *avago_serdes_rxffe_print(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_rxffe_t *rxffe);
EXT int   avago_serdes_rxffe_read( Aapl_t *aapl, uint addr,            Avago_serdes_rxffe_t *rxffe);
EXT int   avago_serdes_rxffe_write(Aapl_t *aapl, uint addr,            Avago_serdes_rxffe_t *rxffe);

#ifdef AAPL_ENABLE_INTERNAL_FUNCTIONS
EXT int avago_serdes_rxffe_validate(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_rxffe_t *rxffe);
#endif

/**@brief DFE parameters */
typedef struct
{
    short gaintap;
    short gaintap2;
    short gain2;
    short gain3;
    short gain4;
    short gain5;
    short gain6;
    short gain7;
    short gain8;
    short gain9;
    short gain10;
    short gain11;
    short gain12;
    short gain13;
    short o_gaintap;
    short o_gaintap2;
    short o_gain2;
    short o_gain3;
    short o_gain4;
    short o_gain5;
    short o_gain6;
    short o_gain7;
    short o_gain8;
    short o_gain9;
    short o_gain10;
    short o_gain11;
    short o_gain12;
    short o_gain13;

} Avago_serdes_dfe_t;

typedef struct
{
    short gaintap_min;
    short gaintap_max;
    short gaintap2_min;
    short gaintap2_max;
    short gainx_min;
    short gainx_max;
    short gainy_min;
    short gainy_max;

} Avago_serdes_dfe_limits_t;

EXT int   avago_serdes_dfe_get_limits(Aapl_t *aapl, uint addr, Avago_serdes_dfe_limits_t *limits);

EXT int   avago_serdes_dfe_apply(Aapl_t *aapl, uint addr, bigint mask, Avago_serdes_dfe_t *dfe);
EXT char *avago_serdes_dfe_print(Aapl_t *aapl, uint addr, bigint mask, Avago_serdes_dfe_t *dfe);
EXT int   avago_serdes_dfe_read( Aapl_t *aapl, uint addr,            Avago_serdes_dfe_t *dfe);
EXT int   avago_serdes_dfe_write(Aapl_t *aapl, uint addr,            Avago_serdes_dfe_t *dfe);

#ifdef AAPL_ENABLE_INTERNAL_FUNCTIONS
EXT int avago_serdes_dfe_validate(Aapl_t *aapl, uint addr, bigint mask, Avago_serdes_dfe_t *dfe);
#endif

typedef struct
{
    short upper_odd_dly;
    short upper_even_dly;
    short middle_odd_dly;
    short middle_even_dly;
    short lower_odd_dly;
    short lower_even_dly;
    short test_odd_dly;
    short test_even_dly;
    short edge_odd_dly;
    short edge_even_dly;
    short tap_dly;
    short padding;
} Avago_serdes_vernier_delay_t;

typedef struct
{
    short prev0_even;	/* index 5 */
    short prev1_even;
    short test_even;
    short tap_even;
    short edge_even;
    short cdc_even;
    short prev0_odd;
    short prev1_odd;
    short test_odd;
    short tap_odd;
    short edge_odd;
    short cdc_odd;
} Avago_serdes_vernier_delay_d6_t;

EXT int   avago_serdes_vernier_delay_apply(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_vernier_delay_t *params);
EXT char *avago_serdes_vernier_delay_print(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_vernier_delay_t *params);
EXT int   avago_serdes_vernier_delay_read( Aapl_t *aapl, uint addr,            Avago_serdes_vernier_delay_t *params);
EXT int   avago_serdes_vernier_delay_write(Aapl_t *aapl, uint addr,            Avago_serdes_vernier_delay_t *params);
#define avago_serdes_vernier_delay_d6_print(a,b,c,d) avago_serdes_vernier_delay_print(a,b,c,(Avago_serdes_vernier_delay_t *)d);
#define avago_serdes_vernier_delay_d6_apply(a,b,c,d) avago_serdes_vernier_delay_apply(a,b,c,(Avago_serdes_vernier_delay_t *)d);
#define avago_serdes_vernier_delay_d6_write(a,b,  d) avago_serdes_vernier_delay_write(a,b,  (Avago_serdes_vernier_delay_t *)d);
#define avago_serdes_vernier_delay_d6_read( a,b,  d) avago_serdes_vernier_delay_read (a,b,  (Avago_serdes_vernier_delay_t *)d);

typedef struct
{
    short upper_odd_cal;
    short upper_even_cal;
    short middle_odd_cal;
    short middle_even_cal;
    short lower_odd_cal;
    short lower_even_cal;
} Avago_serdes_vernier_cal_t;

EXT int   avago_serdes_vernier_cal_apply(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_vernier_cal_t *params);
EXT char *avago_serdes_vernier_cal_print(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_vernier_cal_t *params);
EXT int   avago_serdes_vernier_cal_read( Aapl_t *aapl, uint addr,            Avago_serdes_vernier_cal_t *params);
EXT int   avago_serdes_vernier_cal_write(Aapl_t *aapl, uint addr,            Avago_serdes_vernier_cal_t *params);

typedef struct
{
    short error_threshold;            /* global threshold for error counts. */
    short nrz_ctle_dwell_1ex;         /* set dwell for CTLE tuning in NRZ. */
    short nrz_ctle_lf_dwell_shift;    /* set extra LF evaluation shift amount. */
    short eye_oversample;             /* lev_coarse eye oversample amount */
    short pam4_ctle_dwell_1ex;        /* set dwell for pam4 ctle tuning. (Eye Ratchet) */
    short pam4_dvos_dwell_1ex;        /* set dwell for DVOS tuning. */
    short pam4_dvos_pcal_dwell_1ex;   /* set dwell for DVOS tuning in pCal. */
    short lms_dwell_1ex;              /* set dwell for LMS algorithms */
    short ctle_fixed;                 /* CTLE fixed parameters 0b[short_channel,gainshate2,gainshape1,bw,hf,lf,dc] */
    short rxffe_fixed;                /* RxFFE fixed parameters 0b[short_channel,bfhf,bflf,post1,pre1,pre2] */
    short dfe_fixed;                  /* DFE fixed parameters 0b[dfe12-dfe2,dfegain2,dfegain1] */
    short gaintap_max_min;            /* gaintap max and min [upper byte = max, lower byte = min] */
    short gaintap2_max_min;           /* gaintap max and min [upper byte = max, lower byte = min] */
    short pCal_loops;                 /* number of pCal loops to run */
    short disable_one_shot_pcal;      /* should we run a one-shot pCal after iCal; */
    short lms_pcal_dwell_1ex;         /* set dwell for LMS algorithms in pCal. */
    short dcr_pcal_dwell_1ex;         /* set dwell for DC nns search in pCal. */
    short pCal_delay;                 /* delay between loops in continuous adaptive. */
    short iq_cal_interleave_disable;  /* disable IQ cal interleave in bootstrap. */
    short ctle_lfhf_max_min;          /* place algorithm limits on ctle [lfmax,lfmin,hfmax,hfmin]. default 0x90f0; */
    short ctle_dc_max_min;            /* place algorithm limits on ctle [dcmax,dcmin]. default 0xff00 */
    short vernier_fixed;              /* Vernier fixed parameters 0b[ data_upper, data_middle, data_lower, edge] */
    short prbs_tune_mode;             /* 0= data independent tuning. 1=prbs based tuning */
    short gradient_options;           /* one hot variables.  0b00000000000 */
    short ical_effort;                /* 0=minimal effort (< 1.5 second tune time), 1= full effort (take as much time as you need) */
    short use_rx_clock_cal_values;    /* 0=Don't apply rx clock calibration values to verniers;1=Apply rx clock calibration values to verniers */
    short latch_fail;                 /* indicates transparent latch failure detected (0 or 1 is passing) */
    short delta_cal_fail;             /* indicates failure informatrion from the DVOS and vernier delta calibration function */

} Avago_serdes_global_tune_params_t;

EXT int   avago_serdes_global_tune_params_apply(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_global_tune_params_t *params);
EXT char *avago_serdes_global_tune_params_print(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_global_tune_params_t *params);
EXT int   avago_serdes_global_tune_params_read( Aapl_t *aapl, uint addr,            Avago_serdes_global_tune_params_t *params);
EXT int   avago_serdes_global_tune_params_write(Aapl_t *aapl, uint addr,            Avago_serdes_global_tune_params_t *params);

typedef struct  /* Used by AVAGO_HAL_GRADIENT_INPUTS */
{
    short dwell_shift_ical;          /* 0x0_the dwell is (1<<dwell_shift) */
    short agc_target_low;            /* 0x1_target range low  for automatic gain control */
    short agc_target_high;           /* 0x2_target range high for automatic gain control */
    short tune_level;                /* 0x3_1 = measure both level 2 and level 3 */
                                     /*     2 = measure only Level 2 */
                                     /*     3 = measure only Level 3 */
    short dwell_shift_pcal;          /* 0x4_the dwell is (1<<dwell_shift) */
    short pcal_hysteresis_pre1_pos;  /* 0x5_pCal hysteresis threshold for pre1 */
    short pcal_hysteresis_pre1_neg;  /* 0x6_pCal hysteresis threshold for pre1 */
    short pcal_hysteresis_post1_pos; /* 0x7_pCal hysteresis threshold for post1 */
    short pcal_hysteresis_post1_neg; /* 0x8_pCal hysteresis threshold for post1 */
    short pcal_hysteresis_67_pre1;   /* 0x9_pCal additional hysteresis threshold for pre1  transition */
    short pcal_hysteresis_78_post1;  /* 0xA_pCal additional hysteresis threshold for post1 transition */
    short pcal_level3_threshold;     /* 0xB_pCal changes bflf(or Lf) to control cursor gain when level_3 changes this amount */
    short pcal_threshold_offset_post1_pos; /* UNSUPPORTED HFPOST // 0xC_pCal positive offset to the post1 threshold (helpful for Elway 10/5/2017) */
    short pcal_threshold_offset_post1_neg; /* UNSUPPORTED HFPOST // 0xD_pCal negative offset to the post1 threshold */
    short pcal_hysteresis_pre2_pos;  /* 0xE_pCal hysteresis threshold for pre2 */
    short pcal_hysteresis_pre2_neg;  /* 0xF_pCal hysteresis threshold for pre2 */

} Avago_serdes_gradient_inputs_t;

EXT int   avago_serdes_gradient_inputs_apply(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_gradient_inputs_t *params);
EXT char *avago_serdes_gradient_inputs_print(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_gradient_inputs_t *params);
EXT int   avago_serdes_gradient_inputs_read( Aapl_t *aapl, uint addr,            Avago_serdes_gradient_inputs_t *params);
EXT int   avago_serdes_gradient_inputs_write(Aapl_t *aapl, uint addr,            Avago_serdes_gradient_inputs_t *params);

typedef struct  /* AVAGO_HAL_TEST_CHANNEL_INPUTS, AVAGO_HAL_TEST_CHANNEL_CAL */
{
    short test_e;   /* test even - register dfe_td1uose */
    short test_o;   /* test odd  - register dfe_td1uoso */
    short edge_e;   /* edge even - register dfe_td0lose */
    short edge_o;   /* edge odd  - register dfe_td0loso */
} Avago_serdes_test_channel_inputs_t;

EXT int   avago_serdes_test_channel_inputs_apply(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_test_channel_inputs_t *params);
EXT char *avago_serdes_test_channel_inputs_print(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_test_channel_inputs_t *params);
EXT int   avago_serdes_test_channel_inputs_read( Aapl_t *aapl, uint addr,            Avago_serdes_test_channel_inputs_t *params);
EXT int   avago_serdes_test_channel_inputs_write(Aapl_t *aapl, uint addr,            Avago_serdes_test_channel_inputs_t *params);

EXT int   avago_serdes_test_channel_cal_apply(   Aapl_t *aapl, uint addr, uint mask, Avago_serdes_test_channel_inputs_t *params);
EXT int   avago_serdes_test_channel_cal_read(    Aapl_t *aapl, uint addr,            Avago_serdes_test_channel_inputs_t *params);
EXT int   avago_serdes_test_channel_cal_write(   Aapl_t *aapl, uint addr,            Avago_serdes_test_channel_inputs_t *params);

typedef struct /* Used by AVAGO_HAL_DATA_CHANNEL_INPUTS, AVAGO_HAL_DATA_CHANNEL_CAL, AVAGO_HAL_DATA_CHANNEL_CAL_DELTA */
{
    short lower_e;
    short lower_o;
    short mid_e;
    short mid_o;
    short upper_e;
    short upper_o;
} Avago_serdes_data_channel_inputs_t;

typedef struct
{
    short vos_d0e;
    short vos_d0o;
    short vos_d1e;
    short vos_d1o;
} Avago_serdes_data_channel_inputs_d6_t;

EXT int   avago_serdes_data_channel_inputs_apply( Aapl_t *aapl, uint addr, uint mask, Avago_serdes_data_channel_inputs_t *params);
EXT char *avago_serdes_data_channel_inputs_print( Aapl_t *aapl, uint addr, uint mask, Avago_serdes_data_channel_inputs_t *params);
EXT int   avago_serdes_data_channel_inputs_read(  Aapl_t *aapl, uint addr,            Avago_serdes_data_channel_inputs_t *params);
EXT int   avago_serdes_data_channel_inputs_write( Aapl_t *aapl, uint addr,            Avago_serdes_data_channel_inputs_t *params);
#define avago_serdes_data_channel_inputs_d6_print(a,b,c,d) avago_serdes_data_channel_inputs_print(a,b,c,(Avago_serdes_data_channel_inputs_t *)d);
#define avago_serdes_data_channel_inputs_d6_apply(a,b,c,d) avago_serdes_data_channel_inputs_apply(a,b,c,(Avago_serdes_data_channel_inputs_t *)d);
#define avago_serdes_data_channel_inputs_d6_write(a,b,  d) avago_serdes_data_channel_inputs_write(a,b,  (Avago_serdes_data_channel_inputs_t *)d);
#define avago_serdes_data_channel_inputs_d6_read( a,b,  d) avago_serdes_data_channel_inputs_read (a,b,  (Avago_serdes_data_channel_inputs_t *)d);

EXT int avago_serdes_data_channel_cal_apply(      Aapl_t *aapl, uint addr, uint mask, Avago_serdes_data_channel_inputs_t *params);
EXT int avago_serdes_data_channel_cal_read(       Aapl_t *aapl, uint addr,            Avago_serdes_data_channel_inputs_t *params);
EXT int avago_serdes_data_channel_cal_write(      Aapl_t *aapl, uint addr,            Avago_serdes_data_channel_inputs_t *params);
#define avago_serdes_data_channel_cal_d6_apply(a,b,c,d) avago_serdes_data_channel_cal_apply(a,b,c,(Avago_serdes_data_channel_inputs_t *)d);
#define avago_serdes_data_channel_cal_d6_write(a,b,  d) avago_serdes_data_channel_cal_write(a,b,  (Avago_serdes_data_channel_inputs_t *)d);
#define avago_serdes_data_channel_cal_d6_read( a,b,  d) avago_serdes_data_channel_cal_read (a,b,  (Avago_serdes_data_channel_inputs_t *)d);

EXT int avago_serdes_data_channel_cal_delta_apply(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_data_channel_inputs_t *params);
EXT int avago_serdes_data_channel_cal_delta_read( Aapl_t *aapl, uint addr,            Avago_serdes_data_channel_inputs_t *params);
EXT int avago_serdes_data_channel_cal_delta_write(Aapl_t *aapl, uint addr,            Avago_serdes_data_channel_inputs_t *params);

typedef struct /* Used by AVAGO_HAL_PAM4_LEVELS */
{
    short level_x0x_e;
    short level_x0x_o;
    short level_x1x_e;
    short level_x1x_o;
    short level_x2x_e;
    short level_x2x_o;
    short level_x3x_e;
    short level_x3x_o;

} Avago_serdes_pam4_levels_t;

EXT int   avago_serdes_pam4_levels_apply(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_pam4_levels_t *params);
EXT char *avago_serdes_pam4_levels_print(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_pam4_levels_t *params);
EXT int   avago_serdes_pam4_levels_read( Aapl_t *aapl, uint addr,            Avago_serdes_pam4_levels_t *params);
EXT int   avago_serdes_pam4_levels_write(Aapl_t *aapl, uint addr,            Avago_serdes_pam4_levels_t *params);

typedef struct /* Used by AVAGO_HAL_PAM4_EYE */
{
    short height_even_l; /*  0 */
    short height_even_m; /*  1 */
    short height_even_u; /*  2 */
    short height_odd_l;  /*  3 */
    short height_odd_m;  /*  4 */
    short height_odd_u;  /*  5 */

    short start_even_l;  /*  6 */
    short start_even_m;  /*  7 */
    short start_even_u;  /*  8 */
    short start_odd_l;   /*  9 */
    short start_odd_m;   /* 10 */
    short start_odd_u;   /* 11 */
} Avago_serdes_pam4_eye_t;

EXT int   avago_serdes_pam4_eye_apply(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_pam4_eye_t *params);
EXT char *avago_serdes_pam4_eye_print(Aapl_t *aapl, uint addr, uint mask, Avago_serdes_pam4_eye_t *params);
EXT int   avago_serdes_pam4_eye_read( Aapl_t *aapl, uint addr,            Avago_serdes_pam4_eye_t *params);
EXT int   avago_serdes_pam4_eye_write(Aapl_t *aapl, uint addr,            Avago_serdes_pam4_eye_t *params);


#endif /* AAPL_SERDES_HAL_H_ */
