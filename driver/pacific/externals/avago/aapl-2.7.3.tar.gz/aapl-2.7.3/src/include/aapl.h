/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */

/** @file */
/** @brief   Customer level configuration file. */
/** @details aapl.h is the only file we expect customers to configure. */
/** @details aapl.h consists mostly of defines taking a value of 0 or 1. */
/**          To disable functionality, set the define value to 0.  Do not */
/**          comment or remove the define as that will cause compile failures. */
/** @details aapl.h must be included to access AAPL functions.  Typically, */
/**          it's the only AAPL header a library user needs to include. */

#ifndef AAPL_H_
#define AAPL_H_

#ifndef AVAGO_FIRMWARE_PATH
/** @brief This optional define provides a shortcut for accessing firmware */
/**        by [fw_rev] and [build_id] rather than only by full path. */
/** */
/** It points to a directory tree organized as follows: */
/** */
/**  #AVAGO_FIRMWARE_PATH/serdes/[fw_rev]/serdes.[fw_rev]_[build_id].rom */
/** */
/**  #AVAGO_FIRMWARE_PATH/serdes/[fw_rev]/serdes.[fw_rev]_[build_id].swap */
/** */
/**  #AVAGO_FIRMWARE_PATH/sbus_master/[fw_rev]/sbus_master.[fw_rev]_[build_id].rom */
#define AVAGO_FIRMWARE_PATH "/avago/firmware/"
#endif

/* The AAPL_ALLOW_* defines enable/disable code sections of AAPL. */
/* To remove an unneeded code section from AAPL, set the define */
/*      value to 0. Do not comment or remove a define as that may */
/*      cause compile failures. */

#define AAPL_ALLOW_AACS                1  /**< Set to 0 to remove the AACS (via TCP) communication functions. */
#define AAPL_ALLOW_MDIO                1  /**< Set to 0 to remove the MDIO communication functions. */
#define AAPL_ALLOW_GPIO_MDIO           1  /**< Set to 0 to remove the built-in GPIO based MDIO communication functions. */
#define AAPL_ALLOW_I2C                 1  /**< Set to 0 to remove the I2C communication functions. */
#define AAPL_ALLOW_SYSTEM_I2C          1  /**< Set to 0 to remove the built-in system I2C communication functions (ie, /dev/i2c) */
#define AAPL_ALLOW_OFFLINE_SBUS        1  /**< Set to 0 to remove the built-in offline communication functions. */
#define AAPL_ALLOW_JTAG                1  /**< Set to 0 to remove the JTAG communication functions. */
#define AAPL_ALLOW_GPIO_JTAG           1  /**< Set to 0 to remove the built-in GPIO based JTAG communication functions. */
#define AAPL_ALLOW_THREAD_SUPPORT      1  /**< Set to 1 to enable mutex locking for certain functions to help make AAPL more thread safe */
#define AAPL_ALLOW_ANSI_COLORS         1  /**< Set to 1 to enable ANSI color codes in log messages */
#define AAPL_ALLOW_SIGNALS             1  /**< Set to 1 to enable AAPL to trap SIGINT system signals */

/* Set value to 0 to disable corresponding feature support: */
#define AAPL_ENABLE_DIAG               1  /**< Enable diagnostics. */
#define AAPL_ENABLE_FILE_IO            1  /**< Enable use of file IO and the FILE type. */
#define AAPL_ENABLE_C_LINKING          1  /**< Set to 0 if library and callers all are C++ compiled. */
#define AAPL_ENABLE_AACS_SERVER        1  /**< Enable the AACS server. */
#define AAPL_ENABLE_ATT                1  /**< Enable ASIC Temperature programming */

#define AAPL_ENABLE_EYE_MEASUREMENT    1  /**< Enable eye measurement support. */
#define AAPL_ENABLE_SERDES_AUTO_NEG    1 /**< Enable SerDes Auto-negotiation */
#define AAPL_ENABLE_SERDES_HAL         1  /**< Enable SerDes HAL support */
#define AAPL_ENABLE_FEC                1  /**< Enable SerDes FEC support */


#define AAPL_ENABLE_AVSP_1104          1  /**< Enable AVSP 1104 support. */
#define AAPL_ENABLE_AVSP_4412          1  /**< Enable AVSP 4412 support. */
#define AAPL_ENABLE_AVSP_5410          1  /**< Enable AVSP 5410 support. */
#define AAPL_ENABLE_AVSP_7412          1  /**< Enable AVSP 7412 support. */
#define AAPL_ENABLE_AVSP_8801          1  /**< Enable AVSP 8801 support. */
#define AAPL_ENABLE_AVSP_8812          1  /**< Enable AVSP 8812 support. */
#define AAPL_ENABLE_AVSP_9104          1  /**< Enable AVSP 9104 support. */
#define AAPL_ENABLE_AVSP_AUTO_NEG      1  /**< Enable AVSP Auto-Negotiation support. */
#define AAPL_ENABLE_AVSP_KR_TRAINING   1  /**< Enable AVSP KR Training support. */
#define AAPL_ENABLE_AVSP_STATE         1  /**< Enable AVSP stating support. */

#define AAPL_ENABLE_ATE_VEC            1  /**< Enable AAPL ATE test vector interface */
#define AAPL_ENABLE_DDR3_ETRAIN        1  /**< Enable DDR ETRAIN support. */
#define AAPL_ENABLE_EFUSE              1  /**< Enable eFUSE reading. */
#define AAPL_ENABLE_EEPROM             1  /**< Enable eeprom creating support. */
#define AAPL_ENABLE_ESCOPE_MEASUREMENT 1  /**< Enable escope measurement support. */
#define AAPL_ENABLE_EXAMPLES           1  /**< Enable Avago supplied examples in the "aapl" program. */
#define AAPL_ENABLE_HBM                1  /**< Enable HBM support. */
#define AAPL_ENABLE_MAIN               1  /**< Set to 0 to skip compiling the "aapl" program. */
#define AAPL_ENABLE_PS1                1  /**< Enable support for Avago PS1. */
#define AAPL_ENABLE_FLOAT_USAGE        1  /**< Enable float type use in core AAPL. */
                                          /**< Note that this does not affect float usage in measurement functions. */

/* Note that these IP defines are currently incompletely implemented. */
/* Setting one or two of these to zero *may* reduce code and/or data memory. */
#define AAPL_ENABLE_28NM_IP            1  /**< Enable 28nm specific functionality */
#define AAPL_ENABLE_16NM_IP            1  /**< Enable 16nm specific functionality */
#define AAPL_ENABLE_07NM_IP            1  /**< Enable  7nm specific functionality */


#ifdef AAPL_ASCRIPT_BUILD
# undef AAPL_ENABLE_DDR3_ETRAIN
# define AAPL_ENABLE_DDR3_ETRAIN 0
# undef AAPL_ENABLE_EEPROM
# define AAPL_ENABLE_EEPROM 0
# undef AAPL_ENABLE_EXAMPLES
# define AAPL_ENABLE_EXAMPLES 0
# undef AAPL_ENABLE_MLD
# define AAPL_ENABLE_MLD 0
# undef AAPL_ENABLE_HBM
# define AAPL_ENABLE_HBM 0
#endif


/* Defines to be used internally only: */
#ifndef AAPL_ALLOW_THREADED_SBUS
#define AAPL_ALLOW_THREADED_SBUS       0  /**< Set to 1 to enable threaded SBus operations (for internal use only) */
#endif
#ifndef AAPL_ENABLE_HS2
#define AAPL_ENABLE_HS2                0  /**< Enable only if running as an HS2 or PS2 */
#endif
#ifndef AAPL_ENABLE_CONSOLE
#define AAPL_ENABLE_CONSOLE            0  /**< Enable AAPL interactive console. */
#endif

#if AAPL_ENABLE_AVSP_1104 || AAPL_ENABLE_AVSP_4412  || AAPL_ENABLE_AVSP_5410 || AAPL_ENABLE_AVSP_7412 || AAPL_ENABLE_AVSP_8801 || AAPL_ENABLE_AVSP_8812 || AAPL_ENABLE_AVSP_9104
# define AAPL_ENABLE_AVSP 1
# define AAPL_AVSP_COUNT AAPL_ENABLE_AVSP_1104+AAPL_ENABLE_AVSP_4412+AAPL_ENABLE_AVSP_5410+AAPL_ENABLE_AVSP_7412+AAPL_ENABLE_AVSP_8801+AAPL_ENABLE_AVSP_8812+AAPL_ENABLE_AVSP_9104
#else
# define AAPL_ENABLE_AVSP 0
#endif

#if !AAPL_ENABLE_AVSP
# undef  AAPL_ENABLE_AVSP_STATE
# define AAPL_ENABLE_AVSP_STATE 0         /* Remove if no other AVSP support */
# undef  AAPL_ENABLE_AVSP_KR_TRAINING
# define AAPL_ENABLE_AVSP_KR_TRAINING 0   /* Remove if no other AVSP support */
#endif

#if !AAPL_ENABLE_FILE_IO
# undef  AAPL_ENABLE_EEPROM
# define AAPL_ENABLE_EEPROM 0
# undef  AAPL_ENABLE_AVSP_STATE
# define AAPL_ENABLE_AVSP_STATE 0
# undef  AAPL_ENABLE_ATT
# define AAPL_ENABLE_ATT 0
#endif


#if AAPL_ENABLE_AACS_SERVER && !AAPL_ALLOW_AACS
#error "AAPL_ENABLE_AACS_SERVER requires AAPL_ALLOW_AACS to also be enabled."
#endif


/** @brief   Defines the available communication methods. */
/** @details AAPL supports several methods for communicating with Avago IP. */
/**          The communication_method member of the aapl structure defines */
/**          which is used by the library, and can be changed at run time. */
/** */
/**          The default value compiled into the library is configured using */
/**          the AAPL_DEFAULT_COMM_METHOD define in the aapl.h header file. */
/** */
/**          Note also that several AAPL_ALLOW_* defines configure which */
/**          methods are compiled into the library. */
typedef enum
{
    AVAGO_SBUS,             /**< Send SBus commands via the registered SBus function. AACS supported. */

    AVAGO_MDIO,             /**< Send SBus commands via the registered MDIO function. AACS supported. */
    AVAGO_GPIO_MDIO,        /**< Send SBus commands via the registered GPIO MDIO function. */

    AVAGO_I2C,              /**< Send SBus commands via the registered I2C function. AACS supported. */
    AVAGO_SYSTEM_I2C,       /**< Send SBus commands via registered system calls. */

    AVAGO_JTAG,             /**< Send SBus commands via the registered JTAG function. AACS supported. */
    AVAGO_BB_JTAG,          /**< Send SBus commands via the registered bit-banged JTAG function. AACS supported. */
    AVAGO_BB_GPIO_JTAG,     /**< Send SBus commands via the registered bit banged MDIO function. */

    AVAGO_OFFLINE           /**< Emulate SBus commands internally */

    /* NOTE: AACS is supported via all methods, except: AVAGO_GPIO_MDIO, AVAGO_SYSTEM_I2C, AVAGO_BB_GPIO_MDIO, and AVAGO_OFFLINE */
} Aapl_comm_method_t;

/** @brief Set the default AAPL communication_method value. */
/** @details The AAPL communication method actually used to communicate with */
/**          devices is controlled by Aapl_t::communication_method (of type */
/**          Aapl_comm_method_t).  This */
/**          define simply sets the compiled in default value for this field. */
/** @details Note: The AAPL_ALLOW_* defines determine if the code for */
/**          specific communication methods is compiled into the library. */
#define AAPL_DEFAULT_COMM_METHOD         AVAGO_SBUS

/** @brief The default value for Aapl_t::i2c_base_addr. */
/** The base I2C address for Avago devices is usually 0x40. */
/** Normally, this is set to the address of the first Avago device. */
#define AAPL_DEFAULT_I2C_BASE_ADDR       0x40

/** @brief The I2C device to communicate with for the SYSTEM_I2C communication method */
#define AAPL_SYSTEM_I2C_DEVICE "/dev/i2c-1"

/** @brief The default value for Aapl_t::mdio_base_port_addr. */
/** Normally, this is set to the address of the first Avago device. */
#define AAPL_DEFAULT_MDIO_BASE_PORT_ADDR    0

/** @brief The default value for the location of the SBus iJTAG TDR. */
#define AAPL_DEFAULT_SBUS_TDR_OPCODE_BASE 0x180

/* AAPL_PROCESS_ID_OVERRIDE allows the user to override the process ID. */
/* If AAPL is not using AACS to communicate with the device, you should */
/* specify this here, otherwise AAPL will assume the process type */
/* AVAGO_TSMC_28 and issue a warning. (AACS can auto determine the process type, */
/* whereas other communication methods can not.) */

/*#define AAPL_PROCESS_ID_OVERRIDE AVAGO_TSMC_28 */

/** @brief Allows the user to override the number of devices with which */
/**        AAPL will communicate.  The value 0 indicates that AAPL should */
/**        auto-discover this value, if possible. */
/** */
/** If AAPL is not using AACS to communicate with the device, you should */
/** specify this here, otherwise AAPL will assume one device */
/** and issue a warning. */

#define AAPL_NUMBER_OF_CHIPS_OVERRIDE 0


/** @brief Allows the user to override the number of SBus rings with which */
/**        AAPL will communicate.  The value 0 indicates that AAPL should */
/**        auto-discover this value, if possible. */
/** */
/** If AAPL is not using AACS to communicate with the device, you should */
/** specify this here, otherwise AAPL will assume one SBus ring. */

#define AAPL_NUMBER_OF_RINGS_OVERRIDE 0


/* The AAPL_CHIP_ID_HEX_OVERRIDEn defines JTAG IDCODES for devices AAPL will be */
/* communicating with. If AAPL is using an AVAGO_AACS_* communication method */
/* these IDCODES will be auto-discovered. */
/* If you are not using an AVAGO_AACS_* communication method you should define */
/* AAPL_CHIP_ID_HEX_OVERRIDE0 through AAPL_CHIP_ID_HEX_OVERRIDEn, where n is */
/* the number of devices AAPL will be communicating with. */
/* You must always start at AAPL_CHIP_ID_HEX_OVERRIDE0. */
/* WARNING: The values below are examples, and are not valid IDCODEs. */
/*   The user should contact Avago if they do not know the proper */
/*   IDCODE value to use here. */
/*#define AAPL_CHIP_ID_HEX_OVERRIDE0 0xaaaaaaaa */
/*#define AAPL_CHIP_ID_HEX_OVERRIDE1 0xaaaaaaaa */
/*... */
/*#define AAPL_CHIP_ID_HEX_OVERRIDE14 0xaaaaaaaa */
/* */
/* Id codes can also be entered as binary strings, using the following defines: */
/* */
/*#define AAPL_CHIP_ID_OVERRIDE0  "10101010101010101010101010101010" */
/*#define AAPL_CHIP_ID_OVERRIDE1  "10101010101010101010101010101010" */
/*... */
/*#define AAPL_CHIP_ID_OVERRIDE14 "10101010101010101010101010101010" */
/* */
/* If both are given, the hex values will be used. */


/** Maximum number of devices AAPL supports. */
/** Reducing this value to that actually used will reduce the memory footprint of the Aapl_t struct. */
/** Valid range: [1-15]. */
#define AAPL_MAX_CHIPS 15

/** Maximum number of SBus rings AAPL supports. */
/** Reducing this value to that actually used will reduce the memory footprint of the Aapl_t struct. */
/** Valid range: [1-15]. */
#define AAPL_MAX_RINGS 15

/** Maximum number of AACS commands to queue before send. */
/** Setting this to 0 disables command buffering. */
#define AAPL_MAX_CMDS_BUFFERED      1000

#define AAPL_SERDES_INT_TIMEOUT        500  /**< Maximum number of SBus reads to check for completion of SPICO interrupt command */
#define AAPL_SBUS_MDIO_TIMEOUT         100  /**< Maximum number of reads of the SBUS_RESULT register in sbus-over-mdio mode */
#define AAPL_SERDES_INIT_RDY_TIMEOUT    20  /**< Maximum milliseconds for pll calibration */
#define AAPL_SPICO_UPLOAD_WAIT_TIMEOUT 500  /**< Maximum milliseconds to wait for AAPL to wait for external SPICO upload to complete */
#define AAPL_I2C_HARD_RESET_TIMEOUT    100  /**< Maximum number of commands to send after a hard I2C reset to wait for bus to come back up */

/* */
/* AAPL Logging defines: */
/* */
/* The following table describes when and where messages get logged when using AAPL. */
/* */
/* NOTE: If you are integrating AAPL into your your codebase and do not want AAPL to */
/*       save log messages on its own or send any output to a console, do the following: */
/* */
/*          1. Comment out the define for AAPL_STREAM below. This prevents AAPL from */
/*             sending messages to stdout (this could alternatively could be done at */
/*             runtime by setting Aapl_t::enable_stream_logging to 0). */
/* */
/*          2. Comment out the define for AAPL_STREAM_ERR below. This prevents AAPL */
/*             from sending messages to stderr (this could alternatively could be done at */
/*             runtime by setting Aapl_t::enable_stream_err_logging to 0). */
/* */
/*          3. Register your own logging function using aapl_register_logging_fn(). */
/*             Once that is done, AAPL will always call that function for ALL messages, */
/*             including debug messages, warnings, and errors. */
/* */
/*                     AAPL_STREAM           AAPL_STREAM_ERR                      Registered */
/*                                                                              logging function * */
/*                     ------------          ----------------                   ------------------ */
/* */
/*   AVAGO_DEBUGn   (#ifdef AAPL_STREAM &&        never                       (Aapl_t::enable_debug_logging */
/*                  Aapl_t::enable_stream_logging                                  && n <= Aapl_t::debug) */
/*                  && n <= Aapl_t::debug) */
/* */
/*   AVAGO_INFO     (#ifdef AAPL_STREAM &&        never                         always written */
/*                  Aapl_t::enable_stream_logging) */
/* */
/*   AVAGO_WARNING         never           (#ifdef AAPL_STREAM_ERR &&           always written */
/*                                          Aapl_t::enable_stream_err_logging) */
/*   AVAGO_ERR             never           (#ifdef AAPL_STREAM_ERR &&           always written */
/*                                          Aapl_t::enable_stream_err_logging) */
/* */
/*   AVAGO_MEM_LOG**       never                  never                         always written */
/* */
/* */
/*   * Will be Aapl_t::log unless the user has registered a logging function by calling */
/*     aapl_register_logging_fn(). If it has been called, then all writes that would have */
/*     gone to Aapl_t::log will instead be sent to the registered logging function. */
/* */
/*  ** AVAGO_MEM_LOG is an internal logging method to send lines without a newline to the log. */

/** Sets the stdio stream to write debug and info messages. */
/** @see aapl_log_printf(). */
/** */
/** Comment out, or set Aapl_t::enable_stream_logging member of aapl to false, */
/**   to suppress this type of output. */
/** */
/** @see AAPL_STREAM_ERR */
/** */
#define AAPL_STREAM stdout

/** Sets the stdio stream to write warning and error messages. */
/** @see aapl_log_printf(). */
/** */
/** Comment out, or set Aapl_t::enable_stream_err_logging member of aapl to false, */
/**   to suppress this type of output. */
/** */
/** @see AAPL_STREAM */
/** */
#define AAPL_STREAM_ERR stderr

/** @brief Default value for Aapl_t::enable_debug_logging. */
/** This value also can be changed at run time. */
/** */
#define AAPL_DEFAULT_ENABLE_DEBUG_LOGGING        1

/** @brief Default value for Aapl_t::enable_stream_logging. */
/** This value also can be changed at run time. */
/** */
#define AAPL_DEFAULT_ENABLE_STREAM_LOGGING       1

/** @brief Default value for Aapl_t::enable_stream_err_logging. */
/** This value also can be changed at run time. */
/** */
#define AAPL_DEFAULT_ENABLE_STREAM_ERR_LOGGING   1

/** Default for Aapl_t::log_time_stamps. */
/** If defined, this value also can be changed at run time. */
/** */
/** Comment out the define to remove time stamp logging from the compile. */
/** Set to 0 to compile in with a disabled default. */
/** Set to 1 to compile in with an enabled default. */
/** */
#define AAPL_LOG_TIME_STAMPS 1


/** Only used when calling the aacs_server() function */
#define AACS_SERVER_BUFFERS 4096  /* buffer used to store data to be returned to client */

/** Buffer used by aapl_log_printf(). */
/** If too small, output will be truncated. */
#define AAPL_LOG_PRINTF_BUF_SIZE 4096

/** Used by AAPL for the log, data_char, and debug buffers. */
/** Also used by recv. This number should always be >= the max size */
/** the AACS server will return. */
/** */
/** AAPL's AACS server can return up to AAPL_MAX_CMDS_BUFFERED * AAPL_SBUS_CMD_LOG_BUF_SIZE. */
/** */
#define AAPL_LOG_BUF_SIZE 1024

/* */
/* Portability defines: */
/* */

#define HAVE_UINT 0  /**< Set to 1 if your system headers already have the uint typedef. */

/* Add additional defines here to replace any library */
/* functions your build environment doesn't support. */

/*#define strtoul(a,b,c) simple_strtol(a,b,c)   // Example */

#ifdef KERNEL_INCLUDES
#include "system_includes.h"    /* system level C includes */

#define MS_SLEEP(milliseconds) udelay(milliseconds*1000)   /* Edit as needed. */

#define AAPL_EXIT(val)       {}

#define AAPL_MALLOC(sz)      kmalloc(sz, GFP_KERNEL)         /**< AAPL uses this for malloc. */
#define AAPL_REALLOC(ptr,sz) krealloc(ptr,sz, GFP_KERNEL)    /**< AAPL uses this for realloc. */
#define AAPL_FREE(ptr)       kfree(ptr)                      /**< AAPL uses this for free. */

static inline unsigned long aapl_strtoul(char *nptr, char **endptr, int base) {unsigned long val; if(kstrtoul(nptr, base, &val)) {*endptr = nptr; return 0;} else {return val;}}
static inline long aapl_strtol(char *nptr, char **endptr, int base) {long val; if(kstrtol(nptr, base, &val)) {*endptr = nptr; return 0;} else {return val;}}

#else   /* NON-KERNEL: */

/* Uncomment and edit if the default ms_sleep doesn't work for you. */
/*#define MS_SLEEP(milliseconds) udelay(milliseconds*1000)   // Edit as needed. */

#define AAPL_EXIT(val)       exit(val)          /**< AAPL uses this for exit. */

/* All malloc/realloc/free calls make use of these macros: */
#define AAPL_MALLOC(sz)      malloc(sz)         /**< AAPL uses this for malloc. */
#define AAPL_REALLOC(ptr,sz) realloc(ptr,sz)    /**< AAPL uses this for realloc. */
#define AAPL_FREE(ptr)       free(ptr)          /**< AAPL uses this for free. */

#define aapl_strtoul(nptr,endptr,base) strtoul(nptr,endptr,base)
#define aapl_strtol( nptr,endptr,base) strtol( nptr,endptr,base)

#endif  /* KERNEL_INCLUDES */

#if 0
/* Use this code to replace the aapl_{malloc/realloc/free} error */
/*   tracing calls with straight malloc versions. */
/* */
# define aapl_malloc(a,sz,c)      AAPL_MALLOC(sz)
# define aapl_realloc(a,ptr,sz,c) AAPL_REALLOC(ptr,sz)
# define aapl_free(a,ptr,c)       AAPL_FREE(ptr)
#endif

/* Note:  BOOL is a macro, not a typedef "bool" with "false" and "true" values, */
/* to avoid reserved word conflicts for C++ compilations. */
/* FALSE must have the value 0; if compiling using C++ it may also be false. */
/* TRUE must have the value 1; if compiling using C++ it may also be true. */
#if !defined BOOL && !defined __MINGW32__ && !defined _MSC_VER
#define BOOL int
#endif
#ifndef FALSE
#define FALSE 0
#endif
#ifndef TRUE
#define TRUE 1
#endif


/* AAPL required files: */
#include "system_includes.h"    /* system level C includes */
#include "aapl_library.h"       /* Utility macros, types and functions */
#include "aapl_core.h"          /* Core types and functions */
#include "sbus.h"               /* SBus IO commands */
#include "mdio.h"               /* MDIO functions */
#include "gpio_mdio.h"          /* Example GPIO MDIO implementation */
#include "i2c.h"                /* I2C functions */
#include "serdes_core.h"        /* Core SerDes types and functions. */
#include "spico.h"              /* SPICO specific (including SBus Master and SerDes with integrated SPICO) */
#include "pmd.h"                /* KR / PMD functions */
#include "logging.h"            /* Logging functions and type to string functions */
#include "diag_core.h"          /* Basic diagnostic routines */

#include "sensor.h"             /* Avago sensor functions */
#include "sbm.h"                /* SBus master specific routines */
#include "pmro.h"               /* PMRO specific routines */
#include "aacs_server.h"        /* AACS Server functions */
#include "serdes_dfe.h"         /* SerDes DFE functions */


#include "serdes_dma.h"         /* SerDes DMA location defines */

#ifndef AAPL_CORE_FILE
#include "an.h"                 /* SerDes AN functions */
#include "serdes.h"             /* SerDes functions */
#include "hal.h"                /* HAL SerDes types and functions. */
#include "fec.h"                /* FEC functions */
#include "escope.h"             /* Escope functions */
#include "eye.h"                /* SerDes eye functions */
#include "meas.h"
#include "eye_math.h"
#include "ps1.h"                /* PS1 specific routines */
#include "avsp.h"               /* AVSP functions */
#include "diag.h"               /* Diagnostic routines */
#include "etrain.h"             /* DDR3 eTrain routines */
#include "hbm.h"                /* HBM routines */
#include "aapl_str_conv.h"      /* Type to string conversions */
#include "aapl_util.h"          /* "system" level commands for AAPL */
#include "main_program.h"       /* Functions used by command line. */


#endif /* AAPL_CORE_FILE */

#endif /* AAPL_H_ */
