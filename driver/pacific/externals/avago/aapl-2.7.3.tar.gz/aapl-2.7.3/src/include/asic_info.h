/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/** @file
 ** @brief Declarations of ASIC-specific values used in AAPL.
 */

#ifndef AVAGO_ASIC_INFO_H_
#define AVAGO_ASIC_INFO_H_

typedef struct
{
        uint jtag_idcode;
        const char *name;
        const char *rev;
        Avago_process_id_t process_id;
        uint sbus_rings;
} Avago_chip_id_t;

/* Only one compilation unit defines this global variable; others just get the
 * definition:
 */

Avago_chip_id_t avago_chip_id[] =
{
    /* NOTE: Add new entries near beginning of list, not at end. */

    {0x1000057f, "\x41\x41\x50\x4c\x5f\x31\x5f\x53\x42\x55\x53\x5f\x52\x49\x4e\x47","1", AVAGO_UNKNOWN_PROCESS, 1}, 
    {0x2000057f, "\x41\x41\x50\x4c\x5f\x32\x5f\x53\x42\x55\x53\x5f\x52\x49\x4e\x47","1", AVAGO_UNKNOWN_PROCESS, 2}, 
    {0x3000057f, "\x41\x41\x50\x4c\x5f\x33\x5f\x53\x42\x55\x53\x5f\x52\x49\x4e\x47","1", AVAGO_UNKNOWN_PROCESS, 3}, 
    {0x4000057f, "\x41\x41\x50\x4c\x5f\x34\x5f\x53\x42\x55\x53\x5f\x52\x49\x4e\x47","1", AVAGO_UNKNOWN_PROCESS, 4}, 
    {0x5000057f, "\x41\x41\x50\x4c\x5f\x35\x5f\x53\x42\x55\x53\x5f\x52\x49\x4e\x47","1", AVAGO_UNKNOWN_PROCESS, 5}, 
    {0x6000057f, "\x41\x41\x50\x4c\x5f\x36\x5f\x53\x42\x55\x53\x5f\x52\x49\x4e\x47","1", AVAGO_UNKNOWN_PROCESS, 6}, 
    {0x7000057f, "\x41\x41\x50\x4c\x5f\x37\x5f\x53\x42\x55\x53\x5f\x52\x49\x4e\x47","1", AVAGO_UNKNOWN_PROCESS, 7}, 
    {0x8000057f, "\x41\x41\x50\x4c\x5f\x38\x5f\x53\x42\x55\x53\x5f\x52\x49\x4e\x47","1", AVAGO_UNKNOWN_PROCESS, 8}, 
    {0x9000057f, "\x41\x41\x50\x4c\x5f\x39\x5f\x53\x42\x55\x53\x5f\x52\x49\x4e\x47","1", AVAGO_UNKNOWN_PROCESS, 9}, 
    {0xa000057f, "\x41\x41\x50\x4c\x5f\x31\x30\x5f\x53\x42\x55\x53\x5f\x52\x49\x4e\x47","1", AVAGO_UNKNOWN_PROCESS, 10}, 
    {0xb000057f, "\x41\x41\x50\x4c\x5f\x31\x31\x5f\x53\x42\x55\x53\x5f\x52\x49\x4e\x47","1", AVAGO_UNKNOWN_PROCESS, 11}, 
    {0xc000057f, "\x41\x41\x50\x4c\x5f\x31\x32\x5f\x53\x42\x55\x53\x5f\x52\x49\x4e\x47","1", AVAGO_UNKNOWN_PROCESS, 12}, 
    {0xd000057f, "\x41\x41\x50\x4c\x5f\x31\x33\x5f\x53\x42\x55\x53\x5f\x52\x49\x4e\x47","1", AVAGO_UNKNOWN_PROCESS, 13}, 
    {0xe000057f, "\x41\x41\x50\x4c\x5f\x31\x34\x5f\x53\x42\x55\x53\x5f\x52\x49\x4e\x47","1", AVAGO_UNKNOWN_PROCESS, 14}, 

    {0x0912457f, "\x41\x56\x53\x50\x2d\x31\x31\x30\x34",                     "1",    AVAGO_TSMC_28, 1},
    {0x0912657f, "\x41\x56\x53\x50\x2d\x31\x31\x30\x34",                     "2",    AVAGO_TSMC_28, 1},
    {0x0912657f, "\x41\x56\x53\x50\x2d\x31\x31\x30\x34",                     "2",    AVAGO_TSMC_28, 1},
    {0x0954657f, "\x41\x56\x53\x50\x2d\x34\x34\x31\x32\x2f\x38\x38\x30\x31", "1",    AVAGO_TSMC_28, 1},
    {0x1954657f, "\x41\x56\x53\x50\x2d\x34\x34\x31\x32\x2f\x38\x38\x30\x31", "2",    AVAGO_TSMC_28, 1},
    {0x096d157f, "\x41\x56\x53\x50\x2d\x34\x34\x31\x32\x2f\x38\x38\x30\x31", "3",    AVAGO_TSMC_28, 1},
    {0x0968257f, "\x41\x56\x53\x50\x2d\x34\x34\x31\x32\x2f\x38\x38\x30\x31", "4",    AVAGO_TSMC_28, 1},
    {0x090b957f, "\x41\x56\x53\x50\x2d\x35\x32\x31",                         "1",    AVAGO_TSMC_28, 1},
    {0x1911357f, "\x41\x56\x53\x50\x2d\x35\x32\x31",                         "1.1",  AVAGO_TSMC_28, 1},
    {0x0911457f, "\x41\x56\x53\x50\x2d\x35\x32\x31",                         "x",    AVAGO_TSMC_28, 1},
    {0x099a557f, "\x41\x56\x53\x50\x2d\x35\x34\x31\x30",                     "1",    AVAGO_TSMC_28, 1},
    {0x199a557f, "\x41\x56\x53\x50\x2d\x35\x34\x31\x30",                     "2",    AVAGO_TSMC_28, 1},
    {0x0990357f, "\x41\x56\x53\x50\x2d\x37\x34\x30\x31",                     "1",    AVAGO_TSMC_28, 1},
    {0x0973957f, "\x41\x56\x53\x50\x2d\x37\x34\x31\x32",                     "1",    AVAGO_TSMC_28, 1},
    {0x1973957f, "\x41\x56\x53\x50\x2d\x37\x34\x31\x32",                     "2",    AVAGO_TSMC_28, 1},
    {0x0973157f, "\x41\x56\x53\x50\x2d\x38\x38\x31\x32",                     "1",    AVAGO_TSMC_28, 1},
    {0x1973157f, "\x41\x56\x53\x50\x2d\x38\x38\x31\x32",                     "2",    AVAGO_TSMC_28, 1},
    {0x0964257f, "\x41\x56\x53\x50\x2d\x39\x31\x30\x34",                     "1",    AVAGO_TSMC_28, 1},
    {0x1964257f, "\x41\x56\x53\x50\x2d\x39\x31\x30\x34",                     "2",    AVAGO_TSMC_28, 1},
    {0x2964257f, "\x41\x56\x53\x50\x2d\x39\x31\x30\x34",                     "3",    AVAGO_TSMC_28, 1},


    {0x1a2e357f, "\x43\x68\x61\x6d\x65\x6c\x65\x6f\x6e",                     "1",    AVAGO_TSMC_07, 1},
    {0x1a18957f, "\x43\x6f\x6c\x75\x67\x6f",                                 "1",    AVAGO_TSMC_07, 1},
    {0x1a21657f, "\x44\x46\x45",                                             "1",    AVAGO_TSMC_07, 1},
    {0x1a05557f, "\x44\x4c\x55\x2d\x28\x41\x49\x29",                         "1",    AVAGO_TSMC_07, 1},
    {0x1a2d757f, "\x4c\x53\x50",                                             "1",    AVAGO_TSMC_07, 1},
    {0x1a0c357f, "\x4d\x63\x43\x68\x69\x70",                                 "1",    AVAGO_TSMC_07, 1},
    {0x1a19457f, "\x4d\x69\x6c\x65\x2d\x48\x69\x67\x68",                     "1",    AVAGO_TSMC_07, 1},
    {0x1a37157f, "\x52\x69\x6b\x65\x72",                                     "1",    AVAGO_TSMC_07, 1},
    {0x1a19357f, "\x53\x74\x61\x6d\x70\x65\x64\x65",                         "1",    AVAGO_TSMC_07, 1},
    {0x19ca357f, "\x54\x43\x48\x49\x50",                                     "1",    AVAGO_TSMC_07, 7},
    {0x29ca357f, "\x54\x43\x48\x49\x50",                                     "2",    AVAGO_TSMC_07, 7},
    {0x1a30157f, "\x54\x68\x75\x6e\x64\x65\x72\x2d\x43",                     "1",    AVAGO_TSMC_07, 6},
    {0x1a2d957f, "\x5a\x58\x32\x32\x32\x30\x31\x39",                         "1",    AVAGO_TSMC_07, 1},
    {0x1a39157f, "\x5a\x58\x32\x32\x32\x33\x30\x30",                         "1",    AVAGO_TSMC_07, 1},

    {0x19d6357f, "\x41\x70\x70\x6c\x65                                       River", "1", AVAGO_TSMC_16, 2},
    {0x19d3157f, "\x41\x76\x69\x61\x74\x6f\x72",                             "1",    AVAGO_TSMC_16, 2},
    {0x19a1657f, "\x42\x65\x76\x65\x72\x6c\x79",                             "1",    AVAGO_TSMC_16, 1},
    {0x19c2757f, "\x42\x69\x67\x53\x6b\x79",                                 "1",    AVAGO_TSMC_16, 1},
    {0x19c3657f, "\x42\x6c\x61\x63\x6b\x73\x74\x6f\x6e\x65                   River","1", AVAGO_TSMC_16, 1},
    {0x0996957f, "\x42\x6c\x61\x63\x6b\x73\x77\x69\x66\x74",                 "1",    AVAGO_TSMC_16, 1},
    {0x19a8457f, "\x42\x72\x61\x67\x69                                       Next    Gen", "1", AVAGO_TSMC_16, 1},
    {0x0a16857f, "\x42\x52\x43\x35",                                         "1",    AVAGO_TSMC_16, 1},
    {0x1a18257f, "\x43\x61\x70\x72\x69",                                     "1",    AVAGO_TSMC_16, 1},
    {0x09a2957f, "\x43\x6f\x6c\x66\x61\x78",                                 "1",    AVAGO_TSMC_16, 1},
    {0x19d6457f, "\x43\x6f\x6c\x75\x6d\x62\x69\x61\x56\x69\x6c\x6c\x65",     "1",    AVAGO_TSMC_16, 2},
    {0x39d6457f, "\x43\x6f\x6c\x75\x6d\x62\x69\x61\x56\x69\x6c\x6c\x65\x42\x30", "1",    AVAGO_TSMC_16, 2},
    {0x1a19557f, "\x43\x6f\x6c\x75\x6d\x62\x69\x61\x56\x69\x6c\x6c\x65\x53\x44", "1",    AVAGO_TSMC_16, 2},
    {0x1040a57f, "\x44\x61\x76\x6f\x73",                                     "1",    AVAGO_TSMC_16, 4},
    {0x2040a57f, "\x44\x61\x76\x6f\x73",                                     "2",    AVAGO_TSMC_16, 4},
    {0x19b6857f, "\x44\x65\x6c\x74\x61",                                     "1",    AVAGO_TSMC_16, 1},
    {0x29b6857f, "\x44\x65\x6c\x74\x61",                                     "2",    AVAGO_TSMC_16, 1},
    {0x099a957f, "\x44\x6f\x70\x70\x6c\x65\x72\x44\x53\x2d\x44",             "1",    AVAGO_TSMC_16, 1},
    {0x09a1557f, "\x44\x6f\x70\x70\x6c\x65\x72\x44\x53\x2d\x53",             "1",    AVAGO_TSMC_16, 1},
    {0x0992757f, "\x44\x6f\x70\x70\x6c\x65\x72\x45",                         "1",    AVAGO_TSMC_16, 1},
    {0x1992757f, "\x44\x6f\x70\x70\x6c\x65\x72\x45",                         "1.1",  AVAGO_TSMC_16, 1},
    {0x19a7557f, "\x45\x6c\x61\x6d",                                         "1",    AVAGO_TSMC_16, 1},
    {0x29a7557f, "\x45\x6c\x61\x6d",                                         "1.1",  AVAGO_TSMC_16, 1},
    {0x0a19657f, "\x46\x31",                                                 "1",    AVAGO_TSMC_16, 1},
    {0x0a04757f, "\x48\x65\x61\x76\x65\x6e\x6c\x79",                         "1",    AVAGO_TSMC_16, 1},
    {0x09b9357f, "\x48\x69\x67\x68\x6c\x61\x6e\x64",                         "1",    AVAGO_TSMC_16, 1},
    {0x09c2857f, "\x48\x6f\x6d\x65\x77\x6f\x6f\x64",                         "1",    AVAGO_TSMC_16, 1},
    {0x0978157f, "\x49\x6e\x64\x72\x61\x32",                                 "1",    AVAGO_TSMC_16, 8},
    {0x1978157f, "\x49\x6e\x64\x72\x61\x32",                                 "1.1",  AVAGO_TSMC_16, 8},
    {0x2978157f, "\x49\x6e\x64\x72\x61\x32",                                 "1.2",  AVAGO_TSMC_16, 8},
    {0x1040957f, "\x4c\x61\x63\x72\x6f\x73\x73\x65",                         "1",    AVAGO_TSMC_16, 8},
    {0x2040957f, "\x4c\x61\x63\x72\x6f\x73\x73\x65",                         "2",    AVAGO_TSMC_16, 8},
    {0x1c00f57f, "\x4c\x53\x51",                                             "1",    AVAGO_TSMC_16, 8},
    {0x0a08357f, "\x4d\x41\x43\x48",                                         "1",    AVAGO_TSMC_16, 1},
    {0x39a7857f, "\x4d\x61\x6e\x6e\x69\x6e\x67",                             "1.2",  AVAGO_TSMC_16, 5},
    {0x29a7857f, "\x4d\x61\x6e\x6e\x69\x6e\x67",                             "1.1",  AVAGO_TSMC_16, 5},
    {0x19a7857f, "\x4d\x61\x6e\x6e\x69\x6e\x67",                             "1",    AVAGO_TSMC_16, 5},
    {0x09d6557f, "\x4d\x61\x6e\x6f\x72                                       Hill",  "1", AVAGO_TSMC_16, 1},
    {0x1995657f, "\x4d\x61\x75\x6e\x61\x4c\x6f\x61",                         "1",    AVAGO_TSMC_16, 1},
    {0x1995757f, "\x4d\x61\x75\x6e\x61\x4c\x6f\x61",                         "1",    AVAGO_TSMC_16, 1},
    {0x09a7657f, "\x4d\x65\x63\x6b\x6c\x65\x6e\x62\x75\x72\x67",             "1",    AVAGO_TSMC_16, 1},
    {0x19a7657f, "\x4d\x65\x63\x6b\x6c\x65\x6e\x62\x75\x72\x67",             "1.1",  AVAGO_TSMC_16, 1},
    {0x0a0e657f, "\x4d\x6f\x6e\x61\x72\x63\x68",                             "1",    AVAGO_TSMC_16, 1},
    {0x09ca657f, "\x4d\x6f\x72\x70\x68\x65\x75\x73",                         "1",    AVAGO_TSMC_16, 1},
    {0x09da157f, "\x4e\x65\x77\x70\x6f\x72\x74",                             "1",    AVAGO_TSMC_16, 1},
    {0x19c8757f, "\x4f\x4c\x54                                               (ZX279220)", "1", AVAGO_TSMC_16, 1},
    {0x19ba557f, "\x50\x53\x49\x46\x4e\x47",                                 "1",    AVAGO_TSMC_16, 1},
    {0x19a7257f, "\x50\x61\x72\x61\x6c\x6c\x61\x78",                         "1",    AVAGO_TSMC_16, 1},
    {0x14a4657f, "\x50\x61\x72\x61\x6c\x6c\x61\x78",                         "1",    AVAGO_TSMC_16, 6},
    {0x0a16457f, "\x50\x65\x6e\x74\x73\x69\x61",                             "1",    AVAGO_TSMC_16, 1},
    {0x09a2857f, "\x50\x69\x6e\x6f\x6c\x65",                                 "1",    AVAGO_TSMC_16, 1},
    {0x09a7757f, "\x50\x6c\x75\x6d\x6d\x65\x72",                             "1",    AVAGO_TSMC_16, 1},
    {0x19a7757f, "\x50\x6c\x75\x6d\x6d\x65\x72",                             "1.1",  AVAGO_TSMC_16, 1},
    {0x10246549, "\x50\x72\x69\x73\x6d",                                     "1",    AVAGO_TSMC_16, 2},
    {0x1444657f, "\x51\x75\x6f\x6b\x6b\x61",                                 "1",    AVAGO_TSMC_16, 6},
    {0x0000957f, "\x52\x61\x76\x65\x6e",                                     "1",    AVAGO_TSMC_16, 1},
    {0x09b4957f, "\x52\x65\x64\x73\x74\x6f\x6e\x65",                         "1",    AVAGO_TSMC_16, 2},
    {0x09b5557f, "\x52\x65\x64\x73\x74\x6f\x6e\x65\x54\x43",                 "1",    AVAGO_TSMC_16, 2},
    {0x19ba157f, "\x52\x69\x63\x68\x61\x72\x64\x73",                         "1",    AVAGO_TSMC_16, 1},
    {0x09a7957f, "\x53\x68\x61\x72\x70\x65",                                 "1",    AVAGO_TSMC_16, 1},
    {0x1045057f, "\x53\x6b\x79\x62\x6f\x6c\x74",                             "1",    AVAGO_TSMC_16, 2},
    {0x19b0257f, "\x53\x6b\x79\x62\x6f\x6c\x74\x54\x43",                     "1",    AVAGO_TSMC_16, 1},
    {0x0a21357f, "\x53\x70\x72\x69\x6e\x67\x43\x72\x65\x73\x74",             "1",    AVAGO_TSMC_16, 1},
    {0x099a457f, "\x53\x74\x61\x70\x6c\x65\x72",                             "1",    AVAGO_TSMC_16, 1},
    {0x1040b57f, "\x53\x75\x67\x61\x72\x62\x6f\x77\x6c",                     "1",    AVAGO_TSMC_16, 4},
    {0x2040b57f, "\x53\x75\x67\x61\x72\x62\x6f\x77\x6c",                     "2",    AVAGO_TSMC_16, 4},
    {0x3040b57f, "\x53\x75\x67\x61\x72\x62\x6f\x77\x6c",                     "3",    AVAGO_TSMC_16, 4},
    {0x0995357f, "\x54\x6f\x66\x69\x6e\x6f",                                 "1",    AVAGO_TSMC_16, 2},
    {0x1995357f, "\x54\x6f\x66\x69\x6e\x6f",                                 "2",    AVAGO_TSMC_16, 1},
    {0x09b9957f, "\x57\x6f\x6f\x64",                                         "1",    AVAGO_TSMC_16, 1},
    {0x1988457f, "\x5a\x46",                                                 "1",    AVAGO_TSMC_16, 1},
    {0x1060157f, "\x5a\x48",                                                 "1",    AVAGO_TSMC_16, 1},
    {0x1994557f, "\x5a\x54",                                                 "1",    AVAGO_TSMC_16, 5},
    {0x1997757f, "\x5a\x58",                                                 "1",    AVAGO_TSMC_16, 3},

    {0x19d9957F, "\x55\x4e\x43",                                             "1",    AVAGO_TSMC_28, 1},
    {0x09c8957F, "\x4c\x75\x74\x65\x74\x69\x61\x2d\x32",                     "1",    AVAGO_TSMC_28, 1},
    {0x0968157f, "\x57\x46\x52",                                             "1",    AVAGO_TSMC_28, 1},
    {0x0967957f, "\x50\x52\x52",                                             "1",    AVAGO_TSMC_28, 1},
    {0x0997857f, "\x52\x52\x43",                                             "2",    AVAGO_TSMC_28, 2},
    {0x0095757f, "\x58\x50\x38\x30",                                         "1",    AVAGO_TSMC_28, 1},
    {0x1917257F, "\x4c\x75\x74\x65\x74\x69\x61",                             "1",    AVAGO_TSMC_28, 1},
    {0x1917357f, "\x44\x69\x76\x69\x6f",                                     "1",    AVAGO_TSMC_28, 2},
    {0x00d8257f, "\x43\x75\x62",                                             "1",    AVAGO_TSMC_28, 6},
    {0x00d7057f, "\x56\x65\x6e\x74\x75\x72\x61",                             "1",    AVAGO_TSMC_28, 3},
    {0x00d8157f, "\x54\x69\x67\x65\x72",                                     "1",    AVAGO_TSMC_28, 1},
    {0x4986457f, "\x50\x61\x63\x75\x61\x72\x65",                             "1",    AVAGO_TSMC_28, 2},
    {0x194d957f, "\x52\x52\x43",                                             "1",    AVAGO_TSMC_28, 2},
    {0x103d357f, "\x41\x6c\x70\x69\x6e\x65",                                 "1",    AVAGO_TSMC_28, 2},
    {0x0043057f, "\x42\x6f\x64\x65\x67\x61",                                 "1",    AVAGO_TSMC_28, 2},
    {0x103cb57f, "\x42\x69\x67\x53\x75\x72\x2d\x43\x52",                     "1",    AVAGO_TSMC_28, 1},
    {0x0987357f, "\x43\x4d\x34\x45\x53",                                     "1",    AVAGO_TSMC_28, 1},
    {0x0911857f, "\x4b\x6f\x68\x61\x6c\x61",                                 "1",    AVAGO_TSMC_28, 1},
    {0x08fa857f, "\x4b\x6f\x68\x61\x6c\x61\x44",                             "1",    AVAGO_TSMC_28, 1},
    {0x5800057f, "\x4e\x65\x6f",                                             "1.1",  AVAGO_TSMC_28, 2},
    {0x4800057f, "\x4e\x65\x6f",                                             "1",    AVAGO_TSMC_28, 2},
    {0x88fa557f, "\x4e\x65\x6f",                                             "2",    AVAGO_TSMC_28, 2},
    {0x103d457f, "\x4e\x6f\x72\x74\x68\x73\x74\x61\x72",                     "1",    AVAGO_TSMC_28, 1},
    {0x0975457f, "\x50\x61\x6e\x64\x6f\x72\x61",                             "P1",   AVAGO_TSMC_28, 1},
    {0x0972357f, "\x50\x61\x6e\x64\x6f\x72\x61",                             "M4",   AVAGO_TSMC_28, 1},
    {0x103dc57f, "\x53\x74\x61\x72\x6c\x69\x66\x74\x65\x72",                 "1",    AVAGO_TSMC_28, 1},
    {0x203d257f, "\x53\x4d\x31\x35",                                         "2",    AVAGO_TSMC_28, 3},
    {0x103d257f, "\x53\x4d\x31\x35",                                         "1",    AVAGO_TSMC_28, 3},
    {0x103c157f, "\x53\x4d\x31\x35\x54\x43",                                 "1",    AVAGO_TSMC_28, 1},
    {0x203c657f, "\x54\x69\x67\x65\x72\x73\x68\x61\x72\x6b",                 "2",    AVAGO_TSMC_28, 2},
    {0x103c657f, "\x54\x69\x67\x65\x72\x73\x68\x61\x72\x6b",                 "1",    AVAGO_TSMC_28, 2},
    {0x19ba957f, "\x5a\x58\x32\x37\x39\x31\x32\x31",                         "1",    AVAGO_TSMC_28, 1},


    /* Test chips go here: */
    {0x0a17657f, "\x41\x6c\x74\x61",                                         "1",    AVAGO_TSMC_07, 1},
    {0x1a08457f, "\x42\x65\x61\x76\x65\x72\x2d\x43\x72\x65\x65\x6b",         "1",    AVAGO_TSMC_07, 2},
    {0x2a08457f, "\x42\x65\x61\x76\x65\x72\x2d\x43\x72\x65\x65\x6b",         "2",    AVAGO_TSMC_07, 2},
    {0x1a38857f, "\x4d\x61\x6d\x6d\x6f\x74\x68",                             "1",    AVAGO_TSMC_07, 5},
    {0x0a2c957f, "\x57\x68\x69\x73\x74\x6c\x65\x72",                         "1",    AVAGO_TSMC_07, 2},
    {0x1f00057f, "\x43\x65\x6e\x74\x65\x6e\x61\x72\x69\x6f",                 "1",    AVAGO_TSMC_07, 1},

    {0x09b1657f, "\x46\x65\x72\x6d\x69",                                     "1",    AVAGO_TSMC_16, 1},
    {0x09c2557f, "\x46\x65\x72\x6d\x69\x42",                                 "1.1",  AVAGO_TSMC_16, 1},
    {0x49c2557f, "\x46\x65\x72\x6d\x69\x42",                                 "2.0",  AVAGO_TSMC_16, 1},
    {0x09ce657f, "\x46\x72\x61\x6e\x6b\x6c\x69\x6e",                         "1",    AVAGO_TSMC_16, 1},
    {0x49ce657f, "\x46\x72\x61\x6e\x6b\x6c\x69\x6e",                         "2.0",  AVAGO_TSMC_16, 1},
    {0x14211001, "\x48\x65\x72\x74\x7a",                                     "1",    AVAGO_TSMC_16, 1},
    {0x09b93001, "\x48\x69\x67\x68\x6c\x61\x6e\x64",                         "1",    AVAGO_TSMC_16, 2},
    {0x19827001, "\x4c\x6f\x72\x65\x6e\x74\x7a",                             "1",    AVAGO_TSMC_16, 1},
    {0x0000057f, "\x4d\x61\x78\x77\x65\x6c\x6c",                             "1",    AVAGO_TSMC_16, 1},
    {0x0992957f, "\x53\x69\x6d\x62\x61",                                     "1",    AVAGO_TSMC_16, 1},
    {0x0995957f, "\x54\x65\x73\x6c\x61",                                     "1",    AVAGO_TSMC_16, 1},

    {0x09a1757f, "\x41\x63\x61\x64\x65\x6d\x79",                             "1",    AVAGO_TSMC_28, 1},
    {0x0985357f, "\x42\x6f\x72\x61\x68\x2d\x50\x65\x61\x6b",                 "1",    AVAGO_TSMC_28, 1},
    {0x099a757f, "\x42\x75\x63\x6b\x2d\x48\x69\x6c\x6c",                     "1",    AVAGO_TSMC_28, 1},
    {0x199a757f, "\x42\x75\x63\x6b\x2d\x48\x69\x6c\x6c",                     "2",    AVAGO_TSMC_28, 1},
    {0x0911657f, "\x44\x65\x6e\x61\x6c\x69",                                 "Bx",   AVAGO_TSMC_28, 1},
    {0x090b857f, "\x44\x65\x6e\x61\x6c\x69",                                 "B25",  AVAGO_TSMC_28, 1},
    {0x0912257f, "\x44\x65\x6e\x61\x6c\x69",                                 "B15",  AVAGO_TSMC_28, 1},
    {0x0901457f, "\x44\x65\x6e\x61\x6c\x69",                                 "1",    AVAGO_TSMC_28, 1},
    {0x0954957f, "\x4d\x63\x4b\x69\x6e\x6c\x65\x79",                         "XTAL", AVAGO_TSMC_28, 1},
    {0x0954857f, "\x4d\x63\x4b\x69\x6e\x6c\x65\x79",                         "25",   AVAGO_TSMC_28, 1},
    {0x0912557f, "\x4d\x63\x4b\x69\x6e\x6c\x65\x79",                         "15",   AVAGO_TSMC_28, 1},
    {0x0991757f, "\x50\x69\x6b\x65\x73",                                     "1",    AVAGO_TSMC_28, 1},

    /* NOTE: Add new entries at the front of this list, NOT here. */
};

#endif /* AVAGO_ASIC_INFO_H_ */
