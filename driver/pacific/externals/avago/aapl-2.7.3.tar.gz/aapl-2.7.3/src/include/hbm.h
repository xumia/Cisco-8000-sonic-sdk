/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
#ifndef AVAGO_HBM_H_
#define AVAGO_HBM_H_

/** Doxygen File Header */
/** @file */
/** @brief   Functions and data structures for HBM access */

#if AAPL_ENABLE_HBM

/* Default timeout for HBM operations */
EXT int avago_hbm_default_timeout;

/* HBM firmware parameters */
typedef enum
{
  AVAGO_HBM_INTERFACE_REQUEST               = 0,
  AVAGO_HBM_MAX_TIMEOUT                     = 1,
  AVAGO_HBM_TINIT1_CYCLES                   = 2,
  AVAGO_HBM_TINIT2_CYCLES                   = 3,
  AVAGO_HBM_TINIT3_CYCLES                   = 4,
  AVAGO_HBM_TINIT4_CYCLES                   = 5,
  AVAGO_HBM_TINIT5_CYCLES                   = 6,
  AVAGO_HBM_RW_LATENCY_OFFSET               = 7,
  AVAGO_HBM_LATENCY_ODD_N_EVEN              = 8,
  AVAGO_HBM_SAVE_RESTORE_CONFIG             = 9,
  AVAGO_HBM_MODE_REGISTER0                  = 10,
  AVAGO_HBM_MODE_REGISTER1                  = 11,
  AVAGO_HBM_MODE_REGISTER2                  = 12,
  AVAGO_HBM_MODE_REGISTER3                  = 13,
  AVAGO_HBM_MODE_REGISTER4                  = 14,
  AVAGO_HBM_MODE_REGISTER5                  = 15,
  AVAGO_HBM_MODE_REGISTER6                  = 16,
  AVAGO_HBM_MODE_REGISTER7                  = 17,
  AVAGO_HBM_MODE_REGISTER8                  = 18,
  AVAGO_HBM_PHY_CONFIG0                     = 19,
  AVAGO_HBM_PHY_CONFIG1                     = 20,
  AVAGO_HBM_PHY_CONFIG2                     = 21,
  AVAGO_HBM_PHY_CONFIG3                     = 22,
  AVAGO_HBM_PHY_CONFIG4                     = 23,
  AVAGO_HBM_PHY_CONFIG5                     = 24,
  AVAGO_HBM_PHY_CONFIG6                     = 25,
  AVAGO_HBM_LBP_DRV_IMP                     = 26,
  AVAGO_HBM_DELAY_CONFIG_DLL                = 27,
  AVAGO_HBM_IGNORE_PHYUPD_HANDSHAKE         = 28,
  AVAGO_HBM_TUPDMRS                         = 29,
  AVAGO_HBM_T_RDLAT_OFFSET                  = 30,
  AVAGO_HBM_MBIST_REPAIR_MODE               = 31,
  AVAGO_HBM_MBIST_PATTERN                   = 32,
  AVAGO_HBM_MIST_HARD_REPAIR_CYCLES         = 33,
  AVAGO_HBM_HARD_LANE_REPAIR_CYCLES         = 34,
  AVAGO_HBM_POWER_ON_LANE_REPAIR_MODE       = 35,
  AVAGO_HBM_MBIST_BANK_ADDRESS_END          = 36,
  AVAGO_HBM_MBIST_ROW_ADDRESS_END           = 37,
  AVAGO_HBM_MBIST_COLUMN_ADDRESS_END        = 38,
  AVAGO_HBM_FREQ                            = 39,
  AVAGO_HBM_DIV_MODE                        = 40,
  AVAGO_HBM_CKE_EXIT_STATE                  = 41,
  AVAGO_HBM_TEST_MODE_REGISTER0             = 42,
  AVAGO_HBM_TEST_MODE_REGISTER1             = 43,
  AVAGO_HBM_TEST_MODE_REGISTER2             = 44,
  AVAGO_HBM_TEST_MODE_REGISTER3             = 45,
  AVAGO_HBM_TEST_MODE_REGISTER4             = 46,
  AVAGO_HBM_TEST_MODE_REGISTER5             = 47,
  AVAGO_HBM_TEST_MODE_REGISTER6             = 48,
  AVAGO_HBM_TEST_MODE_REGISTER7             = 49,
  AVAGO_HBM_TEST_MODE_REGISTER8             = 50,
  AVAGO_HBM_CTC_RUN_CYCLES                  = 51,
  AVAGO_HBM_CTC_CHANNEL_IGNORE              = 52,
  AVAGO_HBM_CTC_INITIAL_ADDRESS_LO          = 53,
  AVAGO_HBM_CTC_INITIAL_ADDRESS_HI          = 54,
  AVAGO_HBM_CTC_MAX_ADDRESS_LO              = 55,
  AVAGO_HBM_CTC_MAX_ADDRESS_HI              = 56,
  AVAGO_HBM_TEST_T_RDLAT_OFFSET             = 57,
  AVAGO_HBM_MODE_REGISTER15                 = 58,
  AVAGO_HBM_TEST_MODE_REGISTER15            = 59,
  AVAGO_HBM_BYPASS_TESTMODE_RESET           = 60,
  AVAGO_HBM_DISABLE_ADDR_LANE_REPAIR        = 61,
  AVAGO_HBM_CTC_PATTERN_TYPE                = 62,
  AVAGO_HBM_BYPASS_REPAIR_ON_RESET          = 63,
  AVAGO_HBM_STACK_HEIGHT                    = 64,
  AVAGO_HBM_MANUFACTURER_ID                 = 65,
  AVAGO_HBM_DENSITY                         = 66,
  AVAGO_HBM_MANUALLY_CONFIGURE_ID           = 67,
  AVAGO_HBM_PARITY_LATENCY                  = 68,
  AVAGO_HBM_TEST_PARITY_LATENCY             = 69,
  AVAGO_HBM_DFI_T_RDDATA_EN                 = 70,
  AVAGO_HBM_MANUALLY_CONFIGURE_NWL          = 71,
  AVAGO_HBM_CTC_PSEUDO_CHANNEL              = 72,
  AVAGO_HBM_MMT_CONFIGURATION               = AVAGO_HBM_CTC_PATTERN_TYPE
} Avago_hbm_parameter_t;

/* Set a hbm training parameter value */
EXT int avago_hbm_set_parameter(Aapl_t *aapl, uint spico_addr, Avago_hbm_parameter_t param, uint value);

/* Get a hbm training parameter value */
EXT int avago_hbm_get_parameter(Aapl_t *aapl, uint spico_addr, Avago_hbm_parameter_t param);


/* HBM firmware operations that can be run */
typedef enum
{
  AVAGO_HBM_OP_RESET                 = 0,
  AVAGO_HBM_OP_RESET_PHY             = 1,
  AVAGO_HBM_OP_RESET_HBM             = 2,
  AVAGO_HBM_OP_POWER_ON_FLOW         = 5,
  AVAGO_HBM_OP_CONNECTIVITY_CHECK    = 6,
  AVAGO_HBM_OP_BYPASS_TEST           = 7,
  AVAGO_HBM_OP_READ_DEVICE_ID        = 8,
  AVAGO_HBM_OP_AWORD_TEST            = 9,
  AVAGO_HBM_OP_AERR_TEST             = 10,
  AVAGO_HBM_OP_DWORD_TEST            = 11,
  AVAGO_HBM_OP_DERR_TEST             = 12,
  AVAGO_HBM_OP_LANE_REPAIR           = 13,
  AVAGO_HBM_OP_AWORD_ILB             = 14,
  AVAGO_HBM_OP_DWORD_ILB             = 15,
  AVAGO_HBM_OP_READ_TEMPERATURE      = 16,
  AVAGO_HBM_OP_BURN_HARD_REPAIRS     = 17,
  AVAGO_HBM_OP_COPY_HARD_REPAIRS     = 18,
  AVAGO_HBM_OP_RUN_SAMSUNG_MBIST     = 19,
  AVAGO_HBM_OP_RUN_SKH_MBIST         = 20,
  AVAGO_HBM_OP_RESET_MODE_REGISTERS  = 21,
  AVAGO_HBM_OP_RESET_PHY_CONFIG      = 22,
  AVAGO_HBM_OP_AWORD_SLB             = 23,
  AVAGO_HBM_OP_DWORD_SLB             = 24,
  AVAGO_HBM_OP_SAMSUNG_CHIPPING_TEST = 25,
  AVAGO_HBM_OP_AERR_ILB              = 27,
  AVAGO_HBM_OP_AERR_SLB              = 28,
  AVAGO_HBM_OP_DERR_ILB              = 29,
  AVAGO_HBM_OP_DERR_SLB              = 30,
  AVAGO_HBM_OP_INITIALIZE_NWL_MCS    = 31,
  AVAGO_HBM_OP_RUN_CTCS              = 32,
  AVAGO_HBM_OP_VERIFY_LANE_ERRORS    = 33,
  AVAGO_HBM_OP_START_CTC             = 34,
  AVAGO_HBM_OP_STOP_CTC              = 35,
  AVAGO_HBM_OP_TMRS                  = 36,
  AVAGO_HBM_OP_RELEASE_CTC_CONTROL   = 37,
  AVAGO_HBM_OP_CATTRIP               = 38,
  AVAGO_HBM_OP_TOGGLE_NWL_CKE        = 39,
  AVAGO_HBM_OP_CTC_BANDWIDTH         = 40,
  AVAGO_HBM_OP_RUN_CELL_REPAIR       = 41,
  AVAGO_HBM_OP_FUSE_SCAN             = 42,
  AVAGO_HBM_OP_EXTEST_SLB            = 43,
  AVAGO_HBM_OP_RUN_MMT               = AVAGO_HBM_OP_RUN_CTCS,
  AVAGO_HBM_OP_START_MMT             = AVAGO_HBM_OP_START_CTC,
  AVAGO_HBM_OP_STOP_MMT              = AVAGO_HBM_OP_STOP_CTC
} Avago_hbm_operation_t;

typedef struct
{
  uint global_error_code;
  uint channel_error_code[8];
  uint channel_operation_code[8];
} Avago_hbm_operation_results_t;

/* Launches an HBM operation on all PHY/HBM channels */
EXT int avago_hbm_launch_operation(Aapl_t *aapl, uint spico_addr, Avago_hbm_operation_t operation, Avago_hbm_operation_results_t *results, int max_timeout);

/* Launches an HBM operation on a single PHY/HBM channel */
EXT int avago_hbm_launch_channel_operation(Aapl_t *aapl, uint spico_addr, Avago_hbm_operation_t operation, Avago_hbm_operation_results_t *results, uint channel, int max_timeout);

/* Reads the HBM channel errors code from firmware */
EXT int avago_hbm_get_operation_results(Aapl_t *aapl, uint spico_addr, Avago_hbm_operation_results_t *results);

/* Print the results of the operation */
EXT int avago_hbm_print_operation_results(Aapl_t *aapl, Avago_hbm_operation_results_t *results);

/* HBM Device ID */
typedef struct
{
  uint gen2_test;
  uint ecc;
  uint density;
  uint manufacturer_id;
  uint manufacturing_loc;
  uint manufacturing_year;
  uint manufacturing_week;
  unsigned long serial_number_31_0;
  uint  serial_number_33_32;
  uint addressing_mode;
  uint channel_available;
  uint hbm_stack_height;
  uint model_number;
  uint value2;
  uint value1;
  uint value0;
} Avago_hbm_device_id_t;

/* Get the HBM device id and store the results in the device_id structure */
EXT int avago_hbm_read_device_id(Aapl_t *aapl, uint spico_addr, Avago_hbm_device_id_t *device_id);

/* Print the HBM device id  */
EXT int avago_hbm_print_device_id(Aapl_t *aapl, uint spico_addr);

/* HBM Mode Registers */
typedef struct
{
  uint mr0;
  uint mr1;
  uint mr2;
  uint mr3;
  uint mr4;
  uint mr5;
  uint mr6;
  uint mr7;
  uint mr8;
  uint mr9;
  uint mr10;
  uint mr11;
  uint mr12;
  uint mr13;
  uint mr14;
  uint mr15;
} Avago_hbm_mrs_t;

/* Get the HBM MRS values and store the results in the mrs structure */
EXT int avago_hbm_read_mrs(Aapl_t *aapl, uint spico_addr, Avago_hbm_mrs_t *mrs, uint channel);

/* Print the HBM MRS values */
EXT int avago_hbm_print_mrs(Aapl_t *aapl, uint spico_addr, uint channel);

/* Print the HBM Hard lane repairs */
EXT int avago_hbm_print_hard_lane_repairs(Aapl_t *aapl, uint apc_addr);

/* Get the HBM temperature */
EXT int avago_hbm_read_device_temp(Aapl_t *aapl, uint spico_addr);

/* Return the APC address on the sbus ring */
EXT int avago_hbm_get_apc_addr(Aapl_t *aapl, uint spico_addr, uint *apc_addr);

/* HBM diagnostics */
EXT int avago_hbm_run_diagnostics(Aapl_t *aapl, uint spico_addr);
EXT int avago_hbm_run_ctc_diagnostics(Aapl_t *aapl, uint spico_addr, int do_reset, int do_init_nwl);
EXT int avago_hbm_run_mbist_diagnostics(Aapl_t *aapl, uint spico_addr);
EXT int avago_hbm_run_temp_diagnostics(Aapl_t *aapl, uint spico_addr, int count);
EXT int avago_hbm_ctc_start(Aapl_t *aapl, uint spico_addr, int pattern_type, int init);
EXT int avago_hbm_ctc_stop(Aapl_t *aapl, uint spico_addr);
EXT int avago_hbm_print_ctc_results(Aapl_t *aapl, uint apc_addr);
EXT BOOL avago_hbm_has_ctc(Aapl_t *aapl, uint apc_addr);
EXT int avago_hbm_run_mmt_diagnostics(Aapl_t *aapl, uint spico_addr);
EXT int avago_hbm_mmt_start(Aapl_t *aapl, uint spico_addr, int pattern_type);
EXT int avago_hbm_mmt_stop(Aapl_t *aapl, uint spico_addr);
EXT int avago_hbm_print_mmt_results(Aapl_t *aapl, uint apc_addr, uint verbose);
EXT int avago_hbm_print_spare_results(Aapl_t *aapl, uint spico_addr);

/* TMRS */
EXT int avago_hbm_run_tmrs(Aapl_t *aapl, uint spico_addr, const char *tmrs_code, uint channel, uint safety);

#endif /* AAPL_ENABLE_HBM */

#endif /* AVAGO_HBM_H_ */
