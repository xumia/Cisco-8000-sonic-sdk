/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* Logging and core type conversion functions */
/* */

/** Doxygen File Header */
/** @file */
/** @brief Logging and core type conversion functions. */

#ifndef AAPL_LOGGING_H_
#define AAPL_LOGGING_H_

/*////////////////////////////////////////////////////////////////////// */
/* AAPL LOGGING functions: */

/** @defgroup Logging Logging Functions and Types */
/** @{ */

EXT int  aapl_fail(      Aapl_t *aapl, const char *caller, int line, const char *fmt, ...);
EXT void aapl_log_printf(Aapl_t *aapl, Aapl_log_type_t log_sel, const char *caller, int line, const char * fmt, ...);
EXT void aapl_log_add(   Aapl_t *aapl, Aapl_log_type_t log_sel, const char *string, const char *caller, int line);

EXT const char *aapl_log_get(Aapl_t *aapl);     /* Returns pointer to log. */
EXT void        aapl_log_clear(Aapl_t *aapl);   /* Truncates the log. */

EXT void aapl_start_file_logging(Aapl_t *aapl, const char* filepath); /* Redirect log to the file */
EXT void aapl_stop_file_logging(Aapl_t *aapl); /* Stop logging to file */

# ifdef AAPL_ENABLE_INTERNAL_FUNCTIONS
/** @cond INTERNAL */
    EXT void aapl_buf_add(Aapl_t *aapl, char **buf, char **buf_end, int *size, const char *fmt, ...);
    EXT void aapl_built_in_logging_fn(Aapl_t *aapl, Aapl_log_type_t log_sel, const char * buf, size_t new_item_length);
/** @endcond */
# endif

EXT void aapl_register_logging_fn(Aapl_t *aapl,
    void (* log_fn)(Aapl_t *, Aapl_log_type_t log_sel, const char * buf, size_t new_item_length),
    int  (* log_open_fn)(Aapl_t *),
    int  (* log_close_fn)(Aapl_t *)
);
/** @} */


/*////////////////////////////////////////////////////////////////////// */
/* Functions to convert types to strings, and strings to types. */
/* Allows for human readable output of these enums during logging. */

# ifdef AAPL_ENABLE_INTERNAL_FUNCTIONS
/** @cond INTERNAL */
    typedef struct
    {
        const char *const name;
        int value;
    } Aapl_conv_table_t;

    EXT int name_to_index(Aapl_conv_table_t tbl[], const char *name, uint skip_prefix);
    EXT int value_to_index(Aapl_conv_table_t tbl[], int value);
/** @endcond */
# endif

EXT const char *aapl_addr_to_str          (uint                          val);
EXT const char *aapl_bigint_to_str        (bigint                        val);
EXT const char *aapl_bigint_to_str2       (bigint                        val, BOOL pretty);
EXT const char *aapl_bool_to_str          (int                           val);
EXT const char *aapl_comm_method_to_str   (Aapl_comm_method_t            val);
EXT const char *aapl_cmp_data_to_str      (Avago_serdes_rx_cmp_data_t    val);
EXT const char *aapl_cmp_mode_to_str      (Avago_serdes_rx_cmp_mode_t    val);
EXT const char *aapl_data_sel_to_str      (Avago_serdes_tx_data_sel_t    val);
EXT const char *aapl_dfe_status_to_str    (uint                          val);
EXT const char *aapl_dfe_tune_mode_to_str (Avago_serdes_dfe_tune_mode_t  val);
EXT const char *aapl_enable_to_str        (int                           val);
EXT const char *aapl_line_encoding_to_str (Avago_serdes_line_encoding_t  val);
EXT const char *aapl_ip_type_to_str       (Avago_ip_type_t               val);
EXT const char *aapl_log_type_to_str      (Aapl_log_type_t               val);
EXT const char *aapl_mem_type_to_str      (Avago_serdes_mem_type_t       val);
EXT const char *aapl_onoff_to_str         (int                           val);
EXT const char *aapl_pll_clk_to_str       (Avago_serdes_tx_pll_clk_t     val);
EXT const char *aapl_process_id_to_str    (Avago_process_id_t            val);
EXT const char *aapl_rx_clock_cdc_to_str  (Avago_serdes_rx_clock_cdc_t   val);
EXT const char *aapl_rx_clock_to_str      (Avago_serdes_rx_clock_t       val);
EXT const char *aapl_term_to_str          (Avago_serdes_rx_term_t        val);
EXT const char *aapl_spico_clk_to_str     (Avago_serdes_spico_clk_t      val);

EXT BOOL aapl_str_to_addr         (const char *name, char **endptr, uint *addr);
EXT BOOL aapl_str_to_cmp_data     (const char *name, Avago_serdes_rx_cmp_data_t *out);
EXT BOOL aapl_str_to_cmp_mode     (const char *name, Avago_serdes_rx_cmp_mode_t *out);
EXT BOOL aapl_str_to_comm_method  (const char *name, Aapl_comm_method_t *out);
EXT BOOL aapl_str_to_data_sel     (const char *name, Avago_serdes_tx_data_sel_t *out);
EXT BOOL aapl_str_to_dfe_tune_mode(const char *name, Avago_serdes_dfe_tune_mode_t *out);
EXT BOOL aapl_str_to_line_encoding(const char *name, Avago_serdes_line_encoding_t *out);
EXT BOOL aapl_str_to_ip_type      (const char *name, Avago_ip_type_t *out);
EXT BOOL aapl_str_to_mem_type     (const char *name, Avago_serdes_mem_type_t *out);
EXT BOOL aapl_str_to_pll_clk      (const char *name, Avago_serdes_tx_pll_clk_t *out);
EXT BOOL aapl_str_to_rx_clock     (const char *name, Avago_serdes_rx_clock_t *out);
EXT BOOL aapl_str_to_rx_clock_cdc (const char *name, Avago_serdes_rx_clock_cdc_t *out);
EXT BOOL aapl_str_to_term         (const char *name, Avago_serdes_rx_term_t *out);
EXT BOOL aapl_str_to_spico_clk    (const char *name, Avago_serdes_spico_clk_t *out);

#endif /* AAPL_LOGGING_H_ */
