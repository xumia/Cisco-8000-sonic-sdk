/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */

/** Doxygen File Header */
/** @file */
/** @brief Core AAPL types and function definitions. */

#ifndef AAPL_CORE_H_
#define AAPL_CORE_H_

/* Macros to suppress error accounting when errors are expected and handled: */
#define AAPL_SUPPRESS_ERRORS_PUSH(aapl) { int return_code = (aapl->suppress_errors++, aapl->return_code)
#define AAPL_SUPPRESS_ERRORS_POP(aapl)        aapl->return_code = return_code; aapl->suppress_errors--; }

/* AAPL debug defines (used to debug specific sections of code using aapl->debug) */
#define AAPL_DEBUG_LOCK 0x10
#define AAPL_DEBUG_MEMORY_NAMES 0x20
#define AAPL_DEBUG_TEMP_SENSOR 0x20 /* yes, this is the same as AAPL_DEBUG_MEMORY_NAMES, but this should be OK, as these are in very different areas of the code */
#define AAPL_DEBUG_SBUS_RW_TEST 0x40
#define AAPL_DEBUG_SBM_TABLE 0x800

/* AACS Server capabilities flags: */
#define AACS_SERVER_NO_CAPABILITIES 0x1 /* prevents capability checking */
#define AACS_SERVER_SPICO_INT       0x2 /* Send interrupt over AACS */
#define AACS_SERVER_DIAG            0x4
#define AACS_SERVER_SBUS_RESET      0x8
#define AACS_SERVER_NO_CRC          0x10 /* Don't run CRC -- useful for verilog simulations */
#define AACS_SERVER_MDIO            0x20 /* Send MDIO over AACS */
#define AACS_SERVER_PMI             0x40 /* Send PMI over AACS */

#define AAPL_3D_ARRAY_ADDR(addr) (addr).chip][(addr).ring][(addr).sbus

/** @brief Aapl_log_type_t is used for the AAPL struct log buffers */
typedef enum
{
    AVAGO_DEBUG0 = 0,
    AVAGO_DEBUG1, AVAGO_DEBUG2, AVAGO_DEBUG3, AVAGO_DEBUG4, AVAGO_DEBUG5, /* AAPL application logging */
    AVAGO_DEBUG6, AVAGO_DEBUG7, AVAGO_DEBUG8, AVAGO_DEBUG9, /* AAPL utility logging */
    AVAGO_DEBUG10, AVAGO_DEBUG11, AVAGO_DEBUG12,    /* AAPL communication logging */
    AVAGO_DEBUG13, AVAGO_DEBUG14, AVAGO_DEBUG15,    /* Registered function logging */
    AVAGO_MEM_LOG, AVAGO_DATA_CHAR, AVAGO_DATA_CHAR_ADD,
    AVAGO_ERR, AVAGO_WARNING, AVAGO_INFO
} Aapl_log_type_t;


typedef enum
{
    AVAGO_UNKNOWN_PROCESS = 0,
    AVAGO_TSMC_16,
    AVAGO_TSMC_07,
    AVAGO_TSMC_28
    /* If new enums are added here, add them to serdes/str_conv.c as well! */
} Avago_process_id_t;

typedef enum
{
    AVAGO_UNKNOWN_IP                 = 0x00,
    AVAGO_SERDES                     = 0x01,
    AVAGO_SBUS_CONTROLLER            = 0x02,
    AVAGO_SPICO                      = 0x03,
    AVAGO_QPI                        = 0x04,
    AVAGO_BLACKHAWK                  = 0x05, /* 7nm */
    AVAGO_PCS64B66B                  = 0x06,
    AVAGO_AUTO_NEGOTIATION           = 0x07,
    AVAGO_PCS64B66B_FEC              = 0x08,
    AVAGO_PCIE_PCS                   = 0x09,
    AVAGO_CORE_PLL                   = 0x0a,
    AVAGO_PMRO                       = 0x0b,
    AVAGO_DDR_ADDRESS                = 0x0c, /* 28nm only */
    AVAGO_DDR_DATA                   = 0x0d, /* 28nm only */
    AVAGO_DDR_TRAIN                  = 0x0e, /* 28nm only */
    AVAGO_DDR_CTC                    = 0x0f, /* 28nm only */
    AVAGO_DDR_STOP                   = 0x10, /* 28nm only */
    AVAGO_HBM_CTC                    = 0x0f, /* 28/16nm only */
    AVAGO_HBM_STOP                   = 0x10,
    AVAGO_THERMAL_SENSOR             = 0x11,
    AVAGO_RMON                       = 0x12,
    AVAGO_LINK_EMULATOR              = 0x13,
    AVAGO_AVSP_CONTROL_LOGIC         = 0x14,
    AVAGO_M4                         = 0x15,
    AVAGO_P1                         = 0x16,
    AVAGO_MLD                        = 0x17,
    AVAGO_RSFEC_BRIDGE               = 0x18,
    AVAGO_CROSSPOINT                 = 0x19,
    AVAGO_MAX                        = 0x1a, /* 7nm */
    AVAGO_SBUS2APB                   = 0x1b, /* 7nm */
  /*AVAGO_SBUS2PMI                   = 0x1c, // unused */
    AVAGO_EFUSE                      = 0x1d, /* 7nm */
    AVAGO_RESCAL                     = 0x1e, /* 7nm */
    AVAGO_CPLL_LC                    = 0x1f,
    AVAGO_SAPPH_GBX                  = 0x20, /* 28nm */
    AVAGO_SAPPH_GBX_TOP              = 0x21, /* 28nm */
    AVAGO_OPAL_RSFEC528              = 0x22, /* 28nm */
    AVAGO_OPAL_RSFEC528_544          = 0x23, /* 28nm */
    AVAGO_OPAL_HOST_ALIGNER          = 0x24, /* 28nm */
    AVAGO_OPAL_MOD_ALIGNER           = 0x25, /* 28nm */
    AVAGO_OPAL_CONTROL               = 0x26, /* 28nm */
    AVAGO_OSC_SSC_PLL                = 0x27, /* 28nm */
    AVAGO_GARNET_25GE_INTERFACE      = 0x28, /* 28nm */
    AVAGO_SGMII                      = 0x29,
    AVAGO_APC                        = 0x2a, /* 16/7nm */
    AVAGO_MLD_RX2                    = 0x2b,
    AVAGO_PMRO2                      = 0x2c, /* 7nm */
    AVAGO_OSPREY                     = 0x2d, /* 7nm */
    AVAGO_RS4K_FEC                   = 0x2e, /* 7nm */
    AVAGO_BCH16K_FEC                 = 0x2f, /* 7nm */

    AVAGO_ADCTEMP                    = 0x30, /* 7nm */
    AVAGO_BIAS                       = 0x31, /* 7nm */
    AVAGO_CLKBUF                     = 0x32, /* 7nm */
    AVAGO_ELA                        = 0x33, /* 7nm */
    AVAGO_MXS_TEST                   = 0x34, /* 7nm */
    AVAGO_MXS_SUBSYSTEM              = 0x35, /* 7nm */
    AVAGO_PLLSYS                     = 0x36, /* 7nm */
    AVAGO_ROSC                       = 0x37, /* 7nm */
    AVAGO_XTAL                       = 0x38, /* 7nm */
    AVAGO_D7S_SBUS2APB               = 0x39, /* 7nm */

    AVAGO_5GLTE_A2D                  = 0x40, /* 7nm */
    AVAGO_5GLTE_D2A                  = 0x41, /* 7nm */
    AVAGO_5GLTE_RX_GB                = 0x42, /* 7nm */
    AVAGO_5GLTE_TX_GB                = 0x43, /* 7nm */
    AVAGO_5GLTE_CONV_PLL             = 0x44, /* 7nm */
    AVAGO_5GLTE_AGC                  = 0x45, /* 7nm */
    AVAGO_5GLTE_CAPRAM               = 0x46, /* 7nm */
    AVAGO_KEYSTONE_HSIO              = 0x47, /* 7nm */
    AVAGO_KEYSTONE_RX_CORE           = 0x48, /* 7nm */
    AVAGO_KEYSTONE_TX_CORE           = 0x49, /* 7nm */
    AVAGO_KEYSTONE_MISC              = 0x4a, /* 7nm */


    /* NOTE: Add new entries here.  Update AVAGO_IP_TYPE_MAX entry to match highest number above. */
    /* If new enums are added here, add them to logging.c as well! */

    AVAGO_IP_TYPE_MAX                = 0x4a, /* Maximum value used when setting the Avago_ip_type_t variable. */

    AVAGO_IP_TYPE_ALT_RANGE_LO       = 0x81, /* Start of alternative range when setting the Avago_ip_type_t variable. */
    AVAGO_LINK_EMULATOR_2            = 0x81,
    AVAGO_SLE_PKT                    = 0x82,
    AVAGO_SLE                        = 0x83, /* 16nm; is RAM_PMRO on 28nm */
    AVAGO_MXU                        = 0x84,

    /* Add additional alternate range entries here. */
    /* If new enums are added here, add them to logging.c as well! */
    AVAGO_PAD_CONTROL                = 0x88,

    /* The following types are not defined by their enum number: */
    /*  they're special cases that must be handled carefully -- see aapl_core.c. */
    AVAGO_RAM_PMRO,                          /* 28nm only */
    AVAGO_PANDORA_LSB,
    AVAGO_IP_TYPE_ALT_RANGE_HI,              /* End of alternative range when setting the Avago_ip_type_t variable. */


    AVAGO_MAX_RING_ADDRESS           = 0xdf, /* Last address usable in sbus ring */

    AVAGO_SGMII_BROADCAST            = 0xea,
    AVAGO_OSC_SSC_BROADCAST          = 0xeb, /* 28nm only? */
    AVAGO_MLD_BROADCAST              = 0xec, /* 16/7nm */
    AVAGO_SERDES_P1_BROADCAST        = 0xed, /* 16/28nm only, repurposed in 7nm */
    AVAGO_SERDES_M4_BROADCAST        = 0xee, /* 16/28nm only, repurposed in 7nm */
    AVAGO_THERMAL_SENSOR_BROADCAST   = 0xef, /* 16/28nm only, repurposed in 7nm */

    AVAGO_5GLTE_A2D_BROADCAST        = 0xe9, /* 7nm */
    AVAGO_5GLTE_D2A_BROADCAST        = 0xed, /* 7nm */
    AVAGO_5GLTE_RX_GB_BROADCAST      = 0xee, /* 7nm */
    AVAGO_5GLTE_TX_GB_BROADCAST      = 0xef, /* 7nm */

    AVAGO_DDR_STOP_BROADCAST         = 0xf0, /* 28nm only, repurposed in 16/7nm */
    AVAGO_DDR_CTC_BROADCAST          = 0xf1, /* 28nm only, repurposed in 16nm */
    AVAGO_DDR_TRAIN_BROADCAST        = 0xf2, /* 28nm only */
    AVAGO_DDR_DATA_BROADCAST         = 0xf3, /* 28nm only, repurposed in 7nm */
    AVAGO_DDR_ADDRESS_BROADCAST      = 0xf4, /* 28nm only, repurposed in 7nm */
    AVAGO_HBM_STOP_BROADCAST         = 0xf0, /* 16/7nm, reused */
    AVAGO_HBM_CTC_BROADCAST          = 0xf1, /* 16nm only, reused */
    AVAGO_APC_BROADCAST              = 0xf2, /* Is this used? */
    AVAGO_MAX_BROADCAST              = 0xf3, /* 7nm, reused */
    AVAGO_RESCAL_ADDRESS_BROADCAST   = 0xf4, /* 7nm, reused */

    AVAGO_PMRO_BROADCAST             = 0xf5,
    AVAGO_PMRO2_BROADCAST            = 0xf5, /* Intentionally reused value */
    AVAGO_RESERVED_BROADCAST         = 0xf6,
    AVAGO_CPLL_LC_BROADCAST          = 0xf6, /* reused */
    AVAGO_PCIE_PCS_BROADCAST         = 0xf7,
    AVAGO_MXU_BROADCAST              = 0xf8, /* Mammoth test chip only! */
    AVAGO_PCS64B66B_BROADCAST        = 0xf8, /* 7 & 28nm */
    AVAGO_AUTO_NEGOTIATION_BROADCAST = 0xf9,
    AVAGO_OSPREY_BROADCAST           = 0xfa, /* 7nm only */
    AVAGO_BLACKHAWK_BROADCAST        = 0xfb, /* 7nm */
    AVAGO_QPI_BROADCAST              = 0xfc, /* 28nm, repurposed in 16/7nm */
    AVAGO_MLD_RX2_BROADCAST          = 0xfc, /* 16/7nm, reused. */
    AVAGO_SPICO_BROADCAST            = 0xfd,
    AVAGO_SERDES_D6_BROADCAST        = 0xff,
    AVAGO_SERDES_BROADCAST           = 0xff
} Avago_ip_type_t;


/* Required to be declared here since it gets used in Aapl_t below */
typedef enum
{
    AVAGO_MDIO_ADDR,
    AVAGO_MDIO_WRITE,
    AVAGO_MDIO_READ,
    AVAGO_MDIO_WAIT
} Avago_mdio_cmd_t;


/** @defgroup Address IP Addressing Functions */
/** @{ */

/** @brief Internal hardware address structure. */
/** Not generally end-user accessible. */
/** Each value can be AVAGO_ADDR_BROADCAST to indicate broadcast to all at that level. */
/** Else the valid values are hardware and call dependent. */
typedef struct Avago_addr_t
{
    unsigned char chip;   /**< Device number. */
    unsigned char ring;   /**< Ring on device. */
    unsigned char sbus;   /**< SBus address on ring. */
    unsigned char lane;   /**< Lane at SBus address. */
    unsigned char pll;    /**< Pll/micro at SBus address. */
    uint results;         /**< Place to store return value for list read and interrupt operations. */
    bigint bigint_results;/**< Place to store return value for list read and interrupt operations. */
    uint group_addr;      /**< SBus broadcast group address.  0 if none. */

    struct Avago_addr_t *next; /**< Address of next Avago_addr_t element in linked list. */
} Avago_addr_t;

/** @brief AAPL addressing constants. */
typedef enum
{
    AVAGO_ADDR_BROADCAST      = 0xff,
    AVAGO_ADDR_IGNORE_LANE    = 0xf0,
    AVAGO_ADDR_QUAD_LOW       = 0xf1,
    AVAGO_ADDR_QUAD_HIGH      = 0xf2,
    AVAGO_ADDR_QUAD_ALL       = 0xf3
} Aapl_broadcast_control_t;

#define AVAGO_BROADCAST                (AVAGO_ADDR_BROADCAST)
#define AVAGO_SBUS_MASTER_ADDRESS      (0xfd)
#define AVAGO_SBUS_CONTROLLER_ADDRESS  (0xfe)
#define AVAGO_SERDES_BROADCAST_ADDRESS (0xff)
#define AVAGO_MAKE_SERDES_BROADCAST_ADDRESS(addr) (avago_make_serdes_broacast_addr(addr))   /* Deprecated macro */

/** @} */



/** @brief AAPL struct used by virtually every function in this API. */
/** @warning Generally the user should not read or modify any elements of this struct. */
/** Use functions provided to get and set information in this structure. */
typedef struct _Aapl_t
{
    /* START of public SWIG members */
    /* These first variables are public to the SWIG output (they're listed in the #ifdef SWIG section below) */

    uint debug;                               /**< global debug level */
    uint verbose;                             /**< global verbosity level */
    uint suppress_errors;                     /**< Turn aapl_log_add ERR and WARNINGS into DEBUG1 messages */
    uint upgrade_warnings;                    /**< If set, all WARNINGS are upgraded to ERRORS */
    uint diag_on_failure;                     /**< Run avago_diag when SPICO interrupts fail. Each time avago_diag is called this variable is decremented. */
    BOOL ansi_colors;                         /**< Defaults to the value in aapl.h. When 1, colorized output will be used when isatty() is true. When set to 2 colorized output will always be used. */
    BOOL spico_int_only;                      /**< If set, AAPL will warn the user of any SBus commands (that are not SPICO interrupts). It will also convert all serdes_mem_rmw commands into non-atomic RMWs.  */
                                              /**< The user will then need to manually configure the AAPL struct as avago_get_ip_info() will not work properly. */

    int enable_debug_logging;                 /**< When enabled, data sent to DEBUGn will also be added to the AAPL log */
    int enable_stream_logging;                /**< When enabled, INFO and DEBUGn messages are written to AAPL_STREAM (if defined) */
    int enable_stream_err_logging;            /**< When enabled, warnings and errors are written to AAPL_STREAM_ERR (if defined) */
    char *logging_file_path;                  /**< Redirect all INFO and DEBUGn messages to user specified file */
                                              /**< Setting file path to this variable will enable redirecting data to the file. */
                                              /**< This is intended for short term debugging. */

    int log_time_stamps;                      /**< When enabled, time stamps are added to AAPL logs and DEBUGn output */

    int serdes_int_timeout;                   /**< 28nm SerDes SPICO interrupt maximum number of tries */
    int sbus_mdio_timeout;                    /**< sbus-over-mdio SBUS_RESULT polling maximum number of tries */
    uint tck_delay;                           /**< Allows user to slow down bit-banged GPIO JTAG operations */

    Aapl_comm_method_t communication_method;  /**< Method for communicating with Avago devices. */

    uint chips;                               /**< number of die this struct points to */
    uint sbus_rings;                          /**< number of SBus rings this struct points to */

    int max_cmds_buffered;                    /**< Maximum bumber of commands to queue before sending them via TCP over AACS. */
                                              /**< Setting this to 0 disables command buffering */
    int prior_connection;                     /**< Indicates if this AAPL struct has ever connected to an AACS server. */
    int disable_reconnect;                    /**< Don't allow AAPL to reconnect to TCP clients */

    int cmds_buffered;                        /**< number of commands in buf_cmd (which are bufferred AACS commands) */

    uint capabilities;                        /**< Bitmask of the remote AACS Server's capabilities */

    BOOL aacs;                                /**< Is AACS being used for communication? */
    uint tap_gen;                             /**< Avago TAP generation being communicated with */

    uint sbus_commands;                       /**< SBus commands executed */
    uint commands;                            /**< AACS Server commands received */

    int errors;                               /**< Incremented each time an error occurs */
    int warnings;                             /**< Incremented each time an error occurs */
    int data;                                 /**< used for functions that return int data */

#ifndef AAPL_ASCRIPT_BUILD
    uint  (*sbus_fn)             (struct _Aapl_t *aapl, uint addr, unsigned char reg_addr, unsigned char command, uint *sbus_data);
    uint  (*sbus_fn_2)           (struct _Aapl_t *aapl, uint addr, unsigned char reg_addr, unsigned char command, uint *sbus_data, uint flags);
    int   (*hard_sbus_reset_fn)  (struct _Aapl_t *aapl, uint addr);
    int   (*comm_open_fn)        (struct _Aapl_t *aapl);
    int   (*comm_close_fn)       (struct _Aapl_t *aapl);
    uint  (*jtag_idcode_fn)      (struct _Aapl_t *aapl, uint device);

    uint  (*pmi_fn)              (struct _Aapl_t *aapl, uint sbus_addr, int command, uint reg_addr, uint *data, uint mask);
#if AAPL_ENABLE_ATE_VEC
    int   (*ate_vec_fn)          (struct _Aapl_t *aapl, const char *command);
#endif

    int   (*i2c_write_fn)        (struct _Aapl_t *aapl, unsigned int dev_addr, unsigned int length, unsigned char * buffer);
    int   (*i2c_read_fn)         (struct _Aapl_t *aapl, unsigned int dev_addr, unsigned int length, unsigned char * buffer);

    uint  (*mdio_fn)             (struct _Aapl_t *aapl, Avago_mdio_cmd_t mdio_cmd, uint port_addr, uint dev_addr, uint reg_addr, uint data);

    char *(*jtag_fn)             (struct _Aapl_t *aapl, int opcode, int bits, const char *tdi, BOOL get_tdo);
    BOOL  (*bit_banged_jtag_fn)  (struct _Aapl_t *aapl, BOOL tms, BOOL tdi, BOOL trst_l, BOOL get_tdo);
    uint  (*serdes_int_fn)       (struct _Aapl_t *aapl, uint addr, int int_code, int int_data);
    void  (* log_fn)             (struct _Aapl_t *aapl, Aapl_log_type_t log_sel, const char * buf, size_t new_item_length);
    int   (* log_open_fn)        (struct _Aapl_t *aapl);
    int   (* log_close_fn)       (struct _Aapl_t *aapl);

    int   (*parallel_serdes_int_fn) (struct _Aapl_t *aapl, Avago_addr_t *addr_list, int int_num, int int_data);

    void *client_data;                        /**< Pointer for client data of arbitrary type. */
    volatile int async_cancel;

    /* END of public SWIG members */
# ifndef SWIG    /* stuff in this block doesn't need to be exported for SWIG. */

#if AAPL_ALLOW_OFFLINE_SBUS
    int *offline_sbus_reg;                    /**< Pointer to offline SBus storage */
#endif
#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
    volatile unsigned *rpi_gpio_access;       /**< memory mapped I/O access on rpi. Used by GPIO JTAG access functions */
    int prev_opcode;
    unsigned char recv_data_valid[AAPL_MAX_CHIPS][AAPL_MAX_RINGS]; /**< Last value of recv_data_valid (used in SBus over JTAG modes) */
    char sbus_reg[128];                       /**< SBus IJTAG register. Gets ORed in whenever an SBus an command is sent (in SBus over JTAG modes) (used globally for all rings and chips) */
    uint curr_chip;                           /**< Current chip that we're communicating with (used for JTAG and BB JTAG functions) */
                                              /**< Set using aapl_set_chip(). */

    char *buf_cmd, *buf_cmd_end;              /**< Pointer to start/end of AACS command buffer */
#endif

    const char *chip_name[AAPL_MAX_CHIPS];  /**< Array of chip name pointers */
    const char *chip_rev[AAPL_MAX_CHIPS];   /**< Array of chip revision pointers */

    char *aacs_server_buffer;               /**< Pointer to aacs_server's internal buffer */
    char *aacs_server;                      /**< Server name (or IP address) used to open the AACS socket */
    int socket;                             /**< Socket used for AACS TCP communications. */
                                            /**< It must be >= 0 after successful open, and < 0 on open failure and after close. */
                                            /**< If open/close don't touch this, AAPL will manage its value. */
    int tcp_port;                           /**< TCP port used to open the AACS socket */

    uint jtag_idcode[AAPL_MAX_CHIPS];       /**< JTAG IDCODE for each chip */
    Avago_process_id_t process_id[AAPL_MAX_CHIPS]; /**< Process Identifier for each chip */

    uint last_mdio_addr[AAPL_MAX_CHIPS];    /**< Last MDIO address used */
    uint mdio_base_port_addr;               /**< MDIO base port address. */
    int  i2c_base_addr;                     /**< I2C base address. */
    uint sbus_tdr_opcode_base;              /**< Opcode for first SBus iJTAG chain */
    unsigned short       ip_rev[AAPL_MAX_CHIPS][AAPL_MAX_RINGS][256]; /**< IP revision for each SBus Rx */
    unsigned short     firm_rev[AAPL_MAX_CHIPS][AAPL_MAX_RINGS][256]; /**< Revision of firmware load, populated if ip_type is SERDES or SPICO */
    unsigned short   firm_build[AAPL_MAX_CHIPS][AAPL_MAX_RINGS][256]; /**< Build of firmware load, populated if ip_type is SERDES or SPICO */
    char          spico_running[AAPL_MAX_CHIPS][AAPL_MAX_RINGS][256]; /**< Indicator of SPICO processor is running. */
    unsigned char       ip_type[AAPL_MAX_CHIPS][AAPL_MAX_RINGS][256]; /**< Avago_ip_type_t identifier for each SBus Rx */
    signed   char       lsb_rev[AAPL_MAX_CHIPS][AAPL_MAX_RINGS][256]; /**< Revision of LSB block, populated if ip_type is SERDES */
    unsigned char max_sbus_addr[AAPL_MAX_CHIPS][AAPL_MAX_RINGS];      /**< max SBus address for each die and SBus ring */
#  if AAPL_ENABLE_FILE_IO
    char         *firmware_file[AAPL_MAX_CHIPS][AAPL_MAX_RINGS][256]; /**< Keeps track of firmware file loaded */
#  endif

    /* IO variables used to pass data to/from most functions and to maintain command sent and error logs */
    int return_code;        /**< set by most functions to indicate success/fail status */

    char *data_char;        /**< used for functions that return strings */
    char *data_char_end;    /**< to truncate data_char, set data_char_end = data_char; */
    int   data_char_size;   /**< data_char memory management */

    char *log;              /**< memory log, logs commands, info,errors, warnings, and debug statements */
    char *log_end;          /**< to truncate log, set log_end = log; */
    int   log_size;         /**< memory log managment */
    char *last_log;         /**< pointer to start of most recent item stored in the log */
    char *last_err;         /**< pointer to start of most recent warning or error */


#if AAPL_ALLOW_THREADED_SBUS || AAPL_ALLOW_THREAD_SUPPORT
    BOOL destroy_thread;
#endif /* AAPL_ALLOW_THREADED_SBUS || AAPL_ALLOW_THREAD_SUPPORT */
#if AAPL_ALLOW_THREAD_SUPPORT && AAPL_ENABLE_HS2
    pthread_t telnet_thread;
#endif
#if AAPL_ALLOW_THREADED_SBUS
    pthread_t sbus_thread;
    uint sbus_sa;
    unsigned char sbus_da;
    unsigned char sbus_cmd;
    volatile uint sbus_data;
    BOOL sbus_recv_data_back;
    volatile    BOOL sbus_execute;
#endif /* AAPL_ALLOW_THREADED_SBUS */
#if AAPL_ALLOW_THREAD_SUPPORT
    #define AAPL_SPICO_INT_LOCK \
        {if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Attempting to lock.\n"); \
        pthread_mutex_lock(&aapl->spico_int_mutex); \
        if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Lock complete.\n");}
    #define AAPL_SPICO_INT_UNLOCK \
        {pthread_mutex_unlock(&aapl->spico_int_mutex); \
        if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Unlock.\n");}

    #define AAPL_CLOSE_LOCK \
        {if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Attempting to lock.\n"); \
        pthread_mutex_lock(&aapl->close_mutex); \
        if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Lock complete.\n");}
    #define AAPL_CLOSE_UNLOCK \
        {pthread_mutex_unlock(&aapl->close_mutex); \
        if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Unlock.\n");}

    #define AAPL_AACS_LOCK \
        {if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Attempting to lock.\n"); \
        pthread_mutex_lock(&aapl->aacs_mutex); \
        if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Lock complete.\n");}
    #define AAPL_AACS_UNLOCK \
        {pthread_mutex_unlock(&aapl->aacs_mutex); \
        if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Unlock.\n");}

    #define AAPL_SERDES_MEM_LOCK \
        {if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Attempting to lock (%d).\n", mem_lock_count); \
        if (!mem_lock_count) pthread_mutex_lock(&aapl->serdes_mem_mutex); \
        mem_lock_count += 1; \
        if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Lock complete (%d).\n", mem_lock_count);}
    #define AAPL_SERDES_MEM_UNLOCK \
        {mem_lock_count --; if (!mem_lock_count) pthread_mutex_unlock(&aapl->serdes_mem_mutex); \
        if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Unlock (%d).\n", mem_lock_count);}

    #define AAPL_IP_INFO_LOCK \
        {if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Attempting to lock (%d).\n", ip_lock_count); \
        if (!ip_lock_count) pthread_mutex_lock(&aapl->ip_info_mutex); \
        ip_lock_count += 1; \
        if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Lock complete (%d).\n", ip_lock_count);}
    #define AAPL_IP_INFO_UNLOCK \
        {ip_lock_count --; if (!ip_lock_count) pthread_mutex_unlock(&aapl->ip_info_mutex); \
        if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Unlock (%d).\n", ip_lock_count);}

    #define AAPL_SENSOR_LOCK \
        {if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Attempting to lock.\n"); \
        pthread_mutex_lock(&aapl->sensor_mutex); \
        if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Lock complete.\n");}
    #define AAPL_SENSOR_UNLOCK \
        {pthread_mutex_unlock(&aapl->sensor_mutex); \
        if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Unlock.\n");}

    #define AAPL_PRINTF_LOCK \
        {pthread_mutex_lock(&aapl->log_printf_mutex);}
    #define AAPL_PRINTF_UNLOCK \
        {pthread_mutex_unlock(&aapl->log_printf_mutex);}

    #define AAPL_SBUS_LOCK \
        {if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Attempting to lock.\n"); \
        pthread_mutex_lock(&aapl->sbus_mutex); \
        if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Lock complete.\n");}
    #define AAPL_SBUS_UNLOCK \
        {pthread_mutex_unlock(&aapl->sbus_mutex); \
        if (aapl->debug & AAPL_DEBUG_LOCK) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Unlock.\n");}

    #define AAPL_HAL_LOCK \
        {pthread_mutex_lock(&aapl->hal_mutex);}
    #define AAPL_HAL_UNLOCK \
        {pthread_mutex_unlock(&aapl->hal_mutex);}

    /* Thread related variables */
 /* pthread_mutex_t sbus_execute_mutex; */

    pthread_mutex_t aacs_mutex;
    pthread_mutex_t close_mutex;
    pthread_mutex_t hal_mutex;
    pthread_mutex_t ip_info_mutex;
    pthread_mutex_t log_printf_mutex;
    pthread_mutex_t sbus_mutex;
    pthread_mutex_t sensor_mutex;
    pthread_mutex_t serdes_mem_mutex;
    pthread_mutex_t spico_int_mutex;

#else
    #define AAPL_AACS_LOCK
    #define AAPL_AACS_UNLOCK
    #define AAPL_CLOSE_LOCK
    #define AAPL_CLOSE_UNLOCK
    #define AAPL_HAL_LOCK
    #define AAPL_HAL_UNLOCK
    #define AAPL_IP_INFO_LOCK
    #define AAPL_IP_INFO_UNLOCK
    #define AAPL_PRINTF_LOCK
    #define AAPL_PRINTF_UNLOCK
    #define AAPL_SBUS_LOCK
    #define AAPL_SBUS_UNLOCK
    #define AAPL_SENSOR_LOCK
    #define AAPL_SENSOR_UNLOCK
    #define AAPL_SERDES_MEM_LOCK
    #define AAPL_SERDES_MEM_UNLOCK
    #define AAPL_SPICO_INT_LOCK
    #define AAPL_SPICO_INT_UNLOCK
#endif /* AAPL_ALLOW_THREAD_SUPPORT */

# endif  /* not SWIG */
# endif /* not AAPL_ASCRIPT_BUILD */
} Aapl_t;

/* Create a pointer to a new AAPL struct */
EXT Aapl_t *aapl_construct(void);
EXT void    aapl_destruct(Aapl_t *aapl);

/* Address list handling functions: */
EXT void          avago_addr_init(Avago_addr_t *addr_struct);
EXT Avago_addr_t *avago_addr_new(Aapl_t *aapl);
EXT Avago_addr_t *avago_addr_new_from_struct(Aapl_t *aapl, Avago_addr_t *initial_value);
EXT void          avago_addr_delete(Aapl_t *aapl, Avago_addr_t *addr_list);
EXT void          avago_group_expand_broadcast(Aapl_t *aapl, Avago_addr_t *addr_list);
EXT void          avago_group_setup(Aapl_t *aapl, Avago_addr_t *addr_list);
EXT void          avago_group_clear(Aapl_t *aapl, Avago_addr_t *addr_list);
EXT Avago_addr_t *avago_group_get_next(Avago_addr_t *addr_list);
EXT uint          avago_group_get_addr(Avago_addr_t *addr_list);
EXT void          avago_print_addr_list(Aapl_t *aapl, Aapl_log_type_t debug, Avago_addr_t *addr_list, const char *caller, uint line);

EXT BOOL avago_addr_to_struct(uint addr, Avago_addr_t *addr_struct);
EXT uint avago_struct_to_addr(Avago_addr_t *addr);

EXT uint avago_addr_init_broadcast(Avago_addr_t *addr_struct);
EXT uint avago_make_addr3(int chip, int ring, int sbus);
EXT uint avago_make_addr4(int chip, int ring, int sbus, int lane);
EXT uint avago_make_sbus_addr(uint addr, int sbus);
EXT uint avago_make_sbus_lane_addr(uint addr, int lane);
EXT uint avago_make_sbus_master_addr(uint addr);
EXT uint avago_make_sbus_controller_addr(uint addr);
EXT uint avago_make_serdes_broadcast_addr(uint addr);

EXT int aapl_get_async_cancel_flag(Aapl_t *aapl);
EXT int aapl_set_async_cancel_flag(Aapl_t *aapl, int new_value);

/* Returns the return code and then sets it to zero. Values less than 0 indicate failure, while 0 indicates no error. */
EXT int         aapl_get_return_code(Aapl_t *aapl);

/* The following functions return information from the Aapl_t struct. addr is used to return specific information for that element. */
EXT uint        aapl_get_chips(Aapl_t *aapl);
EXT uint        aapl_get_max_sbus_addr(Aapl_t *aapl, uint addr);
EXT uint        aapl_get_jtag_idcode(Aapl_t *aapl, uint addr);
EXT const char *aapl_get_chip_name(Aapl_t *aapl, uint addr);
EXT const char *aapl_get_chip_rev_str(Aapl_t *aapl, uint addr);
EXT const char *aapl_get_process_id_str(Aapl_t *aapl, uint addr);
EXT uint        aapl_get_ip_rev(Aapl_t *aapl, uint addr);
EXT uint        aapl_get_lsb_rev(Aapl_t *aapl, uint addr);
EXT int         aapl_get_firmware_rev(Aapl_t *aapl, uint addr);
EXT int         aapl_get_firmware_build(Aapl_t *aapl, uint addr);
/* Functions to access client defined aapl data */
EXT void        aapl_bind_set(Aapl_t *aapl, void *client_data );
EXT void       *aapl_bind_get(Aapl_t *aapl);

EXT Avago_process_id_t     aapl_get_process_id(Aapl_t *aapl, uint addr);
EXT Avago_ip_type_t        aapl_get_ip_type(Aapl_t *aapl, uint addr);
EXT void                   aapl_set_ip_type(Aapl_t *aapl, uint addr);
EXT BOOL aapl_get_spico_running_flag(Aapl_t *aapl, uint addr);
EXT BOOL aapl_set_spico_running_flag(Aapl_t *aapl, uint addr, BOOL running);

#ifdef AAPL_ENABLE_INTERNAL_FUNCTIONS
/* Functions to manage chip selection: */
EXT void aapl_set_chip(Aapl_t *aapl, uint chipnum);
EXT void aapl_set_chip_by_addr(Aapl_t *aapl, uint addr);
#endif

/* Query ASIC(s) to fully fill out the AAPL struct. Should be done before using. */
EXT void    aapl_get_ip_info(Aapl_t *aapl, int chip_reset);

/* Send / receive JTAG information. */
typedef enum
{
    AVAGO_SHIFT_DR,
    AVAGO_RTI
} Aapl_jtag_state_t;
EXT char *avago_jtag(        Aapl_t *aapl, int opcode, int length, const char *data);
EXT char *avago_jtag_options(Aapl_t *aapl, int opcode, int length, const char *data, BOOL get_tdo);
EXT char *avago_jtag_rd(     Aapl_t *aapl, int opcode, int length);
EXT char *avago_jtag_rd_len( Aapl_t *aapl, int opcode, int *length);
EXT void  avago_jtag_set_bit(Aapl_t *aapl, int opcode, uint length, uint set_bit, uint value);
EXT void  avago_jtag_scan(   Aapl_t *aapl, int length, int tms, const char * tdi, char * tdo);
EXT void  avago_jtag_scan_options(Aapl_t *aapl, int length, int tms, const char * tdi, char * tdo, Aapl_jtag_state_t state);
EXT void avago_jtag_reset(   Aapl_t *aapl, int chip);

/* checks addr against ip_type or process. Args is the number of arguments passed in for ip_type or process */
/* for example: aapl_check_ip_type(aapl, addr, __func__,__LINE__, 2, AVAGO_SERDES, AVAGO_QPI); */
EXT BOOL aapl_check_ip_type(       Aapl_t *aapl, uint addr, const char *caller, int line, int error, int args, ...);
EXT BOOL aapl_check_ip_type_exists(Aapl_t *aapl, uint addr, const char *caller, int line, int error, int args, ...);
EXT BOOL aapl_check_process(       Aapl_t *aapl, uint addr, const char *caller, int line, int error, int args, ...);
EXT BOOL aapl_check_firmware_rev(  Aapl_t *aapl, uint addr, const char *caller, int line, int error, int args, ...);
EXT BOOL aapl_check_firmware_build(Aapl_t *aapl, uint addr, const char *caller, int line, int error, int args, ...);
EXT BOOL aapl_check_broadcast_address( Aapl_t *aapl, uint addr, const char *caller, int line, int error_on_match);

EXT void avago_system_chip_setup(Aapl_t *aapl, int reset, int chip);
EXT uint avago_get_tap_gen(Aapl_t *aapl);


/* Setup AAPL's connection to a device. */
/* If using an AVAGO_AACS_* communication method, this will setup a TCP connection. */
EXT void aapl_connect(Aapl_t *aapl, const char *aacs_server, int tcp_port);
EXT void aapl_close_connection(Aapl_t *aapl);
EXT int  aapl_connection_status(Aapl_t *aapl);  /* 0 indicates "open" */

#ifdef AAPL_ENABLE_INTERNAL_FUNCTIONS
EXT BOOL aapl_check_sdrev(Aapl_t *aapl, uint addr, const char *caller, int line, int error, int args, ...);
EXT void aapl_close_connection2(Aapl_t *aapl);  /* close without flushing -- internal use only */
EXT int  aapl_reconnect(Aapl_t *aapl, const char * command);
EXT int  aapl_send(Aapl_t *aapl, char * data, int len, int tcp_port);
#endif /* AAPL_ENABLE_INTERNAL_FUNCTIONS */

EXT BOOL aapl_is_jtag_communication_method(Aapl_t *aapl);
EXT BOOL aapl_is_i2c_communication_method(Aapl_t *aapl);
EXT BOOL aapl_is_mdio_communication_method(Aapl_t *aapl);
EXT BOOL aapl_is_sbus_communication_method(Aapl_t *aapl);
EXT BOOL aapl_is_aacs_communication_method(Aapl_t *aapl);

EXT char *avago_read_efuse_chain(Aapl_t *aapl, uint chip, const char *mapfilename);
EXT char *avago_format_efuse_chain(Aapl_t *aapl, uint chip, const char *efuse_chain);

#ifdef AAPL_ENABLE_INTERNAL_FUNCTIONS
#define AAPL_BROADCAST_IGNORE_LANE     (0x01)
#define AAPL_BROADCAST_NO_ITER_LANE    (0x02)
#define AAPL_BROADCAST_LANE            (0x04)
#define AAPL_BROADCAST_NO_ITER_SBUS    (0x08)
EXT BOOL aapl_broadcast_first(Aapl_t *aapl, Avago_addr_t *addr, Avago_addr_t *start, Avago_addr_t *stop, Avago_addr_t *first, uint flags);
EXT BOOL aapl_broadcast_next(Aapl_t *aapl, Avago_addr_t *addr, Avago_addr_t *start, Avago_addr_t *stop, uint flags);
EXT BOOL aapl_addr_selects_fw_device(Aapl_t *aapl, Avago_addr_t *addr_struct, uint addr, BOOL *ignore);
EXT BOOL aapl_is_octal_p1(Aapl_t *aapl, uint addr);

#  if AAPL_ENABLE_FILE_IO
    EXT char *aapl_read_file(Aapl_t *aapl, const char *filename);
#  endif

typedef enum
{
    AAPL_SDREV_UNKNOWN = 0, /* Unknown */
    AAPL_SDREV_D6      = 1, /* 28nm D6 */
    AAPL_SDREV_16      = 2, /* 16nm D6 */
    AAPL_SDREV_P1      = 3, /* 28nm P1 */
    AAPL_SDREV_HVD6    = 4, /* 28nm HVD6 */
    AAPL_SDREV_OM4     = 5, /* 28nm OM4 */
    AAPL_SDREV_CM4     = 6, /* 28nm CM4 */
    AAPL_SDREV_CM4_16  = 7, /* 16nm CM4 */
    AAPL_SDREV_PON     = 9, /* 16nm PON */
    AAPL_SDREV_D6_07   =10, /*  7nm D6 */
    AAPL_SDREV_BH_07   =11, /*  7nm Blackhawk */
    AAPL_SDREV_BH_16   =12, /* 16nm Blackhawk */
    AAPL_SDREV_XXX
} Aapl_sdrev_t;
EXT int aapl_get_sdrev(Aapl_t *aapl, uint addr);
EXT int aapl_get_interrupt_rev(Aapl_t *aapl, uint addr, int int_num);

#endif /* AAPL_ENABLE_INTERNAL_FUNCTIONS */

/*////////////////////////////////////////////////////////////////////// */
/* AAPL memory functions that log on allocation failure: */

#ifndef aapl_malloc
EXT void *aapl_malloc(Aapl_t *aapl, size_t bytes, const char *description);
EXT void *aapl_realloc(Aapl_t *aapl, void *ptr, size_t bytes, const char *description);
EXT void  aapl_free(Aapl_t *aapl, void *ptr, const char *description);
#endif


/*////////////////////////////////////////////////////////////////////// */
/* AACS Functions and Globals */

/* Size of buffer for SBus commands. Largest command could be: */
/* sbus 00 00 00 0x00000000 */
/* NOTE: Currently no comments are sent, so this is the biggest possible command */
#define AAPL_SBUS_CMD_LOG_BUF_SIZE (32)


/* Always available, but may be empty: */
EXT const char *avago_aacs_send_command(            Aapl_t *aapl, const char *cmd);
EXT int         avago_aacs_send_command_int(        Aapl_t *aapl, const char *cmd);
EXT const char *avago_aacs_send_command_options(    Aapl_t *aapl, const char *cmd,     int recv_data_back, int strtol);
EXT int         avago_aacs_send_command_options_int(Aapl_t *aapl, const char *command, int recv_data_back);
EXT void        avago_aacs_flush(Aapl_t *aapl);

#if AAPL_ALLOW_AACS

# ifdef AAPL_ENABLE_INTERNAL_FUNCTIONS
    EXT int avago_aacs_open_fn(Aapl_t *aapl);
    EXT int avago_aacs_close_fn(Aapl_t *aapl);
    EXT uint aapl_aacs_sbus_fn(Aapl_t *aapl, uint addr, unsigned char reg_addr, unsigned char command, uint *sbus_data, uint recv_data_back);

    EXT const char *aapl_tcp_strerr(void);
    EXT int aapl_recv(Aapl_t *aapl);
    EXT void aapl_check_capabilities(Aapl_t *aapl);
# endif /* AAPL_ENABLE_INTERNAL_FUNCTIONS */

#endif /* AAPL_ALLOW_AACS */

# ifndef SWIG
    EXT const char *aapl_default_server;
    EXT const uint  aapl_default_port;
# endif


#if AAPL_ENABLE_ATE_VEC
EXT void aapl_register_ate_vec_fn(Aapl_t *aapl,
    int (*ate_vec_fn)(Aapl_t *, const char *command)
);
#endif

EXT void aapl_register_sbus_fn(Aapl_t *aapl,
    uint (* user_sbus_fn)(Aapl_t *, uint addr, unsigned char reg_addr, unsigned char command, uint *sbus_data),
    int (* comm_open_fn)(Aapl_t *),
    int (* comm_close_fn)(Aapl_t *)
);

EXT void aapl_register_hard_sbus_reset_fn(Aapl_t *aapl,
    int  (*hard_sbus_reset_fn)(Aapl_t *aapl, uint addr)
);

EXT void aapl_register_mdio_fn(Aapl_t *aapl,
    uint (* mdio_fn)(Aapl_t *, Avago_mdio_cmd_t mdio_cmd, uint port_addr, uint dev_addr, uint reg_addr, uint data),
    int (* comm_open_fn)(Aapl_t *),
    int (* comm_close_fn)(Aapl_t *)
);

EXT void aapl_register_i2c_fn(Aapl_t *aapl,
    int (* i2c_rd_fn)(Aapl_t *, uint dev_addr, uint length, unsigned char * buffer),
    int (* i2c_wr_fn)(Aapl_t *, uint dev_addr, uint length, unsigned char * buffer),
    int (* comm_open_fn)(Aapl_t *),
    int (* comm_close_fn)(Aapl_t *)
);

EXT void aapl_register_jtag_fn(Aapl_t *aapl,
    char *(* jtag_fn)(Aapl_t *, int opcode, int bits, const char *tdi, BOOL get_tdo),
    int (* comm_open_fn)(Aapl_t *),
    int (* comm_close_fn)(Aapl_t *)
);

EXT void aapl_register_bit_banged_jtag_fn(Aapl_t *aapl,
    int (* jtag_fn)(Aapl_t *, BOOL tms, BOOL tdi, BOOL trst_l, BOOL get_tdo),
    int (* comm_open_fn)(Aapl_t *),
    int (* comm_close_fn)(Aapl_t *)
);

EXT void aapl_register_spico_int_fn(Aapl_t *aapl,
    uint  (*serdes_int_fn)     (Aapl_t *aapl, uint addr, int int_code, int int_data)
);

EXT void aapl_register_parallel_serdes_int_fn(Aapl_t *aapl,
     int  (*parallel_serdes_int_fn) (Aapl_t *aapl, Avago_addr_t *addr_list, int int_code, int int_data)
);

EXT void aapl_register_jtag_idcode_fn(Aapl_t *aapl,
    uint (* jtag_idcode_fn)(Aapl_t *, uint device)
);

EXT void aapl_register_user_supplied_functions(Aapl_t *aapl);

EXT void aapl_sigint_check(Aapl_t *aapl);

/*EXT void aapl_register_pmi_fn(Aapl_t *aapl, */
/*    uint  (*pmi_fn)      (Aapl_t *aapl, uint sbus_addr, int command, uint reg_addr, uint *data, uint mask) */
/*); */

#endif /* AAPL_CORE_H_ */
