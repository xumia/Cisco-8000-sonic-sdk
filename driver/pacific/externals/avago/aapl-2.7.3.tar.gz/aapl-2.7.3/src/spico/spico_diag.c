/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* AAPL (ASIC and ASSP Programming Layer) SPICO diagnostics */

/** Doxygen File Header */
/** @file */
/** @brief Functions for SerDes diagnostics. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_DIAG

/** @cond INTERNAL */

#if AAPL_ENABLE_FILE_IO
/** @brief   Searches for a diagnostic file that matches the SerDes firmware */
/**          running on the SPICO at addr, and if found, reads the file into */
/**          memory. */
/** @return  On success, returns an allocated buffer with contents of file. */
/**          Call aapl_free() to release the buffer after use. */
/** @return  Returns NULL if a file is not found. */
char *read_spico_file(Aapl_t *aapl, uint addr, const char *suffix)
{
    char *file = 0;
    char filename[256];
    char *ptr = filename;
    char ip_type[16];
    int eng_rel = avago_firmware_get_engineering_id(aapl, addr);

    if( aapl_check_ip_type(aapl, addr, 0, 0, FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) )
         snprintf(ip_type, sizeof(ip_type), "serdes");
    else snprintf(ip_type, sizeof(ip_type), "sbus_master");

    /* now try local directory */
    ptr = filename;
    ptr += sprintf(ptr, "%s.0x%04X_%04X", ip_type, aapl_get_firmware_rev(aapl, addr), aapl_get_firmware_build(aapl, addr));
    if( eng_rel ) ptr += sprintf(ptr, "_%03X", eng_rel);
    ptr += sprintf(ptr, "%s", suffix);
    file = aapl_read_file(aapl, filename);
    if (file) return file;

    /* now try local directory */
    ptr = filename;
    ptr += sprintf(ptr, "%s.%04X%s", ip_type, aapl_get_firmware_build(aapl, addr), suffix);
    file = aapl_read_file(aapl, filename);
    if( !file )
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Sbus %s, %s file for uploaded firmware (rev: 0x%04X, build: 0x%04X, eng_rel: 0x%03X) not found.\n",
                        aapl_addr_to_str(addr), suffix, aapl_get_firmware_rev(aapl, addr),  aapl_get_firmware_build(aapl, addr), eng_rel);
    else return file;

    /* now try local directory with build of 0000 */
    ptr = filename;
    ptr += sprintf(ptr, "%s.0000%s", ip_type, suffix);
    file = aapl_read_file(aapl, filename);
    if (file) return file;


    ptr = filename;
    ptr += sprintf(ptr, AVAGO_FIRMWARE_PATH);

    if( eng_rel ) ptr += sprintf(ptr, "engineering_releases/%s/%s.0x%04X_%04X_%03X/%s.0x%04X_%04X_%03X",ip_type, ip_type, aapl_get_firmware_rev(aapl, addr),
                                      aapl_get_firmware_build(aapl, addr), eng_rel, ip_type, aapl_get_firmware_rev(aapl, addr),
                                      aapl_get_firmware_build(aapl, addr), eng_rel);
    else          ptr += sprintf(ptr, "%s/0x%04X/%s.0x%04X_%04X", ip_type, aapl_get_firmware_rev(aapl, addr),
                                      ip_type, aapl_get_firmware_rev(aapl, addr), aapl_get_firmware_build(aapl, addr));

    ptr += sprintf(ptr, "%s", suffix);
    file = aapl_read_file(aapl, filename);
    if (file) return file;

    return file;
}
#endif /* AAPL_ENABLE_FILE_IO */

static int spico_label_lookup(char *file, const char *label)
{
    if( file && label )
    {
        char *found1 = strstr(file, label); /* find label */
        if (found1)
        {
            found1 = strstr(found1, "\t"); /* move past label */
            if (found1)
                return aapl_strtol(found1, 0, 16) & 0xffffffff;
        }
    }
    return 0;
}

static void spico_imem_lookup(char *file, char *str, int pc)
{
    (void)pc;
    str[0] = 0;
    if (file)
    {
        char *found1;
        char find_str[32]; /* what we're searching for */

        snprintf(find_str, 9, "%04x ", pc & 0xffff);
        found1 = strstr(file, find_str);
        if( found1 )
        {
            char *found2 = strstr(found1, "\n");
            if (found2 && (found2-found1 < 1000)) /* did we find something and do we have enough room? */
            {
                strncpy(str, found1, found2-found1);
                str[found2-found1] = 0; /* string terminator */
            }
        }
    }
}

/** @brief   Returns the SPICO status byte from the processor. */
/** @return  SPICO's status byte */
/** @see     avago_spico_status */
static uint avago_spico_get_status(Aapl_t *aapl, uint addr)
{
    switch( aapl_get_ip_type(aapl, addr) )
    {
    case AVAGO_P1:
    case AVAGO_M4:
    case AVAGO_SERDES: return avago_sbus_rd(aapl, addr, 0x27);
    case AVAGO_SPICO:  return avago_sbus_rd(aapl, addr, 0x0c)  /* status */
                            | avago_sbus_rd(aapl, addr, 0x0e);  /* error code */
    default:           return 0;
    }
}

static uint avago_spico_get_operands(Aapl_t *aapl, uint addr)
{
    switch( aapl_get_ip_type(aapl, addr) )
    {
    case AVAGO_P1:
    case AVAGO_M4:
    case AVAGO_SERDES: return avago_sbus_rd(aapl, addr, 0x28);
    case AVAGO_SPICO:  return avago_sbus_rd(aapl, addr, 0x0d);
    default:           return 0;
    }
}

static uint avago_spico_get_result(Aapl_t *aapl, uint addr)
{
    switch( aapl_get_ip_type(aapl, addr) )
    {
    case AVAGO_P1:
    case AVAGO_M4:
    case AVAGO_SERDES: return avago_sbus_rd(aapl, addr, 0x29);
    case AVAGO_SPICO:  return avago_sbus_rd(aapl, addr, 0x10);
    default:           return 0;
    }
}

static uint avago_spico_get_ab_reg(Aapl_t *aapl, uint addr)
{
    switch( aapl_get_ip_type(aapl, addr) )
    {
    case AVAGO_P1:
    case AVAGO_M4:
    case AVAGO_SERDES: return avago_sbus_rd(aapl, addr, 0x2b);
    case AVAGO_SPICO:  return avago_sbus_rd(aapl, addr, 0x11);
    default:           return 0;
    }
}

/** @brief  Single step the addressed SPICO processor. */
/** @return void */
void avago_spico_single_step(Aapl_t *aapl, uint addr, uint state)
{
    switch( aapl_get_ip_type(aapl, addr) )
    {
    case AVAGO_P1:
    case AVAGO_M4:
    case AVAGO_SERDES: avago_sbus_wr(aapl, addr, 0x20, state | 0x3); /* single step */
                       break;
    case AVAGO_SPICO:  avago_sbus_wr(aapl, addr, 0x5, state | 0x1);  /* single step */
                       avago_sbus_wr(aapl, addr, 0x5, state | 0x3);  /* single step */
    default:           return;
    }
}

/** @brief  Print spico trace header */
/** @return void */
static void avago_spico_diag_header(Aapl_t *aapl, BOOL is_snap)
{
    if( is_snap )
        aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%4s %4s %2s %5s %3s %4s %4s %8s %2s %4s %4s %4s %4s %4s\n", "PC", "SP", "ER", "SCNOZ", "INS", "OP1", "OP2", "RESULT", "ST", "A", "B", "C", "D", "E");
    else
        aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%4s %4s %2s %5s %3s %4s %4s %8s %2s %4s %4s\n", "PC", "SP", "ER", "SCNOZ", "INS", "OP1", "OP2", "RESULT", "ST", "A", "B");
}

/** @brief  Print spico trace line */
/** @return void */
/** */
void avago_spico_diag_line(Aapl_t *aapl, uint addr, char *hexfile, char *str, int cycle)
{
    const char decode[] = "-S-C-N-O-Z";
    int status, operands, result, state, ab_reg;
    int pc = avago_spico_get_pc(aapl, addr);
    BOOL is_snap = aapl_get_process_id(aapl,addr) == AVAGO_TSMC_07;

    if ((cycle % 50) == 0) avago_spico_diag_header(aapl, is_snap);

    str[0] = 0; /* clear string */

    spico_imem_lookup(hexfile, str, pc);
    status = avago_spico_get_status(aapl, addr);
    operands = avago_spico_get_operands(aapl, addr);
    result = avago_spico_get_result(aapl, addr);
    state = avago_spico_get_state(aapl, addr);
    ab_reg = avago_spico_get_ab_reg(aapl, addr);
    if( is_snap )
    {
        int cd_reg = avago_sbus_rd(aapl, addr, 28);
        int epsw_reg = avago_sbus_rd(aapl, addr, 29);
        aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%04x %04x %02x %c%c%c%c%c %03x %04x %04x %08x %02x %04x %04x %04x %04x %04x  %s\n",
            pc & 0xffff,
            pc >> 16,
            status >> 27,
            decode[((status >> 24) & 1) + 0],
            decode[((status >> 19) & 1) + 2],
            decode[((status >> 18) & 1) + 4],
            decode[((status >> 17) & 1) + 6],
            decode[((status >> 16) & 1) + 8],
            status & 0x3ff,
            operands & 0xffff,
            (operands >> 16) & 0xffff,
            result,
            state,
            ab_reg & 0xFFFF,
            (ab_reg >> 16) & 0xFFFF,
            cd_reg & 0xFFFF,
            (cd_reg >> 16) & 0xFFFF,
            epsw_reg & 0xFFFF,
            str);
        return;
    }
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%04x %04x %02x %c%c%c%c%c %03x %04x %04x %08x %02x %04x %04x  %s\n",
        pc & 0xffff,
        pc >> 16,
        status >> 27,
        decode[((status >> 24) & 1) + 0],
        decode[((status >> 19) & 1) + 2],
        decode[((status >> 18) & 1) + 4],
        decode[((status >> 17) & 1) + 6],
        decode[((status >> 16) & 1) + 8],
        status & 0x3ff,
        operands & 0xffff,
        (operands >> 16) & 0xffff,
        result,
        state,
        ab_reg & 0xFFFF,
        (ab_reg >> 16) & 0xFFFF,
        str);
}

/** @endcond */

/** @brief  Run diagnostics on SPICO */
/** @return Returns 0 on success, < 0 on failure. */
int avago_spico_diag(Aapl_t *aapl, uint addr, int cycles)
{
    int cycle = 0;
    int initial_state;
    char * hexfile = 0;
    char * tablefile = 0;
    char str[1024];    /* result of search */

    if (!aapl_check_process(aapl, addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28)) return 0;
    if (!aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 4, AVAGO_SPICO, AVAGO_SERDES, AVAGO_M4, AVAGO_P1)) return 0;

#if AAPL_ENABLE_FILE_IO
    hexfile = read_spico_file(aapl, addr, ".hex");
    tablefile = read_spico_file(aapl, addr, ".table");
#endif
    initial_state = avago_spico_halt(aapl, addr);

    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n########## Printing %d subsequent values of SPICO's PC for SBus address %s ##########\n", cycles, aapl_addr_to_str(addr)) ;
    for (cycle = 0; cycle < cycles; cycle++)
    {
        avago_spico_diag_line(aapl, addr, hexfile, str, cycle);
        avago_spico_single_step(aapl, addr, initial_state); /* single step */
    }

    if (aapl_check_ip_type(aapl, addr, __func__, __LINE__, FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1)) /* only works for SerDes */
    {
        int int_number;
        int table_start   = spico_label_lookup(tablefile, "interrupt_debug_xdmem_data");
        int debug_pointer = spico_label_lookup(tablefile, "interrupt_debug_pointer");
        if (table_start)
        {
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Interrupt debug from XDMEM pointer @ 0x%x\n", table_start);
            table_start = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, table_start);
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Interrupt debug from XDMEM data @ 0x%x\n", table_start);
        }
        else
        {
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Interrupt debug from DMEM @ 0x202\n");
            debug_pointer = spico_label_lookup(tablefile, "interrupt_debug_pointer");
            if (!debug_pointer) debug_pointer = 0x202; /* educated guess for D6 serdes */
            table_start = debug_pointer + 1; /* start of table */
        }

        debug_pointer = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, debug_pointer); /* address of where next interrupt would be saved */
        debug_pointer += table_start;

        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n########## Last 8 interrupts received for SBus address %s. ##########\n", aapl_addr_to_str(addr)) ;
        aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%7s   %9s %8s   %8s  (%12s)\n", "", "Interrupt", "Data", "Source", "DMEM address");
        for (int_number = 0; int_number <= 7; int_number ++)
        {
            uint source;
            if (debug_pointer == table_start) debug_pointer = table_start + 24; /* move to end */
            debug_pointer -= 3; /* move backwards one interrupt */
            source = ~avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, debug_pointer+2) & 0xffff;
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%7s      0x%04x   0x%04x   %8s  (0x%04x)\n",
                int_number == 0 ? "Newest" : int_number == 7 ? "Oldest" : "",
                avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, debug_pointer+0),
                avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, debug_pointer+1),
                (source & 0x8000) ? "SBM" : (source & 0x4000) ? "SBus" :  "Core",
                debug_pointer+0);
        }
    }

    if (aapl_check_ip_type(aapl, addr, __func__, __LINE__, FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1)) /* only works for SerDes */
    {
        int sp;
        int pc = avago_spico_get_pc(aapl, addr);
        int m4 = aapl_check_ip_type(aapl, addr, __func__, __LINE__, FALSE, 1, AVAGO_M4);
        int d6_07 = aapl_get_sdrev(aapl, addr) == AAPL_SDREV_D6_07;
        int sp_max = m4 ? 0x57f : d6_07 ? 0x0fff : 0x3ff;
        sp = pc >> 16;
        pc &= 0xffff;

        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n########## Stack dump for SBus address %s. ##########\n", aapl_addr_to_str(addr)) ;
        aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "PC: 0x%04x  SP: 0x%04x\n", pc, sp);
        if (!sp) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "NOTE: Stack pointer either 0 or not available on this hardware revision.\n");
        else aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%6s (%4s %4s %4s %4s) %6s %6s\n", "SP", "sp+0", "sp+1", "sp+2", "sp+3", "Ret1", "Ret2");
        while (sp <= sp_max && sp != 0)
        {
            int a, b, c, d, ret1, ret2;
            a = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, sp);
            b = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, sp+1);
            c = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, sp+2);
            d = avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, sp+3);

            ret1 = (a & 0x3f) << 10 | b;
            ret2 = (c & 0x3f) << 10 | d;

            str[0] = 0;
            spico_imem_lookup(hexfile, str, ret1);
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "0x%04x (%4x %4x %4x %4x) 0x%04x 0x%04x ## %s\n", sp, a, b, c, d, ret1, ret2, str);
            sp += m4 ? 1 : 2;
        }
    }

    avago_spico_resume(aapl, addr, initial_state);

    if (hexfile) aapl_free(aapl, hexfile, __FILE__);
    if (tablefile) aapl_free(aapl, tablefile, __FILE__);

    return aapl->return_code;
}


void avago_spico_dmi_dump(Aapl_t *aapl, uint addr, uint imem_guess)
{
    avago_spico_dmi_dump_file(aapl, addr, 0, imem_guess);
}


static int dmi_mem_rd(Aapl_t *aapl, uint addr, int imem_addr, unsigned short *imem)
{
    if (imem) return imem[imem_addr];
    return avago_serdes_mem_rd(aapl, addr, AVAGO_IMEM, imem_addr);
}


#if AAPL_ENABLE_FILE_IO
#if AAPL_ENABLE_MAIN
static unsigned short *dmi_read_file(Aapl_t *aapl, const char *filename, uint sbus_addr)
{
    char * file;
    char *found1;
    char *save_ptr1;
    int labels = 1;
    int mem_addr = 0;
    unsigned short *imem = 0;
    char buf[64];

    file = aapl_read_file(aapl, filename);
    if (!file) return 0;

    snprintf(buf, 64, "SerDes IMEM dump for SBus address %s", aapl_addr_to_str(sbus_addr));
    aapl_log_printf(aapl, AVAGO_DEBUG1, 0, 0, "Searching for %s.\n", buf);

    found1 = strstr(file, buf);
    if (!found1) 
    {
        snprintf(buf, 64, "SerDes IMEM dump for SBus address");
        aapl_log_printf(aapl, AVAGO_DEBUG1, 0, 0, "Searching for %s.\n", buf);
        found1 = strstr(file, buf);
    }
    if (!found1) 
    {
        aapl_fail(aapl, __func__, __LINE__, "%s", "Did not appear to be valid dumpfile.\n"); 
        goto done;
    }

    found1 = aapl_strtok_r(found1, "\n", &save_ptr1); /* skip the DMEM dump line */
    if (!found1) {aapl_fail(aapl, __func__, __LINE__, "%s", "Did not appear to be valid dumpfile.\n"); goto done;}

    imem = (unsigned short *)aapl_malloc(aapl, 32768 * sizeof(unsigned short), __func__);


    while (1) /* we operate one line at a time and will break when done */
    {
        char *save_ptr2 = 0;
        char *found2;

        found2 = aapl_strtok_r(NULL, "\n", &save_ptr1); /* get this line */
        if (strstr(found2, "WARNING") || strstr(found2, "ERROR") || strstr(found2, "not found")) continue; /* ignore error and warning lines */
        if (strstr(found2, "0x00 0x01")) /* diag output without labels */
        {
            found2 = aapl_strtok_r(NULL, "\n", &save_ptr1); /* skip the header line */
            labels = 0;
        }
        if (!found2) break; /* no more lines? */
        found2 = strstr(found2, "0x"); /* skip past first address marker */
        if (!found2) break; /* line without address? */
        found2 = aapl_strtok_r(found2, " ", &save_ptr2); /* found2 is now the address */
        if (!found2) break; /* */


        while (found2) /* while we have things left on this line to process */
        {
            int mem_value;
            const char *mem_name = "";

            found2 = aapl_strtok_r(NULL, " ", &save_ptr2); /* get next data point */
            if (!found2 || strlen(found2) < 4) break; /* if there's nothing else, move to next line */

            found2[4] = 0; /* pull out 4 character string to convert to address */
            mem_value = aapl_num_from_str(found2, "memory address", 16); /* otherwise it's the next memory address' value */
            if (labels)
            {
                int count = 0;
                while (*save_ptr2 == ' ') {save_ptr2++; count++;}
                if (count < 16) mem_name = aapl_strtok_r(NULL, " ", &save_ptr2); /* if the next field is not blank then capture the name */
            }
            aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "### 0x%04x 0x%04x %s\n", mem_addr, mem_value, mem_name);

            /* NOTE: restore address 0 later otherwise writing it now will cause an interrupt to immediately occur, which then will force the stack to have a valid return value present otherwise it will crash when re-enabled */
            imem[mem_addr] = mem_value;
            mem_addr++;
        }
    }

done:
    if (file) aapl_free(aapl, file, __func__);
    return imem;
}
#endif /* AAPL_MAIN */
#endif /* AAPL_ENABLE_FILE_IO */


void avago_spico_dmi_dump_file(Aapl_t *aapl, uint addr, const char *filename, uint imem_guess)
{
    int num_bytes, imem_addr;
    int x, count = 0;
    unsigned short *imem = 0;

#if AAPL_ENABLE_FILE_IO
#if AAPL_ENABLE_MAIN
    if (filename) imem = dmi_read_file(aapl, filename, addr);
#endif /* AAPL_ENABLE_MAIN */
#endif /* AAPL_ENABLE_FILE_IO */
    if (filename && !imem) return;

    if (1) /* auto detect beginning of DMI area */
    {
        int spico_run_state = 0;
        if (!imem) spico_run_state = avago_spico_halt(aapl, addr);
        for (imem_addr= imem_guess ? imem_guess + 10 : 0x7fff; imem_addr>= 0; imem_addr--)
        {
            int nop = 0x4e;
            if (aapl_get_process_id(aapl,addr) == AVAGO_TSMC_07) nop = 0x2e;
            if (imem && (imem[imem_addr] == nop && imem[imem_addr+8] == 0x312)) break;
            else if (!imem)
            {
                int mem = avago_serdes_mem_rd(aapl, addr, AVAGO_IMEM_PREHALTED, imem_addr);
                if (mem == nop && avago_serdes_mem_rd(aapl, addr, AVAGO_IMEM_PREHALTED, imem_addr+8) == 0x312) break;
            }
        }
        if (!imem) avago_spico_resume(aapl, addr, spico_run_state);
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "End of IMEM: 0x%4x\n", imem_addr);
    }
    imem_addr += 8;

    num_bytes = dmi_mem_rd(aapl, addr, imem_addr+1, imem);
    count =     dmi_mem_rd(aapl, addr, imem_addr+2, imem);
    count +=    dmi_mem_rd(aapl, addr, imem_addr+3, imem) * 256;

    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "DMI header (0x%04x-0x%04x): ", imem_addr, imem_addr+num_bytes-1);

    if (imem_addr < 100 || count > 10000)
    {
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n");
        aapl_fail(aapl, __func__, __LINE__, "Could not find DMI header.\n");
        return;
    }

    for (x=0; x<num_bytes; x++)
    {
        int data = dmi_mem_rd(aapl, addr, imem_addr++, imem);
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%04x ", data);
    }
    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, " ---> %d words per line. 0x%x (%d) lines total.\n", num_bytes, count, count);

    if (aapl->verbose || count)
    for (x = 0; 1; x++)
    {
        int data;
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "## Line %4d (0x%04x-0x%04x):    ", x+1, imem_addr, imem_addr+num_bytes-1);

        data = dmi_mem_rd(aapl, addr, imem_addr++, imem);
        if (data == 0x111 && aapl->verbose == 0) /* saved interrupt */
        {
            int interrupt, param, out;
            int extra1, extra2;
            interrupt = (dmi_mem_rd(aapl, addr, imem_addr, imem) << 8) | dmi_mem_rd(aapl, addr, imem_addr+1, imem);
            param = (dmi_mem_rd(aapl, addr, imem_addr+2, imem) << 8) | dmi_mem_rd(aapl, addr, imem_addr+3, imem);
            out = (dmi_mem_rd(aapl, addr, imem_addr+4, imem) << 8) | dmi_mem_rd(aapl, addr, imem_addr+5, imem);
            extra1 = (dmi_mem_rd(aapl, addr, imem_addr+6, imem)) ;
            extra2 = (dmi_mem_rd(aapl, addr, imem_addr+7, imem)) ;
            imem_addr += num_bytes - 1;
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, " Interrupt %04x %04x -> %04x %04x %04x\n", interrupt, param, out, extra1, extra2);
        }
        else
        {
            int y;
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%04x ", data);
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "(%4d)   ", (data & 0x200) ? data | (int) 0xfffffc00 : data);
            for (y=1; y<num_bytes; y++)
            {
                data = dmi_mem_rd(aapl, addr, imem_addr++, imem);
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%04x ", data);
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "(%4d)   ", (data & 0x200) ? data | (int) 0xfffffc00 : data);
            }
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n");
        }

        if (imem_addr+num_bytes >= 0x8000) break;
        if (count == x + 1) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "End of DMI data #########\n");
        if (!aapl->verbose && count == x + 1) break;
    }
    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Last addr: 0x%04x\n", imem_addr-1);
    if (imem) aapl_free(aapl, imem, __func__);
}

#endif /* AAPL_ENABLE_DIAG */

