/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */

/** Doxygen File Header */
/** @file */
/** @brief   Main for the aapl command. */

#include "aapl.h"

#if AAPL_ENABLE_MAIN

int main(int argc, char *argv[])
{
    return aapl_main_entry(argc, argv);
}

#endif /* AAPL_ENABLE_MAIN */
