/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */

/** Doxygen File Header */
/** @file */
/** @details A few simple sub-commands are implemented here. */
/**          Most have their own _main.c source file. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_MAIN

/* Utility function to return the program basename. */
static const char *_basename(const char *path)
{
    const char *ptr = strrchr(path,'/');
    if( ptr )
        path = ptr+1;
    ptr = strrchr(path,'\\');
    if( ptr )
        path = ptr+1;
    return path;
}

/* A place to put experimental code that is easy to find, compile, and use */
/* To run this code, call:  ./aapl cmd -exp */
static int experimental_code(Aapl_t *aapl, uint reset, Avago_addr_t *addr_list, int arg1, int arg2)
{
    int addr = avago_struct_to_addr(addr_list);
    printf("#### Running experimental code on %s\n", aapl_addr_to_str(addr));
    aapl_connect(aapl, 0, 0);
    aapl_get_ip_info(aapl, reset);
    (void) arg1;
    (void) arg2;

    /* code goes here */
    {
    }

    return 0;
}




/*============================================================================= */
/* CMD MAIN */

static int show_cmd_help()
{
    aapl_common_main_help(TRUE);
    printf(
"<cmd>              Parse <cmd> and return the results.\n"
"-aacs              Skip parsing and pass <cmd> directly to AACS server.\n"
"-hex               Convert result to hex before printing.\n"
"-reset             Perform hard SBus reset.\n"
"-soft-reset        Performs soft SBus reset on given address.\n"
"-cont              Performs command continuosly (until ctrl-c).\n"
);
    printf(
"-sbus-[rd|read] <reg> Read specified SBus register from the selected SBus address.\n"
"-sbus-wr[ite] <reg> <data>\n"
"                   Write <data> to <reg> on selected SBus address.\n"
"-sbus-rmw <reg> <data> <mask>\n"
"                   Write <mask> selected bits of <data> to <reg>.\n"
"-keep-open         Keeps socket open while console is running.\n"
);

#if AAPL_ALLOW_JTAG
    printf(
"-jtag-bit <length> <opcode> <bit> [<val>]   Reads or sets bit in JTAG chain.\n"
"-jtag-rd <length> <opcode>                  Non-destructively reads JTAG scan chain.\n"
"-jtag-rd-len <opcode>                       Non-destructively reads JTAG scan chain while determining it's length.\n"
"-jtag-wr <length> <opcode> <data>           Writes data as new jtag values.\n"
);
#endif /* AAPL_ALLOW_JTAG */

#if AAPL_ENABLE_DIAG
printf(
"-step <num>        Step processor at -addr <addr>, <num> times after sending\n"
"                   command.\n"
"-file <filename>   Execute commands from specified file.\n"
"-stop-on-fail      Stop executing \"-file\" file when first error encountered.\n"
"-single            When in file mode, wait for <CR> between each command\n"
);
#endif /* AAPL_ENABLE_DIAG */

printf(
"NOTE: -addr default is *:*:* and only applies when -sbus-read is present.\n"
"Pass command \"help\" for a list of commands supported by the AACS server.\n"
"\n"
);
    return 1;
}

int aapl_cmd_main(int argc, char *argv[], Aapl_t *aapl)
{
    /* Set default values: */
    int         aacs_cmd       = 0;
    char        *cmd           = 0;
    uint        hex            = 0;
#if AAPL_ENABLE_DIAG
    uint        sbus_addr;
#endif /* AAPL_ENABLE_DIAG */
    Avago_addr_t addr_struct;
    char       *sbus_data      = 0;
    uint        sbus_read_en   = 0;
    uint        sbus_write     = 0;
    uint        sbus_rmw       = 0;
    uint        cont           = 0;
    uint        keep_open      = 0;
    uint        reset          = 0;
    uint        soft_reset     = 0;
    uint        exp            = 0; /* run experimental_code() */
    int         exp_arg1       = 0; /* run experimental_code() */
    int         exp_arg2       = 0; /* run experimental_code() */
    uint        step           = 0;
    int chip = 0, ring = 0;
    int rc, index = 0;
    char * file = 0;
    char * remaining_cmds = 0;
#if AAPL_ENABLE_FILE_IO
    char * cmd_from_file = 0;
#endif /* AAPL_ENABLE_FILE_IO */
    BOOL stop_on_fail = 0;
    int pass = TRUE;
    int single = 0;
    int         jtag_bit      = 0;
    int         jtag_rd       = 0;
    int         jtag_rd_len   = 0;
    int         jtag_wr       = 0;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"aacs",      0, 0, 'A'}, /* pass <command> directly to aacs. */
        {"hex",       0, 0, 'h'}, /* print result in hex */
        {"sbus-read", 1, 0, 's'}, /* perform SBus read operation from address specified */
        {"sbus-write",0, 0, 'w'}, /* perform SBus write operation from address specified */
        {"sbus-rd",   1, 0, 's'}, /* perform SBus read operation from address specified */
        {"sbus-wr",   0, 0, 'w'}, /* perform SBus write operation from address specified */
        {"sbus-rmw",  0, 0, 'm'}, /* perform SBus rmw operation from address specified */
#if AAPL_ENABLE_DIAG
        {"step",      1, 0, 't'}, /* single step the processor n number of times after command is sent */
#endif /* AAPL_ENABLE_DIAG */
        {"cont",      0, 0, 'c'}, /* issue command continuously (until ctrl-c) */
        {"keep-open", 0, 0, 'k'}, /* keep socket connection open */
        {"file",      1, 0, 'f'}, /* execute commands from file */
        {"stop-on-fail",0, 0, 'x'}, /* stop executing commands from -file when first error encountered */
        {"exp",       0, 0, 'e'}, /* run experimental code */
        {"exp-arg1",  1, 0, 0x100 | 'e'}, /* run experimental code */
        {"exp-arg2",  1, 0, 0x200 | 'e'}, /* run experimental code */
        {"reset",     0, 0, 'R'}, /* reset */
        {"r",         0, 0, 'R'}, /* reset */
        {"soft-reset",0, 0, 'r'}, /* reset */
        {"single",    0, 0, 1},   /* when in file mode, wait for <CR> between each command */
#if AAPL_ALLOW_JTAG
        {"jtag-bit",  0, 0, 2},   /* get/set JTAG bits */
        {"jtag-rd",   0, 0, 3},   /* read JTAG chain */
        {"jtag-read", 0, 0, 3},   /* read JTAG chain */
        {"jtag-rd-len", 0, 0, 4},   /* read JTAG chain and length */
        {"jtag-read-len", 0, 0, 4},   /* read JTAG chain and length */
        {"jtag-write", 0, 0, 5},   /* write complete JTAG chain */
#endif /* AAPL_ALLOW_JTAG */
        {0,           0, 0, 0}
    };

    avago_addr_init_broadcast(&addr_struct);
    if (aapl_common_main_options(aapl, argc, argv, /*sbus_addr*/ &addr_struct) < 0)
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_cmd_help();
    }
#if AAPL_ENABLE_DIAG
    sbus_addr = avago_struct_to_addr(&addr_struct);
#endif /* AAPL_ENABLE_DIAG */

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        /* const char *name = options[index].name; */
        switch( rc )
        {
        case 'R': reset = 1; break;
        case 'r': soft_reset = 1; break;
        case 'A': aacs_cmd = 1; break;
        case 'h': hex = 1;      break;
        case 'c': cont = 1;     break;
        case 'k': keep_open = 1; break;
        case 'f': file = optarg; break;
        case 'e': exp = 1;      break;
        case 'x': stop_on_fail = 1; break;
        case (0x100 | 'e'): exp_arg1 = aapl_num_from_str(optarg,options[index].name,0); break;
        case (0x200 | 'e'): exp_arg2 = aapl_num_from_str(optarg,options[index].name,0); break;
#if AAPL_ENABLE_DIAG
        case 't': step = aapl_num_from_str(optarg,options[index].name,0); break;
#endif /* AAPL_ENABLE_DIAG */
        case 'w': sbus_write = 1; break;
        case 'm': sbus_rmw = 1; break;
        case   1: single = 1; break;
#if AAPL_ALLOW_JTAG
        case   2: jtag_bit = 1; break;
        case   3: jtag_rd = 1; break;
        case   4: jtag_rd_len = 1; break;
        case   5: jtag_wr     = 1; break;
#endif /* AAPL_ALLOW_JTAG */
        case 's':
            sbus_read_en = 1;
            sbus_data = optarg;
            break;

        case '?':
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }
    if (exp) return experimental_code(aapl, reset, &addr_struct, exp_arg1, exp_arg2);  /* run experimental code */

    if( sbus_write && (argc-optind) != 2 )
        aapl_main_error("The -sbus-write commands requires 2 parameters:\n"
                        "    -sbus-write <reg> <value>\n");

    if( sbus_rmw && (argc-optind) != 3 )
        aapl_main_error("The -sbus-rmw commands requires 3 parameters:\n"
                        "    -sbus-rmw <reg> <value> <mask>\n");

#if AAPL_ALLOW_JTAG
    if ((jtag_bit && ((argc - optind) != 3 && (argc - optind) != 4)) ||
       (jtag_rd_len && ((argc - optind) != 1)) ||
       (jtag_wr && ((argc - optind) != 3)) ||
       (jtag_rd && ((argc - optind) != 2)))
            aapl_main_error("Wrong number of arguments supplied\n");
#endif /* AAPL_ALLOW_JTAG */

    /* A command or one of the following options must be specified */
    if( optind == argc && !(sbus_read_en || sbus_write || sbus_rmw || file || soft_reset || reset || jtag_bit || jtag_rd || jtag_rd_len || step))
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_cmd_help();
    }

    /* Exactly one args is required: */
    if( optind+1 != argc && !(sbus_read_en || sbus_write || sbus_rmw || file || soft_reset || reset || jtag_bit || jtag_rd || jtag_wr || step))
        aapl_main_error("A single command or other option is required. Run with -h for a usage summary.\n");

    cmd = argv[optind];

    /* Prepare a lower-level (back end) connection to forward commands for handling: */
    if (aacs_cmd) aapl->capabilities = AACS_SERVER_NO_CAPABILITIES; /* send the command raw */
    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);

    if (!aacs_cmd)
    {
        aapl_get_ip_info(aapl, reset);
        if( aapl_get_return_code(aapl) < 0 )
            aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "aapl_get_ip_info returned a negative value.\n");
    }

#if AAPL_ENABLE_FILE_IO
    if (file) /* read commands from external file to execute */
    {
        cmd_from_file = aapl_read_file(aapl, file);
        if (!cmd_from_file) return -1;
        remaining_cmds = cmd_from_file;
    }
#endif /* AAPL_ENABLE_FILE_IO */

    if (soft_reset)
    {
        Avago_addr_t start, stop, next; BOOL st;
        for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, 0); st; st = aapl_broadcast_next(aapl, &next, &start, &stop, 0) )
            avago_sbus_reset(aapl, avago_struct_to_addr(&next), 0);
    }

#if AAPL_ALLOW_JTAG
    if( jtag_rd_len )
    {
        int opcode = aapl_num_from_str(argv[optind],"<opcode>",0);
        int length = 0;
        avago_jtag_rd_len(aapl, opcode, &length);
        printf("0x%04x[%d:0]: %s\n", opcode, length-1, aapl->data_char);
        return 0;
    }
    else if( jtag_wr )
    {
        uint length = aapl_num_from_str(argv[optind+0],"<length>",0);
        int opcode = aapl_num_from_str(argv[optind+1],"<opcode>",0);
        char *data = argv[optind+2];
        if( strlen(data) != length )
        {
            /* If not full length, prepend data with 0s. */
            char *buf = (char *)aapl_malloc(aapl, length+1, "jtag_wr");
            memset(buf,'0',length);
            strcpy(buf+length-strlen(data), data);
            data = buf;
        }
        avago_jtag(aapl, opcode, length, data);
        avago_jtag_rd(aapl, opcode, length);
        printf("0x%04x[%4d:0]: %s\n            --> %s\n", opcode, length-1, data, aapl->data_char);
        if( data != argv[optind+2] )
            aapl_free(aapl, data, "jtag_wr");
        return 0;
    }
    else if (jtag_bit || jtag_rd)
    {
        int bit;
        int length = aapl_num_from_str(argv[optind+0],"<length>",0);
        int opcode = aapl_num_from_str(argv[optind+1],"<opcode>",0);

        if (jtag_rd) /* do a read of the whole scan chain and return */
        {
            avago_jtag_rd(aapl, opcode, length);
            printf("0x%04x[%d:0]: %s\n", opcode, length-1, aapl->data_char);
            return 0;
        }
        bit = aapl_num_from_str(argv[optind+2],"<bit>",0);

        if (argc-optind == 4) /* are we setting? */
        {
            int value = aapl_num_from_str(argv[optind+3],"<value>",0) + 0x30;
            if (value > '1') value = '1';
            avago_jtag_set_bit(aapl, opcode, length, bit, value);
        }

        /* read bit specified */
        avago_jtag_rd(aapl, opcode, length);
        printf("0x%04x[%d]: %x\n", opcode, bit, aapl->data_char[length - 1 - bit] - 0x30);
        return 0;
    }
#endif /* AAPL_ALLOW_JTAG */

    if (cmd || file || sbus_write || sbus_rmw || sbus_read_en || step > 0)
    {
    int aapl_diag = 0;
    do
    {
        const char *result = 0;
#if AAPL_ENABLE_DIAG
        int spico_state = 0;
#endif /* AAPL_ENABLE_DIAG */
        if (file && remaining_cmds) /* get next command from read in file */
        {
            char *found = 0;
            if (single) getchar();
            cmd = remaining_cmds;

            found = strstr(remaining_cmds, "\n");
            if (found)
            {
                if (cmd != remaining_cmds) strncpy(cmd, remaining_cmds, found - remaining_cmds);
                cmd[found-remaining_cmds] = 0; /* string terminator */
                remaining_cmds = found + 1;
                if (strstr(cmd, "AAPL diag started. AAPL version:")) aapl_diag = 1; /* recognize aapl diag dump */
                if (!strcmp(cmd, "exit")) return 0;
                if (aapl_diag == 1) /* if we are parsing a diag dump ignore all lines until the SBus dump begins */
                {
                    if (strstr(cmd, "SBus dump for SBus address")) aapl_diag = 2; /* found the SBus dump, so start parsing on the following line */
                    continue;
                }
                if (aapl_diag == 2) /* all lines inside the SBus dump section */
                {
                    char *cmd2 = cmd;
                    uint sbus_addr, data_addr, data;
                    if (!aapl_str_to_addr(cmd, &cmd2, &sbus_addr))  /* end of SBus section of diag dump */
                    {
                        aapl_diag = 1;
                        continue;
                    }
                    cmd = cmd2;
                    data_addr = aapl_strtoul(cmd, &cmd2, 0);
                    cmd = cmd2 + 1; /* move past : */
                    data = aapl_strtoul(cmd, &cmd2, 0);
                    sprintf(cmd, "sbus %02x %02x 01 0x%08x", sbus_addr, data_addr, data);
                    /*printf("### %s ###\n", cmd); */
                }
            }
            else remaining_cmds = 0;
            if (!remaining_cmds) break;
        }

#if AAPL_ENABLE_DIAG
        if (step)
        {
            aapl_get_firmware_rev(aapl, sbus_addr);   /* needed to store rev and build into aapl (as SPICO will be turned off, and we can't get the info then) */
            aapl_get_firmware_build(aapl, sbus_addr);
            spico_state = avago_spico_halt(aapl, sbus_addr);
        }
#endif /* AAPL_ENABLE_DIAG */
        if( aacs_cmd ) /* send the command directly via AACS */
        {
            aapl_log_printf(aapl, AVAGO_DEBUG1, 0, 0, "Sending: %s\n", cmd);
            avago_aacs_send_command(aapl, cmd);
            aapl_str_rep(aapl->data_char, ';', 0xa); /* replace ";" with newline */
            result = aapl->data_char;
        }
        else /* use AAPL's aacs_server commands to parse the command */
        {
            if (sbus_write || sbus_rmw || sbus_read_en)
            {
                if (sbus_write) /* SBus writes will be sent to broadcast address if supplied */
                {
                    Avago_addr_t start, stop, next; BOOL st;
                    int reg  = aapl_num_from_str(argv[optind  ],"<reg>",0);
                    uint data = aapl_num_from_str(argv[optind+1],"<value>",0);
                    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, AAPL_BROADCAST_NO_ITER_SBUS); st;
                         st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_NO_ITER_SBUS) )
                    {
                        uint sbus_addr = avago_struct_to_addr(&next);
                        int ret  = avago_sbus_wr(aapl, sbus_addr, reg, data);
                        if (aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, AVAGO_UNKNOWN_IP)) continue; /* don't call lower level functions unless they are known types */
                        printf("avago_sbus_wr (aapl, %s, 0x%02x, 0x%04x) = 0x%04x\n", aapl_addr_to_str(sbus_addr), reg, data, ret);
                    }
                    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, 0); st;
                         st = aapl_broadcast_next(aapl, &next, &start, &stop, 0) )
                    {
                        uint sbus_addr = avago_struct_to_addr(&next);
                        if (aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, AVAGO_UNKNOWN_IP)) continue; /* don't call lower level functions unless they are known types */
                        printf("avago_sbus_rd (aapl, %s, 0x%02x) new_value = 0x%08x\n", aapl_addr_to_str(sbus_addr), reg, avago_sbus_rd(aapl, sbus_addr, reg));
                    }
                }
                else
                {
                    Avago_addr_t start, stop, next; BOOL st;
                    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, 0); st;
                         st = aapl_broadcast_next(aapl, &next, &start, &stop, 0) )
                    {
                        uint sbus_addr = avago_struct_to_addr(&next);
                        if (aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, AVAGO_UNKNOWN_IP)) continue; /* don't call lower level functions unless they are known types */
                        if (sbus_read_en) /* Perform broadcast safe SBus read */
                        {
                            int start = 0, stop = 0, reg;
                            if( !aapl_parse_range(sbus_data,&start,&stop) || (!sbus_read_en && start != stop) )
                                aapl_fail(aapl, 0, 0, "Invalid address or address range in parameter 2: %s\n",argv[optind+1]);
                            for( reg = start; reg <= stop; reg++ )
                            {
                                int ret = avago_sbus_rd(aapl, sbus_addr, reg);
                                aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%s 0x%02x (%3d) -> 0x%08x\n", aapl_addr_to_str(sbus_addr), reg, reg, ret);
                            }
                        }
                        else if( sbus_rmw )
                        {
                            int reg  = aapl_num_from_str(argv[optind  ],"<reg>",0);
                            uint data = aapl_num_from_str(argv[optind+1],"<value>",0);
                            uint mask = aapl_num_from_str(argv[optind+2],"<mask>",0);
                            int ret  = avago_sbus_rmw(aapl, sbus_addr, reg, data, mask);
                            printf("avago_sbus_rmw(aapl, %s, 0x%02x, 0x%04x, 0x%04x) = 0x%04x; new_value = 0x%04x\n",
                                    aapl_addr_to_str(sbus_addr), reg, data, mask, ret, avago_sbus_rd(aapl, sbus_addr, reg));
                        }
                    }
                }
            }
            else if( !step ) /* not SBus command (ie -sbus-rd -sbus-wr -sbus-rmw) */
            {
                BOOL local_pass = TRUE;
                BOOL is_sbus_read = FALSE;
                result = avago_aacs_process_cmd(aapl, cmd, &chip, &ring);
                if ((!aapl_strncasecmp(cmd, "sbus", 4)
                    && (!aapl_strncasecmp(cmd+5+5, " 02 ", 4) || !aapl_strncasecmp(cmd+6+5, " 02 ", 4) || !aapl_strncasecmp(cmd+7+5, " 02 ", 4))))
                    is_sbus_read = TRUE;
                else if (((cmd[0] >= 0x30 && cmd[0] <=0x39) || (cmd[0] >= 0x41 && cmd[0] <= 0x46) || (cmd[0] >= 0x61 && cmd[0] <= 0x66)) /* if the line starts with [0-9a-fA-F] then assume it is an SBus command */
                    && (!aapl_strncasecmp(cmd+5+0, " 02 ", 4) || !aapl_strncasecmp(cmd+6+0, " 02 ", 4) || !aapl_strncasecmp(cmd+7+0, " 02 ", 4)))
                    is_sbus_read = TRUE;
                if (is_sbus_read == TRUE)
                {
                    /*      01234567890123456 */
                    /* sbus 00 .. 02 <data> */
                    /* sbus 000 .. 02 <data> */
                    /* sbus 0000 .. 02 <data> */
                    char * expect_ptr = cmd;
                    char * expect_ptr2 = cmd;
                    int data_length;
                    uint expected = 0;
                    uint int_result;

                    if (!aapl_strncasecmp(cmd, "sbus", 4)) expect_ptr += 5; /* remove "sbus " if it exists */
                    if (expect_ptr) expect_ptr = strchr(expect_ptr, ' ')+1; /* remove sbus address */
                    if (expect_ptr) expect_ptr = strchr(expect_ptr, ' ')+1; /* remove data address */
                    if (expect_ptr) expect_ptr = strchr(expect_ptr, ' ')+1; /* remove command */
                    if (expect_ptr) expect_ptr2 = strchr(expect_ptr, ' ');  /* fine " " after end of date */
                    if (expect_ptr2) expect_ptr[expect_ptr2 - expect_ptr] = 0; /* remove anything after data (ie comments) */

                    data_length = strlen(expect_ptr);

                    if (data_length == 2 || data_length == 10)  expected = aapl_strtol(expect_ptr, NULL, 16); /* hex data */
                    else if (data_length == 8)                  expected = aapl_strtol(expect_ptr, NULL, 2);  /* ASCII encoded binary */

                    int_result = aapl_strtol(result, NULL, 2); /* get result from command */

                    if (data_length == 32) /* binary data (possibly with Xs -- check each bit */
                    {
                        int offset;
                        for (offset = 0; offset <= 31; offset++)
                        {
                            uint bit = 0;
                            if (expect_ptr[31-offset] == 'x' || expect_ptr[31-offset] == 'X') continue; /* if we don't care, move to next bit */
                            if (expect_ptr[31-offset] == '1') bit = 1;

                            if (((int_result >> offset) & 0x1) != bit) local_pass = FALSE;
                        }
                    }
                    else if (expected != int_result) local_pass = FALSE;
                }
                if (!local_pass) aapl_fail(aapl, __func__, __LINE__, "%-50s -> %32s (FAIL)\n", cmd, result);
                if (aapl->debug >= 1 || aapl->verbose >= 1)
                {
                    if (is_sbus_read) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%-50s -> %32s (%s)\n", cmd, result, local_pass == 1 ? "PASS" : "FAIL");
                    else aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%s -> %s\n", cmd, result);
                }
                if (local_pass == FALSE) pass = FALSE;
                if (local_pass == FALSE && stop_on_fail) remaining_cmds = 0;
            }
        }
#if AAPL_ENABLE_DIAG
        if (step)
        {
            avago_spico_diag(aapl, sbus_addr, step);
            avago_spico_resume(aapl, sbus_addr, spico_state);
        }
        else
#endif /* AAPL_ENABLE_DIAG */

        if (!(sbus_write || sbus_rmw || sbus_read_en)) /* sbus reads were printed above */
        {
            if (hex) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "0x%x\n",aapl_strtoul(result,0,2));
            else if (!file) printf("%s\n",result);
        }
        if (cont && !keep_open) aapl_close_connection(aapl);
    } while( cont || remaining_cmds);
    }

#if AAPL_ENABLE_FILE_IO
    if (file) aapl_free(aapl, cmd_from_file, __FILE__);
#endif /* AAPL_ENABLE_FILE_IO */
    if (file) printf("%s\n", pass == 1 ? "PASS" : "FAIL");

    avago_addr_delete(aapl, &addr_struct);
    return !rc;
}
/* END AACS MAIN */


#if AAPL_ENABLE_AACS_SERVER
/*============================================================================= */
/* AVAGO_AACS_SERVER_MAIN */

const uint aapl_default_listen_port = 9000;

static int show_aacs_server_help()
{
    aapl_common_main_help(FALSE);
    printf(
"-listen-port <port_number>\n"
"       TCP/IP port number where to listen for command client requests\n"
"       (front-end connection); default = %u.\n"
, aapl_default_listen_port);
    printf(
"-ats-server <ip_addr>    Remote AAPL ATS server to connect to.\n"
"-ats-server-port <port>  If ats-host supplied, the port to connect to.\n"
"                         Otherwise, start a local ATS server at this port.\n"
"                         Default is 9100.\n");
    printf(
"-dump\n"
"       Call aapl_print_struct() before exiting.\n"
"-reset                   Resets the device prior to obtaining device info.\n"
"\n");

    return 1;
}

/* Main program for a standalone aacs_server program, instead of a library call */
/* on a pre-existing process/thread.  Exits with 0 for success or 1 for error. */

int aapl_aacs_server_main(int argc, char *argv[], Aapl_t *aapl)
{
    /* Set default values: */
    uint        listen_port = aapl_default_listen_port;
    int         dump        = 0;
    BOOL        reset       = 0;
    char       *ats_server = NULL;   /* Remote AAPL ATS server */
    uint        ats_server_port = 0; /* If ats-host supplied, the port to connect to.\n" */
                                     /* Otherwise, start a local ATS server at this port.\n" */
    int rc, index = 0;
    BOOL        close_connection = TRUE;  /* Closes downstream connection when client closes socket */

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"listen-port",        1, NULL, 'P'},   /* <port_number> for front end connection. */
        {"dump",               0, NULL, 'D'},   /* to call aapl_print_struct() before exiting. */
        {"ats-server",         1, NULL, '1'},   /* If ats-host supplied, the port to connect to. */
        {"ats-server-port",    1, NULL, '2'},   /* start a local ATS server at this port. */
        {"r-port",             1, NULL, '2'},   /* start a local ATS server at this port. */
        {"keep-open",          0, NULL, '3'},   /* Keep the downstream connection open when client closes connection */
        {"reset",              0, NULL, '4'},   /* Reset the device first */
        {"r",                  0, NULL, '4'},   /* Reset the device first */
        {0,                    0, NULL, 0}
    };

    if (aapl_common_main_options(aapl, argc, argv, /*sbus_addr*/ 0) < 0)
        return show_aacs_server_help();

    setbuf(stdout,0);
    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch( rc )
        {
        case 'P': listen_port = aapl_num_from_str(optarg,name,10); break;
        case '2': ats_server_port = aapl_num_from_str(optarg,name,10); break;
        case 'D': dump = 1; break;
        case '1': ats_server = aapl_strdup(optarg); break;
        case '3': close_connection = FALSE; break;
        case '4': reset = TRUE; break;
        case '?':
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    /* No args are allowed beyond options: */

    if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    if (ats_server && !ats_server_port) ats_server_port = 9100; /* Default local ats_server port is 9100 */

    if ((!ats_server && !ats_server_port) || (ats_server && ats_server_port))
    {
        /* If we're a standard AACS server OR if we're are connected to a remote ATS server */
        /* verify that we can connect to the device now rather than wait until a client tries to connect. */
        aapl_connect(aapl,0,0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
        aapl_get_ip_info(aapl, reset);
    }
    if( aapl_get_return_code(aapl) < 0 )
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "aapl_get_ip_info returned a negative value.\n");
    if (close_connection) aapl_close_connection(aapl);

/* Run the AAPL server: */

    rc = avago_aacs_server_options(aapl, listen_port, ats_server, ats_server_port, close_connection);
    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "avago_aacs_server() returned %d.\n", rc);

    if (dump) aapl_print_struct(aapl, 2, 0xffff, (Avago_ip_type_t) 0);

    if (ats_server) AAPL_FREE(ats_server);
    return rc != 0;
}
#endif /* AAPL_ENABLE_AACS_SERVER */


/*============================================================================= */
/* BUILD INFO MAIN */
int aapl_build_info_main(int argc, char *argv[], Aapl_t *aapl)
{
    char *build_info = aapl_build_info(1);
    (void)argc;
    (void)argv;
    (void)aapl;
    printf("%s\n", build_info);
    AAPL_FREE(build_info);
    return 0;
}

int aapl_version_main(int argc, char *argv[], Aapl_t *aapl)
{
    char *build_info = aapl_build_info(2);
    (void)argc;
    (void)argv;
    (void)aapl;
    printf("%s\n", build_info);
    AAPL_FREE(build_info);
    return 0;
}

#if AAPL_ENABLE_FILE_IO
/** @brief   Reads a ".rom" file and displays the firmware rev and build. */
/** @details If present, also displays the engineering release count, compile date and time. */
/**          Works for newer SerDes and SBus Master .rom files. */
int aapl_rom_info_main(int argc, char *argv[], Aapl_t *aapl)
{
    int i;
    if( argc == 1 || strstr(argv[1], "-help") )
    {
        printf("Usage: %s [file.rom] ...\n", argv[0]);
        return 1;
    }
    for( i = 1; i < argc; i++ )
    {
        char *buf = aapl_read_file(aapl, argv[i]);
        if( buf )
        {
            int offset = 40;
            uint tmp;
            uint rev_id = 0, build_id = 0, eng_rel_cnt = 0, compile_day = 0, compile_hr = 0, compile_min = 0;
            uint month, day;
            /*printf("Open file %s\n", argv[i]); */

            sscanf(&buf[24+ 0], "%3x", &tmp);
            sscanf(&buf[24+ 4], "%3x", &rev_id); rev_id |= tmp << 8;
            sscanf(&buf[24+ 8], "%3x", &tmp);
            sscanf(&buf[24+12], "%3x", &build_id); build_id |= tmp << 8;

            if( buf[24] == '0' && buf[28] == '0' && buf[32] == '0' && buf[36] == '0' &&
               (buf[40] != '0' || buf[44] != '0' || buf[48] != '0' || buf[52] != '0') &&
                (rev_id & 0xff) <= 0x64 && (rev_id >> 12) < 4 && (rev_id >> 12) > 0 )
                offset = 24;

            sscanf(&buf[offset+ 0], "%3x", &tmp);
            sscanf(&buf[offset+ 4], "%3x", &rev_id); rev_id |= tmp << 8;
            sscanf(&buf[offset+ 8], "%3x", &tmp);
            sscanf(&buf[offset+12], "%3x", &build_id); build_id |= tmp << 8;
            sscanf(&buf[offset+16], "%3u", &compile_day);
            sscanf(&buf[offset+20], "%3u", &compile_hr);
            sscanf(&buf[offset+24], "%3u", &compile_min);
            sscanf(&buf[offset+28], "%3x", &eng_rel_cnt);
            /* Doesn't handle leap year: */
            if(      compile_day <=  31 ) { month =  1; day = compile_day; }
            else if( compile_day <=  59 ) { month =  2; day = compile_day -  31; }
            else if( compile_day <=  90 ) { month =  3; day = compile_day -  59; }

            else if( compile_day <= 120 ) { month =  4; day = compile_day -  90; }
            else if( compile_day <= 151 ) { month =  5; day = compile_day - 120; }
            else if( compile_day <= 181 ) { month =  6; day = compile_day - 151; }

            else if( compile_day <= 212 ) { month =  7; day = compile_day - 181; }
            else if( compile_day <= 243 ) { month =  8; day = compile_day - 212; }
            else if( compile_day <= 273 ) { month =  9; day = compile_day - 243; }

            else if( compile_day <= 304 ) { month = 10; day = compile_day - 273; }
            else if( compile_day <= 334 ) { month = 11; day = compile_day - 304; }
            else                          { month = 12; day = compile_day - 334; }

            if( eng_rel_cnt > 10 ) offset = 24;

            if( rev_id > 0x4fff || build_id > 0xffff || (rev_id & 0x0f00) > 0x0100 || (offset > 24 && (compile_hr >= 24 || compile_min >= 60 || compile_day > 366)) )
            {
                char *ptr;
                offset = 0;
                rev_id = 0;

                /* Find 28/16nm SBus Master firmware instructions: */
                for( ptr = buf; offset == 0 && 0 != (ptr = strstr(ptr, "3b7")); ptr++ )
                {
                    /*printf("ptr = %.40s\n", ptr); */
                    if( strncmp(ptr+8,"1a7",3) == 0 && strncmp(ptr+36,"3b7",3) == 0 && strncmp(ptr+44,"1a7",3) == 0 )
                    {
                        uint tmp;
                        sscanf(&ptr[4], "%3x", &tmp);
                        sscanf(&ptr[16], "%3x", &rev_id); rev_id |= tmp << 8;
                        sscanf(&ptr[40], "%3x", &tmp);
                        sscanf(&ptr[52], "%3x", &build_id); build_id |= tmp << 8;
                        offset = 24;
                        break;
                    }
                }

                /* Find 7 nm SBus Master firmware instructions: */
                for( ptr = buf; offset == 0 && 0 != (ptr = strstr(ptr, "f37")); ptr++ )
                {
                    if( strncmp(ptr+8,"327",3) == 0 && strncmp(ptr+36,"f37",3) == 0 && strncmp(ptr+44,"327",3) == 0 )
                    {
                        uint tmp;
                        sscanf(&ptr[4], "%3x", &tmp);
                        sscanf(&ptr[16], "%3x", &rev_id); rev_id |= tmp << 8;
                        sscanf(&ptr[40], "%3x", &tmp);
                        sscanf(&ptr[52], "%3x", &build_id); build_id |= tmp << 8;
                        offset = 24;
                        break;
                    }
                }

                /* Find 28/16nm SerDes firmware instructions: */
                for( ptr = buf+8; offset == 0 && 0 != (ptr = strstr(ptr, "1a7\n3a5\n")); ptr++ )
                {
                    uint tmp = 0, instr = 0;
                    uint id = 0;
                    /*printf("ptr = %.40s\n", ptr-8); */
                    sscanf(ptr-8, "%3x", &instr);
                    sscanf(ptr-4, "%3x", &tmp);
                    sscanf(ptr+8, "%3x", &id);
                    if( instr == 0x3a7 || instr == 0x3b7 )
                        ; /* tmp has correct value */
                    else if( (tmp & ~0x1f) == 0x0a0 )
                        tmp &= 0x1f;
                    else
                        continue;
                    id |= tmp << 8;
                    if( rev_id == 0 )
                    {
                        if( id < 0x1000 )
                            continue;
                        rev_id = id;
                        build_id = 0;
                    }
                    else
                    {
                        offset = 24;
                        build_id = id;
                        break;
                    }
                }
                if( offset == 0 && rev_id != 0 )
                    offset = 24;
            }

            if( offset == 24 )
                printf("0x%04X_%04X                                      %s\n",rev_id, build_id, argv[i]);
            else if( offset == 40 )
                printf("0x%04X_%04X_%03X built %02u/%02u at %02u:%02u (day = %3u) %s\n",rev_id, build_id, eng_rel_cnt, month, day, compile_hr, compile_min, compile_day, argv[i]);
            else
                printf("Could not find a version:                        %s\n", argv[i]);

            aapl_free(aapl, buf, __func__);
        }
    }
    return 0;
}
#endif /* AAPL_ENABLE_FILE_IO */

#if AAPL_ENABLE_CONSOLE
/*============================================================================= */
/* AAPL INTERACTIVE CONSOLE */
/* */
#ifndef _POSIX_SOURCE
#define _POSIX_SOURCE
#endif
#ifndef __USE_POSIX
#define __USE_POSIX
#endif
#include <setjmp.h>
#include <signal.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <curses.h>
jmp_buf ctrlc_buf;
static char * rl_gets (char * line_read, int repeat);
static void console(Aapl_t *aapl, char * external_cmd, int keep_open, Avago_addr_t *addr_struct, Avago_state_table_options_t *table_options, Avago_ip_type_t type);

void handle_signals(int signo)
{
    endwin();

    write_history("/tmp/aapl.txt");
    if (signo == SIGINT)
    {
        printf("\n");
        siglongjmp(ctrlc_buf, 1);
    }
}


static int show_console_help()
{
    aapl_common_main_help(TRUE);
    printf(
"-reset                  Resets the device prior to starting the console.\n"
"-keep-open              Keeps socket open while console is running.\n"
"-disable-clk            Disable clock output for dev info when in verbose mode.\n"
"-disable-dfe            Disable dfe output for dev info when in verbose mode.\n"
"-disable-tx             Disable tx output for dev info when in verbose mode.\n"
"-disable-rx             Disable rx output for dev info when in verbose mode.\n"
"-disable-info           Disable IP info for dev info when in verbose mode.\n"
);
    printf(
"-ip-type <type>         Filter output by IP type <type> (ie, serdes).\n"
"-cmd <cmd>              Execute given console command.\n"
);
    return 1;
}

int rl_callback(int x, int y)
{
    printf("###\n");
    return x+y;
}

int aapl_console_main(int argc, char *argv[], Aapl_t *aapl)
{
    int rc, index = 0;
    uint reset = 0;
    char *cmd = 0;
    Avago_addr_t addr_struct;
    Avago_state_table_options_t table_options;
    Avago_ip_type_t type = (Avago_ip_type_t) 0;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"reset",        0, 0, 'r'}, /* reset for get_ip_info */
        {"r",            0, 0, 'r'}, /* reset for get_ip_info */
        {"keep-open",    0, 0, 'k'}, /* keep socket connection open */
        {"disable-clk",  0, 0, 'c'}, /* disable clock output in verbose mode */
        {"disable-dfe",  0, 0, 'd'}, /* disable dfe output in verbose mode */
        {"disable-tx",   0, 0, 'T'}, /* disable tx output in verbose mode */
        {"disable-rx",   0, 0, 'R'}, /* disable rx output in verbose mode */
        {"disable-info", 0, 0, 'i'}, /* disable rx output in verbose mode */
        {"cmd",          1, 0, 'C'}, /* execute command given */
        {"ip-type",      1, 0, 't'}, /* filter by ip_type */
        {0,              0, 0, 0}
    };

    avago_addr_init_broadcast(&addr_struct);
    if (aapl_common_main_options(aapl, argc, argv, &addr_struct) < 0)
        return show_console_help();

    memset(&table_options, 0, sizeof(table_options));         /* set all bytes to zero */

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        /*const char *name = options[index].name; */
        switch( rc )
        {
        case 'r': reset = 1; break;
        case 'k': table_options.keep_open = 1; break;
        case 'c': table_options.disable_clk = 1; break;
        case 'd': table_options.disable_dfe = 1; break;
        case 'T': table_options.disable_tx = 1; break;
        case 'R': table_options.disable_rx = 1; break;
        case 'i': table_options.disable_info = 1; break;
        case 't': if (!aapl_str_to_ip_type(optarg, &type)) aapl_main_error("Invalid ip_type"); break;
        case 'C': cmd = (char *)aapl_realloc(aapl, cmd, strlen(optarg)+1000, __func__);
                  strncpy(cmd, optarg, strlen(optarg)+1);
                  break;
        case '?':
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    aapl_connect(aapl, 0, 0);
    aapl_get_ip_info(aapl, reset);
    aapl_get_return_code(aapl);     /* Clear any errors */
    if (!table_options.keep_open) aapl_close_connection(aapl);

    printf("Starting AAPL %s command line interface.\n", AAPL_VERSION);
    printf("Ctrl-c twice, or use the \"exit\" command to exit.\n");

    console(aapl, cmd, table_options.keep_open, &addr_struct, &table_options, type);

    avago_addr_delete(aapl, &addr_struct);
    return 0;
}


static void console(Aapl_t *aapl, char * external_cmd, int keep_open, Avago_addr_t *addr_struct, Avago_state_table_options_t *table_options, Avago_ip_type_t type)
{
    char *line_read = (char *)NULL;
    int chip_num = 0;
    int ring_num = 0;
    volatile int repeat = 1; /* needs to be volatile to prevent compiler warning about these values getting clobbered when a jmp occurs */
    volatile int error_displays = 1;

    signal(SIGINT, handle_signals);
    sigsetjmp( ctrlc_buf, 1 );

    aapl->enable_stream_logging = 1; /* here to clean these up in case of ctrl-c while in ncurses mode */
    aapl->enable_stream_err_logging = 1;

    using_history();
    clear_history();
    read_history("/tmp/aapl.txt");

    while (1)
    {
        int result;
        char *cmd;
        char *line;
        BOOL unrecognized = FALSE;

        /*rl_bind_key ('', rl_callback); */
        if (!external_cmd)
        {
            line = rl_gets(line_read, repeat);
            result = history_expand(line, &cmd);

            if (result == -1 || result == 2 || result == 1) printf ("%s\n", cmd);  /* print the command */
            if (result == -1 || result == 2) continue;  /* don't execute this command */
        }
        else {cmd = external_cmd;}

        if (!aapl_strncasecmp(cmd, "exit", 4) || !aapl_strncasecmp(cmd, "quit", 4) || !aapl_strcasecmp(cmd, "q") ) break;
        else if (cmd[0] == '_')
        {
            if (! aapl_strncasecmp(cmd+1, "clear", 5)) clear_history();
            else if (! aapl_strncasecmp(cmd+1, "system", 6))
                system(cmd+7);
            else if (! aapl_strncasecmp(cmd+1, "d ", 2))
            {
                aapl->debug = aapl_strtol(cmd+3, 0, 10);
                printf("aapl->debug set to: %d\n", aapl->debug);
            }
            else if (! aapl_strncasecmp(cmd+1, "v ", 2))
            {
                aapl->verbose = aapl_strtol(cmd+3, 0, 10);
                printf("aapl->verbose set to: %d\n", aapl->verbose);
            }
            else if (! aapl_strncasecmp(cmd+1, "a ", 2))
            {
                if (!aapl_addr_list_from_str(aapl, addr_struct, cmd+3)) printf("Invalid address range or value specified. Must be a comma deliminated list of one or more addresses. ie: 1-5, 13-0xf,:2:2f-:2:5a,9\n");
                printf("Address set to: %s\n", aapl_addr_to_str(avago_struct_to_addr(addr_struct)));
            }
            else if (! aapl_strncasecmp(cmd+1, "repeat", 6))
            {
                repeat = aapl_strtol(cmd+8, NULL, 10);
                printf ("Repeat set to %d.\n", repeat);
            }
            else if (! aapl_strncasecmp(cmd+1, "history", 7))
            {
              register HIST_ENTRY **the_list;
              the_list = history_list ();
              if (the_list)
              {
                register int i;
                for (i = 0; the_list[i]; i++)
                  printf ("%d: %s\n", i + history_base, the_list[i]->line);
              }
            }
            else if (! aapl_strncasecmp(cmd+1, "get_ip", 6))
            {
                uint reset = 0;
                if (cmd[8] == '1') reset = 1;
                aapl_get_ip_info(aapl, reset);
            }
            else if (! aapl_strncasecmp(cmd+1, "print_dev", 9)) avago_device_info_options(aapl, addr_struct, type, table_options);
            else if (! aapl_strncasecmp(cmd+1, "dev cont", 8) ||
                    (! aapl_strncasecmp(cmd+1, "sbus cont", 9)))
            {
                #include "timer.h"
                Aapl_microtimer_t timer, timer2;
                unsigned long time_val = 0;
                unsigned long total_time = 0;
                char *buf = 0;
                char *buf_end = 0;
                int size = 0;
                uint error_prev[AAPL_MAX_CHIPS][AAPL_MAX_RINGS][255];
                memset(error_prev, 0, sizeof(uint) * AAPL_MAX_CHIPS * AAPL_MAX_RINGS * 255);

                initscr();
                timeout(0); /* don't block on getch below */
                aapl->enable_stream_logging = 0; /* don't send anything to stdout */
                aapl->enable_stream_err_logging = 0;
                aapl_timer_reset(&timer);
                aapl_timer_start(&timer);
                aapl_timer_reset(&timer2);
                aapl_timer_start(&timer2);
                while (1)
                {
                    int char_pressed;
                    Avago_addr_t start, stop, next; BOOL st;

                    move(0,0);
                    clear();
                    printw("%s\n%s\n", aapl_log_get(aapl), buf);

                    aapl_log_clear(aapl);
                    aapl_get_ip_info(aapl, 0);
                    if (! aapl_strncasecmp(cmd+1, "sbus cont", 9))
                        avago_diag_sbus_dump(aapl, avago_struct_to_addr(addr_struct), 1);
                    else if (! aapl_strncasecmp(cmd+1, "dev cont", 8))
                    {
                        const char *sep = "---------------";
                        avago_device_info_options(aapl, addr_struct, type, table_options);

                        /* clear buffer */
                        if (buf) aapl_free(aapl, buf, __func__);
                        buf = 0;
                        buf_end = 0;
                        size = 0;

                        total_time = aapl_timer_get(&timer2);
                        aapl_buf_add(aapl, &buf, &buf_end, &size, "Total elapsed time: %.3f s (press 't' to reset time)\n", (float) total_time / 1e6);
                        aapl_buf_add(aapl, &buf, &buf_end, &size, "Error counts (press 'r' to reset error counters, or press 'x' to enable/disable this feature):\n\n");
                        if (error_displays)
                        {
                            aapl_buf_add(aapl, &buf, &buf_end, &size, "%6s   %6s %10s %10s %10s %9s %9s\n", "Addr", "Rate", "Errors", "Error diff", "Errors/sec", "Inst BER", "Total BER");
                            aapl_buf_add(aapl, &buf, &buf_end, &size, "%.6s   %.6s %.10s %.10s %.10s %.9s %.9s\n", sep, sep, sep, sep, sep, sep, sep);
                            for( st = aapl_broadcast_first(aapl, addr_struct, &start, &stop, &next, 0); st; st = aapl_broadcast_next(aapl, &next, &start, &stop, 0) )
                            {
                                float errors_per_second, inst_ber, total_ber;
                                Avago_serdes_pll_state_t pll_state;
                                uint errors, error_diff;
                                uint addr = avago_struct_to_addr(&next);
                                Avago_serdes_line_encoding_t pam_tx, pam_rx;

                                if (!aapl_check_ip_type(aapl, addr, __func__, __LINE__, FALSE, 2, AVAGO_M4, AVAGO_SERDES)) continue; /* don't call lower level functions unless they are known types */

                                errors = avago_serdes_get_errors(aapl, addr, AVAGO_LSB, 0);
                                error_diff = errors - error_prev[next.chip][next.ring][addr];

                                errors_per_second = error_diff / (time_val / 1e6);
                                if (errors_per_second >= 999999999) errors_per_second = 999999999;

                                avago_serdes_get_tx_pll_state(aapl, addr, &pll_state);     /* Get PLL state, which contains the estimated bitrate */
                                avago_serdes_get_tx_rx_line_encoding(aapl, addr, &pam_tx, &pam_rx);
                                pll_state.est_rate *= (int) (pam_rx) + 1;

                                inst_ber = error_diff / ((float) pll_state.est_rate  * time_val / 1e6);

                                if (!errors) total_ber = (errors+1) / ((float) pll_state.est_rate * (total_time / 1e6));
                                else         total_ber = errors / ((float) pll_state.est_rate * (total_time / 1e6));

                                aapl_buf_add(aapl, &buf, &buf_end, &size, "%6s @ %6.3f ", aapl_addr_to_str(addr), (float) pll_state.est_rate / 1000000000);
                                aapl_buf_add(aapl, &buf, &buf_end, &size, "%10u %10u %10.0f %.3e %.3e\n", errors, error_diff, errors_per_second, inst_ber, total_ber);
                                error_prev[next.chip][next.ring][addr] = errors;
                            }
                            time_val = aapl_timer_get(&timer);
                            aapl_timer_reset(&timer);
                            aapl_timer_start(&timer);
                        }
                    }
                    refresh();
                    char_pressed = getch();

                    if (char_pressed == 'R' || char_pressed == 'r') /* reset serdes error counters// reset serdes error counters */
                    {
                        for( st = aapl_broadcast_first(aapl, addr_struct, &start, &stop, &next, 0); st; st = aapl_broadcast_next(aapl, &next, &start, &stop, 0) )
                            avago_serdes_get_errors(aapl, avago_struct_to_addr(&next), AVAGO_LSB, 1);
                    }
                    else if (char_pressed == 'X' || char_pressed == 'x') error_displays ^= 1;
                    else if (char_pressed == 'T' || char_pressed == 't')  /* reset total time */
                    {
                        aapl_timer_reset(&timer2);
                        aapl_timer_start(&timer2);
                    }
                    else if (char_pressed > 0) break; /* break on any other character typed */

                    if (!keep_open) aapl_close_connection(aapl);
                }
                endwin();
                aapl->enable_stream_logging = 1;
                aapl->enable_stream_err_logging = 1;
            }
            else if (! aapl_strncasecmp(cmd+1, "dev", 3))
            {
                uint reset = 0;
                if (cmd[5] == '1') reset = 1;
                aapl_get_ip_info(aapl, reset);
                avago_device_info_options(aapl, addr_struct, type, table_options);
            }
            else
            {
                printf("ERROR: Unrecognized AAPL console command.\n");
                unrecognized = TRUE;
            }
        }
        else
        {
            int loop;
            if (!aapl_strncasecmp(cmd, "help", 4) || (!aapl_strncasecmp(cmd, "h", 1)))
            {
                printf("AAPL console commands:\n");
                printf("    q|quit|exit         Exit.\n");
                printf("    _d <val>            Sets aapl->debug to val\n");
                printf("    _v <val>            Sets aapl->verbose to val\n");
                printf("    _history            Prints command history.\n");
                printf("    _clear              Clears command history.\n");
                printf("    _repeat n           Repeat all future commands n times.\n");
                printf("    _get_ip [1]         Calls aapl_get_ip_info() with optional reset.\n");
                printf("    _print_dev          Calls avago_device_info() only.\n");
                printf("    _dev [1]            Calls aapl_get_ip_info() with optional reset followed by avago_device_info.\n");
                printf("    _dev cont           Calls aapl_get_ip_info() followed by avago_device_info until any character is pressed.\n");
                printf("    _sbus cont          Calls avago_diag_sbus_dump until any character is pressed.\n");
                printf("    _system <str>       Calls system(<str>)\n");
                printf("AACS Server Commands:\n");
            }
            for (loop=0; loop<repeat; loop++)
            {
                char next_cmd[AACS_SERVER_BUFFERS];
                char next_result[AACS_SERVER_BUFFERS];
                const char *index;
                const char *index2;
                const char *remaining_cmd;
                const char *remaining_result;
                int single_cmd = !(strchr(cmd, ';'));
                int num = 1;
                int hex = 0;
                int hex_value = 0;

                remaining_result = avago_aacs_process_cmd(aapl, cmd, &chip_num, &ring_num);
                remaining_cmd = cmd;

                do
                {
                    index = strchr(remaining_cmd, ';');
                    if (index) strncpy(next_cmd, remaining_cmd, index - remaining_cmd); /* isolate the first command */
                    else       strncpy(next_cmd, remaining_cmd, strlen(remaining_cmd)+1); /* isolate the first command */
                    if (index) next_cmd[index-remaining_cmd] = 0; /* terminate string */
                    remaining_cmd = index + 1; /* move past ";" */

                    index2 = strchr(remaining_result, ';');
                    if (index2) strncpy(next_result, remaining_result, index2 - remaining_result); /* isolate the first command */
                    else        strncpy(next_result, remaining_result, strlen(remaining_result)+1); /* isolate the first command */
                    if (index2) next_result[index2-remaining_result] = 0; /* terminate string */
                    remaining_result = index2 + 1; /* move past ";" */

                    if (!strncmp(next_cmd, "sbus", 4))
                    {
                        const char * cp = next_result;
                        hex_value = aapl_strtol(cp, 0, 2);
                        hex = 1;
                        aapl_hex_2_bin(next_result, hex_value, 1, strlen(next_result));
                    }
                    else hex = 0;

                    if (repeat > 1) printf(" loop %4d:  ", loop+1);
                    if (single_cmd) printf("    ");
                    else            printf(" cmd %3d: %s ", num, next_cmd);

                    if (hex) printf("-> 0x%08x   (%s)\n", hex_value, next_result);
                    else printf("-> %s\n", next_result);
                    num ++;

                } while (index);
            }
        }
        if (!unrecognized && cmd && *cmd) add_history (cmd);
        if (!keep_open) aapl_close_connection(aapl);
        signal(SIGINT, handle_signals);
        if (external_cmd) break;
    }
    write_history("/tmp/aapl.txt");
    if (line_read) free(line_read);
    if (external_cmd) free(external_cmd);
}

/* Read a string, and return a pointer to it.  Returns NULL on EOF. */
static char * rl_gets (char * line_read, int repeat)
{
    char buf[64];
    /* Free memory if already read */
    if (line_read)
    {
        free (line_read);
        line_read = (char *)NULL;
    }
    if (repeat > 1)
        snprintf(buf, 63, "%d (repeat %d) > ", history_length, repeat);
    else
        snprintf(buf, 63, "%d > ", history_length);
    line_read = readline (buf);
    return (line_read);
}
#endif /* AAPL_ENABLE_CONSOLE */


/*============================================================================= */
/* DEVICE INFO MAIN */
static int show_device_info_help()
{
    aapl_common_main_help(TRUE);
    printf(
"-ip-type <type>         Filter output by IP type <type> (ie, serdes).\n"
"-reset                  Resets the device prior to obtaining device info.\n"
"-keep-open              Keeps socket open while console is running.\n"
);
    printf(
"-disable-clk            Disable clock output when in verbose mode.\n"
"-disable-dfe            Disable dfe output when in verbose mode.\n"
"-disable-tx             Disable tx output when in verbose mode.\n"
"-disable-rx             Disable rx output when in verbose mode.\n"
);
    printf(
"-refclk <Hz>            Specify reference clock frequency to use in -v 1 output.\n"
"                        If omitted, an estimated value will be used.\n"
#if AAPL_ENABLE_DIAG && AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_PS1
"-ps1                    Display PS1 power status.\n"
#endif
);

    return 1;
}


int aapl_device_info_main(int argc, char *argv[], Aapl_t *aapl)
{
    int rc, index = 0;
    Avago_ip_type_t type = (Avago_ip_type_t) 0;
    uint        reset       = 0;
    Avago_addr_t addr_struct;
    uint ps1 = 0;
    char *temp = getenv("SERDES_REFCLK");

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"ip-type",      1, 0, 't'}, /* filter by ip_type */
        {"reset",        0, 0, 'r'}, /* reset for get_ip_info */
        {"r",            0, 0, 'r'}, /* reset for get_ip_info */
        {"keep-open",    0, 0, 'k'}, /* keep socket connection open */
        {"disable-clk",  0, 0, 'c'}, /* disable clock output in verbose mode */
        {"disable-dfe",  0, 0, 'd'}, /* disable dfe output in verbose mode */
        {"disable-tx",   0, 0, 'T'}, /* disable tx output in verbose mode */
        {"disable-rx",   0, 0, 'R'}, /* disable rx output in verbose mode */
        {"disable-info", 0, 0, 'i'}, /* disable info in verbose mode */
        {"disable-data", 0, 0, 'D'}, /* disable 80 bit RX data */
        {"refclk",       1, 0, 'z'}, /* Set refclk frequency in Hz. */
#if AAPL_ENABLE_DIAG && AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_PS1
        {"ps1",          0, 0, 'p'}, /* show PS1 status */
#endif
        {0,              0, 0, 0}
    };
    Avago_state_table_options_t table_options;
    memset(&table_options, 0, sizeof(table_options));         /* set all bytes to zero */
    table_options.refclk_hz = temp && *temp ? aapl_nume_from_str(temp, "env") : 0; /* If no env var, default to estimate rate */

    avago_addr_init_broadcast(&addr_struct);
    if (aapl_common_main_options(aapl, argc, argv, &addr_struct) < 0)
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_device_info_help();
    }

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch( rc )
        {
        case 't': if (!aapl_str_to_ip_type(optarg, &type)) aapl_main_error("Invalid ip_type"); break;
        case 'r': reset = 1; break;
        case 'k': table_options.keep_open = 1; break;
        case 'c': table_options.disable_clk = 1; break;
        case 'd': table_options.disable_dfe = 1; break;
        case 'T': table_options.disable_tx = 1; break;
        case 'i': table_options.disable_info = 1; break;
        case 'R': table_options.disable_rx = 1; break;
        case 'D': table_options.disable_data = 1; break;
        case 'z': table_options.refclk_hz  = aapl_nume_from_str(optarg, name); break;
        case 'p': ps1 = 1; break;
        case '?':
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
    aapl_get_ip_info(aapl, reset);

#if AAPL_ENABLE_DIAG && AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_PS1
    if (ps1) avago_ps1_display_power_status(aapl);
#else
    (void) ps1; /* to prevent compiler warnings */
#endif
    avago_device_info_options(aapl, &addr_struct, type, &table_options);
    avago_addr_delete(aapl, &addr_struct);
    return 0;
}


/*============================================================================= */
/* INIT_MAIN */

static int show_init_help()
{
    aapl_common_main_help(TRUE);
    printf(
"-upload                  Upload firmware to SerDes. Use -rev and -build\n"
"                           to specify specific versions.\n"
"-rev <rev>               Firmware revision to upload. Default = %s.\n"
"-build <build>           Firmware build number to upload.\n"
"                           Default <build> varies by SerDes type.\n"
"                         <rev> and <build> are case sensitive.\n"
"-firmware-file <path>    Path of firmware file to upload.\n"
, aapl_default_firmware_rev);

    printf(
"-divider    <int>        Set the PLL divider; default = %d.\n"
"-tx-divider <int>        Set the Tx PLL divider.\n"
"-rx-divider <int>        Set the Rx PLL divider.\n"
, aapl_default_divider);

    printf(
"-encoding      <2|4>     Set the Tx and Rx serial transmission encoding.\n"
"-tx-encoding   <2|4>     Set the TX serial transmission encoding.\n"
"-rx-encoding   <2|4>     Set the RX serial transmission encoding.\n"
);

    printf(
"-width-mode    <10|16|20|32|40|64|80> Set the Tx and Rx width modes.\n"
"-tx-width-mode <10|16|20|32|40|64|80> Set the Tx width mode.\n"
"-rx-width-mode <10|16|20|32|40|64|80> Set the Rx width mode.\n"
"-disable-signal-ok       Disable signal OK\n"
"-tx-output-en <0|1>      Disable/enable tx-output (default=enabled).\n"
);

    printf(
"-burst-mode              Configure SerDes in burst mode. Burst mode is only valid for PON SerDes.\n"
"-rate-sel   <number>     Tx/Rx rate selector.\n"
"                         0 = Full rate, 1 = Half rate, 2 = Quarter rate, 3 = Eighth rate.\n"
);
    printf(
"-reset                   Resets the device prior to running the init.\n"
"-elb                     Configure SerDes for external input.\n"
"-tx-core                 Configure Tx input from the CORE rather than PRBS.\n"
"-tune                    Run DFE tuning after switching to ELB (requires -elb).\n"
"-addr-b                  Run serdes_link_init() on this address and -addr <val>.\n"
);
    printf(
"-deep-post               Enable deep-post mode for CM4 NRZ.\n"
);


# if AAPL_ENABLE_EYE_MEASUREMENT
printf(
"-eye                     Measure eye in ELB mode (requires -elb).\n"
"-eye-type <type>         Full (default), size, height, width, vdual or dvos.\n"
"-y-step-size <int>       Set DAC scan resolution; default = 4.\n"
);

printf(
"-y-points <int>          Points to gather over the Y range; default = 33.\n"
"                          (y-step-size * y-points) defines the Y scan range.\n"
"                          y-points is adjusted to keep the product <= 256.\n"
"-x-resolution <int>      Points to gather per UI; default = 32; min = 8.\n"
"                          Value is rounded down to the nearest power of 2.\n"
);
# endif

    printf(
"-invert     <0|1>        Disable/enable invert in the Tx and Rx datapaths.\n"
"-rx-invert  <0|1>        Disable/enable invert in the Rx datapath.\n"
"-tx-invert  <0|1>        Disable/enable invert in the Tx datapath.\n"
"-gray       <0|1>        Disable/enable Gray coding/decoding in Tx and Rx datapaths.\n"
"-rx-gray    <0|1>        Disable/enable Gray decoding in Rx datapath.\n"
"-tx-gray    <0|1>        Disable/enable Gray encoding in Tx datapath.\n"
);
      printf(
"-precode    <0|1>        Disable/enable precoding/predecoding in Tx and Rx datapaths.\n"
"-tx-precode <0|1>        Disable/enable precoding in Tx datapath.\n"
"-rx-precode <0|1>        Disable/enable predecoding in Rx datapath.\n"
"-swizzle    <0|1>        Disable/enable swizzle encoding in Tx and Rx datapaths.\n"
"-tx-swizzle <0|1>        Disable/enable swizzle encoding in Tx datapath.\n"
"-rx-swizzle <0|1>        Disable/enable swizzle encoding in Rx datapath.\n"
);

    printf(
"-base-init               Perform base initialization of SerDes (Tx and Rx both).\n"
"-tx-init                 Initialize SerDes Tx only.\n"
"-rx-init                 Initialize SerDes Rx only.\n"
"-loopback-test           Validate loopback configuration.\n"
);

    printf(
"\n"
"NOTE: -addr default is *:*:*.\n");

    return 1;
}


#if AAPL_ENABLE_DIAG
static void run_health_check(Aapl_t *aapl, uint addr, BOOL elb, BOOL signal_ok_en, BOOL tx_invert, int rx_invert)
{
    Avago_serdes_health_check_config_t *health;
    health = avago_serdes_health_check_config_construct(aapl);
    health->verbose = 1;
    health->crc = 1;
    health->spico_running = 1;
    health->ready = 1;
    health->tx_invert_check = 1;
    if ( rx_invert == 2)
        health->rx_invert_check = 0;
    else
        health->rx_invert_check = 1;
    health->tx_invert = tx_invert;
    health->rx_invert = rx_invert;
    health->loopback_check = 1;
    health->loopback = !elb;
    health->elec_idle_check = elb;
    health->signal_ok_check = signal_ok_en && elb;
    /*health->errors_check = 1; */
    avago_serdes_health_check(aapl, addr, health);
    avago_serdes_health_check_config_destruct(aapl, health);
}
#endif

static void run_elb_checks(Aapl_t *aapl, uint addr, BOOL tune)
{
    uint errors;

    /* Now let's switch to ELB, run DFE tuning and measure the eye height */
    avago_serdes_set_rx_input_loopback(aapl, addr, FALSE);

    if( tune ) /* Start DFE tuning, then wait for it to complete */
    {
        Avago_serdes_dfe_tune_t dfe;
        avago_serdes_tune_init(aapl, &dfe);
        avago_serdes_tune(aapl, addr, &dfe);
        avago_serdes_dfe_wait(aapl, addr);
    }

    avago_serdes_set_rx_cmp_mode(aapl, addr, AVAGO_SERDES_RX_CMP_MODE_MAIN_PATGEN);

             avago_serdes_get_errors(aapl, addr, AVAGO_LSB, 1);    /* To clear */
    errors = avago_serdes_get_errors(aapl, addr, AVAGO_LSB, 1);    /* To read */
    printf(" ELB errors: %u.", errors);
}

int aapl_serdes_init_main(int argc, char *argv[], Aapl_t *aapl)
{
    /* Set default values: */
#if AAPL_ENABLE_FILE_IO
    char        firmware_file[512] = "";
    const char *firmware_file_ptr = 0;
    const char *fw_build          = 0;
    uint        addr_b_upload     = TRUE;
    int         upload            = 0;
#endif /* AAPL_ENABLE_FILE_IO */
    int         deep_post_en      = 0;
    int         tx_core           = 0;
    int         elb               = 0;
    uint        chip_reset        = 0;
    uint        sbus_reset        = 1;
    uint        sbus_addr;
    uint        addr_b            = 0;
    Avago_addr_t addr_b_struct;
    int rc, index = 0;
    uint        tune              = 0;
    int         encoding          = 0;
    int         tx_encoding       = 0;
    int         rx_encoding       = 0;
#if AAPL_ENABLE_DIAG
    BOOL        link_train        = FALSE;
#endif
    int         tx_data_width     = 0;
    int         rx_data_width     = 0;
    int         tx_divider        = aapl_default_divider;
    int         rx_divider        = aapl_default_divider;
    int         rate_sel          = 1;
    BOOL        burst_mode        = 0;
    BOOL        signal_ok_en      = TRUE;
    BOOL        base_init         = FALSE;
    BOOL        tx_init           = FALSE;
    BOOL        rx_init           = FALSE;
    BOOL        loopback_test     = FALSE;
    BOOL        tx_output_enable  = TRUE;
# if AAPL_ENABLE_EYE_MEASUREMENT
    uint        eye               = 0;
    Avago_serdes_eye_type_t eye_type = AVAGO_EYE_FULL;
    uint y_points                 = 32;
    uint y_step_size              = 4;
    uint x_resolution             = 32;
# endif
    Avago_addr_t addr_list;

    Avago_serdes_datapath_t rx_datapath, tx_datapath;
    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"upload",       0, 0, 'u'}, /* Load specific firmware revision */
        {"rev",          1, 0, 'r'}, /* Load specific firmware revision */
        {"build",        1, 0, 'b'}, /* Load specific firmware build */
        {"firmware-file",1, 0, 'R'}, /* Load full firmware file path */
        {"reset",        0, 0, 'x'}, /* JTAG reset and hard SBus reset */
        {"r",            0, 0, 'x'}, /* JTAG reset and hard SBus reset */
        {"addr-b",       1, 0, 'B'}, /* Second address for SerDes link init function (first address is -addr <val>) */

        {"encoding",     1, 0,  2 }, /* Encoding mode */
        {"tx-encoding",  1, 0,213 }, /* Encoding mode for Tx */
        {"rx-encoding",  1, 0,214 }, /* Encoding mode for Rx */
        {"width-mode",   1, 0,  3 }, /* Set Tx and Rx width modes. */
        {"tx-width-mode",1, 0,215 }, /* Set TX width modes. */
        {"rx-width-mode",1, 0,216 }, /* Set RX width modes. */
        {"divider",      1, 0, 'v'}, /* Set divider */
        {"tx-divider",   1, 0,217 }, /* Set Tx divider */
        {"rx-divider",   1, 0,218 }, /* Set Rx divider */
        {"rate-sel",     1, 0, 'd'}, /* Select Rx rate */
        {"tx-core",      0, 0, 'c'}, /* Configure Tx core data input */
        {"elb",          0, 0, 'e'}, /* Enable external loopback */
        {"burst-mode",   0, 0, 'p'}, /* Enable burst mode */
        {"tune",         0, 0, 't'}, /* Tune DFE after switching to ELB */
        {"disable-signal-ok",0, 0, 'O'}, /* Disable signal OK */
# if AAPL_ENABLE_EYE_MEASUREMENT
        {"eye",          0, 0, 'E'}, /* Measure eye after switching to ELB */
        {"eye-type",     1, 0, 'T'}, /* ec_eye_type. */
        {"y-points",     1, 0, 'Y'},  /* ec_y_points. */
        {"y-step-size",  1, 0, 'z'},  /* ec_y_step_size. */
        {"x-resolution", 1, 0, 'X'},  /* ec_x_resolution. */
# endif
        {"invert",       1, 0, 201}, /* Set the value of Tx and Rx inversion */
        {"tx-invert",    1, 0, 202}, /* Set the value of Tx inversion */
        {"rx-invert",    1, 0, 203}, /* Set the value of Rx inversion */
        {"gray",         1, 0, 204}, /* Set the value of TX and RX Gray encoding */
        {"tx-gray",      1, 0, 205}, /* Set the value of Tx Gray encoding */
        {"rx-gray",      1, 0, 206}, /* Set the value of Rx Gray encoding */
        {"precode",      1, 0, 207}, /* Set the value of Tx and Tx Precode */
        {"tx-precode",   1, 0, 208}, /* Set the value of Tx Precode encoding */
        {"rx-precode",   1, 0, 209}, /* Set the value of RX Precode */
        {"swizzle",      1, 0, 210}, /* Set the value of Tx and Rx swizzle coding */
        {"tx-swizzle",   1, 0, 211}, /* Set the value of Tx swizzle coding */
        {"rx-swizzle",   1, 0, 212}, /* Set the value of Rx swizzle coding */
        {"base-init",    0, 0, 219}, /* Perform base initialization a SerDes (both Tx and Rx) */
        {"tx-init",      0, 0, 220}, /* Initialize SerDes Tx only */
        {"rx-init",      0, 0, 221}, /* Initialize SerDes Rx only */
        {"loopback-test",0, 0, 222}, /* Test loopback configuration */
        {"tx-output-enable",1, 0, 250}, /* Set TX enable state. */
        {"no-sreset",       0, 0, 261}, /* No SBus reset during Serdes-init */
        {0,                 0, 0,   0}
    };
    avago_addr_to_struct(aapl_default_device_addr, &addr_list);
    memset(&tx_datapath, 0, sizeof(tx_datapath));
    memset(&rx_datapath, 0, sizeof(rx_datapath));

    avago_addr_init(&addr_b_struct);
    if (aapl_common_main_options(aapl, argc, argv, &addr_list) < 0)
    {
        avago_addr_delete(aapl, &addr_list);
        return show_init_help();
    }
    sbus_addr = avago_struct_to_addr(&addr_list);

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch( rc )
        {
        case  2 : encoding = aapl_num_from_str(optarg,name,10);
                  if( encoding != 2 && encoding != 4 )
                  {
                      fprintf(stderr,"ERROR: encoding value must be 2 or 4.\n");
                      return 2;
                  }
                  tx_encoding = rx_encoding = encoding;
                  break;
        case 213: tx_encoding = aapl_num_from_str(optarg,name,10);
                  if( tx_encoding != 2 && tx_encoding != 4 )
                  {
                      fprintf(stderr,"ERROR: tx_encoding value must be 2 or 4.\n");
                      return 2;
                  }
                  break;
        case 214: rx_encoding = aapl_num_from_str(optarg,name,10);
                  if( rx_encoding != 2 && rx_encoding != 4 )
                  {
                      fprintf(stderr,"ERROR: rx_encoding value must be 2 or 4.\n");
                      return 2;
                  }
                  break;
        case  3 : tx_data_width  = rx_data_width = aapl_num_from_str(optarg,name,10); break;
        case 215: tx_data_width  = aapl_num_from_str(optarg,name,10); break;
        case 216: rx_data_width  = aapl_num_from_str(optarg,name,10); break;
        case 'v': tx_divider     = rx_divider = aapl_default_divider = aapl_num_from_str(optarg,name,0); break;
        case 217: tx_divider     = aapl_num_from_str(optarg,name,0); break;
        case 218: rx_divider     = aapl_num_from_str(optarg,name,0); break;
        case 234: deep_post_en   = 1; break;
        case 'd': rate_sel       = aapl_num_from_str(optarg,name,0); break;
#if AAPL_ENABLE_FILE_IO
        case 'u': upload         = 1; break;
        case 'b': fw_build       = optarg; upload = 1; break;
        case 'r': aapl_default_firmware_rev   = optarg; upload = 1; break;
        case 'R': firmware_file_ptr = optarg; upload = 1; break;
#endif /* AAPL_ENABLE_FILE_IO */
        case 'e': elb            = 1; break;
        case 'p': burst_mode     = 1; break;
        case 't': tune           = 1; break;
        case 'x': chip_reset     = 1; break;
        case 261: sbus_reset     = 0; break;
        case 'c': tx_core        = 1; break;
        case 'B': if (!aapl_addr_list_from_str(aapl, &addr_b_struct, optarg))
                    aapl_main_error("Invalid address range or value specified. Must be a comma deliminated list of one or more addresses. ie: 1-5, 13-0xf,:2:2f-:2:5a,9\n");
                    addr_b = avago_struct_to_addr(&addr_b_struct);
                    break;
        case 'O': signal_ok_en = FALSE; break;
# if AAPL_ENABLE_EYE_MEASUREMENT
        case 'E': eye          = 1; break;
        case 'T': if( !aapl_str_to_eye_type(optarg, &eye_type) )
                      aapl_main_error("-%s option requires a valid eye type; got: \"%s\".", name, optarg);
                  break;
        case 'Y': y_points     = aapl_num_from_str( optarg, name, 10); break;
        case 'z': y_step_size  = aapl_num_from_str( optarg, name, 10); break;
        case 'X': x_resolution = aapl_num_from_str( optarg, name, 10); break;
# endif

        case 201: tx_datapath.polarity_invert= rx_datapath.polarity_invert= aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x01; rx_datapath.mask |= 0x01; break;
        case 204: tx_datapath.gray_enable    = rx_datapath.gray_enable    = aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x02; rx_datapath.mask |= 0x02; break;
        case 207: tx_datapath.precode_enable = rx_datapath.precode_enable = aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x04; rx_datapath.mask |= 0x04; break;
        case 210: tx_datapath.swizzle_enable = rx_datapath.swizzle_enable = aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x08; rx_datapath.mask |= 0x08; break;
        case 202: tx_datapath.polarity_invert= aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x01; break;
        case 205: tx_datapath.gray_enable    = aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x02; break;
        case 208: tx_datapath.precode_enable = aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x04; break;
        case 211: tx_datapath.swizzle_enable = aapl_bool_from_str(optarg,name); tx_datapath.mask |= 0x08; break;
        case 203: rx_datapath.polarity_invert= aapl_bool_from_str(optarg,name); rx_datapath.mask |= 0x01; break;
        case 206: rx_datapath.gray_enable    = aapl_bool_from_str(optarg,name); rx_datapath.mask |= 0x02; break;
        case 209: rx_datapath.precode_enable = aapl_bool_from_str(optarg,name); rx_datapath.mask |= 0x04; break;
        case 212: rx_datapath.swizzle_enable = aapl_bool_from_str(optarg,name); rx_datapath.mask |= 0x08; break;
        case 219: base_init       = TRUE; break;
        case 220: tx_init         = TRUE; break;
        case 221: rx_init         = TRUE; break;
        case 222: loopback_test   = TRUE; break;
        case 250: tx_output_enable = aapl_bool_from_str(optarg,name); break;
        case '?':
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    /* No args are allowed beyond options: */
    if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
    aapl_get_ip_info(aapl, chip_reset);
    if( aapl_get_return_code(aapl) < 0 )
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "aapl_get_ip_info returned a negative value.\n");
    aapl_get_return_code(aapl);     /* Clear any errors */

#if AAPL_ENABLE_FILE_IO
    if (firmware_file_ptr) upload = 1; /* user specified firmware file, so upload implied */
#endif /* AAPL_ENABLE_FILE_IO */

    if (!aapl_check_process(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_28, AVAGO_TSMC_16, AVAGO_TSMC_07)) return -1;

    if( avago_struct_to_addr(&addr_list) == aapl_default_device_addr ) /* in case no address is provided by user */
    {
        /* Construct an address list for all SerDes: */
        aapl_addr_list_from_str(aapl, &addr_list, "*:*:ff,*:*:ee,*:*:ed");
    }

    avago_group_expand_broadcast(aapl, &addr_list);
    sbus_addr = avago_struct_to_addr(&addr_list);


    /* If given a single, invalid address that isn't a useful type, complain: */
    if( addr_list.next == 0
        && !aapl_check_ip_type(aapl, avago_struct_to_addr(&addr_list), __func__, __LINE__, TRUE, 7,
                                AVAGO_SPICO,    /* For -interrupt support only */
                                AVAGO_SERDES, AVAGO_SERDES_D6_BROADCAST,
                                AVAGO_M4,     AVAGO_SERDES_M4_BROADCAST,
                                AVAGO_P1,     AVAGO_SERDES_P1_BROADCAST) )
        goto cleanup_and_exit; /* prevents invalid addresses from silently doing nothing */

#if AAPL_ENABLE_FILE_IO
    firmware_file[0] = 0;
    if( upload ) avago_serdes_upload_firmware(aapl, &addr_list, fw_build, firmware_file_ptr, firmware_file, sizeof(firmware_file));

    /* If uploading to a broadcast address, or only one address, do it here: */
    if( upload && addr_b && addr_b_upload )
    {
        printf("Uploading file: %s to SBus address %s\n", firmware_file_ptr, aapl_addr_to_str(addr_b));
        avago_serdes_upload_firmware(aapl, &addr_b_struct, fw_build, firmware_file_ptr, firmware_file, sizeof(firmware_file));
    }
#endif /* AAPL_ENABLE_FILE_IO */

    if (addr_b && ( (aapl_get_ip_type(aapl, sbus_addr) == AVAGO_SERDES) || (aapl_get_ip_type(aapl, sbus_addr) == AVAGO_M4)) )
    {
        BOOL result;
        Avago_serdes_link_init_config_t *config = avago_serdes_link_init_config_construct(aapl, sbus_addr, aapl, addr_b);

        config->dfe_tune = tune;
# if AAPL_ENABLE_EYE_MEASUREMENT
        config->eye = eye;
#endif
        config->serdes_config_a->tx_divider = aapl_default_divider;
        config->serdes_config_a->rx_divider = aapl_default_divider;
        config->serdes_config_b->tx_divider = aapl_default_divider;
        config->serdes_config_b->rx_divider = aapl_default_divider;

        config->serdes_config_a->signal_ok_en = signal_ok_en;
        config->serdes_config_b->signal_ok_en = signal_ok_en;

        result = avago_serdes_link_init(config);
        avago_serdes_link_init_config_destruct(aapl, config);
        return result;
    }

    {
        Avago_addr_t *addr_struct;
        Avago_serdes_init_config_t *config;
        Avago_serdes_line_encoding_t tx_line_encoding = AVAGO_SERDES_NRZ;
        Avago_serdes_line_encoding_t rx_line_encoding = AVAGO_SERDES_NRZ;

        if( aapl_get_ip_type(aapl, sbus_addr) == AVAGO_M4 ) /* PAM only valid for M4 SerDes */
        {
            if( (tx_encoding == 4) && (tx_data_width == 0 || tx_data_width >= 20) ) /* PAM only valid at 20+ width modes */
                tx_line_encoding = AVAGO_SERDES_PAM4;

            if( (rx_encoding == 4) && (rx_data_width == 0 || rx_data_width >= 20) ) /* PAM only valid at 20+ width modes */
                rx_line_encoding = AVAGO_SERDES_PAM4;
        }

        config = avago_serdes_init_config_construct(aapl);
        config->sbus_reset = sbus_reset;
        if( tx_encoding   != 0 ) config->tx_encoding = tx_line_encoding;
        if( rx_encoding   != 0 ) config->rx_encoding = rx_line_encoding;
        if( tx_data_width != 0 ) config->tx_width = tx_data_width;
        if( rx_data_width != 0 ) config->rx_width = rx_data_width;
        if( rate_sel      != 1 ) config->rate_sel = rate_sel;
        if( burst_mode         ) config->burst_mode = burst_mode;
        config->rx_divider   = rx_divider;
        config->tx_divider   = tx_divider;
        config->signal_ok_en = signal_ok_en;
        config->tx_output_en = tx_output_enable;
        config->deep_post_en = deep_post_en;
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__,  "Setting data width to %d/%d, and line encoding to %s/%s\n",
            config->tx_width,config->rx_width, aapl_line_encoding_to_str(config->tx_encoding), aapl_line_encoding_to_str(config->rx_encoding));

        if( tx_datapath.mask )
        {
            if( tx_datapath.mask & 0x01 ) config->tx_datapath.polarity_invert = tx_datapath.polarity_invert;
            if( tx_datapath.mask & 0x02 ) config->tx_datapath.gray_enable     = tx_datapath.gray_enable;
            if( tx_datapath.mask & 0x04 ) config->tx_datapath.precode_enable  = tx_datapath.precode_enable;
            if( tx_datapath.mask & 0x08 ) config->tx_datapath.swizzle_enable  = tx_datapath.swizzle_enable;
            config->tx_datapath.mask |= tx_datapath.mask;
        }
        if( rx_datapath.mask )
        {
            if( rx_datapath.mask & 0x01 ) config->rx_datapath.polarity_invert = rx_datapath.polarity_invert;
            if( rx_datapath.mask & 0x02 ) config->rx_datapath.gray_enable     = rx_datapath.gray_enable;
            if( rx_datapath.mask & 0x04 ) config->rx_datapath.precode_enable  = rx_datapath.precode_enable;
            if( rx_datapath.mask & 0x08 ) config->rx_datapath.swizzle_enable  = rx_datapath.swizzle_enable;
            config->rx_datapath.mask |= rx_datapath.mask;
        }
        if( tx_core )
            config->init_mode = elb ? AVAGO_CORE_DATA_ELB : AVAGO_CORE_DATA_ILB;
        else
            config->init_mode = elb ? AVAGO_PRBS31_ELB : AVAGO_PRBS31_ILB;

        if( !base_init && !tx_init && !rx_init && !loopback_test )
            if (avago_parallel_serdes_init_by_group(aapl, &addr_list, config) < 0) goto cleanup_and_exit;
        if( base_init )
            if (avago_parallel_serdes_base_init(aapl, &addr_list, config->skip_crc ) < 0) goto cleanup_and_exit;

        for( addr_struct = &addr_list; addr_struct; addr_struct = addr_struct->next )
        {
            int width;
            uint sbus_addr = avago_struct_to_addr(addr_struct);
            Avago_serdes_pll_state_t pll_state;

            if( base_init || tx_init || rx_init || loopback_test )
            {
                if( tx_init )
                    avago_serdes_tx_init(aapl, sbus_addr, config);
                if( rx_init )
                    avago_serdes_rx_init(aapl, sbus_addr, config);
                if( loopback_test )
                    avago_serdes_loopback_test(aapl, sbus_addr, config);
                continue;
            }

            /* Parallel SerDes init status reporting: */
            avago_serdes_get_tx_pll_state(aapl, sbus_addr, &pll_state);     /* Get PLL state, which contains the estimated bitrate */
            avago_serdes_get_tx_rx_width(aapl, sbus_addr, &width, &width);
            tx_line_encoding = avago_serdes_get_tx_line_encoding(aapl, sbus_addr) ? AVAGO_SERDES_PAM4 : AVAGO_SERDES_PAM2;

            {
                printf("SerDes init complete for SBus %3s using div %d, width %s%d. ",
                    aapl_addr_to_str(sbus_addr), tx_divider,
                    tx_line_encoding == AVAGO_SERDES_NRZ ? "" : "P", width);
                if (!pll_state.est_rate)
                    printf("Estimated bit rate/ref clock:  ??  Gbps /  ?  MHz. CF: %3d.", pll_state.cal_code);
                else
                {
                        printf("Estimated bit rate/ref clock: ~%3d Gbps / %3d MHz. CF: %3d.",
                            (int)((pll_state.est_rate+500000000) / 1000000000) * (tx_line_encoding == AVAGO_SERDES_NRZ ? 1 : 2),
                            (int)(pll_state.est_rate / 1000000) / tx_divider, pll_state.cal_code);
                }

                printf(" ILB errors: %u.", (uint)addr_struct->bigint_results);
            }

            if( elb )
                run_elb_checks(aapl, sbus_addr, tune);

#           if AAPL_ENABLE_EYE_MEASUREMENT
            if( elb && eye )
            {
                Avago_serdes_eye_config_t *eye_config = avago_serdes_eye_config_construct(aapl);
                Avago_serdes_eye_data_t *eye_data = avago_serdes_eye_data_construct(aapl);
                eye_config->ec_eye_type = eye_type;
                eye_config->ec_y_points = y_points;
                eye_config->ec_y_step_size = y_step_size;
                eye_config->ec_x_resolution = x_resolution;

                avago_serdes_eye_get(aapl, sbus_addr, eye_config, eye_data);

                printf("\n");
                avago_serdes_eye_vbtc_log_print(aapl, AVAGO_INFO, __func__, __LINE__, &eye_data->ed_vbtc[0]);
                avago_serdes_eye_hbtc_log_print(aapl, AVAGO_INFO, __func__, __LINE__, &eye_data->ed_hbtc[0]);

                avago_serdes_eye_plot_log_print(aapl, AVAGO_INFO, __func__, __LINE__, eye_data);

                avago_serdes_eye_config_destruct(aapl, eye_config);
                avago_serdes_eye_data_destruct(aapl, eye_data);
            }
#           endif /* AAPL_ENABLE_EYE_MEASUREMENT */
            printf("\n");
#if         AAPL_ENABLE_DIAG
            run_health_check(aapl, sbus_addr, elb, signal_ok_en, tx_datapath.polarity_invert, link_train ? 2 : rx_datapath.polarity_invert);
#endif
        }
        avago_serdes_init_config_destruct(aapl, config);
    }

cleanup_and_exit:
    avago_group_clear(aapl, &addr_list);
    avago_addr_delete(aapl, &addr_list);
    return 0;
}
/* END INIT MAIN */


#if AAPL_ENABLE_DIAG
static int show_bsb_help()
{
    aapl_common_main_help(FALSE);
    printf(
"-source-addr <addr>     SBus address (eg. 0xa, 10, ff:ff:ff).\n"
"-dest-addr <addr>       SBus address (eg. 0xa, 10, ff:ff:ff).\n"
"-bsb-mode <mode>        mode=BSB_{DISABLE|CLK|PASSTHRU|DMA|SBUS|CORE}\n"
"-clk-sel <mode>         Clock sel for bsb-mode BSB_CLK. Default: RX_F10.\n"
"                        <mode> is one of:\n"
);
    printf(
"                          GND|PCS6466_FIFO_CLK|LSSEL|RESET_COMPLETE|AVDD|\n"
"                              REFCLK|REFCLK_TEST|\n"
"                          RX_{F10|F20|F40_FIFO_CLK|CLK|FIFO_CLK|PI_CLK|\n"
"                              F66_CLK|DIVX_CLK}|\n"
"                          TX_{F10|F20|F40|FIFO_CLK|TEST_CLK|DIVX_CLK|\n"
"                              F10_CLK_VAR|F20_CLK_VAR|CLK_TEST}|\n"
"                          SBUS_{CLK|CLK_TEST}\n"
);
    printf(
"-mem-addr <addr>        Memory address for bsb-mode BSB_DMA or BSB_SBUS.\n"
"-mem-bit <bit (0-31)>   Bit number associated with mem-addr.\n");

    return 1;
}


int aapl_bsb_main(int argc, char *argv[], Aapl_t *aapl)
{
    int dest_addr = 0;
    int source_addr = 0;
    int mem_addr  = 0;
    int mem_bit   = 0;
    Avago_serdes_bsb_mode_t bsb_mode = AVAGO_SERDES_BSB_CLK;
    Avago_serdes_bsb_clk_sel_t clk_sel = AVAGO_SERDES_BSB_RX_F10;
    int rc, index = 0;
    BOOL have_user_option = FALSE;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"dest-addr",    1, 0, 'D'}, /* address of channel for BSB data output */
        {"source-addr",  1, 0, 's'}, /* address of channel for BSB data origin */
        {"bsb-mode",     1, 0, 'm'}, /* bsb mode */
        {"clk-sel",      1, 0, 'c'}, /* bsb clock select */
        {"mem-addr",     1, 0, 'a'}, /* DMA address */
        {"mem-bit",      1, 0, 'b'}, /* DMA Bit */
        {0,              0, 0, 0}
    };

    if (aapl_common_main_options(aapl, argc, argv, 0) < 0)
        return show_bsb_help();

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        have_user_option = TRUE;
        switch( rc )
        {
        case 'D': dest_addr   = aapl_addr_from_str(optarg,name);     break;
        case 's': source_addr = aapl_addr_from_str(optarg,name);     break;
        case 'm': bsb_mode    = aapl_bsb_mode_from_str(optarg,name); break;
        case 'c': clk_sel     = aapl_bsb_clk_from_str(optarg,name);  break;
        case 'a': mem_addr    = aapl_num_from_str(optarg,name,0);    break;
        case 'b': mem_bit     = aapl_num_from_str(optarg,name,0);    break;
        case '?':
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
        }
    }
    if( !have_user_option )
        return show_bsb_help();

    if (source_addr == 0 && dest_addr == 0)
        aapl_main_error("Source and/or destination address required. Run with -h for a usage summary.");

    aapl_connect(aapl, 0, 0);
    aapl_get_ip_info(aapl, /* chip_reset */ 0);
    if( aapl_get_return_code(aapl) < 0 ) aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "aapl_get_ip_info returned a negative value.\n");

    avago_serdes_set_bsb(aapl, source_addr, dest_addr, bsb_mode, clk_sel, mem_addr, mem_bit);
    return 0;
}
#endif /* AAPL_ENABLE_DIAG */


/*============================================================================= */
/* The "main" main */
struct _cmds commands[] =
{
#if AAPL_ENABLE_AACS_SERVER
    {"aacs-server", aapl_aacs_server_main, "Run the aacs server"},
#endif
#if AAPL_ENABLE_AVSP_1104 && AAPL_ENABLE_FILE_IO
    {"avsp-1104",   aapl_avsp_1104_main,   "Run AVSP 1104 specific commands"},
    {"1104",        aapl_avsp_1104_main,    0},
#endif
#if AAPL_ENABLE_AVSP_4412 && AAPL_ENABLE_FILE_IO
    {"avsp-4412",   aapl_avsp_retimer_main,"Run AVSP 4412 specific commands"},
    {"4412",        aapl_avsp_retimer_main, 0},
#endif
#if AAPL_ENABLE_AVSP_5410 && AAPL_ENABLE_FILE_IO
    {"avsp-5410",   aapl_avsp_5410_main,   "Run AVSP 5410 specific commands"},
    {"5410",        aapl_avsp_5410_main,    0},
#endif
#if AAPL_ENABLE_AVSP_7412 && AAPL_ENABLE_FILE_IO
    {"avsp-7412",   aapl_avsp_7412_main,   "Run AVSP 7412 specific commands"},
    {"7412",        aapl_avsp_7412_main,    0},
#endif
#if AAPL_ENABLE_AVSP_8801 && AAPL_ENABLE_FILE_IO
    {"avsp-8801",   aapl_avsp_retimer_main,"Run AVSP 8801 specific commands"},
    {"8801",        aapl_avsp_retimer_main, 0},
#endif
#if AAPL_ENABLE_AVSP_8812 && AAPL_ENABLE_FILE_IO
    {"avsp-8812",   aapl_avsp_8812_main,   "Run AVSP 8812 specific commands"},
    {"8812",        aapl_avsp_8812_main,    0},
#endif
#if AAPL_ENABLE_AVSP_9104 && AAPL_ENABLE_FILE_IO
    {"avsp-9104",   aapl_avsp_9104_main,   "Run AVSP 9104 specific commands"},
    {"9104",        aapl_avsp_9104_main,    0},
#endif
#if AAPL_ENABLE_DIAG
    {"bist",        aapl_bist_main,        "Run BIST test"},
    {"bsb",         aapl_bsb_main,         "Configure SerDes BSB functionality for debug"},
#endif
    {"build-info",  aapl_build_info_main,  "Display version/build/compile info"},
#if AAPL_ENABLE_CONSOLE
    {"console",     aapl_console_main,     "AAPL interactive console"},
#endif
    {"cmd",         aapl_cmd_main,         "Directly execute a command"},
    {"device-info", aapl_device_info_main, "Display Avago device info"},
    {"dfe",         aapl_dfe_main,         "Display SerDes DFE info"},
#if AAPL_ENABLE_DIAG
    {"diag",        aapl_diag_main,        "Run diagnostics"},
#endif
#if AAPL_ENABLE_EEPROM && AAPL_ENABLE_AVSP_STATE
    {"eeprom",      aapl_eeprom_main,      "Create EEPROM images"},
#endif
#if AAPL_ENABLE_EFUSE && (AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS)
    {"efuse",       aapl_efuse_main,       "Read ASIC eFUSE info"},
#endif
#if AAPL_ENABLE_ESCOPE_MEASUREMENT
    {"escope",      aapl_escope_main,      "Extract a repeating pattern waveform"},
#endif
#if AAPL_ENABLE_EXAMPLES && AAPL_ENABLE_FILE_IO
    {"examples",    aapl_examples_main,    "Run examples"},
#endif
#if AAPL_ENABLE_EYE_MEASUREMENT
    {"eye",         aapl_eye_main,         "Measure the eye of a SerDes"},
#endif
#if AAPL_ENABLE_FEC
    {"fec",         aapl_fec_main,         "Configure FEC block."},
#endif
#if AAPL_ENABLE_SERDES_HAL
    {"hal",         aapl_hal_main,         "HAL interface."},
#endif
#if AAPL_ENABLE_HBM
    {"hbm",         aapl_hbm_main,         "Operate on an HBM interface."},
#endif
#if AAPL_ENABLE_PS1 && AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG
    {"ps1",         aapl_ps1_main,         "PS1 control and observation"},
#endif
#if AAPL_ENABLE_FILE_IO
    {"rom-info",    aapl_rom_info_main,    "Display firmware rom file info"},
#endif
    {"sbm",         aapl_sbus_master_main, "Operate on an SBus Master device"},
    {"serdes",      aapl_serdes_main,      "Configure a specific SerDes"},
#if AAPL_ENABLE_SERDES_AUTO_NEG
    {"serdes-an",   aapl_serdes_an_main,   "Configure serdes Auto-Negotiation."},
#endif
    {"serdes-init", aapl_serdes_init_main, "Initialize SerDes devices"},
#if AAPL_ENABLE_AVSP_STATE && AAPL_ENABLE_FILE_IO
    {"state",       aapl_state_main,       "Process AVSP startup state."},
#endif
#if AAPL_ENABLE_AVSP && AAPL_ENABLE_FILE_IO
    {"supervisor",  aapl_supervisor_main,  "Set or query supervisor status."},
#endif
    {"version",     aapl_version_main,     "Display version info"}
};

int commands_length = AAPL_ARRAY_LENGTH(commands);

static int find_command_index(const char *cmd)
{
    int best_match_index = -1;
    int best_match_length = 0;
    BOOL multiple_best_match = FALSE;
    int i;
    for( i = 0; i < AAPL_ARRAY_LENGTH(commands); i++ )
    {
        int match_length;
        const char *a = cmd;
        const char *b = commands[i].cmd;
        while( *a && *a == *b ) /* Count matching prefix length */
            a++, b++;
        if( !*a && !*b )
            return i;   /* Exact match */
        if( *a )
            continue;   /* cmd not fully matched */
        match_length = a - cmd;
        if( match_length > best_match_length )
        {
            best_match_length = match_length;
            best_match_index = i;
            multiple_best_match = FALSE;
        }
        else if( match_length == best_match_length )
            multiple_best_match = TRUE;
    }
    if( multiple_best_match )
    {
        printf("Command '%s' is ambiguous.\n",cmd);
        return -1;
    }
    if( best_match_index < 0 )
        printf("Command '%s' is not recognized.\n",cmd);
    return best_match_index;
}

static int print_usage(const char *name)
{
    int i;
    printf("AAPL Version: " AAPL_VERSION "\n" AAPL_COPYRIGHT "\n");
    printf("Usage: %s <command> <args>\n",name);
    printf("Available commands are:\n");
    for( i = 0; i < AAPL_ARRAY_LENGTH(commands); i++ )
        if( commands[i].description )   /* Omit from help if NULL description */
            printf("   %-21s %s\n",commands[i].cmd,commands[i].description);

    printf("\nRun '%s <command> -help' for more information on a specific command.\n", name);
    return 1;
}


/** @brief   The AAPL command line main program. */
/** @details Can be called from within customer code.  */
int aapl_main_str(Aapl_t *aapl, const char *str)
{
    char *argv[64];
    char *strstr = (char *)aapl_malloc(aapl, strlen(str)+1, __func__);
    int argc = 0, ret;
    snprintf(strstr, strlen(str)+1, "%s", str);
    aapl_str_to_arg(strstr, &argc, argv);
    ret = aapl_main(argc, argv, aapl);
    aapl_free(aapl, strstr, __func__);
    return ret;
}

/** @brief   Converts a string to argc/argv */
void aapl_str_to_arg(char *str, int *argc, char *argv[])
{
    char *found1 = 0, *save_ptr;
    *argc = 1; /* argument 1 is the name of the executable */
    argv[0] = (char *) "aapl_main";
    
    found1 = aapl_strtok_r(str, " ", &save_ptr);
    while (found1)
    {
        argv[(*argc)++] = found1;
        found1 = aapl_strtok_r(0, " ", &save_ptr);
    }
}

/** @brief   The AAPL command line main program. */
/** @details Can be called from within customer code. Use aapl_main_str() to pass a string instead of argv/argc */
int aapl_main(int argc, char *argv[], Aapl_t *aapl) /* externally callable main function */
{
    const char *name = _basename(argv[0]);
    int command_index = -1;
    char buf[1050];

    aapl->return_code = 0;

    if( argc >= 2 )
        command_index = find_command_index(argv[1]);

    if( command_index < 0 )
        return print_usage(name);

    snprintf(buf,sizeof(buf),"%s %s",name,commands[command_index].cmd);
    aapl_myname = argv[1] = buf;

    return commands[command_index].function(argc-1,argv+1, aapl);
}

int aapl_main_entry(int argc, char *argv[])
{
    int rc;
    Aapl_t *aapl = aapl_construct();
    rc = aapl_main(argc, argv, aapl);
    aapl_destruct(aapl);
    return rc;
}

#endif /* AAPL_ENABLE_MAIN */

/* run without delay cal @ 160 */
/* save DFE before and after pCal @ 180 */
/* delay cal ILB */
