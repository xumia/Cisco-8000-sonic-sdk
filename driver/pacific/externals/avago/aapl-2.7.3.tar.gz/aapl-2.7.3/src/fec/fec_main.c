/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* MAIN program for the serdes sub-command. */
/* */

/** Doxygen File Header */
/** @file */
/** @brief Launch wrappers for SerDes sub-commands. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_MAIN && AAPL_ENABLE_FEC

static int show_fec_help()
{
    aapl_common_main_help(TRUE);
    printf(
"-enable   <mode>            Enable FEC with selected mode. <mode>: FEC_528 or FEC_544. Default FEC_528.\n"
"-start-frame                Start FEC frame.\n"
"-halt     <0|1>             Halt FEC. 0 = Halt right now, 1 = Halt based on on_max_cw.\n"
);

    printf(
"-clear-on-read      <0|1>   Disable/enable clear on read.\n"
"-err-indication     <0|1>   Disable/enable error indication.\n"
"-err-correct-bypass <0|1>   Disable/enable bypass error correction.\n"
"-display                    Display FEC statistics.\n"
);

    printf(
"-get-status                 Get FEC status.\n"
"-reset-stats                Reset FEC statistics(counters).\n"
"-reset                      Reset FEC i.e reset gearfifo, reset ebuf, reset alignment, reset counters.\n"
);
    return 1;
}

int aapl_fec_main(int argc, char *argv[], Aapl_t *aapl)
{
    Avago_addr_t addr_struct;
    uint addr;
    int rc, index = 0;

    BOOL have_user_option = FALSE;
    BOOL halt_fec = FALSE;
    BOOL enable_fec = FALSE;
    BOOL start_frame = FALSE;
    int config_fec = 0;
    BOOL halt = 0;
    BOOL display = FALSE;
    BOOL get_status = FALSE;
    BOOL reset_stats = FALSE;
    BOOL reset = FALSE;
    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"enable",            1, NULL, 'e'}, /* Enable FEC */
        {"start-frame",       0, NULL, 'f'}, /* Start FEC frame */
        {"halt",              1, NULL, 'h'}, /* Configure the statistics of RSFEC to halt */
        {"display",           0, NULL, 'd'}, /* Display FEC statistics */
        {"clear-on-read",     1, NULL, 'c'}, /* Set clear on read configuration */
        {"err-indication",    1, NULL, 'i'}, /* Set error indication configuration */
        {"err-correct-bypass",1, NULL, 'b'}, /* Set error correction bypass configuration */
        {"get-status",        0, NULL, 's'}, /* Get FEC status */
        {"reset-stats",       0, NULL, 'R'}, /* Reset FEC counters */
        {"reset",             0, NULL, 'r'}, /* Reset FEC */
    };

    Avago_fec_config_t *config;
    config = avago_fec_config_construct(aapl);
    avago_addr_to_struct(aapl_default_device_addr, &addr_struct);
    if (aapl_common_main_options(aapl, argc, argv, &addr_struct) < 0)
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_fec_help();
    }

    addr = avago_struct_to_addr(&addr_struct);
    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        have_user_option = TRUE;
        switch( rc )
        {
        case 'e': enable_fec = TRUE; config->mode = aapl_fec_mode_from_str(optarg, name); break;
        case 'f': start_frame = TRUE; break;
        case 'h': halt = aapl_bool_from_str(optarg,name); halt_fec = TRUE; break;
        case 'd': display = TRUE; break;
        case 'c': config->stats_clear_on_read         = aapl_bool_from_str(optarg,name); config_fec |= 0x01; break;
        case 'i': config->error_indication_enable     = aapl_bool_from_str(optarg,name); config_fec |= 0x02; break;
        case 'b': config->error_correct_bypass_enable = aapl_bool_from_str(optarg,name); config_fec |= 0x04; break;
        case 's': get_status = TRUE; break;
        case 'R': reset_stats = TRUE; break;
        case 'r': reset = TRUE; reset_stats = TRUE; break;
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    if( !have_user_option )
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_fec_help();
    }
    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
    aapl_get_ip_info(aapl,0);

    if(!aapl_check_ip_type( aapl, addr, __func__, __LINE__, TRUE, 5,
                            AVAGO_PCS64B66B_FEC,
                            AVAGO_MLD,
                            AVAGO_RSFEC_BRIDGE,
                            AVAGO_OPAL_RSFEC528,
                            AVAGO_OPAL_RSFEC528_544
                          )
    )
    {
        goto cleanup_and_exit;
    }

    if( halt_fec )
    {
        if( halt == 0 ) avago_fec_set_stats_halt(aapl, addr, TRUE, FALSE);  /* Halt right now */
        else            avago_fec_set_stats_halt(aapl, addr, FALSE, TRUE);  /* Halt based on on_max_cw */
    }

    if( enable_fec )
    {
        aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, mode %s is selected.\n",
                              aapl_addr_to_str(addr), aapl_fec_mode_to_str(config->mode));
        avago_fec_chip_config(aapl, addr, config->mode);
    }

    if( start_frame )
        avago_rsfec_frame(aapl, addr);

    if( config_fec )
    {
        Avago_fec_config_t *new_config;
        new_config = avago_fec_config_construct(aapl);
        if( config_fec & 0x01 )
        {
            new_config->stats_clear_on_read = config->stats_clear_on_read;
            avago_fec_config(aapl, addr, AVAGO_FEC_CFG_CLR_ON_READ, new_config);
        }
        if( config_fec & 0x02 )
        {
            new_config->error_indication_enable = config->error_indication_enable;
            avago_fec_config(aapl, addr, AVAGO_FEC_CFG_ERR_INDICATION, new_config);
        }
        if( config_fec & 0x04 )
        {
            new_config->error_correct_bypass_enable = config->error_correct_bypass_enable;
            avago_fec_config(aapl, addr, AVAGO_FEC_CFG_ERR_COR_BYPASS, new_config);
        }
        avago_fec_config_destruct(aapl, new_config);
    }

    if( get_status )
    {
        Avago_fec_status_t status;
        int lane = 0;
        memset(&status, 0, sizeof(status));
        avago_fec_get_status(aapl, addr, &status);
        printf("FEC Status for SbusRx: %s\n", aapl_addr_to_str(addr));
        printf("%30s  %10s\n", "FEC mode", aapl_fec_mode_to_str(avago_rsfec_get_fec_mode(aapl, addr)));
        printf("%30s  %10s\n", "clear_on_read_active", aapl_bool_to_str(status.clear_on_read_active));
        for(lane = 0; lane < 4; lane++)
            printf("%30s%d %10s\n", "fec_align_status_lane", lane, aapl_bool_to_str(status.fec_align_status[lane]));

        for(lane = 0; lane < 4; lane++)
            printf("%30s%d %10s\n", "fec_lane_map_lane", lane, aapl_bool_to_str(status.fec_lane_map[lane]));

        printf("%30s  %10s\n", "error_indication_ability", aapl_bool_to_str(status.error_indication_ability));
        printf("%30s  %10s\n", "error_correct_bypass_ability", aapl_bool_to_str(status.error_correct_bypass_ability));
        printf("%30s  %10s\n", "error_indication", aapl_bool_to_str(status.error_indication));
        printf("%30s  %10s\n", "error_correct_bypass", aapl_bool_to_str(status.error_correct_bypass));
    }

    if( display )
    {
        char *buf;
        Avago_fec_stats_t stats;
        memset(&stats, 0, sizeof(stats));
        avago_fec_get_stats(aapl, &stats, addr, 4);
        buf = avago_rsfec_stats_to_str(aapl, &stats, addr);

        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Interleave: %s\n", (avago_sbus_rd(aapl, 0xA, 0x4) & 0x30) ? "BIT" : "RS_SYM");
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%s\n", buf);
            aapl_free(aapl, buf, __func__);
        }
    }

    if( reset_stats )
        /* Reset FEC counters */
        avago_fec_reset_stats(aapl, addr, FALSE);

    if( reset )
    {
        /* Reset halt flag if halted */
        avago_fec_reset_stats(aapl, addr, TRUE);

        /* Reset RSFEC alignment status */
        avago_fec_reset_alignment_status(aapl, addr);

        /* Reset the gear fifo status */
        avago_fec_reset_gearfifo(aapl, addr, TX_GEARFIFO_OVERFLOW_RESET);
        avago_fec_reset_gearfifo(aapl, addr, TX_GEARFIFO_UNDERFLOW_RESET);
        avago_fec_reset_gearfifo(aapl, addr, RX_GEARFIFO_OVERFLOW_RESET);
        avago_fec_reset_gearfifo(aapl, addr, RX_GEARFIFO_UNDERFLOW_RESET);

        /* Reset the ebuf status */
        avago_fec_reset_ebuf(aapl, addr, TX_EBUF_OVERFLOW_RESET);
        avago_fec_reset_ebuf(aapl, addr, TX_EBUF_UNDERFLOW_RESET);
        avago_fec_reset_ebuf(aapl, addr, RX_EBUF_OVERFLOW_RESET);
        avago_fec_reset_ebuf(aapl, addr, RX_EBUF_UNDERFLOW_RESET);
    }

cleanup_and_exit:
    avago_fec_config_destruct(aapl, config);
    if( aapl->return_code && !rc ) printf("ERROR\n");
    if( !rc && aapl->return_code != 0 ) rc = 1;
    avago_addr_delete(aapl, &addr_struct);
    return rc;
}

#endif /* AAPL_ENABLE_MAIN && AAPL_ENABLE_FEC */
