/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/** Doxygen File Header */
/** @file */
/** @brief Functions specific to the AVSP-5410 */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_AVSP_5410

/** @brief   Configure internal logic for the given mode. */
/** @return  On success, returns 0. */
/** @return  On failure, decrements aapl->return_code and returns -1. */
int avsp_5410_set_mode(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint prtad,         /**< [in] Port address of the target device. */
    Avsp_mode_t mode)   /**< [in] New mode to set */
{
    uint addr = 0;
    switch( mode )
    {
    case AVSP_REPEATER_DUPLEX: {

        break;
    }
    case AVSP_GEARBOX_4_1: {
        addr = avago_make_addr3(prtad, 0, 0xec);
        /* Set host i/f, clock reset */
          avago_sbus_wr(aapl, addr, 0xf9, 0x00);
          avago_sbus_wr(aapl, addr, 0x99, 0x0A05);

          /* Configuration */

          /* Assert Soft reset to garnet_25G_if register i/f */
          addr = avago_make_addr3(prtad, 0, 0x0b);
          avago_sbus_wr(aapl, addr, 0x04, 0x0f);

          /* RESETS 25G ADDR: 151 */
          addr = avago_make_addr3(prtad, 0, 0xec);
          avago_sbus_wr(aapl, addr, 151, 0x03);

          /* Override the reset ports, I_RESET_RX_0 input port & I_RESET_TX_0 input port */
          addr = avago_make_addr3(prtad, 0, 0xec);
          avago_sbus_wr(aapl, addr, 0x00, 0x07);
          avago_sbus_wr(aapl, addr, 0x20, 0x07);
          avago_sbus_wr(aapl, addr, 0x40, 0x07);
          avago_sbus_wr(aapl, addr, 0x60, 0x07);

          /* Wait for sometime */

          /* Set MODE_2X = 0, bypass= 0 , bypass2 = 0, host_40b = 0, mode_40g = 1 */
          /* CONTROL_25G_ADDR */
         /* avago_sbus_wr(aapl, addr, 0x150, 0x1009900f); */

          /* Disable FEC : CONFIG_ADDR = 0x5 */
          addr = avago_make_addr3(prtad, 0, 0x0b);
          avago_sbus_wr(aapl, addr, 0x05, 0x28);
          addr = avago_make_addr3(prtad, 0, 0x0c);
          avago_sbus_wr(aapl, addr, 0x05, 0x28);
          /* Wait for sometime */

          /* Deassert garnet_25G_if Reg resets */
          addr = avago_make_addr3(prtad, 0, 0x0b);
          avago_sbus_wr(aapl, addr, 0x04, 0x0e);
          avago_sbus_wr(aapl, addr, 0x04, 0x0c);
          /* Set AM_DEBUG_SHORT time = 1279 in 25G IF */
          /* REGISTER_ADDRESS_REG_ADDR */
          /* WRITE_DATA_REGISTER_ADDR */
          /* START_REGISTER_TRANSACTIONS_ADDR */
          avago_sbus_wr(aapl, addr,10,0x8002);
          avago_sbus_wr(aapl, addr,12,1279);
          avago_sbus_wr(aapl, addr,6,0x02);
          avago_sbus_wr(aapl, addr,6,0x00);

          /* Mode=2; 40@25, RS, MLD, CL82; PCS_MODE=1?, VENDOR_CONTROL=0x04 */
          /* write a=7,d=3'b100  PCS_MODE cl82; d=3'b000=cl49 */
          /* want VENDOR_CONTROL=4, PCS_MODE=1 */
          avago_sbus_wr(aapl, addr,10,0x7);
          avago_sbus_wr(aapl, addr,12,0x100);
          avago_sbus_wr(aapl, addr,6,0x10);
          avago_sbus_wr(aapl, addr,6,0x00);

          /* Deassert garnet_25G_if Reg resets */
          avago_sbus_wr(aapl, addr,4,0x00);

          /* deassert host resets */
          addr = avago_make_addr3(prtad, 0, 0xec);
          avago_sbus_wr(aapl, addr,0x00,0x05);
          avago_sbus_wr(aapl, addr,0x20,0x05);
          avago_sbus_wr(aapl, addr,0x40,0x05);
          avago_sbus_wr(aapl, addr,0x60,0x05);

          /* Wait for HOST LOCK */
          /* */

          /* Deassert 25G IF external resets based on bypass modes */
          avago_sbus_wr(aapl, addr,151,0x02);

          addr = avago_make_addr3(prtad, 0, 0xb);
          avago_sbus_wr(aapl, addr,0x04,0x00);

          /* deassert host resets */
          addr = avago_make_addr3(prtad, 0, 0xec);
          avago_sbus_wr(aapl, addr,0x00,0x01);
          avago_sbus_wr(aapl, addr,0x20,0x01);
          avago_sbus_wr(aapl, addr,0x40,0x01);
          avago_sbus_wr(aapl, addr,0x60,0x01);

          /* Wait for MOD BLOCK LOCK */


    }
    case AVSP_RS_FEC: {
         /*Assert all div66 clock reset */
          addr = avago_make_addr3(prtad, 0, 0xec);
          avago_sbus_wr(aapl, addr,0xf9,0x0f);

          /* Set host i/f, clock reset */
          avago_sbus_wr(aapl, addr,0xf9,0x00);
          avago_sbus_wr(aapl, addr,0x99,0x0A05);

          /* Configuration */

          /* Assert Soft reset to garnet_25G_if register i/f */
          addr = avago_make_addr3(prtad, 0, 0x0b);
          avago_sbus_wr(aapl, addr,0x04,0x0f);
          addr = avago_make_addr3(prtad, 0, 0x0c);
          avago_sbus_wr(aapl, addr,0x04,0x0f);

          /* RESETS 25G ADDR: 151 */
          addr = avago_make_addr3(prtad, 0, 0xec);
          avago_sbus_wr(aapl, addr,151,0x03);

          /* Override the reset ports, I_RESET_RX_0 input port & I_RESET_TX_0 input port */
          avago_sbus_wr(aapl, addr,0x00,0x07);
          avago_sbus_wr(aapl, addr,0x20,0x07);
          avago_sbus_wr(aapl, addr,0x40,0x07);
          avago_sbus_wr(aapl, addr,0x60,0x07);

           /* CONTROL_25G_ADDR */
/*          avago_sbus_wr(aapl, addr,150,0x1009900f); */

          /* Deassert garnet_25G_if Reg resets */
          addr = avago_make_addr3(prtad, 0, 0x0b);
          avago_sbus_wr(aapl, addr,0x04,0x0e);
          avago_sbus_wr(aapl, addr,0x04,0x0c);

          /* Set AM_DEBUG_SHORT time = 1279 in 25G IF */
          avago_sbus_wr(aapl, addr,10,0x8002);
          avago_sbus_wr(aapl, addr,12,1279);
          avago_sbus_wr(aapl, addr,6,0x02);
          avago_sbus_wr(aapl, addr,6,0x00);

          /* Mode=2; 40@25, RS, MLD, CL82; PCS_MODE=1?, VENDOR_CONTROL=0x04 */
          /* write a=7,d=3'b100  PCS_MODE cl82; d=3'b000=cl49 */
          /* want VENDOR_CONTROL=4, PCS_MODE=1 */
          avago_sbus_wr(aapl, addr,10,0x7);
          avago_sbus_wr(aapl, addr,12,0x100);
          avago_sbus_wr(aapl, addr,6,0x10);
          avago_sbus_wr(aapl, addr,6,0x00);
          /* Deassert garnet_25G_if Reg resets */
          avago_sbus_wr(aapl, addr,4,0x00);

          /* deassert host resets */
          addr = avago_make_addr3(prtad, 0, 0xec);
          avago_sbus_wr(aapl,addr,0x00,0x05);
          avago_sbus_wr(aapl,addr,0x20,0x05);
          avago_sbus_wr(aapl,addr,0x40,0x05);
          avago_sbus_wr(aapl,addr,0x60,0x05);

          /* Wait for HOST LOCK */
          /* */

          /* Deassert 25G IF external resets based on bypass modes */
          avago_sbus_wr(aapl,addr,151,0x02);

          addr = avago_make_addr3(prtad, 0, 0xb);
          avago_sbus_wr(aapl,addr,0x04,0x00);

          /* deassert host resets */
          addr = avago_make_addr3(prtad, 0, 0xec);
          avago_sbus_wr(aapl,addr,0x00,0x01);
          avago_sbus_wr(aapl,addr,0x20,0x01);
          avago_sbus_wr(aapl,addr,0x40,0x01);
          avago_sbus_wr(aapl,addr,0x60,0x01);
    }
    default:
    break;
    }
    return 0;
}

/** @brief  Retrieves the mode into which the core logic is configured. */
/** @return Returns the core logic configuration mode. */
Avsp_mode_t avsp_5410_get_mode(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint prtad)     /**< [in] Port address of the target device. */
{
    uint addr = avago_make_addr3(prtad, 0, 0xfd);
    int val = avago_spico_int(aapl,addr,0x26,0x3800) & 0x0f;
    Avsp_mode_t mode = val == 0x001 ? AVSP_REPEATER_DUPLEX :
                       val == 0x002 ? AVSP_GEARBOX_4_1 :
                       val == 0x003 ? AVSP_RS_FEC : AVSP_ADHOC;
    return mode;
}


/** @brief This is a DEBUGGING function. */
/** @details  NOTE: This function is provided for purposes of testing, but */
/**           not for production code. */
/**           This signature is likely to change in a future release. */
/** @details           Sets up various host/module side loopback modes. */
/**                    The NEAR loopback modes re-configure the SerDes on */
/**                    the selected #lb_side. All other loopback modes assume */
/**                    that the chip has already been stated by the user into */
/**                    a desired configuration.  All modes can be recovered */
/**                    by issuing the AVSP_LB_OFF case. Keep in mind that there is */
/**                    no checking done on the current state. It is up to the */
/**                    user to ensure that only one LB mode is selected at any */
/**                    time as these can interfere with each other. */
/** @return  On success, returns 0. */
/** @return  On failure, returns -1. */
int avsp_5410_loopback(
    Aapl_t *aapl,
    const char * sel_tuning,
    uint prtad,
    Avsp_lb_mode_t lb_mode,
    Avsp_lb_side_t lb_side)
{
    uint sbus;
    uint addr;
    Avago_serdes_dfe_state_t *dfe = avago_serdes_dfe_state_construct(aapl);

    /* Near host */
    /* Put host in PLB */
    if ((lb_mode = AVSP_LB_NEAR) && (lb_side = AVSP_LB_HOST))
    {
        /* Perfor on Host slice parallel lb */
        for( sbus = 0x06; sbus <= 0x09; sbus++)
        {
            addr = avago_make_addr3(prtad, 0, sbus);
            avago_serdes_set_tx_data_sel(   aapl, addr, AVAGO_SERDES_TX_DATA_SEL_LOOPBACK);
            avago_serdes_set_tx_pll_clk_src(aapl, addr, AVAGO_SERDES_TX_PLL_RX_DIVX);
        }

        /* Optional DFE tune on host slices */
        if( strcmp( sel_tuning, "TUNE") == 0 ){
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing ical tuning on Rx of Host slices.\n");
            avsp_batch_tune(aapl, prtad, AVSP_HOST, dfe, 500, 400, 10000);
        }

        /* Phase cal on host slices */
        for( sbus = 0x06; sbus <= 0x09; sbus++)
        {
            avago_spico_int_check(aapl, __func__, __LINE__, addr, 0xb, 1);     /* Tx Phase Cal */
        }
    }

    /* Far host */
    /* Put mod in ILB */
    if ((lb_mode = AVSP_LB_FAR) && (lb_side = AVSP_LB_HOST))
    {
        /* MOD slice in ILB */
        addr = avago_make_addr3(prtad, 0, 0x05);
        avago_serdes_set_rx_input_loopback(aapl, addr, TRUE);

        /* Optional DFE tune on host slices */
        if( strcmp( sel_tuning, "TUNE") == 0 ){
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing ical tuning on Rx of Host slices.\n");
            avsp_batch_tune(aapl, prtad, AVSP_HOST, dfe, 500, 400, 10000);
        }

        /* Phase cal on host slices */
        for( sbus = 0x06; sbus <= 0x09; sbus++)
        {
            avago_spico_int_check(aapl, __func__, __LINE__, addr, 0xb, 1);     /* Tx Phase Cal */
        }

        /* Control logic reset on mod-to-host path */
        avsp_5410_control_logic_reset_direct(aapl, prtad, "mod_to_host");
    }

    /*  Near mod */
    /*  Put mod in PLB */
    if ((lb_mode = AVSP_LB_NEAR) && (lb_side = AVSP_LB_MOD))
    {
        addr = avago_make_addr3(prtad, 0, 0x05);
        avago_serdes_set_tx_data_sel(   aapl, addr, AVAGO_SERDES_TX_DATA_SEL_LOOPBACK);
        avago_serdes_set_tx_pll_clk_src(aapl, addr, AVAGO_SERDES_TX_PLL_RX_DIVX);

        /* Optional DFE tune on mod slice */
        if( strcmp( sel_tuning, "TUNE") == 0 ){
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing ical tuning on Rx of Host slices.\n");
            avsp_batch_tune(aapl, prtad, AVSP_MOD, dfe, 500, 400, 10000);
        }

        /* Phase cal on mod slice */
        addr = avago_make_addr3(prtad, 0, 0x05);
        avago_spico_int_check(aapl, __func__, __LINE__, addr, 0xb, 1);     /* Tx Phase Cal */
    }

    /* Far mod */
    /* Put host in ILB */
    if ((lb_mode = AVSP_LB_FAR) && (lb_side = AVSP_LB_MOD))
    {
        /* Perfor on Host slice parallel lb */
        for( sbus = 0x06; sbus <= 0x09; sbus++)
        {
            addr = avago_make_addr3(prtad, 0, sbus);
            avago_serdes_set_rx_input_loopback(aapl, addr, TRUE);
        }

        /* Optional DFE tune on mod slice */
        if( strcmp( sel_tuning, "TUNE") == 0 ){
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing ical tuning on Rx of Host slices.\n");
            avsp_batch_tune(aapl, prtad, AVSP_MOD, dfe, 500, 400, 10000);
        }

        /* Phase cal on mod slice */
        addr = avago_make_addr3(prtad, 0, 0x05);
        avago_spico_int_check(aapl, __func__, __LINE__, addr, 0xb, 1);     /* Tx Phase Cal */

        /* Control logic reset on host-to-mod path */
        avsp_5410_control_logic_reset_direct(aapl, prtad, "host_to_mod");
    }

    /* Loopback OFF */
    else if (lb_mode == AVSP_LB_OFF)
    {
        /* Host slices */
        for( sbus = 0x06; sbus <= 0x09; sbus++ )
        {
            addr = avago_make_addr3(prtad, 0, sbus);
            avago_serdes_set_rx_input_loopback(aapl, addr, FALSE);
            avago_serdes_set_tx_data_sel(      aapl, addr, AVAGO_SERDES_TX_DATA_SEL_CORE);
        }
        /* mod slice */
        addr = avago_make_addr3(prtad, 0, 0x05);
        avago_serdes_set_rx_input_loopback(aapl, addr, FALSE);
        avago_serdes_set_tx_data_sel(      aapl, addr, AVAGO_SERDES_TX_DATA_SEL_CORE);

        if( strcmp( sel_tuning, "TUNE") == 0 ){
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing ical tuning on Rx of Host slices.\n");
            avsp_batch_tune(aapl, prtad, AVSP_ALL, dfe, 500, 400, 10000);
        }
        for( sbus = 0x05; sbus <= 0x09; sbus++ )
        {
            avago_spico_int_check(aapl, __func__, __LINE__, addr, 0xb, 1);     /* Tx Phase Cal */
        }
        avsp_5410_control_logic_reset_direct(aapl, prtad, "both");
    }

    /* Any unsupported selection */
    else
    {
        aapl_fail(aapl, __func__,__LINE__, "An invalid loopback method was selected\n");
        avago_serdes_dfe_state_destruct(aapl, dfe);
        return -1;
    }

    avago_serdes_dfe_state_destruct(aapl, dfe);
    return 0;
}



/** @brief   Bring up device according to rx signal */
/** @return  On success, returns 0. */
/** @return  On error, returns -1. */
int avsp_5410_bring_up(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    uint prtad,             /**< [in] Port address of the targeted device */
    const char * direction)     /**< [in] direction for bring up */
{
    Avago_serdes_dfe_state_t *dfe = avago_serdes_dfe_state_construct(aapl);
    uint sbus_addr;

    if( strcmp( direction, "HOST") == 0 || strcmp( direction, "both") == 0 ) /* bring up host mod path */
    {
        aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing ical tuning on Rx of Host slices.\n");
        avsp_batch_tune(aapl, prtad, AVSP_HOST, dfe, 500, 400, 10000);
        aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing phase cal on Tx of mod slice.\n");
        sbus_addr = avago_make_addr3(prtad, 0, 0x05);
        avago_spico_int_check(aapl, __func__, __LINE__, sbus_addr, 0xb, 1);     /* Tx Phase Cal */
    }
    if( strcmp( direction, "MOD") == 0 || strcmp( direction, "both") == 0 ) /* bring up mod host path */
    {
        uint i;
        aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing ical tuning on Rx of Mod slice.\n");
        avsp_batch_tune(aapl, prtad, AVSP_MOD, dfe, 500, 400, 10000);
        aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing phase cal on Tx of host slices.\n");
        for( i = 0x6; i <= 0x9; i++ )
        {
             sbus_addr = avago_make_addr3(prtad, 0, i);
             avago_spico_int_check(aapl, __func__, __LINE__, sbus_addr, 0xb, 1);     /* Tx Phase Cal */
        }

    }
    avago_serdes_dfe_state_destruct(aapl, dfe);

    return 0;
}


/** @brief   Directly resets the core logic. */
/** @return  On success, returns 0. */
/** @return  On failure, decrements aapl->return_code and returns -1. */
BOOL avsp_5410_control_logic_reset_direct(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint prtad,        /**< [in] Port address of the targeted device. */
    const char * direction) /**< [in] direction from host to mod or mod to host */
{
    uint addr;
    addr = avago_make_addr3(prtad, 0, 0xa);

    if( strcmp( direction, "host_to_mod") == 0 || strcmp( direction, "both") == 0){
        /* reset host to mod path */
        aapl_log_printf(aapl,AVAGO_INFO,0,0,"Resetting control logic from host to mod direction \n");
        avago_sbus_wr(aapl, addr, 0, 0x0002);  /* Assert PCS LANE0 Tx Reset */
        avago_sbus_wr(aapl, addr, 20, 0x0002);  /* Assert PCS LANE1 Tx Reset */

        avago_sbus_wr(aapl, addr, 0, 0);  /* Clear PCS LANE0 Tx Reset */
        avago_sbus_wr(aapl, addr, 20, 0);  /* Clear PCS LANE1 Tx Reset */
    }
    if( strcmp( direction, "mod_to_host") == 0 || strcmp( direction, "both") == 0){
        /* reset mod to host path */
        aapl_log_printf(aapl,AVAGO_INFO,0,0,"Resetting control logic from mod to host direction \n");
        avago_sbus_wr(aapl, addr, 0, 0x0001);  /* Assert PCS LANE0 Tx Reset */
        avago_sbus_wr(aapl, addr, 20, 0x0001);  /* Assert PCS LANE1 Tx Reset */

        avago_sbus_wr(aapl, addr, 0, 0);  /* Clear PCS LANE0 Tx Reset */
        avago_sbus_wr(aapl, addr, 20, 0);  /* Clear PCS LANE1 Tx Reset */

        /* Reset MTIP core */
        avago_sbus_wr(aapl, addr, 151, 0x0003);  /* Assert 25G (MTIP) LANE0 reset */
        avago_sbus_wr(aapl, addr, 151, 0x0002);  /* Clear 25G (MTIP) LANE0 reset */
    }
    return 0;
}
#endif /* AAPL_ENABLE_AVSP_5410 */
