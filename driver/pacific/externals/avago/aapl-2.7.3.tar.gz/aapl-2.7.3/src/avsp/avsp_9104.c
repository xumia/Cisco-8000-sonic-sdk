/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* AAPL (ASIC and ASSP Programming Layer) support for AVSP */

/** Doxygen File Header */
/** @file */
/** @brief Functions specific to the AVSP-1104 and AVSP-9104. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_AVSP_9104

/*============================================================================= */
/* A V S P   9 1 0 4   L O O P B A C K */
/* */
/** @brief This is a DEBUGGING function. */
/** @details  NOTE: This function is provided for purposes of testing, but */
/**           not for production code. */
/**           This signature is likely to change in a future release. */
/** @details           Sets up various host/module side loopback modes. */
/**                    The NEAR loopback modes re-configure the SerDes on */
/**                    the selected #lb_side. All other loopback modes assume */
/**                    that the chip has already been stated by the user into */
/**                    a desired configuration.  All modes can be recovered */
/**                    by issuing the AVSP_LB_OFF case. Keep in mind that there is */
/**                    no checking done on the current state. It is up to the */
/**                    user to ensure that only one LB mode is selected at any */
/**                    time as these can interfere with each other. */
/** @param div_ratio   This sets the divider ratio in the SerDes. Bitrate is */
/**                    equal to div_ratio * refclk, this is only used in the */
/**                    NEAR #lb_mode and is ignored in other cases. */
/** @param lb_mode     Selects one of the loopback options */
/**                    - AVSP_LB_NEAR: The near side data is sent along in parallel */
/**                               loopback, and the clock used on the TX is recovered */
/**                               from the FAR side being in ILB. */
/**                    - AVSP_LB_FAR:  Sets the SerDes on the opposing lb_side into */
/**                               internal loopback (ILB) mode sending TX data */
/**                               back into the RX. This setup makes no changes */
/**                               to the current SerDes states so the device must */
/**                               be properly configured beforehand. */
/**                    - AVSP_LB_OFF:  This option turns off all loopback on all SerDes. */
/**                               This will recover from all modes besides AVSP_LB_NEAR. */
/**                               All the loopback modes issue a rest to the control */
/**                               logic when transitioning between modes so while */
/**                               the device will still pass all traffic, the user */
/**                               should expect to see that lane markers are not */
/**                               maintained in the same channels as they were */
/**                               prior to the issue of loopback change. */
/**                    - AVSP_LB_STATE:This option makes no change to the current state */
/**                               and simply reads the current value of the */
/**                               loopback bits in each bank of SerDes. Each indicator */
/**                               bit is only set if all SerDes in a given bank are */
/**                               in the same mode, this is a pretty gross check of */
/**                               the current state. */
/**                               return[0] - indicates all Host slices are in ILB */
/**                               return[1] - indicates all Host slices are in PLB */
/**                               return[2] - indicates all MOD25G# slices are in ILB */
/**                               return[3] - indicates all MOD25G# slices are in PLB */
/**                               return[4] - indicates all MOD slices are in ILB */
/**                               return[5] - indicates all MOD slices are in PLB */
/** @param lb_side     Selects one side of the chip for configuration */
/**                    - AVSP_LB_HOST: Directs the #lb_mode selection to the host side */
/**                    - AVSP_LB_MOD:  Directs the #lb_mode selection to the mod side. */
/**                               The MOD selection also uses the pma_v_rpt choice */
/**                               to determine if 4 or 10 devices are targetted. */
/** @return   The return value is 0 for most states, and in the AVSP_LB_STATE mode */
/**           selection the return value indicates the current state of */
/**           loopback bits in the chip. */

uint avsp_9104_loopback(
    Aapl_t *aapl,               /**< Pointer to Aapl_t structure. */
    uint div_ratio,             /**< */
    uint avsp_prtad,            /**< The port address of the targeted device */
    Avsp_mode_t pma_v_rpt,      /**< AVSP_PMA or AVSP_RPT */
    Avsp_lb_mode_t lb_mode,     /**< */
    Avsp_lb_side_t lb_side)     /**< */
{
    return avsp_1104_loopback(aapl, div_ratio, avsp_prtad, pma_v_rpt, lb_mode, lb_side);
}


/*============================================================================= */
/* A V S P   9 1 0 4   S L I P */
/* */
/** @brief   Function to achieve alignment in DEMO modes. */
/** @brief    This is a DEBUGGING function. */
/** @details  NOTE: This function is provided for purposes of testing, but */
/**           not for production code. */
/**           This signature is likely to change in a future release. */
/** */
/** This function sets a host slice to output parallel PRBS data into */
/** the core and then performs bit-slips on the associated module slice */
/** until the same PRBS pattern is detected back at the parallel input to */
/** the slice. After this is accomplished, there is some cleanup activity */
/** to put the slice back into a known good state. The end result is that */
/** data coming into the host_sbus_addr RX will be aligned so that it */
/** returns to the host_sbus_rx TX */
/** */
/** @return  Returns TRUE on success, FALSE on failure. */
uint avsp_9104_slip(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint avsp_prtad,        /**< [in] MDIO address of the device */
    uint host_sbus_addr,    /**< [in] SBus slice address for host slice sending data */
    uint mod_sbus_addr)     /**< [in] SBus slice address for mod slice looping data back */
{
    return avsp_1104_slip(aapl, avsp_prtad, host_sbus_addr, mod_sbus_addr);
}

/** @brief  Retrieves the mode into which the core logic is configured. */
/** @return Returns the core logic configuration mode. */
Avsp_mode_t avsp_9104_get_mode(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint avsp_prtad)        /**< [in] MDIO address of the device */
{
    return avsp_1104_get_mode(aapl, avsp_prtad);
}


/** @brief  Configure 9104 modes. */
/** @return Returns 0 on success. */
/** @return On error, decrements aapl->return_code and returns -1. */
int avsp_9104_set_control(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    uint prtad,                 /**< [in] The port address of the device to modify. */
    Avsp_fec_register_t type,   /**< [in] Select register to update. */
    int value)                  /**< [in] New value to set. */
{
    uint ctl_logic = avago_make_addr3(prtad, 0, 0x2c);
    switch( type )
    {
    case AVSP_FEC_ERROR_INDICATION_DISABLE:
        avago_sbus_rmw(aapl, ctl_logic, 0xd0, value ? 0x02 : 0, 0x02);
        return 0;
    case AVSP_FEC_ERROR_CORRECTION_BYPASS_ENABLE:
        avago_sbus_rmw(aapl, ctl_logic, 0xd0, value ? 0x08 : 0, 0x08);
        return 0;
    default: break;
    }
    return aapl_fail(aapl, __func__, __LINE__, "Unsupported Avsp_fec_register_t type: %d\n", type);
}

/** @brief  Reads FEC status registers. */
/** @return On success, returns the value requested. */
/** @return On error, decrements aapl->return_code and returns -1. */
int avsp_9104_get_status(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    uint prtad,                 /**< [in] The port address of the device to read. */
    Avsp_fec_register_t type,   /**< [in] Status type to retrieve.  For multi-value types, lane and/or host provide the index. */
    uint lane,                  /**< [in] Select lane number. Range [0-3] for symbol errors, */
                                /**<      [0-19] for BIP errors. */
    BOOL host)                  /**< [in] Select host(TRUE) or mod(FALSE) slices */
{
    uint ctl_logic = avago_make_addr3(prtad, 0, 0x2c);
    switch( type )
    {
    case AVSP_PCS_LANE_MAPPING:     /* Select which lane to read, then read: */
                                             avago_sbus_wr(aapl, ctl_logic, 0xa3, (lane & 0x1f));
                                     return (avago_sbus_rd(aapl, ctl_logic, 0xa3) >>  5) & 0x1f;
    case AVSP_PCS_LANE_ALIGNMENT:    return  avago_sbus_rd(aapl, ctl_logic, 0xa4);  /* bits [19:0] */
    case AVSP_PCS_BLOCK_LOCK:        return  avago_sbus_rd(aapl, ctl_logic, 0xa5);  /* bits [19:0] */
/*  case AVSP_FEC_HIGH_SER: */

    case AVSP_FEC_ERROR_INDICATION_DISABLE_ABILITY: return (avago_sbus_rd(aapl, ctl_logic, 0xd0) >> 0) & 1;
    case AVSP_FEC_ERROR_INDICATION_DISABLE:         return (avago_sbus_rd(aapl, ctl_logic, 0xd0) >> 1) & 1;
    case AVSP_FEC_ERROR_CORRECTION_BYPASS_ABILITY:  return (avago_sbus_rd(aapl, ctl_logic, 0xd0) >> 2) & 1;
    case AVSP_FEC_ERROR_CORRECTION_BYPASS_ENABLE:   return (avago_sbus_rd(aapl, ctl_logic, 0xd0) >> 3) & 1;
    case AVSP_FEC_LANE_ALIGNMENT: return (avago_sbus_rd(aapl, ctl_logic, 0xa3) >> 21) & 0xf;
    case AVSP_FEC_LANE_MAPPING:  /* Return hex value with lane maps for 3-0 stored in a hex value as 0x3210 */
    {
        int ret = avago_sbus_rd(aapl, ctl_logic, 0xd0);
        return ((ret >> 8) & 3) | ((ret >> 6) & 0x30) | ((ret >> 4) & 0x300) | ((ret >> 2) & 0x3000);
    }
    case AVSP_FEC_CORRECTED:     return  avago_sbus_rd(aapl, ctl_logic, 0xd1);
    case AVSP_FEC_UNCORRECTED:   return  avago_sbus_rd(aapl, ctl_logic, 0xd2);
    case AVSP_FEC_SYMBOL_ERRORS: return  avago_sbus_rd(aapl, ctl_logic, 0xd3 + (lane & 3));
/*  case AVSP_HI_BER:            return (avago_sbus_rd(aapl, ctl_logic, 0x31) >> (host ? 6 : 7)) & 1; */
    case AVSP_BIP_ERRORS:        /* Select which host/lane to read, then read: */
                                         avago_sbus_wr(aapl, ctl_logic, 0xe1, (host & 0x1) | ((lane & 0x1f) << 1));
                                 return (avago_sbus_rd(aapl, ctl_logic, 0xe1) >> 13) & 0xffff;
    case AVSP_ALL_ERRORS:
    {
        int lane;
        int errors = 0;

        int errors_1 = avsp_9104_get_status(aapl, prtad, AVSP_FEC_CORRECTED, 0, 0);
        int errors_2 = avsp_9104_get_status(aapl, prtad, AVSP_FEC_UNCORRECTED, 0, 0);
        errors += errors_1 + errors_2;
        if( aapl->verbose )
        {
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"Corrected:    %11d\n",errors_1);
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"Uncorrected:  %11d\n",errors_2);
        }
        for( lane = 0; lane < 4; lane++ )
        {
            int errors_lane = avsp_9104_get_status(aapl, prtad, AVSP_FEC_SYMBOL_ERRORS, lane, 0);
            errors += errors_lane;
            if( aapl->verbose )
                aapl_log_printf(aapl,AVAGO_INFO,0,0,"Sym[lane %2d]: %11d\n",lane,errors_lane);
        }

        for (lane = 0; lane < 20; lane++)
        {
            int errors_m = avsp_9104_get_status(aapl, prtad, AVSP_BIP_ERRORS, lane, 0);
            int errors_h = avsp_9104_get_status(aapl, prtad, AVSP_BIP_ERRORS, lane, 1);
            errors += errors_m + errors_h;
            if( aapl->verbose )
                aapl_log_printf(aapl,AVAGO_INFO,0,0,"BIP[host %2d]: %11d,   BIP[mod %2d]: %11d\n", lane, errors_h, lane, errors_m);
        }
        if( aapl->verbose )
        {
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"PCS Block Lock     = 0x%05x\n", avsp_9104_get_status(aapl, prtad, AVSP_PCS_BLOCK_LOCK       , 0, 0));
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"PCS Lane Alignment = 0x%05x\n", avsp_9104_get_status(aapl, prtad, AVSP_PCS_LANE_ALIGNMENT   , 0, 0));
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"FEC Lane Alignment = 0x----%x\n", avsp_9104_get_status(aapl, prtad, AVSP_FEC_LANE_ALIGNMENT, 0, 0));
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"PCS Lane Mapping:");
            for( lane = 0; lane < 20; lane++ )
                aapl_log_printf(aapl,AVAGO_INFO,0,0,"%3d", avsp_9104_get_status(aapl, prtad, AVSP_PCS_LANE_MAPPING, lane, 0));
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"\n");
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"FEC Lane Mapping   = 0x%05x\n", avsp_9104_get_status(aapl, prtad, AVSP_FEC_LANE_MAPPING  , 0, 0));
        }
        return errors;
    }
    default: break;
    }
    return aapl_fail(aapl, __func__, __LINE__, "Unsupported Avsp_fec_register_t type: %d\n", type);
}

#if 0
static int avsp_9104_setup_broadcast(Aapl_t *aapl, uint prtad)
{
    /*echo "Setup broadcast addresses of interest, all host slices get 0xca and mod slices get 0xcd" */
    avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1e), 0xfd, 0x00ff0ca0); /* Set H10G0 to have broadcast addresses 0xff and 0xca */
    avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1d), 0xfd, 0x00ff0ca0); /* Set H10G1 to have broadcast addresses 0xff and 0xca */
    avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1c), 0xfd, 0x00ff0ca0); /* Set H10G2 to have broadcast addresses 0xff and 0xca */
    avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1b), 0xfd, 0x00ff0ca0); /* Set H10G3 to have broadcast addresses 0xff and 0xca */
    avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x20), 0xfd, 0x00ff0ca0); /* Set H10G4 to have broadcast addresses 0xff and 0xca */
    avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1a), 0xfd, 0x00ff0ca0); /* Set H10G5 to have broadcast addresses 0xff and 0xca */
    avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x18), 0xfd, 0x00ff0ca0); /* Set H10G6 to have broadcast addresses 0xff and 0xca */
    avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x21), 0xfd, 0x00ff0ca0); /* Set H10G7 to have broadcast addresses 0xff and 0xca */
    avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x19), 0xfd, 0x00ff0ca0); /* Set H10G8 to have broadcast addresses 0xff and 0xca */
    avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1f), 0xfd, 0x00ff0ca0); /* Set H10G9 to have broadcast addresses 0xff and 0xca */

    avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x08), 0xfd, 0x00ff0cb0); /* Set M25G0 to have broadcast addresses 0xff and 0xcb */
    avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x07), 0xfd, 0x00ff0cb0); /* Set M25G1 to have broadcast addresses 0xff and 0xcb */
    avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x06), 0xfd, 0x00ff0cb0); /* Set M25G2 to have broadcast addresses 0xff and 0xcb */
    avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x05), 0xfd, 0x00ff0cb0); /* Set M25G3 to have broadcast addresses 0xff and 0xcb */
    return 0;
}
#endif

static void avsp_9104_rs_fec_init(Aapl_t *aapl, uint prtad)
{
    int addr;
    uint slice_0xb  = avago_make_addr3(prtad, 0, 0x0b);
    uint serdes_addr;
    uint ctl_logic = avago_make_addr3(prtad, 0, 0x2c);


    /* Reset and initialize all slices in a default mode */
    for( addr = 0x18; addr <= 0x21; addr++ )
        avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, addr), 0x07, 0x00000011); /* Reset the slice */
    for( addr = 5; addr <= 8; addr++ )
        avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, addr), 0x07, 0x00000011); /* Reset the slice */
    avago_sbus_wr(aapl, slice_0xb, 0x07, 0x00000011); /* Reset the slice */

    for( addr = 0x18; addr <= 0x21; addr++ )
    {
        serdes_addr = avago_make_addr3(prtad, 0, addr);
        avago_sbus_wr(aapl, serdes_addr, 0x07, 0x00000010); /* Clear the reset */
        avago_sbus_wr(aapl, serdes_addr, 0x07, 0x00000012); /* Re-enable SPICO */
    }

    for( addr = 5; addr <= 8; addr++ )
    {
        serdes_addr = avago_make_addr3(prtad, 0, addr);
        avago_sbus_wr(aapl, serdes_addr, 0x07, 0x00000010); /* Clear the reset */
        avago_sbus_wr(aapl, serdes_addr, 0x07, 0x00000012); /* Re-enable SPICO */
    }

    avago_sbus_wr(aapl, slice_0xb, 0x07, 0x00000010); /* Clear the reset */
    avago_sbus_wr(aapl, slice_0xb, 0x07, 0x00000012); /* Re-enable SPICO */

    for (addr = 0x18; addr <= 0x21; addr++)
    {
        serdes_addr = avago_make_addr3(prtad, 0, addr);
        avago_spico_int(aapl, serdes_addr, 0x01, 0x0000);   /* Disable TX/RX/output */
        avago_spico_int(aapl, serdes_addr, 0x11, 0x0003);   /* Set recal bits on TX/RX */
        avago_spico_int(aapl, serdes_addr, 0x05, 0x9042);   /* Set div ratio of 64 on host slices */
        avago_spico_int(aapl, serdes_addr, 0x14, 0x0011);   /* Set 20 bit mode on hosts */
        avago_spico_int(aapl, serdes_addr, 0x0e, (0x8000 | ( 4 << 8)));  /* Set phase slip for hosts */
        avago_spico_int(aapl, serdes_addr, 0x01, 0x0007);   /* Enable TX/RX/output */
    }

    for (addr = 0x05; addr <= 0x08; addr++)
    {
        serdes_addr = avago_make_addr3(prtad, 0, addr);
        avago_spico_int(aapl, serdes_addr, 0x01, 0x0000);   /* Disable TX/RX/output */
        avago_spico_int(aapl, serdes_addr, 0x11, 0x0003);   /* Set recal bits on TX/RX */
        avago_spico_int(aapl, serdes_addr, 0x05, 0x90a5);   /* Set div ratio of 160 on 25G mod slices */
        avago_spico_int(aapl, serdes_addr, 0x14, 0x0033);   /* Set 40 bit mode on mods */
        avago_spico_int(aapl, serdes_addr, 0x0e, (0x8000 | ( 25 << 8)));  /* Set phase slip for 25G mods */
        avago_spico_int(aapl, serdes_addr, 0x01, 0x0007);   /* Enable TX/RX/output */
    }

    avago_spico_int(aapl, slice_0xb, 0x01, 0x0000);   /* Disable TX/RX/output */
    avago_spico_int(aapl, slice_0xb, 0x11, 0x0003);   /* Set recal bits on TX/RX */
    avago_spico_int(aapl, slice_0xb, 0x05, 0x1032);   /* Set div ratio of 50 on mod7 TX */
    avago_spico_int(aapl, slice_0xb, 0x14, 0x0011);   /* Set 20 bit mode on mod7 */
    avago_spico_int(aapl, slice_0xb, 0x01, 0x0001);   /* Enable TX/RX/output */

    /* Run this to force wait on TX ready... */
    avago_serdes_set_tx_rx_enable(aapl, slice_0xb, TRUE, FALSE, FALSE);  /* Enable TX */
    for( addr = 0x18; addr <= 0x21; addr++ )
        avago_serdes_set_tx_rx_enable(aapl, avago_make_addr3(prtad, 0, addr), TRUE, TRUE, TRUE);
    for( addr = 5; addr <= 8; addr++ )
        avago_serdes_set_tx_rx_enable(aapl, avago_make_addr3(prtad, 0, addr), TRUE, TRUE, TRUE);


    avsp_9104_fec_control_logic_reset_direct(aapl, prtad); /* Setup the clock paths before switching to recovered clocks */

/*#if 0 */
    for (addr = 0x18; addr <= 0x21; addr++)
    {
        serdes_addr = avago_make_addr3(prtad, 0, addr);
        avago_spico_int(aapl, serdes_addr, 0x11, 0x0000);   /* Clear recal bits on TX/RX */
        avago_spico_int(aapl, serdes_addr, 0x05, 0x1010);   /* Set div ratio of 16 on host TXs */
        avago_spico_int(aapl, serdes_addr, 0x30, 0x0070);   /* Set TX PLL to pcie_core clock input */
        avago_spico_int(aapl, serdes_addr, 0x01, 0x0005);   /* RX toggling */
        avago_spico_int(aapl, serdes_addr, 0x01, 0x0007);   /* RX toggling */
    }

    for (addr = 0x05; addr <= 0x08; addr++)
    {
        serdes_addr = avago_make_addr3(prtad, 0, addr);
        avago_spico_int(aapl, serdes_addr, 0x11, 0x0000);   /* Clear recal bits on TX/RX */
        /* Skip this step for pcs fifo clk selection (div66 is pcs clock so we still want 165) */
        /*avago_spico_int(aapl, serdes_addr, 0x05, 0x1032);   // Set div ratio of 50 on mod TXs */
        avago_spico_int(aapl, serdes_addr, 0x30, 0x0070);   /* Set TX PLL to pcie_core clock input */
        avago_spico_int(aapl, serdes_addr, 0x01, 0x0005);   /* RX toggling */
        avago_spico_int(aapl, serdes_addr, 0x01, 0x0007);   /* RX toggling */
    }

    avago_spico_int(aapl, slice_0xb, 0x11, 0x0000);   /* Clear recal bits on TX/RX */
    avago_spico_int(aapl, slice_0xb, 0x30, 0x0070);   /* Set TX PLL to pcie_core clock input */
/*#endif */


    /* Configure mod_o_rx_pcs_fifo_clock to div66: */
    for (addr = 0x5; addr<=0x8; addr++) /* For each 25G SerDes: */
    {
        uint serdes_addr = avago_make_addr3(prtad, 0, addr);
        /*avago_spico_int(aapl, serdes_addr, 0x18, 0x4073);   // Select ESB register 0x73 (RXDIV_MISC2_CTL) */
        /*avago_spico_int(aapl, serdes_addr, 0x19, 0x0e61);   // Set MODE66, DIVX_IN_CNTL_S2=3, div468_override=3, div468_override_sel=1) */
        /*avago_serdes_mem_rmw(aapl, serdes_addr, AVAGO_ESB, 0x73, 0x0e01, 0xff1f); */
        avago_serdes_mem_rmw(aapl, serdes_addr, AVAGO_ESB, 0x73, 0x0e01, 0x0e01);
        avago_spico_int(aapl, serdes_addr, 0x0c, 0x0300);   /* Enable direct ESB bit slip, enable F66 autoslip */
    }

    /* Set ILB for our checks (and we leave it on currently) */
    for( addr = 5; addr <= 8; addr++ )
    {
        avago_spico_int(aapl, addr, 0x08, 0x0301);  /* Set internal loopback */
    }

    /* reset all sync fifos after SerDes are ready */
    avsp_9104_fec_control_logic_reset_host_to_mod_direct(aapl, prtad);
    avsp_9104_fec_control_logic_reset_mod_to_host_direct(aapl, prtad);

    /* Run phase cal on 25G slices */
    for( addr = 5; addr <= 8; addr++ )
    {
        avago_spico_int(aapl, addr, 0x0b, 0x0001);  /* Run phase calibration */
    }

    /* Reset the HOST path */
    avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000001); /* Set RS_HOST_RESET */
    avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000000); /* Clear RS_HOST_RESET */

}

#if 0
static void avsp_9104_rs_fec_init(Aapl_t *aapl, uint prtad)
{
    int addr;
    uint all_serdes = avago_make_serdes_broadcast_addr(avago_make_addr3(prtad, 0, 0));
    uint all_host   = avago_make_addr3(prtad, 0, 0xca);
    uint all_mod25  = avago_make_addr3(prtad, 0, 0xcb);
    uint slice_0xb  = avago_make_addr3(prtad, 0, 0x0b);

    /* Reset and initialize all slices in a default mode */
    avago_sbus_wr(aapl, all_serdes, 0x07, 0x00000011); /* Reset all the slices */
    avago_sbus_wr(aapl, all_serdes, 0x07, 0x00000010); /* Clear the resets */
    avago_sbus_wr(aapl, all_serdes, 0x07, 0x00000012); /* Re-enable SPICO in all slices */

    /* Configure the SerDes devices for Gearbox RS-FEC mode: */
    avago_sbus_wr(aapl, all_serdes, 0x03, 0x00010000); /* Set TX/RX/Output OFF */
    avago_sbus_wr(aapl, all_serdes, 0x03, 0x00110003); /* Set recal bits on TX and RX */

    avago_sbus_wr(aapl, all_host,   0x03, 0x00059042); /* Set div ratio of 66 on RX host slices */
    avago_sbus_wr(aapl, all_host,   0x03, 0x00140011); /* Set 20 bit mode on host */

    avago_sbus_wr(aapl, all_mod25,  0x03, 0x000590a5); /* Set div ratio of 165 on RX mod slices */
    avago_sbus_wr(aapl, all_mod25,  0x03, 0x00140033); /* Set 40 bit mode on mod */

    avago_sbus_wr(aapl, slice_0xb,  0x03, 0x00051032); /* Set div ratio of 50 on mod7 TX (used by FEC's clocking scheme) */
    avago_sbus_wr(aapl, slice_0xb,  0x03, 0x00140011); /* Set 20 bit mode on mod7 */

    if( aapl_get_jtag_idcode(aapl, prtad) == 0x0975457f )  /* Rev 1 */
    {
        avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1e), 0x03, 0x000e8000 | (5<<8)); /* Set appropriate RX phase slip on each slice, H10G0 */
        avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1d), 0x03, 0x000e8000 | (5<<8)); /* Set appropriate RX phase slip on each slice, H10G1 */
        avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1c), 0x03, 0x000e8000 | (8<<8)); /* Set appropriate RX phase slip on each slice, H10G2 */
        avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1b), 0x03, 0x000e8000 | (3<<8)); /* Set appropriate RX phase slip on each slice, H10G3 */
        avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x20), 0x03, 0x000e8000 | (6<<8)); /* Set appropriate RX phase slip on each slice, H10G4 */
        avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1a), 0x03, 0x000e8000 | (5<<8)); /* Set appropriate RX phase slip on each slice, H10G5 */
        avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x18), 0x03, 0x000e8000 | (8<<8)); /* Set appropriate RX phase slip on each slice, H10G6 */
        avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x21), 0x03, 0x000e8000 | (6<<8)); /* Set appropriate RX phase slip on each slice, H10G7 */
        avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x19), 0x03, 0x000e8000 | (5<<8)); /* Set appropriate RX phase slip on each slice, H10G8 */
        avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1f), 0x03, 0x000e8000 | (9<<8)); /* Set appropriate RX phase slip on each slice, H10G9 */

        avago_sbus_wr(aapl, all_mod25,  0x03, 0x000e8a00); /* Set appropriate RX phase slip on each M25G slice */
    }
    else    /* Rev 2, aka production */
    {
        avago_sbus_wr(aapl, all_host,   0x03, 0x000e8000 | ( 4 << 8)); /* Set appropriate RX phase slip on each host slice */
        avago_sbus_wr(aapl, all_mod25,  0x03, 0x000e8000 | (25 << 8)); /* Set appropriate RX phase slip on each M25G slice */
    }

    avago_sbus_wr(aapl, all_mod25, 0x03, 0x00010007); /* Enable RX, TX and TX output */
    avago_sbus_wr(aapl, all_host,  0x03, 0x00010007); /* Enable RX, TX and TX output */

    /* Run this to force wait on TX ready... */
    avago_serdes_set_tx_rx_enable(aapl, slice_0xb, TRUE, FALSE, FALSE);  /* Enable TX */
    for( addr = 0x18; addr <= 0x21; addr++ )
        avago_serdes_set_tx_rx_enable(aapl, avago_make_addr3(prtad, 0, addr), TRUE, TRUE, TRUE);
    for( addr = 5; addr <= 8; addr++ )
        avago_serdes_set_tx_rx_enable(aapl, avago_make_addr3(prtad, 0, addr), TRUE, TRUE, TRUE);

    avago_sbus_wr(aapl, all_host,  0x03, 0x00052010); /* Set div ratio of 16 on TX host slices, no recal */
    avago_sbus_wr(aapl, all_mod25, 0x03, 0x00052032); /* Set div ratio of 50 on TX mod slices, no recal */

    avago_sbus_wr(aapl, all_serdes, 0x03, 0x00300070); /* Set clocks (F66, refclk, Tx PLL from pcie_core_clk) */

    /* Configure mod_o_rx_pcs_fifo_clock to div66: */
    for (addr = 0x5; addr<=0x8; addr++) /* For each 25G SerDes: */
    {
        uint serdes_addr = avago_make_addr3(prtad, 0, addr);
        avago_spico_int(aapl, serdes_addr, 0x18, 0x4073);   /* Select ESB register 0x73 (RXDIV_MISC2_CTL) */
        avago_spico_int(aapl, serdes_addr, 0x19, 0x0e61);   /* Set MODE66, DIVX_IN_CNTL_S2=3, div468_override=3, div468_override_sel=1) */
        avago_spico_int(aapl, serdes_addr, 0x0c, 0x0300);   /* Enable direct ESB bit slip, enable F66 autoslip */
    }
}
#endif

/** @brief  Reset the FEC control logic in the host to mod direction by */
/**         directly writing to the IP. */
/** @return Always returns TRUE. */
BOOL avsp_9104_fec_control_logic_reset_host_to_mod_direct(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint prtad)     /**< [in] The port address of the device to read. */
{
    uint ctl_logic = avago_make_addr3(prtad, 0, 0x2c);
    int reg;
    for (reg = 20; reg <= 39; reg += 2)     /* For each Host slice: */
        avago_sbus_wr(aapl, ctl_logic, reg, 0x2e); /* Reset sync gearfifo, repeater data, select sync_gf_rx_out, reset phase beacon, turn off pcie_clk_in */
    return TRUE;
}

/** @brief  Reset the FEC control logic in the mod to host direction by */
/**         directly writing to the IP. */
/** @return Always returns TRUE. */
BOOL avsp_9104_fec_control_logic_reset_mod_to_host_direct(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint prtad)     /**< [in] The port address of the device to read. */
{
    uint ctl_logic = avago_make_addr3(prtad, 0, 0x2c);
    int reg;

    for (reg = 40; reg <= 47; reg += 2)     /* For each M25G slice: */
    {
        /*avago_sbus_wr(aapl, ctl_logic, reg, 0x25);     // Reset sync gearfifo, repeater data, reset phase_beacon, select common rx_fifo_clk for M25Gs */
        avago_sbus_wr(aapl, ctl_logic, reg, 0x26);     /* Reset sync gearfifo, repeater data, reset phase_beacon, select pcs_fifo_clk for M25Gs */
    }
    return TRUE;
}


/** @brief  Reset the FEC control logic by directly writing to the IP. */
/** @return Always returns TRUE. */
BOOL avsp_9104_fec_control_logic_reset_direct(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint prtad)     /**< [in] The port address of the device to read. */
{
    uint ctl_logic = avago_make_addr3(prtad, 0, 0x2c);
    uint all_mod25  = avago_make_addr3(prtad, 0, 0xcb);

    /* Configure 9104 Control Logic for Gearbox RS-FEC mode: */
    avago_sbus_wr(aapl, ctl_logic, 0x96, 0x000000a1); /* Set OPMODE to RSFEC, bit slip wait time to 0xa. */
    avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000003); /* Set RS_HOST_RESET and RS_MOD_RESET */

    avago_sbus_wr(aapl, ctl_logic, 0x36, 0x00000002); /* Configure Mod7: pcie_clk_in to common host recovered clock */
    avago_sbus_wr(aapl, ctl_logic, 0x0a, 0x00000800); /* Set up clock routing (COMMON_CLOCK_SELECTS) */

    avsp_9104_fec_control_logic_reset_host_to_mod_direct(aapl, prtad);

    avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000002); /* Release the host reset (keep mod reset) */

    avsp_9104_fec_control_logic_reset_mod_to_host_direct(aapl, prtad);

    avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000000); /* Clear the reset */

    avago_sbus_wr(aapl, all_mod25, 0x03, 0x000b0000); /* Tx Phase Cal off */
    avago_sbus_wr(aapl, all_mod25, 0x03, 0x000b0001); /* Tx Phase Cal on */
    avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000003); /* Reset rs_host and rs_mod */
    avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000000); /* Clear resets */
    return TRUE;
}

/** @brief  Attempt to sync up the FEC lanes. */
/** @return TRUE on success, FALSE on failure. */
static BOOL avsp_9104_fec_slip(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint prtad)     /**< [in] The port address of the device to read. */
{
    uint slice_0x1b   = avago_make_addr3(prtad, 0, 0x1b);
    uint slice_0x1c   = avago_make_addr3(prtad, 0, 0x1c);
    uint slice_0x1d   = avago_make_addr3(prtad, 0, 0x1d);
    uint slice_0x1e   = avago_make_addr3(prtad, 0, 0x1e);
    uint pcs_block_lock = avsp_9104_get_status(aapl, prtad, AVSP_PCS_BLOCK_LOCK, 0, 0);
    uint pcs_lane_align = avsp_9104_get_status(aapl, prtad, AVSP_PCS_LANE_ALIGNMENT, 0, 0);
    uint fec_lane_align = avsp_9104_get_status(aapl, prtad, AVSP_FEC_LANE_ALIGNMENT, 0, 0);
    if( 0xfffff == pcs_block_lock &&
        0xfffff == pcs_lane_align &&
        0x0000f == fec_lane_align )
    {
        int retry;
        int verbose_prev = aapl->verbose;

        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Alignment OK\n");

        for (retry = 0; retry <= 10; retry++)
        {
            int lock, errors, prev_errors;
            aapl->verbose = 0;  /* Insure that get_status(ALL) doesn't do verbose stuff... */
            prev_errors = avsp_9104_get_status(aapl, prtad, AVSP_ALL_ERRORS, 0, 0);
            ms_sleep(2);
            errors = avsp_9104_get_status(aapl, prtad, AVSP_ALL_ERRORS, 0, 0);
            lock = avsp_9104_get_status(aapl, prtad, AVSP_FEC_LANE_ALIGNMENT, 0, 0);
#if 0
            if( errors == prev_errors && lock == 0xf ) /* If stable, wait a bit longer to be sure... */
            {
                ms_sleep(8);
                errors = avsp_9104_get_status(aapl, prtad, AVSP_ALL_ERRORS, 0, 0);
                lock = avsp_9104_get_status(aapl, prtad, AVSP_FEC_LANE_ALIGNMENT, 0, 0);
            }
#endif
            aapl->verbose = verbose_prev;
            aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Lock 0x%x; Errors %d; Change %d\n", lock, errors, errors-prev_errors);

            if (errors == prev_errors && lock == 0xf)
            {
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Lock after %d slips\n", retry);
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Slip once more to sweet spot\n");
                avago_serdes_mem_rmw(aapl, slice_0x1b, AVAGO_ESB, 0x71, 0x0000, 0x2000);
                avago_serdes_mem_rmw(aapl, slice_0x1b, AVAGO_ESB, 0x71, 0x2000, 0x2000);
                avago_serdes_mem_rmw(aapl, slice_0x1c, AVAGO_ESB, 0x71, 0x0000, 0x2000);
                avago_serdes_mem_rmw(aapl, slice_0x1c, AVAGO_ESB, 0x71, 0x2000, 0x2000);
                avago_serdes_mem_rmw(aapl, slice_0x1d, AVAGO_ESB, 0x71, 0x0000, 0x2000);
                avago_serdes_mem_rmw(aapl, slice_0x1d, AVAGO_ESB, 0x71, 0x2000, 0x2000);
                avago_serdes_mem_rmw(aapl, slice_0x1e, AVAGO_ESB, 0x71, 0x0000, 0x2000);
                avago_serdes_mem_rmw(aapl, slice_0x1e, AVAGO_ESB, 0x71, 0x2000, 0x2000);
                return TRUE;
            }

/* Restating sets the phase relationship which stays constant during these loops */
/* The only places I saw the trickle of errors was bit slipping H10G0 */

/* phase slips sometimes work (they do cause reset afterall) */
            /*avago_spico_int(aapl, slice_0x21, 0x0e, 0x0100);  // Slip just the slice of interest */
            /*avago_sbus_wr(aapl, all_host, 0x03, 0x000e0100);   // Slip Rx phase one bit */
/* Resetting the host also sometimes works (takes a bunch and sometimes a re-state) */
            /*avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000001); // Set RS_HOST_RESET */
            /*avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000000); // Clear RS_HOST_RESET */
/* Bit slips did turn up the trickle on lane id 17 effect (on H10G0 anyway) */
            /*avago_spico_int(aapl, slice_0x21, 0x0c, 0x0001);  // Bit slip common source */
            /*avago_spico_int(aapl, 0x1e, 0x0c, 0x0001);  // Bit slip H10G0 */
/* Disabling the M10G7 TX adjusts the phase relationship (randomizes it) and this also works */
            /*avago_spico_int(aapl, 0x0b, 0x01, 0x0006);  // Disable TX PLL on M10G7 */
            /*avago_spico_int(aapl, 0x0b, 0x01, 0x0007);  // Re-enable TX PLL on M10G7 */
              
            avago_serdes_mem_rmw(aapl, slice_0x1b, AVAGO_ESB, 0x71, 0x0000, 0x2000);
            avago_serdes_mem_rmw(aapl, slice_0x1b, AVAGO_ESB, 0x71, 0x2000, 0x2000);
            avago_serdes_mem_rmw(aapl, slice_0x1c, AVAGO_ESB, 0x71, 0x0000, 0x2000);
            avago_serdes_mem_rmw(aapl, slice_0x1c, AVAGO_ESB, 0x71, 0x2000, 0x2000);
            avago_serdes_mem_rmw(aapl, slice_0x1d, AVAGO_ESB, 0x71, 0x0000, 0x2000);
            avago_serdes_mem_rmw(aapl, slice_0x1d, AVAGO_ESB, 0x71, 0x2000, 0x2000);
            avago_serdes_mem_rmw(aapl, slice_0x1e, AVAGO_ESB, 0x71, 0x0000, 0x2000);
            avago_serdes_mem_rmw(aapl, slice_0x1e, AVAGO_ESB, 0x71, 0x2000, 0x2000);
        }
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "No lock after %d slips\n", retry - 1);
    }
    return FALSE;
}

/** @cond INTERNAL */

/** @brief  Reset the MLG control logic in the host to mod direction */
/**         by directly writing to the IP. */
/** @return Always returns TRUE. */
BOOL avsp_9104_mlg_control_logic_reset_host_to_mod_direct(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint prtad)     /**< [in] The port address of the device to read. */
{
    uint ctl_logic = avago_make_addr3(prtad, 0, 0x2c);
    int reg;
    for (reg = 20; reg <= 39; reg += 2)     /* For each Host slice: */
        avago_sbus_wr(aapl, ctl_logic, reg, 0x24); /* Reset beacon and gearfifo pointers */
    return TRUE;
}

/** @brief  Reset the MLG control logic in the mod to host direction */
/**         by directly writing to the IP. */
/** @return Always returns TRUE. */
BOOL avsp_9104_mlg_control_logic_reset_mod_to_host_direct(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint prtad)     /**< [in] The port address of the device to read. */
{
    uint ctl_logic = avago_make_addr3(prtad, 0, 0x2c);
    int reg;

    for (reg = 40; reg <= 47; reg += 2)     /* For each M25G slice: */
    {
        avago_sbus_wr(aapl, ctl_logic, reg, 0x24); /* Reset beacon and gearfifo pointers */
    }
    return TRUE;
}

#if 0
BOOL avsp_9104_mlg_control_logic_reset_direct(Aapl_t *aapl, int prtad)
{
    uint ctl_logic = avago_make_addr3(prtad, 0, 0x2c);
    uint all_mod25  = avago_make_addr3(prtad, 0, 0xcb);


    avago_sbus_rmw(aapl, ctl_logic, 0x0a, 0x0000, 0x1c00); /* Select M10G pcs clock */
    avago_sbus_rmw(aapl, ctl_logic, 0x90, 0x0002, 0x000e); /* Select M25G refclk */
    avago_sbus_rmw(aapl, ctl_logic, 0x96, 0x0004, 0x000f); /* Set OPMODE bits */
    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0003, 0x0003); /* RMW Host and Mod reset bits */
    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0000, 0x0001); /* Clear the host reset */
    avago_sbus_rmw(aapl, ctl_logic, 0xbc, 0x0001, 0x0001); /* Set MOD_TX_BEACON_ENABLE */

    /* Phase cal 25G here? */
      
    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0001, 0x0001); /* Set the host reset */
    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0000, 0x0001); /* Clear the host reset */
    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0000, 0x0002); /* Clear the mod reset */
    avago_sbus_rmw(aapl, ctl_logic, 0xb3, 0x0001, 0x0001); /* Set HOST_TX_BEACON_ENABLE */
    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0003, 0x0003); /* RMW Host and Mod reset bits */
    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0000, 0x0001); /* Clear the host reset */
    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0000, 0x0002); /* Clear the mod reset */


    avago_sbus_wr(aapl, ctl_logic, 0x96, 0x000000a1); /* Set OPMODE to RSFEC, bit slip wait time to 0xa. */
    avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000003); /* Set RS_HOST_RESET and RS_MOD_RESET */

    avago_sbus_wr(aapl, ctl_logic, 0x36, 0x00000002); /* Configure Mod7: pcie_clk_in to common host recovered clock */
    avago_sbus_wr(aapl, ctl_logic, 0x0a, 0x00000800); /* Set up clock routing (COMMON_CLOCK_SELECTS) */


    avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000002); /* Release the host reset (keep mod reset) */


    avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000000); /* Clear the reset */

    avago_sbus_wr(aapl, all_mod25, 0x03, 0x000b0000); /* Tx Phase Cal off */
    avago_sbus_wr(aapl, all_mod25, 0x03, 0x000b0001); /* Tx Phase Cal on */
    avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000003); /* Reset rs_host and rs_mod */
    avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000000); /* Clear resets */
    return TRUE;
}
#endif


/** @brief  Reset the MLG control logic in the mod to host direction */
/**         by directly writing to the IP. */
/** @return Always returns TRUE. */
void avsp_9104_mlg_state(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint prtad)     /**< [in] The port address of the device to read. */
{
    int addr;
    uint slice_0xb  = avago_make_addr3(prtad, 0, 0x0b);
    uint slice_0xa  = avago_make_addr3(prtad, 0, 0x0a);
    uint serdes_addr;
    uint ctl_logic = avago_make_addr3(prtad, 0, 0x2c);


    /* Reset and initialize all slices in a default mode */
    for( addr = 0x18; addr <= 0x21; addr++ )
        avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, addr), 0x07, 0x00000011); /* Reset the slice */
    for( addr = 5; addr <= 8; addr++ )
        avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, addr), 0x07, 0x00000011); /* Reset the slice */
    avago_sbus_wr(aapl, slice_0xa, 0x07, 0x00000011); /* Reset the slice */
    avago_sbus_wr(aapl, slice_0xb, 0x07, 0x00000011); /* Reset the slice */

    for( addr = 0x18; addr <= 0x21; addr++ )
    {
        serdes_addr = avago_make_addr3(prtad, 0, addr);
        avago_sbus_wr(aapl, serdes_addr, 0x07, 0x00000010); /* Clear the reset */
        avago_sbus_wr(aapl, serdes_addr, 0x07, 0x00000012); /* Re-enable SPICO */
    }

    for( addr = 5; addr <= 8; addr++ )
    {
        serdes_addr = avago_make_addr3(prtad, 0, addr);
        avago_sbus_wr(aapl, serdes_addr, 0x07, 0x00000010); /* Clear the reset */
        avago_sbus_wr(aapl, serdes_addr, 0x07, 0x00000012); /* Re-enable SPICO */
    }
    avago_sbus_wr(aapl, slice_0xa, 0x07, 0x00000010); /* Clear the reset */
    avago_sbus_wr(aapl, slice_0xa, 0x07, 0x00000012); /* Re-enable SPICO */
    avago_sbus_wr(aapl, slice_0xb, 0x07, 0x00000010); /* Clear the reset */
    avago_sbus_wr(aapl, slice_0xb, 0x07, 0x00000012); /* Re-enable SPICO */

    for (addr = 0x18; addr <= 0x21; addr++)
    {
        serdes_addr = avago_make_addr3(prtad, 0, addr);
        avago_spico_int(aapl, serdes_addr, 0x01, 0x0000);   /* Disable TX/RX/output */
        avago_spico_int(aapl, serdes_addr, 0x0c, 0x0300);   /* Enable fast slips from core */
        avago_spico_int(aapl, serdes_addr, 0x11, 0x0003);   /* Set recal bits on TX/RX */
        avago_spico_int(aapl, serdes_addr, 0x05, 0x9042);   /* Set div ratio of 64 on host slices */
        avago_spico_int(aapl, serdes_addr, 0x14, 0x0011);   /* Set 20 bit mode on hosts */
        avago_spico_int(aapl, serdes_addr, 0x0e, (0x8000 | ( 12 << 8)));  /* Set phase slip for hosts */
        avago_spico_int(aapl, serdes_addr, 0x01, 0x0007);   /* Enable TX/RX/output */
    }

    for( addr = 0x18; addr <= 0x21; addr++ )
        avago_serdes_set_tx_rx_enable(aapl, avago_make_addr3(prtad, 0, addr), TRUE, TRUE, TRUE);

    for (addr = 0x05; addr <= 0x08; addr++)
    {
        serdes_addr = avago_make_addr3(prtad, 0, addr);
        avago_spico_int(aapl, serdes_addr, 0x01, 0x0000);   /* Disable TX/RX/output */
        avago_spico_int(aapl, serdes_addr, 0x0c, 0x0300);   /* Enable fast slips from core */
        avago_spico_int(aapl, serdes_addr, 0x11, 0x0003);   /* Set recal bits on TX/RX */
        avago_spico_int(aapl, serdes_addr, 0x05, 0x90a5);   /* Set div ratio of 160 on 25G mod slices */
        avago_spico_int(aapl, serdes_addr, 0x14, 0x0033);   /* Set 40 bit mode on mods */
        avago_spico_int(aapl, serdes_addr, 0x0e, (0x8000 | ( 16 << 8)));  /* Set phase slip for 25G mods */
        avago_spico_int(aapl, serdes_addr, 0x01, 0x0007);   /* Enable TX/RX/output */
    }

    for( addr = 5; addr <= 8; addr++ )
        avago_serdes_set_tx_rx_enable(aapl, avago_make_addr3(prtad, 0, addr), TRUE, TRUE, TRUE);

    avago_spico_int(aapl, slice_0xa, 0x01, 0x0000);   /* Disable TX/RX/output */
    avago_spico_int(aapl, slice_0xa, 0x11, 0x0003);   /* Set recal bits on TX/RX */
    avago_spico_int(aapl, slice_0xa, 0x05, 0x9032);   /* Set div ratio of 50 on mod4 TX */
    avago_spico_int(aapl, slice_0xa, 0x14, 0x0011);   /* Set 20 bit mode on mod4 */
    avago_spico_int(aapl, slice_0xa, 0x01, 0x0007);   /* Enable TX/RX/output */
    avago_serdes_set_tx_rx_enable(aapl, slice_0xa, TRUE, TRUE, TRUE);
    avago_spico_int(aapl, slice_0xa, 0x08, 0x0301);   /* Set ILB */
    avago_spico_int(aapl, slice_0xa, 0x02, 0x0125);   /* Set PRBS31 on the TX */
    avago_spico_int(aapl, slice_0xa, 0x02, 0x0235);   /* Set PRBS31 on the RX checker (so no errors are showing) */
    avago_spico_int(aapl, slice_0xa, 0x03, 0x0203);   /* Set error counter to M^P and reset it */

    avago_spico_int(aapl, slice_0xb, 0x01, 0x0000);   /* Disable TX/RX/output */
    avago_spico_int(aapl, slice_0xb, 0x11, 0x0003);   /* Set recal bits on TX/RX */
    avago_spico_int(aapl, slice_0xb, 0x05, 0x9042);   /* Set div ratio of 66 on mod7 TX */
    avago_spico_int(aapl, slice_0xb, 0x14, 0x0011);   /* Set 20 bit mode on mod7 */
    avago_spico_int(aapl, slice_0xb, 0x01, 0x0007);   /* Enable TX/RX/output */
    avago_serdes_set_tx_rx_enable(aapl, slice_0xb, TRUE, TRUE, TRUE);
    avago_spico_int(aapl, slice_0xb, 0x08, 0x0301);   /* Set ILB */
    avago_spico_int(aapl, slice_0xb, 0x02, 0x0125);   /* Set PRBS31 on the TX */
    avago_spico_int(aapl, slice_0xb, 0x02, 0x0235);   /* Set PRBS31 on the RX checker (so no errors are showing) */
    avago_spico_int(aapl, slice_0xb, 0x03, 0x0203);   /* Set error counter to M^P and reset it */

    /* Configure mod_o_rx_pcs_fifo_clock to div66: */
    for (addr = 0x5; addr<=0x8; addr++) /* For each 25G SerDes: */
    {
        uint serdes_addr = avago_make_addr3(prtad, 0, addr);
        avago_serdes_mem_rmw(aapl, serdes_addr, AVAGO_ESB, 0x73, 0x0e00, 0x0e00);
    }

    /* Set ILB for our checks (and we leave it on currently) */
    for( addr = 5; addr <= 8; addr++ )
    {
        avago_spico_int(aapl, addr, 0x08, 0x0301);  /* Set internal loopback */
    }

    /* reset all sync fifos after SerDes are ready */
    avsp_9104_mlg_control_logic_reset_host_to_mod_direct(aapl, prtad);
    avsp_9104_mlg_control_logic_reset_mod_to_host_direct(aapl, prtad);

    /* Configure 9104 Control Logic for MLG mode: */
    avago_sbus_rmw(aapl, ctl_logic, 0x0a, 0x0000, 0x1c00); /* Set SEL_M10G_PCS_CLK bits [12:10] to zero (M10G7) */
    avago_sbus_rmw(aapl, ctl_logic, 0x90, 0x0002, 0x000e); /* Set SEL_M25G_REF_CLK bits [3:1] to one (M10G4) */
    avago_sbus_rmw(aapl, ctl_logic, 0x96, 0x0004, 0x000f); /* Set OPMODE bits */
    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0003, 0x0003); /* RMW Host and Mod reset bits */
    ms_sleep(1);                                           /* Hold reset for a bit */
    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0000, 0x0001); /* Clear the host reset */
    ms_sleep(1);                                           /* Wait for host lock (could poll on bits) */
    avago_sbus_rmw(aapl, ctl_logic, 0xbc, 0x0001, 0x0001); /* Set MOD_TX_BEACON_ENABLE */

    /* Run the beacon alignment on the 25G slices */
    for( addr = 5; addr <= 8; addr++ )
    {
        avago_spico_int(aapl, addr, 0x0b, 0x0001);  /* Do TX phase beacon optimization */
    }

    /* Wait for ready after beacon */
    for( addr = 5; addr <= 8; addr++ )
    {
        avago_serdes_set_tx_rx_enable(aapl, avago_make_addr3(prtad, 0, addr), TRUE, TRUE, TRUE);
    }

    /* Reset the host-to-mod path again */
    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0001, 0x0001); /* Set the host reset */
    ms_sleep(1);                                           /* Hold reset for a bit */
    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0000, 0x0001); /* Clear the host reset */
    ms_sleep(1);                                           /* Wait for host lock (could poll on bits) */
    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0000, 0x0002); /* Clear the mod reset */
    ms_sleep(1);                                           /* Wait for mod lock (could poll on bits) */
    avago_sbus_rmw(aapl, ctl_logic, 0xb3, 0x0001, 0x0001); /* Set HOST_TX_BEACON_ENABLE */

    /* Run the beacon alignment on the host slices */
    for (addr = 0x18; addr <= 0x21; addr++)
    {
        avago_spico_int(aapl, addr, 0x0b, 0x0001);  /* Do TX phase beacon optimization */
    }

    /* Wait for ready after beacon */
    for (addr = 0x18; addr <= 0x21; addr++)
    {
        avago_serdes_set_tx_rx_enable(aapl, avago_make_addr3(prtad, 0, addr), TRUE, TRUE, TRUE);
    }

    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0003, 0x0003); /* RMW Host and Mod reset bits */
    ms_sleep(1);                                           /* Hold reset for a bit */
    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0000, 0x0001); /* Clear the host reset */
    ms_sleep(1);                                           /* Wait for host lock (could poll on bits) */
    avago_sbus_rmw(aapl, ctl_logic, 0x97, 0x0000, 0x0002); /* Clear the mod reset */
    ms_sleep(1);                                           /* Wait for mod lock (could poll on bits) */

    /*exit(0); */
}

/** @brief  State the device into RS-FEC mode. */
void avsp_9104_rs_fec_state(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint prtad)     /**< [in] The port address of the device to read. */
{
    uint ctl_logic = avago_make_addr3(prtad, 0, 0x2c);
    /*avsp_9104_setup_broadcast(aapl, prtad); */

#if 1
    int loop = 0;

    for( loop = 0; loop < 10; loop++ )
    {

        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "LOOP %d\n", loop);

        avsp_9104_rs_fec_init(aapl, prtad); /* Set up SerDes */

        /*if( TRUE ) */
        if( avsp_9104_fec_slip(aapl, prtad) )
        {
            if( aapl->verbose )
            {
                avsp_9104_get_status(aapl, prtad, AVSP_ALL_ERRORS, 0, 0);
                aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "0xa3=%08x; 0xa8=%08x\n",
                    avago_sbus_rd(aapl, ctl_logic, 0xa3),
                    avago_sbus_rd(aapl, ctl_logic, 0xa8));
            }
            return;
        }
    }
    
    aapl_fail(aapl,__func__,__LINE__,"FAILED TO INITIALIZE\n");
    return;

#else

    for( loop = 0; loop < 10; loop++ )
    {
        int reg;
        int lock;
        int addr;
        uint all_serdes = avago_make_serdes_broadcast_addr(avago_make_addr3(prtad, 0, 0));
        uint all_host   = avago_make_addr3(prtad, 0, 0xca);
        uint all_mod25  = avago_make_addr3(prtad, 0, 0xcb);
        uint slice_0xb  = avago_make_addr3(prtad, 0, 0x0b);

printf("Loop %d\n",loop);

        /* Reset and initialize all slices in a defaultish mode */
        avago_sbus_wr(aapl, all_serdes, 0x07, 0x00000011); /* Reset all the slices */
        avago_sbus_wr(aapl, all_serdes, 0x07, 0x00000010); /* Clear the resets */
        avago_sbus_wr(aapl, all_serdes, 0x07, 0x00000012); /* Re-enable SPICO in all slices */

        /* Configure the SerDes devices for Gearbox RS-FEC mode: */
        avago_sbus_wr(aapl, all_serdes, 0x03, 0x00010000); /* Set TX/RX/Output OFF */
        avago_sbus_wr(aapl, all_serdes, 0x03, 0x00110003); /* Set recal bits on TX and RX */

        avago_sbus_wr(aapl, all_host,   0x03, 0x00140011); /* Set 20 bit mode on host */
        avago_sbus_wr(aapl, all_host,   0x03, 0x00059042); /* Set div ratio of 66 on TX and RX for host */

        avago_sbus_wr(aapl, all_mod25,  0x03, 0x00140033); /* Set 40 bit mode on mod */
        avago_sbus_wr(aapl, all_mod25,  0x03, 0x000590a5); /* Set div ratio of 165 on TX and RX for mod */

        avago_sbus_wr(aapl, slice_0xb,  0x03, 0x00140011); /* Set 20 bit mode on mod7 */
        avago_sbus_wr(aapl, slice_0xb,  0x03, 0x00051032); /* Set div ratio of 50 on mod7 Tx (used by FEC's clocking scheme) */

        if( aapl_get_jtag_idcode(aapl, prtad) == 0x0975457f )  /* Rev 1 */
        {
            avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1e), 0x03, 0x000e8000 | (5<<8)); /* Set appropriate RX phase slip on each slice, H10G0 */
            avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1d), 0x03, 0x000e8000 | (5<<8)); /* Set appropriate RX phase slip on each slice, H10G1 */
            avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1c), 0x03, 0x000e8000 | (8<<8)); /* Set appropriate RX phase slip on each slice, H10G2 */
            avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1b), 0x03, 0x000e8000 | (3<<8)); /* Set appropriate RX phase slip on each slice, H10G3 */
            avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x20), 0x03, 0x000e8000 | (6<<8)); /* Set appropriate RX phase slip on each slice, H10G4 */
            avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1a), 0x03, 0x000e8000 | (5<<8)); /* Set appropriate RX phase slip on each slice, H10G5 */
            avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x18), 0x03, 0x000e8000 | (8<<8)); /* Set appropriate RX phase slip on each slice, H10G6 */
            avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x21), 0x03, 0x000e8000 | (6<<8)); /* Set appropriate RX phase slip on each slice, H10G7 */
            avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x19), 0x03, 0x000e8000 | (5<<8)); /* Set appropriate RX phase slip on each slice, H10G8 */
            avago_sbus_wr(aapl, avago_make_addr3(prtad, 0, 0x1f), 0x03, 0x000e8000 | (9<<8)); /* Set appropriate RX phase slip on each slice, H10G9 */

            avago_sbus_wr(aapl, all_mod25,  0x03, 0x000e8a00); /* Set appropriate RX phase slip on each M25G slice */
        }
        else    /* Rev 2, aka production */
        {
            avago_sbus_wr(aapl, all_host,   0x03, 0x000e8000 | ( 4 << 8)); /* Set appropriate RX phase slip on each host slice */
            avago_sbus_wr(aapl, all_mod25,  0x03, 0x000e8000 | (25 << 8)); /* Set appropriate RX phase slip on each M25G slice */
        }

        avago_sbus_wr(aapl, all_serdes, 0x03, 0x00010007); /* Enable RX, TX and TX output */

        /* Configure mod_o_rx_pcs_fifo_clock to div66: */
        for (addr = 0x5; addr<=0x8; addr++) /* For each 25G SerDes: */
        {
            uint serdes_addr = avago_make_addr3(prtad, 0, addr);
            avago_spico_int(aapl, serdes_addr, 0x18, 0x4073);   /* Select ESB register 0x73 */
            avago_spico_int(aapl, serdes_addr, 0x1a, 0x0000);   /* Read value */
            avago_spico_int(aapl, serdes_addr, 0x18, 0x4073);   /* Select ESB register 0x73 (RXDIV_MISC2_CTL) */
            avago_spico_int(aapl, serdes_addr, 0x19, 0x0e61);   /* Set MODE66, DIVX_IN_CNTL_S2=3, div468_override=3, div468_override_sel=1) */
            avago_spico_int(aapl, serdes_addr, 0x18, 0x4073);   /* Select ESB register 0x73 */
            avago_spico_int(aapl, serdes_addr, 0x1a, 0x0000);   /* Read value */
            avago_spico_int(aapl, serdes_addr, 0x0c, 0x0300);   /* Enable direct ESB bit slip, enable F66 autoslip */
        }

        avago_sbus_wr(aapl, ctl_logic, 0x96, 0x000000a1); /* Set OPMODE to RSFEC, bit slip wait time to 0xa. */
        avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000003); /* Reset rs_host and rs_mod logic */

        for (reg = 20; reg <= 39; reg += 2)     /* For each Host slice: */
            avago_sbus_wr(aapl, ctl_logic, reg, 0x2e); /* Reset sync gearfifo, repeater data, select sync_gf_rx_out, reset phase beacon, turn off pcie_clk_ctl */

        for (reg = 40; reg <= 47; reg += 2)     /* For each M25G slice: */
            avago_sbus_wr(aapl, ctl_logic, reg, 0x25);     /* Reset sync gearfifo, repeater data, reset phase_beacon, select common pcs_fifo_clk for mlg */

        avago_sbus_wr(aapl, ctl_logic, 0x0a, 0x00000800); /* COMMON CLOCK SELECTS (set up clock routing) */
        avago_sbus_wr(aapl, ctl_logic, 0x36, 0x00000002); /* Configure Mod7: pcie_clk_in is off */
        avago_spico_int(aapl, slice_0xb, 0x030, 0x0070); /* Set clocks (F66, refclk, Tx PLL from pcie_core_clk) */

        avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000002); /* Release the host reset (keep mod reset) */

        /*# Wait for clocks to resolve */
        /*#sleep 1 */

        /* Set the dividers and clock forwarding for the 25G slices */
        /* Set ILB while we're at it */
        for (addr = 5; addr <= 8; addr ++)  /* For each M25G slice: */
        {
            uint serdes_addr = avago_make_addr3(prtad, 0, addr);
            avago_spico_int(aapl, serdes_addr, 0x05, 0x1032);  /* Set TX divider to 50, set REFCLK sync master */
            avago_spico_int(aapl, serdes_addr, 0x30, 0x0070);  /* Set clocks (F66, refclk, Tx PLL from pcie_core_clk) */
            avago_spico_int(aapl, serdes_addr, 0x08, 0x0301);  /* Set internal loopback */
        }

        /*# Wait for ready, could phase align here, but nervous about effects */
        /*#sleep 1 */

        avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000003); /* Reset the host and mod rs logic */
        /*sleep 0.1 */
        avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000000); /* Clear the reset */

        /*# Set the dividers and clock forwarding for the host slices */
        for (addr = 0x18; addr <= 0x21; addr ++)    /* For each host slice: */
        {
            uint host_serdes_addr = avago_make_addr3(prtad, 0, addr);
            avago_spico_int(aapl, host_serdes_addr, 0x05, 0x1010);  /* Set Tx Bit divider to 16, full rate, set as REFCLK sync master */
            avago_spico_int(aapl, host_serdes_addr, 0x30, 0x0070);  /* Set SPICO clk = refclk, Tx PLL refclk = pcie_core_clk, PCS FIFO = F66. */
        }

        /*# Wait for ready, could phase align here, but nervous about effects */
        /*#sleep 1 */

        avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000002); /* Release the host reset (keep mod reset) */
        /*sleep 0.1 */

        for (reg = 40; reg <= 47; reg += 2)     /* For each M25G slice: */
            avago_sbus_wr(aapl, ctl_logic, reg, 0x25);     /* Reset sync gearfifo, repeater data, reset phase_beacon, select common pcs_fifo_clk for mlg */

        /*sleep 0.1 */
        avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000000); /* Clear the reset */
        /* sleep? */
        avago_sbus_wr(aapl, all_mod25, 0x03, 0x000b0000); /* Tx Phase Cal    off */
        avago_sbus_wr(aapl, all_mod25, 0x03, 0x000b0001); /* Tx Phase Cal    on */
        avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000003); /* Reset rs_host and rs_mod */
        avago_sbus_wr(aapl, ctl_logic, 0x97, 0x00000000); /* Clear resets */

        sleep (1);

        avago_sbus_rd(aapl, ctl_logic, 0xa3);           /* Read ALIGN MAP STATUS */
        lock = avago_sbus_rd(aapl, ctl_logic, 0xa3);    /* Read ALIGN MAP STATUS */
        if (aapl->verbose) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Lock: %08x\n", lock);

        if ((lock >> 21) == 0x1f)
        {
            int prev_errors;
            int retry;
            int errors = 0;
            int verbose_prev = aapl->verbose;

            for (retry = 0; retry <= 20; retry++)
            {
                prev_errors = errors;
                if (aapl->verbose) aapl->verbose -= 1;
                errors = avsp_9104_get_status(aapl, prtad, AVSP_ALL_ERRORS, 0, 0);
                aapl->verbose = verbose_prev;
                lock = avago_sbus_rd(aapl, ctl_logic, 0xa3);   /* Read ALIGN MAP STATUS */
                if (errors == prev_errors && (lock >> 21) == 0x1f) break;

                if (aapl->verbose) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Failed: %d\n", errors);
                avago_sbus_wr(aapl, all_host, 0x03, 0x000e0100);   /* Slip Rx phase one bit */
            }
            if (aapl->verbose) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Errors: %d %d, LOCK: %08x\n", prev_errors, errors, lock);
            if (errors == prev_errors && (lock >> 21) == 0x1f) break;
        }
    }

    avsp_9104_get_status(aapl, prtad, AVSP_ALL_ERRORS, 0, 0);

    if (aapl->verbose) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "%08x %08x %08x %08x\n",
        avago_sbus_rd(aapl, ctl_logic, 0xa3),
        avago_sbus_rd(aapl, ctl_logic, 0xa4),
        avago_sbus_rd(aapl, ctl_logic, 0xa5),
        avago_sbus_rd(aapl, ctl_logic, 0xa8));
#endif
}

/** @endcond */

#if AAPL_ENABLE_AVSP_KR_TRAINING
/** @brief Configure KR behavior. */
void avsp_9104_set_kr_backchannel_mux(
    Aapl_t *aapl,               /**< Pointer to Aapl_t structure. */
    uint chip,                  /**< [in] Sets chip for enabling KR. */
    uint slice_0_rx,            /**< [in] Sets who slice0's tx should listen to during asymmetric KR [0,1,2,3] */
    uint slice_1_rx,            /**< [in] Sets who slice1's tx should listen to during asymmetric KR [0,1,2,3] */
    uint slice_2_rx,            /**< [in] Sets who slice2's tx should listen to during asymmetric KR [0,1,2,3] */
    uint slice_3_rx)            /**< [in] Sets who slice3's tx should listen to during asymmetric KR [0,1,2,3] */
{
    uint addr            = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
    uint ctl_logic       = avago_make_addr3(addr, 0, 0x2c);
    uint user_input      = avago_sbus_rd(aapl, ctl_logic, 0xe3);
    user_input          |= (slice_0_rx << 2);
    user_input          |= (slice_1_rx << 6);
    user_input          |= (slice_2_rx << 10);
    user_input          |= (slice_3_rx << 14);
    avago_sbus_wr(aapl, ctl_logic, 0xe3, user_input); /* Clear resets */
}
#endif

#endif /* AAPL_ENABLE_AVSP_9104 */

