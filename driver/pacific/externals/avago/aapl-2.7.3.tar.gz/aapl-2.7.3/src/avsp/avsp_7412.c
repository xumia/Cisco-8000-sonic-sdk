/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/** Doxygen File Header */
/** @file */
/** @brief Functions specific to the AVSP-7412. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_AVSP_7412

static void aapl_usleep(int time)
{
    ms_sleep(1 + (time / 1000));
}

static void serdes_disable(Aapl_t *aapl, uint prtad)
{
    uint len, *addrs, i;
    aapl_get_addr_list(aapl, prtad, "AVSP-7412", AVSP_HOST, &len, &addrs);
    for( i = 0; i < len; i++ )
    {
        if( i > 0 ) aapl_usleep(100);
        avago_serdes_set_tx_rx_enable(aapl, addrs[i], FALSE, FALSE, FALSE);
    }
    aapl_get_addr_list(aapl, prtad, "AVSP-7412", AVSP_MOD, &len, &addrs);
    for( i = 0; i < len; i++ )
    {
        aapl_usleep(100);
        avago_serdes_set_tx_rx_enable(aapl, addrs[i], FALSE, FALSE, FALSE);
    }
}

static void serdes_host_enable(Aapl_t *aapl, uint prtad, Avago_serdes_init_config_t *cfg)
{
    uint len, *addrs, i;
    aapl_get_addr_list(aapl, prtad, "AVSP-7412", AVSP_HOST, &len, &addrs);
    for( i = 0; i < len; i++ )
    {
        if( i > 0 ) aapl_usleep(100);
        avago_serdes_init(aapl, addrs[i], cfg);
        avago_serdes_set_rx_term(aapl, addrs[i], AVAGO_SERDES_RX_TERM_AGND);
    }
}

static void serdes_mod_enable(Aapl_t *aapl, uint prtad, Avago_serdes_init_config_t *cfg, uint num)
{
    uint len, *addrs, i;
    aapl_get_addr_list(aapl, prtad, "AVSP-7412", AVSP_MOD, &len, &addrs);
    for( i = 0; i < num && i < len; i++ )
    {
        if( i > 0 ) aapl_usleep(100);
        avago_serdes_init(aapl, addrs[i], cfg);
        avago_serdes_set_rx_term(aapl, addrs[i], AVAGO_SERDES_RX_TERM_AGND);
    }
}

static void core_disable(Aapl_t *aapl, uint prtad)
{
    /* FIXME: These should reset asserts of registers so we don't clear any */
    /*        required boot configurations like interrupt enable flags */
    avago_sbus_reset(aapl, avago_make_addr3(prtad, 0, AVSP_7412_RS528), 0);
    avago_sbus_reset(aapl, avago_make_addr3(prtad, 0, AVSP_7412_RS544), 0);
    avago_sbus_reset(aapl, avago_make_addr3(prtad, 0, AVSP_7412_HOST_ALIGN), 0);
    avago_sbus_reset(aapl, avago_make_addr3(prtad, 0, AVSP_7412_MOD_ALIGN), 0);
    avago_sbus_reset(aapl, avago_make_addr3(prtad, 0, AVSP_7412_CNTL), 0);
}

static void serdes_enable_4to2_rs528(Aapl_t *aapl, uint prtad)
{
    Avago_serdes_init_config_t *cfg = avago_serdes_init_config_construct(aapl);
    uint len, *addrs, i;

    cfg->sbus_reset = FALSE;
    cfg->init_mode  = AVAGO_INIT_ONLY;

    cfg->init_tx            = TRUE;
    cfg->tx_divider         = 165;
    cfg->tx_output_en       = FALSE;
    cfg->tx_width           = 40;
    cfg->tx_phase_cal       = FALSE; /* enable later on */
    cfg->refclk_sync_master = TRUE;
    cfg->tx_datapath.polarity_invert = FALSE;

    cfg->init_rx             = TRUE;
    cfg->rx_divider          = 165;
    cfg->rx_width            = 40;
    cfg->signal_ok_en        = TRUE;
    cfg->signal_ok_threshold = 0;
    cfg->rx_datapath.polarity_invert = FALSE;

    /* Host slice enable */
    serdes_host_enable(aapl, prtad, cfg);
    aapl_get_addr_list(aapl, prtad, "AVSP-7412", AVSP_HOST, &len, &addrs);
    for( i = 0; i < len; i++ )
        avago_serdes_mem_rmw(aapl, addrs[i], AVAGO_ESB, 0x73, 0x7 << 9, 0x7 << 9);


    /* PAM slice configuration */
    cfg->tx_width = 80;
    cfg->rx_width = 80;
    aapl_usleep(100);                   /* first slice init doesn't wait */
    serdes_mod_enable(aapl, prtad, cfg, AVSP_7412_MOD4TO2_NUM);
}

static void serdes_enable_4to2_rs544(Aapl_t *aapl, uint prtad)
{
    Avago_serdes_init_config_t *cfg = avago_serdes_init_config_construct(aapl);
    uint len, *addrs, i;

    cfg->sbus_reset = FALSE;
    cfg->init_mode  = AVAGO_INIT_ONLY;

    cfg->init_tx            = TRUE;
    cfg->tx_divider         = 165;
    cfg->tx_output_en       = FALSE;
    cfg->tx_width           = 40;
    cfg->tx_phase_cal       = FALSE; /* enable later on */
    cfg->refclk_sync_master = TRUE;
    cfg->tx_datapath.polarity_invert = FALSE;

    cfg->init_rx             = TRUE;
    cfg->rx_divider          = 165;
    cfg->rx_width            = 40;
    cfg->signal_ok_en        = TRUE;
    cfg->signal_ok_threshold = 0;
    cfg->rx_datapath.polarity_invert = FALSE;

    /* Host slice enable */
    serdes_host_enable(aapl, prtad, cfg);
    aapl_get_addr_list(aapl, prtad, "AVSP-7412", AVSP_HOST, &len, &addrs);
    for( i = 0; i < len; i++ )
        avago_serdes_mem_rmw(aapl, addrs[i], AVAGO_ESB, 0x73, 0x7 << 9, 0x7 << 9);



    /* PAM slice configuration */
    cfg->tx_width  = 80;
    cfg->tx_divider= 170;
    cfg->rx_width  = 80;
    cfg->rx_divider= 170;
    cfg->tx_encoding=AVAGO_SERDES_PAM4;
    cfg->rx_encoding=AVAGO_SERDES_PAM4;
    aapl_usleep(100);                   /* first slice init doesn't wait */
    serdes_mod_enable(aapl, prtad, cfg, AVSP_7412_MOD4TO2_NUM);
}

static void serdes_enable_4to2      (Aapl_t *aapl, uint prtad) {(void)aapl; (void)prtad;}
static void serdes_enable_4to4_rs528(Aapl_t *aapl, uint prtad) {(void)aapl; (void)prtad;}
static void serdes_enable_4to4      (Aapl_t *aapl, uint prtad) {(void)aapl; (void)prtad;}

static void core_enable_4to2_rs528(Aapl_t *aapl, uint prtad)
{
    uint addr = avago_make_addr3(prtad, 0, AVSP_7412_HOST_ALIGN);
    avago_sbus_wr(aapl, addr,  1, 0x100);
    avago_sbus_wr(aapl, addr, 30, 0xffffffff);
    avago_sbus_wr(aapl, addr, 31, 0x1);

    addr = avago_make_addr3(prtad, 0, AVSP_7412_CNTL);
    avago_sbus_wr(aapl, addr, 0, 0x2);
    avago_sbus_wr(aapl, addr, 32, 0x0330);
    avago_sbus_wr(aapl, addr, 33, 0x0030);
    avago_sbus_wr(aapl, addr, 34, 0xffffffff);

    addr = avago_make_addr3(prtad, 0, AVSP_7412_MOD_ALIGN);
    avago_sbus_wr(aapl, addr, 4, 0xcc1);

    addr = avago_make_addr3(prtad, 0, AVSP_7412_CNTL);
    avago_sbus_wr(aapl, addr, 0, 0x3); /* assert reset */
}

static void core_enable_4to2_rs544(Aapl_t *aapl, uint prtad) {(void)aapl; (void)prtad;}
static void core_enable_4to2      (Aapl_t *aapl, uint prtad) {(void)aapl; (void)prtad;}
static void core_enable_4to4_rs528(Aapl_t *aapl, uint prtad) {(void)aapl; (void)prtad;}
static void core_enable_4to4      (Aapl_t *aapl, uint prtad) {(void)aapl; (void)prtad;}


static int serdes_enable(Aapl_t *aapl, uint prtad, Avsp_state_7412_t state)
{
    switch(state)
    {
    case AVSP_7412_4TO2_RS528 : serdes_enable_4to2_rs528(aapl, prtad); break;
    case AVSP_7412_4TO2_RS544 : serdes_enable_4to2_rs544(aapl, prtad); break;
    case AVSP_7412_4TO2       : serdes_enable_4to2      (aapl, prtad); break;
    case AVSP_7412_4TO4_RS528 : serdes_enable_4to4_rs528(aapl, prtad); break;
    case AVSP_7412_4TO4       : serdes_enable_4to4      (aapl, prtad); break;
    default                   : return 0;
    }
    return 1;
}

static int core_enable(Aapl_t *aapl, uint prtad, Avsp_state_7412_t state)
{
    switch(state)
    {
    case AVSP_7412_4TO2_RS528 : core_enable_4to2_rs528(aapl, prtad); break;
    case AVSP_7412_4TO2_RS544 : core_enable_4to2_rs544(aapl, prtad); break;
    case AVSP_7412_4TO2       : core_enable_4to2      (aapl, prtad); break;
    case AVSP_7412_4TO4_RS528 : core_enable_4to4_rs528(aapl, prtad); break;
    case AVSP_7412_4TO4       : core_enable_4to4      (aapl, prtad); break;
    default                   : return 0;
    }
    return 1;
}

/** @brief   Enable SerDes and initializes core of AVSP 7412. */
/** @return  void. */
void avsp_7412_init(
    Aapl_t *aapl,            /**< [in] Pointer to Aapl_t structure. */
    uint prtad,              /**< [in] Port address of the targeted device. */
    Avsp_state_7412_t state) /**< [in] State structure of AVSP 7412. */
{
  (void)state;
  #if 0
  BOOL mode_4to2;

  switch(state) {
    case AVSP_7412_4TO2_RS528 :
    case AVSP_7412_4TO2_RS544 :
    case AVSP_7412_4TO2       : mode_4to2 = TRUE; break;
    case AVSP_7412_4TO4_RS528 :
    case AVSP_7412_4TO4       : mode_4to2 = FALSE; break;
    default                   : mode_4to2 = FALSE;
  }
  #endif

  serdes_disable(aapl, prtad);
  core_disable(aapl, prtad);

  serdes_enable(aapl, prtad, state);
  core_enable(aapl, prtad, state);
}
int avsp_7412_set_mode(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    Avsp_state_t *state)    /**< State structure to write. */
{
    uint addr = 0;
    switch( state->mode )
    {
    case AVSP_RS_FEC_528: { 
         addr = avago_make_addr3(state->prtad, 0, 0x00f);
         avago_sbus_wr(aapl, addr, 0x001, 0x0003);                    /* Assert host and mod resets */

         addr = avago_make_addr3(state->prtad, 0, 0x003);
         avago_sbus_wr(aapl, addr, 0x022, 0x0001);                    /* Ping RW1C host aligner reset */
         addr = avago_make_addr3(state->prtad, 0, 0x00f);
         avago_sbus_wr(aapl, addr, 0x001, 0x0002);                    /* De-assert host reset */
         avago_sbus_wr(aapl, addr, 0x001, 0x0000);
         break;
    }
    case AVSP_RS_FEC_544: { 
         addr = avago_make_addr3(state->prtad, 0, 0x00f);
         avago_sbus_wr(aapl, addr, 0x001, 0x0003);                    /* Assert host and mod resets */

         addr = avago_make_addr3(state->prtad, 0, 0x003);
         avago_sbus_wr(aapl, addr, 0x022, 0x0001);                    /* Ping RW1C host aligner reset */
         addr = avago_make_addr3(state->prtad, 0, 0x00f);
         avago_sbus_wr(aapl, addr, 0x001, 0x0002);                    /* De-assert host reset */
         avago_sbus_wr(aapl, addr, 0x001, 0x0000);
         break;
    }
    case AVSP_GEARBOX_2_1: {
         break;
    }
     
    case AVSP_REPEATER_DUPLEX: {
         break;
    }

    default:
    break;
    }
    return 0;
}

/** @brief  Retrieves the mode into which the core logic is configured. */
/** @return Returns the core logic configuration mode. */
Avsp_mode_t avsp_7412_get_mode(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint prtad)     /**< [in] Port address of the target device. */
{
    uint addr = avago_make_addr3(prtad, 0, 0xfd);
    int val = avago_spico_int(aapl,addr,0x26,0x3800) & 0x0f;
    Avsp_mode_t mode = val == 0x000 ? AVSP_REPEATER_DUPLEX :
                       val == 0x001 ? AVSP_GEARBOX_2_1 :
                       val == 0x002 ? AVSP_RS_FEC_528 :
                       val == 0x003 ? AVSP_RS_FEC_544 : AVSP_ADHOC;
    return mode;
   /* 
    uint setting = avago_sbus_rd(aapl, ctl_addr, 0x14);
    uint mode    = avago_sbus_rd(aapl, ctl_addr, 0x96) & 0x0f;
*/
}
#endif /* AAPL_ENABLE_AVSP_7412 */
