/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* Support for AAPL handling PS1 */

/** @file */
/** @brief  Functions for accessing Avago PS1 */
/** @defgroup PS1 API for reading and controlling Avago PS1 */
/** @{ */
/* */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_DIAG && AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_PS1


/** @brief Returns TRUE if PS1 device: */
static BOOL verify_ps1(Aapl_t *aapl)
{
    avago_aacs_send_command(aapl, "version"); /* check and see if we're talking to AAPL or to an HS1/PS1, etc */
    /* send the status command (which should be sent directly to the HS1 (via the "send status" command) if talking to an AAPL AACS server */
    return strstr(aapl->data_char, "AACS PS1") != 0;
}

/** @brief   Retrieves voltage, current and clock frequency settings from PS1 device. */
/** @return  Returns TRUE on success, FALSE if not a PS1 or if other failure. */
BOOL avago_ps1_get_power_settings(
    Aapl_t            *aapl,    /**< [in] Pointer to Aapl_t structure. */
    Avago_ps1_power_t *power)   /**< [out] Values queried from PS1. */
{
    int count;
    char *ptr;
    memset(power, 0, sizeof(Avago_ps1_power_t));
    avago_aacs_send_command(aapl,"ven;vset;iset;clken;clkset");
    ptr = aapl->data_char;
    count  = sscanf(ptr,"%1d %1d %1d %1d %1d",        &power->power_enable[0], &power->power_enable[1], &power->power_enable[2], &power->power_enable[3],
                                                                                                                                 &power->power_enable[4]); ptr = strchr(ptr,';');
    if( ptr ) {ptr++; count += sscanf(ptr,"%9f %9f %9f %9f", &power->voltage[0],      &power->voltage[1],      &power->voltage[2],      &power->voltage[3]);      ptr = strchr(ptr,';');}
    if( ptr ) {ptr++; count += sscanf(ptr,"%9f %9f %9f %9f", &power->current[0],      &power->current[1],      &power->current[2],      &power->current[3]);      ptr = strchr(ptr,';');}
    if( ptr ) {ptr++; count += sscanf(ptr,"%1d %1d %1d %1d", &power->clock_enable[0], &power->clock_enable[1], &power->clock_enable[2], &power->clock_enable[3]); ptr = strchr(ptr,';');}
    if( ptr ) {ptr+=3;count += sscanf(ptr,"%3d %9f %9f %9f %9f", &power->crystal,      &power->freq_MHz[0],     &power->freq_MHz[1],     &power->freq_MHz[2],     &power->freq_MHz[3]);}
    return count == 22;
}

/** @brief   Retrieves measured voltage, current and clock frequencies from PS1 device. */
/** @return  Returns TRUE on success, FALSE if not a PS1 or if other failure. */
BOOL avago_ps1_get_power_values(
    Aapl_t            *aapl,    /**< [in] Pointer to Aapl_t structure. */
    Avago_ps1_power_t *power)   /**< [out] Values queried from PS1. */
{
    int count;
    char *ptr;
    memset(power, 0, sizeof(Avago_ps1_power_t));
    avago_aacs_send_command(aapl,"ven;vread;iread;clken;clkread");
    ptr = aapl->data_char;
    count  = sscanf(ptr,"%1d %1d %1d %1d %1d",               &power->power_enable[0], &power->power_enable[1], &power->power_enable[2], &power->power_enable[3],
                                                                                                                                        &power->power_enable[4]); ptr = strchr(ptr,';');
    if( ptr ) {ptr++; count += sscanf(ptr,"%9f %9f %9f %9f", &power->voltage[0],      &power->voltage[1],      &power->voltage[2],      &power->voltage[3]);      ptr = strchr(ptr,';');}
    if( ptr ) {ptr++; count += sscanf(ptr,"%9f %9f %9f %9f", &power->current[0],      &power->current[1],      &power->current[2],      &power->current[3]);      ptr = strchr(ptr,';');}
    if( ptr ) {ptr++; count += sscanf(ptr,"%1d %1d %1d %1d", &power->clock_enable[0], &power->clock_enable[1], &power->clock_enable[2], &power->clock_enable[3]); ptr = strchr(ptr,';');}
    if( ptr ) {ptr++; count += sscanf(ptr,"%9f %9f %9f %9f", &power->freq_MHz[0],     &power->freq_MHz[1],     &power->freq_MHz[2],     &power->freq_MHz[3]);}
    return count == 21;
}

/** @brief   Check voltage and current status of Avago PS1 */
void avago_ps1_display_power_status(
    Aapl_t *aapl)   /**< [in] Pointer to Aapl_t structure. */
{
    int supply, clock;
    float power = 0;
    Avago_ps1_power_t pset, pread;

    if( !verify_ps1(aapl) ) return;

    if( !avago_ps1_get_power_settings(aapl,&pset) || !avago_ps1_get_power_values(aapl,&pread) )
        return;

    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "PS1 clocks:");
    for( clock = 0; clock < 4; clock++ )
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, " %.11gMHz(%s)", pset.freq_MHz[clock], aapl_onoff_to_str(pset.clock_enable[clock]));
    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n");

    for( supply = 0; supply < 4; supply++ )
    {
        power += pread.voltage[supply] * pread.current[supply];
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Supply %d: %3s   %5.3fV  %6.3fA  |  %5.3fV  %5.3fA  |  %5.3fW\n",
                supply, pset.power_enable[supply] ? "ON" : "OFF",
                pset.voltage[supply], pset.current[supply],
                pread.voltage[supply], pread.current[supply],
                pread.voltage[supply] * pread.current[supply]);
    }
    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Supply 4: %3s\n", pset.power_enable[4] ? "ON" : "OFF");
    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Total:                                                 %2.3fW\n", power);
}

#undef ON
#undef OFF
#define ON TRUE
#define OFF FALSE
Avago_ps1_power_t power_table[] =
{
    /* CHIP NAME             POWER ENABLES         VOLTAGE (Volts)       MAX CURRENT (Amps)       CLOCK ENABLES        CLOCK FREQUENCY (MHz)               ALIASES */

    /* Classic D6: */
    { "AVSP-4412/8801",  { ON,OFF, ON, ON,OFF}, {0.9, 0.0, 1.0, 2.5}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {312.50, 312.50, 250.0, 250.0}, 0, "4412_app,4412_char"
                                                                                                                                                      ",sd28C_str_txhs_rxd6_04"
                                                                                                                                                      ",sd28C_str_txhs_rxd6_03"
                                                                                                                                                      },
    { "AVSP default",    { ON,OFF, ON, ON,OFF}, {0.9, 0.0, 1.0, 2.5}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "9104_app"
                                                                                                                                                      ",9104_char"
                                                                                                                                                      ",AVSP-9104"
                                                                                                                                                      ",sd28C_txke_rxd6e_04"
                                                                                                                                                      ",sd28C_txhsg_rxd6g_01"
                                                                                                                                                      ",AVSP-5410"
                                                                                                                                                      ",garnet"
                                                                                                                                                      ",AVSP-8812"
                                                                                                                                                      ",8812_app,8812_char"
                                                                                                                                                      ",sd28C_str_txhs_rxd6_05"
                                                                                                                                                      ",AVSP-1104"
                                                                                                                                                      ",1104_app,1104_char,1104_mcm_tiny"
                                                                                                                                                      ",sd28C_txke_rxd6e_02"
                                                                                                                                                      ",sd28C_txhs_rxd6_03"
                                                                                                                                                      ",sd28C_txk_rxd6e_gb_2_03"
                                                                                                                                                      ",sd28C_str_txhs_rxd6_02"
                                                                                                                                                      },

    /* M4: */
    { "AVSP-7401" ,      { ON, ON, ON, ON,OFF}, {0.9, 1.1, 1.1, 2.5}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "coral" },
    /*                                          DVDD      AVDD  VDD (wiring from Jeff S) */
    /*                                          VDD        AVDD VDDH (according to Hugh/ AVSP-7412 v0.9.2 Datasheet */
    { "AVSP-7412" ,      { ON, ON, ON, ON,OFF}, {0.9, 0.0, 1.0, 2.5}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "7412_char"
                                                                                                                                                      ",sd28Quad_p1_02"
                                                                                                                                                      ",sd28C_txopam4_rxom4_02"
                                                                                                                                                      }, /* Opal rev 2 */
/*  { "AVSP-7412" ,      { ON, ON, ON, ON,OFF}, {1.0, 1.0, 1.2, 2.5}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "" }, // Opal rev 1 */

    /* Tesla Entries:                            VDD AVDDH AVDD VDD2 (I/O set externally) */
    { "tesla_p1",        { ON, ON, ON, ON, ON}, {0.8, 1.1, 0.8, 0.9}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "tesla_p1_tr"
                                                                                                                                                     ",sd16Q_p1_ew_01"
                                                                                                                                                     ",sd16Q_p2_ew_ex1_01" },
    { "Tesla",           { ON, ON, ON, ON, ON}, {0.8, 1.1, 0.9, 0.9}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "tesla_d6"
                                                                                                                                                     ",tesla_cm4_tr"
                                                                                                                                                     ",sd16C_txhs_rxd6_mim_ns_03"
                                                                                                                                                     ",sd16C_pcie_shrt_ns_03"
                                                                                                                                                     ",sd16C_txhs_rxd6_mim_13p5_ns_03"
                                                                                                                                                     ",sd16C_txhs_rxd6_ns_03"
                                                                                                                                                     ",sd16C_txcpam4_rxcm4_ns_01" },


    /* Fermi Entries:   VDD AVDDH AVDD VDD2 PLLVDD VDD AVDDH AVDD VDD2 (PLLVDD is set on board via pot to 1.8v) */
    { "FermiB"    ,      { ON, ON, ON, ON, ON},   {0.8, 1.1, 0.9, 0.9}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 156.25, 156.25}, 0, "sd16C_txhs_rxd6_mim_ns_062"
                                                                                                                                                         ",sd16C_txcpam4_rxcm4_ns_09"
                                                                                                                                                         ",sd16Q_p1_ew_021"
                                                                                                                                                         ",sd16Q_p1_ew_03"
                                                                                                                                                         ",sd16C_pcie_gen4_ns_03" },
    { "Fermi"     ,      { ON, ON, ON, ON, ON},   {0.8, 1.1, 0.9, 0.9}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 156.25, 156.25}, 0, "fermi_d6"
                                                                                                                                                         ",fermi_d6_tr"
                                                                                                                                                         ",fermi_cm4"
                                                                                                                                                         ",fermi_cm4_unit"
                                                                                                                                                         ",fermi_cm4_tr"
                                                                                                                                                         ",fermi_p1"
                                                                                                                                                         ",fermi_p1_tr" },
    { "fermi_gladiator", { ON, ON, ON, ON,OFF},   {0.8, 1.1, 0.9, 1.8}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 156.25, 156.25}, 0, "" }, /* M4 */
    { "fermi_tiny",      { ON, ON, ON, ON,OFF},   {0.8, 1.1, 0.9, 1.8}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 156.25, 156.25}, 0, "" }, /* M4 */

    /* Franklin Entries:   VDD AVDDH AVDD VDD2 PLLVDD VDD AVDDH AVDD VDD2 (PLLVDD is set on board via pot to 1.8v) */
    { "franklin_p1",     { ON, ON, ON, ON, ON},   {0.8, 1.1, 0.8, 0.9}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 156.25, 156.25}, 0, "sd16Q_p1_ew_011"
                                                                                                                                                         ",sd16Q_p1_ew_02" },
    { "Franklin",        { ON, ON, ON, ON, ON},   {0.8, 1.1, 0.9, 0.9}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 156.25, 156.25}, 0, "franklin_d6"
                                                                                                                                                         ",franklin_cm4"
                                                                                                                                                         ",franklin_cm4_temp"
                                                                                                                                                         ",franklin_temp"
                                                                                                                                                         ",franklin_cm4_tr"
                                                                                                                                                         ",franklin_cm4_unit"
                                                                                                                                                         ",sd16C_txhs_rxd6_mim_ns_04"
                                                                                                                                                         ",sd16C_txcpam4_rxcm4_ns_02"
                                                                                                                                                         ",sd16C_txcpam4_rxcm4_ns_03"
                                                                                                                                                         ",sd16C_pcie_gen4_ns_01"
                                                                                                                                                         ",sd16C_txhs_rxd6_ns_04"
                                                                                                                                                         ",sd16C_txhs_rxd6_mim_ns_08"
                                                                                                                                                         /* Franklin 2.0 IP: */
                                                                                                                                                         ",sd16C_txhs_rxd6_mim_ns_09"
                                                                                                                                                         ",sd16C_pcie_txke_rxd6e_gen4_07"
                                                                                                                                                         ",sd16C_pon_txke_rxd6e_ns_09"
                                                                                                                                                         ",sd16C_txcpam4_rxcm4_ns_08"
                                                                                                                                                         },

    /* 7nm D6 Entries:   VDD AVDDH AVDD VDD2 VDDH  VDD AVDDH AVDD VDD2 */
    /* have temporaritly bump 3 supply (using 1 as the first index) 10 % up for tuning */
    /* bumping to 12.5% because if intermittent pll_cal data failures. */
  /*  "Beaver-Creek" ,   { ON, ON, ON, ON, ON},   {0.765,0.9,0.8, 0.8}, { 5.0,  5.0,  5.0,  5.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 156.25, 156.25}, 0, "sd07C_txd6_rxd6_ns_01" */
    { "Beaver-Creek" ,   { ON, ON, ON, ON, ON},   {0.765,0.9,0.9, 0.8}, { 5.0,  5.0,  5.0,  5.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 156.25, 156.25}, 0, "sd07C_txd6_rxd6_ns_01"
                                                                                                                                                         ",sd07C_pcie_ns_01"
                                                                                                                                                         ",sd07C_txd6_rxd6_ns_03"
                                                                                                                                                         ",sd07C_pcie_ns_03"
                                                                                                                                                         ",beaver_creek" },

    /* 7nm Blackhawk: */
    /*  Latest analysis of Alta, supplies 0,2,3 need to be upped to resolve some timing issues for PAM4 */
    { "Alta"      ,      { ON, ON, ON, ON, ON},   {.825, 1.2, .75, .75}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 156.25, 156.25}, 0, "sd07C_cpam4bh_oct_ns_01" },

    /* HVD6: */
    { "Pikes"     ,      { ON, ON, ON, ON,OFF},   {1.0, 1.5, 1.0, 1.8}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "" },
    { "Academy"   ,      { ON, ON, ON, ON,OFF},   {1.0, 1.5, 1.0, 1.8}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "" },

    { "Borah-Peak",      { ON,OFF, ON, ON,OFF},   {0.9, 0.0, 1.0, 1.8}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "borah_peak" },
    { "Buck-Hill" ,      { ON,OFF, ON, ON,OFF},   {0.9, 0.0, 1.0, 1.8}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "buck_hill" },

    /* Old chips: */
/*  { "AVSP-521"  ,      { ON,OFF, ON, ON,OFF},   {0.9, 0.0, 1.0, 1.8}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "" }, */
    { "McKinley"  ,      { ON, ON, ON, ON,OFF},   {0.9, 1.0, 1.0, 1.8}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "mckinley,mckinley_tr,mckinley_xtal"
                                                                                                                                                        ",d28C_hf_txhs_rxd6_03"
                                                                                                                                                        ",sd28C_txhs_rxd6_pcs_03"
                                                                                                                                                        ",sd28C_txhsln_rxd7_01"
                                                                                                                                                        ",sd28C_pcie_05" },

    /* 16nm D6: */
    { "Maxwell"   ,      { ON,OFF, ON, ON,OFF},   {0.9, 0.0, 1.0, 1.8}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "" },
    { "Simba"     ,      { ON,OFF, ON, ON,OFF},   {0.8, 0.0, 0.9, 1.8}, {20.0, 20.0, 20.0, 20.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "sd16C_txhs_rxd6_ns_02"
                                                                                                                                                        ",sd16C_txke_rxd6e_ns_02"
                                                                                                                                                        ",sd16C_pcie_ns_02" },

    /* Special power states: */
    { "QUERY1"    ,      { ON, ON, ON, ON, ON},   {0.9, 0.9, 0.9, 0.9}, { 2.0,  2.0,  2.0,  2.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "" }, /* 1st safe voltages to try to query device */
/*  { "QUERY2"    ,      { ON, ON, ON,OFF, ON},   {0.9, 1.1, 1.0, 1.8}, { 2.0,  2.0,  2.0,  2.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "" }, // 2nd safe voltages to try to query device */
/*  { "QUERY3"    ,      { ON, ON, ON, ON, ON},   {0.9, 1.5, 1.0, 2.0}, { 2.0,  2.0,  2.0,  2.0}, { ON, ON,OFF,OFF}, {156.25, 156.25, 250.0, 250.0}, 0, "" }, // 2nd safe voltages to try to query device */
};

/* Find power table entry for name. */
/* Return address of entry, or NULL if not found. */
static int avago_ps1_power_table_find(const char *chip_name)
{
    int index, match = -1;
    for( index = 0; index < AAPL_ARRAY_LENGTH(power_table); index++ )
        if( 0 == aapl_strcasecmp(chip_name, power_table[index].chip_name) )
            return index;
    for( index = 0; index < AAPL_ARRAY_LENGTH(power_table); index++ )
    {
        /* printf("index = %u, search_name = %s, chip_name = %s, aliases = %s\n", index, chip_name, power_table[index].chip_name, power_table[index].aliases); */
        if( strstr(power_table[index].aliases,chip_name) )
        {
            if( match != -1 )
                return -1;   /* Multiple matches */
            match = index;
        }
    }
    return match;
}

/** @brief   Sets clock frequencies and enablement for all supplies. */
/** @return Returns TRUE on success, FALSE if not a PS1 or other error. */
BOOL avago_ps1_set_clock_settings(
    Aapl_t            *aapl,    /**< [in] Pointer to Aapl_t structure. */
    Avago_ps1_power_t *power)   /**< [in] Values to set. */
{
    char str[512];
    char *ptr = str;
    int j;
    Avago_ps1_power_t pset;
    BOOL work_to_do = FALSE;
    int retry = 0;

    if( !verify_ps1(aapl) )
        return FALSE;

    if( !avago_ps1_get_power_settings(aapl,&pset) )
        return FALSE;

    retry:
    /* Set clock frequencies and enablements to defaults: */
    ptr += sprintf(ptr,"clkset t %d", pset.crystal);
    for( j = 0; j < 4; j++ )
    {
        /* Note: frequencies are all set together in one command: */
        ptr += sprintf(ptr," %.11g", power->freq_MHz[j]);
        if( power->clock_enable[j] && power->freq_MHz[j] != pset.freq_MHz[j] )
            work_to_do = TRUE;  /* Only set if changes */
    }
    ptr += sprintf(ptr,";");
    if( !work_to_do )
        ptr = str;  /* No change, don't send clkset command. */

    for( j = 0; j < 4; j++ )
        if( power->clock_enable[j] != pset.clock_enable[j] )
            ptr += sprintf(ptr,"clken %d %d;", j, power->clock_enable[j]);

    if( ptr > str )
    {
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Sending command: %s\n", str);
        AAPL_SUPPRESS_ERRORS_PUSH(aapl);
        avago_aacs_send_command(aapl, str);
        AAPL_SUPPRESS_ERRORS_POP(aapl);
        if (strstr(aapl->data_char, "WARNING") || strstr(aapl->data_char, "ERROR"))    /* did the response contain ERROR or WARNING? */
        {
            if (retry == 0 || retry == 1) /* allowed to fail once, then try again on original setting */
            {
                if      (pset.crystal == 40) pset.crystal = 26;
                else if (pset.crystal == 26) pset.crystal = 40;
                aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Failed setting frequency after sending %s -> %s. Trying crystal frequency of %d MHz.\n", aapl->data_char, str, pset.crystal);
                retry ++;
                ptr = str;
                goto retry;
            }
            aapl_fail(aapl, __func__, __LINE__, "Failed setting frequency after sending %s -> %s\n", aapl->data_char, str);
            return FALSE;
        }
        ms_sleep(100); /* allow time for the clocks to settle */
    }
    return TRUE;
}

static BOOL set_clocks(Aapl_t *aapl, const char *chip_name)
{
    int index = avago_ps1_power_table_find(chip_name);
    if( index >= 0 )
    {
        BOOL status;
        if( index < AAPL_ARRAY_LENGTH(power_table) )
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Setting %s clock configuration.\n", chip_name);
        AAPL_SUPPRESS_ERRORS_PUSH(aapl);
        status = avago_ps1_set_clock_settings(aapl, &power_table[index]);
        AAPL_SUPPRESS_ERRORS_POP(aapl);
        if( status ) return TRUE;
        return avago_ps1_set_clock_settings(aapl, &power_table[index]);
    }
    aapl_log_printf(aapl, AVAGO_WARNING, 0, 0, "Chip %s is an unknown device, clock configuration not changed.\n", chip_name);
    return FALSE;
}

/** @brief   Sets power, current and enablement for all supplies. */
/** @return Returns TRUE on success, FALSE if not a PS1 or other error. */
BOOL avago_ps1_set_power_settings(
    Aapl_t            *aapl,    /**< [in] Pointer to Aapl_t structure. */
    Avago_ps1_power_t *power)   /**< [in] Values to set. */
{
    char str[512];
    char *ptr = str;
    int j;
    Avago_ps1_power_t pset;

    if( !avago_ps1_get_power_settings(aapl,&pset) )
        return FALSE;

    *ptr = '\0';

    /* Set power values and enablements to defaults; */
    for( j = 0; j < 5; j++ )
        if( !power->power_enable[j] && /* Power down those which shouldn't be on */
            power->power_enable[j] != pset.power_enable[j] )
        {
            ptr += sprintf(ptr,"ven %d 0;", j);
            pset.power_enable[j] = FALSE;
        }
    for( j = 0; j < 4; j++ )
    {
        /* Incrementally update voltages and max currents: */
        if( power->voltage[j] != pset.voltage[j] && power->power_enable[j] )
            ptr += sprintf(ptr,"vset %d %1.3f;", j, power->voltage[j]);
        if( power->current[j] != pset.current[j] )
            ptr += sprintf(ptr,"iset %d %1.3f;", j, power->current[j]);
    }
    for( j = 0; j < 5; j++ )
        if( power->power_enable[j] != pset.power_enable[j] )
            ptr += sprintf(ptr,"ven %d %d;", j, power->power_enable[j]);

    if( ptr > str )
    {
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Sending command: %s\n", str);
        avago_aacs_send_command(aapl, str);
        ms_sleep(100); /* allows time to PS1 power supplies to settle */
    }
    return TRUE;
}

static BOOL set_power(Aapl_t *aapl, const char *chip_name)
{
    int index = avago_ps1_power_table_find(chip_name);
    if( !verify_ps1(aapl) )
    {
        aapl_log_printf(aapl, AVAGO_WARNING, 0, 0, "Can only set power on a PS1 device.\n");
        return FALSE;
    }

    if( index >= 0 )
    {
        BOOL status;
        if( index < AAPL_ARRAY_LENGTH(power_table) )
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Setting %s power configuration.\n", chip_name);

        AAPL_SUPPRESS_ERRORS_PUSH(aapl);
        status = avago_ps1_set_power_settings(aapl,&power_table[index]);
        AAPL_SUPPRESS_ERRORS_POP(aapl);
        if( status ) return TRUE;
        return avago_ps1_set_power_settings(aapl,&power_table[index]);
    }

    aapl_log_printf(aapl, AVAGO_WARNING, 0, 0, "Chip %s is an unknown device, power configuration not changed.\n", chip_name);
    return FALSE;
}

/** @brief  Tells a PS1 to power off all supplies. */
/** @return Returns TRUE on success, FALSE on failure. */
BOOL avago_ps1_power_off(
    Aapl_t *aapl)   /**< [in] Pointer to Aapl_t structure. */
{
    const char *result = avago_aacs_send_command(aapl,"ven 0 0;ven 1 0; ven 2 0; ven 3 0; ven 4 0");
    uint rc = 0==strcmp(result,"0;0;0;0;0");
    return rc;
}

static void configure_device(Aapl_t *aapl, const char *chip_name)
{
    aapl_log_printf(aapl, AVAGO_DEBUG1, 0, 0, "Can't read chip id, trying power state %s\n", chip_name);
    set_clocks(aapl,chip_name);
    set_power(aapl, chip_name);
    AAPL_SUPPRESS_ERRORS_PUSH(aapl);
    aapl_get_ip_info(aapl,1);
    AAPL_SUPPRESS_ERRORS_POP(aapl);
}

/** @brief   Tells a PS1 to power on supplies appropriately based on the type of device. */
/** @details If a device is not already powered on, it must be partially */
/**          powered up to detect the device type.  If the detection process fails to */
/**          detect a known device, the device is powered down. */
/** @return  Returns TRUE on success, FALSE on failure. */
BOOL avago_ps1_set_power_defaults(
    Aapl_t *aapl)   /**< [in] Pointer to Aapl_t structure. */
{
    const char *chip_name = 0;
    const char *dut = getenv("SERDES_DUT");
    const char *gatekeeper = getenv("SERDES_GATEKEEPER");
    Aapl_t *aapl_hs1 = aapl; /* HS1 and PS1 are the same by default */
    const char *ip_str = getenv("SERDES_DUT_IP");

    if (ip_str && getenv("SERDES_PS1_IP")) /* use this environment variable for the HS1 hostname */
    {
        aapl_close_connection(aapl_hs1);
        aapl_hs1 = aapl_construct();
        aapl_hs1->aacs_server = (char *)aapl_realloc(aapl_hs1,aapl_hs1->aacs_server, strlen(getenv("SERDES_DUT_IP"))+1,__func__);
        strncpy(aapl_hs1->aacs_server, ip_str, strlen(ip_str)+1);
        aapl_log_printf(aapl_hs1,AVAGO_INFO,0,0,"NOTE: Using environment variable SERDES_DUT_IP for HS1 IP address (%s).\n", aapl_hs1->aacs_server);
        aapl_connect(aapl_hs1, 0, 0);
    }

    if( gatekeeper )
    {
        /* Some systems need to have different power than the defaults for the IP specified in $SERDES_DUT. */
        if( 0==strncmp(gatekeeper,"cs09.",5) ) chip_name = "1104_mcm_tiny";
        if( 0==strncmp(gatekeeper,"cs47.",5) ) chip_name = "fermi_gladiator";
        if( 0==strncmp(gatekeeper,"cs56.",5) ) chip_name = "fermi_tiny";
        if( 0==strncmp(gatekeeper,"cs51.",5) ) chip_name = "quokka";
        if( chip_name )
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Environment selecting configuration %s\n", chip_name);
    }

    /* First, search table for $SERDES_DUT */
    /* Only use this for systems that can't be set by their chip name: */
    if( dut && (!chip_name || !*chip_name) )
    {
        int index = avago_ps1_power_table_find(dut);
        if( index >= 0 )
        {
            chip_name = power_table[index].chip_name;
            if( 0==strcmp(chip_name,"fermi_gladiator") ||
                0==strcmp(chip_name,"franklin_p1") ||
                0==strcmp(chip_name,"tesla_p1") ||
                0==strcmp(chip_name,"fermi_tiny") )
            {
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Environment selecting configuration %s\n", chip_name);
            }
            else
                chip_name = 0;
        }
    }

    /* Second, try querying the chip for id info: */
    if( !chip_name || !*chip_name )
    {
        Avago_ps1_power_t power;
        AAPL_SUPPRESS_ERRORS_PUSH(aapl);
        if( avago_ps1_get_power_settings(aapl, &power) && (power.power_enable[0] + power.power_enable[1] + power.power_enable[2] + power.power_enable[3] + power.power_enable[4]) >= 3 )
        {
            /* Only attempt this if power is on: */
            aapl_get_ip_info(aapl_hs1,0);
        }
        AAPL_SUPPRESS_ERRORS_POP(aapl);

        chip_name = aapl_get_chip_name(aapl_hs1,0);
        if( chip_name && 0==strcmp(chip_name,"unknown") )
            chip_name = 0;
    }

    /* Third, search table for $SERDES_DUT */
    /* Same search as the first one, but give live chip name precedence. */
    if( dut && (!chip_name || !*chip_name) )
    {
        int index = avago_ps1_power_table_find(dut);
        if( index >= 0 )
        {
            chip_name = power_table[index].chip_name;
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Environment selecting configuration %s\n", chip_name);
        }
    }

    /* Finally, try some discovery power settings: */
    /* Get here if chip is powered down and $SERDES_DUT is not set. */
    if( !chip_name || !*chip_name )
    {
        configure_device(aapl,"QUERY1");
        chip_name = aapl_get_chip_name(aapl_hs1,0);
    }
    #if 0
    if( !chip_name || !*chip_name )
    {
        configure_device(aapl,"QUERY2");
        chip_name = aapl_get_chip_name(aapl_hs1,0);
    }
    if( !chip_name || !*chip_name )
    {
        configure_device(aapl,"QUERY3");
        chip_name = aapl_get_chip_name(aapl_hs1,0);
    }
    #endif
    if( !chip_name || !*chip_name )
    {
        AAPL_SUPPRESS_ERRORS_PUSH(aapl);
        avago_ps1_power_off(aapl);
        AAPL_SUPPRESS_ERRORS_POP(aapl);
        aapl_log_printf(aapl, AVAGO_WARNING, 0, 1, "Cannot determine device type so cannot setup power defaults.\n");
        return FALSE;
    }
    if (getenv("SERDES_DUT_IP") && getenv("SERDES_PS1_IP")) /* use this environment variable for the HS1 hostname */
        aapl_destruct(aapl_hs1);
    return set_clocks(aapl,chip_name) && set_power(aapl, chip_name);
}

#if AAPL_ENABLE_MAIN

static int show_ps1_help(Aapl_t *aapl)
{
    aapl_common_main_help(TRUE);
    aapl_log_printf(aapl, AVAGO_INFO, 0, 0,
"-off                    Power off device. Applied before other options.\n"
"-set-defaults           Set power for \"known\" devices to default settings.\n"
"                        Applied before -vset and -iset options.\n"
"-cset <clock>=<value>   Set clock (0-3) frequency to <value> MHz.\n"
"                        Clock will be disabled if <value> is 0.\n"
"-load <ip_name>         Load power and clock defaults for <ip_name>.\n"
);
    aapl_log_printf(aapl, AVAGO_INFO, 0, 0,
"-vset <supply>=<value>  Set supply (0-4) to <value> volts.\n"
"                        Supply will be disabled if <value> is 0.\n"
"                        Supply 4 can only be enabled (<value>=1) or disabled.\n"
"-iset <supply>=<value>  Set max current for supply (0-3) to <value> amps.\n"
"-display                Display clock and power configuration.\n"
);

    return 1;
}

int aapl_ps1_main(int argc, char *argv[], Aapl_t *aapl)
{
    int rc, index = 0;
    Avago_addr_t addr_struct;
    float cset[4] = {-1,-1,-1,-1};
    float iset[4] = {-1,-1,-1,-1};
    float vset[5] = {-1,-1,-1,-1,-1};
    BOOL set_power_defaults = FALSE;
    BOOL power_off = FALSE;
    BOOL display = FALSE;
    char *chip_name = NULL;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"off",          0, 0, 'O'},
        {"set-defaults", 0, 0, 'S'},
        {"cset",         1, 0, 'c'},
        {"iset",         1, 0, 'i'},
        {"vset",         1, 0, 'v'},
        {"load",         1, 0, 'l'},
        {"display",      0, 0, 'D'},
        {0,              0, 0, 0}
    };

    avago_addr_init_broadcast(&addr_struct);
    if (aapl_common_main_options(aapl, argc, argv, &addr_struct) < 0)
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_ps1_help(aapl);
    }
    avago_addr_delete(aapl, &addr_struct);

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        int supply;
        float value;
        const char *name = options[index].name;
        switch( rc )
        {
        case 'c':   if( 2 == sscanf(optarg,"%9d=%9f",&supply, &value) && supply >= 0 && supply <= 3 )
                    {
                        cset[supply] = value;
                        break;
                    }
                    aapl_main_error("Option %s parameter is invalid.  Expected [0-3]=<value>, got '%s'\n",name,optarg);
        case 'v':   if( 2 == sscanf(optarg,"%9d=%9f",&supply, &value) && supply >= 0 && supply <= 4 )
                    {
                        vset[supply] = value;
                        break;
                    }
                    aapl_main_error("Option %s parameter is invalid.  Expected [0-4]=<value>, got '%s'\n",name,optarg);
        case 'i':   if( 2 == sscanf(optarg,"%9d=%9f",&supply, &value) && supply >= 0 && supply <= 3 )
                    {
                        iset[supply] = value;
                        break;
                    }
                    aapl_main_error("Option %s parameter is invalid.  Expected [0-3]=<value>, got '%s'\n",name,optarg);
        case 'l': chip_name = optarg; break;
        case 'S': set_power_defaults = TRUE; break;
        case 'O': power_off          = TRUE; break;
        case 'D': display            = TRUE; break;
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    rc = 0;

    if (getenv("SERDES_PS1_IP")) /* use this environment variable for the PS1 hostname */
    {
        aapl->aacs_server = (char *)aapl_realloc(aapl,aapl->aacs_server, strlen(getenv("SERDES_PS1_IP"))+1,__func__);
        strncpy(aapl->aacs_server, getenv("SERDES_PS1_IP"), strlen(getenv("SERDES_PS1_IP"))+1);
        aapl_log_printf(aapl,AVAGO_INFO,0,0,"NOTE: Using environment variable SERDES_PS1 for PS1 IP address (%s).\n", aapl->aacs_server);
    }

    aapl_connect(aapl, 0, 0);

    if( !verify_ps1(aapl) )
    {
        aapl_fail(aapl, 0, 0, "This command only talks to a PS1 device.\n");
        return 1;
    }

    if( power_off )
    {
        rc = avago_ps1_power_off(aapl);
        if( rc ) aapl_log_printf(aapl,AVAGO_INFO,0,0,"Device powered off.\n");
        else     aapl_log_printf(aapl,AVAGO_INFO,0,0,"Device could not be powered off.\n");
    }

    if( chip_name ) /* -load <name> option */
    {
        int index = avago_ps1_power_table_find(chip_name);
        if( index >= 0 )
        {
            configure_device(aapl, chip_name);
            display = TRUE;
            set_power_defaults = FALSE;
        }
        else
            aapl_log_printf(aapl,AVAGO_WARNING,0,0,"Unrecognized name '%s' passed to -load option.\n", chip_name);
    }

    if( set_power_defaults )
    {
        rc = avago_ps1_set_power_defaults(aapl);
        if( rc ) display = TRUE;
    }

    /* Set individual values: */
    {
        Avago_ps1_power_t power;
        int supply;
        char str[512];
        char *ptr = str;
        *str = '\0';

        /* Since PS1 doesn't support individual clock settings, if any are being */
        /* set individually, read them all here: */
        if( cset[0] >= 0.0 || cset[1] >= 0.0 || cset[2] >= 0.0 || cset[3] >= 0.0 )
            avago_ps1_get_power_settings(aapl, &power);

        for( supply = 0; supply < 4; supply++ )
        {
            if( cset[supply] > 0 )
            {
                power.freq_MHz[supply] = cset[supply];
                power.clock_enable[supply] = TRUE;
            }
            else if( cset[supply] == 0.0 )
                power.clock_enable[supply] = FALSE;
            if( vset[supply] > 0 )
                ptr += sprintf(ptr, "vset %d %5.3f; ven %d 1;", supply, vset[supply], supply);
            else if( vset[supply] == 0.0 )
                ptr += sprintf(ptr, "ven %d 0;",supply);
            if( iset[supply] > 0 )
                ptr += sprintf(ptr, "iset %d %5.3f;", supply, iset[supply]);
        }
        if( vset[4] >= 0 )
            ptr += sprintf(ptr, "ven 4 %d;", vset[4] == 0 ? 0 : 1); /* Can only turn off or on */

        /* Set clocks if individual values specified: */
        if( cset[0] >= 0.0 || cset[1] >= 0.0 || cset[2] >= 0.0 || cset[3] >= 0.0 )
            avago_ps1_set_clock_settings(aapl, &power);

        if( *str )
        {
            aapl_log_printf(aapl,AVAGO_DEBUG1,0,0,"Sending command: %s\n", str);
            avago_aacs_send_command(aapl, str);
        }
        else if( !power_off && cset[0] < 0.0 && cset[1] < 0.0 && cset[2] < 0.0 && cset[3] < 0.0 )
            display = TRUE;
    }

    if( display )
        avago_ps1_display_power_status(aapl);

    return rc;
}
#endif /* AAPL_ENABLE_MAIN */
#endif /* AAPL_ENABLE_DIAG && AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_PS1 */

/** @} */
