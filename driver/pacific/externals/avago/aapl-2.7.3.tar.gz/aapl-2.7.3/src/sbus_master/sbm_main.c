/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* MAIN program for the sbm (sbus master) sub-command. */
/* */

/** Doxygen File Header */
/** @file */
/** @brief Launch wrapper for sbm command. */


#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_MAIN

/** @brief Directly read sbus_master memory locations. */
/** */
/** @return 0 on success, aapl->return_code (< 0) on error. */

static int sbm_peek_memory(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr,          /**< [in] Address number. */
    int start,          /**< [in] First address to dump. */
    int stop)           /**< [in] Last address to dump. */
{
    const int MOD = 16;
    int mem_addr, i = 0, data;
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__,__LINE__, "range: %d-%d (0x%x-%x)\n",start,stop, start,stop);
    printf("     0x00 0x01 0x02 0x03 0x04 0x05 0x06 0x07 "
                "0x08 0x09 0x0a 0x0b 0x0c 0x0d 0x0e 0x0f\n");
    data = avago_sbm_read_mem(aapl, addr, start);
    printf("%04x ", start & ~(MOD-1));
    for( i = 0; i < (start % MOD); i++ )
        printf("     ");
    for( mem_addr = start; mem_addr < stop; mem_addr++, i++ )
    {
        if( (mem_addr % MOD == 0) && mem_addr != start )
            printf("%04x ", mem_addr & ~(MOD-1));
        printf("%04x",data);
        printf((mem_addr % MOD) == (MOD-1) ? "\n" : " ");
        data = avago_sbm_read_next_mem(aapl, addr);
    }
    if( (stop % MOD) != 0 )
        printf("\n");

    if( aapl->return_code != 0 )
        printf("RETURN CODE FAILURE\n");
    return aapl->return_code;
}

/** @brief Directly read sbus_master memory locations. */
/** */
/** @return 0 on success, aapl->return_code (< 0) on error. */

static int sbm_poke_memory(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr,          /**< [in] Address number. */
    int start,          /**< [in] First address to write. */
    char *data)         /**< [in] Data to write (must still parse). */
{
    const char *separators = ", ;";

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__,__LINE__, "start: %d (0x%x), data = %s\n",start,start,data);

    data += strspn(data, separators);
    while( start < 9216 && *data )
    {
        char *ptr;
        int value = aapl_strtol(data,&ptr,0);
        if( data == ptr )
        {
            aapl_fail(aapl, __func__, __LINE__, "Invalid value: %s\n", ptr);
            return aapl->return_code;
        }
        data = ptr;
        data += strspn(data, separators);
        avago_sbm_write_mem(aapl, addr, start++, value);
    }

    if( aapl->return_code != 0 )
        printf("Memory write failure.\n");
    return aapl->return_code;
}


/* Return TRUE if valid range, FALSE otherwise. */
static BOOL parse_range(const char *optarg, int *start, int *stop)
{
    if( aapl_parse_range(optarg, start, stop) )
    {
        if( *stop == *start )
            (*stop)++;
        if( *stop <= 9216 )
            return TRUE;
    }
    return FALSE;
}

static int show_sbus_master_help()
{
    aapl_common_main_help(TRUE);

printf(
"At least one of the following is required:\n"
"-display                 Display SBus Master/SPICO/Controller information.\n"
"-divider <div>           Set the SBus divider value. [1-4096].\n"
"-refclk                  Measure the reference clock\n"
"-interrupt <int> <data>  Invoke <int> with <data>.\n"
);
printf(
"-sbm-ring-diag           Diagnostic dump of SBM to SBM ring communications.\n"
"-sbm-ring-verify         Verify SBM to SBM ring communications.\n"
);

printf(
"-peek-memory <start>-<stop>\n"
"                   Read the SBus Master memory.  Maximum range is [0-9215).\n"
"-poke-memory <start_address>,value[,value]...\n"
"                   Write 16 bit values to memory. Address range is [0-9215).\n"
"                   Address & values may be decimal, hex (0xNN) or octal (0nnn).\n"
);

printf(
"-upload                Upload firmware to SBus master. Use -rev and -build\n"
"                       to specify specific versions.\n"
"-rev <rev>             Firmware revision to upload. Default = %s.\n"
"-build <build>         Firmware build number to upload.\n"
"                         Default <build> varies by device type.\n"
"                       <rev> and <build> are case sensitive.\n"
"-firmware-file <path>  Path of firmware file to upload.\n"
, aapl_default_sbm_firmware_rev);
#if AAPL_ENABLE_ATT
printf(
"\n"
"-read-imem                 Read ASIC temperature program from imem.\n"
"-read-rom-file <filebase>  Read ASIC temperature program from .rom files.\n"
"-read-att-file <file>      Read ASIC temperature program from a humanly readable .att file.\n"
);
printf(
"-write-imem                Write ASIC temperature program to imem.\n"
"-write-rom-file <filebase> Write ASIC temperature program to .rom files.\n"
"-fw-file <file>            Use with -write-rom-file to specify a firmware input file.\n"
"-write-att-file <file>     Write ASIC temperature program to a humanly readable .att file.\n"
"-print-att-state           Print diagnostic info for the SBM ATT execution.\n"
"-chip <chip_num>           Set the chip number to read/write SBM.\n"
);
#endif /* AAPL_ENABLE_ATT */

#if AAPL_ENABLE_EYE_MEASUREMENT
printf(
"\n"
"-eye-options <opts>       1 to disable centering.        Default = 0.\n"
"-eye-start <offset>       Set DAC or PHASE start offset. Default = 0.\n"
"-eye-points <count>       Set points to gather.          Default = 1.\n"
"-eye-step <count>         Set position increment size.   Default = 1.\n"
"-eye-dwell <count>        Set gather bit count.          Default = 1000000.\n"
);
printf(
"-eye-gather-row <row>     Gather errors from row.\n"
"-eye-gather-column <col>  Gather errors from column.\n"
"-eye-gather-mission       Gather errors from mission column.\n"
);
#endif /* AAPL_ENABLE_EYE_MEASUREMENT */

    return 1;
}

static void print_sbm_ring_diag_header(Aapl_t *aapl)
{
    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "         SBM                    vld/ack\n");
    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "  addr -> ID  ring_in  ring_out in  out\n");
}
static void print_sbm_ring_diag_line(Aapl_t *aapl, uint addr)
{
    int ring_id  = avago_spico_int(aapl, addr, 3, 0x04) >> 12;
    int ring_in  = avago_spico_int(aapl, addr, 3, 0x11);
    int ring_out = avago_spico_int(aapl, addr, 3, 0x10);
    if( !aapl_get_spico_running_flag(aapl, addr) )
    {
        printf("ERROR: Firmware not running on %6s.\n", aapl_addr_to_str(addr));
        return;
    }
    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%6s -> %2d   0x%04x  0x%04x   %d%d  %d%d\n",
        aapl_addr_to_str(addr), ring_id, ring_in, ring_out, (ring_in&2)/2, ring_out&1, (ring_out&2)/2, ring_in&1);
}

/** @brief main program for sbus_master subcommand. */
/** */
/** @return 0 on success, > 0 on failure. */

int aapl_sbus_master_main(int argc, char *argv[], Aapl_t *aapl)
{
    /* Set default values: */
    Avago_addr_t addr_struct;
    Avago_addr_t *addr_ptr;
    uint        addr;
    uint        sbm_addr;

    int rstart = -1, rstop = -1;
    int wstart = -1;
    char *wdata = 0;
    BOOL display           = FALSE;
    BOOL reset             = FALSE;
    BOOL sbm_ring_diag     = FALSE;
    BOOL sbm_ring_verify   = FALSE;
    uint divider           = 0;
    int  call_interrupt    = 0;
    BOOL refclk            = FALSE;
    int  upload            = 0;
    uint eye_gather        = 0;
    int att_action         = 0;

#if AAPL_ENABLE_FILE_IO
    const char *fw_build = 0;
    const char *firmware_file_ptr = 0;
#endif /* AAPL_ENABLE_FILE_IO */

#if AAPL_ENABLE_ATT
    /* Options to read and write ASIC Temperature Tables: */
    BOOL read_imem = FALSE;
    BOOL write_imem = FALSE;
    char *input_rom_file = 0;
    char *output_rom_file = 0;
    char *input_temp_file = 0;
    char *output_temp_file = 0;
    char *fw_file = 0;
    int chip = 0;
    BOOL print_sbm_state = FALSE;
#endif /* AAPL_ENABLE_ATT */
    int rc, index = 0;

#if AAPL_ENABLE_EYE_MEASUREMENT
    int eye_options = 0;
    int eye_start = 0;
    uint eye_points = 1;
    uint eye_step = 1;
    bigint eye_dwell = 1000000;
#endif /* AAPL_ENABLE_EYE_MEASUREMENT */

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"display",            0, NULL, 'D'}, /* Display sbus master/controller info */
        {"peek-memory",        1, NULL, 'x'}, /* directly read sbus master memory */
        {"poke-memory",        1, NULL, 'X'}, /* directly write sbus master memory */
        {"interrupt",          0, NULL,  36}, /* Execute interrupt */
        {"divider",            1, NULL, 'V'}, /* Set sbus divider value */
        {"reset",              0, NULL, 'r'}, /* */
        {"refclk",             0, NULL, 'R'}, /* Measure refclk */
        {"sbm-ring-diag",      0, NULL,  20}, /* Diagnostic dump of SBM ring */
        {"sbm-ring-verify",    0, NULL,  21}, /* Diagnostic dump of SBM ring */
#if AAPL_ENABLE_EYE_MEASUREMENT
        {"eye-options",        1, NULL, 129}, /* Set options. */
        {"eye-start",          1, NULL, 130}, /* Set DAC or PHASE start */
        {"eye-points",         1, NULL, 131}, /* Set points to gather */
        {"eye-step",           1, NULL, 132}, /* Set points to gather */
        {"eye-dwell",          1, NULL, 133}, /* Set points to gather */
        {"eye-gather-row",     1, NULL, 134}, /* Gather errors from row */
        {"eye-gather-column",  1, NULL, 135}, /* Gather errors from column */
        {"eye-gather-mission", 0, NULL, 136}, /* Do mission column gather */
#endif /* AAPL_ENABLE_EYE_MEASUREMENT */

#if AAPL_ENABLE_FILE_IO
        {"upload",             0, NULL, 190}, /* Upload SBM SPICO firmware file */
        {"rev",                1, NULL, 191}, /* Load specific firmware revision */
        {"build",              1, NULL, 192}, /* Load specific firmware build */
        {"firmware-file",      1, NULL, 193}, /* Load full firmware file path */
#if AAPL_ENABLE_ATT
        {"read-imem",          0, NULL, 201},
        {"write-imem",         0, NULL, 202},
        {"read-rom-file",      1, NULL, 203},
        {"write-rom-file",     1, NULL, 204},
        {"read-att-file",      1, NULL, 205},
        {"write-att-file",     1, NULL, 206},
        {"fw-file",            1, NULL, 207},
        {"chip",               1, NULL, 208},
        {"print-att-state",    0, NULL, 209},
#endif /* AAPL_ENABLE_ATT */
#endif /* AAPL_ENABLE_FILE_IO */

        {0,             0, NULL, 0}
    };

    aapl_addr_list_from_str(aapl, &addr_struct, "*:*:fd");
    if( aapl_common_main_options(aapl, argc, argv, &addr_struct) < 0 )
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_sbus_master_help();
    }
    addr = avago_struct_to_addr(&addr_struct);
    sbm_addr = avago_make_sbus_master_addr(addr);
    if( addr_struct.sbus != 0xfd )
        avago_addr_to_struct(sbm_addr, &addr_struct);

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch( rc )
        {
        case 'V': divider = aapl_num_from_str(optarg,name,0); break;
        case 'D': display   = TRUE; break;
        case  20: sbm_ring_diag = TRUE; break;
        case  21: sbm_ring_verify = TRUE; break;
        case  36: call_interrupt = 1; break;
        case 'x': if( !parse_range(optarg,&rstart,&rstop) ) /* PEEK command */
                    aapl_main_error("Invalid range: %s; must be in range of [0-9216).\n", optarg);
                  break;
        case 'X':   /* POKE command */
            {
                char *ptr;
                wstart = aapl_strtol(optarg,&ptr,0);
                if( ptr == optarg || wstart < 0 || wstart >= 9216 ||
                    *ptr == '\0' )
                    aapl_main_error("Write args must start with address in range 0-9216, followed by comma separated data values.\n");
                wdata = ptr;
                break;
            }

        case 'r': reset = TRUE; break;
        case 'R': refclk = TRUE; break;

#if AAPL_ENABLE_EYE_MEASUREMENT
        case 129: eye_options= aapl_num_from_str(optarg,name,0); break;
        case 130: eye_start  = aapl_num_from_str(optarg,name,0); break;
        case 131: eye_points = aapl_num_from_str(optarg,name,0); break;
        case 132: eye_step   = aapl_num_from_str(optarg,name,0); break;
        case 133: eye_dwell  = aapl_num_from_str(optarg,name,0); break;
        case 134: eye_gather = 0xa000 | (0x7ff & aapl_num_from_str(optarg,name,0)); break; /* row */
        case 135: eye_gather = 0xb000 | (0x7ff & aapl_num_from_str(optarg,name,0)); break; /* column */
        case 136: eye_gather = 0xc000; break; /* mission column */
#endif /* AAPL_ENABLE_EYE_MEASUREMENT */

        /* Options to read and write ASIC Temperature Tables: */
#if AAPL_ENABLE_FILE_IO
        case 190: upload = 1; break;
        case 191: upload = 1; aapl_default_sbm_firmware_rev = optarg; break;
        case 192: upload = 1; fw_build = optarg; break;
        case 193: upload = 1; firmware_file_ptr = optarg; break;
#endif /* AAPL_ENABLE_FILE_IO */

#if AAPL_ENABLE_ATT
        case 201: read_imem = TRUE; att_action |= 0x11; break;
        case 202: write_imem = TRUE; break;
        case 203: input_rom_file = optarg; att_action |= 1; break;
        case 204: output_rom_file = optarg; break;
        case 205: input_temp_file = optarg; att_action |= 1; break;
        case 206: output_temp_file = optarg; break;
        case 207: fw_file = optarg; break;
        case 208: chip = aapl_num_from_str(optarg,name,0); break;
        case 209: print_sbm_state = TRUE; att_action |= 2; break;
#endif /* AAPL_ENABLE_ATT */

        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

#if AAPL_ENABLE_ATT
    {
        BOOL att_rd = read_imem || input_rom_file || input_temp_file;
        BOOL att_wr = write_imem || output_rom_file || output_temp_file;
        if( (att_rd && !att_wr) || (!att_rd && att_wr) )
        {
            aapl_log_printf(aapl, AVAGO_ERR, 0, 0, "ASIC Temperature Table actions require one input and one or more output options.\n");
            avago_addr_delete(aapl, &addr_struct);
            return show_sbus_master_help();
        }
    }
#endif /* AAPL_ENABLE_ATT */

    if( rstart < 0 && wstart < 0 && !display && !divider && !upload && !reset && !refclk && !call_interrupt
    && !eye_gather && !sbm_ring_diag && !sbm_ring_verify && !att_action )
    {
        aapl_log_printf(aapl, AVAGO_ERR, 0, 0, "No action selected.\n");
        avago_addr_delete(aapl, &addr_struct);
        return show_sbus_master_help();
    }

    if( call_interrupt && ((argc-optind) != 2) )
    {
        aapl_fail(aapl, 0, 0, "The -interrupt command require two parameters:\n"
                              "    -interrupt <int_num> <int_data>\n");
    }

    if( rstart != -1 || wstart != -1 || display || divider || upload || reset || refclk || call_interrupt
        || eye_gather || sbm_ring_diag || sbm_ring_verify || 0 != (att_action & 0x10) )
    {
        aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
        aapl_get_ip_info(aapl,0);
    }

#if AAPL_ENABLE_EYE_MEASUREMENT
    if( eye_gather )
        sbm_eye_gather(aapl, addr, eye_dwell, eye_start, eye_points, eye_step, eye_gather, eye_options);
#endif /* AAPL_ENABLE_EYE_MEASUREMENT */


    if( call_interrupt )
    {
        BOOL st;
        Avago_addr_t start, stop, next;
        char *ptr0, *ptr1;
        int int_num  = aapl_strtol(argv[optind  ],&ptr0,0);
        int int_data = aapl_strtol(argv[optind+1],&ptr1,0);
        if( *ptr0 != '\0' && *ptr0 != 0xd)
                aapl_fail(aapl, 0, 0, "Extra characters in -interrupt parameter 1: %s\n",argv[optind]);
        if( *ptr1 != '\0' && *ptr1 != 0xd)
                aapl_fail(aapl, 0, 0, "Extra characters in -interrupt parameter 2: %s\n",argv[optind+1]);
        for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, AAPL_BROADCAST_IGNORE_LANE|AAPL_BROADCAST_NO_ITER_SBUS);
             st;
             st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_IGNORE_LANE|AAPL_BROADCAST_NO_ITER_SBUS) )
        {
            uint loop_addr = avago_struct_to_addr(&next);
            int ret = avago_spico_int(aapl, loop_addr, int_num, int_data);
            printf("Interrupt 0x%04x (%d), 0x%04x (%d) executed on SBus address %s -> 0x%x (%d)\n",
                            int_num, int_num, int_data, int_data, aapl_addr_to_str(loop_addr), ret, ret);
        }
    }
    /* No args are allowed beyond options for the following: */
    else if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    if( reset          ) avago_spico_reset(aapl, sbm_addr);
#if AAPL_ENABLE_FILE_IO
    if( upload )
    {
        char firmware_file[512];
        avago_group_expand_broadcast(aapl, &addr_struct);
        avago_serdes_upload_firmware(aapl, &addr_struct, fw_build, firmware_file_ptr, firmware_file, sizeof(firmware_file));
    }
#endif /* AAPL_ENABLE_FILE_IO */

    if( sbm_ring_diag )
    {
        Avago_addr_t *current;
        avago_group_expand_broadcast(aapl, &addr_struct);
        print_sbm_ring_diag_header(aapl);
        for( current = &addr_struct; current; current = current->next )
        {
            uint loop_addr = avago_struct_to_addr(current);
            print_sbm_ring_diag_line(aapl, loop_addr);
        }
    }
    if( sbm_ring_verify )
    {
        uint ring_in_array[AAPL_MAX_RINGS];
        uint loopcheck[AAPL_MAX_RINGS];
        uint chip;

        printf("Verifying SBM ring communications...\n");
        memset(ring_in_array, 0, sizeof(ring_in_array));
        for( chip = 0; chip < aapl->chips; chip++ )
        {
            uint ring, ring_in, ring_addr = 0;

            /* Verify unique ids and that firmware in running on all SBM. */
            /* Then set unique ring_out values on all SBMs. */
            memset(loopcheck, 0, sizeof(loopcheck));
            for( ring = 0; ring < aapl->sbus_rings; ring++ )
            {
                ring_addr = avago_make_addr3(chip, ring, AVAGO_SBUS_MASTER_ADDRESS);
                avago_spico_int(aapl, ring_addr, 0x2e, 0x00);   /* Disable SBM BG temperature action. */
            }
            for( ring = 0; ring < aapl->sbus_rings; ring++ )
            {
                int ring_id;
                ring_addr = avago_make_addr3(chip, ring, AVAGO_SBUS_MASTER_ADDRESS);
                ring_id  = avago_spico_int(aapl, ring_addr, 3, 0x04) >> 12;
                if( !aapl_get_spico_running_flag(aapl,ring_addr) )
                {
                    printf("ERROR: Firmware not running on %6s.", aapl_addr_to_str(ring_addr));
                    break;
                }
                if( ++loopcheck[ring_id] > 1 )
                    printf("SBM Ring IDs must be unique, ID %d is duplicated.\n", ring_id);
                avago_spico_int(aapl, ring_addr, 0x11, 0x10);   /* Set sbm_ring_out address */
                avago_spico_int(aapl, ring_addr, 0x12, (ring_id << 12) | (chip << 8) | (ring << 4));
            }
            if( !aapl_get_spico_running_flag(aapl,ring_addr) )
            {
                printf("  Skipping verification on chip %u.\n", chip);
                continue;
            }

            /* printf("Unique ID check passed on chip %d\n", chip); */

            /* Read the ring_in values on all rings: */
            for( ring = 0; ring < aapl->sbus_rings; ring++ )
            {
                uint ring_addr = avago_make_addr3(chip, ring, AVAGO_SBUS_MASTER_ADDRESS);
                ring_in_array[ring] = avago_spico_int(aapl, ring_addr, 0x3, 0x11);   /* Get sbm_ring_in value */
            }

            memset(loopcheck, 0, sizeof(loopcheck));

            /* Verify and show connectivity through all SBMs: */
            printf("SBM Ring Connections: %s", aapl_addr_to_str(avago_make_addr3(chip,0,AVAGO_SBUS_MASTER_ADDRESS)));
            ring_in = 0;
            for( ring = 0; ring < aapl->sbus_rings; ring++ )
            {
                int ring_out = (ring_in_array[ring_in] >> 4) & 0xf;
                printf(" <-- %s", aapl_addr_to_str(avago_make_addr3(chip,ring_out,AVAGO_SBUS_MASTER_ADDRESS)));
                if( ++loopcheck[ring_in] > 1 )
                    printf("\nERROR: SBM ring on chip %u has multiple loops.\n", chip);
                ring_in = ring_out;
            }
            printf("\n");

            /* Verify all bits: */
            ring_in = 0;
            for( ring = 0; ring < aapl->sbus_rings; ring++ )
            {
                int ring_in_value, ring_out_value;
                uint ring_in_addr = avago_make_addr3(chip, ring_in, AVAGO_SBUS_MASTER_ADDRESS);
                int  ring_out = (ring_in_array[ring_in] >> 4) & 0xf;
                uint ring_out_addr = avago_make_addr3(chip, ring_out, AVAGO_SBUS_MASTER_ADDRESS);

                ring_out_value = 0xfffc;
                avago_spico_int(aapl, ring_out_addr, 0x11, 0x10);   /* Set sbm_ring_out address */
                avago_spico_int(aapl, ring_out_addr, 0x12, ring_out_value); /* Set sbm_ring_out value */
                ring_in_value = avago_spico_int(aapl, ring_in_addr, 0x3, 0x11);   /* Get sbm_ring_in value */
                if( ring_in_value != ring_out_value )   /* verify they are the same */
                    printf("ring_out 0x%x != ring_in 0x%x\n", ring_out_value, ring_in_value);

                ring_out_value = 0;
                avago_spico_int(aapl, ring_out_addr, 0x11, 0x10);   /* Set sbm_ring_out address */
                avago_spico_int(aapl, ring_out_addr, 0x12, ring_out_value); /* Set sbm_ring_out value */
                ring_in_value = avago_spico_int(aapl, ring_in_addr, 0x3, 0x11);   /* Get sbm_ring_in value */
                if( ring_in_value != ring_out_value )   /* verify they are the same */
                    printf("ring_out 0x%x != ring_in 0x%x\n", ring_out_value, ring_in_value);

                ring_in = ring_out;
            }
            {
                uint sbm_addr = avago_make_addr3(chip, 0, AVAGO_SBUS_MASTER_ADDRESS);
                uint ring_count = avago_spico_int(aapl, sbm_addr, 0x27, 0);
                if( ring_count != aapl->sbus_rings )
                    printf("Ring counting failed for %s: Expected %d, got 0x%x\n", aapl_addr_to_str(sbm_addr), aapl->sbus_rings, ring_count);
            }
        }
    }

    if( wstart > 0     ) sbm_poke_memory(aapl, addr, wstart, wdata);
    if( rstart < rstop ) sbm_peek_memory(aapl, addr, rstart, rstop);

#if AAPL_ENABLE_ATT
    if( 0 != (att_action & 0x01) )
    {
        Avago_asic_table_t table;
        Avago_addr_t addr_struct;

        avago_addr_to_struct(sbm_addr, &addr_struct);

        if( read_imem )
        {
            if( !avago_sbm_read_asic_table_from_chip(aapl, chip, &table) )
                aapl_log_printf(aapl, AVAGO_ERR, 0, 0, "Read from chip '%d' failed.\n", chip);
        }
        else if( input_rom_file )
        {
            if( !avago_sbm_read_asic_table_from_rom_files(aapl, &table, input_rom_file) )
                aapl_log_printf(aapl, AVAGO_ERR, 0, 0, "Reading from .rom files '%s' failed.\n", input_rom_file);
        }
        else if( input_temp_file )
        {
            if( !avago_sbm_read_asic_table_from_temperature_file(aapl, &table, input_temp_file) )
                aapl_log_printf(aapl, AVAGO_ERR, 0, 0, "Read from temperature file '%s' failed.\n", input_temp_file);
        }

        if( output_rom_file )
        {
            if( !avago_sbm_write_asic_table_to_rom_files(aapl, &table, fw_file, output_rom_file) )
                aapl_log_printf(aapl, AVAGO_ERR, 0, 0, "Write to .rom file '%s' failed.\n", output_rom_file);
        }
        if( output_temp_file )
        {
            if( !avago_sbm_write_asic_table_to_temperature_file(aapl, &table, output_temp_file) )
                aapl_log_printf(aapl, AVAGO_ERR, 0, 0, "Write to file '%s' failed.\n", output_temp_file);
        }
        if( write_imem )
        {
            if( !avago_sbm_write_asic_table_to_chip(aapl, chip, &table) )
                aapl_log_printf(aapl, AVAGO_ERR, 0, 0, "Write to chip '%d' failed.\n", chip);
        }
        avago_sbm_free_asic_table(aapl, &table);
    }

#endif /* AAPL_ENABLE_ATT */

    avago_group_expand_broadcast(aapl, &addr_struct);
    for( addr_ptr = &addr_struct; addr_ptr; addr_ptr = addr_ptr->next )
    {
        uint addr = avago_struct_to_addr(addr_ptr);
        if( divider > 0    ) avago_sbm_set_sbus_clock_divider(aapl, addr, divider);
        if( refclk         ) printf ("Refclk: %d kHz\n", avago_sbm_get_refclk(aapl, addr));

        if( display )
        {
            printf("SBus divider value: %u\n"
                   "Firmware revision:  sbus_master.0x%04X_%04X\n",
                avago_sbm_get_sbus_clock_divider(aapl, addr),
                avago_sbm_get_firmware_rev(aapl, addr),
                avago_sbm_get_firmware_build_id(aapl, addr));
            aapl_get_return_code(aapl); /* Clear any errors */
        }

#if AAPL_ENABLE_ATT
        if( print_sbm_state )
        {
            int i;
            int temp = avago_spico_int(aapl, addr, 0x2D, 0x84);
            printf("Last sensor address =    :%02x\n",  avago_spico_int(aapl, addr, 0x2D, 0x81));
            printf("Last SerDes address =    :%02x\n",  avago_spico_int(aapl, addr, 0x2D, 0x82));
            printf("Temperature offset  = %6d\n",  (short)avago_spico_int(aapl, addr, 0x2D, 0x83));
            if( aapl_get_process_id(aapl, addr) == AVAGO_TSMC_16 )
                printf("Temperature value   = %6d (%.3f C)\n", temp, temp / 8.0);
            else
            {
                printf("Temperature value   = 0x%04x", temp);
#               if AAPL_ENABLE_07NM_IP
                printf(" (%.2f C)\n", avago_sensor_to_mC(aapl, addr, temp) / 1000.0);
#               endif /* AAPL_ENABLE_07NM_IP */
            }
            printf("PC            = 0x%04x\n",    avago_spico_int(aapl, addr, 0x2D, 0x85));
            printf("Command       =  0x%03x\n",   avago_spico_int(aapl, addr, 0x2D, 0x86));
            printf("Action        = %d\n",        avago_spico_int(aapl, addr, 0x2D, 0x87));
            printf("Update period = %d\n",        avago_spico_int(aapl, addr, 0x2D, 0x88));
            printf("ATT active    = %d\n",        avago_spico_int(aapl, addr, 0x2D, 0x89));
            printf("Slots: %2u", avago_spico_int(aapl, addr, 0x2D, 0x90));
            for( i = 1; i < 16; i++ )
                printf(", %2u", avago_spico_int(aapl, addr, 0x2D, 0x90 + i));
            printf("\n");
        }
#endif /* AAPL_ENABLE_ATT */
    }

    if( aapl->return_code ) printf("ERROR\n");

    rc = aapl->return_code != 0;
    avago_addr_delete(aapl, &addr_struct);
    return rc;
}

/* Figure: SBM CLI commands for ATT I/O: */
/* */
/*                                                -read-imem    +--------+ */
/*                                      +-----------------------|        | */
/*                                      |                       |  SBM   | */
/*                                      |        -write-imem    | Memory | */
/*                                      |   +------------------>|        | */
/*                                      |   |                   +--------+ */
/*                                      V   | */
/*    +-------+    -read-att-file     +-------+    -read-rom    +----------+ */
/*    |       |---------------------->|       |<----------------|          | */
/*    | .att  |                       | AAPL  |                 | .att_bin | */
/*    | file  |    -write-att-file    |       |   -write-rom    |   file   | */
/*    |       |<----------------------|       |---------------->|          | */
/*    +-------+                       +-------+                 +----------+ */
/*                                      |  ^ */
/*                                      |  |       -read-rom    +--------+ */
/*                                      |  +--------------------|        | */
/*                                      |          -fw-file     |   SBM  | */
/*                                      |                       |  .rom  | */
/*                                      |         -write-rom    |  file  | */
/*                                      +---------------------->|        | */
/*                                                              +--------+ */
#endif /* AAPL_ENABLE_MAIN */
