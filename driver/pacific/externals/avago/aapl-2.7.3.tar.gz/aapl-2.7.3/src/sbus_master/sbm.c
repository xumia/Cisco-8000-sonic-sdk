/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* Support for AAPL (ASIC and ASSP Programming Layer) handling of SBus */
/* Master. */

/** Doxygen File Header */
/** @file */
/** @brief SBus Master / Controller functions. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

/** @brief   Gets the SBus clock divider value. */
/** @details The SBus clock frequency is set to the ref clock frequency */
/**          divided by the sbus clock divider. */
/**          Normally, a power of two is used, but this is not required. */
/** @return  On success, returns the SBus clock divider value. */
/**          On error, decrements aapl->return_code and returns -1. */
int avago_sbm_get_sbus_clock_divider(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr)          /**< [in] Device address, only chip & ring parts used. */
{
    int return_code = aapl->return_code;
    int divider = (int)avago_sbus_rd(aapl, addr = avago_make_sbus_controller_addr(addr), 0x0a);

    if( divider & (1 << 7) )    /* If non 2^n clock divider */
    {
        /* Read divider value: */
        divider = avago_sbus_rd(aapl, addr, 0x0b);
        divider++;
    }
    else
    {
        /* convert exponent to value: */
        divider = (divider >= 12) ? 4096 : (1 << divider);
    }
    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus %s, divider %u\n",aapl_addr_to_str(addr),divider);
    return return_code == aapl->return_code ? divider : -1;
}

/** @brief   Sets the SBus clock divider. */
/** @details The SBus clock frequency is the ref clock frequency */
/**          divided by the sbus clock divider. */
/**          Normally, a power of two is used, but this is not required. */
/**          Valid divider range is [1..4096]. */
/** @return  On success, returns 0. */
/**          On error, decrements aapl->return_code and returns -1. */
int avago_sbm_set_sbus_clock_divider(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr,          /**< [in] Device address, only chip & ring parts used. */
    uint divider)       /**< [in] New sbus divider value in range [1-4096]. */
{
    int return_code = aapl->return_code;
    uint exponent;
    addr = avago_make_sbus_controller_addr(addr);

    if( divider == 0 || divider > 4096 )
        return aapl_fail(aapl,__func__,__LINE__,"SBus %s, divider %u is out of valid range [1-4096].\n",aapl_addr_to_str(addr),divider);

    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus %s, divider %u\n",aapl_addr_to_str(addr),divider);

    /* Determine the smallest 2^exponent value > divider: */
    for( exponent = 1; (divider >> exponent) != 0; exponent++ )
        continue;
    if( (divider & (divider - 1)) == 0 ) /* Test if only one bit set in value */
    {
        /* Only one bit set: it was the next smaller exponent. */
        exponent--;
        /* Set bit position (exponent) into register 0x0A [3:0]: */
        avago_sbus_wr(aapl, addr, 0x0a, exponent);
    }
    else
    {
        /* Set arbitrary divider value: */
        avago_sbus_wr(aapl, addr, 0x0a, exponent);            /* Clears bit 7 */
        avago_sbus_wr(aapl, addr, 0x0b, divider - 1);         /* Call before setting bit 7 */
        avago_sbus_wr(aapl, addr, 0x0a, exponent | 0x0080);   /* Set bit 7 */
    }
    return return_code == aapl->return_code ? 0 : -1;
}


/*============================================================================= */
/* SBM GET TEMP DATA */
/** @brief  Gets the temperature data from a given AVAGO_THERMAL_SENSOR temperature probe. */
/** @return Returns the temperature in milli-degrees C. */
/**         On error, returns 999999. */
/** @details Verifies that the process is 28nm, the #sensor_addr is */
/**          AVAGO_THERMAL_SENSOR, and the SBus Master SPICO for the sensor */
/**          is running, then issues the get_temp_data interrupt. */
/**          Takes the resulting 12b signed value and converts it to an integer. */
/** */
/** NOTE: THIS API IS INCOMPLETE AND SUBJECT TO CHANGE IN A FUTURE RELEASE. */
int avago_sbm_get_temperature(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint sensor_addr,   /**< [in] SBus address of the AVAGO_THERMAL_SENSOR */
    uint sensor)        /**< [in] Which sensor to get data for. */
{
    const int invalid_data = 999999;
    int data;
    Avago_addr_t addr_struct;
    uint addr = avago_make_sbus_master_addr(sensor_addr);

    if (!aapl_check_process(aapl, addr, __func__, __LINE__, TRUE, 2, AVAGO_TSMC_16, AVAGO_TSMC_28)) return invalid_data;
    if (!aapl_check_ip_type(aapl, sensor_addr, __func__, __LINE__, TRUE, 1, AVAGO_THERMAL_SENSOR))  return invalid_data;

    if( !avago_spico_running(aapl,addr) )
        return invalid_data;  /* spico not running return a bogus temp */

    avago_addr_to_struct(sensor_addr,&addr_struct);
    data = avago_spico_int(aapl, addr, 0x17, (sensor << 12) | (addr_struct.sbus & 0xff) );
    /* result is a 12b signed value in 1/8 degree increments */
    if( data & 0x8000 )
    {  /* bit[15] indicates result is good */
        data &= 0x0FFF;     /* Mask down to 12b temp value */
        if (data & 0x0800)  /* Negative 12b temp value, do sign extension */
            data = -1 * (((~data) & 0x0FFF) + 1);
        return data * (1000 / 8);   /* Scale to milli-degrees. */
    }
    return invalid_data;  /* Temperature not valid */
}

/** @brief   Write 16 bit data to dmem address mem_addr. */
/** @details Valid addresses are 0-1023 (0x0000-0x03FF). */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */

static int sbm_write_dmem(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] Device address, only chip & ring parts used. */
    uint mem_addr,  /**< [in] Memory location to write. */
    uint data)      /**< [in] 16-bit data to write. */
{
    int return_code = aapl->return_code;
    addr = avago_make_sbus_master_addr(addr);
    avago_spico_int(aapl, addr, 0x0011, mem_addr); /*write the dmem address */
    avago_spico_int(aapl, addr, 0x0012, data);     /*write the dmem data */
    return return_code == aapl->return_code ? 0 : -1;
}

/** @brief   Read the next 16 bit datum. */
/** @details Use with sbm_read_mem to efficiently read a block of memory. */
/** @return  Datum. On failure, aapl->return_code is decremented. */

uint avago_sbm_read_next_mem(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Device address, only chip & ring parts used. */
{
    return avago_spico_int(aapl, avago_make_sbus_master_addr(addr), 0x3, 0x13);
}

/** @brief   Read 16 bit datum from dmem address mem_addr. */
/** @details Valid addresses are 0-9216 (0x0000-0x23ff). */
/**          Use with sbm_read_next_mem to efficiently read a block of memory. */
/** @return  Datum. On failure, aapl->return_code is decremented. */

uint avago_sbm_read_mem(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,     /**< [in] Device address, only chip & ring parts used. */
    uint mem_addr)      /**< [in] Memory location to read. */
{
    sbm_write_dmem(aapl, sbus_addr, 0x12, mem_addr); /* Write mem_addr location into 0x12 */
    return avago_sbm_read_next_mem(aapl, sbus_addr);
}

/** @brief   Writes 16 bit datum to SBusMaster memory. */
/** @details Valid addresses are in the range [0..9215]. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */

int avago_sbm_write_mem(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr,          /**< [in] Device address, only chip & ring parts used. */
    uint mem_addr,      /**< [in] Memory location to write. */
    uint data)          /**< [in] 16-bit data to write. */
{
    int return_code = aapl->return_code;
    if( mem_addr < 1024 )
        return sbm_write_dmem(aapl, addr, mem_addr, data);
    /* Writes to dmem location 0x13 are redirected to the memory location */
    /*   stored in dmem location 0x12.  So we write our xdmem address */
    /*   to location 12.  But to do that, we must set the dmem address (12) */
    /*   using int 0x11.  Since we are writing to dmem addresses 12 and 13 */
    /*   sequentially, we do the write to 12 with auto increment, so the */
    /*   next write goes to 13 and indirectly to xdmem. */
    addr = avago_make_sbus_master_addr(addr);
    avago_spico_int(aapl, addr, 0x11, 0x12);     /* select 0x12 for write */
    avago_spico_int(aapl, addr, 0x13, mem_addr); /* write mem_addr to 0x12++ */
    avago_spico_int(aapl, addr, 0x12, data);     /* write xdmem data to 0x13 */
    return return_code == aapl->return_code ? 0 : -1;
}

/** @cond INTERNAL */

/** @brief Reads a block of SBM imem. */
/** @details Requires that the processor be halted before calling. */
/** @return Returns TRUE on success, FALSE on failure. */
BOOL avago_sbm_imem_read_prehalted(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint sbm_addr,      /**< [in] SBus address of the SBus Master processor. */
    int start,          /**< [in] Address of first imem location to read. */
    int *data,          /**< [out] Output array.  Must be at least length words long. */
    int length)         /**< [in] Number of locations to read. */
{
    int return_code = aapl->return_code;
    int i;
    for( i = 0; i < length; i++ )
    {
        avago_sbus_wr(aapl, sbm_addr, 0x03, start + i);
        data[i] = avago_sbus_rd(aapl, sbm_addr, 0x09) & 0xfff;
    }

    return return_code == aapl->return_code;
}

/** @brief Writes a block of SBM imem. */
/** @details Requires that the processor be halted before calling. */
/** @return On detected error, increments aapl->return_code. */
void avago_sbm_imem_write_prehalted(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint sbm_addr,      /**< [in] SBus address of the SBus Master processor. */
    int imem_addr,      /**< [in] Address of first imem location to write. */
    const int *data,    /**< [in] Data to write. */
    int length)         /**< [in] Number of locations to write. */
{
    int i;
    for( i = 0; i < length; i++ )
        avago_sbus_wr(aapl, sbm_addr, 0x3, (imem_addr + i) | (data[i] << 16) | (1<<31));
}

/** @brief Halts the SBus Master processor for instruction memory access. */
/** @return Returns processor state to be passed to avago_sbm_resume(). */
uint avago_sbm_halt(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint sbm_addr)      /**< [in] SBus address of the SBus Master processor. */
{
    int old_reg5 = avago_sbus_rmw(aapl, sbm_addr, 0x05, 0x01, 0x01);   /* stop processor */
    int old_reg1 = avago_sbus_rmw(aapl, sbm_addr, 0x01, 0x240, 0x2c0); /* Enable IMEM access */
    return (old_reg5 & 0xffff) << 16 | (old_reg1 & 0xffff);
}

/** @brief Resumes the SBus Master processor after being halted. */
void avago_sbm_resume(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint sbm_addr,      /**< [in] SBus address of the SBus Master processor. */
    uint state)         /**< [in] Processor state returned by avago_sbm_halt(). */
{
    avago_sbus_wr(aapl, sbm_addr, 0x01, (state >>  0) & 0xffff);    /* restore reg1 */
    avago_sbus_wr(aapl, sbm_addr, 0x05, (state >> 16) & 0xffff);    /* restore reg5 / resume processor */
}

/** @endcond */

/** @brief Reads a block of SBM imem. */
/** @details Halts the processor during the read. */
/** @return Returns TRUE on success, FALSE on failure. */
BOOL avago_sbm_imem_read(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint sbm_addr,      /**< [in] SBus address of the SBus Master processor. */
    int start,          /**< [in] Address of first imem location to read. */
    int *data,          /**< [out] Caller provided buffer into which to copy the SBM memory. */
    int length)         /**< [in] Number of memory locations to read. */
{
    int return_code = aapl->return_code;
    uint spico_state = avago_sbm_halt(aapl, sbm_addr);
    avago_sbm_imem_read_prehalted(aapl, sbm_addr, start, data, length);
    avago_sbm_resume(aapl, sbm_addr, spico_state);
    return return_code == aapl->return_code;
}

/** @brief Writes a block of SBM imem. */
/** @details Halts the processor during the write. */
/** @return Returns TRUE on success, FALSE on failure. */
BOOL avago_sbm_imem_write(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint sbm_addr,      /**< [in] SBus address of the SBus Master processor. */
    int imem_addr,      /**< [in] Address of first imem location to write. */
    const int *data,    /**< [in] Data to write. */
    int length)         /**< [in] Length of data. */
{
    int return_code = aapl->return_code;
    uint spico_state = avago_sbm_halt(aapl, sbm_addr);
    avago_sbm_imem_write_prehalted(aapl, sbm_addr, imem_addr, data, length);
    avago_sbm_resume(aapl, sbm_addr, spico_state);
    return return_code == aapl->return_code;
}

/** @brief Reads the number of tables appended to the imem firmware image. */
/** @return Returns the number of tables appended to the imem firmware image. */
uint avago_sbm_imem_read_table_count(
    Aapl_t *aapl,       /**< [in] */
    uint sbm_addr)      /**< [in] SBus address of the SBus Master processor. */
{
    int table[4];
    int imem_start = avago_spico_int(aapl, sbm_addr, 0x1c, 0);  /* Get end of program in imem. */

    if( avago_sbm_imem_read(aapl, sbm_addr, imem_start, table, 4) )
    {
        /* Do some validation: */
        if( table[3] == 0 && (table[1] | table[0]) != 0 )
            return table[2];
    }
    return 0;
}

/** @brief   Retrieves the SBus Master firmware revision. */
/** */
/** @return  Firmware revision. On error, aapl->return_code is set negative. */
uint avago_sbm_get_firmware_rev(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Device address, only chip & ring parts used. */
{
    return avago_firmware_get_rev(aapl, avago_make_sbus_master_addr(addr));
}

/** @brief   Retrieves the SBus Master firmware build id. */
/** */
/** @return  Firmware build id. On error, aapl->return_code is set negative. */
uint avago_sbm_get_firmware_build_id(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Device address, only chip & ring parts used. */
{
    return avago_firmware_get_build_id(aapl, avago_make_sbus_master_addr(addr));
}




/** @brief   Gets the DFE round-robin tuning mode for the given ring. */
/** @details Queries SBus master on the given chip and ring for the */
/**          current round-robin configuration. */
/** @return  Returns the number of parallel round-robins tunes enabled. */
/** @return  A return value of 0 indicates that round-robin is disabled. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_sbm_set_dfe_rr_mode(). */
int avago_sbm_get_dfe_rr_mode(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] SBus chip & ring address. */
{
    int return_code = aapl->return_code;
    int rv;

    addr = avago_make_sbus_master_addr(addr);

    /* RR support added in 0x100E and build id with bit 0 set. */
    if( !aapl_check_firmware_rev(aapl,addr, __func__, __LINE__, FALSE, 1, 0x100E) )
        return 0;

    rv = avago_spico_int(aapl, addr, 0x02b, 0x4000);

    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus Master %s round robin parallel tune count is %#04x\n",aapl_addr_to_str(addr),rv & 0xff);
    return return_code == aapl->return_code ? (rv & 0xff) : -1;
}

/** @brief   Sets the DFE round-robin tuning mode for the given ring. */
/** @details Configures the SBus master to continuously run up to count parallel */
/**          tunes on the specified SBus ring.  Only the SerDes which have */
/**          round-robin tuning enabled will participate. */
/**          Set count to 0 to disable round-robin tuning on the ring. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_sbm_get_dfe_rr_mode(). */
int avago_sbm_set_dfe_rr_mode(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] SBus chip & ring address. */
    int count)      /**< [in] Maximum number of parallel tunes. */
{
    int return_code = aapl->return_code;
    int cmd = (count == 0) ? 0 : (0x8000 | count);
    int rv;

    addr = avago_make_sbus_master_addr(addr);

    /* RR support added in 0x100E and build id with bit 0 set. */
    if( !aapl_check_firmware_rev(aapl,addr, __func__, __LINE__, TRUE, 1, 0x100E) )
        return -1;

    if( count < 0 || count > 255 )
        return aapl_fail(aapl,__func__,__LINE__,"SBus Master %s, number of parallel tunes %d is out of valid range [1-255].\n",aapl_addr_to_str(addr),count);

    rv = avago_spico_int (aapl, addr, 0x02b, cmd);
    if( rv != cmd )
        return aapl_fail(aapl,__func__,__LINE__,"SBus Master %s, failed to initialize round robin to %#06x, instead returned 0x%#010x\n",aapl_addr_to_str(addr),cmd,rv);

    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus Master %s, parallel tune count %d\n",aapl_addr_to_str(addr),count);
    return return_code == aapl->return_code ? 0 : -1;
}



#if AAPL_ENABLE_ATT

/* Figure: SBM Internal communications: */
/*                                                                                                 +--------+ */
/*                                                                                                 |        | */
/*                                                       avago_sbm_read_asic_table_from_chip()     |  SBM   | */
/*                                                        avago_sbm_write_asic_table_to_chip()     | Memory | */
/*                                                                        .----------------------->|        | */
/*               avago_sbm_read_asic_table_from_temperature_file()        |                        +--------+ */
/*                                                                        V */
/*    +-------+  parse_file()         +--------+   att_compile()     +--------+                    +----------+ */
/*    |       |---------------------->|        |-------------------->|        |                    |          | */
/*    | .att  |                       | symbol |                     |  ASIC  | same as .rom file  | .att_bin | */
/*    | file  |  print_sensor_list()  |  list  |   att_decompile()   |  table |<------------------>|   file   | */
/*    |       |<----------------------|        |<--------------------|        |                    |          | */
/*    +-------+                       +--------+                     +--------+                    +----------+ */
/*               avago_sbm_write_asic_table_to_temperature_file()         ^ */
/*                                                                        |                        +--------+ */
/*                                                                        `------------------------|        | */
/*                                                     avago_sbm_read_asic_table_from_rom_files()  |   SBM  | */
/*                                                      avago_sbm_write_asic_table_to_rom_files()  |  .rom  | */
/*                                                                                                 |  file  | */
/*                                                                                                 |        | */
/*                                                                                                 +--------+ */
/* */
/* Notes: The .att_bin file is simply a .rom file with only the compiled table, while a .rom */
/*        output by these commands will have the ATT program appended to the SBM image. */
/*        Either can be used for input for accessing the SBM image or the ATT programs. */

#define aapl_malloc_int_array(length) (int *)aapl_malloc(aapl, (length) * sizeof(int), __func__)
#define SBM_DATA_LENGTH(rom) ((rom)[0] << 8 | (rom)[1])
#define SBM_DATA_SIZE(rom) (SBM_DATA_LENGTH(rom) + 5)
#define memcpy_int_array(to,from,len) memcpy(to,from,len*sizeof(int))

/** @brief Creates an empty SBM data image. */
/** @details The returned pointer should be freed by calling aapl_free(). */
/** @return The empty SBM data image.  On malloc error, returns NULL. */
static int *avago_sbm_table_init(Aapl_t *aapl)
{
    int data_size = 4;
    int *sbm_data_image = aapl_malloc_int_array(data_size);
    if( sbm_data_image )
        memset(sbm_data_image, 0, data_size * sizeof(int));
    return sbm_data_image;
}

/** @brief Retrieves the indicated table from the SBM data image. */
/** @return On success, returns a pointer to the table in the given SBM data image and sets *length. */
/** @return If the requested table does not exist, returns NULL. */
static const int *avago_sbm_data_find_table(
    const int *sbm_data_image,  /** [in] SBM data image to access */
    int which,                  /** [in] Which table to return */
    int *length)                /** [out] Length of returned table. */
{
    int table_count = sbm_data_image[2];

    *length = 0;
    if( which < table_count && which >= 0 )
    {
        int image_length = SBM_DATA_LENGTH(sbm_data_image);
        if( image_length >= 6 + 2 * which )
        {
            int offset = 4 + which * 2;
            int start = SBM_DATA_LENGTH(&sbm_data_image[offset]);
            int end = (which == table_count-1) ? image_length : SBM_DATA_LENGTH(&sbm_data_image[offset+2]);
            if( start < image_length && end <= image_length )
            {
                *length = end - start;
                return &sbm_data_image[start];
            }
        }
    }
    return 0;
}

/** @brief Sets the CRC if data has at least one table. */
static void avago_sbm_data_set_crc(int *sbm_data_image)
{
    int sbm_image_length = SBM_DATA_LENGTH(sbm_data_image);
    if( sbm_image_length >= 6 && sbm_data_image[2] >= 1 )
    {
        int crc = 0;
        sbm_image_length += 5;

        /* Calculate CRC from array and set CRC value into array end: */
        sbm_data_image[sbm_image_length-5] = 0x2e;
        crc = aapl_crc_rom(sbm_data_image, sbm_image_length - 4);
        sbm_data_image[sbm_image_length-4] = (crc >>  0) & 0xff;
        sbm_data_image[sbm_image_length-3] = (crc >>  8) & 0xff;
        sbm_data_image[sbm_image_length-2] = (crc >> 16) & 0xff;
        sbm_data_image[sbm_image_length-1] = (crc >> 24) & 0xff;
    }
}

/* Helper function. */
static int avago_sbm_data_append_table(
    int *new_image,         /** [in] SBM data image to add to. */
    int which,              /** [in] Which slot to add to. */
    int write_offset,       /** [in] Offset to write to. */
    int table_length,       /** [in] Length of table. */
    const int *table)       /** [in] Table to add. */
{
    new_image[4 + 2*which] = write_offset >> 8;
    new_image[5 + 2*which] = write_offset & 0xff;
    memcpy_int_array(&new_image[write_offset], table, table_length);
    return table_length;
}

/** @brief Adds a table to the existing SBM data image. */
/** @return The updated SBM data image.  On malloc error, returns NULL. */
static int *avago_sbm_table_add(
    Aapl_t *aapl,               /** [in] */
    const int *sbm_data_image,  /** [in] SBM data image to add to. */
    int table_length,           /** [in] Length of table. */
    const int *table)           /** [in] Table to add. */
{
    int sbm_image_length = SBM_DATA_LENGTH(sbm_data_image);
    int new_image_length = (sbm_image_length==0 ? 6 : sbm_image_length + 2) + table_length;
    int *new_image = aapl_malloc_int_array(new_image_length + 5);
    if( new_image )
    {
        int which;
        int write_offset;
        new_image[0] = new_image_length >> 8;
        new_image[1] = new_image_length & 0xff;
        new_image[2] = sbm_data_image[2] + 1;
        new_image[3] = 0;
        write_offset = 4 + 2 * new_image[2];
        for( which = 0; which < sbm_data_image[2]; which++ )
        {
            int tab_length;
            const int *tab = avago_sbm_data_find_table(sbm_data_image, which, &tab_length);
            write_offset += avago_sbm_data_append_table(new_image, which, write_offset, tab_length, tab);
        }
        write_offset += avago_sbm_data_append_table(new_image, sbm_data_image[2], write_offset, table_length, table);
        if( write_offset == new_image_length )
            avago_sbm_data_set_crc(new_image);
        else /* Logic error */
        {
            aapl_free(aapl, new_image, __func__);
            new_image = 0;
        }
    }
    return new_image;
}


/** @brief Writes complete SBM data image to SBM imem */
/** @details Stops any temperature program execution, writes the new program and starts it running. */
/** @return Returns TRUE on successful CRC validation of the written data. */
/** @return Returns FALSE and decrements the aapl->return_code value on failure. */
static BOOL avago_sbm_write_table_to_imem(
    Aapl_t *aapl,
    uint sbm_addr,      /**< [in] Address of SBM to access. */
    const int *sbm_data_image)
{
    int return_code = aapl->return_code;
    int write_start = avago_spico_int(aapl, sbm_addr, 0x1c, 0);  /* Get end of program in imem. */
    int array_len = SBM_DATA_SIZE(sbm_data_image);
    avago_spico_int(aapl, sbm_addr, 0x2D, 0xf);         /* Stop temperature program execution */
    avago_sbm_imem_write(aapl, sbm_addr, write_start, sbm_data_image, array_len);
    if( 1 != avago_spico_int(aapl, sbm_addr, 0x1a, 0) )
        aapl->return_code--;
    else
        avago_spico_int(aapl, sbm_addr, 0x2D, 0x0);         /* Start temperature program execution */
    return return_code == aapl->return_code;
}

/** @brief Reads the complete SBM data image from the SBM. */
/** @return On success, returns aapl_malloc'd space with the full image. */
/** @return If no program is loaded, returns NULL. */
static int *avago_sbm_read_table_from_imem(
    Aapl_t *aapl,       /**< [in] */
    uint sbm_addr)      /**< [in] Address of SBM to access. */
{
    int *sbm_data_image;
    int length;
    int table[4];
    int imem_start = avago_spico_int(aapl, sbm_addr, 0x1c, 0);  /* Get end of program in imem. */
    uint spico_state = avago_sbm_halt(aapl, sbm_addr);

    avago_sbm_imem_read_prehalted(aapl, sbm_addr, imem_start, table, 4);
    length = SBM_DATA_LENGTH(table);
    if( length == 0 || table[2] == 0 || table[3] != 0 )
    {
        sbm_data_image = 0;
    }
    else
    {
        length += 5;
        sbm_data_image = aapl_malloc_int_array(length);
        if( sbm_data_image )
            avago_sbm_imem_read_prehalted(aapl, sbm_addr, imem_start, sbm_data_image, length);
    }
    avago_sbm_resume(aapl, sbm_addr, spico_state);
    return sbm_data_image;
}

/** @brief    Finds the offset to the end of the SBM image, ignoring any appended data. */
/** @details  Looks for the image checksum. */
/** @returns  Returns the length of the SBM image or 0 if the file does not contain an SBM image, or on error. */
static int find_sbm_data_image_offset(
    Aapl_t *aapl,
    const char *filename)
{
    int ret = 0;
    int rom_size, *rom;
    if( 0 == avago_load_rom_from_file(aapl, filename, &rom_size, &rom) )
    {
        int *ptr = rom + rom_size;

        if( SBM_DATA_SIZE(rom) == rom_size && rom[3] == 0 )
            return 0;   /* File only has a table. */

        while( --ptr > rom )
        {
            if( *ptr == 0x2e || *ptr == 0x4e )    /* If SNAP or SPICO nop instruction */
            {
                /* see if checksum matches.  If so, we are done. */
                int crc = aapl_crc_rom(rom, ptr - rom + 1);
                if( (ptr[1] == ((crc >>  0) & 0xff)) &&
                    (ptr[2] == ((crc >>  8) & 0xff)) &&
                    (ptr[3] == ((crc >> 16) & 0xff)) &&
                    (ptr[4] == ((crc >> 24) & 0xff)) )
                {
                    /* We have found the end! */
                    ret = (ptr - rom) + 5;
                    break;
                }
            }
        }

        aapl_free(aapl, rom, __func__);
    }
    return ret;
}


/** @brief Appends an SBM data image to end of program image in a .rom file.  If a data image is already present, it is replaced. */
/** @return Returns TRUE on successful writing of the image. */
/** @return Returns FALSE and decrements the aapl->return_code value on failure. */
static BOOL avago_sbm_write_table_to_rom_file(
    Aapl_t *aapl,               /**< [in] */
    const int *sbm_data_image,  /**< [in] SBM data image */
    const char *sbm_rom_file,   /**< [in] Input SBM firmware image file. */
    const char *filename)       /**< [in] File to create or overwrite with the combined image. */
{
    int data_offset = sbm_rom_file ? find_sbm_data_image_offset(aapl, sbm_rom_file) : 0;
    int sbm_data_image_size = SBM_DATA_SIZE(sbm_data_image);
    FILE *file;
    int alloc_length = data_offset + sbm_data_image_size;
    int *new_rom = aapl_malloc_int_array(alloc_length);
    int i;

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "sbm_rom_file = %s, output_file = %s, data_offset = %d\n", sbm_rom_file ? sbm_rom_file : "NULL", filename, data_offset);

    if( !new_rom )
        return aapl_fail(aapl, __func__, __LINE__, "## Allocation error\n");

    /* Read the SBM FW image into output array. */
    if( data_offset > 0 )
    {
        int rom_size, *rom;
        if( 0 == avago_load_rom_from_file(aapl, sbm_rom_file, &rom_size, &rom) )
        {
            memcpy_int_array(new_rom, rom, data_offset);
            aapl_free(aapl, rom, __func__);
        }
    }

    file = 0==strcmp(filename,"-") ? stdout : fopen(filename, "wb+");
    if( !file )                         /* Alert user to any read issues */
        return aapl_fail(aapl, __func__, __LINE__, "## ERROR opening file %s: %s\n",filename,strerror(errno));

    /* Append the SBM data image: */
    memcpy_int_array(&new_rom[data_offset], &sbm_data_image[0], sbm_data_image_size);

    /* Write the whole result to the output file: */
    for( i = 0; i < alloc_length; i++ )
        fprintf(file, "%03x\n", new_rom[i]);

    aapl_free(aapl, new_rom, __func__);

    return file == stdout || 0 == fclose(file);
}

/** @brief Reads the SBM data image from the .rom file. */
/** @return On success, returns aapl_malloc'd space with the full image. */
/** @return Returns NULL if no ATT program or other error. */
static int *avago_sbm_read_table_from_rom_file(
    Aapl_t *aapl,
    const char *filename)
{
    int data_offset = find_sbm_data_image_offset(aapl, filename);
    int rom_size, *rom;
    if( 0 == avago_load_rom_from_file(aapl, filename, &rom_size, &rom) )
    {
        int *table = 0;
        if( data_offset == 0 )
            return rom;
        if( rom_size - data_offset > 5 )
        {
            int alloc_len = (rom_size - data_offset + 1);
            table = aapl_malloc_int_array(alloc_len);
            memcpy_int_array(table, rom+data_offset, alloc_len);
        }
        aapl_free(aapl, rom, __func__);
        return table;
    }
    return 0;
}

/** @brief   Frees the ASIC Temperature Table contents. */
/** @details Does not free the structure itself so it can be a stack object. */
void avago_sbm_free_asic_table(
    Aapl_t *aapl,                   /**< [in] */
    Avago_asic_table_t *asic_table) /**< [in,out] ASIC output structure. */
{
    int ring;
    for( ring = 0; ring < asic_table->rings; ring++ )
        if( asic_table->table[ring] )
            aapl_free(aapl, asic_table->table[ring], __func__);
}

/** @brief Reads the ASIC Temperature Table from a chip. */
/** @details Loads table from each ring's SBus Master. */
/** @return On success, populates the output table and returns TRUE.  Else returns FALSE. */
BOOL avago_sbm_read_asic_table_from_chip(
    Aapl_t *aapl,                   /**< [in] */
    uint chip,                      /**< [in] Chip number to access. */
    Avago_asic_table_t *asic_table) /**< [out] ASIC output structure. */
{
    int ring;

    memset(asic_table,0,sizeof(*asic_table));
    asic_table->rings = aapl->sbus_rings;

    for( ring = 0; ring < asic_table->rings; ring++ )
    {
        uint sbm_addr = avago_make_addr3(chip, ring, AVAGO_SBUS_MASTER_ADDRESS);
        asic_table->table[ring] = avago_sbm_read_table_from_imem(aapl, sbm_addr);
    }
    return TRUE;
}

/* If there is only one asic table entry, it is entry 0 and entry 0 has a push or pop, then this is a generic program to upload to all rings. */
static BOOL is_generic_att(const Avago_asic_table_t *asic_table)
{
    if( asic_table->table[0] && asic_table->rings == 1 )
    {
        int i, length;
        const int *pgm2 = avago_sbm_data_find_table(asic_table->table[0], 1, &length);

        for( i = 0; i < length; i++ )
        {
            int opcode = pgm2[i];
            if( ((opcode & 0x3f0) == 0x310) || ((opcode & 0x3f0) == 0x320) )
                return TRUE;
        }
    }
    return FALSE;
}

/** @brief Writes the ASIC Temperature Table to a chip. */
/** @details Loads table into each ring's SBus Master. */
/** @return On success, returns TRUE.  Else returns FALSE. */
BOOL avago_sbm_write_asic_table_to_chip(
    Aapl_t *aapl,                           /**< [in] */
    uint chip,                              /**< [in] Chip number to access. */
    const Avago_asic_table_t *asic_table)   /**< [in] ASIC input structure. */
{
    BOOL status = TRUE;
    int ring;
    BOOL generic_att = is_generic_att(asic_table);
    int ring_count = generic_att ? (int)aapl->sbus_rings : asic_table->rings;

    for( ring = 0; ring < ring_count; ring++ )
    {
        uint sbm_addr = avago_make_addr3(chip, ring, AVAGO_SBUS_MASTER_ADDRESS);
        if( generic_att )
            status &= avago_sbm_write_table_to_imem(aapl, sbm_addr, asic_table->table[0]);
        else if( asic_table->table[ring] )
            status &= avago_sbm_write_table_to_imem(aapl, sbm_addr, asic_table->table[ring]);
    }
    return status;
}

/** @brief Generates name and returns aapl_malloc() space. */
static char *generate_ring_file_name(Aapl_t *aapl, const char *base, int ring)
{
    int buffer_length = strlen(base) + 32;
    char *path = (char *)aapl_malloc(aapl, buffer_length, __func__);
    snprintf(path, buffer_length, "%s_ring_%d", base, ring);    /* Generate ring-specific name. */
    return path;
}

/** @brief Loads ASIC Temperature Table information from a set of ROM files. */
/** @return On success, returns TRUE.  Else returns FALSE. */
BOOL avago_sbm_read_asic_table_from_rom_files(
    Aapl_t *aapl,                   /**< [in] */
    Avago_asic_table_t *asic_table, /**< [out] ASIC structure to populate. */
    const char *basepath)           /**< [in] Basepath for input files. */
{
    int ring;

    memset(asic_table,0,sizeof(*asic_table));
    for( ring = 0; ring < AAPL_MAX_RINGS; ring++ )
    {
        FILE *file;
        char *path = generate_ring_file_name(aapl, basepath, ring); /* Generate ring-specific name. */
        asic_table->table[ring] = 0;
        if( (file = fopen(path, "r")) != NULL )
        {
            fclose(file);
            asic_table->table[ring] = avago_sbm_read_table_from_rom_file(aapl, path);
            asic_table->rings = ring+1;
        }
        aapl_free(aapl, path, __func__);
    }
    if( asic_table->rings == 0 )
    {
        FILE *file;
        if( (file = fopen(basepath, "r")) != NULL )
        {
            fclose(file);
            asic_table->table[0] = avago_sbm_read_table_from_rom_file(aapl, basepath);
            asic_table->rings = 1;
        }
    }
    return asic_table->rings > 0;
}

/** @brief Creates a set of ROM files containing SBM firmware and ring-specific ASIC Temperature Table programs. */
/** @details If no SBM ROM file is given, only the ring-specific temperature tables are output. */
/** @return On success, returns TRUE.  Else returns false. */
BOOL avago_sbm_write_asic_table_to_rom_files(
    Aapl_t *aapl,                           /**< [in] */
    const Avago_asic_table_t *asic_table,   /**< [in] ASIC structure to write. */
    const char *sbm_rom_file,               /**< [in] Input .rom file containing SBM image. */
    const char *basepath)                   /**< [in] Basepath for output files. */
{
    BOOL status = TRUE;
    int ring;

    if( asic_table->rings == 1 )
    {
        return avago_sbm_write_table_to_rom_file(aapl, asic_table->table[0], sbm_rom_file, basepath);
    }

    for( ring = 0; ring < asic_table->rings; ring++ )
    {
        if( asic_table->table[ring] )
        {
            char *path = generate_ring_file_name(aapl, basepath, ring); /* Generate ring-specific name. */
            status &= avago_sbm_write_table_to_rom_file(aapl, asic_table->table[ring], sbm_rom_file, path);
            aapl_free(aapl, path, __func__);
        }
    }
    return status;
}

typedef struct avago_serdes_entry_t
{
    uint serdes_addr;
    short temp_offset;
    short serdes_type;
    struct avago_serdes_entry_t *next;
} Avago_serdes_entry_t;

typedef struct avago_sensor_t
{
    uint select;    /* SBus address and lane field = sensor select.  0 == none determined. */
    BOOL init;      /* TRUE if should initialize IP at SBM startup. */
    short slot;     /* 0-15, -1 == none determined.  Used during code generation. */
    short offset;   /* Current offset value. Used during code generation. */
    short periodic; /* Update period, 0 if none specified. */
    Avago_serdes_entry_t *serdes;
    struct avago_sensor_t *next;
} Avago_sensor_t;

/** @brief Allocates and initializes the object. */
static Avago_sensor_t *new_sensor(Aapl_t *aapl)
{
    Avago_sensor_t *sensor = (Avago_sensor_t *)aapl_malloc(aapl, sizeof(Avago_sensor_t), __func__);
    memset(sensor, 0, sizeof(Avago_sensor_t));
    sensor->slot = -1;
    return sensor;
}

/** @brief Deinitializes and frees the sensor. */
static void delete_sensor(Aapl_t *aapl, Avago_sensor_t *sensor)
{
    if( sensor )
    {
        Avago_serdes_entry_t *serdes = sensor->serdes;
        while( 0 != (serdes = sensor->serdes) )
        {
            sensor->serdes = serdes->next;
            aapl_free(aapl, serdes, __func__);
        }
        aapl_free(aapl, sensor, __func__);
    }
}

/** @brief Deinitializes and frees the sensor and all referenced sensors in the "next" list. */
static void delete_sensor_list(Aapl_t *aapl, Avago_sensor_t *list)
{
    while( list )
    {
        Avago_sensor_t *sensor = list;
        list = list->next;
        delete_sensor(aapl, sensor);
    }
}

/** @brief Creates and adds an Avago_serdes_entry_t to the serdes list in sensor. */
static void sensor_add_serdes(Aapl_t *aapl, Avago_sensor_t *sensor, uint serdes_addr, int serdes_type, int temp_offset)
{
    Avago_serdes_entry_t *serdes = (Avago_serdes_entry_t *)aapl_malloc(aapl, sizeof(Avago_serdes_entry_t), __func__);
    serdes->serdes_addr = serdes_addr;
    serdes->temp_offset = temp_offset;
    serdes->serdes_type = serdes_type;
    serdes->next = 0;

    if( !sensor->serdes )
        sensor->serdes = serdes;    /* Add first serdes to list */
    else
    {
        /* Find last entry in list */
        Avago_serdes_entry_t *last = sensor->serdes;
        while( last->next )
            last = last->next;
        last->next = serdes;        /* Add to end of list */
    }
}

/* Appends new sensor to end of list if not already present. */
/* Returns selected sensor, creating it if necessary. */
static Avago_sensor_t *find_add_sensor(Aapl_t *aapl, Avago_sensor_t **list, uint select, BOOL init)
{
    Avago_sensor_t *end = *list, *sensor;
    for( sensor = *list; sensor; sensor = sensor->next )
    {
        if( sensor->select == select && init == sensor->init )
            return sensor;
        end = sensor;
    }
    sensor = new_sensor(aapl);
    sensor->select = select;
    sensor->init = init;
    if( end )
        end->next = sensor; /* Add at end of list */
    else
        *list = sensor;     /* Start list */
    return sensor;
}

static Avago_sensor_t *find_add_slot(Aapl_t *aapl, Avago_sensor_t **list, int slot)
{
    Avago_sensor_t *end = *list, *sensor;
    for( sensor = *list; sensor; sensor = sensor->next )
    {
        if( sensor->slot == slot )
            return sensor;
        end = sensor;
    }
    sensor = new_sensor(aapl);
    sensor->slot = slot;
    if( end )
        end->next = sensor; /* Add at end of list */
    else
        *list = sensor;     /* Start list */
    return sensor;
}

static int tokenize(char *line, char **tok_array, int tok_array_size)
{
    int i;
    char *ptr = line;
    char *saveptr;

    line[strcspn(line, "#\n\r")] = '\0';    /* Strip comments, trailing newline */
    for( i = 0; i < tok_array_size; i++ )
    {
        if( (tok_array[i] = aapl_strtok_r(ptr, " \t", &saveptr)) == 0 )
            return i;
        ptr = NULL;
    }
    return 0;
}

/** @brief Print the sensor list to file. */
/** @see   parse_file(), att_decompile(). */
static void print_sensor_list(FILE *file, Avago_sensor_t *list)
{
    Avago_sensor_t *sensor;
    int periodic = 0;
    int init_type = -1;

    for( sensor = list; sensor; sensor = sensor->next )
    {
        Avago_serdes_entry_t *serdes;
        int offset = 1000;
        if( init_type != sensor->init )
        {
            init_type = sensor->init;
            if( init_type )
            {
                Avago_addr_t addr_struct;
                avago_addr_to_struct(sensor->select, &addr_struct);
                fprintf(file,"\n");
                fprintf(file,"# Initialization commands for Thermal Sensors:\n");
                fprintf(file,"#\n");
                fprintf(file,"# periodic <period>             # Set update period.  Range: [0..15]\n");
                fprintf(file,"# thermal_init <ring>:<sbus>    # Initialize Thermal Sensor IP.\n");
                fprintf(file,"#     If <sbus> is '0', initialize the first Thermal Sensor on the ring.\n");
             /* fprintf(file,"#     If <sbus> is '*', initialize all Thermal Sensors on the ring.\n"); */
                fprintf(file,"#     If <ring> is '*', create a generic initialization that will run on any ring.\n");
                fprintf(file,"\n");
            }
            else
            {
                fprintf(file,"\n");
                fprintf(file,"# Periodic commands for Thermal Sensors:\n");
                fprintf(file,"#\n");
                fprintf(file,"# thermal <ring>:<sbus>.<probe>\n");
                fprintf(file,"#     offset     <offset>       # in whole degrees C.\n");
                fprintf(file,"#     bh_serdes  <ring>:<sbus>  # Write sensor value + offset\n");
                fprintf(file,"#     d6_serdes  <ring>:<sbus>  #   to SerDes at <ring:sbus>\n");
            /*  fprintf(file,"#     os_serdes  <ring>:<sbus>\n"); */
            /*  fprintf(file,"#     m4_serdes  <ring>:<sbus>  # 16nm only.\n"); */
                fprintf(file,"#     If <sbus> is '*', write to all selected SerDes on the given ring.\n");
                fprintf(file,"#     If <ring> is '*', write to all selected SerDes on all rings.\n");
                fprintf(file,"\n");
            }

        }
        if( sensor->init )
        {
            if( sensor->periodic != periodic )
            {
                fprintf(file,"periodic %d\n", sensor->periodic);
                periodic = sensor->periodic;
            }
            fprintf(file,"thermal_init %s\n", aapl_addr_to_str(sensor->select));
        }
        else
        {
            fprintf(file,"thermal %s\n", aapl_addr_to_str(sensor->select));
        }
        for( serdes = sensor->serdes; serdes; serdes = serdes->next )
        {
            const char *cmd;
            if( serdes->temp_offset != offset )
            {
                offset = serdes->temp_offset;
                fprintf(file,"    offset %d\n", offset);
            }
            switch( serdes->serdes_type )
            {
            case AVAGO_M4:        cmd = "m4_serdes"; break;
            case AVAGO_SERDES:    cmd = "d6_serdes"; break;
            case AVAGO_OSPREY:    cmd = "os_serdes"; break;
            default:
            case AVAGO_BLACKHAWK: cmd = "bh_serdes"; break;
            }

            #if 0
            {  /* I believe this is unnecessary */
                Avago_addr_t addr_struct;
                avago_addr_to_struct(addr, &addr_struct);
                if( addr_struct.sbus == AVAGO_BLACKHAWK_BROADCAST || addr_struct.sbus == AVAGO_OSPREY_BROADCAST || addr_struct.sbus == AVAGO_SERDES_M4_BROADCAST )
                    addr = avago_make_addr3(0, addr_struct.ring, AVAGO_SERDES_BROADCAST);  /* Display type specific broadcast as '*' */
            }
            #endif

            fprintf(file,"    %s %s\n", cmd, aapl_addr_to_str(serdes->serdes_addr));
        }
    }
}

/** @brief  Parses the given ASIC Temperature Table specification file. */
/** @details Stores the results into the Avago_sensor_t list. */
/** @return  Returns TRUE on success. */
/** @see print_sensor_list(), att_compile(). */
static Avago_sensor_t *parse_file(Aapl_t *aapl, const char *filename)
{
    Avago_sensor_t *sensor = 0, *list = 0;
    int offset = 0;
    int periodic = 1;
    FILE *file = fopen(filename, "r");
    int linenum = 0;
    BOOL status = TRUE;
    BOOL have_valid_sensor_probe = FALSE;
    int sensor_line = 0;

    if( !file )
    {
        aapl_fail(aapl, __func__, __LINE__, "%s: failed to open: %s\n", filename, strerror(errno));
        return FALSE;
    }

    for(;;)
    {
        char buf[500];
        char line[100];
        char *tokens[4];
        int token_count;
        char *full_line = fgets(buf, sizeof(buf), file);

        if( !full_line ) break;

        linenum++;

        strncpy(line, full_line, sizeof(line));
        line[sizeof(line)-1] = '\0';
        token_count = tokenize(line, tokens, AAPL_ARRAY_LENGTH(tokens));

        if( token_count == 2 )
        {
            Avago_addr_t addr_struct;
            char *endptr;
            uint addr;
            BOOL is_broadcast_sbus = FALSE;

            addr_struct.lane = 0;   /* To eliminate static analysis warnings. */
            if( aapl_str_to_addr(tokens[1], &endptr, &addr) && *endptr == '\0' )
            {
                avago_addr_to_struct(addr, &addr_struct);
                addr_struct.chip = 0;
                addr = avago_struct_to_addr(&addr_struct);
                if( addr_struct.sbus > AVAGO_MAX_RING_ADDRESS )
                    is_broadcast_sbus = TRUE;
                if( addr_struct.ring >= AAPL_MAX_RINGS && addr_struct.ring != AVAGO_ADDR_BROADCAST )
                {
                    status = FALSE;
                    fprintf(stderr, "%s:%d: error: Ring value is out-of-range.  Expected [0-%d].  Got: %s\n", filename, linenum, AAPL_MAX_RINGS-1, tokens[1]);
                    continue;
                }
            }

            /* NOTE: There is no 7nm Thermal Sensor broadcast address.  So require specific addresses, or use 0 to select first sensor on ring. */
            /* If address given is not a thermal sensor, then operations on it are ignored by SBM code. */
            /* thermal_init <ring>:<sbus>   # Initialize specific sensor on specific <ring>. */
            /* thermal_init <ring>:0        # Initialize first sensor on specific <ring>. */
            /* thermal_init *:0             # Initialize first sensor on ring.  Generic for all rings. */
            /* thermal_init *:<sbus>        # Initialize specific sensor on <ring>.  Generic for all rings. */
            if( 0 == strcmp(tokens[0], "thermal_init") )
            {
                if( *endptr != '\0' )
                {
                    status = FALSE;
                    fprintf(stderr, "%s:%d: error: Expected Thermal sensor SBus address.  Got: %s\n", filename, linenum, tokens[1]);
                    continue;
                }
                if( is_broadcast_sbus || addr_struct.lane != AVAGO_ADDR_IGNORE_LANE )
                {
                    status = FALSE;
                    fprintf(stderr, "%s:%d: error: Cannot specify a broadcast sbus address or a temperature probe number during initialization.  Got: %s\n", filename, linenum, tokens[1]);
                    continue;
                }
                sensor = find_add_sensor(aapl, &list, addr, TRUE);
                offset = 0;
                if( addr_struct.lane <= 8 )
                    have_valid_sensor_probe = TRUE;
                else
                    sensor_line = linenum;
                continue;   /* Success */
            }
            if( 0 == strcmp(tokens[0], "thermal") )
            {
                if( is_broadcast_sbus )
                {
                    status = FALSE;
                    fprintf(stderr, "%s:%d: error: Cannot specify broadcast address when reading temperature.  Got: %s\n", filename, linenum, tokens[1]);
                    continue;
                }
                if( addr_struct.lane > 8 )
                {
                    status = FALSE;
                    fprintf(stderr, "%s:%d: error: Expected sensor probe number \".#\" [0-8] at end of address.  Got: %s\n", filename, linenum, tokens[1]);
                    continue;
                }
                sensor = find_add_sensor(aapl, &list, addr, FALSE);
                offset = 0;
                have_valid_sensor_probe = TRUE;
                continue;   /* Success */
            }
            if( 0 == strcmp(tokens[0], "periodic") )
            {
                periodic = strtol(tokens[1], &endptr, 0);
                if( *endptr != '\0' || periodic > 15 || periodic < 0 )
                {
                    status = FALSE;
                    fprintf(stderr, "%s:%d: error: periodic value out of range: Expected range [0..15]. Got: \"%s %s\"\n", filename, linenum, tokens[0], tokens[1]);
                }
                continue;
            }

            if( !sensor )
            {
                status = FALSE;
                fprintf(stderr, "%s:%d: error: Expected \"thermal\", \"periodic\" or \"thermal_init\".  Got: \"%s %s\"\n", filename, linenum, tokens[0], tokens[1]);
                continue;
            }

            if( 0 == strcmp(tokens[0], "offset") )
            {
                offset = strtol(tokens[1], &endptr, 0);
                if( offset < 32 && offset >= -32 && *endptr == '\0' )
                    continue;   /* Success */
                status = FALSE;
                fprintf(stderr, "%s:%d: error: Valid offset range is [-32..31].  Got: \"%s %s\"\n", filename, linenum, tokens[0], tokens[1]);
                continue;
            }

            if( !have_valid_sensor_probe )
            {
                status = FALSE;
                fprintf(stderr, "%s:%d: error: Thermal sensor address on line %d must specify a probe number.\n", filename, linenum, sensor_line);
                continue;
            }

            if( 0 == strcmp(tokens[0], "bh_serdes") )
            {
                sensor_add_serdes(aapl, sensor, addr, AVAGO_BLACKHAWK, offset);
                continue;   /* Success */
            }
            if( 0 == strcmp(tokens[0], "d6_serdes") )
            {
                sensor_add_serdes(aapl, sensor, addr, AVAGO_SERDES, offset);
                continue;   /* Success */
            }
            if( 0 == strcmp(tokens[0], "os_serdes") )
            {
                sensor_add_serdes(aapl, sensor, addr, AVAGO_OSPREY, offset);
                continue;   /* Success */
            }
            if( 0 == strcmp(tokens[0], "m4_serdes") )
            {
                sensor_add_serdes(aapl, sensor, addr, AVAGO_M4, offset);
                continue;   /* Success */
            }
        }
        else if( token_count == 0 )
            continue;

        /* Warn about unexpected input: */
        fprintf(stderr,"%s:%d: error: Unexpected input: %s\n", filename, linenum, full_line);
        status = FALSE;
    }
    fclose(file);
    if( status )
    {
        for( sensor = list; sensor; sensor = sensor->next )
            sensor->periodic = periodic;
        if( (aapl->debug & 0x210) == 0x210 )
            print_sensor_list(stdout, list);
        return list;
    }
    delete_sensor_list(aapl, list);
    return 0;
}


#define THERMAL(x)      (0x000|(x&0xff))
#define SERDES(x)       (0x100|(x&0xff))
#define OFFSET(x)       (0x200|(x&0x3f))

#define READ(x)         (0x300|(x&0xf))
#define PUSH(x)         (0x310|(x&0xf))
#define POP(x)          (0x320|(x&0xf))
#define SET_PERIODIC(x) (0x330|(x&0xf))
#define RUN_PROGRAM(x)  (0x340|(x&0xf))

#define WR_BLACKHAWK()  (0x3f0) /* 7nm only */
#define INIT()          (0x3f1)
#define WR_SERDES()     (0x3f2)
#define WR_OSPREY()     (0x3f3)
#define WR_M4()         (0x3f4)
#define END()           (0x3ff)

static int find_max_ring_ref(Avago_sensor_t *list)
{
    Avago_sensor_t *sensor;
    int rings = 0;

    if( list )
        rings = 1;  /* will have at least one entry. */
    for( sensor = list; sensor; sensor = sensor->next )
    {
        Avago_serdes_entry_t *serdes;
        Avago_addr_t addr_struct;
        avago_addr_to_struct(sensor->select, &addr_struct);
        if( rings <= addr_struct.ring && addr_struct.ring != AVAGO_ADDR_BROADCAST )
            rings = addr_struct.ring + 1;
        for( serdes = sensor->serdes; serdes; serdes = serdes->next )
        {
            avago_addr_to_struct(serdes->serdes_addr, &addr_struct);
            if( rings <= addr_struct.ring && addr_struct.ring != AVAGO_ADDR_BROADCAST )
                rings = addr_struct.ring + 1;
        }
    }
    return rings;
}

/** @brief Compile a sensor action list into separate programs for each ring: */
/** @see   att_decompile(), parse_file(). */
static void att_compile(Aapl_t *aapl, Avago_asic_table_t *asic_table, Avago_sensor_t *list)
{
    Avago_sensor_t *sensor;
    int slots_used = 0;
    int i;
    struct ring_state_t
    {
        int *byte_code;
        int *periodic_ptr;
        int *write_ptr;
        int offset;         /* current set value for this ring program. */
        int temp_source;    /* sensor_addr for read sensor, -1-slot for slot number.  -100 for none. */
        int sensor_sbus;    /* Which sbus address has the sensor just read. */
        int ring;           /* Which ring is this? */
    } ring_state[AAPL_MAX_RINGS];

    struct ring_state_t *sensor_ring_state, *serdes_ring_state;

    asic_table->rings = find_max_ring_ref(list);
    /*printf("asic_table->rings = %d\n", asic_table->rings); */

    /* Allocate and initialize arrays: */
    memset(asic_table->table, 0, sizeof(asic_table->table));
    memset(ring_state, 0, sizeof(ring_state));
    for( i = 0; i < asic_table->rings; i++ )
    {
        ring_state[i].byte_code =
        ring_state[i].write_ptr = (int *)aapl_malloc(aapl, sizeof(int) * 500, __func__);
        ring_state[i].offset = 1001;
        ring_state[i].temp_source = -100;
        ring_state[i].sensor_sbus = -1;
        ring_state[i].ring = i;
        *ring_state[i].write_ptr++ = SET_PERIODIC(list->periodic);
    }

    /* Find and emit the initialization programs: */
    for( sensor = list; sensor; sensor = sensor->next )
    {
        if( sensor->init )
        {
            Avago_addr_t sensor_struct;

            avago_addr_to_struct(sensor->select, &sensor_struct);
            for( i = 0; i < asic_table->rings; i++ )
            {
                if( sensor_struct.ring == i || sensor_struct.ring == AVAGO_ADDR_BROADCAST )
                {
                    sensor_ring_state = &ring_state[i];
                    *sensor_ring_state->write_ptr++ = THERMAL(sensor_struct.sbus);  /* Set sensor address. */
                    *sensor_ring_state->write_ptr++ = INIT();
                }
            }
        }
    }

    /* Add RUN_PROGRAM(1) program command to all programs: */
    for( i = 0; i < asic_table->rings; i++ )
    {
        *ring_state[i].write_ptr++ = RUN_PROGRAM(1);
        ring_state[i].periodic_ptr = ring_state[i].write_ptr;
    }

    /* Emit the periodic programs: */
    for( sensor = list; sensor; sensor = sensor->next )
    {
        Avago_serdes_entry_t *serdes;
        Avago_addr_t sensor_struct;

        avago_addr_to_struct(sensor->select, &sensor_struct);
        sensor->offset = 1000;
        sensor->slot = -1;
        sensor_ring_state = &ring_state[sensor_struct.ring == AVAGO_ADDR_BROADCAST ? 0 : sensor_struct.ring];

        if( sensor->init )
            continue;

        /* Output read_sensor command: */
        if( sensor_ring_state->sensor_sbus != sensor_struct.sbus )
        {
            *sensor_ring_state->write_ptr++ = THERMAL(sensor_struct.sbus);  /* Set sensor address. */
            sensor_ring_state->sensor_sbus = sensor_struct.sbus;
        }

        *sensor_ring_state->write_ptr++ = READ(sensor_struct.lane);     /* Select which sensor probe. */
        sensor_ring_state->temp_source = sensor->select;                /* Which sensor do we have */

        /* Output write temperature to serdes commands: */
        for( serdes = sensor->serdes; serdes; serdes = serdes->next )
        {
            Avago_addr_t serdes_struct;
            avago_addr_to_struct(serdes->serdes_addr, &serdes_struct);
            serdes_ring_state = &ring_state[serdes_struct.ring == AVAGO_ADDR_BROADCAST ? 0 : serdes_struct.ring];

            /* Make sure sensor value is available to target SerDes ring: */
            if( serdes_ring_state->temp_source != sensor_ring_state->temp_source )  /* If target is a different ring */
            {
                if( sensor->slot < 0 )                                              /* If not yet pushed sensor value, do it now. */
                {
                    sensor->slot = slots_used++;                                    /* Allocate a slot for remote ring */
                    *sensor_ring_state->write_ptr++ = PUSH(sensor->slot);           /* and push value to it. */
                }
                *serdes_ring_state->write_ptr++ = POP(sensor->slot);                /* Pop temperature on target ring */
                serdes_ring_state->temp_source = sensor_ring_state->temp_source;    /* Remember temperature source on target ring. */
            }
            if( sensor_struct.ring == AVAGO_ADDR_BROADCAST )
            {
                if( sensor->slot < 0 )                                              /* If not yet pushed sensor value, do it now. */
                {
                    sensor->slot = slots_used++;                                    /* Allocate a slot for remote ring */
                    *sensor_ring_state->write_ptr++ = PUSH(sensor->slot);           /* and push value to it. */
                    *serdes_ring_state->write_ptr++ = POP(sensor->slot);                /* Pop temperature on target ring */
                    serdes_ring_state->temp_source = sensor_ring_state->temp_source;    /* Remember temperature source on target ring. */
                }
            }

            /* Set target offset if needed: */
            if( serdes_ring_state->offset != serdes->temp_offset )
            {
                *serdes_ring_state->write_ptr++ = OFFSET(serdes->temp_offset);  /* Set target ring offset value. */
                serdes_ring_state->offset = serdes->temp_offset;                /* Remember offset value on target ring. */
            }

            /* Output type specific broadcast address: */
            if( serdes_struct.sbus == AVAGO_SERDES_D6_BROADCAST )
            {
                switch( serdes->serdes_type )
                {
                case AVAGO_BLACKHAWK: serdes_struct.sbus = AVAGO_BLACKHAWK_BROADCAST; break;
                case AVAGO_OSPREY   : serdes_struct.sbus = AVAGO_OSPREY_BROADCAST;    break;
                case AVAGO_M4       : serdes_struct.sbus = AVAGO_SERDES_M4_BROADCAST; break;
                default:                                                              break;
                }
            }

            /* Write temperature value to selected SerDes: */
            *serdes_ring_state->write_ptr++ = SERDES(serdes_struct.sbus);
            *serdes_ring_state->write_ptr++ = serdes->serdes_type == AVAGO_BLACKHAWK ? WR_BLACKHAWK() :
                                              serdes->serdes_type == AVAGO_OSPREY    ? WR_OSPREY()    :
                                              serdes->serdes_type == AVAGO_M4        ? WR_M4()        : WR_SERDES();
        }
    }
    /* Add END of program command to all non-empty programs: */
    for( i = 0; i < asic_table->rings; i++ )
    {
        int length;

        /* If a periodic program, terminate it: */
        if( ring_state[i].write_ptr != ring_state[i].periodic_ptr )
            *ring_state[i].write_ptr++ = END();         /* Terminate */
        else if( ring_state[i].write_ptr == ring_state[i].byte_code + 2 )
            ring_state[i].write_ptr = ring_state[i].periodic_ptr = ring_state[i].byte_code; /* No program, emit nothing. */

        length = ring_state[i].periodic_ptr - ring_state[i].byte_code;
        if( length > 0 )
        {
            int *byte_code = avago_sbm_table_init(aapl);
            int *byte_code2 = avago_sbm_table_add(aapl, byte_code, length, ring_state[i].byte_code);
            aapl_free(aapl, byte_code, __func__);

            length = ring_state[i].write_ptr - ring_state[i].periodic_ptr;
            asic_table->table[i] = avago_sbm_table_add(aapl, byte_code2, length, ring_state[i].periodic_ptr);
            aapl_free(aapl, byte_code2, __func__);
        }
        else
            asic_table->table[i] = 0;
        aapl_free(aapl, ring_state[i].byte_code, __func__);
    }
}

/** @return Returns TRUE if more byte_codes are present, FALSE on error or after END byte_code displayed. */
static void print_byte_code(Aapl_t *aapl, int cmd)
{
    int cmd2 = cmd >> 8 & 0x03;
    int cmd6 = cmd >> 4 & 0x3f;
    (void)aapl;

    if( cmd2 != 3 ) /* An 8 bit value: */
    {
        if(      cmd2 == 0 ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "THERMAL_ADDRESS(0x%x)\n", cmd & 0xff);
        else if( cmd2 == 1 ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "SERDES_ADDRESS(0x%x)\n", cmd & 0xff);
        else
        {
            int temp_offset  = cmd & 0x7f;
            if( temp_offset & 0x40 )
                temp_offset |= ~0x7f;
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "TEMPERATURE_OFFSET(%d)\n", temp_offset);
        }
    }
    else if( cmd6 != 0x3f ) /* Command with a 4 bit value: */
    {
        if(      cmd6 == 0x30 ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "READ_SENSOR(%d)\n", cmd & 0xf);
        else if( cmd6 == 0x31 ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "PUSH(%d)\n", cmd & 0xf);
        else if( cmd6 == 0x32 ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "POP(%d)\n", cmd & 0xf);
        else if( cmd6 == 0x33 ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "SET_PERIODIC(%d)\n", cmd & 0xf);
        else if( cmd6 == 0x34 ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "RUN_PROGRAM(%d)\n", cmd & 0xf);
        else                    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "UNKNOWN BYTE CODE 0x%x\n", cmd);
    }
    else    /* Command without a value: */
    {
        if(      cmd == 0x3f0 ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "WR_BLACKHAWK\n");
        else if( cmd == 0x3f1 ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "INIT_THERMAL\n");
        else if( cmd == 0x3f2 ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "WR_SERDES\n");
        else if( cmd == 0x3f3 ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "WR_OSPREY\n");
        else if( cmd == 0x3f4 ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "WR_M4\n");
        else if( cmd == 0x3ff ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "END()\n");
        else
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "UNKNOWN BYTE CODE 0x%x\n", cmd);
    }
}

static void print_att_program(Aapl_t *aapl, const int *table)
{
    int which;
    for( which = 0; which < 10; which++ )
    {
        int length, i;
        const int *byte_code = avago_sbm_data_find_table(table, which, &length);
        if( !byte_code )
            break;
        if( which == 0 ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "# Init Program:\n");
        else             aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "# Periodic Program %d:\n", which);
        for( i = 0; i < length; i++ )
        {
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "    ");
            print_byte_code(aapl, byte_code[i]);
        }
    }
}

static uint make_ring_addr(uint addr, uint ring)
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr,&addr_struct);
    addr_struct.ring = ring;
    return avago_struct_to_addr(&addr_struct);
}

/** @brief Decompiles an SBM ASIC temperature table into a sensor structure list. */
/** @see   att_compile(), print_sensor_list(). */
static Avago_sensor_t *att_decompile(Aapl_t *aapl, const Avago_asic_table_t *asic_table)
{
    Avago_sensor_t *sensor = 0, *list = 0;
    int ring;
    uint periodic = 0;
    BOOL temp_pushed = FALSE;
    for( ring = 0; ring < asic_table->rings; ring++ )
    {
        int which;
        uint thermal_addr = 0;
        uint serdes_addr = 0;
        int temp_offset = 1002;

        if( asic_table->table[ring] == 0 )  /* Skip if no table. */
            continue;

        for( which = 0; which < 10; which++ )
        {
            int j, length;
            const int *byte_code = avago_sbm_data_find_table(asic_table->table[ring], which, &length);

            aapl_log_printf(aapl, AVAGO_DEBUG1, 0, 0, "Program for ring %d:\n", ring);
            for( j = 0; j < length; j++ )
            {
                int cmd = byte_code[j];
                int cmd2 = cmd >> 8 & 0x03;
                int cmd6 = cmd >> 4 & 0x3f;

                if( (aapl->debug & 0x240) == 0x240 )
                    print_byte_code(aapl, cmd);

                if( cmd2 != 3 )            /* 2 bit instructions */
                {
                    if(      cmd2 == 0 ) thermal_addr = avago_make_addr3(0, ring, cmd & 0xff);                      /* ring:sbus */
                    else if( cmd2 == 1 ) serdes_addr  = avago_make_addr3(0, ring, cmd & 0xff);                      /* ring:sbus */
                    else               { temp_offset  = cmd & 0x3f; if( temp_offset & 0x20 ) temp_offset |= ~0x3f; } /* value */
                }
                else if( cmd6 != 0x3f )    /* 6 bit instructions */
                {
                    if( cmd6 == 0x30 )      /* Read thermal */
                    {
                        Avago_addr_t addr_struct;
                        avago_addr_to_struct(thermal_addr, &addr_struct);
                        addr_struct.lane = cmd & 0xf;
                        sensor = find_add_sensor(aapl, &list, avago_struct_to_addr(&addr_struct), FALSE);
                        if( periodic )
                            sensor->periodic = periodic;
                    }
                    else if( cmd6 == 0x31 ) { sensor->slot = cmd&0xf; temp_pushed = TRUE; } /* Push to slot */
                    else if( cmd6 == 0x32 ) sensor = find_add_slot(aapl, &list, cmd&0xf);   /* Pop from slot */
                    else if( cmd6 == 0x33 )                                                 /* Set periodic period */
                    {
                        periodic = cmd & 0xf;
/*printf("%d: periodic = %u, sensor->periodic = %d, sensor = %x\n", __LINE__, periodic, sensor ? sensor->periodic : -1, sensor); */
                        if( sensor )
                            sensor->periodic = periodic;
                    }
                    else if( cmd6 == 0x34 ) ; /* printf("    run_table %d\n", cmd & 0xf); */
                    else                    aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Unknown opcode: 0x%x\n", cmd);
                }
                else                                    /* 10 bit instructions */
                {
                    Avago_addr_t addr_struct;
                    avago_addr_to_struct(serdes_addr, &addr_struct);
                    if( addr_struct.sbus > AVAGO_MAX_RING_ADDRESS )
                        serdes_addr = avago_make_addr3(0, addr_struct.ring, AVAGO_SERDES_BROADCAST);

                    if(      cmd == 0x3f0 ) sensor_add_serdes(aapl, sensor, serdes_addr, AVAGO_BLACKHAWK, temp_offset); /* bh_serdes */
                    else if( cmd == 0x3f1 ) /* thermal_init */
                    {
                        sensor = find_add_sensor(aapl, &list, thermal_addr, TRUE);
                        if( periodic )
                            sensor->periodic = periodic;
/*printf("%d: periodic = %u, sensor->periodic = %d, sensor = %x\n", __LINE__, periodic, sensor->periodic, sensor); */
                    }
                    else if( cmd == 0x3f2 ) sensor_add_serdes(aapl, sensor, serdes_addr, AVAGO_SERDES, temp_offset); /* d6_serdes */
                    else if( cmd == 0x3f3 ) sensor_add_serdes(aapl, sensor, serdes_addr, AVAGO_OSPREY, temp_offset); /* os_serdes */
                    else if( cmd == 0x3f4 ) sensor_add_serdes(aapl, sensor, serdes_addr, AVAGO_M4,     temp_offset); /* m4_serdes */
                    else if( cmd == 0x3ff ) break;

                    else if( cmd != 0x3ff ) aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Unknown opcode: 0x%x\n", cmd);
                }
            }
        }
    }
    {
        int rings = find_max_ring_ref(list);
        if( rings == 1 && temp_pushed )  /* In this case, we have a generic program */
        {
            for( sensor = list; sensor; sensor = sensor->next )
            {
                Avago_serdes_entry_t *serdes;
                sensor->select = make_ring_addr(sensor->select, AVAGO_ADDR_BROADCAST);
                for( serdes = sensor->serdes; serdes; serdes = serdes->next )
                    serdes->serdes_addr = make_ring_addr(serdes->serdes_addr, AVAGO_ADDR_BROADCAST);
            }
        }
    }
    return list;
}


/** @brief Reads an ASIC Temperature Table (.att) file. */
/** @return Returns TRUE on successful read and populates asic_table. */
/** @return Returns FALSE and decrements the aapl->return_code value on failure. */
BOOL avago_sbm_read_asic_table_from_temperature_file(
    Aapl_t *aapl,                   /**< [in] */
    Avago_asic_table_t *asic_table, /**< [out] ASIC output structure. */
    const char *filename)           /**< [in] Input file to parse. */
{
    BOOL status = FALSE;
    Avago_sensor_t *sensor_list = parse_file(aapl, filename);

    memset(asic_table, 0, sizeof(*asic_table));
    if( sensor_list )
    {
        /* At this point, we have parsed the input file into a list of sensors and associated serdes with offsets. */
        att_compile(aapl, asic_table, sensor_list);    /* Compile the sensor list into ring-specific programs. */
        delete_sensor_list(aapl, sensor_list);
        status = TRUE;

        /* The following dumps all the compiled byte code: */
        if( (aapl->debug & 0x220) == 0x220 )
        {
            int ring;
            for( ring = 0; ring < asic_table->rings; ring++ )
            {
                if( asic_table->table[ring] )
                {
                    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "# Byte code for ring %d:\n", ring);
                    print_att_program(aapl, asic_table->table[ring]);
                }
            }
        }
    }
    return status;
}

/** @brief Writes the SBM data image to an Asic Temperature Table (.att) file. */
/** @return Returns TRUE on successful write. */
/** @return Returns FALSE and decrements the aapl->return_code value on failure. */
BOOL avago_sbm_write_asic_table_to_temperature_file(
    Aapl_t *aapl,                         /**< [in] */
    const Avago_asic_table_t *asic_table, /**< [in] ASIC output structure. */
    const char *filename)                 /**< [out] Output file to write. */
{
    BOOL status = FALSE;
    Avago_sensor_t *sensor_list = att_decompile(aapl, asic_table);  /* Decompile ring-specific programs into sensor list */
    FILE *file = 0==strcmp(filename,"-") ? stdout : fopen(filename, "w");
    if( file )
    {
        print_sensor_list(file, sensor_list);   /* Output of this is compatible with the .att input text file format. */
        if( file == stdout || 0 == fclose(file) )
            status = 1;
        else
            status = 0;
    }
    if( !status )
        aapl_log_printf(aapl, AVAGO_ERR, __func__, __LINE__, "Cannot open %s for writing: %s\n", filename, strerror(errno));

    delete_sensor_list(aapl, sensor_list);

    return status;
}
#endif /* AAPL_ENABLE_ATT */

#if AAPL_ENABLE_MAIN
#include "timer.h"

/** @brief   Measures the reference clock frequency */
/** @details Uses a counter in the SBus master and a high resolution timer on */
/**          on the machine running AAPL to compute the reference clock frequency. */
/** @return  Returns the reference clock frequency, in kHz. */
int avago_sbm_get_refclk(
    Aapl_t *aapl,
    uint addr)
{
    int loop_count = 0;
    int delay = 7;
    int loops = 0;
    int sbus_div = avago_sbm_get_sbus_clock_divider(aapl, addr);
    int skip_next = 0;
    int time_prev = 0;
    unsigned long first_time = 0;
    unsigned long second_time = 0;
    unsigned long third_time = 0;
    int cism_count = 0;
    int freq = 0;
    int max_cmds = aapl->max_cmds_buffered;
    aapl->max_cmds_buffered = 0; /* to prevent batching */

    while (delay < 31 && loop_count++ < 50)
    {
        long time = 0;  /* Must not be unsigned or chance of core dump */
        unsigned long temp;
        int data = 0;
        int rc;
        int sbc = avago_make_sbus_controller_addr(addr);
        Aapl_microtimer_t timer;
        loops = 0;

        if (!skip_next) delay += 1;
        avago_sbm_set_sbus_clock_divider(aapl, addr, sbus_div); /* sometimes this seems to get reset below, so always write it */

        /* Write all CISM registers as other code may use them: */
        avago_sbus_wr(aapl, sbc, 0x01, delay);
        avago_sbus_wr(aapl, sbc, 0x10, 0xfe); /* send commands to sbc */
        avago_sbus_wr(aapl, sbc, 0x11, 0x01); /* write command */
        avago_sbus_wr(aapl, sbc, 0x12, 0xff); /* write address 0xff (ie do nothing) */
        avago_sbus_wr(aapl, sbc, 0x13, 0x1a); /* write value 0x1a to 0xff (ie do nothing) */
        avago_sbus_wr(aapl, sbc, 0x14, 0x01); /* write command */
        avago_sbus_wr(aapl, sbc, 0x15, 0x13); /* write address 0x13 */
        avago_sbus_wr(aapl, sbc, 0x16, 0xff); /* write value 0xff to 0x13 */

        avago_sbus_wr(aapl, sbc, 0x00, 0x00); /* clear CISM start */
        AAPL_SUPPRESS_ERRORS_PUSH(aapl); /* we may get errors from the HS1 when the CISM completes, so ignore them */
        rc = aapl->return_code;
        aapl_timer_reset(&timer);
        aapl_timer_start(&timer);
        avago_sbus_wr(aapl, sbc, 0x00, 0x01); /* start the CISM */

        while ((temp = aapl_timer_get(&timer)) < 2000000)
        {
            data = avago_sbus_rd(aapl, sbc, 0x13); /* read result */
            if (data == 0xff || data == 0x87 || rc != aapl->return_code) break; /* quit when done or error detected */
            loops++;
        }
        time = (long)aapl_timer_get(&timer); /* get final time */
        AAPL_SUPPRESS_ERRORS_POP(aapl);

        if (skip_next) {skip_next = 0; continue;} /* repeat this delay again if we were to skip */
        if ((data != 0xff || rc != aapl->return_code) || (third_time != 0 && (time-temp) > first_time * 3 / 2))
        {
            skip_next = 1; /* if there was an error, skip the next value to help things settle */
            delay -= 1; /* repeat this delay value */
            aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "Refclk measurement failed: %d %d (%d %d %d) %x\n", rc, aapl->return_code, time, temp, first_time, data);
            continue;
        }

        /* first_time, second_time and third_time are used to find the median */
        /* of the first three accepted round-trip times, as a measure of fixed */
        /* communication overhead, which is used to improve accuracy of the */
        /* cism timer delay measurement. */
        if( first_time == 0 )
            first_time = (time + time_prev) / 2;
        else if( second_time == 0 )
            second_time = (time + time_prev) / 2;
        else if( third_time == 0 )
        {
            third_time = (time + time_prev) / 2;
            if( first_time < second_time && second_time < third_time )
                first_time = second_time;
            else if( first_time > second_time && second_time > third_time )
                first_time = second_time;
            else if( first_time < third_time && third_time < second_time )
                first_time = third_time;
            else if( first_time > third_time && third_time > second_time )
                first_time = third_time;
        }
        time_prev = time;
        time -= first_time;
        if( time < 1000 )
            continue;

        cism_count = (sbus_div << delay); /* + 39500; */

        freq = cism_count / ((time+50) / 100) * 10;

        if (time > 200000) break;
        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Delay setting: %3d Total div: %10d Loops: %3d Time: %5dms Freq: %dkHz\n", delay, cism_count, loops, time_prev/1000, freq);
    }
    aapl->max_cmds_buffered = max_cmds; /* restore value */
    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Delay setting: %3d Total div: %10d Loops: %3d Time: %5dms Freq: %dkHz\n", delay, cism_count, loops, time_prev/1000, freq);
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Refclk freq: %dkHz, Total loop count: %d\n", freq, loop_count);
    return freq;
}

#endif /* AAPL_ENABLE_MAIN */
