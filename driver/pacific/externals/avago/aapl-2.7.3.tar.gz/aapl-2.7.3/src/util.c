/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* AAPL (ASIC and ASSP Programming Layer) "system level" calls (not AVAGO_SERDES, or */
/* SPICO, etc). */

/** Doxygen File Header */
/** @file */
/** @brief System level functions. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#define EQS(str1,str2) (0==strcmp(str1,str2))

/** @brief Print information on the device(s) AAPL is connected to using the AVAGO_INFO log type (which is typically STDOUT). */
/** @details */
/**          As aapl->verbose levels increase, more information is printed */
/** @return void */
void avago_device_info_all(
    Aapl_t *aapl)
{
    Avago_addr_t addr_struct;
    avago_addr_init_broadcast(&addr_struct);
    avago_device_info(aapl, &addr_struct, AVAGO_UNKNOWN_IP);
}

/** @brief Print information on the device(s) AAPL is connected to using the AVAGO_INFO log type (which is typically STDOUT). */
/** @details The addr field selects the device to print info on. */
/**          As aapl->verbose levels increase, more information is printed */
/**          The type input will print info only for the IP type specified.\n */
/** @return void */
void avago_device_info(
    Aapl_t *aapl,
    Avago_addr_t *addr_struct,
    Avago_ip_type_t type)
{
    avago_device_info_options(aapl, addr_struct, type, 0);
}


/** @brief   Deprecated. Please use avago_device_info() instead. */
/** @return void */
void aapl_print_struct(
    Aapl_t *aapl,         /**< [in] Pointer to AAPL structure */
    int verbose,          /**< [in] Verbosity to print (0-2) */
    uint addr,            /**< [in] Address number. */
    Avago_ip_type_t type) /**< [in] ip_type filter (null for none) */
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr, &addr_struct);
    if (verbose >= (int) aapl->verbose) aapl->verbose = verbose;
    avago_device_info(aapl, &addr_struct, type);
}


/** @brief   Return an allocated buffer with library build information. */
/** @details The information returned when detailed is true, includes */
/**          compile date and time, compiler version, size of basic types, */
/**          and the values of AAPL_* configuration defines. */
/** @return  An AAPL_MALLOC() allocated buffer on success. NULL on failure. */
/**          A non-NULL return should be freed by the caller using AAPL_FREE(ret). */
char *aapl_build_info(
    int detailed)       /**< [in]  Set to 1 to get detailed build info. */
                        /**<       Set to 0 to return only AAPL version info. */
                        /**<       Set to 2 to return AAPL version info including build date/time. */
{
    size_t buf_len = 6000;
    char *buf = (char *)AAPL_MALLOC(buf_len);
    char *end = buf + buf_len;
    char *ptr = buf;
    if( buf == NULL )
        return buf;

    if (detailed == 0 || detailed == 2)
    {
        ptr += snprintf(buf, end-ptr,"%s", AAPL_VERSION);
        if (detailed == 0) return buf;
        ptr += snprintf(ptr, end-ptr,"  Compiled: %s %s",__DATE__,__TIME__);
        return buf;
    }

    ptr += snprintf(ptr, end-ptr,"AAPL version: " AAPL_VERSION "\n");
    ptr += snprintf(ptr, end-ptr,"  " AAPL_COPYRIGHT "\n");
    ptr += snprintf(ptr, end-ptr,"  Compiled %s %s using the",__DATE__,__TIME__);

#ifdef __cplusplus
    ptr += snprintf(ptr, end-ptr," %d C++", (int)__cplusplus);
#elif defined(__STDC_VERSION__)
    ptr += snprintf(ptr, end-ptr," %ld C",__STDC_VERSION__);
#elif defined(__STDC__)
    ptr += snprintf(ptr, end-ptr," c89 C");
#else
    ptr += snprintf(ptr, end-ptr," pre-c89 C");
#endif
    ptr += snprintf(ptr,end-ptr," standard.\n");
#if defined(__GNUC__)
    ptr += snprintf(ptr, end-ptr,"  Gnu Compiler revision ");
# if defined(__VERSION__)
    ptr += snprintf(ptr, end-ptr,"%s.\n",__VERSION__);
# elif defined(__GNUC_PATCHLEVEL__)
    ptr += snprintf(ptr, end-ptr,"%d.\n",__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__);
# else
    ptr += snprintf(ptr, end-ptr,"%d.\n",__GNUC__ * 10000 + __GNUC_MINOR__ * 100);
# endif
#elif defined(_MSC_VER)
    ptr += snprintf(ptr, end-ptr,"  Microsoft Visual C version %d.\n",_MSC_VER);
#endif
    ptr += snprintf(ptr, end-ptr,"  sizeof(char)   = %u  ",(uint)sizeof(char));
    ptr += snprintf(ptr, end-ptr,"  sizeof(long)   = %u  ",(uint)sizeof(long));
    ptr += snprintf(ptr, end-ptr,"  sizeof(float)  = %u\n",(uint)sizeof(float));

    ptr += snprintf(ptr, end-ptr,"  sizeof(short)  = %u  ",(uint)sizeof(short));
    ptr += snprintf(ptr, end-ptr,"  sizeof(bigint) = %u  ",(uint)sizeof(bigint));
    ptr += snprintf(ptr, end-ptr,"  sizeof(double) = %u\n",(uint)sizeof(double));

    ptr += snprintf(ptr, end-ptr,"  sizeof(int)    = %u  ",(uint)sizeof(int));
    ptr += snprintf(ptr, end-ptr,"  sizeof(char *) = %u  ",(uint)sizeof(char *));
    ptr += snprintf(ptr, end-ptr,"  sizeof(Aapl_t) = %u\n",(uint)sizeof(Aapl_t));
    ptr += snprintf(ptr, end-ptr,"\n");
    ptr += snprintf(ptr, end-ptr,"AAPL defines during this compile:\n");

#define STRINGIFY(x) #x
#define PRINT_DEFINE(macro) ptr += snprintf(ptr, end-ptr,"  %-38s = %s\n",#macro, STRINGIFY(macro))

#ifdef __STDC_VERSION__
    PRINT_DEFINE(__STDC_VERSION__);
#endif
#ifdef __cplusplus
    PRINT_DEFINE(__cplusplus);
#endif
#ifdef __MINGW_EXTENSION
    PRINT_DEFINE(__MINGW_EXTENSION);
#endif
#ifdef _STDINT_H
    PRINT_DEFINE(_STDINT_H);
#endif

    PRINT_DEFINE(AAPL_ALLOW_AACS);
    PRINT_DEFINE(AAPL_ALLOW_ANSI_COLORS);
    PRINT_DEFINE(AAPL_ALLOW_GPIO_JTAG);
    PRINT_DEFINE(AAPL_ALLOW_GPIO_MDIO);
    PRINT_DEFINE(AAPL_ALLOW_I2C);
    PRINT_DEFINE(AAPL_ALLOW_JTAG);
    PRINT_DEFINE(AAPL_ALLOW_MDIO);
    PRINT_DEFINE(AAPL_ALLOW_OFFLINE_SBUS);
    PRINT_DEFINE(AAPL_ALLOW_SIGNALS);
    PRINT_DEFINE(AAPL_ALLOW_SYSTEM_I2C);
    PRINT_DEFINE(AAPL_ALLOW_THREAD_SUPPORT);
    PRINT_DEFINE(AAPL_ALLOW_THREADED_SBUS);
    PRINT_DEFINE(AAPL_ENABLE_07NM_IP);
    PRINT_DEFINE(AAPL_ENABLE_16NM_IP);
    PRINT_DEFINE(AAPL_ENABLE_28NM_IP);
    PRINT_DEFINE(AAPL_ENABLE_AACS_SERVER);
    PRINT_DEFINE(AAPL_ENABLE_ATE_VEC);
    PRINT_DEFINE(AAPL_ENABLE_ATT);
    PRINT_DEFINE(AAPL_ENABLE_AVSP_1104);
    PRINT_DEFINE(AAPL_ENABLE_AVSP_4412);
    PRINT_DEFINE(AAPL_ENABLE_AVSP_5410);
    PRINT_DEFINE(AAPL_ENABLE_AVSP_7412);
    PRINT_DEFINE(AAPL_ENABLE_AVSP_8801);
    PRINT_DEFINE(AAPL_ENABLE_AVSP_8812);
    PRINT_DEFINE(AAPL_ENABLE_AVSP_9104);
    PRINT_DEFINE(AAPL_ENABLE_AVSP_AUTO_NEG);
    PRINT_DEFINE(AAPL_ENABLE_AVSP_KR_TRAINING);
    PRINT_DEFINE(AAPL_ENABLE_AVSP_STATE);
    PRINT_DEFINE(AAPL_ENABLE_CONSOLE);
    PRINT_DEFINE(AAPL_ENABLE_C_LINKING);
    PRINT_DEFINE(AAPL_ENABLE_DDR3_ETRAIN);
    PRINT_DEFINE(AAPL_ENABLE_DIAG);
    PRINT_DEFINE(AAPL_ENABLE_EEPROM);
    PRINT_DEFINE(AAPL_ENABLE_EFUSE);
    PRINT_DEFINE(AAPL_ENABLE_ESCOPE_MEASUREMENT);
    PRINT_DEFINE(AAPL_ENABLE_EXAMPLES);
    PRINT_DEFINE(AAPL_ENABLE_EYE_MEASUREMENT);
    PRINT_DEFINE(AAPL_ENABLE_FEC);
    PRINT_DEFINE(AAPL_ENABLE_FILE_IO);
    PRINT_DEFINE(AAPL_ENABLE_FLOAT_USAGE);
    PRINT_DEFINE(AAPL_ENABLE_HBM);
    PRINT_DEFINE(AAPL_ENABLE_HS2);
    PRINT_DEFINE(AAPL_ENABLE_MAIN);
    PRINT_DEFINE(AAPL_ENABLE_PS1);
    PRINT_DEFINE(AAPL_ENABLE_SERDES_AUTO_NEG);
    PRINT_DEFINE(AAPL_ENABLE_SERDES_HAL);

    PRINT_DEFINE(AAPL_DEFAULT_COMM_METHOD);
    PRINT_DEFINE(AAPL_DEFAULT_I2C_BASE_ADDR);
    PRINT_DEFINE(AAPL_DEFAULT_MDIO_BASE_PORT_ADDR);
    PRINT_DEFINE(AAPL_DEFAULT_ENABLE_STREAM_LOGGING);
    PRINT_DEFINE(AAPL_DEFAULT_ENABLE_STREAM_ERR_LOGGING);
    PRINT_DEFINE(AAPL_DEFAULT_ENABLE_DEBUG_LOGGING);
    PRINT_DEFINE(AAPL_LOG_BUF_SIZE);
    PRINT_DEFINE(AAPL_LOG_PRINTF_BUF_SIZE);
    #ifdef AAPL_LOG_TIME_STAMPS
    PRINT_DEFINE(AAPL_LOG_TIME_STAMPS);
    #endif
    PRINT_DEFINE(AAPL_MAX_CHIPS);
    PRINT_DEFINE(AAPL_MAX_RINGS);
    PRINT_DEFINE(AAPL_MAX_CMDS_BUFFERED);
    #ifdef AAPL_PROCESS_ID_OVERRIDE
    PRINT_DEFINE(AAPL_PROCESS_ID_OVERRIDE);
    #endif
    PRINT_DEFINE(AAPL_SBUS_MDIO_TIMEOUT);
    PRINT_DEFINE(AAPL_SERDES_INT_TIMEOUT);
    PRINT_DEFINE(AAPL_SERDES_INIT_RDY_TIMEOUT);
    #ifdef AAPL_STREAM
    PRINT_DEFINE(AAPL_STREAM);
    #endif
    #ifdef AAPL_STREAM_ERR
    PRINT_DEFINE(AAPL_STREAM_ERR);
    #endif
    PRINT_DEFINE(AAPL_EXIT(value));
    PRINT_DEFINE(AAPL_FREE(ptr));
    PRINT_DEFINE(AAPL_MALLOC(sz));
    PRINT_DEFINE(AAPL_REALLOC(ptr,sz));
    #ifdef MS_SLEEP
    PRINT_DEFINE(MS_SLEEP(milliseconds));
    #endif
    #ifdef aapl_malloc
    PRINT_DEFINE(aapl_malloc(aapl,sz,caller));
    #endif
    #ifdef aapl_realloc
    PRINT_DEFINE(aapl_realloc(aapl,ptr,sz,caller));
    #endif
    #ifdef aapl_free
    PRINT_DEFINE(aapl_free(aapl,ptr,caller));
    #endif
    PRINT_DEFINE(AAPL_NUMBER_OF_RINGS_OVERRIDE);
    PRINT_DEFINE(AAPL_NUMBER_OF_CHIPS_OVERRIDE);
    #ifdef AAPL_CHIP_ID_OVERRIDE0
    PRINT_DEFINE(AAPL_CHIP_ID_OVERRIDE0);
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE1
    PRINT_DEFINE(AAPL_CHIP_ID_OVERRIDE1);
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE2
    PRINT_DEFINE(AAPL_CHIP_ID_OVERRIDE2);
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE3
    PRINT_DEFINE(AAPL_CHIP_ID_OVERRIDE3);
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE4
    PRINT_DEFINE(AAPL_CHIP_ID_OVERRIDE4);
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE5
    PRINT_DEFINE(AAPL_CHIP_ID_OVERRIDE5);
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE6
    PRINT_DEFINE(AAPL_CHIP_ID_OVERRIDE6);
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE7
    PRINT_DEFINE(AAPL_CHIP_ID_OVERRIDE7);
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE8
    PRINT_DEFINE(AAPL_CHIP_ID_OVERRIDE8);
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE9
    PRINT_DEFINE(AAPL_CHIP_ID_OVERRIDE9);
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE10
    PRINT_DEFINE(AAPL_CHIP_ID_OVERRIDE10);
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE11
    PRINT_DEFINE(AAPL_CHIP_ID_OVERRIDE11);
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE12
    PRINT_DEFINE(AAPL_CHIP_ID_OVERRIDE12);
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE13
    PRINT_DEFINE(AAPL_CHIP_ID_OVERRIDE13);
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE14
    PRINT_DEFINE(AAPL_CHIP_ID_OVERRIDE14);
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE0
    PRINT_DEFINE(AAPL_CHIP_ID_HEX_OVERRIDE0);
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE1
    PRINT_DEFINE(AAPL_CHIP_ID_HEX_OVERRIDE1);
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE2
    PRINT_DEFINE(AAPL_CHIP_ID_HEX_OVERRIDE2);
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE3
    PRINT_DEFINE(AAPL_CHIP_ID_HEX_OVERRIDE3);
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE4
    PRINT_DEFINE(AAPL_CHIP_ID_HEX_OVERRIDE4);
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE5
    PRINT_DEFINE(AAPL_CHIP_ID_HEX_OVERRIDE5);
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE6
    PRINT_DEFINE(AAPL_CHIP_ID_HEX_OVERRIDE6);
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE7
    PRINT_DEFINE(AAPL_CHIP_ID_HEX_OVERRIDE7);
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE8
    PRINT_DEFINE(AAPL_CHIP_ID_HEX_OVERRIDE8);
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE9
    PRINT_DEFINE(AAPL_CHIP_ID_HEX_OVERRIDE9);
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE10
    PRINT_DEFINE(AAPL_CHIP_ID_HEX_OVERRIDE10);
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE11
    PRINT_DEFINE(AAPL_CHIP_ID_HEX_OVERRIDE11);
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE12
    PRINT_DEFINE(AAPL_CHIP_ID_HEX_OVERRIDE12);
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE13
    PRINT_DEFINE(AAPL_CHIP_ID_HEX_OVERRIDE13);
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE14
    PRINT_DEFINE(AAPL_CHIP_ID_HEX_OVERRIDE14);
    #endif

    return buf;
}


/** @brief  Gets the string version of the IP type for the sbus address. */
/** @return The IP type of the sbus device for the current chip and */
/**        sbus ring (specified by the sbus address) */
/**        Returns the aapl->data_char string pointer, which is a C-string holding the command status. */
/**        aapl->data is set to length of the returned string. */
const char *aapl_get_ip_type_str(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    return aapl_ip_type_to_str(aapl_get_ip_type(aapl,addr));
}

/** @brief  Gets the string version of the file name firmware */
/** @return The file name ROM file loaded into sbus device */
/**        chip (specified by the sbus address) */
/**        sbus ring (specified by the sbus address) */
/**        sbus device(specified by the sbus address) */
/**        Returns the aapl->data_char string pointer, which is a C-string holding the command status. */
#if AAPL_ENABLE_FILE_IO
const char *aapl_get_ip_firmware_file_str(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< chip [in] Address number. */
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr, &addr_struct);
    return aapl->firmware_file[addr_struct.chip][addr_struct.ring][addr_struct.sbus];
}
#endif


