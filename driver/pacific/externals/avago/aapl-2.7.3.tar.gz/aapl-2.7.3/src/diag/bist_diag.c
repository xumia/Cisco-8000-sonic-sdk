/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* AAPL (ASIC and ASSP Programming Layer) diagnostics */

/** Doxygen File Header */
/** @file */
/** @brief Functions for API-level diagnostics. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_DIAG

#if AAPL_ENABLE_FILE_IO
BOOL avago_bist_file(Aapl_t *aapl, uint reset, uint sbus_addr_in, uint divider, uint testmask, uint upgrade_warnings, const char *firmware)
{
    BOOL result;
    int rom_size = -1, *rom;
    avago_load_rom_from_file(aapl, firmware, &rom_size, &rom);
    result = avago_bist(aapl, reset, sbus_addr_in, divider, testmask, upgrade_warnings, rom_size, rom);
    aapl_free(aapl, rom, __func__);
    return result;
}
#endif /* AAPL_ENABLE_FILE_IO */


/**============================================================================= */
/** avago_bist */
/** Run BIST tests on various IP. */
/** */
/** @brief TBD: Documentation to be completed */
/** @return TBD: Documentation to be completed */
/** */
BOOL avago_bist(Aapl_t *aapl, uint reset, uint sbus_addr_in, uint divider, uint testmask, uint upgrade_warnings, int rom_size, const int * rom)
{
    BOOL result = TRUE;
    BOOL overall_result = TRUE;
    BOOL st;
    int test = 0;
    char buffer[10]; /* PASSED, FAILED */
    Avago_addr_t addr_struct, start, stop, next;
    avago_addr_to_struct(sbus_addr_in, &addr_struct);
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "AAPL BIST started. AAPL version: " AAPL_VERSION ";  " AAPL_COPYRIGHT "\n");

    aapl->upgrade_warnings = upgrade_warnings;
    while (1)
    {
        result = TRUE; /* pass unless specifically failed below */

        if      (test == 0 && (testmask & (1 << test))) aapl_connect(aapl, 0, 0); 
        else if (test == 1 && (testmask & (1 << test))) aapl_get_ip_info(aapl, reset);
        else if (test == 2 && (testmask & (1 << test))) avago_diag_sbus_rw_test(aapl, 0, 10); /* do a very quick r/w test to see if things are ok */
        /* 3 is below */
        else if (test == 4 && (testmask & (1 << test))) {if (avago_spico_ram_bist(aapl, sbus_addr_in) < 0) result = FALSE;}
        else if (test == 5 && (testmask & (1 << test))) {if (avago_spico_upload(aapl, sbus_addr_in, TRUE, rom_size, rom) < 0) result = FALSE;}
        /* 6 is below */
        else if (test == 7 && (testmask & (1 << test))) aapl_close_connection(aapl);
        else
        { 
            for (st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, 0);
                 st;
                 st = aapl_broadcast_next(aapl, &next, &start, &stop, 0) )
            {
                uint sbus_addr = avago_struct_to_addr(&next);
                if (aapl_get_ip_type(aapl, sbus_addr) != AVAGO_SERDES) continue;

                if (test == 3 && (testmask & (1 << test))) avago_diag_sbus_rw_test(aapl, sbus_addr, 10); /* do a very quick r/w test to each serdes */
                if (test == 5 && (testmask & (1 << test))) if (avago_serdes_init_quick(aapl, sbus_addr, divider)) result = FALSE;
            }
        }

        if (aapl_get_return_code(aapl) < 0) result = FALSE;

        if (!(testmask & (1 << test))) snprintf(buffer, 9, "SKIPPED");
        else if( result )              snprintf(buffer, 9, "PASSED");
        else                           snprintf(buffer, 9, "FAILED");

        if      (test == 0) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "AAPL Connect                                                         %-10s\n", buffer);
        else if (test == 1) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "aapl_get_ip_info                                                     %-10s\n", buffer);
        else if (test == 2) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "SBus read/write test (10 loops) to controller                        %-10s\n", buffer);
        else if (test == 3) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "SBus read/write test (10 loops) to SerDes                            %-10s\n", buffer);
        else if (test == 4) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "SPICO RAM BIST check                                                 %-10s\n", buffer);
        else if (test == 5) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "SPICO firmware upload                                                %-10s\n", buffer);
        else if (test == 6) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "SerDes init test, using divider of %-3d                               %-10s\n", divider, buffer);
        else if (test == 7) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "aapl_close_connection                                                %-10s\n", buffer);
        else break;

        if (!result) overall_result = FALSE; /* if any test fails, fail the overall result */
        test++;
    }

    if( overall_result ) snprintf(buffer, 9, "PASSED");
    else                 snprintf(buffer, 9, "FAILED");
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Avago BIST ran %2d tests. Final result:                               %-10s\n", test, buffer);

    return result;
}

#endif /* AAPL_ENABLE_DIAG */


