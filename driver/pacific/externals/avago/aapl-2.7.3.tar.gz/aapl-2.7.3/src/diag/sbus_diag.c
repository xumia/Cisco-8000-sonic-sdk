/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* AAPL (ASIC and ASSP Programming Layer) diagnostic/test support. */

/** Doxygen File Header */
/** @file */
/** @brief Diagnostics routines for SBus. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_DIAG

#if AAPL_ENABLE_MAIN
#include "timer.h"

void avago_sbus_speed_test(Aapl_t *aapl, uint sbus_addr, int cycles)
{
    long cmd_per_sec;
    int orig_val;
    Aapl_microtimer_t timer;
    int x;
    char data[1000]; /* data used for avago_jtag below */
    Avago_addr_t serdes_addr;

    memset(data, 0x30, sizeof(char) * 1000);
    avago_addr_to_struct(sbus_addr, &serdes_addr);

    /* if a valid address was not passed in, then search for one otherwise use the passed in value */
    if (aapl_get_ip_type(aapl, sbus_addr) != AVAGO_SERDES && aapl_get_ip_type(aapl, sbus_addr) != AVAGO_M4) 
        for (serdes_addr.sbus = 1; serdes_addr.sbus <= AVAGO_MAX_RING_ADDRESS; serdes_addr.sbus++)
            if (aapl_get_ip_type(aapl, avago_struct_to_addr(&serdes_addr)) == AVAGO_SERDES || aapl_get_ip_type(aapl, avago_struct_to_addr(&serdes_addr)) == AVAGO_M4) break; /* look for first serdes */

    /* now check and see if we found a SerDes or not (as not all rings contain serdes) */
    if (aapl_get_ip_type(aapl, avago_struct_to_addr(&serdes_addr)) == AVAGO_SERDES || aapl_get_ip_type(aapl, avago_struct_to_addr(&serdes_addr)) == AVAGO_M4) 
    {
        aapl_timer_reset(&timer);
        aapl_timer_start(&timer);
        for( x = 0; x < cycles; x++ ) avago_spico_int(aapl, avago_struct_to_addr(&serdes_addr), 0x0, 0);
        avago_aacs_flush(aapl);
        cmd_per_sec = (long) ((bigint) cycles * 1000000 / aapl_timer_get(&timer));
        aapl_log_printf (aapl, AVAGO_INFO, __func__, __LINE__, "%10d %-18s %8d cmds/s %8d us/cmd (sent to SBus address: %s)\n", cycles, "SPICO int:", cmd_per_sec, cmd_per_sec ? 1000000/cmd_per_sec : 0, aapl_addr_to_str(avago_struct_to_addr(&serdes_addr)));
    }

    sbus_addr = avago_make_sbus_controller_addr(sbus_addr); /* now send commands to the controller on this ring */
    orig_val = avago_sbus_rd(aapl, sbus_addr, 0x13); /* store original value so we can restore it later */

    aapl_timer_reset(&timer);
    aapl_timer_start(&timer);
    for( x = 0; x < cycles; x++ ) avago_sbus_wr(aapl, sbus_addr, 0x13, x);
    avago_aacs_flush(aapl);
    cmd_per_sec = (long) ((bigint) cycles * 1000000 / aapl_timer_get(&timer));
    aapl_log_printf (aapl, AVAGO_INFO, __func__, __LINE__, "%10d %-18s %8ld cmds/s %8ld us/cmd (sent to SBus address: %s)\n", cycles, "SBus write:", cmd_per_sec, cmd_per_sec ? 1000000/cmd_per_sec : 0, aapl_addr_to_str(sbus_addr));

    aapl_timer_reset(&timer);
    aapl_timer_start(&timer);
    for( x = 0; x < cycles; x++ ) avago_sbus_rmw(aapl, sbus_addr, 0x13, x, !x);
    avago_aacs_flush(aapl);
    cmd_per_sec = (long) ((bigint) cycles * 1000000 / aapl_timer_get(&timer));
    aapl_log_printf (aapl, AVAGO_INFO, __func__, __LINE__, "%10d %-18s %8ld cmds/s %8ld us/cmd (sent to SBus address: %s)\n", cycles, "SBus rmw:", cmd_per_sec, cmd_per_sec ? 1000000/cmd_per_sec : 0, aapl_addr_to_str(sbus_addr));

    aapl_timer_reset(&timer);
    aapl_timer_start(&timer);
    for( x = 0; x < cycles; x++ ) avago_sbus_rd(aapl, sbus_addr, 0x13);
    avago_aacs_flush(aapl);
    cmd_per_sec = (long) ((bigint) cycles * 1000000 / aapl_timer_get(&timer));
    aapl_log_printf (aapl, AVAGO_INFO, __func__, __LINE__, "%10d %-18s %8ld cmds/s %8ld us/cmd (sent to SBus address: %s)\n", cycles, "SBus read:", cmd_per_sec, cmd_per_sec ? 1000000/cmd_per_sec : 0, aapl_addr_to_str(sbus_addr));

    aapl_timer_reset(&timer);
    aapl_timer_start(&timer);
    for( x = 0; x < cycles; x++ ) avago_sbus(aapl, sbus_addr, 0x13, 0x02, 0x00, 0);
    avago_aacs_flush(aapl);
    cmd_per_sec = (long) ((bigint) cycles * 1000000 / aapl_timer_get(&timer));
    aapl_log_printf (aapl, AVAGO_INFO, __func__, __LINE__, "%9d %-18s %8ld cmds/s %8ld us/cmd (sent to SBus address: %s)\n", cycles, "SBus batched read:", cmd_per_sec, cmd_per_sec ? 1000000/cmd_per_sec : 0, aapl_addr_to_str(sbus_addr));

    aapl_timer_reset(&timer);
    aapl_timer_start(&timer);
    for( x = 0; x < cycles; x++ ) avago_jtag(aapl, 0x2b6, 1000, data);
    avago_aacs_flush(aapl);
    cmd_per_sec = (long) ((bigint) cycles * 1000 * 1000 / aapl_timer_get(&timer));
    aapl_log_printf (aapl, AVAGO_INFO, __func__, __LINE__, "%9d %-18s %8ld kbits/s %7ld ns/bit\n", cycles * 1000, "bits JTAG read:", cmd_per_sec, cmd_per_sec ? 1000000/cmd_per_sec : 0);


    avago_sbus_wr(aapl, sbus_addr, 0x13, orig_val); /* restore original value */
}
#endif /* AAPL_ENABLE_MAIN */
#endif /* AAPL_ENABLE_DIAG */
