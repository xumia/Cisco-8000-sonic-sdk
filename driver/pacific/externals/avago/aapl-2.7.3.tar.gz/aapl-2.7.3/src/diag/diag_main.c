/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.3                                        */
/* MAIN program for the diag command. */

/** Doxygen File Header */
/** @file */
/** @brief Launch wrapper for diagnostic routines */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS

#include "aapl.h"

#if AAPL_ENABLE_MAIN && AAPL_ENABLE_DIAG

static int show_diag_help()
{
    aapl_common_main_help(TRUE);
    printf(
"-speed                  Run speed tests.  Use -cycles to set how many read/writes to do.\n"
"-reset                  Reset hardware before running any tests.\n"
"-cycles <number>        How many loops to run\n"
"-sensor-logger          Poll sensor in tight loop and print log of values\n"
"                        Use with -addr -cycles -sensor-num -temp-or-volt -refclk (in Hz).\n"
"-sensor-num  <0..7>     Which sensor 0 - 7 to log\n"
);
    printf(
"-temp-or-volt <0|1>     Which type of measurement: temperature (0) or voltage (1)\n"
"-refclk <Hz>            Frequency of the chip's refclk in Hz for enhanced sensor accuracy\n"
"-read-write             Run the SBus and MDIO read/write tests and exit\n"
"-destructive            Run diagnostics that do not preserve SerDes state.\n"
);
    printf(
"-disable-columns        Don't output SerDes memory dumps in columns.\n"
"-disable-dma-dump       Don't output LSB, ESB, DMA or SPICO DMEM data.\n"
"-disable-sbus-dump      Don't output SBus register data.\n"
"-disable-state-dump     Don't output SerDes state information.\n"
"-disable-annotation     Don't annotation SerDes memory addresses with names.\n"
);
    printf(
"-dmem                   Output SPICO DMEM data.\n"
"-imem                   Output SPICO IMEM data.\n"
"-init-only              Only run SerDes init when in destructive mode.\n"
"-use-divider            Rather than sweep divider settings, get the current\n"
"                           divider setting from the SerDes (TX) and use it.\n"
"-pmd                    Output PMD diagnostic data.\n"
);

    printf(
"-dmi                    Output DMI dump from SerDes.\n"
"-dmi-file <filename>    Parse aapl diag -imem output for DMI data.\n"
"-dmi-imem <addr>        Optional. Give an address >= end_of_rom to help find DMI data faster.\n"
);

    printf(
"NOTE: Default SBus address is *:*:*.\n");

    return 1;
}

int aapl_diag_main(int argc, char *argv[], Aapl_t *aapl)
{
    /* Set default values: */
    Avago_addr_t addr_struct;
    uint sbus_addr;
    int rc, index = 0;
    int destructive = 0;
    int use_divider = 0;
    int serdes_init_only = 0;

    int disable_state_dump = 0;
    int disable_columns = 0;
    int disable_dma_dump = 0;
    int disable_sbus_dump = 0;
    int disable_annotation = 0;
    int dmem = 0;
    int imem = 0;
    int pmd = 0;
    int io_test_only = 0;
    uint reset = 0;
    int dmi = 0;
    uint dmi_imem_guess = 0;
    const char* dmi_file = 0;

    int read_write = 0;
    int speed = 0;   /* run speed test? */
    int cycles = 20; /* number of iterations for speed test and PC output for avago_diag */
    int sensor_logger = 0; /* run sensor logger? */
    int sensor_num = 0;    /* which sensor to log */
    int temp_or_volt = 0;  /* which type of measurement to do (temperature=0, voltage=1) */
    char *temp = getenv("SERDES_REFCLK");
    uint refclk = temp && *temp ? aapl_nume_from_str(temp, "env") : 0; /* If no env var, default to estimate rate */
    Avago_addr_t start, stop, next; BOOL st;


    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"read-write",           0, NULL,  10},
        {"cycles",               1, NULL,  1 },
        {"speed",                0, NULL,  3 },

        {"destructive",          0, NULL,  2 },
        {"use-divider",          0, NULL,  6 },

        {"dmem",                 0, NULL,  7 },
        {"imem",                 0, NULL,  9 },
        {"pmd",                  0, NULL,  15},
        {"disable-columns",      0, NULL,  5 },
        {"disable-dma-dump",     0, NULL,  8 },
        {"disable-sbus-dump",    0, NULL,  11},
        {"disable-state-dump",   0, NULL,  12},
        {"disable-annotation",   0, NULL,  23},

        {"dmi",                  0, NULL,  16},
        {"dmi-file",             1, NULL,  21},
        {"dmi-imem-addr",        1, NULL,  22},

        {"init-only",            0, NULL,  13}, /* Run serdes init only */
        {"reset",                0, NULL,  14},
        {"sensor-logger",        0, NULL,  17}, /* Tight polling on voltage/temp sensor */
        {"refclk",               1, NULL,  18}, /* Input refclk frequency in Hz */
        {"sensor-num",           1, NULL,  19}, /* Which sensor to poll  */
        {"temp-or-volt",         1, NULL,  20}, /* Which type of measurement to so */
        {0,                      0, NULL,  0 }
    };

    avago_addr_init_broadcast(&addr_struct);
    if(aapl_common_main_options(aapl, argc, argv, &addr_struct) < 0)
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_diag_help();
    }

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch( rc )
        {
        case  1 : cycles      = aapl_num_from_str(optarg, name, 0);  break;
        case  2 : destructive = 1;                              break;
        case  3 : speed       = 1; io_test_only = 1;            break;
        case  5 : disable_columns = 1;                          break;
        case  6 : use_divider = 1;                              break;
        case  7 : dmem = 1;                                     break;
        case  8 : disable_dma_dump = 1;                         break;
        case  23: disable_annotation = 1;                       break;
        case  9 : imem = 1;                                     break;
        case  10: read_write = TRUE; io_test_only = 1;          break;
        case  11: disable_sbus_dump = 1;                        break;
        case  12: disable_state_dump = 1;                       break;
        case  13: serdes_init_only = 1;                         break;
        case  14: reset = 1;                                    break;
        case  15: pmd = 1;                                      break;
        case  16: dmi = 1;           io_test_only = 1;          break;
        case  21: dmi_file = optarg; io_test_only = 1;          break;
        case  22: dmi_imem_guess  = aapl_num_from_str(optarg, name, 0); break;
        case  17: sensor_logger = 1; io_test_only = 1;          break;
        case  18: refclk       = aapl_nume_from_str(optarg, name); break;
        case  19: sensor_num   = aapl_num_from_str(optarg, name, 0); break;
        case  20: temp_or_volt = aapl_num_from_str(optarg, name, 0); break;




        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    /* No args are allowed beyond options: */
    if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1); /* Connect to the device */

    aapl_get_ip_info(aapl, /* chip_reset */ reset);
    if( aapl_get_return_code(aapl) < 0 )
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "aapl_get_ip_info returned a negative value.\n");

    sbus_addr = avago_struct_to_addr(&addr_struct);

    /* Run these tests once (not once per address): */

    if( read_write )
    {
#if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO
        if( aapl_is_mdio_communication_method(aapl) )
        {
            Avago_addr_t addr;
            avago_addr_to_struct(sbus_addr,&addr);
            avago_diag_mdio_rw_test(aapl, addr.chip, cycles);
        }
        else
#endif /* AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO */
        if( avago_diag_sbus_rw_test(aapl, sbus_addr, cycles) )
            aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "read-write test of %d cycles passed.\n", cycles);
    }

    if( speed )     /* Run SBus speed test */
    {
        uint sbus_addr2 = sbus_addr;
        if( aapl_check_broadcast_address(aapl, sbus_addr, __func__, __LINE__, FALSE) ) sbus_addr2 = 0; /* can't call rw test on broadcast */
        avago_sbus_speed_test(aapl, sbus_addr2, cycles);
    }

    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, 0);
         st;
         st = aapl_broadcast_next(aapl, &next, &start, &stop, 0) )
    {
        uint sbus_addr = avago_struct_to_addr(&next);
        if ((int)sbus_addr == aapl->max_sbus_addr[next.chip][next.ring] + 1) sbus_addr = 0xfd; /* aapl_broadcast_next will go to max_sbus_addr + 2 to allow inclusion of 0xfd and 0xfe */
        if ((int)sbus_addr == aapl->max_sbus_addr[next.chip][next.ring] + 2) sbus_addr = 0xfe; /* aapl_broadcast_next will go to max_sbus_addr + 2 to allow inclusion of 0xfd and 0xfe */

        if( sensor_logger )     /* Run sensor logger for specified cycles */
        {
            if (!aapl_check_ip_type(aapl, sbus_addr , __func__, __LINE__, TRUE, 1, AVAGO_THERMAL_SENSOR))
            {
                aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Provided SBus address is not a volt/temp sensor.\n");
                return -1; /* must be sensor */
            }

            AAPL_SUPPRESS_ERRORS_PUSH(aapl);
            /* determine which type of measurement to log */
            int x;
            for( x = 0; x < cycles; x++ )
            {
                aapl_close_connection(aapl); /* close connection in preparation for opening it only during sensor reads */
                if (temp_or_volt)
                {
                    /* voltage */
                    int mV = avago_sensor_get_voltage(aapl,sbus_addr,sensor_num,refclk);
                    if( mV < 0 ) break;
                    aapl_log_printf(aapl, AVAGO_INFO, __func__, 0, "%u,%d.%03d \n", x+1, mV/1000,(mV > 0 ? 1 : -1) * mV%1000);
                } else {
                    /* temperature */
                    int mC = avago_sensor_get_temperature(aapl,sbus_addr,sensor_num,refclk);
                    if( mC < -40000 ) break;
                    aapl_log_printf(aapl, AVAGO_INFO, __func__, 0, "%u,%d.%d \n", x+1, mC/1000,(mC > 0 ? 1 : -1) * mC%1000/100);
                }
            }
            AAPL_SUPPRESS_ERRORS_POP(aapl);
        }

        if (dmi)
        {
            avago_spico_dmi_dump(aapl, sbus_addr, dmi_imem_guess);
        }

        if (dmi_file)
        {
            avago_spico_dmi_dump_file(aapl, sbus_addr, dmi_file, dmi_imem_guess);
            break; /* this is usually run in offline mode, so running this on multiple addresses doesn't make sense */
        }

        if (!io_test_only)
        {   /* For a local context: */
            Avago_diag_config_t *config  = avago_diag_config_construct(aapl);
            config->columns              = !disable_columns;
            config->destructive          = destructive;
            config->use_existing_divider = use_divider;
            config->serdes_init_only     = serdes_init_only;
            config->state_dump           = !disable_state_dump;
            config->sbus_dump            = !disable_sbus_dump;
            config->dma_dump             = !disable_dma_dump;
            config->dmem_dump            = dmem;
            config->imem_dump            = imem;
            config->pmd_debug            = pmd;
            config->cycles               = cycles;
            config->refclk               = refclk;
            config->enable_annotation    = !disable_annotation;

            avago_diag(aapl, sbus_addr, config);
            avago_diag_config_destruct(aapl, config);
        }
    }

    avago_addr_delete(aapl, &addr_struct);
    return 0;
}


static int show_bist_help()
{
    aapl_common_main_help(TRUE);
    printf(
"-rev <rev>               Firmware revision to upload. Default = %s.\n"
"-build <build>           Firmware build number to upload.\n"
"                           Default <build> varies by SerDes type.\n"
"                         <rev> and <build> are case sensitive.\n"
"-firmware-file <path>    Path of firmware file to upload.\n"
, aapl_default_firmware_rev);

    printf(
"-divider                 Divider value for SerDes init tests. Default = %d.\n"
"-mask                    Mask for which tests to run. Default = 0xffffffff.\n"
"-reset                   Resets the device prior to running the init.\n"
"-upgrade-warnings        Turn all AAPL WARNINGS into ERRORS.\n"
, aapl_default_divider);

    printf(
"NOTE: Default SBus address is *:*:*.\n");

    return 1;
}


int aapl_bist_main(int argc, char *argv[], Aapl_t *aapl)
{
    /* Set default values: */
    uint        sbus_addr;
    Avago_addr_t addr_struct;
    int rc, index = 0;
#if AAPL_ENABLE_FILE_IO
    uint reset = 0;
    uint mask = 0xffffffff;
    uint upgrade_warnings = 1;
#endif /* AAPL_ENABLE_FILE_IO */
    char firmware_file[512];
    const char *firmware_file_ptr = 0;
    const char *fw_build = 0;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"rev",                  1, NULL, 'r'}, /* Load specific firmware revision */
        {"build",                1, NULL, 'b'}, /* Load specific firmware build */
        {"firmware-file",        1, NULL, 'R'}, /* Load full firmware file path */
        {"reset",                0, NULL,  1},
        {"mask",                 1, NULL,  2},
        {"upgrade-warnings",     0, NULL,  3},
        {"divider",              1, NULL,  4},
        {0,                      0, NULL,  0}
    };

    avago_addr_init_broadcast(&addr_struct);
    if(aapl_common_main_options(aapl, argc, argv, &addr_struct) < 0)
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_bist_help();
    }
    sbus_addr = avago_struct_to_addr(&addr_struct);

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch( rc )
        {
#if AAPL_ENABLE_FILE_IO
        case   1: reset = 1;                                    break;
        case   2: mask  = aapl_num_from_str(optarg, name, 0);   break;
        case   3: upgrade_warnings = 1;                         break;
#endif /* AAPL_ENABLE_FILE_IO */
        case   4: aapl_default_divider = aapl_num_from_str(optarg,name,0);break;
        case 'b': fw_build                  = optarg; break;
        case 'r': aapl_default_firmware_rev = optarg; break;
        case 'R': firmware_file_ptr = optarg;         break;

        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    /* No args are allowed beyond options: */
    if( optind < argc ) aapl_exit_on_unexpected_arg(argv[optind]);

    aapl_connect(aapl, 0, 0);
    aapl_get_ip_info(aapl, 0);

    if( !firmware_file_ptr )
    {
        if( !fw_build )
            fw_build = aapl_get_default_firmware_build(aapl, sbus_addr);
        if( aapl_find_firmware(aapl, sbus_addr, fw_build, firmware_file, sizeof(firmware_file)) )
            firmware_file_ptr = firmware_file;
        else
            printf("Error: Firmware revision '%s' for build '%s' not found.\n", aapl_default_firmware_rev, fw_build);
    }

    aapl_close_connection(aapl);

#if AAPL_ENABLE_FILE_IO
    if( firmware_file_ptr )
        avago_bist_file(aapl, reset, sbus_addr, aapl_default_divider, mask, upgrade_warnings, firmware_file_ptr);
#else
    (void)firmware_file_ptr;
#endif /* AAPL_ENABLE_FILE_IO */

    avago_addr_delete(aapl, &addr_struct);
    /* bist already did the AAPL destruct */
    return 0;
}


#endif /* AAPL_ENABLE_MAIN && AAPL_ENABLE_DIAG */
