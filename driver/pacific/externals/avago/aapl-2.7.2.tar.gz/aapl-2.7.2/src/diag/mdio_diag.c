/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* AAPL (ASIC and ASSP Programming Layer) diagnostic/test support. */

/** Doxygen File Header */
/** @file */
/** @brief Diagnostic routines for MDIO. */

#include "aapl.h"
#if AAPL_ENABLE_DIAG
#if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO

/** @brief   Repeatedly run MDIO read/write diagnostic tests. */
/** @details Execute a set of read/write operations cycles number of times. */
/**          Stops if any read value is different than what was written. */
/** @return  0 on success, aapl->return_code (< 0) on error. */
/** */
BOOL avago_diag_mdio_rw_test(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint prtad,         /**< [in] Port address */
    int cycles)         /**< [in] How many times to run the test */
{
    uint reg0 = 32782;
    uint reg1 = 32789;
    uint reg2 = 32790;

    int rc = aapl->return_code;
    int x;

    for (x=1; x<=cycles; x++)  /* repeat R/W cycles */
    {
        uint data;
        if(aapl->aacs)
        {
            /* Running the mdio test that is on the HS1, will increase performance */
            avago_aacs_send_command(aapl, "mdio x");
            if( 0 != strcmp(aapl->data_char, "OK") )
                aapl_fail(aapl, __func__, __LINE__, "MDIO test failed on loop %d. Expected \"OK\", but got %s.\n", x, aapl->data_char);
            continue;
        }
        avago_mdio_wr(aapl, prtad, AVSP_DEVAD, reg0, 42);   /* Write 42 to reg0 */
        avago_mdio_wr(aapl, prtad, AVSP_DEVAD, reg1, 1);    /* Write 1 to reg1 */
        avago_mdio_wr(aapl, prtad, AVSP_DEVAD, reg2, 2);    /* Write 2 to reg2 */

        data = (avago_mdio_rd(aapl, prtad, AVSP_DEVAD, reg1) & 0xffff);
        if (data != 1)
        {
            aapl_fail(aapl, __func__, __LINE__, "MDIO readback failed on loop %d. Expected 1, but got 0x%02x.\n", x, data);
            break;
        }

        data = (avago_mdio_rd(aapl, prtad, AVSP_DEVAD, reg2) & 0xffff);
        if (data != 2)
        {
            aapl_fail(aapl, __func__, __LINE__, "MDIO readback failed on loop %d. Expected 2, but got 0x%02x.\n", x, data);
            break;
        }

        avago_mdio_wr(aapl, prtad, AVSP_DEVAD, reg1, 3);    /* Write 3 to reg1 */
        avago_mdio_wr(aapl, prtad, AVSP_DEVAD, reg2, 4);    /* Write 4 to reg2 */

        data = (avago_mdio_rd(aapl, prtad, AVSP_DEVAD, reg1) & 0xffff);
        if (data != 3)
        {
            aapl_fail(aapl, __func__, __LINE__, "MDIO readback failed on loop %d. Expected 3, but got 0x%02x.\n", x, data);
            break;
        }

        data = (avago_mdio_rd(aapl, prtad, AVSP_DEVAD, reg2) & 0xffff);
        if (data != 4)
        {
            aapl_fail(aapl, __func__, __LINE__, "MDIO readback failed on loop %d. Expected 4, but got 0x%02x.\n", x, data);
            break;
        }

        data = (avago_mdio_rd(aapl, prtad, AVSP_DEVAD, reg0) & 0xffff);
        if (data != 42)
        {
            aapl_fail(aapl, __func__, __LINE__, "MDIO readback failed on loop %d. Expected 42, but got 0x%02x.\n", x, data);
            break;
        }
        avago_mdio_wr(aapl, prtad, AVSP_DEVAD, reg0, 0);   /* Write 0 to reg0 */
    }

    if (aapl->return_code != rc) 
    {
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "MDIO R/W test passed, %d cycles.\n", cycles);
        return TRUE;
    }
    return FALSE;
}

#endif /* MDIO */
#endif /* AAPL_ENABLE_DIAG */
