/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* AAPL (ASIC and ASSP Programming Layer) SerDes diagnostics */

/** Doxygen File Header */
/** @file */
/** @brief Functions for SerDes diagnostics. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"



#if AAPL_ENABLE_DIAG

/** @brief   Prints a formatted dump of all SBus registers with non-zero values. */
/** @details Dumps all SBus registers for a given sbus_addr. */
/**          Only registers with non-zero values are written.  All output */
/**          is written using AVAGO_INFO logging via aapl_log_printf(). */
/** @return  void */
void avago_diag_sbus_dump(Aapl_t *aapl, uint sbus_addr, BOOL bin_enable)
{
    int mem_addr;
    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "SBus dump for SBus address %s\n", aapl_addr_to_str(sbus_addr));

    for( mem_addr=0; mem_addr <= 0xff; mem_addr++ )
    {
        uint data;
        if (aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, AVAGO_PMRO) && (mem_addr<0xf8))
            continue;
        data = avago_sbus_rd(aapl, sbus_addr, mem_addr);
        if( data != 0 || aapl->verbose)
        {
            if( bin_enable )
                aapl_hex_2_bin(aapl->data_char, data, 1, 32);   /* convert to bin with underscores */
            else
                aapl->data_char[0] = 0x00;                       /* if no binary, clear out data_char */

            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%s 0x%02x: 0x%08x  %s\n", aapl_addr_to_str(sbus_addr), mem_addr, data, aapl->data_char);
        }
    }
}


static void search_table_file_addr(Aapl_t *aapl, char *tablefile, uint mem_addr, char *str)
{
    (void)tablefile;
    (void)mem_addr;
    str[0] = 0; /* clear string */

#if AAPL_ENABLE_FILE_IO
    if (tablefile)
    {
        char find_str[10]; /* what we're searching for */
        char *found1 = 0;
        snprintf(find_str, 9, "\t%04x\t", mem_addr); /* start and end search with tab (0x9) */

        found1 = strstr(tablefile, find_str); /* find the address */
        if (found1)
        {
            char *found2;
            for (; found1 >= tablefile; found1--) if (found1[0] == '\n') break; /* go backwards until previous \n */
            found1++; /* move forward 1 to next line */
            found2 = strstr(found1, "\n");
            if (found2-found1 >= 127) found2 = found1 + 127; /* deal with long lines */

            strncpy(str, found1, found2-found1); /* take entire found line */
            str[found2-found1] = 0; /* terminate string */
            if (strstr(str, "IMEM_LABEL")) /* if it's an IMEM label ignore it */
            {
                found2 = found1 = 0;
                str[0] = 0;
            }

            if (found1)
            {
                found2 = strstr(found1, find_str) + 1; /* search for variable number. The +1 is for the extra tab that was in the original search string */
                if (found2-found1 > 1000) found2 = found1 + 1000; /* deal with lines over 1000 chars long */
                strncpy(str, found1, found2-found1);
                str[found2-found1] = 0; /* string terminator */
                while(str[found2-found1-1] == 0x20 || str[found2-found1-1] == 0x9) str[--found2-found1] = 0; /* remove trailing spaces */
            }
        }
        /* Remove "reg_" prefix from register names: */
        if( 0 == strncmp(str, "reg_", 4) ) memmove(str,str+4,strlen(str+4)+1);
    }
#endif
    if (aapl->debug & AAPL_DEBUG_MEMORY_NAMES) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Address 0x%x converted into %s.\n", mem_addr, str);
}

#if AAPL_ENABLE_FILE_IO && AAPL_ENABLE_MAIN
static char *read_serdes_mapfile(Aapl_t *aapl, uint addr, BOOL esb)
{
    char filename[256];
    char *ptr;
    char *file;

    const char *rev_id_name = avago_get_ip_info(aapl, addr)->rev_id_name;

    if (*rev_id_name)
    {
        ptr = filename;
        if (esb) ptr += snprintf(ptr, sizeof(filename), "%s.esb_dma_reg_map.txt", rev_id_name);
        else     ptr += snprintf(ptr, sizeof(filename), "dma_reg_map.txt");
        file = aapl_read_file(aapl, filename);
        if (file) return file;

        ptr = filename;
        ptr += sprintf(ptr, "%s../user_data/kramers/ip_rtl/ip_rtl/serdes16/doc/reg_maps/", AVAGO_FIRMWARE_PATH);
        if (esb) ptr += snprintf(ptr, sizeof(filename), "%s/%s.esb_dma_reg_map.txt", rev_id_name, rev_id_name);
        else     ptr += snprintf(ptr, sizeof(filename), "%s/dma_reg_map.txt", rev_id_name);
        file = aapl_read_file(aapl, filename);
        if (file) return file;

        ptr = filename;
        ptr += sprintf(ptr, "/home/kramers/work/ip_rtl/ip_rtl/serdes07/doc/reg_maps/");
        if (esb) ptr += snprintf(ptr, sizeof(filename), "%s/%s.esb_dma_reg_map.txt", rev_id_name, rev_id_name);
        else     ptr += snprintf(ptr, sizeof(filename), "%s/dma_reg_map.txt", rev_id_name);
        file = aapl_read_file(aapl, filename);
        if (file) return file;
    }

    ptr = filename;
    if (esb) ptr += snprintf(ptr, sizeof(filename), "esb_dma_reg_map.txt");
    else     ptr += snprintf(ptr, sizeof(filename), "dma_reg_map.txt");
    file = aapl_read_file(aapl, filename);
    if (file) return file;

    return 0;
}

static char *read_spico_tablefile(Aapl_t *aapl, uint addr)
{
    char filename[256];
    char *ptr;
    char ip_type[16];
    char *file;

    int eng_rel = avago_firmware_get_engineering_id(aapl, addr);
    if( aapl_check_ip_type(aapl, addr, 0, 0, FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) )
         snprintf(ip_type, sizeof(ip_type), "serdes");
    else snprintf(ip_type, sizeof(ip_type), "sbus_master");

    /* now try local directory */
    ptr = filename;
    ptr += sprintf(ptr, "%s.0x%04X_%04X", ip_type, aapl_get_firmware_rev(aapl, addr), aapl_get_firmware_build(aapl, addr));
    if( eng_rel ) ptr += sprintf(ptr, "_%03X", eng_rel);
    ptr += sprintf(ptr, ".table");
    file = aapl_read_file(aapl, filename);
    if (file) return file;

    /* now try local directory */
    ptr = filename;
    ptr += sprintf(ptr, "%s.%04X.table", ip_type, aapl_get_firmware_build(aapl, addr));
    file = aapl_read_file(aapl, filename);
    if (file) return file;

    if( eng_rel )
    {
        ptr = filename;
        ptr += sprintf(ptr, AVAGO_FIRMWARE_PATH);
        ptr += sprintf(ptr, "engineering_releases/%s/%s.0x%04X_%04X_%03X/%s.0x%04X_%04X_%03X",ip_type, ip_type, aapl_get_firmware_rev(aapl, addr),
                                      aapl_get_firmware_build(aapl, addr), eng_rel, ip_type, aapl_get_firmware_rev(aapl, addr),
                                      aapl_get_firmware_build(aapl, addr), eng_rel);
        ptr += sprintf(ptr, ".table");
        file = aapl_read_file(aapl, filename);
        if (file) return file;
        else return 0; /* if this is an engineering release, do not proceed to looking for non engneering release firmware below because it almost certainly would not match */
    }

    ptr = filename;
    ptr += sprintf(ptr, AVAGO_FIRMWARE_PATH);
    ptr += sprintf(ptr, "%s/0x%04X/%s.0x%04X_%04X", ip_type, aapl_get_firmware_rev(aapl, addr),
                                      ip_type, aapl_get_firmware_rev(aapl, addr), aapl_get_firmware_build(aapl, addr));
    ptr += sprintf(ptr, ".table");
    file = aapl_read_file(aapl, filename);
    if (file) return file;

    ptr = filename;
    ptr += sprintf(ptr, AVAGO_FIRMWARE_PATH);
    ptr += sprintf(ptr, "%s/latest/%s.0x%04X_%04X", ip_type, ip_type, aapl_get_firmware_rev(aapl, addr), aapl_get_firmware_build(aapl, addr));
    ptr += sprintf(ptr, ".table");
    file = aapl_read_file(aapl, filename);
    return file;
}

/* search mapfile for name of given bit in given mem_addr */
/* str modified with result */
static void search_map_file(Aapl_t *aapl, char *tablefile, uint mem_addr, char *bitfield, char *str)
{
    char find_addr_str[10]; /* what we're searching for */
    char *found1 = 0, *save_ptr, *addr_name;

    str[0] = 0; /* clear string */
    if (!tablefile) return;

    /*ADDR 128/0x80 async RX_PLL_MISC_CTL */
    /*REG      1      0   RW RX_FAST_PFD_MODE */
    /*REG      0      0   RW RX_SEL_PFD */
    /* */
    /*############################################ */
    /*#  interupt_levelX = DISASBLE_X & (sticky_levelX cleared by rtiX | sticky_regX cleared by clearX) */
    /*ADDR  0/0x0  clk   INTERRUPT CONTROL */
    /*REG   0   0  RW1C  CLEAR_INTERRUPT_SBUS          # Clear sticky reg that would induce interruptX */
    /*#REG   1   0  RW1C  CLEAR_INTERRUPT_HDW */
    /*REG   1   0  RW    REG0_1                       # no sticky reg anymore */
    /*REG   2   0  RW1C  CLEAR_INTERRUPT_CORE */

    snprintf(find_addr_str, 9, "ADDR %u/", mem_addr); /* LSB memory map style */
    found1 = strstr(tablefile, find_addr_str); /* find the address */
    if (!found1)
    {
        snprintf(find_addr_str, 10, "ADDR  %u/", mem_addr); /* ESB memory map style */
        found1 = strstr(tablefile, find_addr_str); /* find the address */
    }
    if (!found1) return; /* address not found */

    aapl_strtok_r(found1, " ", &save_ptr); /* ADDR string */
    aapl_strtok_r(0, " ", &save_ptr); /* address */
    aapl_strtok_r(0, " ", &save_ptr); /* sync */
    addr_name = aapl_strtok_r(0, "\n", &save_ptr); /* name */
    if (!addr_name) return; /* no name present */

    if (aapl->debug & AAPL_DEBUG_MEMORY_NAMES) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "\n### %d: %s -> %s ###\n", mem_addr, find_addr_str, addr_name);
    while(1) /* search through all bitfield names in this address */
    {
        char *bit_text, *name;
        found1 = aapl_strtok_r(0, " ", &save_ptr); /* REG */
        bit_text = aapl_strtok_r(0, " ", &save_ptr); /* bitfield text */
        name = aapl_strtok_r(0, "\n", &save_ptr); /* name */
        if (aapl->debug & AAPL_DEBUG_MEMORY_NAMES) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "##### %120s ## %20s ## %20s !!!\n", name, found1, bit_text);
        if (strstr(found1, "REG") && strlen(found1) == 3 && !strcmp(bit_text, bitfield))
        {
            aapl_strtok_r(name, " ", &save_ptr); /* address */
            aapl_strtok_r(0, " ", &save_ptr); /* sync */
            name = aapl_strtok_r(0, "\n", &save_ptr); /* name */
            if (strstr(name, "#")) name = aapl_strtok_r(name, "#", &save_ptr); /* strip off any comments */
            while(strlen(name) > 1 && (name[strlen(name)-1] == ' ' || name[strlen(name)-1] == 0x9)) name[strlen(name)-1] = 0; /* remove trailing whitespace and tabs */
            while(strlen(name) > 1 && (name[0] == ' ' || name[0] == 0x9)) memmove(name, name+1, strlen(name)); /* remove and leading whitespace and tabs */
            sprintf(str, "%s", name);
            if (aapl->debug & AAPL_DEBUG_MEMORY_NAMES) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "## Final: \"%s\"\n", name);
            /*for (uint x = 0; x<=strlen(name); x++) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%x\n", name[x]); */
            break;
        }
        if (!found1 || !bit_text || !name || (strstr(found1, "ADDR") && strlen(found1) == 5) || strstr(name, "Register_type")) break; /* if we've made it to the next address, then no bitfield matched -- give up */
    }
}

static int search_table_file_str(Aapl_t *aapl, char *tablefile, const char *str)
{
    (void)aapl, (void)tablefile, (void)str;
    if (tablefile)
    {
        char *found1 = aapl_strcasestr(tablefile, str); /* find the string which precedes the address */
        if (found1)
        {
            int val;
            while (found1[0] != 0x20 && found1[0] != 0 && found1[0] != 0x9) found1++; /* move until whitespace (skip past name) */
            while ((found1[0] == 0x20 || found1[0] == 0x9) && found1[0] != 0x0) found1++; /* skip all whitespace */
            found1[4] = 0; /* address is 4 characters */
            /*printf("### %s ###\n", found1); */
            val = aapl_num_from_str(found1, "memory address", 16); /* otherwise it's the next memory address' value */
            if (aapl->debug & AAPL_DEBUG_MEMORY_NAMES) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "\"%s\" decoded into address %d (0x%0x).\n", str, val, val);
            return val;
        }
    }
    return -1;
}

static int search_map_file_str(Aapl_t *aapl, char *tablefile, const char *str, uint *bit_field_bits, uint *bit_field_shift)
{
    (void)aapl, (void)tablefile, (void)str, (void)bit_field_bits, (void)bit_field_shift;

    if (tablefile)
    {
        char find_addr_str[10]; /* what we're searching for */
        char *start = tablefile, *save_ptr;
        char *found = tablefile;
        char *addr_name = 0, *addr_val = 0;

        aapl_strtok_r(found, "\n", &save_ptr); /* get this line */
        while(1)
        {
            int str_found = 0;
            char *line = aapl_strtok_r(NULL, "\n", &save_ptr); /* get this line */
            if (!line) break;
            if (line[0] == '#') continue; /* skip comments */

            /*# ADDR <NUMBER> <clock> <PROJ ADDRESS NAME> <RESERVED?> */
            /*# REG  BITS DEFAULT ACCESS <PROJ_REGNAME> <NOTES> <RESERVED?> */
            /* */
            /* ADDR 128/0x80 async RX_PLL_MISC_CTL */
            /* REG     15      0   RW RX_TEST_CLK_CNTL_1 */

            snprintf(find_addr_str, 9, "ADDR "); /* LSB memory map style */
            start = strstr(line, find_addr_str); /* find the address */
            if (!start && aapl_strcasestr(line, str)) str_found = 1;  /* not an "^ADDR" line, so look for search string */

            if (start)
            {
                char *save_ptr, *addr_name_local = 0, *addr_val_local = 0, *save_ptr2; 

                aapl_strtok_r(start, " ", &save_ptr); /* "ADDR" */
                addr_val_local = aapl_strtok_r(NULL, " ", &save_ptr); /* address */

                aapl_strtok_r(addr_val_local, "/", &save_ptr2); /* get decimal address before "/" */
                addr_val_local = aapl_strtok_r(NULL, " ", &save_ptr2); /* get hex address after "/" */

                aapl_strtok_r(NULL, " ", &save_ptr); /* async */
                addr_name_local = aapl_strtok_r(NULL, "\n", &save_ptr); /* name */
                if (addr_val_local && addr_name_local) /* && !aapl_strtok_r(NULL, " ", &save_ptr)) */
                {
                    addr_name = addr_name_local;
                    addr_val = addr_val_local;
                    if (aapl_strcasestr(addr_name, str)) str_found = 1;  /* is this address name what we were looking for? */
                }
                /*printf("## %s ## %s ## %s ##\n", start, addr_val, addr_name); */
            }
            if (str_found && addr_name && addr_val) /* found name we are looking for */
            {
                char *save_ptr, *save_ptr2, *bitfield = 0;
                int bitfield_hi = -1, bitfield_lo = -1;

                /*printf("@@@ %s @ %s @ %s @ %s @ %s @\n", str, addr_name, addr_val, line, bitfield); */
                aapl_strtok_r(line, " ", &save_ptr); /* "REG" */
                bitfield = aapl_strtok_r(NULL, " ", &save_ptr); /* bitfield */

                if (bitfield) 
                {
                    char *bitfield_present = strstr(bitfield, ":");
                    bitfield_lo = bitfield_hi = aapl_strtoul(aapl_strtok_r(bitfield, ":", &save_ptr2), NULL, 10);
                    if (bitfield_present) bitfield_lo = aapl_strtoul(aapl_strtok_r(NULL, ":", &save_ptr2), NULL, 10);
                }

                aapl_strtok_r(NULL, " ", &save_ptr); /* default */
                aapl_strtok_r(NULL, " ", &save_ptr); /* name */

                if (bitfield) /* only modify the input pointers if a bitfield was found */
                {
                    *bit_field_bits = bitfield_hi - bitfield_lo + 1;
                    *bit_field_shift = bitfield_lo;
                }
                aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "## found %s at %s (%s) [%d:%d]\n", str, addr_name, addr_val, bitfield_hi, bitfield_lo);
                return aapl_strtoul(addr_val, NULL, 16);
            }
        }
    }
    return -1;
}

#endif /* AAPL_ENABLE_FILE_IO && AAPL_ENABLE_MAIN */


static void serdes_dmem_imem_dump(Aapl_t *aapl, uint sbus_addr, BOOL columns, BOOL dmem_dump, BOOL enable_annotation)
{
    int page_width = 16; /* number of addresses per line (without tablefile) */
    int range_start[3] = {0, 0, 0};
    int range_stop[3];
    int range_count = 1;

    int spico_run_state = 0;
    char *buf;
    char *tablefile = 0;
    (void)enable_annotation;

    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "\n");
    aapl_log_printf(aapl, AVAGO_INFO, __func__, 0, "SerDes %cMEM dump for SBus address %s.\n", dmem_dump?'D':'I',aapl_addr_to_str(sbus_addr));

    if (dmem_dump)
    {
        if ( (aapl_get_lsb_rev(aapl,sbus_addr) < 5) &&
             (aapl_get_process_id(aapl,sbus_addr) == AVAGO_TSMC_28)  )
            range_start[0] = 0x200;

        if (aapl_get_process_id(aapl,sbus_addr) == AVAGO_TSMC_16) range_stop[0] = 0x57f; /* stop address includes 0x400-0x57f for extended DMEM (which is really "real" memory addresss 0-0x17f that LSB and ESB memory overlap) */
        else range_stop[0] = 0x3ff;  /* AVAGO_DMEM is 1k by default for all other serdes */

        if( aapl_get_process_id(aapl, sbus_addr) == AVAGO_TSMC_07 && aapl_get_ip_type(aapl, sbus_addr) == AVAGO_SERDES )
        {
            range_start[0] = 0x0000; range_stop[0]  = 0x007f; /* 0x80-0xff appear to be unused, and bits 8 & 9 unconnected */
            range_start[1] = 0x0400; range_stop[1]  = 0x05ff; /* 0x600-0x7ff appear to be unused */
            range_start[2] = 0x0800; range_stop[2]  = 0x0fff;
            range_count = 3;
        }
    }
    else
    {
        if      (aapl_get_process_id(aapl, sbus_addr) == AVAGO_TSMC_07) range_stop[0] = 32 * 1024 - 1;
        else if (aapl_get_lsb_rev(aapl, sbus_addr) <= 2)                range_stop[0] = 8  * 1024 - 1;
        else if (aapl_get_lsb_rev(aapl, sbus_addr) <= 5)                range_stop[0] = 12 * 1024 - 1;
        else if (aapl_get_lsb_rev(aapl, sbus_addr) <= 0xd)              range_stop[0] = 24 * 1024 - 1;
        else                                                            range_stop[0] = 32 * 1024 - 1;
    }

    if (! (dmem_dump && (aapl_get_lsb_rev(aapl,sbus_addr) > 4) ))
      spico_run_state = avago_spico_halt(aapl, sbus_addr);

#if AAPL_ENABLE_FILE_IO && AAPL_ENABLE_MAIN
    if (dmem_dump && enable_annotation) tablefile = read_spico_tablefile(aapl, sbus_addr);
    if( tablefile )
    {
        page_width = 4; /* if we have a tablefile, only allow this many addresses per line */
        buf = (char *) aapl_malloc(aapl, page_width * 5 * 16 + 20, __func__);
    }
    else
#endif
    buf = (char *) aapl_malloc(aapl, page_width * 5 * 1  + 20, __func__);

    if( buf )
    {
        Avago_serdes_mem_type_t mem_type = dmem_dump ? AVAGO_DMEM_PREHALTED : AVAGO_IMEM_PREHALTED;
        int range;

        int old_ecc = avago_sbus_rmw(aapl, sbus_addr, 0xb, 0, dmem_dump ? 0x00080000 : 0x00040000);  /* Clear the DMEM/IMEM ECC_ENAB bits */

        if (aapl->spico_int_only)
        {
            mem_type = dmem_dump ? AVAGO_DMEM: AVAGO_IMEM;
            aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "NOTE: SerDes diag called in SPICO interrupt only mode. The memory dump will be performed via interrupts while the processor is running meaning that the memory dump will not taken from a single moment in time.\n");
        }

        /* Print out a header when printing 16 columns of dump data: */
        if( page_width == 16 )
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "        0x00 0x01 0x02 0x03 0x04 0x05 0x06 0x07 0x08 0x09 0x0a 0x0b 0x0c 0x0d 0x0e 0x0f\n");

        for( range = 0; range < range_count; range++ )
        {
            int mem_addr;
            char *ptr = buf;

            for( mem_addr = range_start[range]; mem_addr <= range_stop[range]; mem_addr++ )
            {
                char sym[1024]; /* result of search */
                char *sym_ptr = sym;
                uint data = avago_serdes_mem_rd(aapl, sbus_addr, mem_type, mem_addr);

                search_table_file_addr(aapl, tablefile, mem_addr, sym);
                if( columns && sym[0] && strncmp(sym+1,"sb_",3) == 0 ) sym_ptr += 4;   /* Drop "lsb_" and "esb_" prefixes */
                if( !columns || ((mem_addr-range_start[range]) % page_width) == 0 )
                {
                    ptr = buf;
                    ptr += sprintf(ptr,"0x%04x:", mem_addr);
                }
                if( tablefile )
                {
                    if( columns ) ptr += sprintf(ptr, " %04x %-16.16s", data, sym_ptr);
                    else          ptr += sprintf(ptr, " %04x %-s", data, sym);
                }
                else             ptr += sprintf(ptr, " %04x", data);
                if( !columns || ((1+mem_addr-range_start[range]) % page_width) == 0 )
                    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%s\n", buf);
            }
            if( columns != 0 && ((mem_addr-range_start[range]) % page_width) != 0 )
                aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%s\n", buf);
        }
        if (!dmem_dump)
            avago_sbus_wr(aapl, sbus_addr, 0x00, 0x00);

        avago_sbus_wr(aapl, sbus_addr, 0xb, old_ecc);                       /* Restore the DMEM/IMEM ECC_ENAB bits. */

        if (! (dmem_dump && (aapl_get_lsb_rev(aapl,sbus_addr) > 4) ))
            avago_spico_resume(aapl, sbus_addr, spico_run_state);
    }

    if (tablefile) aapl_free(aapl, tablefile, __func__);
    if (buf)       aapl_free(aapl, buf, __func__);
}

#if AAPL_ENABLE_FILE_IO && AAPL_ENABLE_MAIN
/* @cond INTERNAL */
/** @brief   Restores a SerDes to the state stored in file. */
/** @details filename should be the output of 'aapl diag'. */
/**          Upon calling this function, the state of the SerDes */
/**          specified will be returned to the state stored in the */
/**          file. The SerDes needs to already have firmware loaded */
/**          that matches the revision and build contained in */
/**          the file. */
/** @return  void */
void avago_serdes_restore(
    Aapl_t *aapl,
    uint sbus_addr,
    char *filename)
{
    char *file, *found1, *found2, *save_ptr1 = 0;
    uint loop = 50; /* wait a max of 50ms */
    int mem_addr = 0;
    int labels = 1;
    int mem_addr_0_value = 0;

    file = aapl_read_file(aapl, filename);
    aapl_str_rep(file, 0x0d, ' '); /* replace carriage returns with space */
    if (!file) return;

    found1 = strstr(file, "SerDes DMEM dump for SBus address");
    if (!found1) {aapl_fail(aapl, __func__, __LINE__, "%s", "Did not appear to be valid dumpfile."); goto done;}

    found1 = aapl_strtok_r(found1, "\n", &save_ptr1); /* skip the DMEM dump line */
    if (!found1) {aapl_fail(aapl, __func__, __LINE__, "%s", "Did not appear to be valid dumpfile."); goto done;}

    aapl->suppress_errors += 1; /* we don't care about any errors produced by serdes_init */
    avago_serdes_init_quick(aapl, sbus_addr, 10); /* required to get everything powered up properly before restoring things */
    aapl->suppress_errors -= 1;

    while (--loop) /* halt the processor */
    {
        uint dmem_base = 0x180;
        uint paws_opcode = 0x4f;
        if (aapl_get_process_id(aapl, sbus_addr) == AVAGO_TSMC_07)
        {
            dmem_base = 0x800;
            paws_opcode = 0x2f;
        }

        AAPL_SUPPRESS_ERRORS_PUSH(aapl); /* next instruction will cause an interupt timeout */
        avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_DMEM, dmem_base, 0x400); /* attempt to get the processor halted by setting bit 10 of current action which for most builds should cause us to go to paws */
        AAPL_SUPPRESS_ERRORS_POP(aapl);
        ms_sleep(1);
        if ((avago_sbus_rd(aapl, sbus_addr, 0x27) & 0x3ff) == paws_opcode) break; /* paws instruction */
    }
    if (!loop) {aapl_fail(aapl, __func__, __LINE__, "%s", "Was not able to get processor halted properly."); goto done;}

    avago_sbus_wr(aapl, sbus_addr, 0x20, 0x1); /* set single step so the processor doesn't know what is going on */

    while (1) /* we operate one line at a time and will break when done */
    {
        char *save_ptr2 = 0;
        int temp_addr = 0;
        found2 = aapl_strtok_r(NULL, "\n", &save_ptr1); /* get this line */
        if (!found2) break; /* end of file */
        if (strstr(found2, "WARNING") || strstr(found2, "ERROR")) continue; /* ignore error and warning lines */
        if (strstr(found2, "INFO:         0x00")) /* diag output without labels */
        {
            found2 = aapl_strtok_r(NULL, "\n", &save_ptr1); /* skip the header line */
            labels = 0;
        }
        if (!found2) break; /* no more lines? */
        found2 = strstr(found2, "0x"); /* skip past first address marker */
        if (!found2) break; /* line without address? */
        found2 = aapl_strtok_r(found2, " ", &save_ptr2); /* found2 is now the address */
        if (!found2) break; /* */
        found2[6] = 0; /* pull out 4 character string to convert to address */
        temp_addr = aapl_num_from_str(found2, "memory address", 16);
        if (temp_addr) mem_addr = temp_addr;

        while (found2) /* while we have things left on this line to process */
        {
            int mem_value;
            const char *mem_name = "";

            found2 = aapl_strtok_r(NULL, " ", &save_ptr2); /* get next data point */
            if (!found2) break; /* if there's nothing else, move to next line */

            found2[4] = 0; /* pull out 4 character string to convert to address */
            mem_value = aapl_num_from_str(found2, "memory address", 16); /* otherwise it's the next memory address' value */
            if (labels)
            {
                int count = 0;
                while (*save_ptr2 == ' ') {save_ptr2++; count++;}
                if (count < 16) mem_name = aapl_strtok_r(NULL, " ", &save_ptr2); /* if the next field is not blank then capture the name */
            }
            aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "### 0x%04x 0x%04x %s\n", mem_addr, mem_value, mem_name);

            /* NOTE: restore address 0 later otherwise writing it now will cause an interrupt to immediately occur, which then will force the stack to have a valid return value present otherwise it will crash when re-enabled */
            if (mem_addr == 0) mem_addr_0_value = mem_value; /* restore after processor is enabled */
            if (mem_addr != 0) avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_DMEM_PREHALTED, mem_addr, mem_value);
            mem_addr++;
        }
    }

    done:
    avago_sbus_wr(aapl, sbus_addr, 0x20, 0x0); /* allow the processor to turn back on */
    avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_DMEM_PREHALTED, 0, mem_addr_0_value); /* restore address 0 now -- see message above for details */
    avago_spico_int(aapl, sbus_addr, 0x26, (avago_spico_int(aapl, sbus_addr, 0x126, 0x2200) & 0xff) | 0x2200); /* get and restore gainDC which will force DFE values to get updated in the ESB */
    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Restore complete. Last memory address written: 0x%04x. SPICO restarted and reporting its firmware revision as: 0x%04x.\n", mem_addr-1, avago_spico_int(aapl, sbus_addr, 0, 0)); /* we need to send an interrupt to get out of paws -- and this will tell us if things went well or not */
    if (file) aapl_free(aapl, file, __func__);
}
/* @endcond */
#endif /* AAPL_ENABLE_FILE_IO && AAPL_ENABLE_MAIN */

#define MAX_LINES 0x400
/** @brief  Formats and displays the memory contents of the given SerDes. */
/** @return void */
void avago_serdes_mem_dump(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,     /**< [in] SBus address to SerDes. */
    BOOL bin_enable,    /**< [in] Also display binary value. */
    BOOL columns,       /**< [in] Enable multi-column output. */
    BOOL dma_dump,      /**< [in] Dump SerDes register values. */
    BOOL dmem_dump,     /**< [in] Dump data memory. */
    BOOL imem_dump,     /**< [in] Dump instruction memory. */
    BOOL enable_annotation) /**< [in] Enable annotation memory addresses with names. */
{
    int stop_addr = 0;
    Avago_serdes_mem_type_t dma_type = AVAGO_LSB;

    int *data = 0;
    int *data_addr = 0;
    int index[2];
    int type;
    int sdrev = aapl_get_sdrev(aapl, sbus_addr);
    char * tablefile = 0;

    if (imem_dump) serdes_dmem_imem_dump(aapl, sbus_addr, /* columns */ TRUE, FALSE, enable_annotation);

    if( (aapl_get_lsb_rev(aapl,sbus_addr) > 4) ||
        (aapl_get_process_id(aapl, sbus_addr) == AVAGO_TSMC_07) ||
        (aapl_get_process_id(aapl, sbus_addr) == AVAGO_TSMC_16) )
    {
        /* All data memory is dumped with a DMEM dump in 16nm (Hertz & Lorentz are rev 4 + 16nm) */
        serdes_dmem_imem_dump(aapl, sbus_addr, columns, TRUE, enable_annotation);
        if (aapl_get_lsb_rev(aapl,sbus_addr) != 8) return;
        columns = TRUE; /* For HVD6 there is only 1 table to print below, so disable columns */
    }

    if (dmem_dump) serdes_dmem_imem_dump(aapl, sbus_addr, /* columns */ TRUE, TRUE, enable_annotation);

    if (!dma_dump) return;

    if (columns) /* only create these arrays if columns will be used, otherwise data is added directly to the log */
    {
        data = (int *) aapl_malloc(aapl, 2 * MAX_LINES * sizeof(int), "mem_dump data");
        data_addr = (int *) aapl_malloc(aapl, 2 * MAX_LINES * sizeof(int), "mem_dump data");
        if( !data || !data_addr )
            columns = 0;
        else
        {
            memset(index, 0, sizeof(index));
            memset(data, 0, 2 * MAX_LINES * sizeof(int));
            memset(data_addr, 0, 2 * MAX_LINES * sizeof(int));
        }
    }

#if AAPL_ENABLE_FILE_IO && AAPL_ENABLE_MAIN
    if (enable_annotation) tablefile = read_spico_tablefile(aapl, sbus_addr);
#endif

    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "\n");
    aapl_log_printf(aapl, AVAGO_INFO, __func__, 0, "SerDes LSB/ESB DMA dump for SBus address %s.\n", aapl_addr_to_str(sbus_addr));
    for (type = 0; type <= 3; type ++)
    {
        int mem_addr;
        int start_addr = 0;
        if (type == 0) /* LSB */
        {
            if (aapl_get_lsb_rev(aapl,sbus_addr) == 8) continue; /* HVD6 got LSB direct via DMEM dump above */
            dma_type = AVAGO_LSB_DIRECT;
            if( sdrev == AAPL_SDREV_D6_07 )
                stop_addr = 0x3ff;
            else
                stop_addr = 0x60;
            if (!columns) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "LSB DMA dump:\n");
        }
        else if (type == 1) /* RX */
        {
            dma_type = AVAGO_ESB;
            if( sdrev == AAPL_SDREV_D6_07 )
            {
                start_addr = 0x400;
                stop_addr = 0x7ff;
            }
            else
            {
                stop_addr = 0xff;
            }
            if (!columns && aapl_get_lsb_rev(aapl,sbus_addr) != 8 && sdrev != AAPL_SDREV_D6_07) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "RX ESB DMA dump:\n");
            else if (!columns) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "ESB DMA dump:\n");
        }
        else if (type == 2) /* TX */
        {
            if (aapl_get_lsb_rev(aapl,sbus_addr) == 8) continue; /* HVD6 got LSB direct via DMEM dump above */
            if( sdrev == AAPL_SDREV_D6_07 ) continue;            /* Unified memory */
            dma_type = AVAGO_ESB;
            start_addr = 0x200;
            stop_addr = 0x2ff;
            if (!columns) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "TX ESB DMA dump:\n");
        }
        else if (type == 3) /* Clock */
        {
            if( sdrev == AAPL_SDREV_D6_07 ) continue;            /* Unified memory */
            dma_type = AVAGO_ESB;
            start_addr = 0x300;
            stop_addr = 0x305;
            if (!columns) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "CLK ESB DMA dump:\n");
        }

        if (!columns)
        {
            for (mem_addr = start_addr; mem_addr <= stop_addr; mem_addr++)
            {
                uint read = avago_serdes_mem_rd(aapl, sbus_addr, dma_type, mem_addr);
                if (read || aapl->verbose)
                {
                    char str[1024]; /* result of search */
                    char *sym_name = str;
                    sym_name[0] = sym_name[3] = 0;
                    /*if (dma_type != AVAGO_ESB)*/ search_table_file_addr(aapl, tablefile, mem_addr, sym_name);

                    if( sym_name[0] && strncmp(sym_name+1,"sb_",3) == 0 )   /* Drop "lsb_" and "esb_" prefixes */
                        sym_name += 4;

                    if (bin_enable) aapl_hex_2_bin(aapl->data_char, read, 1, 16); /* convert to bin with underscores */
                    else {aapl->data_char[0] = 0x00;}                             /* if no binary, clear out data_char */
                    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "0x%03x 0x%04x %s %16.16s\n", mem_addr, read, aapl->data_char, sym_name);
                }
            }
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "\n");
        }
        else
        {
            for (mem_addr = start_addr; mem_addr <= stop_addr; mem_addr++)
            {
                int col_num;
                uint read = avago_serdes_mem_rd(aapl, sbus_addr, dma_type, mem_addr);
                if      (type == 0) col_num = 0;
                else col_num = 1;

                if (!read && !aapl->verbose) continue; /* if there's no data continue */

                data[col_num * MAX_LINES + index[col_num]] = read;
                data_addr[col_num * MAX_LINES + index[col_num]] = mem_addr;
                index[col_num]++;
            }
        }
    }

    if (columns)
    {
        int x;
        /* The caller has asked for columns. First print the headers, then generate the data. */
        if (bin_enable)
        {
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "                    LSB DMA                                           ESB DMA           \n");
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, " Addr   Data                                       Addr   Data                  \n");
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "----- ------ ----------------------------------   ----- ------ ----------------------------------\n");
        }
        else
        {
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "   LSB DMA         ESB DMA  \n");
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, " Addr   Data     Addr   Data\n");
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "------------    ------------\n");
        }

        for (x = 0; x<=MAX_LINES; x++)
        {
            char buf[255]; /* max number of characters per line */

            int buf_len = 0;
            int have_data = 0;
            int col;
            for (col = 0; col <= 1; col++)
            {
                char str[1024]; /* result of search */
                char *sym_name = str;
                sym_name[0] = sym_name[3] = 0;
                if (bin_enable) aapl_hex_2_bin(aapl->data_char, data[col * MAX_LINES + x], 1, 16); /* convert to bin with underscores */
                /*if (col == 0)*/ search_table_file_addr(aapl, tablefile, data_addr[col * MAX_LINES + x], sym_name);

                if( strncmp(sym_name+1,"sb_",3) == 0 )   /* Drop "lsb_" and "esb_" prefixes */
                    sym_name += 4;

                if      ((aapl->verbose && data_addr[col * MAX_LINES + x]) || (data[col * MAX_LINES + x] && bin_enable))
                                        buf_len += sprintf(buf+buf_len, "0x%03x 0x%04x %16s %16.16s   ",  data_addr[col * MAX_LINES + x], data[col * MAX_LINES + x], aapl->data_char, sym_name);
                else if ((aapl->verbose && data_addr[col * MAX_LINES + x]) || data[col * MAX_LINES + x])
                                        buf_len += sprintf(buf+buf_len, "0x%03x 0x%04x %16.16s    ",       data_addr[col * MAX_LINES + x], data[col * MAX_LINES + x], sym_name);
                else if (bin_enable)    buf_len += sprintf(buf+buf_len, "  %3.3s   %4.4s %16s %16.16s    ", "","", "", "");
                else                    buf_len += sprintf(buf+buf_len, "%16.16s %16.16s", "", "");

                if (x == 0 || data_addr[col * MAX_LINES + x]) have_data = 1;
            }
            if (!have_data) break;      /* quit when no columns have data */
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%s\n", buf);
        }
    }
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "\n");
    if (tablefile) aapl_free(aapl, tablefile, __func__);
    if (data) aapl_free(aapl, data, __func__);
    if (data_addr) aapl_free(aapl, data_addr, __func__);
}


#endif /* AAPL_ENABLE_DIAG */

/** @cond INTERNAL */

/** @brief   Converts a memory address and bit number to register name found in mapfile */
/** @details Bit can either be the exact bit, or the lowest bit within a bitfield */
/** @return  Updates *str with the resulting name. Need to be allocated and destroyed by caller */
void aapl_mem_addr_bitfield_to_str(
    Aapl_t *aapl,
    uint sbus_addr,
    uint mem_addr,
    uint bit_field_bits,
    uint bit_field_shift,
    char *str)
{
#if AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO && AAPL_ENABLE_MAIN
    char * mapfile = 0;
    char bitfield[16];
    if (bit_field_bits > 1) snprintf(bitfield, 15, "%u:%u", bit_field_shift + bit_field_bits - 1, bit_field_shift);
    else                    snprintf(bitfield, 15, "%u", bit_field_shift);
    mapfile = read_serdes_mapfile(aapl, sbus_addr, FALSE);
    search_map_file(aapl, mapfile, mem_addr, bitfield, str);
    if (str[0] == 0)
    {
        if (mapfile) aapl_free(aapl, mapfile, __func__);
        mapfile = read_serdes_mapfile(aapl, sbus_addr, TRUE);
        search_map_file(aapl, mapfile, mem_addr, bitfield, str);
    }
    if (mapfile) aapl_free(aapl, mapfile, __func__);
#else
    (void)aapl, (void)sbus_addr, (void)mem_addr, (void)bit_field_bits, (void)bit_field_shift;
    str[0] = '\0';
#endif /* AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO && AAPL_ENABLE_MAIN */
}

/** @brief   Converts a memory address to register name found in tablefile */
/** @return  Updates *str with the resulting name. Need to be allocated and destroyed by caller */
void aapl_mem_addr_to_str(
    Aapl_t *aapl,
    uint sbus_addr,
    uint mem_addr,
    char *str)
{
#if AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO && AAPL_ENABLE_MAIN
    char * tablefile = 0;
    tablefile = read_spico_tablefile(aapl, sbus_addr);
    search_table_file_addr(aapl, tablefile, mem_addr, str);
    if (tablefile) aapl_free(aapl, tablefile, __func__);
#else
    (void)aapl, (void)sbus_addr, (void)mem_addr, (void)str;
#endif /* AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO && AAPL_ENABLE_MAIN */
}

/** @brief   Converts a memory name found in tablefile to address */
/** @return  Returns address if found, otherwise -1 */
void aapl_str_to_mem_addr(
    Aapl_t *aapl,
    uint sbus_addr,
    const char *str,
    int* addr,
    uint* bit_field_bits,
    uint* bit_field_shift
)
{
#if AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO && AAPL_ENABLE_MAIN
    char * tablefile = 0;
    *addr = -1;
    *bit_field_bits = 0;
    *bit_field_shift = 0;

    tablefile = read_spico_tablefile(aapl, sbus_addr);
    *addr = search_table_file_str(aapl, tablefile, str);
    if (tablefile) aapl_free(aapl, tablefile, __func__);

    if (*addr == -1)
    {
        tablefile = read_serdes_mapfile(aapl, sbus_addr, FALSE);
        *addr = search_map_file_str(aapl, tablefile, str, bit_field_bits, bit_field_shift);
        if (tablefile) aapl_free(aapl, tablefile, __func__);
    }
    if (*addr == -1)
    {
        tablefile = read_serdes_mapfile(aapl, sbus_addr, TRUE);
        *addr = search_map_file_str(aapl, tablefile, str, bit_field_bits, bit_field_shift);
        if (tablefile) aapl_free(aapl, tablefile, __func__);
    }
#else
    (void) aapl, (void) sbus_addr, (void) str, (void) addr, (void) bit_field_bits, (void) bit_field_shift;
#endif /* AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO && AAPL_ENABLE_MAIN */
}

/** @endcond */


/** @brief   Gathers detailed data from a SerDes. */
/** @details Gathers a user defined table of TX, RX, DFE, and other information for a single SerDes. */
/**          Verbose == 1: Print regardless if CRC passes, and print some extra details. */
/**          Verbose == 2: Print eye data as part of RX info */
/** @return  A pointer to the string containing the data requested. */
char *avago_serdes_get_state_dump(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint addr,              /**< [in] SBus address to SerDes. */
    uint disable_features,  /**< [in] Bitmask of features to disable. */
    BOOL ignore_errors,     /**< [in] Continue in face of errors. */
    uint refclk_hz)         /**< [in] The actual reference clock frequency.  If 0, it will be estimated. */
{
    uint features       = ~disable_features;
    uint header         = features & 0x00000001;
    uint tx             = features & 0x00000002;
    uint rx             = features & 0x00000004;
    uint clk            = features & 0x00000020;
#if AAPL_ENABLE_ESCOPE_MEASUREMENT || AAPL_ENABLE_PHASE_CALIBRATION
    uint rx_data        = features & 0x00000040;
#endif
    uint pon            = features & 0x00000080;

    uint details        = features & 0x10000000;
    uint column_header  = features & 0x80000000;

    char *buf = 0;
    char *buf_end = 0;
    int size = 0;
    int crc = 0;
    uint fw_rev, fw_build_id, eng_rel;
    int failed = 0;
    int spico_running;
    int ip_type = aapl_get_ip_type(aapl, addr);

    if( !aapl_check_process(aapl, addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28) ||
        !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) )
        return 0;

    AAPL_SUPPRESS_ERRORS_PUSH(aapl);
    spico_running = avago_spico_running(aapl, addr);
    crc = avago_spico_crc(aapl, addr);
    fw_rev      = avago_firmware_get_rev(aapl, addr);
    fw_build_id = avago_firmware_get_build_id(aapl, addr);
    eng_rel     = avago_firmware_get_engineering_id(aapl, addr);
    AAPL_SUPPRESS_ERRORS_POP(aapl);

    if ((!crc || !spico_running) & !ignore_errors) failed = 1;

    if (header)
    {
        int lsb_rev     = aapl_get_lsb_rev(aapl, addr);
        const char *rev_id_name = avago_get_ip_info(aapl,addr)->rev_id_name;
        aapl_buf_add(aapl, &buf, &buf_end, &size, "########## %s %s %s\n", "SerDes state dump for SBus address", aapl_addr_to_str(addr), " ##############################");
        if (eng_rel) aapl_buf_add(aapl, &buf, &buf_end, &size, "%s LSB rev %d. Firmware: 0x%04X_%04X_%03X.\n\n", rev_id_name, lsb_rev, fw_rev, fw_build_id, eng_rel);
        else         aapl_buf_add(aapl, &buf, &buf_end, &size, "%s LSB rev %d. Firmware: 0x%04X_%04X.\n\n", rev_id_name, lsb_rev, fw_rev, fw_build_id);
    }

    {
        Avago_serdes_pll_state_t tx_pll, rx_pll;
        const char *sep = "---------------";
        BOOL tx_en = FALSE, rx_en = FALSE;
        int  tx_width = 0, rx_width = 0;
        Avago_serdes_tx_data_sel_t tx_data_sel = AVAGO_SERDES_TX_DATA_SEL_PRBS7;
        if( tx || details )
            tx_data_sel = avago_serdes_get_tx_data_sel(aapl, addr);
        if( tx || rx )
        {
            avago_serdes_get_tx_rx_ready(aapl, addr, &tx_en, &rx_en);
            avago_serdes_get_tx_rx_width(aapl, addr, &tx_width, &rx_width);
        }

        /*////// Display TX info: */
        if (tx && column_header)
        {
              const char *fmt = "%8.8s %.2s %.5s %.3s %.3s %.4s %.5s %.4s %.3s %.4s %.3s %5.5s %8.8s %.3s %.4s %8.8s %8.8s %8.8s %8.8s %.4s %.3s %.4s %.2s\n";
              aapl_buf_add(aapl, &buf, &buf_end, &size, fmt,
                "Addr", "TX", "Width", "Pam", "Inv", "Gray", "Pcode", "Swzl", " CF", "Rate", "Div", "Gbps", "Data", "Out", "Pre3", "Pre2", "Pre1", "Atten", "Post", "Vert", "Amp", "Slew", "T2");
              aapl_buf_add(aapl, &buf, &buf_end, &size, fmt, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep);
        }
        if (tx && failed) aapl_buf_add(aapl, &buf, &buf_end, &size, "%6s No data collected. CRC: %d, spico_running: %d\n", aapl_addr_to_str(addr), crc, spico_running);
        else if (tx )
        {
            BOOL                 tx_out       = avago_serdes_get_tx_output_enable(aapl, addr);
            BOOL                 tx_encoding  = avago_serdes_get_tx_line_encoding(aapl, addr);
            char                 pre[8], pre2[8], pre3[4], atten[8], post[8], vert[4], amp[4], slew[4], t2[2];
            int                  sdrev;
            Avago_serdes_tx_eq_t tx_eq;
            Avago_serdes_datapath_t tx_datapath;
            memset(&tx_datapath, 0, sizeof(tx_datapath));
            avago_serdes_get_tx_eq(aapl, addr, &tx_eq);
            avago_serdes_get_tx_datapath(aapl, addr, &tx_datapath);

            aapl_buf_add(aapl, &buf, &buf_end, &size, "%8s %2d %5d %3s %3s ",
                            aapl_addr_to_str(addr), tx_en, tx_width, tx_encoding?"4":"2", aapl_onoff_to_str(tx_datapath.polarity_invert));
            if( ip_type == AVAGO_M4 )
            {
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%4s %5s %4s", aapl_onoff_to_str(tx_datapath.gray_enable),
                aapl_onoff_to_str(tx_datapath.precode_enable), aapl_onoff_to_str(tx_datapath.swizzle_enable));
            }
            else
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%4s %5s %4s", " ", " ", " ");
            {
                int mhz;
                memset(&tx_pll, 0, sizeof(tx_pll));
                avago_serdes_get_tx_pll_state(aapl, addr, &tx_pll);
                if( refclk_hz == 0 )
                    mhz = tx_pll.est_rate / 1000000;
                else
                    mhz = refclk_hz / 1000 * tx_pll.divider / 1000;
                if( tx_encoding ) mhz *= 2;

                    aapl_buf_add(aapl, &buf, &buf_end, &size, " %3u %2d.%1d %3u %2d.%02d ",
                        tx_pll.cal_code, tx_pll.line_rate_div/1000, (tx_pll.line_rate_div / 100) % 10, tx_pll.divider, mhz/1000, (mhz / 10) %100);
            }

            memset(pre, 0, sizeof(pre));
            memset(pre2, 0, sizeof(pre2));
            memset(pre3, 0, sizeof(pre3));
            memset(post, 0, sizeof(post));
            memset(atten, 0, sizeof(atten));
            memset(amp, 0, sizeof(amp));
            memset(slew, 0, sizeof(slew));
            memset(vert, 0, sizeof(vert));
            memset(t2, 0, sizeof(t2));
            sdrev = aapl_get_sdrev(aapl,addr);
            switch(sdrev)
            {
            case AAPL_SDREV_CM4:
            case AAPL_SDREV_CM4_16:
                snprintf(pre, sizeof(pre), "%d", tx_eq.pre);
                snprintf(pre2, sizeof(pre2), "%d", tx_eq.pre2);
                snprintf(atten, sizeof(atten), "%d", tx_eq.atten);
                snprintf(post, sizeof(post), "%d", tx_eq.post);
                snprintf(pre3, sizeof(pre3), "%d", tx_eq.pre3);
                break;
            case AAPL_SDREV_OM4:
                ( tx_eq.pre_lsb != tx_eq.pre_msb ) ? snprintf(pre, sizeof(pre), "%d,%d", tx_eq.pre_msb, tx_eq.pre_lsb) : snprintf(pre, sizeof(pre), "%d", tx_eq.pre_msb);
                ( tx_eq.atten_lsb != tx_eq.atten_msb ) ? snprintf(atten, sizeof(atten), "%d,%d", tx_eq.atten_msb, tx_eq.atten_lsb) : snprintf(atten, sizeof(atten), "%d", tx_eq.atten_msb);
                ( tx_eq.post_lsb != tx_eq.post_msb ) ? snprintf(post, sizeof(post), "%d,%d", tx_eq.post_msb, tx_eq.post_lsb) : snprintf(post, sizeof(post), "%d", tx_eq.post_msb);
                snprintf(vert, sizeof(vert), "%d", tx_eq.vert);
                snprintf(t2, sizeof(t2), "%d", tx_eq.t2);
                break;
            case AAPL_SDREV_HVD6:
                snprintf(amp, sizeof(amp), "%d", tx_eq.amp);
            case AAPL_SDREV_PON:
            case AAPL_SDREV_D6 :
            case AAPL_SDREV_16 :
                snprintf(slew, sizeof(slew), "%d", tx_eq.slew);
            default:
                snprintf(pre, sizeof(pre), "%d", tx_eq.pre);
                snprintf(atten, sizeof(atten), "%d", tx_eq.atten);
                snprintf(post, sizeof(post), "%d", tx_eq.post);
                break;
            }
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%8s %3d %4.4s %8.8s %8.8s %8.8s %8.8s %4.4s %3.3s %4.4s %2.2s \n",
                    aapl_data_sel_to_str(tx_data_sel), tx_out, pre3, pre2, pre, atten, post, vert, amp, slew, t2);
        }
        if (tx && header) aapl_buf_add(aapl, &buf, &buf_end, &size, "\n");

        /*////// Display RX info: */
        if (rx && column_header)
        {
            BOOL ber = FALSE;
            const char *fmt;
#if AAPL_ENABLE_FLOAT_USAGE
            ber = TRUE;
#endif
            fmt = "%8.8s %.2s %.5s %.3s %.3s %.4s %.5s %.4s %.3s %.4s %.3s %5.5s %9.9s %8.8s %12.12s %3.3s %.2s %.2s %.2s %.6s %5.5s %5.5s %1.1s %10.10s %10.10s\n";
            aapl_buf_add(aapl, &buf, &buf_end, &size, fmt,
                "Addr", "RX", "Width", "Pam", "Inv", "Gray", "Pcode", "Swzl", " CF", "Rate", "Div", "Gbps", "Data", "Qual", "Cmp_Mode", "EI", "OK", "LK", "LB", "o_core", "Term", "Phase", "E", "Errors", ber ? "BER" : "");
            aapl_buf_add(aapl, &buf, &buf_end, &size, fmt, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, sep, ber ? sep : "");
        }
        if      (rx && failed) aapl_buf_add(aapl, &buf, &buf_end, &size, "%6s No data collected. CRC: %d, spico_running: %d\n", aapl_addr_to_str(addr), crc, spico_running);
        else if (rx)
        {
#if AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG
            Avago_addr_t addr_struct;
            float                       ber;
            char                        ber_buf[16]  = "-";
#endif
            Avago_serdes_data_qual_t    data_qual  = avago_serdes_get_data_qual(aapl,addr);
            int                         rx_input_sel = avago_serdes_get_rx_input_loopback(aapl,addr);
            Avago_serdes_rx_term_t      rx_term      = avago_serdes_get_rx_term(aapl, addr);
            Avago_serdes_rx_cmp_mode_t  rx_cmp_mode  = avago_serdes_get_rx_cmp_mode(aapl, addr);
            Avago_serdes_rx_cmp_data_t  rx_cmp_data  = avago_serdes_get_rx_cmp_data(aapl, addr);
            uint                        error_count  = avago_serdes_get_errors(aapl, addr, AVAGO_LSB, FALSE);
            BOOL                        aux_error_en = FALSE;
            BOOL                        error_flag   = avago_serdes_get_error_flag(aapl, addr, FALSE);
            BOOL                        signal_ok1;
            BOOL                        signal_ok2;
            BOOL                        freq_lock    = avago_serdes_get_frequency_lock(aapl, addr);
            Avago_serdes_line_encoding_t  rx_encoding;
            Avago_serdes_line_encoding_t  tx_encoding;
            int                         ip_type      = aapl_get_ip_type(aapl, addr);
            char                        elec_idle_buf[16];
            char                        error_cnt_buf[16] = "-";
            Avago_serdes_datapath_t     rx_datapath;

            memset(&rx_datapath, 0, sizeof(rx_datapath));
            avago_serdes_get_tx_rx_line_encoding(aapl, addr, &tx_encoding, &rx_encoding);

                signal_ok1   = avago_serdes_get_signal_ok(aapl, addr, TRUE);
                signal_ok2   = avago_serdes_get_signal_ok(aapl, addr, TRUE);

#if AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG
            avago_addr_to_struct(addr, &addr_struct);
            if (aapl_get_sdrev(aapl,addr) == AAPL_SDREV_CM4_16 && (avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x41) & 0xc000) == 0x8000) /* is the aux error counter enabled? */
            {
                error_count = avago_serdes_aux_counter_read(aapl, addr);
                ber = avago_serdes_get_ber(aapl, &addr_struct, 0, 0, FALSE, 0, TRUE); /* use aux counter */
                aux_error_en = TRUE;
            }
            else ber = avago_serdes_get_ber(aapl, &addr_struct, 0, 0, FALSE, 0, FALSE);
#endif

            if (!avago_serdes_get_signal_ok_enable(aapl, addr))    snprintf(elec_idle_buf, sizeof(elec_idle_buf), "Dis");
            else if (avago_serdes_get_electrical_idle(aapl, addr)) snprintf(elec_idle_buf, sizeof(elec_idle_buf), "1");
            else                                                   snprintf(elec_idle_buf, sizeof(elec_idle_buf), "0");

            if (aux_error_en || aapl->debug || (
            strstr("unqual", aapl_data_qual_to_str(data_qual)) &&
            rx_cmp_mode != AVAGO_SERDES_RX_CMP_MODE_OFF && rx_cmp_mode != AVAGO_SERDES_RX_CMP_MODE_XOR))
            {
                snprintf(error_cnt_buf, sizeof(error_cnt_buf), "%10u", error_count);
#if AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG
                if( error_count == 0xffffffff ) ber = 0.0; /* Don't bother displaying ber if error count is maxed out. */
                if( ber && (error_count == 0) ) snprintf(ber_buf, sizeof(ber_buf), "<%.3e", ber);
                else if( ber )                  snprintf(ber_buf, sizeof(ber_buf), " %.3e", ber);
                else                            snprintf(ber_buf, sizeof(ber_buf), " -");
#endif
            }

#           if AAPL_ENABLE_EYE_MEASUREMENT
            if (aapl->verbose >= 3)
            {
                Avago_serdes_eye_config_t *eye_config = avago_serdes_eye_config_construct(aapl);
                Avago_serdes_eye_data_t *eye_data = avago_serdes_eye_data_construct(aapl);
                eye_config->ec_eye_type = AVAGO_EYE_SIZE;
                /*eye_config->ec_y_points = y_points; */
                /*eye_config->ec_y_step_size = y_step_size; */
                /*eye_config->ec_x_resolution = x_resolution; */

                avago_serdes_eye_get(aapl, addr, eye_config, eye_data);

                aapl_log_printf(aapl,AVAGO_INFO,0,0,"\n");
                avago_serdes_eye_vbtc_log_print(aapl, AVAGO_INFO, __func__, __LINE__, &eye_data->ed_vbtc[0]);
                avago_serdes_eye_hbtc_log_print(aapl, AVAGO_INFO, __func__, __LINE__, &eye_data->ed_hbtc[0]);

                /*avago_serdes_eye_plot_log_print(aapl, AVAGO_INFO, __func__, __LINE__, eye_data); */

                avago_serdes_eye_config_destruct(aapl, eye_config);
                avago_serdes_eye_data_destruct(aapl, eye_data);
            }
#           endif /* AAPL_ENABLE_EYE_MEASUREMENT */
            avago_serdes_get_rx_datapath(aapl, addr, &rx_datapath);
            aapl_buf_add(aapl, &buf, &buf_end, &size, "%8s %2d %5d %3s %3s ",
                            aapl_addr_to_str(addr), rx_en, rx_width, rx_encoding?"4":"2", aapl_onoff_to_str(rx_datapath.polarity_invert));
            if( ip_type == AVAGO_M4 )
            {
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%4s %5s %4s", aapl_onoff_to_str(rx_datapath.gray_enable),
                                aapl_onoff_to_str(rx_datapath.precode_enable), aapl_onoff_to_str(rx_datapath.swizzle_enable));
            }
            else
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%4s %5s %4s", " ", " ", " ");

            {
                int mhz;
                memset(&rx_pll, 0, sizeof(rx_pll));
                avago_serdes_get_rx_pll_state(aapl, addr, &rx_pll);
                if( refclk_hz == 0 )
                    mhz = rx_pll.est_rate / 1000000;
                else
                    mhz = refclk_hz / 1000 * rx_pll.divider / 1000;
                if( rx_encoding ) mhz *= 2;

                aapl_buf_add(aapl, &buf, &buf_end, &size,  " %3u %2d.%1d %3u %2d.%02d",
                                rx_pll.cal_code, rx_pll.line_rate_div/1000, (rx_pll.line_rate_div / 100) % 10, rx_pll.divider, mhz/1000, (mhz / 10) %100);
            }

            aapl_buf_add(aapl, &buf, &buf_end, &size, " %9s", aapl_cmp_data_to_str(rx_cmp_data));

            {
                const char *ptr = aapl_data_qual_to_str(data_qual);
                char temp[100];
                if( strlen(ptr) > 8 ) /* If string too long for display, abbreviate before display. */
                {
                    char *p;
                    strncpy(temp,ptr,100);
                    /* Edit dq string to replace lsb/msb/odd/even with single char abbreviation: */
                    while( (p = strstr(temp,"lsb" )) != NULL ) { *p++ = 'L'; strcpy(p,p+2); }
                    while( (p = strstr(temp,"msb" )) != NULL ) { *p++ = 'M'; strcpy(p,p+2); }
                    while( (p = strstr(temp,"odd" )) != NULL ) { *p++ = 'O'; strcpy(p,p+2); }
                    while( (p = strstr(temp,"even")) != NULL ) { *p++ = 'E'; strcpy(p,p+3); }
                    ptr = temp;
                }
                aapl_buf_add(aapl, &buf, &buf_end, &size, " %8s", ptr);
            }

            {
                int phase = 0;
                int o_core_status = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x27);

#if AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT || AAPL_ENABLE_DIAG
                phase = avago_serdes_get_phase(aapl, addr);
#endif
                aapl_buf_add(aapl, &buf, &buf_end, &size,  " %12s %3s %d%d %2d %2d 0x%04x %5s %5d %1d %10s",
                    aapl_cmp_mode_to_str(rx_cmp_mode),
                    elec_idle_buf, signal_ok1, signal_ok2, freq_lock, rx_input_sel, o_core_status, aapl_term_to_str(rx_term), phase, error_flag, error_cnt_buf);
            }
#if AAPL_ENABLE_FLOAT_USAGE && AAPL_ENABLE_DIAG
            aapl_buf_add(aapl, &buf, &buf_end, &size,  " %10s %s", ber_buf, aux_error_en ? "(errors and BER from aux counter)" : "");
#endif
            aapl_buf_add(aapl, &buf, &buf_end, &size, "\n");
        }
        if (rx && header) aapl_buf_add(aapl, &buf, &buf_end, &size, "\n");

        /*////// Display extra details */
        if (details && !failed)
        {
            int  threshold   = avago_serdes_get_signal_ok_threshold(aapl, addr);
            if( tx_data_sel == AVAGO_SERDES_TX_DATA_SEL_USER )
            {
                long tx_user[4];
                avago_serdes_get_tx_user_data(aapl, addr, tx_user);
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0, " (0x%05lx)", tx_user[0]);
            }
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n");

            aapl_buf_add(aapl, &buf, &buf_end, &size,  "TX PLL gains: bbGAIN=%2u, intGAIN=%2u\n", tx_pll.bbGAIN, tx_pll.intGAIN);
            aapl_buf_add(aapl, &buf, &buf_end, &size,  "RX PLL gains: bbGAIN=%2u, intGAIN=%2u\n", rx_pll.bbGAIN, rx_pll.intGAIN);

            if(    fw_build_id == 0x2447
                || fw_build_id == 0x244D
                || fw_build_id == 0x2347
                || fw_build_id == 0x2547
                || fw_build_id == 0x1047
                || fw_build_id == 0x104D
                )
            {
                int mVppd;
                if( fw_build_id == 0x1047 || fw_build_id == 0x104D )
                     mVppd = (threshold * 498 + 2140) / 100;    /*  7nm */
                else mVppd = (threshold * 93 - 37) / 10;        /* 16nm */
                if( mVppd < 0 ) mVppd = 0;
                aapl_buf_add(aapl, &buf, &buf_end, &size,  "RX: EI detection threshold        (12E,0x08) = %2d\n", avago_spico_int(aapl, addr, 0x12E, 0x08));
                aapl_buf_add(aapl, &buf, &buf_end, &size,  "RX: EI calibration user threshold (12E,0x10) = %2d  = ~%d mVppd\n", threshold, mVppd);
                aapl_buf_add(aapl, &buf, &buf_end, &size,  "RX: EI common mode offset         (12E,0x20) = %2d\n", (short)avago_spico_int(aapl, addr, 0x12E, 0x20));
            }
            else
                aapl_buf_add(aapl, &buf, &buf_end, &size,  "RX: EI threshold = %d\n", threshold);
        }
        if (details && header) aapl_buf_add(aapl, &buf, &buf_end, &size, "\n");

        /*////// Display RX info: */
#       if AAPL_ENABLE_ESCOPE_MEASUREMENT || AAPL_ENABLE_PHASE_CALIBRATION
        if (rx_data && aapl->verbose > 1)
        {
            if (column_header)
            {
                aapl_buf_add(aapl, &buf, &buf_end, &size,  "%6s %s\n" , "Addr", "RX Data");
                aapl_buf_add(aapl, &buf, &buf_end, &size,  "%6s %7s\n" , "------", "-------");
            }
            if      (failed) aapl_buf_add(aapl, &buf, &buf_end, &size, "%6s No data collected. CRC: %d, spico_running: %d\n", aapl_addr_to_str(addr), crc, spico_running);
            else
            {
                char *pattern = avago_serdes_pattern_capture(aapl, addr, 80);
                if (pattern) aapl_buf_add(aapl, &buf, &buf_end, &size,  "%6s %s\n" , aapl_addr_to_str(addr), pattern);
                if (pattern) aapl_free(aapl, pattern, __func__);
            }
            if (header) aapl_buf_add(aapl, &buf, &buf_end, &size, "\n");
        }
#       endif /* AAPL_ENABLE_ESCOPE_MEASUREMENT || AAPL_ENABLE_PHASE_CALIBRATION */

        /*////// Display CLK info: */
        if (clk && column_header)
        {
            if( aapl_get_ip_type(aapl,addr) == AVAGO_P1 )
            {
            aapl_buf_add(aapl, &buf, &buf_end, &size,  "    Addr         SPICO             TX PLL PCS FIFO\n");
            aapl_buf_add(aapl, &buf, &buf_end, &size,  "-------- ------------- ------------------ --------\n");
            }
            else
            {
            aapl_buf_add(aapl, &buf, &buf_end, &size,  "    Addr         SPICO             TX PLL PCS FIFO Data Edge Test  DFE  CDC\n");
            aapl_buf_add(aapl, &buf, &buf_end, &size,  "-------- ------------- ------------------ -------- ---- ---- ---- ---- -----\n");
            }
        }
        if      (clk && failed) aapl_buf_add(aapl, &buf, &buf_end, &size, "%6s No data collected. CRC: %d, spico_running: %d\n", aapl_addr_to_str(addr), crc, spico_running);
        else if (clk)
        {
            Avago_serdes_spico_clk_t spico_clk       = avago_serdes_get_spico_clk_src(aapl, addr);
            Avago_serdes_tx_pll_clk_t tx_pll_clk     = avago_serdes_get_tx_pll_clk_src(aapl, addr);
            Avago_serdes_pcs_fifo_clk_t pcs_fifo_clk = avago_serdes_get_pcs_fifo_clk_div(aapl, addr);

            int sdrev = aapl_get_sdrev(aapl,addr);
            if( sdrev == AAPL_SDREV_P1 )
            {
                aapl_buf_add(aapl, &buf, &buf_end, &size,  "%8.8s %13.13s %18.18s %-8.8s\n"
                    , aapl_addr_to_str(addr), aapl_spico_clk_to_str(spico_clk)
                    , aapl_pll_clk_to_str(tx_pll_clk), aapl_pcs_fifo_clk_to_str(pcs_fifo_clk));
            }
            else
            {
                Avago_serdes_rx_clocks_t rx_clock;
                memset(&rx_clock, 0, sizeof(rx_clock));
                avago_serdes_rx_clock_read(aapl, addr, &rx_clock);
                aapl_buf_add(aapl, &buf, &buf_end, &size,  "%8.8s %13.13s %18.18s %-8.8s %4.4s %4.4s %4.4s %4.4s %5.5s\n",
                    aapl_addr_to_str(addr), aapl_spico_clk_to_str(spico_clk), aapl_pll_clk_to_str(tx_pll_clk),
                    aapl_pcs_fifo_clk_to_str(pcs_fifo_clk),
                    aapl_rx_clock_to_str(rx_clock.data), aapl_rx_clock_to_str(rx_clock.edge),
                    aapl_rx_clock_to_str(rx_clock.test), aapl_rx_clock_to_str(rx_clock.dfe), aapl_rx_clock_cdc_to_str(rx_clock.cdc));
            }
        }
        if( clk && header ) aapl_buf_add(aapl, &buf, &buf_end, &size, "\n");

        /*////// Display DFE info */
        if( (features & 0x00000008) ||  (features & 0x00000010) ) /* DFE */
        {
            Avago_serdes_dfe_state_t dfe;

            memset(&dfe,0,sizeof(dfe));
            if (!failed)
                avago_serdes_get_dfe_state(aapl, addr, &dfe);

            if ( (features & 0x00000008) )
            {
                char *buf2 = avago_serdes_dfe_state_to_str(aapl, addr, &dfe, 0, 1, column_header);
                if (failed) aapl_buf_add(aapl, &buf, &buf_end, &size, "%6s No data collected. CRC: %d, spico_running: %d\n", aapl_addr_to_str(addr), crc, spico_running);
                if (buf2)
                {
                    aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", buf2);
                    aapl_free(aapl, buf2, __func__);
                }
            }


        }


        /*if( pon ) //&& aapl_get_sdrev(aapl,addr) == AAPL_SDREV_PON) // PON */
        if( pon && aapl_get_sdrev(aapl,addr) == AAPL_SDREV_PON) /* PON */
        {
            int addr_14c = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x14c);
            int addr_14b = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x14b);
            int addr_146 = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x146);
            int addr_c8 = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0xc8);
            int addr_a1 = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0xa1);
            int addr_121 = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x121);
            int addr_154 = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x154);
            int addr_143 = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x143);
            int addr_149 = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x149);
            int addr_140 = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x140);
            int addr_a2 = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0xa2);
            int addr_a3 = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0xa3);
            int addr_122 = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x122);
            int addr_123 = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x123);

            if (column_header)
            {
                aapl_buf_add(aapl, &buf, &buf_end, &size, "       Burst Valid   Rate SEL    DCRHP      KP            CDR        GAINDC   GAINHF    GAINLF\n");
                aapl_buf_add(aapl, &buf, &buf_end, &size, "        En DMA PIN  En DMA PIN   HI LO   Fast Std  Burst Lock KP OS  HI  LO   HI  LO    HI   LO\n");
                aapl_buf_add(aapl, &buf, &buf_end, &size, "       -----------  ----------   -----   --------  ----------------  ------  -------  ---------\n");
                /*aapl_buf_add(aapl, &buf, &buf_end, &size, "         0   0   0   0  00  00    7  7      f   f      0    0 ff ff  ff  ff  fff fff  ffff ffff\n"); */
            }

            aapl_buf_add(aapl, &buf, &buf_end, &size, "%6s %3d %3d %3d %3d %3d %3d   ", aapl_addr_to_str(addr),
                (addr_14c >> 12) & 0x1,
                (addr_14c >> 11) & 0x1,
                (addr_c8 >> 13) & 0x1,
                (addr_14b >> 9) & 0x1,
                (addr_146 >> 0) & 0x3,
                (addr_c8 >> 10) & 0x3);

            aapl_buf_add(aapl, &buf, &buf_end, &size, "%2d %2d   ", /* DCRHP */
                (addr_a1 >> 13) & 0x7,
                (addr_121 >> 13) & 0x7);

            aapl_buf_add(aapl, &buf, &buf_end, &size, "%4x %3x  ", /* KP */
                (addr_154 >> 12) & 0xf,
                (addr_143 >> 12) & 0xf);

            aapl_buf_add(aapl, &buf, &buf_end, &size, "%5d %4d %2x %2x  ", /* CDR */
                (addr_146 >> 3) & 0x1,
                (addr_149 >> 0) & 0x1,
                (addr_140 >> 0) & 0xff,
                (addr_140 >> 8) & 0xff);

            aapl_buf_add(aapl, &buf, &buf_end, &size, "%2x  %2x  ", /* gainDC */
                (addr_a1 >> 2) & 0x3f,
                (addr_121 >> 2) & 0x3f);

            aapl_buf_add(aapl, &buf, &buf_end, &size, "%3x %3x  ", /* gainHF */
                (addr_a3 >> 0) & 0xfff,
                (addr_123 >> 0) & 0xfff);

            aapl_buf_add(aapl, &buf, &buf_end, &size, "%4x %4x  ", /* gainLF */
                (addr_a2 >> 0) & 0x7fff,
                (addr_122 >> 0) & 0x7fff);
            aapl_buf_add(aapl, &buf, &buf_end, &size, "\n");
        }
    }
    return buf;
}

/** @brief   Prints detailed information from a SerDes. */
/** @details Prints a predefined table of TX, RX, DFE, and other information for a single SerDes. */
void avago_serdes_state_dump(Aapl_t *aapl, uint addr)
{
    char *buf = avago_serdes_get_state_dump(aapl, addr, 0, TRUE, 0);
    if (buf)
    {
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%s\n", buf);
        aapl_free(aapl, buf, __func__);
    }
}

/** @brief   Prints detailed information for a SerDes. */
/** @details Prints a table of TX, RX, DFE, and other information for the given SerDes. This function is broadcast safe. */
void avago_serdes_print_state_table_options(Aapl_t *aapl, Avago_addr_t *addr_struct, Avago_state_table_options_t *options)
{
    uint loop = 0;
    for (loop = 0; loop <= 6; loop++)
    {
        char space = 0;
        uint header = 0;
        Avago_addr_t start, stop, next;
        BOOL st;

        if (options) /* if no struct was passed in, do everything */
        {
            if (options->disable_tx && loop == 0) continue;
            if (options->disable_rx && loop == 1) continue;
            if (options->disable_dfe && loop == 2) continue;
            if (options->disable_dfe && loop == 3) continue; /* added this and shifted clk and data */
            if (options->disable_clk && loop == 4) continue;
            if (options->disable_data && loop == 5) continue;
        }

        for( st = aapl_broadcast_first(aapl, addr_struct, &start, &stop, &next, AAPL_BROADCAST_LANE);
             st;
             st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_LANE) )
        {
            char * buf = 0;
            uint sbus_addr = avago_struct_to_addr(&next);
            if( !aapl_check_ip_type(aapl, sbus_addr, 0, 0, FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) )
                continue;

            if (options && options->type_filter && options->type_filter != aapl_get_ip_type(aapl, sbus_addr)) continue;

            space=1;

            if (!header++)  buf = avago_serdes_get_state_dump(aapl, sbus_addr, ~(1 << (loop +1)) & ~0x80000000, FALSE, options ? options->refclk_hz : 0);
            else            buf = avago_serdes_get_state_dump(aapl, sbus_addr, ~(1 << (loop + 1)), FALSE, options ? options->refclk_hz : 0);

            if (buf)
            {
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%s", buf);
                aapl_free(aapl, buf, __func__);
            }

            if( loop == 2 && aapl->verbose >= 2 && aapl_get_ip_type(aapl, sbus_addr) == AVAGO_SERDES ) /* display VOS MID values and difference from mid which is, by definition, TAP1 for D6 */
            {
                int x;
                int vos[30];
                for (x = 0; x<=3; x++)   vos[x] = avago_spico_int(aapl, avago_struct_to_addr(&next), 0x126, 0x1000 | (x << 8));
                for (x = 9; x<=9+7; x++) vos[x] = avago_spico_int(aapl, avago_struct_to_addr(&next), 0x126, 0x1000 | (x << 8));

                aapl_log_printf(aapl, AVAGO_INFO, 0, 0,"                                                   ");
                for (x = 9; x<=9+3; x++) aapl_log_printf(aapl, AVAGO_INFO, 0, 0,"%2x  ", vos[x]);
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0,"        ");
                for (x = 9+4; x<=9+3+4-1; x++) aapl_log_printf(aapl, AVAGO_INFO, 0, 0,"%2x  ", vos[x]);
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n");
                /*for (int x = 0; x<=3; x++)   aapl_log_printf(aapl, AVAGO_INFO, 0, 0,"%2x  ", vos[x]); */
                /*aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n"); */
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0,"                                                   ");
                for (x = 0; x<=3; x++)   aapl_log_printf(aapl, AVAGO_INFO, 0, 0,"%2d  ", vos[9+x]-vos[x]);
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0,"\n");
            }
        }
        if (options && !options->keep_open && aapl_is_aacs_communication_method(aapl)) aapl_close_connection(aapl);
        if ( space == 1 )  aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n");
    }
}

/** @brief Print information on the device(s) AAPL is connected to using the AVAGO_INFO log type (which is typically STDOUT). */
/** @details The addr field selects the device to print info on. */
/**          As aapl->verbose levels increase, more information is printed */
/**          The type input will print info only for the IP type specified. */
/**          Provides additional options as compared with avago_device_info.\n */
/** @return void */
void avago_device_info_options(
    Aapl_t *aapl,
    Avago_addr_t *addr_struct,
    Avago_ip_type_t type,
    Avago_state_table_options_t *options)
{
    char buf[640];
    char *ptr = buf;
    BOOL st;
    Avago_addr_t start, stop, next;
    uint prev_chip = ~0;
    uint name_len = 0;
    const char **name_list = 0;
    Avago_addr_t addr2_struct = *addr_struct;

    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Avago Device Info:\n");

    aapl_log_printf(aapl, AVAGO_INFO, 0, 0,  "  Communication method:      %s\n", aapl_comm_method_to_str(aapl->communication_method));
    if(aapl_is_aacs_communication_method(aapl))
    {
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0,  "  Connected to:              %s:%d\n", aapl->aacs_server, aapl->tcp_port);
        if( aapl->capabilities != 0 )
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0,  "  Remote AACS capabilities:  %x\n", aapl->capabilities);
    }
    if( aapl->verbose >= 2 )
    {
        uint c;
        ptr += sprintf(ptr, "  Number of devices:         %d (", aapl->chips);
        for (c = 0; c < aapl->chips; c++)
            ptr += sprintf(ptr, c == 0 ? "%s" : ", %s", aapl->chip_name[c]);
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0,  "%s)\n", buf);

        aapl_log_printf(aapl, AVAGO_INFO, 0, 0,  "  debug:                     %x\n", aapl->debug);
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0,  "  enable_debug_logging:      %x\n", aapl->enable_debug_logging);
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0,  "  enable_stream_logging:     %x\n", aapl->enable_stream_logging);
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0,  "  enable_stream_err_logging: %x\n", aapl->enable_stream_err_logging);

        aapl_log_printf(aapl, AVAGO_INFO, 0, 0,  "  log size / data_char size: %d of %d / %d of %d\n",
            (aapl->data_char_end - aapl->data_char), aapl->data_char_size, (aapl->log_end - aapl->log), aapl->log_size);
    }

    for( st = aapl_broadcast_first(aapl, &addr2_struct, &start, &stop, &next, AAPL_BROADCAST_IGNORE_LANE);
         st && (!options || !options->disable_info);
         st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_IGNORE_LANE) )
    {
        if( next.chip != prev_chip )
        {
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0,   "\nInformation for chip %d:\n", next.chip);
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "  JTAG ID: 0x%08x", aapl->jtag_idcode[next.chip]);
            if (*aapl->chip_name[next.chip])  /* is there a name? */
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0, ";  %s rev %s", aapl->chip_name[next.chip], aapl->chip_rev[next.chip]);
            else
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0, " (%s)", aapl_hex_2_bin(aapl->data_char, aapl->jtag_idcode[next.chip], 0, 32));
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, ";  %s\n", aapl_process_id_to_str(aapl->process_id[next.chip]));

            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n");
            if( aapl->debug >= 4 ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "IP-ID ");
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "  Addr              IP Type  Rev  LSB Firmware        On Miscellaneous Info\n");
            if( aapl->debug >= 4 ) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "----- ");
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "------ -------------------- ---- ---- --------------- -- ----------------------\n");

            /* If AVSP device, read device to sbus address mapping lists: */
            name_len = 0;
            name_list = 0;
#if AAPL_ENABLE_AVSP
            if( 0 == strncmp(aapl->chip_name[next.chip], "AVSP-", 5) )
                avsp_get_name_list(aapl, next.chip, aapl->chip_name[next.chip], &name_len, &name_list);
#endif /* AAPL_ENABLE_AVSP */
        }
        prev_chip = next.chip;

        if( 0 == aapl->max_sbus_addr[next.chip][next.ring] ) continue;

        if ((int) next.sbus <= aapl->max_sbus_addr[next.chip][next.ring] + 2 || next.sbus == 0xfd || next.sbus == 0xfe )
        {
            Avago_addr_t addr_struct2;
            uint sbus_addr;
            Avago_ip_type_t ip_type;
            int ip_rev;
            ptr = buf;

            avago_addr_init(&addr_struct2);
            addr_struct2.chip = next.chip;
            addr_struct2.ring = next.ring;
            addr_struct2.sbus = next.sbus; /* need to make a copy in case we change it on the next line (otherwise the loop above would get upset) */
            addr_struct2.lane = next.lane;
            if ((int)next.sbus == aapl->max_sbus_addr[next.chip][next.ring] + 1) addr_struct2.sbus = 0xfd; /* Print out 0xfd, which is always present */
            if ((int)next.sbus == aapl->max_sbus_addr[next.chip][next.ring] + 2) addr_struct2.sbus = 0xfe; /* Print out 0xfe, which is always present */
            sbus_addr = avago_struct_to_addr(&addr_struct2);

            ip_type = aapl_get_ip_type(aapl, sbus_addr);
            if (type && type != ip_type) continue;  /* check for ip type filter */

            ip_rev = aapl_get_ip_rev(aapl, sbus_addr);

            if( aapl->debug >= 4 )
                ptr += sprintf(ptr,"0x%02x: ", avago_sbus_rd(aapl, sbus_addr, 0xff));
            if( next.sbus < name_len && name_list && name_list[next.sbus] )
            {
                char ip_type_buf[100];
                sprintf(ip_type_buf, "%s %s", aapl_ip_type_to_str(ip_type), name_list[next.sbus]);
                ptr += sprintf(ptr, "%6s %20s", aapl_addr_to_str(sbus_addr), ip_type_buf);
            }
            else
                ptr += sprintf(ptr, "%6s %20s", aapl_addr_to_str(sbus_addr), aapl_ip_type_to_str(ip_type));

            if( ip_type == AVAGO_PMRO )
                ptr += sprintf(ptr, "                              Simple PMRO metric: %d", avago_pmro_get_metric(aapl, sbus_addr));
            else if( ip_type == AVAGO_THERMAL_SENSOR || ip_type == AVAGO_SBUS2APB )
            {
                AAPL_SUPPRESS_ERRORS_PUSH(aapl);
                int i;
                int refclk = options ? options->refclk_hz : 0;
                refclk = refclk ? refclk : 156250000;   /* A reasonable default value */
                ptr += sprintf(ptr,"                              (");
                for( i = 0; i < 9; i++ ) /* temperature sensor range [0..8] */
                {
                    int mC = avago_sensor_get_temperature(aapl, sbus_addr, i, refclk);
                    refclk = 0;
                    if( mC < -40000 && !(aapl->debug & AAPL_DEBUG_TEMP_SENSOR) ) break;
                    ptr += sprintf(ptr, "%d.%d, ",mC/1000,(mC > 0 ? 1 : -1) * mC%1000/100);
                }
                if( i > 0 ) { ptr -= 2; ptr += sprintf(ptr, " C) ("); } /* Remove trailing ", " */
                for( i = 0; i < 8; i++ ) /* voltage sensor range [0..7] */
                {
                    int mV = avago_sensor_get_voltage(aapl, sbus_addr, i, 0);
                    if( mV < 10 && !(aapl->debug & AAPL_DEBUG_TEMP_SENSOR) ) break;
                    ptr += sprintf(ptr, "%d.%03d, ",mV/1000,(mV > 0 ? 1 : -1) * mV%1000);
                }
                ptr -= 2;   /* Remove trailing ", " */
                *ptr = '\0';
                if( i > 0 ) ptr += sprintf(ptr, " V)");
                AAPL_SUPPRESS_ERRORS_POP(aapl);
            }
#if AAPL_ENABLE_AVSP_1104
            else if (ip_type == AVAGO_AVSP_CONTROL_LOGIC)
            {
                Avsp_mode_t mode = avsp_1104_get_mode(aapl, addr_struct2.chip);
                ptr += sprintf(ptr, " 0x%02x                         mode=%s", ip_rev, aapl_avsp_mode_to_str(mode));
            }
#endif
#if AAPL_ENABLE_SERDES_AUTO_NEG
            else if (ip_type == AVAGO_AUTO_NEGOTIATION) /* Only on 28nm */
            {
                Avago_an_info_t an_info;
                if( avago_an_get_info(aapl, sbus_addr, &an_info) )
                    ptr += sprintf(ptr, " 0x%02x                       %d HCD=%s", an_info.ip_rev, an_info.enabled, aapl_an_hcd_to_str(an_info.hcd));
            }
#endif
#if AAPL_ENABLE_AVSP_8812
            else if (ip_type == AVAGO_SAPPH_GBX)
            {
                int status = avsp_8812_get_enabled(aapl, next.chip, next.sbus);
                ptr += sprintf(ptr, " 0x%02x", ip_rev);
                if( status >= 0 )
                    ptr += sprintf(ptr, "                         mode=%s",
                        status == 0 ? "Repeater"
                            : status == 1 ? "Gearbox_2:1" : "Gearbox_1:2");
            }
            else if (ip_type == AVAGO_CROSSPOINT)
            {
                ptr += sprintf(ptr, "     ");
                ptr += sprintf(ptr, " %08x", avago_sbus_rd(aapl, sbus_addr, 0));
                ptr += sprintf(ptr, " %04x", avago_sbus_rd(aapl, sbus_addr, 1));
                ptr += sprintf(ptr, " %01x", avago_sbus_rd(aapl, sbus_addr, 2));
                ptr += sprintf(ptr, " %08x", avago_sbus_rd(aapl, sbus_addr, 3));
                ptr += sprintf(ptr, " %08x", avago_sbus_rd(aapl, sbus_addr, 4));
                ptr += sprintf(ptr, " %08x", avago_sbus_rd(aapl, sbus_addr, 5));
            }
            else if (ip_type == AVAGO_RSFEC_BRIDGE)
            {
                int status = avsp_8812_get_enabled(aapl, next.chip, next.sbus);
                ptr += sprintf(ptr, " 0x%02x", ip_rev);
                if( status >= 0 )
                    ptr += sprintf(ptr, "                         mode=%s", status == 0 ? "Pass-through" : "RS-FEC");
            }
#endif
            else if (ip_type == AVAGO_SBUS_CONTROLLER)
            {
                int clk_div    = avago_sbm_get_sbus_clock_divider(aapl, sbus_addr);
                const char *halve = "";
                #if AAPL_ENABLE_AVSP
                if( avsp_get_refclk_divisor(aapl,next.chip) == 2 )
                    halve = "refclk_halve,";
                #endif
                ptr += sprintf(ptr, " 0x%02x      %-18s clock_divider=%d", ip_rev, halve, clk_div);
            }
            else /* serdes and SBus master */
            {
                int firm_rev   = aapl_get_firmware_rev(aapl, sbus_addr);
                int firm_build = aapl_get_firmware_build(aapl, sbus_addr);
                int eng_rel    = avago_firmware_get_engineering_id(aapl, sbus_addr);
                int lsb_rev    = aapl_get_lsb_rev(aapl, sbus_addr);
                int swap = 0;

                if (ip_rev != 0xffff) ptr += sprintf(ptr, " 0x%02x", ip_rev);
                else                  ptr += sprintf(ptr, " %4s","    ");

                if (lsb_rev >= 0)     ptr += sprintf(ptr, " 0x%02x", lsb_rev);
                else                  ptr += sprintf(ptr, " %4s","    ");

                /* Read indication of which swap image we have loaded. */
                if( firm_build == 0x0045 && ip_type == AVAGO_SERDES )
                    swap = avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_DMEM, 0x201) & 0x3;

                if (firm_rev != 0xffff)
                {
                    if( eng_rel ) ptr += sprintf(ptr, " 0x%04X_%04X_%03X%c %d", firm_rev, firm_build, eng_rel, " cp "[swap], aapl_get_spico_running_flag(aapl, sbus_addr));
                    else          ptr += sprintf(ptr, " 0x%04X_%04X%c     %d", firm_rev, firm_build, " cp "[swap], aapl_get_spico_running_flag(aapl, sbus_addr));
                }
                else ptr += sprintf(ptr, " %11s   ", "");

                {
                    const char *rev_id_name = avago_get_ip_info(aapl, sbus_addr)->rev_id_name;
                    if( *rev_id_name ) ptr += sprintf(ptr, " %-s", rev_id_name);
#  if AAPL_ENABLE_DIAG
                    else if( ip_type == AVAGO_SPICO && aapl_get_ip_rev(aapl, avago_make_sbus_controller_addr(sbus_addr)) >= 0xbe )
                    {
                        /* Note: This test does not work on McKinley (sbus_controller rev <= 0xbd). */
                        /* Check to see if swap code is loaded: */
                        uint imem[4];
                        uint next_addr = avago_spico_int(aapl, sbus_addr, 0x1C, 0); /* Get address after sbm image */
                        avago_sbm_imem_read(aapl, sbus_addr, next_addr, imem, AAPL_ARRAY_LENGTH(imem));
                        if( imem[2] == 2 )  /* imem[2] indicates how many swap images are present. */
                            ptr += sprintf(ptr, " swap=true");
                    }
#if 0
                    /* Display indication of which half of swap we have loaded: */
                    if( swap != 0 )
                        ptr += sprintf(ptr, " [swap=%s]", swap == 2 ? "PMD" : "CAL");
#endif
#  endif /* AAPL_ENABLE_DIAG */
                }

                while( ptr[-1] == ' ' ) *--ptr = '\0';  /* Strip trailing spaces */
            }
#if AAPL_ENABLE_AVSP_8812
            if( ip_type == AVAGO_SERDES
                && ( aapl->jtag_idcode[next.chip] == 0x1973157f  /* AVSP-8812r2 */
                  || aapl->jtag_idcode[next.chip] == 0x0973157f  /* AVSP-8812r1 */
                   ) )
            {
                int where_from = avsp_8812_crosspoint_get(aapl, next.chip, 19-next.sbus);
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%-s << %x\n", buf, where_from);
            }
            else
#endif /* AAPL_ENABLE_AVSP_8812 */
                aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%-s\n", buf);
        }
    }

    if (aapl->verbose >= 1 )
    {
        Avago_state_table_options_t options_local;
        if( !options )
        {
            memset(&options_local, 0, sizeof(options_local));
            options = &options_local;
        }

        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n");

        if( type )
        {
            options->type_filter = type;
            avago_serdes_print_state_table_options(aapl, addr_struct, options);
        }
        else
        {
            options->type_filter = AVAGO_UNKNOWN_IP;
            #if 0
            options->type_filter = AVAGO_M4;
            avago_serdes_print_state_table_options(aapl, addr_struct, options);
            options->type_filter = AVAGO_SERDES;
            avago_serdes_print_state_table_options(aapl, addr_struct, options);
            options->type_filter = AVAGO_P1;
            #endif
            avago_serdes_print_state_table_options(aapl, addr_struct, options);
        }
    }

    if (aapl->verbose >= 3 )
    {
        aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "  Aapl_t buffers:\n");
        aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "  --------- data_char:       ---------\n%s\n", aapl->data_char);
        aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "  --------- end of data_char ---------\n");
        aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "  --------- log:             ---------\n");
#       ifdef AAPL_STREAM
        fwrite(aapl->log, 1, aapl->log_end - aapl->log, AAPL_STREAM);
#       endif
        aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "  --------- end of log       ---------\n");
        aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "\n");
    }
/*  ptr = buf; */
/*  snprintf(ptr, 80, "########## %s %s %s\n", "End of", __func__, "################################################################################"); */
/*  ptr[78] = '\n'; */
/*  aapl_log_printf(aapl, AVAGO_INFO, 0, 0, buf); */
}

#if AAPL_ENABLE_DIAG

static void phase_slips(Aapl_t *aapl, uint addr, const char *str, int cycles, int interrupt, int interrupt_data, int beacon_addr, int beacon_shift)
{
    int x;
    int distance = -1;
    int orig_beacon = (avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, beacon_addr) >> beacon_shift) & 0x1;
    int size = 0;
    int size_first = 0;

    for (x=0; x<cycles; x++)
    {
        int beacon = (avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, beacon_addr) >> beacon_shift) & 0x1;
        if (beacon != orig_beacon && distance == -1) distance = x;
        if (!size_first && orig_beacon != beacon) size_first = 1;
        if (size_first == 1 && orig_beacon != beacon) size ++;
        if (size_first == 1 && orig_beacon == beacon) size_first = 2; /* done measuring size */
        if (aapl->verbose) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "## %3d %x\n", x, beacon);
        avago_spico_int(aapl, addr, interrupt, interrupt_data);
    }
    aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "%s: number of slips to first transition: %d. Size of first full window: %d\n", str, distance, size);
}

/** @brief   Sweeps various timing domain crossings to check for margin. */
/** @return  void */
void avago_serdes_phase_cal_diag(Aapl_t *aapl, uint addr, uint config)
{
    int tx_width = 0;
    int rx_width = 0;
    avago_serdes_get_tx_rx_width(aapl, addr, &tx_width, &rx_width);

    if (rx_width == 10) rx_width *= 2;
    rx_width *= 2;
    tx_width *= 2;
    if (config & 0x4) phase_slips(aapl, addr, "TX core -> LSB", tx_width , 0xd, 0x1, 0x22, 0);
    if (config & 0x2) phase_slips(aapl, addr, "TX LSB -> ESB", tx_width , 0xd, 0x100, 0xe1, 0);
    if (config & 0x1) phase_slips(aapl, addr, "RX ESB -> LSB", rx_width , 0xe, 0x1, 0x22, 1);
}


/** @brief   Allocates and initializes a default Avago_diag_config_t object. */
/** @return  On success, returns a pointer to the initialized structure, which */
/**          should be freed by calling avago_diag_config_destruct() after use. */
/** @return  On failure, returns NULL. */
/** @see     avago_serdes_diag(), avago_diag_config_destruct(). */
Avago_diag_config_t *avago_diag_config_construct(Aapl_t *aapl)
{
    int dividers[] = {10, 20, 30, 40, 50, 60, 66, 70, 80, 90, 100, 110, 120, 165, -1};
    Avago_diag_config_t *config;
    size_t bytes = sizeof(Avago_diag_config_t);

    if (! (config = (Avago_diag_config_t *) aapl_malloc(aapl, bytes, __func__))) return(NULL);
    memset(config, 0, sizeof(*config));         /* set all bytes to zero */

    config->binary           = TRUE;  /* Output data in binary also */
    config->columns          = FALSE; /* Output data in columns */
    config->serdes_init_only = FALSE; /* Stop after SerDes init is complete */
    config->state_dump       = TRUE;  /* SPICO state dump */
    config->sbus_dump        = TRUE;  /* ESB/LSB Data */
    config->dma_dump         = TRUE;  /* ESB/LSB Data */
    config->dmem_dump        = TRUE;  /* SPICO DMEM */
    config->imem_dump        = FALSE; /* SPICO IMEM */
    config->cycles           = 20;    /* Number of cycles to capture SPICO PC */
    config->refclk           = 156250000; /* Default refclk frequency. */

    config->dividers = (int *)aapl_malloc(aapl, sizeof(dividers), __func__);
    if( !config->dividers ) { aapl_free(aapl, config, __func__); return NULL; }

    memcpy(config->dividers, dividers, sizeof(dividers));
    return config;
}

/** @brief   Releases an Avago_diag_config_t struct. */
/** @return  None. */
/** @see     avago_diag_config_construct(), avago_serdes_diag(). */
void avago_diag_config_destruct(
    Aapl_t *aapl,
    Avago_diag_config_t *config)
{
    aapl_free(aapl, config->dividers, __func__);
    aapl_free(aapl, config, __func__);
}

/** @brief   Run diagnostics and memory dumps on SerDes. */
/** @details See the config struct for more info. */
/** */
/** @return Return 0 on success, negative on error. */
int avago_serdes_diag(
    Aapl_t *aapl,                   /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr_in,              /**< [in] SBus address to SerDes. */
    Avago_diag_config_t *config)    /**< [in] Options for the function. */
{
    BOOL st;
#if AAPL_ENABLE_AVSP
    BOOL self_healing = FALSE;
#endif
    Avago_addr_t addr_struct, start, stop, next;

    if (!aapl_check_process(aapl, sbus_addr_in, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28)) return 0;
    if (!aapl_check_ip_type(aapl, sbus_addr_in, __func__, __LINE__, TRUE, 5, AVAGO_SPICO, AVAGO_SERDES, AVAGO_SERDES_BROADCAST, AVAGO_M4, AVAGO_P1)) return 0;

    avago_addr_to_struct(sbus_addr_in, &addr_struct);
    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, 0);
         st;
         st = aapl_broadcast_next(aapl, &next, &start, &stop, 0) )
    {
        uint sbus_addr = avago_struct_to_addr(&next);

        if( !aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) )
            continue; /* skip non-SerDes */

        avago_diag_sbus_rw_test(aapl, sbus_addr, 2); /* do r/w test directly to the serdes */

        if(config->sbus_dump && !aapl->spico_int_only)
            avago_diag_sbus_dump(aapl, sbus_addr, config->binary);

        if (!aapl_check_process(aapl, sbus_addr_in, __func__, __LINE__, FALSE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28)) return 0;

#if AAPL_ENABLE_AVSP
        if (!aapl->spico_int_only && avsp_get_self_healing(aapl, next.chip))
        {
            self_healing = TRUE;
            avsp_set_self_healing(aapl, next.chip, FALSE); /* if self healing is on, disable it for the time being */
        }
#endif

        if (config->cycles && !aapl->spico_int_only)
            avago_spico_diag(aapl, sbus_addr, config->cycles);
        if(config->dma_dump || config->imem_dump || config->dmem_dump)
            avago_serdes_mem_dump(aapl, sbus_addr, config->binary, config->columns, config->dma_dump, config->dmem_dump, config->imem_dump, config->enable_annotation);
        if(config->state_dump)
            avago_serdes_state_dump(aapl, sbus_addr);
        if(config->pmd_debug)
        {
            Avago_serdes_pmd_debug_t * pmd = avago_serdes_pmd_debug_construct(aapl);
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "########## %s %s %s\n", "SerDes PMD debug for SBus address", aapl_addr_to_str(sbus_addr), " ##############################");
            if( pmd )
            {
                avago_serdes_pmd_debug(aapl, sbus_addr, pmd);
                avago_serdes_pmd_debug_print(aapl, pmd);
                avago_serdes_pmd_debug_destruct(aapl, pmd);
            }
        }

        if( config->destructive )
        {
            int div_loop = -1;
            while (config->dividers[++div_loop] != -1 && !(config->use_existing_divider && div_loop !=0))
            {
                int divider;
                int ilb, errors = 0;
                Avago_serdes_init_config_t *init_config = avago_serdes_init_config_construct(aapl);
                if (config->use_existing_divider)
                {
                    Avago_serdes_pll_state_t pll_state;
                    avago_serdes_get_tx_pll_state(aapl, sbus_addr, &pll_state);
                    divider = pll_state.divider;
                }
                else
                    divider = config->dividers[div_loop];

                if( init_config )
                {
                    int log_en = aapl->enable_stream_err_logging;
                    aapl->enable_stream_err_logging = 0; /* temporarily disable warnings and errors to the console (if enabled) */

                    init_config->init_tx = TRUE;
                    init_config->init_rx = TRUE;
                    init_config->sbus_reset = TRUE;
                    init_config->init_mode = AVAGO_PRBS31_ILB;
                    init_config->tx_divider = divider;
                    init_config->rx_divider = divider;
                    errors = avago_serdes_init(aapl, sbus_addr, init_config);
                    avago_serdes_init_config_destruct(aapl, init_config);

                    aapl->enable_stream_err_logging = log_en;
                }
                aapl_get_return_code(aapl); /* clear any errors // TBD clear errors from actual log */

                {
                    Avago_serdes_pll_state_t pll_state;
                    avago_serdes_get_tx_pll_state(aapl, sbus_addr, &pll_state);

                    aapl_log_printf(aapl, AVAGO_INFO, 0, 1,
                        "SerDes init complete for SBus addr %s using div %3d. "
                        "Estimated bit rate/ref clock: ~%3d Gbps / %3d MHz. CF: %3d. Errors in ILB: %d.\n",
                            aapl_addr_to_str(sbus_addr), divider,
                            (int)((pll_state.est_rate+500000000) / 1000000000),
                            (int)(pll_state.est_rate / 1000000) / divider, pll_state.cal_code, errors);
                    if (config->serdes_init_only) continue;
                }

                for (ilb = 1; ilb >= 0; ilb--)
                {
                    int data_sel_loop;
                    char test_name[256];
                    avago_serdes_set_rx_input_loopback(aapl, sbus_addr, ilb);
                    if (ilb) snprintf(test_name, 256, "ILB");
                    else     snprintf(test_name, 256, "ELB");

                    if      (ilb)
                    {
                        aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%10s %7s %2s %10s\n",      "Mode",       "Data",    "", "Non-invert");
                        aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%10s %7s %2s %10s\n",      "----------", "-------", "",   "----------");
                    }
                    else if (!ilb)
                    {
                        aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%10s %7s %2s %10s %10s\n", "Mode",       "Data",    "OK", "Non-invert", "Inverted");
                        aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%10s %7s %2s %10s %10s\n", "----------", "-------", "--", "----------", "--------");
                    }
                    /* Loop over values of enum, plus one more for USER data pattern. */
                    for (data_sel_loop = AVAGO_SERDES_TX_DATA_SEL_PRBS7; data_sel_loop <= AVAGO_SERDES_TX_DATA_SEL_USER; data_sel_loop ++)
                    {
                        Avago_serdes_tx_data_sel_t data_sel = (Avago_serdes_tx_data_sel_t) data_sel_loop;
                        Avago_serdes_rx_cmp_data_t cmp_data = (Avago_serdes_rx_cmp_data_t) data_sel_loop;
                        if( data_sel_loop == AVAGO_SERDES_TX_DATA_SEL_PRBS31+1 ) continue;  /* Skip unused value. */

                        avago_serdes_set_tx_data_sel(aapl, sbus_addr, data_sel);
                        avago_serdes_set_rx_cmp_data(aapl, sbus_addr, cmp_data);

                        if (!ilb) avago_serdes_initialize_signal_ok(aapl, sbus_addr, 0);       /* setup signal_ok check for checking in a few moments */
                                 avago_serdes_get_errors(aapl, sbus_addr, AVAGO_LSB, /*reset=*/ 1);
                        errors = avago_serdes_get_errors(aapl, sbus_addr, AVAGO_LSB, /*reset=*/ 0);
                        if (ilb) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%10s %7s %2s %10d\n", test_name, aapl_data_sel_to_str(data_sel), "", errors);
                        else
                        {
                            uint signal_ok = avago_serdes_get_signal_ok(aapl, sbus_addr, TRUE);
                            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%10s %7s %2d %10d ", test_name, aapl_data_sel_to_str(data_sel), signal_ok, errors);
                            avago_serdes_set_rx_invert(aapl, sbus_addr, 1);
                                     avago_serdes_get_errors(aapl, sbus_addr, AVAGO_LSB, /*reset=*/ 1);
                            errors = avago_serdes_get_errors(aapl, sbus_addr, AVAGO_LSB, /*reset=*/ 0);
                            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%10d", errors);
                            avago_serdes_set_rx_invert(aapl, sbus_addr, 0);

                            avago_serdes_set_rx_cmp_mode(aapl, sbus_addr, AVAGO_SERDES_RX_CMP_MODE_XOR);
                                     avago_serdes_get_errors(aapl, sbus_addr, AVAGO_LSB, /*reset=*/ 1);
                            errors = avago_serdes_get_errors(aapl, sbus_addr, AVAGO_LSB, /*reset=*/ 0);
                            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, " %10d\n", errors);
                            avago_serdes_set_rx_cmp_mode(aapl, sbus_addr, AVAGO_SERDES_RX_CMP_MODE_MAIN_PATGEN);
                        }
                    }
                    if (ilb) aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "\n");
                }
            }
        }
#if AAPL_ENABLE_AVSP
        if (self_healing) avsp_set_self_healing(aapl, next.chip, TRUE);
#endif
    }
    return aapl->return_code;
}

/**============================================================================= */
/** Diag */
/** Run diagnostics on various IP. See the Avago_diag_config_t struct for more info. */
/** */
/** @brief  Display diagnostics for the given address, which may be a */
/*          broadcast address. */
/** @return On success, returns 0.  Otherwise decrements aapl->return_code and returns -1; */
/** @return On failure, decrements aapl->return_code and returns -1; */
int avago_diag(Aapl_t *aapl, uint sbus_addr_in, Avago_diag_config_t *config)
{
    int return_code = aapl->return_code;
    BOOL st;
    BOOL free_config = FALSE;
    Avago_addr_t addr_struct, start, stop, next;

    if (!config)
    {
        free_config = TRUE;
        config = avago_diag_config_construct(aapl);
        config->columns = TRUE;
    }

    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "AAPL diag started. AAPL version: " AAPL_VERSION " Compiled: %s %s;  " AAPL_COPYRIGHT "\n", __DATE__, __TIME__);
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "aapl->return_code: %d\n", aapl->return_code);

    if (aapl->capabilities & AACS_SERVER_DIAG)
    {
        uint index;
        char cmd_buffer[320];
        char * cmd_buffer_end = cmd_buffer;

        cmd_buffer_end += snprintf(cmd_buffer_end, 319, "diag %s ", aapl_addr_to_str(sbus_addr_in));

        for (index = 0; index < sizeof(Avago_diag_config_t) - 8; index++) /* -8 don't include pointers at end of struct */
            cmd_buffer_end += snprintf(cmd_buffer_end, cmd_buffer_end - cmd_buffer - 319, "0x%x ", *((char *)config + index));

        aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Executing AACS direct diag cmd: %s\n", cmd_buffer);
        AAPL_SUPPRESS_ERRORS_PUSH(aapl);
        avago_aacs_send_command_options(aapl, cmd_buffer, /* recv_data_back */ 1, /* strtol */ 0);
        AAPL_SUPPRESS_ERRORS_POP(aapl);
        aapl_log_add(aapl, AVAGO_INFO, aapl->data_char, __func__, __LINE__);

        if (free_config) avago_diag_config_destruct(aapl, config);
        return return_code == aapl->return_code ? 0 : -1;
    }

    {
        int prev_verbose = aapl->verbose;
        Avago_addr_t addr_struct;
        avago_addr_to_struct(sbus_addr_in, &addr_struct);
        aapl->verbose = 0; /* prevents diag information from being printed */
        avago_device_info_options(aapl, &addr_struct, (Avago_ip_type_t) 0, 0);
        aapl->verbose = prev_verbose;
    }

    avago_addr_to_struct(sbus_addr_in, &addr_struct);
    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, 0);
         st;
         st = aapl_broadcast_next(aapl, &next, &start, &stop, 0) )
    {
        uint sbus_addr = avago_struct_to_addr(&next);
        if ((int)sbus_addr == aapl->max_sbus_addr[next.chip][next.ring] + 1) sbus_addr = 0xfd; /* aapl_broadcast_next will go to max_sbus_addr + 2 to allow inclusion of 0xfd and 0xfe */
        if ((int)sbus_addr == aapl->max_sbus_addr[next.chip][next.ring] + 2) sbus_addr = 0xfe; /* aapl_broadcast_next will go to max_sbus_addr + 2 to allow inclusion of 0xfd and 0xfe */

        if (aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, AVAGO_UNKNOWN_IP)) continue;
        if (!aapl_check_process(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28))
        {
            if (free_config) avago_diag_config_destruct(aapl, config);
            return 0;
        }
        if (aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1))
        {
            avago_serdes_diag(aapl, sbus_addr, config);
            continue;  /*  SerDes diag does a SBus dump, so continue */
        }

        if (config->sbus_dump ) avago_diag_sbus_dump(aapl, sbus_addr, config->binary);

        if (aapl_get_ip_type(aapl, sbus_addr) == AVAGO_SPICO)
        {
            if (config->cycles) avago_spico_diag(aapl, sbus_addr, config->cycles);
            if (config->imem_dump) avago_sbm_imem_dump(aapl, sbus_addr);
            if (config->dmem_dump) avago_sbm_dmem_dump(aapl, sbus_addr);
        }

        /* Dump ROM from SBus controller */
        if (config->imem_dump && aapl_get_ip_type(aapl, sbus_addr) == AVAGO_SBUS_CONTROLLER)
            avago_sbm_rom_dump(aapl, sbus_addr);

#if AAPL_ENABLE_FLOAT_USAGE
        if (aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, AVAGO_PMRO))
        {
            Avago_pmro_t *pmro_config = avago_pmro_construct(aapl);
            if( config->refclk )
                pmro_config->clock_freq = config->refclk / 1000000.0;
            avago_pmro_get_results(aapl, sbus_addr, pmro_config);
            avago_pmro_print_results(aapl, sbus_addr, pmro_config);
            avago_pmro_destruct(aapl,pmro_config);
        }
#endif /* AAPL_ENABLE_FLOAT_USAGE */
    }
    if (free_config) avago_diag_config_destruct(aapl, config);
    return return_code == aapl->return_code ? 0 : -1;
}

#endif /* AAPL_ENABLE_DIAG */
