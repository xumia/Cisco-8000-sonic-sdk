/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* Internal library API for AAPL (ASIC and ASSP Programming Layer). */

/** Doxygen File Header */
/** @file */
/** @brief Utility functions for main programs. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_MAIN
#if !defined HAVE_CONFIG_H
#  if !defined __MINGW32__ && !defined WIN32
#    define HAVE_GLOB_H
#  endif
#endif
#ifdef HAVE_GLOB_H
#include <glob.h>
#endif

/*/////////// GLOBAL VARIABLES */
/* Global defaults for various main programs */
int         aapl_default_divider          = 50;
int         aapl_default_pon_divider      = 66;
const char *aapl_default_firmware_rev     = "latest";
const char *aapl_default_sbm_firmware_rev = "latest";
/*/////////// END OF GLOBAL VARIABLES */

/** @cond INTERNAL */

/** @return Returns a valid build for the given IP. */
/**          If address does not reference a SPICO processor containing IP, */
/**          an empty string is returned (not NULL). */
const char *aapl_get_default_firmware_build(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    const char *fw_build = "";
    Avago_ip_type_t ip_type = aapl_get_ip_type(aapl,addr);
    Avago_process_id_t process_id = aapl_get_process_id(aapl,addr);
    uint ip_rev = aapl_get_ip_rev(aapl,addr);
    uint jtag_idcode = aapl_get_jtag_idcode(aapl,addr);

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "SBus %s, jtag_idcode = 0x%08x, ip_type = %s, ip_rev = 0x%2x\n", aapl_addr_to_str(addr), jtag_idcode, aapl_ip_type_to_str(ip_type), ip_rev);

    switch( ip_type )
    {
    case AVAGO_SERDES_D6_BROADCAST:
    case AVAGO_SERDES:
        {
            const char *id_name = avago_get_ip_info(aapl,addr)->rev_id_name;
            int lsb_rev = aapl_get_lsb_rev(aapl, addr);
            if( process_id == AVAGO_TSMC_16 )
            {
                if( ip_rev == 0x59 )               fw_build = "20F1"; /* v2 PON SerDes */
                else if( 0xb == lsb_rev )          fw_build = "20E1"; /* v1 PON SerDes */
                else if( strstr(id_name, "gen4") ) fw_build = "2347"; /* PCIE Gen 4 */
                else if( strstr(id_name, "pcie") )
                {
                    if( ip_rev < 0x4e || ip_rev == 0x55 || ip_rev == 0x5f )
                                                   fw_build = "2147"; /* Older PCIe */
                    else                           fw_build = "2447"; /* New PCIe */
                }
                else if( ip_rev <= 0x3f )          fw_build = "204D"; /* 16nm D6 (Simba, Tesla D6) */
                else                               fw_build = "244D"; /* 16nm D6 (Franklin 2, FermiB 2 D6) */
            }
            else if( process_id == AVAGO_TSMC_07 )
            {
                if( strstr(id_name, "pcie") )      fw_build = "1047"; /* 07nm PCIe */
                else                               fw_build = "104D"; /* 07nm ethernet */
            }
            /* 28nm: */
            else if( 8 == lsb_rev )                fw_build = "014F"; /* HVD6 */
            else                                   fw_build = "0241"; /* 28nm D6 */
            break;
        }
    case AVAGO_SERDES_M4_BROADCAST:
    case AVAGO_M4:
        if( process_id == AVAGO_TSMC_16 )
        {
            if(      ip_rev <= 0x0a ) fw_build = "A085"; /* Tesla */
            else if( ip_rev <= 0x28 ) fw_build = "A081"; /* Fermi, et al */
            else                      fw_build = "208D"; /* Production CM4 */
        }
        else if( process_id == AVAGO_TSMC_28 )
        {
            if(      ip_rev == 0xe4 ||
                     ip_rev == 0xe0 ) fw_build = "0085"; /* Coral CM4 */
            else if( ip_rev == 0xd8 ) fw_build = "8025"; /* Opal  OM4 */
            else                      fw_build = "0025"; /* Opal2 OM4 */
        }
        break;
    case AVAGO_SERDES_P1_BROADCAST:
    case AVAGO_P1:
        if( process_id == AVAGO_TSMC_16 )    fw_build = "20C3"; /* 16nm P1 */
        else if( jtag_idcode == 0x0985357f ) fw_build = "80C1"; /* Borah-Peak */
        else                                 fw_build = "00C1"; /* 28nm Opal 2 */
        break;
    case AVAGO_SPICO_BROADCAST:
    case AVAGO_SPICO:
        if(      process_id == AVAGO_TSMC_16 ) fw_build = "2001"; /* 16nm */
        else if( process_id == AVAGO_TSMC_07 ) fw_build = "1001"; /* 07nm */
        else
        {
            int ip_rev = aapl_get_ip_rev(aapl, avago_make_sbus_controller_addr(addr));
            if( ip_rev <= 0xbd )             fw_build = "8001"; /* McKinley and older */
            else                             fw_build = "0001"; /* 28nm */
        }
        break;
    default:
        break;
    }
    return fw_build;
}


/** @brief Searches the latest directory for firmware of the given build. */
/** @details If fw_rev is the string "latest", search the latest directory for */
/**          a revision with the specified build. */
/** @return If a firmware file of the given fw_build is found, returns TRUE and writes path into buf. */
/** @return Otherwise returns FALSE. */
BOOL aapl_find_firmware(Aapl_t *aapl, uint addr, const char *fw_build, char *buf, int buf_len)
{
    Avago_addr_t addr_struct;
    FILE *fp;
    char pattern[512];
    const char *path;
    const char *fw_rev;
    (void)aapl;

    avago_addr_to_struct(addr,&addr_struct);
    if( addr_struct.sbus == 0xfd )
    {
        path = AVAGO_FIRMWARE_PATH "sbus_master/%s/sbus_master.%s_%s.rom";
        fw_rev = aapl_default_sbm_firmware_rev;
        snprintf(pattern, sizeof(pattern), path, fw_rev, fw_rev, fw_build);
    }
    else
    {
        path = AVAGO_FIRMWARE_PATH "serdes/%s/serdes.%s_%s.rom";
        fw_rev = aapl_default_firmware_rev;
        snprintf(pattern, sizeof(pattern), path, fw_rev, fw_rev, fw_build);
    }

    fp = fopen(pattern,"r");  /* Does it exist? */
    if( fp )
    {
        fclose(fp);
        strncpy(buf, pattern, buf_len);
        return TRUE;
    }

#ifdef GLOB_ERR /* Do we have glob functionality? */
    {
        glob_t glob_data;
        if( addr_struct.sbus == 0xfd )
            path = AVAGO_FIRMWARE_PATH "sbus_master/%s/sbus_master.*_%s.rom";
        else
            path = AVAGO_FIRMWARE_PATH "serdes/%s/serdes.*_%s.rom";
        snprintf(pattern, sizeof(pattern), path, fw_rev, fw_build);

        if( 0 == glob(pattern, GLOB_ERR | GLOB_NOESCAPE, NULL, &glob_data) )
        {
            strncpy(buf, glob_data.gl_pathv[0], buf_len);
            globfree(&glob_data);
            return TRUE;
        }
        strncpy(buf, pattern, buf_len);
    }
#endif
    return FALSE;
}

/** @brief   Selects all entries matching the filter(s). */
/** @details out_list becomes list of matching addresses. */
/**          out_list should be freed using avago_addr_delete(). */
/** @return  Returns count of matching items. */
static int avago_filter_addr_list(
    Aapl_t *aapl,                   /**< [in] Pointer to Aapl_t structure. */
    Avago_addr_t *addr_list,        /**< [in] List of addresses to search. */
    Avago_addr_t *out_list,         /**< [out] List into which to place matching entries. */
    Avago_ip_type_t filter_ip_type, /**< [in] SerDes type (D6, M4 or P1). */
    int filter_sdrev)               /**< [in] If not 0, sub-type (PON, HVD6, etc).  Bit 15 selects PCIe variants. */
{
    int count = 0, group_count = 0;
    Avago_addr_t *addr_struct, *out_ptr = 0;
    uint group_addr = 0;
    const int pcie_bit = 1<<15;
    BOOL pcie_select = (filter_sdrev & pcie_bit) != 0;  /* Test for pcie_bit */

    filter_sdrev &= ~pcie_bit;  /* clear pcie_bit */

    avago_addr_init(out_list);

    for( addr_struct = addr_list; addr_struct != 0; addr_struct = addr_struct->next )
    {
        uint addr = avago_struct_to_addr(addr_struct);
        if( filter_ip_type == aapl_get_ip_type(aapl, addr)
            && (filter_sdrev == 0
                || (filter_sdrev == aapl_get_sdrev(aapl, addr) && pcie_select == (strstr(avago_get_ip_info(aapl, addr)->rev_id_name,"pcie") != 0)) ) )
        {
            if( count == 0 )
                group_addr = addr_struct->group_addr;
            if( (group_addr&0xff) == (addr_struct->group_addr&0xff) )
                group_count++;
            count++;
            if( out_ptr == 0 )
            {
                *out_list = *addr_struct;
                out_ptr = out_list;
                out_ptr->next = 0;
            }
            else
            {
                out_ptr->next = avago_addr_new_from_struct(aapl, addr_struct);
                out_ptr = out_ptr->next;
                out_ptr->group_addr = addr_struct->group_addr;
            }
        }
    }
    /* If all selected SerDes have same predefined group_addr, and sub-type */
    /* filtering is enabled, verify that no omitted SerDes has same */
    /* group_addr. */
    if( group_count == count && group_addr != 0 && filter_sdrev != 0 )
    {
        group_count = 0;
        for( addr_struct = addr_list; addr_struct != 0; addr_struct = addr_struct->next )
            if( (addr_struct->group_addr&0xff) == (group_addr&0xff) )
                group_count++;  /* Count total uses of group_addr */

    }
    if( group_count != count ) /* If out_list is not all group items, clear group_addr. */
        for( addr_struct = out_list; addr_struct != 0; addr_struct = addr_struct->next )
            addr_struct->group_addr = 0;
    return count;
}

/** @brief Copy status from filtered_list into addr_list. */
static void avago_filter_addr_list_merge_status(
    Avago_addr_t *addr_list,        /**< [in] List of addresses to search. */
    Avago_addr_t *status_list)      /**< [out] List into which to place matching entries. */
{
    Avago_addr_t *sl_ptr;
    for( sl_ptr = status_list; sl_ptr; sl_ptr = sl_ptr->next )
    {
        Avago_addr_t *al_ptr;
        for( al_ptr = addr_list; al_ptr; al_ptr = al_ptr->next )
        {
            if( al_ptr->sbus == sl_ptr->sbus &&
                al_ptr->ring == sl_ptr->ring &&
                al_ptr->chip == sl_ptr->chip &&
                al_ptr->lane == sl_ptr->lane )
            {
                al_ptr->results = sl_ptr->results;
                al_ptr->bigint_results = sl_ptr->bigint_results;
                break;
            }
        }
    }
}

/** @brief   Configures and calibrates multiple SerDes.  SerDes within each SerDes type are initialized in parallel. */
/** @details The initialization is done in parallel on all listed SerDes at once, as much as possible. */
/** @details Since the purpose of this function is performance, some configuration options are not supported. */
/**          If any of these are selected, a message will be logged and an error will be returned. */
/** @details LIMITATION: SerDes of multiple types are supported, but each type is initialized separately. */
/** @details LIMITATION: Both Tx and Rx must be enabled. */
/** @details LIMITATION: SBus reset must be enabled. */
/** @return  Individual success/failure values are saved into the bigint_results fields of addr_list (0==success). */
/** @return  Returns 0 if all initializations successfully return with zero ILB errors. */
/** @return  Returns -1 and decrements aapl->return_code if any failure. */
/** @see     avago_serdes_init_config_construct(), avago_serdes_init_config_destruct(), avago_parallel_serdes_init(), avago_serdes_init_quick(). */
/** @brief Returns 0 on success, -1 on failure. */
int avago_parallel_serdes_init_by_group(
    Aapl_t *aapl,                       /**< [in] Pointer to AAPL structure. */
    Avago_addr_t *addr_list,            /**< [in,out] List of addresses and results. */
    Avago_serdes_init_config_t *config) /**< [in] Desired SerDes configuration. */
{
    Avago_ip_type_t type_list[] = {AVAGO_M4, AVAGO_SERDES, AVAGO_P1, AVAGO_BLACKHAWK};
    int i;

    for( i = 0; i < AAPL_ARRAY_LENGTH(type_list); i++ )
    {
        Avago_addr_t filtered_list;

        int count = avago_filter_addr_list(aapl, addr_list, &filtered_list, type_list[i], 0);
        if( count > 0 )
        {
            int ret;
            config->fail_code = 0;
            ret = avago_parallel_serdes_init(aapl, &filtered_list, config);
            avago_filter_addr_list_merge_status(addr_list, &filtered_list);   /* Copy status from filtered_list into addr_list. */
            avago_addr_delete(aapl, &filtered_list);
            return ret;
        }
    }
    return 0;
}


#if AAPL_ENABLE_FILE_IO
/** @brief Finds a valid build for the given SerDes. */
/** @return Returns a valid build for the given SPICO. */
static void avago_serdes_get_default_firmware(Aapl_t *aapl, Avago_addr_t *addr_struct, const char *fw_build, char *buf, int len)
{
    uint addr = avago_struct_to_addr(addr_struct);
    if( !fw_build )
        fw_build = aapl_get_default_firmware_build(aapl, addr);
    if( !aapl_find_firmware(aapl, addr, fw_build, buf, len) )
        printf("WARNING: SBus %s, firmware revision '%s' for build '%s' not found.\n", aapl_addr_to_str(addr), aapl_default_firmware_rev, fw_build);
    return;
}

static void avago_print_address_list(Aapl_t *aapl, Avago_addr_t *addr_list)
{
    Avago_addr_t *addr_struct;
    for( addr_struct = addr_list; addr_struct != 0; addr_struct = addr_struct->next )
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, " %s", aapl_addr_to_str(avago_struct_to_addr(addr_struct)));
    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n");
}

static int avago_serdes_upload_filtered(
    Aapl_t *aapl,
    Avago_addr_t *addr_list,
    const char *fw_build,
    const char *firmware_file_ptr,
    char *buf,
    int len,
    Avago_ip_type_t filter_ip_type,
    int filter_sdrev)               /**< [in] If not 0, sub-type (PON, HVD6, etc).  Bit 15 selects PCIe variants. */
{
    Avago_addr_t filtered_list;

    int count = avago_filter_addr_list(aapl, addr_list, &filtered_list, filter_ip_type, filter_sdrev);
    if( count > 0 )
    {
        int group_count = 0;
        Avago_addr_t *addr_struct;
        const char *path = NULL;
        if( !firmware_file_ptr )
        {
            /* get path of default firmware */
            path = buf;
            avago_serdes_get_default_firmware(aapl, &filtered_list, fw_build, buf, len);
        }
        else
            path = firmware_file_ptr;
        for( addr_struct = addr_list; addr_struct != 0; addr_struct = avago_group_get_next(addr_struct) )
            group_count++;
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Uploading file %s to SBus address %s =", path, group_count == 1 && filtered_list.group_addr ? aapl_addr_to_str(filtered_list.group_addr) : "group");
        avago_print_address_list(aapl, &filtered_list);

        avago_parallel_spico_upload_file(aapl, &filtered_list, TRUE, path);
        avago_addr_delete(aapl, &filtered_list);
    }
    return count;
}

int avago_serdes_upload_firmware(Aapl_t *aapl, Avago_addr_t *addr_list, const char *fw_build, const char *firmware_file_ptr, char *buf, int len)
{
    const int PCIE_SERDES = 0x8000;
    int count = 0;
    count += avago_serdes_upload_filtered(aapl, addr_list, fw_build, firmware_file_ptr, buf, len, AVAGO_SPICO,  0);
    count += avago_serdes_upload_filtered(aapl, addr_list, fw_build, firmware_file_ptr, buf, len, AVAGO_M4,     0);
    count += avago_serdes_upload_filtered(aapl, addr_list, fw_build, firmware_file_ptr, buf, len, AVAGO_SERDES, AAPL_SDREV_D6_07|PCIE_SERDES);
    count += avago_serdes_upload_filtered(aapl, addr_list, fw_build, firmware_file_ptr, buf, len, AVAGO_SERDES, AAPL_SDREV_D6_07);
    count += avago_serdes_upload_filtered(aapl, addr_list, fw_build, firmware_file_ptr, buf, len, AVAGO_SERDES, AAPL_SDREV_16|PCIE_SERDES);
    count += avago_serdes_upload_filtered(aapl, addr_list, fw_build, firmware_file_ptr, buf, len, AVAGO_SERDES, AAPL_SDREV_16);
    count += avago_serdes_upload_filtered(aapl, addr_list, fw_build, firmware_file_ptr, buf, len, AVAGO_SERDES, AAPL_SDREV_PON);
    count += avago_serdes_upload_filtered(aapl, addr_list, fw_build, firmware_file_ptr, buf, len, AVAGO_SERDES, AAPL_SDREV_D6|PCIE_SERDES);
    count += avago_serdes_upload_filtered(aapl, addr_list, fw_build, firmware_file_ptr, buf, len, AVAGO_SERDES, AAPL_SDREV_D6);
    count += avago_serdes_upload_filtered(aapl, addr_list, fw_build, firmware_file_ptr, buf, len, AVAGO_SERDES, AAPL_SDREV_HVD6|PCIE_SERDES);
    count += avago_serdes_upload_filtered(aapl, addr_list, fw_build, firmware_file_ptr, buf, len, AVAGO_BLACKHAWK, (Aapl_sdrev_t)0);
    count += avago_serdes_upload_filtered(aapl, addr_list, fw_build, firmware_file_ptr, buf, len, AVAGO_P1,     0);
    return count;
}
#endif /* AAPL_ENABLE_FILE_IO */

/** @endcond */

const uint  aapl_default_device_addr    = 0;

/* Return TRUE if valid range, FALSE otherwise. */
/* Note: Returns range [start-stop]. */
BOOL aapl_parse_range(const char *range, int *start, int *stop)
{
    char *ptr;
    *start = *stop = aapl_strtol(range,&ptr,0);
    if( ptr > range && *ptr == '-' )
        *stop = aapl_strtol(ptr+1,&ptr,0);
    return *ptr == '\0' && *start >= 0 && *start <= *stop;
}

void aapl_common_main_help(BOOL show_addr_help)
{
    printf(
"\n"
/* ============================================================================== <- 80 characters */
"AAPL Version: " AAPL_VERSION "\n" AAPL_COPYRIGHT "\n"
"Usage: %s [options]\n", aapl_myname);

    printf(
"-server <IP_address>      AACS server's name or IP address; default = \"%s\".\n"
"-port <port_number>       AACS server's TCP/IP port number; default = %u.\n"
"-comm <comm_method>       Select how to communicate with hardware.\n"
"                           One of {AACS|USER}_{I2C|MDIO|SBUS}, SYSTEM_{I2C|MDIO}\n"
"                           {AACS}_{I2C|MDIO|SBUS|JTAG|BB_JTAG}|SYSTEM_{I2C|MDIO}\n"
"                           |GPIO_MDIO|OFFLINE Default from aapl.h: %s.\n"
    , aapl_default_server, aapl_default_port, aapl_comm_method_to_str(AAPL_DEFAULT_COMM_METHOD));

    printf(
"-sbus-rings <number>      How many SBus rings to communicate with.\n"
"                           See aapl.h for more info. Default from aapl.h: %d.\n", AAPL_NUMBER_OF_RINGS_OVERRIDE);
    if( AAPL_NUMBER_OF_RINGS_OVERRIDE == 0 )
    printf(
"                           (0 means use autodiscover, when possible.)\n"
);

    printf(
"-devices <number>         How many devices to communicate with.\n"
"                           See aapl.h for more info. Default from aapl.h: %d.\n", AAPL_NUMBER_OF_CHIPS_OVERRIDE);
    if( AAPL_NUMBER_OF_CHIPS_OVERRIDE == 0 )
    printf(
"                           (0 means use autodiscover, when possible.)\n"
);
    printf(
"-sbus-tdr-opcode-base <num> JTAG opcode for SBus iJTAG TDR.\n"
"                           Default from aapl.h: %d.\n", AAPL_DEFAULT_SBUS_TDR_OPCODE_BASE);
    printf(
"-mdio-base-addr <num>     MDIO base port address for MDIO communication modes.\n"
"                           Default from aapl.h: %d.\n", AAPL_DEFAULT_MDIO_BASE_PORT_ADDR);
    printf(
"-i2c-base-addr <num>      I2C base address for I2C communication modes.\n"
"                           Default from aapl.h: 0x%x.\n", AAPL_DEFAULT_I2C_BASE_ADDR);
    printf(
"-max-cmds-buff <num>      Max number of AACS commands to buffer.\n"
"                           Default from aapl.h: %d.\n"
    , AAPL_MAX_CMDS_BUFFERED);

    printf(
"-disable-time-stamps      Disable time stamps in log output.\n"
);

    if (show_addr_help) printf(
"-addr <addr>              SBus address (ie 0xa, 10, 0xffff).\n");

    printf(
"-debug <number>           Set AAPL debug level; valid range [0..9]; default = 0.\n"
"-verbose <level>          Increase output verbosity.\n"
"-diag-on-failure <num>    Run avago_diag a maximum of <num> time under specific\n"
"                            error conditions.\n"
"-help                     Print this usage summary.\n"
"-jtag <idcode 1> ... -jtag <idcode N>  Specify JTAG IDCODE(s).\n");

    printf(
"-timeout <count>          Set SerDes interrupt timeout loop count; default = %d.\n"
, AAPL_SERDES_INT_TIMEOUT
);
    printf(
"-tck-delay <int>          Sets TCK delay when in bit banged GPIO JTAG mode.\n"
"                           Default is 0.\n"
);
    printf(
"-logging-file <filepath>  Sets filepath to redirect log messages to the specified file.\n"
"                           Default is NULL. Set to NULL or '0' to disable.\n"
);

    printf("\n");
}

static void debug_print_env_var(Aapl_t *aapl, const char *var)
{
    if( aapl->debug >= AVAGO_DEBUG1 )
    {
        const char *val = getenv(var);
        if( val )
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "%s environment variable is present. Current value: %s.\n", var, val);
    }
}

int aapl_common_main_options(Aapl_t * aapl, int argc, char *argv[], Avago_addr_t * addr)
{
    int rc, index = 0;
    int return_code = 0;
    int jtag_chip = 0;

    char **argv_cp = (char **)aapl_malloc(aapl, argc * sizeof(char *), __func__);
    int argc_cp = argc;
    int x, env_var = 0;
    char *var;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {0,        0, 0, 0}
    };

    optind = 0; /* reset global getopt index so that previous getopt are allowed */

    if( (var = getenv("SERDES_COMM"))              ) aapl->communication_method = aapl_comm_method_from_str(var, "SERDES_COMM environment variable");
    if( (var = getenv("SERDES_DUT_PORT"))          ) aapl->tcp_port             = aapl_strtol (var,NULL,0);
    if( (var = getenv("SERDES_MAX_CMDS_BUFFERED")) ) aapl->max_cmds_buffered    = aapl_strtol (var,NULL,0);
    if( (var = getenv("SERDES_I2C_BASE_ADDR"))     ) aapl->i2c_base_addr        = aapl_strtol (var,NULL,16);
    if( (var = getenv("SERDES_CHIPS"))             ) aapl->chips                = aapl_strtoul(var,NULL,0);
    if( (var = getenv("SERDES_TCK_DELAY"))         ) aapl->tck_delay            = aapl_strtoul(var,NULL,0);
    if( (var = getenv("SERDES_SBUS_RINGS"))        ) aapl->sbus_rings           = aapl_strtoul(var,NULL,0);
    if( (var = getenv("SERDES_SBUS_TDR_OPCODE_BASE"))) aapl->sbus_tdr_opcode_base = aapl_strtoul(var,NULL,0);
    if( addr && (var = getenv("SERDES_ADDR")) && !aapl_addr_list_from_str(aapl, addr, var) )
        aapl_main_error("Invalid address range or value specified. Must be a comma deliminated list of one or more addresses. ie: 1-5, 13-0xf,:2:2f-:2:5a,9\n");

    if( (var = getenv("SERDES_DUT_IP")) ) /* use this environment variable for the hostname, if present. The "-s" option will override this below. */
    {
        const char *ptr;
        aapl->aacs_server = (char *)aapl_realloc(aapl,aapl->aacs_server, strlen(var)+1,__func__);

        ptr = strrchr(var, ',');  /* are there multiple hosts? */
        if( ptr && ptr[1] ) strncpy(aapl->aacs_server, &ptr[1], strlen(var)+1); /* only use last IP address */
        else                strncpy(aapl->aacs_server, var, strlen(var)+1);
        env_var ++;
    }

    for (x = 0; x < argc; x++) argv_cp[x] = argv[x]; /* we must make a copy of argv as getopt below will modify it */

    opterr = 0; /* don't flag invalid options as errors, as programs below will do that */

    while( (rc = getopt_long_only(argc_cp, argv_cp, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch( rc )
        {
        case 0xf000 | 'M':
        {
            aapl->sbus_fn = 0; /* if the user is specifying a command line option, ignore anything set from user_code.c and make AAPL use built-in registration */
            aapl->sbus_fn_2 = 0;
            aapl->communication_method = aapl_comm_method_from_str(optarg,name);
            break;
        }
        case 0xf000 | 'S':
        {
            aapl->aacs_server = (char *)aapl_realloc(aapl,aapl->aacs_server, strlen(optarg)+1,__func__);
            strncpy(aapl->aacs_server, optarg, strlen(optarg)+1);
        }
        break;
        case 0xf000 | 'd': aapl->debug                = aapl_num_from_str(optarg,name,0); break;
        case 0xf000 | 'V': aapl->verbose              = aapl_num_from_str(optarg,name,0); break;
        case 0xf000 | 'F': aapl->diag_on_failure      = aapl_num_from_str(optarg,name,0); break;
        case 0xf000 | 'p': aapl->tcp_port             = aapl_num_from_str(optarg,name,0); break;
        case 0xf000 | 'x': aapl->max_cmds_buffered    = aapl_num_from_str(optarg,name,0); break;
        case 0xf000 | 'c': aapl->chips                = aapl_num_from_str(optarg,name,0); break;
        case 0xf000 | 'r': aapl->sbus_rings           = aapl_num_from_str(optarg,name,0); break;
        case 0xf000 | 'j': aapl->jtag_idcode[jtag_chip++] = aapl_num_from_str(optarg,name,0); break;
        case 0xf100      : aapl->mdio_base_port_addr  = aapl_num_from_str(optarg,name,0); break;
        case 0xf101      : aapl->i2c_base_addr        = aapl_num_from_str(optarg,name,0); break;
        case 0xf107      : aapl->sbus_tdr_opcode_base = aapl_num_from_str(optarg,name,0); break;
        case 0xf102      : aapl->capabilities         = aapl_num_from_str(optarg,name,0); break;
        case 0xf000 | 't': aapl->log_time_stamps      =  0;                               break;
        case 0xf103      : aapl->serdes_int_fn = &avago_serdes_spico_int_le_fn; break;   /* use link emulator */
        case 0xf106      : aapl->logging_file_path    = optarg; break;   /* Redirect all info and debug logs to the user specified file */
        case 0xf104      : aapl->serdes_int_timeout = aapl_num_from_str(optarg, name, 0); break;
        case 0xf105      : aapl->tck_delay          = aapl_num_from_str(optarg, name, 0); break;

        case 0xf000 | 'a': if( addr )
                                {if (!aapl_addr_list_from_str(aapl, addr, optarg)) aapl_main_error("Invalid address range or value specified. Must be a comma deliminated list of one or more addresses. ie: 1-5, 13-0xf,:2:2f-:2:5a,9\n");}
                           else       return_code = -1;
                           break;

        case 0xf000 | 'h': return_code = -1; break;
        }
    }
    opterr = 1; /* make lower level programs flag errors for invalid options */
    optind = 1; /* reset getopt index so that the following "main" programs can re-process the options */

    if (argv_cp) aapl_free(aapl, argv_cp, __func__);

    if ((argc + env_var) <= 1 && aapl_is_aacs_communication_method(aapl) )
    {
        printf("At least 1 argument is required.\n");
        return_code = -1;
    }

    if (strstr(aapl->aacs_server, ":")) /* if a colon is present seperate out the port number */
    {
        aapl->tcp_port = aapl_strtol(strstr(aapl->aacs_server, ":")+1,0,0);
        aapl_str_rep(aapl->aacs_server, ':', 0);
    }

    debug_print_env_var(aapl, "SERDES_COMM");
    debug_print_env_var(aapl, "SERDES_DUT_IP");
    debug_print_env_var(aapl, "SERDES_DUT_PORT");
    debug_print_env_var(aapl, "SERDES_ADDR");
    debug_print_env_var(aapl, "SERDES_CHIPS");
    debug_print_env_var(aapl, "SERDES_TCK_DELAY");
    debug_print_env_var(aapl, "SERDES_I2C_BASE_ADDR");
    debug_print_env_var(aapl, "SERDES_SBUS_RINGS");
    debug_print_env_var(aapl, "SERDES_MAX_CMDS_BUFFERED");
    debug_print_env_var(aapl, "SERDES_SBUS_TDR_OPCODE_BASE");

/*  if (return_code < 0) aapl_common_main_help(aapl, addr); */
    aapl_register_user_supplied_functions(aapl);

    return return_code;
}

/*============================================================================= */
/* SUPPORT FOR STANDALONE MAIN PROGRAMS: */
/* */
/* These are only needed with #ifdef MAIN, but must always be compiled into the */
/* library. */

const char *aapl_myname;  /* set by main() programs. */

/*============================================================================= */
/* M A I N   E R R O R */
/* */
/** @details Print an error message to stderr for main(), with a prefix */
/**          inserted and a newline appended.  Uses global aapl_myname. */
/** @param fmt printf()-style args. */
/** @return void None, exits non-zero. */

void aapl_main_print_error(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);

     fprintf(stderr, "%s: ", aapl_myname);
    vfprintf(stderr, fmt, ap);
     fputc('\n', stderr);

    va_end(ap);
}

void aapl_main_unexpected_arg(const char *arg)
{
    aapl_main_print_error("Unexpected argument(s) on command line, starting with \"%s\".", arg);
    aapl_main_print_error("Run with -help for a usage summary.");
}

void aapl_main_error(const char * fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);

     fprintf(stderr, "%s: ERROR: ", aapl_myname);
    vfprintf(stderr, fmt, ap);
     fputc('\n', stderr);

    va_end(ap);
    AAPL_EXIT(1);
}

/** @brief   Exits from the main() program with error message. */
/** @return  void. */
/** @see     aapl_main_error(). */
void aapl_exit_on_unexpected_arg(
    const char *program)  /**< [in] Argument string. */
{
    aapl_main_error("Unexpected argument(s) on command line, starting with \"%s\".\n"
               "Run with -help for a usage summary.", program);
}

static Avago_addr_t *ll_add_range(Aapl_t *aapl, Avago_addr_t *addr, uint start, uint stop)
{
    uint chip, ring, sbus, lane, pll;
    Avago_addr_t *end_struct = addr;
    Avago_addr_t begin, end;
    avago_addr_to_struct(start, &begin);
    avago_addr_to_struct(stop, &end);
  /*printf("adding 0x%x-0x%x\n", start, stop); */

    for( chip = begin.chip; chip <= end.chip; chip++ )
    for( ring = begin.ring; ring <= end.ring; ring++ )
    for( sbus = begin.sbus; sbus <= end.sbus; sbus++ )
    for( lane = begin.lane; lane <= end.lane; lane++ )
    for( pll  = begin.pll;  pll  <= end.pll;  pll++  )
    {
        addr->sbus = sbus;
        addr->chip = chip;
        addr->ring = ring;
        addr->lane = lane;
        addr->pll  = pll;
        if( pll < end.pll || lane < end.lane || sbus < end.sbus || ring < end.ring || chip < end.chip )
        {
            addr->next = avago_addr_new(aapl);
            addr = addr->next;
            end_struct = addr;
        }
     /* printf("ADDING address %s\n", aapl_addr_to_str(avago_struct_to_addr(addr))); */
    }
    return end_struct;
}

/** @brief   Converts a string to a linked list of addresses. */
/** @details The user should eventually free the linked list with avago_addr_delete() */
/** @return  Returns TRUE and a linked list in *addr on valid optarg. */
/** @return  Returns FALSE on invalid optarg. */
/** @see     avago_addr_delete(). */
BOOL aapl_addr_list_from_str(
    Aapl_t *aapl,            /**< [in] The string to parse. */
    Avago_addr_t *addr,      /**< [in] Starting addess of the linked list. */
    const char *optarg)      /**< [in] The option name being parsed. */
{
    char *ptr = 0;
    int first = 0;
    Avago_addr_t *end = addr; /* end points to the starting addr */
    avago_addr_init(addr);

    while (1)
    {
        uint start, stop;
        Avago_addr_t *prev;

        if (!aapl_str_to_addr(optarg, &ptr, &start)) return FALSE; /* parse first item */
        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Parsed: '%s' ---> %x ## Remaining: '%s'\n", optarg, start, ptr);

        stop = start; /* we have a single item so, start and stop are the same */

        prev = end; /* set previous to the end (the new one added next will be the new end) */
        if (first++ != 0) /* if not the first time, add a new element to the list */
        {
            end->next = avago_addr_new(aapl);
            end = end->next;
        }

        if( *ptr == '-' ) /* if we find a "-" find the next item which will be the "stop" value for the range */
        {
            if (!aapl_str_to_addr(ptr+1, &ptr, &stop)) return FALSE; /* find the stop value */
            end = ll_add_range(aapl, end, start, stop); /* add the range */
        }
        else if (*ptr == ',' || *ptr == 0) /* not a new range, but a single digit, or end of line */
        {
            end = ll_add_range(aapl, end, start, stop);
        }
        else /* Unknown data. Delete new entry and attempt to move on */
        {
            end = prev;
            avago_addr_delete(aapl, end);
            end->next = 0;
            if (strchr(ptr,'-')) ptr = strchr(ptr,'-');
            if (strchr(ptr,'-')) ptr = strchr(ptr,'-');
        }
        if (optarg == ptr || *ptr == 0) break; /* stop if we're at the end of the line, or nothing was found searching above */
        ptr++; /* increment past the "," */
        optarg = ptr; /* reset starting string to next item */
    }
    return TRUE;
}

#endif /* AAPL_ENABLE_MAIN */
