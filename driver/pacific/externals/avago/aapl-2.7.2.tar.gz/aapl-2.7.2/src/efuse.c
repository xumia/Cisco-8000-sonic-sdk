/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/** Doxygen File Header */
/** @file efuse.c */
/** @brief API and CLI for eFuse reading. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS

#include "aapl.h"

#if AAPL_ENABLE_EFUSE && (AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS)

/** @defgroup eFuse Functions for accessing and displaying chip manufacturing information. */
/** @{ */

#if AAPL_ENABLE_FILE_IO
/* Returns the index in TESTREG for the given bit. */
/* Returns first index if selecting a range. */
static int find_testreg_bit(const char *mapfile, const char *pattern)
{
    const char *ptr = strstr(mapfile, pattern);
    if( ptr ) ptr = strstr(ptr, "TESTREGS[");
    if( ptr ) return strtol(ptr+9,0,0);
    return 0;
}
#endif /* AAPL_ENABLE_FILE_IO */

static void read_efuse_via_sbus(Aapl_t *aapl, uint chip, char** efuse_chain)
{
    int val;
    char str[256];
    str[0] = 0;
    avago_sbus_rmw(aapl, (chip << 12) | 0xfe, 0x80, 0x06000000, 0x06000000); /* turn on SBus control of efuse */
    
    for (val = 0xf; val >= 0 ; val--)
    {
        uint val2;
        avago_sbus_rmw(aapl, (chip << 12) | 0xfe, 0x80, val << 27, 0xf8000000);
        val2 = avago_sbus_rd(aapl, (chip << 12) | 0xfe, 0x81);
        
        aapl_hex_2_bin(aapl->data_char, val2 >> 24, 0, 8);
        strcat(str, aapl->data_char);
        /* printf("%02x ", val2 >> 24); */
    }
    avago_sbus_rmw(aapl, (chip << 12) | 0xfe, 0x80, 0x00000000, 0x06000000); /* turn off SBus control of efuse */
    *efuse_chain = aapl_strdup(str);
}

/** @brief   Parses a mapfile to determine how to read the eFuse chain, then reads and returns the chain. */
/** @details If the mapfilename is NULL, use the eFuse chain length to determine how to read the eFuse chain. */
/** @details Returns the eFuse chain as a sequence of ASCII '0' and '1' characters. */
/** @details The returned pointer should be freed using aapl_free(). */
/** @return  The eFuse chain, or NULL on error. */
/** @see     avago_format_efuse_chain(). */
char *avago_read_efuse_chain(
    Aapl_t *aapl,               /**< [in] AAPL structure pointer. */
    uint chip,                  /**< [in] Chip number to access. */
    const char *mapfilename)    /**< [in] Path to tap mapfile. */
{
    int return_code = aapl->return_code;
    int ones[5], zeros[3] = {0,0,0};
    int chain_len = 0, i;
    char *efuse_chain = 0, *chain = 0, *orig_chain = 0, *test_chain = 0;

    if((aapl->jtag_idcode[chip] & 0x0fffffff) == 0x0954657f || /* 4412 rev x */
       (aapl->jtag_idcode[chip] & 0x0fffffff) == 0x096d157f || /* 4412 rev x */
       (aapl->jtag_idcode[chip] & 0x0fffffff) == 0x0968257f)   /* 4412 rev x */
    {
        read_efuse_via_sbus(aapl, chip, &efuse_chain);
        return efuse_chain;
    }

    /* Select which chip to address: */
    aapl_set_chip(aapl, chip);
    chain = avago_jtag_rd_len(aapl, 0x2b4, &chain_len); /* TESTREGS */

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "efuse chain_len = %d\n", chain_len);

    if( mapfilename )
    {
#if AAPL_ENABLE_FILE_IO
        char *mapfile = aapl_read_file(aapl, mapfilename);
        if( mapfile )
        {
            int length  = find_testreg_bit(mapfile,"TESTREG") + 1;
            ones[0] = find_testreg_bit(mapfile, "REG_TEST__FUSE_CTRL_RESET_L");
            ones[1] = find_testreg_bit(mapfile, "TR_FUSE_CTRL_SEL_AS_0");
            ones[2] = find_testreg_bit(mapfile, "REG_TEST__FUSE_CTRL_TAP_CTRL");
            ones[3] = find_testreg_bit(mapfile, "REG_TEST__FUSE_CTRL_DISABLE_RESET");
            ones[4] = find_testreg_bit(mapfile, "TR_DFT_CLK_IS_TCK");
            zeros[0] = find_testreg_bit(mapfile, "REG_TEST__FUSE_CTRL_SPEED_0");
            zeros[1] = find_testreg_bit(mapfile, "REG_TEST__FUSE_CTRL_SPEED_1");
            zeros[2] = find_testreg_bit(mapfile, "REG_TEST__FUSE_CTRL_SPEED_2");
            aapl_free(aapl, mapfile, mapfilename);

            if( aapl->debug >= AVAGO_DEBUG1 )
            {
                int i;
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "TESTREG: length %d, ones at %d", chain_len, ones[0]);
                for( i = 1; i < AAPL_ARRAY_LENGTH(ones); i++ )
                    aapl_log_printf(aapl, AVAGO_DEBUG1, 0, 0, ", %d", ones[i]);
                aapl_log_printf(aapl, AVAGO_DEBUG1, 0, 0, "; zeros at %d", zeros[0]);
                for( i = 1; i < AAPL_ARRAY_LENGTH(zeros); i++ )
                    aapl_log_printf(aapl, AVAGO_DEBUG1, 0, 0, ", %d", zeros[i]);
                aapl_log_printf(aapl, AVAGO_DEBUG1, 0, 0, "\n");
            }
            if( length != chain_len )
                aapl_fail(aapl, __func__, __LINE__, "Mapfile %s does not appear to match the hardware: HW chain length = %d, mapfile length = %d.\n", mapfilename, chain_len, length);
        }
#else
        aapl_fail(aapl, __func__, __LINE__, "Cannot read mapfile %s: File IO disabled in this compile.\n", mapfilename);
#endif /* AAPL_ENABLE_FILE_IO */
    }
    else    /* No mapfile given, see if we can figure things out */
    {
        /* Fill in the ones and zeros arrays based on chain length. */
        if( chain_len == 883 )   /* most 16nm chips */
        {
             /* NOTE: RESET_L must be first entry in ones array. */
             ones[0] = 312;  ones[1] = 306;  ones[2] = 311;  ones[3] = 313;  ones[4] = 868;
            zeros[0] = 347; zeros[1] = 348; zeros[2] = 349;
        }
        else if( chain_len == 882 ) /* 16nm ? */
        {
             ones[0] = 313;  ones[1] = 307;  ones[2] = 312;  ones[3] = 314;  ones[4] = 867;
            zeros[0] = 348; zeros[1] = 349; zeros[2] = 350;
        }
        else if( chain_len == 877 ) /* 28nm 4412, 7412, 9104 */
        {
             ones[0] = 324;  ones[1] = 318;  ones[2] = 323;  ones[3] = 325;  ones[4] = 868;
            zeros[0] = 350; zeros[1] = 351; zeros[2] = 352;
        }
        else
        {
            aapl_fail(aapl, __func__, __LINE__, "Unknown TESTREG chain length (%d), mapfile name required.\n", chain_len);
        }
    }
    if( return_code != aapl->return_code )
        return efuse_chain;

    /* Make copies for later. */
    orig_chain = aapl_strdup(chain);
    test_chain = aapl_strdup(chain);

    /* Set bits necessary to read chip manufacturing info: */
    for( i = 1; i < AAPL_ARRAY_LENGTH(ones); i++ )  /* Set all but RESET_L */
        test_chain[chain_len - 1 - ones[i]] = '1';
    for( i = 0; i < AAPL_ARRAY_LENGTH(zeros); i++ )
        test_chain[chain_len - 1 - zeros[i]] = '0';
    avago_jtag(aapl, 0x2b4, chain_len, test_chain);    /*Is this write necessary? */

    test_chain[chain_len - 1 - ones[0]] = '1';      /* Set RESET_L value */
    avago_jtag(aapl, 0x2b4, chain_len, test_chain);

    /* Verify write was correct: */
    if( aapl->debug > 0 )
    {
        chain = avago_jtag_rd(aapl, 0x2b4, chain_len); /* TESTREGS */
        if( strcmp(chain, test_chain) != 0 )
            aapl_fail(aapl, __func__, __LINE__, "test_chain write failed\n");
    }
    aapl_free(aapl, test_chain, __func__);

    /* Select for eFuse reading and cycle enough that data becomes available. */
    avago_jtag_rd(aapl, 0x2d2, 3000);  /* FUSE_CTRL_READ */

    /* Read eFuse info: */
    {
        char buf[130];
        memset(buf,'0',sizeof(buf));
        chain = avago_jtag(aapl, 0x0200, 128, buf);  /* SEL_FUSE_CTRL_0 */
        efuse_chain = aapl_strdup(chain);
    }

    /* Restore TESTREG chain to original state: */
    avago_jtag(aapl, 0x2b4, chain_len, orig_chain);
    aapl_free(aapl, orig_chain, __func__);

    return efuse_chain;
}

static int get_sign(const char *sign)
{
    return (sign[0] == '1') ? -1 : 1;
}

/* Read binary value from ASCII string starting at bits pointer for len positions. */
/* Negative len means read right to left for abs(len) positions with MSB on right. */
/* Negative len is only mode implemented. */
static int get_int(const char *bits, int len)
{
    int i, value = 0;
    for( i = 0; i > len; i-- )
        value = value * 2 + (bits[i] == '1' ? 1 : 0);
    return value;
}

/** @brief   Returns formatted interpretation of 16nm efuse_chain. */
/** @details The returned pointer should be freed using aapl_free(). */
/** @return  Allocated space contain formated efuse_chain string and interpretation. */
static char *avago_format_efuse_chain_16(Aapl_t *aapl, const char *efuse_chain)
{
    size_t buf_len = 300;
    char *buf = (char *)aapl_malloc(aapl, buf_len, __func__);
    char *end = buf + buf_len;
    char *ptr = buf;
    const char *last = efuse_chain + strlen(efuse_chain) - 1; /* last points to last character in efuse_chain: */

    char lot_num[7];
    int x, y, wfr, pmro_val;
    const char *skew_name, *pmro_name, *v_off_val;

    lot_num[0] = get_int(last- 0, -7);  /* Extract int from 7 chars in reverse direction starting at last. */
    lot_num[1] = get_int(last- 7, -7);  /* Extract int from 7 chars in reverse direction starting at last-7. */
    lot_num[2] = get_int(last-14, -7);
    lot_num[3] = get_int(last-21, -7);
    lot_num[4] = get_int(last-28, -7);
    lot_num[5] = get_int(last-35, -7);
    lot_num[6] = '\0';

    wfr = get_int(last-42, -5);

    x = get_sign(last-47) * get_int(last-48, -7);
    y = get_sign(last-55) * get_int(last-56, -7);

    switch( get_int(last-63, -2) )
    {
    case 0:  pmro_name = "svt"; break;
    case 1:  pmro_name = "lvt"; break;
    case 2:  pmro_name = "hvt"; break;
    case 3:  pmro_name = "all"; break;
    default: pmro_name = "unk"; break;
    }

    pmro_val = get_int(last-65, -12);

    switch( get_int(last-77, -3) )
    {
    default:
    case 0: skew_name = "unk"; break;
    case 1: skew_name = "SS"; break;
    case 2: skew_name = "slow"; break;
    case 3: skew_name = "nom"; break;
    case 4: skew_name = "fast"; break;
    case 5: skew_name = "FF"; break;
    case 6: skew_name = "rsvd"; break;
    case 7: skew_name = "rsvd"; break;
    }

    /* Note: Bits last-80 to last-87 skipped */

    switch( get_int(last-88, -4) )
    {
    case  5: v_off_val = "875"; break;
    case  6: v_off_val = "850"; break;
    case  7: v_off_val = "825"; break;
    case  8: v_off_val = "800"; break;
    case  9: v_off_val = "775"; break;
    case 10: v_off_val = "750"; break;
    default: v_off_val = "unk"; break;
    }

    /* Format to exactly match 16nm perl decoder script output: */
    ptr += snprintf(ptr, end-ptr, "Input DieID bits: %s\n", efuse_chain);
    ptr += snprintf(ptr, end-ptr, "Decoded Values are skew: %s lot_number: %s wafer: %d x: %d y: %d pmro_config: %s pmro_value: %d V_offset: %s\n", skew_name, lot_num, wfr, x, y, pmro_name, pmro_val, v_off_val);

/*  Alternate formats: */
/*  ptr += snprintf(ptr, end-ptr, "eFuse values: skew %s, lot_number %s; wafer %d; x,y: %d,%d; pmro_config %s; pmro_value %d; V_offset %s\n",skew_name, lot_num, wfr, x, y, pmro_name, pmro_val, v_off_val); */
/*  ptr += snprintf(ptr, end-ptr, "Decoded Values are skew %s; lot_number %s; wafer %d; x %d; y %d; pmro_config %s; pmro_value %d; V_offset %s\n",skew_name, lot_num, wfr, x, y, pmro_name, pmro_val, v_off_val); */
    return buf;
}

/** @brief   Returns formatted interpretation of 28nm efuse_chain. */
/** @details The returned pointer should be freed using aapl_free(). */
/** @return  Allocated space contain formated efuse_chain string and interpretation. */
static char *avago_format_efuse_chain_28(Aapl_t *aapl, const char *efuse_chain)
{
    size_t buf_len = 320;
    char *buf = (char *)aapl_malloc(aapl, buf_len, __func__);
    char *end = buf + buf_len;
    char *ptr = buf;
    const char *last = efuse_chain + strlen(efuse_chain) - 1; /* last points to last character in efuse_chain: */

    char lot_num[7];
    int x, y, wfr, pmro_val;
    const char *skew_name, *pmro_name, *v_off_val, *chip_pid;

    switch( get_int(last- 0, -3) )  /* SKEW */
    {
    case 0: skew_name = "nom"; break;
    default:
    case 1: skew_name = "unk"; break;
    case 2: skew_name = "SS"; break;
    case 3: skew_name = "FF"; break;
    case 4: skew_name = "slow"; break;
    case 5: skew_name = "rtran"; break;
    case 6: skew_name = "ltran"; break;
    case 7: skew_name = "fast"; break;
    }


    switch( get_int(last- 5, -4) )  /* Identify fab location */
    {
    case  6: lot_num[0] = 'G'; break;
    case  8: lot_num[0] = 'Q'; break;
    case 12: lot_num[0] = 'N'; break;
    case 14: lot_num[0] = 'P'; break;
    case 15: lot_num[0] = 'T'; break;
    default: lot_num[0] = 'U'; break;
    }

    switch( get_int(last- 9, -1) )  /* Identify lot type - engineering or production */
    {
    case  1: lot_num[1] = 'p'; break;
    default: lot_num[1] = 'e'; break;
    }

    /* Identify lot number: */
    lot_num[2] = get_int(last-10, -7);
    lot_num[3] = get_int(last-17, -7);
    lot_num[4] = get_int(last-24, -7);
    lot_num[5] = get_int(last-31, -7);
    lot_num[6] = '\0';

    /* Wafer, chip coordinate: */
    wfr = get_int(last-38, -5);
    x = get_sign(last-43) * get_int(last-44, -7);
    y = get_sign(last-51) * get_int(last-52, -7);

    /* PMRO data: */
    switch( get_int(last-80, -2) )
    {
    case 0:  pmro_name = "svt"; break;
    case 1:  pmro_name = "lvt"; break;
    case 2:  pmro_name = "hvt"; break;
    case 3:  pmro_name = "all"; break;
    default: pmro_name = "unk"; break;
    }

    pmro_val = get_int(last-82, -12);

    switch( get_int(last-102, -4) ) /* Voltage Offset */
    {
    case  0: v_off_val = "  0"; break;
    case  1: v_off_val = "-25"; break;
    case  2: v_off_val = "-50"; break;
    case  3: v_off_val = "-75"; break;
    case  4: v_off_val = "-100"; break;
    default: v_off_val = "unk"; break;
    }

    switch( get_int(last-106, -4) ) /* Chip process ID */
    {
    case  0: chip_pid = "slow/nom"; break;
    case  1: chip_pid = "slow/nom"; break;
    case  2: chip_pid = "slow/nom"; break;
    case  3: chip_pid = "slow/nom"; break;
    case  4: chip_pid = "slow/nom"; break;
    case  5: chip_pid = "slow/nom"; break;
    case  6: chip_pid = "slow/nom"; break;
    case  7: chip_pid = "nom/nom"; break;
    case  8: chip_pid = "nom/nom"; break;
    case  9: chip_pid = "nom/nom"; break;
    case 10: chip_pid = "nom-fst/nom-25mV"; break;
    case 11: chip_pid = "nom-fst/nom-25mV"; break;
    case 12: chip_pid = "nom-fst/nom-25mV"; break;
    case 13: chip_pid = "fast/nom-50mV"; break;
    case 14: chip_pid = "fast/nom-50mV"; break;
    case 15: chip_pid = "fast/nom-50mV"; break;
    default: chip_pid = "unk"; break;
    }

    /* Format to exactly match 28nm perl decoder script output: */
    ptr += snprintf(ptr, end-ptr, "Input DieID bits: %s\n", efuse_chain);
    ptr += snprintf(ptr, end-ptr, "Decoded Values are skew: %s lot_number: %s wafer: %d x: %d y: %d pmro_config: %s pmro_value: %d V_offset: %s chip_pid %s\n",skew_name, lot_num, wfr, x, y, pmro_name, pmro_val, v_off_val, chip_pid);

/*  Alternate formats: */
/*  ptr += snprintf(ptr, end-ptr, "eFuse values: skew %s, lot_number %s; wafer %d; x,y: %d,%d; pmro_config %s; pmro_value %d; V_offset %s; chip_pid %s\n",skew_name, lot_num, wfr, x, y, pmro_name, pmro_val, v_off_val, chip_pid); */
/*  ptr += snprintf(ptr, end-ptr, "Decoded Values are skew %s; lot_number %s; wafer %d; x %d; y %d; pmro_config %s; pmro_value %d; V_offset %s; chip_pid %s\n",skew_name, lot_num, wfr, x, y, pmro_name, pmro_val, v_off_val, chip_pid); */
    return buf;
}

/** @brief   Returns formatted interpretation of efuse_chain. */
/** @details The returned pointer should be freed using aapl_free(). */
/** @return  On success, returns allocated space contain formatted efuse_chain string and interpretation. */
/** @return  On failure, decrements aapl->return_code and returns NULL. */
/** @see     avago_read_efuse_chain(). */
char *avago_format_efuse_chain(
    Aapl_t *aapl,               /**< [in] AAPL structure pointer. */
    uint chip,                  /**< [in] Chip number to access. */
    const char *efuse_chain)    /**< [in] eFuse chain returned by avago_read_efuse_chain(). */
{
    uint addr = avago_make_addr3(chip,0,0);
    Avago_process_id_t process_id = aapl_get_process_id(aapl, addr);

    switch( process_id )
    {
    case AVAGO_TSMC_16: return avago_format_efuse_chain_16(aapl, efuse_chain);
    case AVAGO_TSMC_28: return avago_format_efuse_chain_28(aapl, efuse_chain);
    default: aapl_fail(aapl, __func__, __LINE__, "Process id %s not supported for eFuse reading.\n", aapl_process_id_to_str(process_id));
    }
    return NULL;
}

#if AAPL_ENABLE_MAIN

static int show_efuse_help()
{
    aapl_common_main_help(TRUE);
    printf(
"-mapfile <mapfilename>   Name of tap mapfile.\n"
);

    return 1;
}

int aapl_efuse_main(int argc, char *argv[], Aapl_t *aapl)
{
    int rc, index = 0;
    uint flags, chip = 0xff;
    Avago_addr_t addr_struct, start, stop, next;
    BOOL st;
    const char *mapfilename = 0;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"mapfile", 1, 0, 'f'},
        {0,         0, 0, 0}
    };
    Avago_state_table_options_t table_options;
    memset(&table_options, 0, sizeof(table_options));         /* set all bytes to zero */

    avago_addr_init_broadcast(&addr_struct);
    if (aapl_common_main_options(aapl, argc, argv, &addr_struct) < 0)
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_efuse_help();
    }

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        /* const char *name = options[index].name; */
        switch( rc )
        {
        case 'f': mapfilename = optarg; break;
        case '?':
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    aapl_connect(aapl, 0, 0);
    aapl_get_ip_info(aapl, 0);

    flags = AAPL_BROADCAST_IGNORE_LANE|AAPL_BROADCAST_NO_ITER_SBUS;
    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, flags);
         st;
         st = aapl_broadcast_next(aapl, &next, &start, &stop, flags) )
    {
        if( next.chip != chip )
        {
            char *efuse_chain = avago_read_efuse_chain(aapl, chip = next.chip, mapfilename);
            if( efuse_chain )
            {
                char *efuse_display = avago_format_efuse_chain(aapl, chip, efuse_chain);
                if( efuse_display )
                {
                    printf("Chip %u:\n%s", chip, efuse_display);
                    aapl_free(aapl, efuse_chain, "efuse_chain");
                }
                aapl_free(aapl, efuse_display, "efuse_display");
            }
        }
    }
    avago_addr_delete(aapl, &addr_struct);
    return 0;
}

#endif /* AAPL_ENABLE_MAIN */

/** @} */

#endif /* AAPL_ENABLE_EFUSE && (AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS) */

