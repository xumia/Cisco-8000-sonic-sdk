/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/** Doxygen File Header */
/** @file */
/** @brief Identifier strings for various types of IP. */

#include "aapl.h"

static const Avago_ip_info_t avago_ip_info[] =
{
   {AVAGO_UNKNOWN_IP, AVAGO_UNKNOWN_PROCESS,  0, 12250, "", ""},

   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x00, 12250, "sd16C_txhs_rxd6_ns_01"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x01, 12250, "sd16C_txke_rxd6e_ns_01"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x02, 12250, "sd16C_hz_txhs_rxd6_01"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x03, 12250, "sd16C_hz_smdiode_txhs_rxd6_01"            , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x04, 12250, "sd16C_lz_txhs_rxd6_01"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x05, 12250, "sd16C_lz_txke_rxd6e_01"                   , ""},
   {AVAGO_P1        , AVAGO_TSMC_16, 0x06, 12250, "sd16Q_p1_ew_01"                           , ""},
/* {AVAGO_M4        , AVAGO_TSMC_16, 0x07, 12250, "sd16C_txom4_rxom4_ns_01"                  , ""}, */
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x09, 12250, "sd16C_pcie_ns_011"                        , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x0a, 12250, "sd16C_txhs_rxd6_ns_02"                    , ""},
   {AVAGO_M4        , AVAGO_TSMC_16, 0x0a, 12250, "sd16C_txcpam4_rxcm4_ns_01"                , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x0b, 12250, "sd16C_txke_rxd6e_ns_02"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x0c, 12250, "sd16C_pcie_ns_02"                         , ""},
/* {AVAGO_SERDES    , AVAGO_TSMC_16, 0x0d, 12250, "sd16C_txhs_rxd6_30P0_ns_01"               , ""}, */
/* {AVAGO_SERDES    , AVAGO_TSMC_16, 0x0e, 12250, "sd16C_txke_rxd6e_36P0_ns_01"              , ""}, */
/* {AVAGO_SERDES    , AVAGO_TSMC_16, 0x0f, 12250, "sd16C_txke_rxd6e_36P0_DP_ns_01"           , ""}, */
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x10, 12250, "sd16C_txhs_rxd6_mim_ns_03"                , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x11, 12250, "sd16C_pcie_shrt_ns_03"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x12, 12250, "sd16C_txhs_rxd6_ns_03"                    , ""},
/* {AVAGO_SERDES    , AVAGO_TSMC_16, 0x13, 12250, "sd16C_txke_rxd6e_ns_03"                   , ""}, */
/* {AVAGO_SERDES    , AVAGO_TSMC_16, 0x14, 12250, "sd16C_pcie_ns_03"                         , ""}, */
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x15, 13500, "sd16C_txhs_rxd6_mim_13p5_ns_03"           , ""},
   {AVAGO_P1        , AVAGO_TSMC_16, 0x16, 12250, "sd16Q_p2_ew_ex1_01"                       , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x17, 12250, "sd16C_txhs_rxd6_mim_ns_04"                , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x19, 12250, "sd16C_txhs_rxd6_ns_031"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x1a, 12250, "sd16C_txhs_rxd6_ns_021"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x1b, 12250, "sd16C_pcie_sas_sata_hvd6_ns_01"           , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x1c, 12250, "sd16C_txke_rxd6e_ns_04"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x1d, 12250, "sd16C_txhs_rxd6_ns_04"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x1e, 12500, "sd16C_pcie_ns_04"                         , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x1f, 12500, "sd16C_pcie_shrt_ns_04"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x20, 12250, "sd16C_txhs_rxd6_no_ctle_bw_mim_ns_05"     , ""},
   {AVAGO_P1        , AVAGO_TSMC_16, 0x21, 12750, "sd16Q_p1_ew_02"                           , ""},
   {AVAGO_M4        , AVAGO_TSMC_16, 0x22, 12250, "sd16C_txcpam4_rxcm4_ns_02"                , ""},
   {AVAGO_P1        , AVAGO_TSMC_16, 0x22, 12500, "sd16Q_p1_ew_011"                          , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x23, 12250, "sd16_ssc_01"                              , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x24, 12250, "sd16Xoscpll_refclkgen_01"                 , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x25, 12500, "sd16C_pcie_gen4_ns_01"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x27, 12250, "sd16C_txhs_rxd6_ns_032"                   , ""},
   {AVAGO_M4        , AVAGO_TSMC_16, 0x28, 12500, "sd16C_txcpam4_rxcm4_ns_03"                , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x29, 12250, "sd16C_pcie_ns_031"                        , ""},
   {AVAGO_P1        , AVAGO_TSMC_16, 0x2b, 12750, "sd16Q_p1_ew_03"                           , ""},
   {AVAGO_P1        , AVAGO_TSMC_16, 0x2c, 12500, "sd16Q_p1_ew_nomim_02"                     , ""},
   {AVAGO_P1        , AVAGO_TSMC_16, 0x2d, 12500, "sd16Q_p1_ew_021"                          , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x2e, 12500, "sd16C_pcie_gen4_ns_02"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x2f, 12250, "sd16C_txhs_rxd6_mim_ns_05"                , ""},
   {AVAGO_M4        , AVAGO_TSMC_16, 0x30, 12500, "sd16C_txcpam4_rxcm4_no_tde_ns_03"         , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x31, 12500, "sd16C_txhs_rxd6_ind_no_slot_mim_ns_05"    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x32, 12500, "sd16C_txhs_rxd6_ns_022"                   , ""},
   {AVAGO_M4        , AVAGO_TSMC_16, 0x33, 12500, "sd16C_txcpam4_rxcm4_ns_04.highland"       , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x34, 12500, "sd16C_pcie_shrt_ns_06"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x35, 12500, "sd16C_txhs_rxd6_mim_ns_06"                , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x36, 12500, "sd16C_txhs_rxd6_ns_06"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x37, 12500, "sd16C_txke_rxd6e_ns_06"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x38, 12500, "sd16C_pcie_ns_06"                         , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x39, 12500, "sd16C_pon_txke_rxd6e_ns_06"               , ""},
   {AVAGO_M4        , AVAGO_TSMC_16, 0x3a, 12500, "sd16C_txcpam4_rxcm4_116G_ns_04"           , ""},
   {AVAGO_M4        , AVAGO_TSMC_16, 0x3b, 12500, "sd16C_txcpam4_rxcm4_dcrlf_ns_04"          , ""},
   {AVAGO_BLACKHAWK , AVAGO_TSMC_16, 0x3c, 12500, "sd16C_cpam4bh_oct_sinai"                  , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x3d, 12500, "sd16C_txhs_rxd6_mim_ns_061"               , ""},
   {AVAGO_M4        , AVAGO_TSMC_16, 0x3e, 12500, "sd16C_txcpam4_rxcm4_ns_04"                , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x3f, 12250, "sd16C_txhs_rxd6_mim_ns_07"                , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x40, 12500, "sd16C_txhs_rxd6_mim_ns_08"                , ""},
   {AVAGO_M4        , AVAGO_TSMC_16, 0x41, 12500, "sd16C_txcpam4_rxcm4_ns_05"                , ""},
   {AVAGO_M4        , AVAGO_TSMC_16, 0x42, 12500, "sd16C_txcpam4_rxcm4_116G_ns_05"           , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x43, 12500, "sd16C_txhs_rxd6_p_int_mim_ns_08"          , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x44, 12500, "sd16C_pcie_txke_rxd6e_gen4_07"            , ""},
   {AVAGO_M4        , AVAGO_TSMC_16, 0x45, 12500, "sd16C_txcpam4_rxcm4_ns_06"                , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x46, 12500, "sd16C_txhs_rxd6_p_int_fpsh_mim_ns_08"     , ""},
   {AVAGO_M4        , AVAGO_TSMC_16, 0x47, 12500, "sd16C_txcpam4_rxcm4_p_int_fpsh_ns_06"     , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x48, 12500, "sd16C_pon_txke_rxd6e_ns_exp06"            , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x49, 12500, "sd16C_txhs_rxd6_ns_061"                   , ""},
   {AVAGO_M4        , AVAGO_TSMC_16, 0x4a, 12500, "sd16C_txcpam4_rxcm4_ns_07"                , ""},
/* {AVAGO_SERDES    , AVAGO_TSMC_16, 0x4b, 12500, "sd16C_pon_txke_rxd6e_ns_07"               , ""}, */
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x4c, 12500, "sd16C_pcie_shrt_ns_061"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x4d, 12500, "sd16C_txhs_rxd6_mim_ns_09"                , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x4e, 12500, "sd16C_pcie_shrt_ns_07"                    , ""},
   {AVAGO_M4        , AVAGO_TSMC_16, 0x4f, 12500, "sd16C_txcpam4_rxcm4_ns_08"                , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x50, 12500, "sd16C_txke_rxd6e_ns_07"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x51, 12500, "sd16C_txhs_rxd6_ns_062"                   , ""},    /* Duplicate Id! */
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x510,12500, "sd16C_txhs_rxd6_mim_ns_062"               , ""},    /* Duplicate Id! */
/* {AVAGO_SERDES    , AVAGO_TSMC_16, 0x52, 12500, "sd16C_txhs_rxd6_ns_033"                   , ""}, */
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x53, 12500, "sd16C_pcie_ns_07"                         , ""},
/* {AVAGO_SERDES    , AVAGO_TSMC_16, 0x54, 12500, "sd16C_txhs_rxd6_ns_07"                    , ""}, */
/* {AVAGO_SERDES    , AVAGO_TSMC_16, 0x55, 12500, "sd16C_pcie_ns_061"                        , ""}, */
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x56, 12500, "sd16C_pon_txke_rxd6e_ns_08"               , ""},
   {AVAGO_M4        , AVAGO_TSMC_16, 0x57, 12500, "sd16C_txcpam4_rxcm4_ns_09"                , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x58, 12500, "sd16C_pcie_gen4_ns_03"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x59, 12500, "sd16C_pon_txke_rxd6e_ns_09"               , ""},
/* {AVAGO_SERDES    , AVAGO_TSMC_16, 0x5a, 12500, "sd16C_txhs_rxd6_ns_032_lsb034 "           , ""}, */
/* {AVAGO_SERDES    , AVAGO_TSMC_16, 0x5b, 12500, "sd16C_txhs_rxd6_mim_ns_06_lsb034"         , ""}, */
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x5e, 12500, "sd16C_pcie_gen4_mim_ns_03"                , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_16, 0x5f, 12500, "sd16C_pcie_shrt_ns_062"                   , ""},
/* {AVAGO_SERDES    , AVAGO_TSMC_16, 0x60, 12500, "sd16C_ccix_ns_01"                         , ""}, */

   {AVAGO_SERDES    , AVAGO_TSMC_07, 0x01, 12250, "sd07C_txd6_rxd6_ns_01"                    , ""},  /* BC 1.0 */
   {AVAGO_SERDES    , AVAGO_TSMC_07, 0x02, 12250, "sd07C_pcie_ns_01"                         , ""},  /* BC 1.0 */
   {AVAGO_SERDES    , AVAGO_TSMC_07, 0x03, 12250, "sd07C_txd6_rxd6_ns_02"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_07, 0x04, 12250, "sd07C_pcie_ns_02"                         , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_07, 0x06, 12250, "sd07C_pcie_ns_03"                         , ""},  /* BC 2.0 */
   {AVAGO_SERDES    , AVAGO_TSMC_07, 0x07, 12250, "sd07C_txd6_rxd6_ns_03"                    , ""},  /* BC 2.0 */
   {AVAGO_SERDES    , AVAGO_TSMC_07, 0x08, 12250, "sd07C_pcie_ns_04"                         , ""},  /* Mammoth */
   {AVAGO_SERDES    , AVAGO_TSMC_07, 0x09, 12250, "sd07C_txd6_rxd6_ns_04"                    , ""},  /* Whistler */
/* {AVAGO_SERDES    , AVAGO_TSMC_07, 0x0a, 12250, "sd07C_txhs_rxd6_ns_031"                   , ""}, */
   {AVAGO_SERDES    , AVAGO_TSMC_07, 0x0b, 12250, "sd07C_pcie_ns_021"                        , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_07, 0x0c, 12250, "sd07C_txd6_rxd6_ns_021"                   , ""},

   {AVAGO_BLACKHAWK , AVAGO_TSMC_07, 0x00, 12250, "sd07C_cpam4bh_oct_ns_01"                  , ""},  /* Alta */
   {AVAGO_BLACKHAWK , AVAGO_TSMC_07, 0x04, 12250, "sd07C_cpam4bh_duo_ns_01"                  , ""},
/* {AVAGO_BLACKHAWK , AVAGO_TSMC_07, 0x05, 12250, "sd07C_cpam4os_quad_ns_01"                 , ""},  // unused */
   {AVAGO_BLACKHAWK , AVAGO_TSMC_07, 0x08, 12250, "sd07C_cpam4bh_oct_ns_02"                  , ""},  /* Whistler */
   {AVAGO_OSPREY    , AVAGO_TSMC_07, 0x0d, 12250, "sd07C_cpam4os_oct_pll1x_ns_01"            , ""},  /* Whistler, Mammoth */
   {AVAGO_BLACKHAWK , AVAGO_TSMC_07, 0x0e, 12250, "sd07C_cpam4bh_oct_pll2x_mb_ns_02"         , ""},  /* Whistler */

   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xfd,  9000, "sd28C_pcie_sas_sata_hvd6_9G_05"           , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xfc,  6250, "sd28C_pcie_sas_sata_hvd6_6G_05"           , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xfb,  6250, "sd28C_txke_rxd6e_05"                      , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xf6,  6250, "sd28C_txke_rxd6e_16b_03"                  , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xf5,  6250, "sd28C_pcie_sas_sata_hvd6_03"              , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xf4,  6250, "sd28C_pcie_16b_03"                        , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xf0,  6250, "sd28C_pcie_16b_02"                        , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xef,  6250, "sd28C_pcie_sas_sata_hvd6_02"              , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xed,  6250, "sd28C_pcie_sas_sata_hvd6_rsa08_01"        , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xe2,  6250, "sd28C_pcie_od_041"                        , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xe1,  6250, "sd28C_txke_rxd6e_041"                     , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xde,  6250, "sd28C_txke_rxd6e_04"                      , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xda, 12250, "sd28C_txhsg_rxd6g_01"                     , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xd9,  6250, "sd28C_pcie_16b_01"                        , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xd6, 12250, "sd28C_txhs_rxd6_pcs_04"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xd5, 12250, "sd28C_p1_uni_txtc_rxpll_01"               , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xd4, 12250, "sd28C_p1_uni_txqpll_01"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xd3, 12250, "sd28C_p1_uni_01"                          , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xd2, 12250, "sd28C_p1_uni_txtc_01"                     , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xd1, 12250, "sd28C_txhs_rxd6_lowancap_05"              , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xcf, 12250, "sd28C_txhs_rxd6xfp_01"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xcd, 12250, "sd28C_txhs_rxd6_05"                       , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xcc,  6250, "sd28C_pcie_06"                            , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xcb,  6250, "sd28C_str_vortex2p0_mckinley_txvco_01"    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xca,  6250, "sd28C_str_vortex2p0_01"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xc9, 12250, "sd28C_str_txhs_rxd6_rsa05_filcap_01"      , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xc8, 12250, "sd28C_str_txhs_rxd6_rsa06_xvcodma_01"     , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xc7, 12250, "sd28C_str_txhs_rxd6_05"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xc6,  6250, "sd28C_str_txke_rxd6e_01"                  , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xc4, 12250, "sd28C_str_txhs_rxd6_04"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xc3,  6250, "sd28C_txke_rxd6e_03"                      , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xc2, 12250, "sd28C_txhs_rxd6_04"                       , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xc1, 12250, "sd28C_hsvlp_txc_rxd6e_01"                 , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xc0,  6250, "mp28C_txhs_xoscpll_sk01"                  , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xbf,  6250, "mp28C_txhs_xoscpll_01"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xbe,  6250, "sd28C_txke_rxd6e_fastM_01"                , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xbd, 15000, "sd28C_hf_txhs_rxd6_03"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xbc, 12250, "sd28C_txhs_rxd6_pcs_03"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xbb,  6250, "sd28C_pcie_05"                            , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xba,  6250, "sd28C_txke_rxd6e_02"                      , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xb9,  6250, "sd28C_pcie_od_04"                         , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xb8, 12250, "sd28C_txhsln_rxd7_01"                     , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xb7,  6250, "sd28C_vlp_txc_rxd6e_01"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xb6,  6250, "sd28C_pcie_04"                            , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xb5,  6250, "sd28C_txke_rxd6e_01"                      , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xb4, 12250, "sd28C_str_txhs_rxd6_03"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xb3,  6250, "sd28C_txk_rxd6e_gb_2_03"                  , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xb2, 12250, "sd28C_str_txhs_rxd6_02"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xb1,  6250, "sd28C_pcie_03"                            , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xb0, 12250, "sd28C_txhs_rxd6_03"                       , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xaf,  6250, "sd28C_txk_rxd6e_03"                       , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xae,  6250, "sd28C_oct_txk_rxd6e_01"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xad,  6250, "sd28C_txk_lp_rxd6e_01"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xac, 12250, "sd28C_hf_txhs_rxd6_01"                    , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xab, 12250, "sd28C_txhs_rxd6_pcs_01"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xaa, 12250, "sd28C_str_txhs_rxd6_01"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xa9,  6250, "sd28C_txk_ntde_rxd6e_01"                  , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xa8,  6250, "sd28C_pcie_02"                            , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xa7, 12250, "sd28C_txhs_rxd6_02"                       , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xa6,  6250, "sd28C_txk_rxd6e_02"                       , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xa5,  6250, "sd28C_txk_rxf5_02"                        , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xa4, 12250, "sd28C_txhs_rxd6_pcie_pcs_sub_01"          , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xa3,  6250, "sd28C_txk_rxd6e_01"                       , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xa2, 12250, "sd28C_txhs_rxd6_01"                       , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xa1,  6250, "sd28C_pcie_01 (sd28C_pcie_txk_rxd6e_01)"  , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xa0, 12250, "sd28C_txk_rxf5_01"                        , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xe5,  6250, "sd28C_pcie_sas_sata_hvd6_01"              , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xd0,  6250, "sd28C_vlp_txc_rxd6e_02"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xce, 12250, "sd28C_str_txhs_rxd6_06"                   , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xc5, 12250, "sd28C_txpam4_rxm4_01"                     , ""},
   {AVAGO_SERDES    , AVAGO_TSMC_28, 0xdd, 12250, "sd28C_txpam4_rxm4_011"                    , ""},
   {AVAGO_M4        , AVAGO_TSMC_28, 0xe4, 12250, "sd28C_txcpam4_rxcm4_01"                   , ""},
   {AVAGO_M4        , AVAGO_TSMC_28, 0xd8, 12250, "sd28C_txopam4_rxom4_01"                   , ""},
   {AVAGO_M4        , AVAGO_TSMC_28, 0xe0, 12250, "sd28C_txcpam4_rxcm4es_01"                 , ""},
   {AVAGO_M4        , AVAGO_TSMC_28, 0xeb, 12250, "sd28C_txopam4_rxom4_02"                   , ""},
   {AVAGO_M4        , AVAGO_TSMC_28, 0xf2, 12250, "sd28C_lux_txopam4_rxom4_02"               , ""},

   {AVAGO_P1        , AVAGO_TSMC_28, 0xc3, 12250, "sd28Oct_p1_01"                            , ""},
   {AVAGO_P1        , AVAGO_TSMC_28, 0xdf, 12250, "sd28Q_p1_01"                              , ""},
   {AVAGO_P1        , AVAGO_TSMC_28, 0xe8, 12250, "sd28Oct_p1_no_bypass_01"                  , ""},
   {AVAGO_P1        , AVAGO_TSMC_28, 0xe9, 12250, "sd28Oct_p2_01"                            , ""},
   {AVAGO_P1        , AVAGO_TSMC_28, 0xea, 12250, "sd28Oct_p1_02"                            , ""},
   {AVAGO_P1        , AVAGO_TSMC_28, 0xee, 12250, "sd28Oct_p2_p1update_01"                   , ""},
   {AVAGO_P1        , AVAGO_TSMC_28, 0xf1, 12250, "sd28Quad_p1_02"                           , ""},
   {AVAGO_P1        , AVAGO_TSMC_28, 0xf3, 12250, "sd28Oct_p2_nobypass_01"                   , ""},
   {AVAGO_P1        , AVAGO_TSMC_28, 0xf7, 12250, "sd28Oct_p1_03"                            , ""},
   {AVAGO_P1        , AVAGO_TSMC_28, 0xf8, 12250, "sd28Oct_p1_nobypass_037_039"              , ""},
   {AVAGO_P1        , AVAGO_TSMC_28, 0xf9, 12250, "sd28Oct_p1_037_039"                       , ""},

   {AVAGO_UNKNOWN_IP, AVAGO_UNKNOWN_PROCESS,  ~0U, ~0, "", ""}
};

/** @brief Returns the index in the avago_ip_info struct for the specified SBus address. */
/** @return The index in avago_ip_info[] of the sbus device for the current chip and */
/**        sbus ring (specified by the sbus address) */
/**        Returns 0 if nothing was found. */
static uint aapl_get_ip_info_index(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr,&addr_struct);
    if( addr_struct.chip >= AAPL_MAX_CHIPS || addr_struct.chip == AVAGO_BROADCAST ||
        addr_struct.ring >= AAPL_MAX_RINGS || addr_struct.ring == AVAGO_BROADCAST ||
                                              addr_struct.sbus == AVAGO_BROADCAST )
        return 0;

    {
        Avago_ip_type_t    ip_type    = aapl_get_ip_type(aapl, addr);
        Avago_process_id_t process_id = aapl_get_process_id(aapl, addr);
        uint               rev_id     = aapl_get_ip_rev(aapl, addr);
        uint index;
        for( index = 0; index < AAPL_ARRAY_LENGTH(avago_ip_info); index++ )
        {
            if( avago_ip_info[index].rev_id     == rev_id     &&
                avago_ip_info[index].process_id == process_id &&
                avago_ip_info[index].ip_type    == ip_type       )
                return index;   /* Success */
        }
    }
    return 0;   /* Failure */
}

/** @brief Retrieves the Avago_ip_info_t structure for the device at the given */
/**        address. */
/** @return Always returns a pointer to a valid structure. */
/**         If the sbus address is invalid, the returned structure is empty. */
const Avago_ip_info_t *avago_get_ip_info(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    uint index = aapl_get_ip_info_index(aapl, addr);
    return &avago_ip_info[index];
}

