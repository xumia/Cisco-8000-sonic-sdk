/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* AAPL (ASIC and ASSP Programming Layer) support for talking with SPICO */
/* processors in SBus master and SerDes slices. */

/** Doxygen File Header */
/** @file spico.c */
/** @brief Functions for SPICO processors. */

#define AAPL_CORE_FILE
#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#define AAPL_LOG_PRINT7 if( aapl->debug >= AVAGO_DEBUG7 ) aapl_log_printf
#define AAPL_LOG_PRINT8 if( aapl->debug >= AVAGO_DEBUG8 ) aapl_log_printf

/** @brief  Check the PC and possibly interrupt pending bits to see if the Processor */
/**         is running or if it's possibly hung. */
/** */
/** @return 0 - The spico is not running for this serdes slice */
/**         1 - The spico is running for this serdes slice */
uint avago_spico_running(
    Aapl_t *aapl,   /**< [in] Pointer to AAPL structure */
    uint sbus_addr) /**< [in] SBus address of SerDes */
{
    int running = 0;
    if( !aapl_check_process(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28) ||
        aapl_check_broadcast_address(aapl, sbus_addr, __func__, __LINE__, TRUE) )
        return 0;

    if (aapl->spico_int_only) return 1;

    switch( aapl_get_process_id(aapl, sbus_addr) )
    {
    case AVAGO_TSMC_07:
    case AVAGO_TSMC_16:
    case AVAGO_TSMC_28:
        if( !aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, TRUE, 4, AVAGO_SERDES, AVAGO_SPICO, AVAGO_M4, AVAGO_P1) ) return 0;
        /* TBD look at enable bit and error codes (possibly in addition to checking the PC) */
        /* if the PC is not the reset value and an interrupt is not pending, then it's probably running */
        if( (aapl_get_ip_type(aapl, sbus_addr) == AVAGO_SERDES) || (aapl_get_ip_type(aapl, sbus_addr) == AVAGO_M4)
                                                                || (aapl_get_ip_type(aapl, sbus_addr) == AVAGO_P1) )
        {
            int pc = avago_sbus_rd(aapl, sbus_addr, 0x25);
            int interrupt = avago_sbus_rd(aapl, sbus_addr, 0x4);
            int mem_bist = avago_sbus_rd(aapl, sbus_addr, 0x9);
            int stepping = avago_sbus_rd(aapl, sbus_addr, 0x20);
            int enable = avago_sbus_rd(aapl, sbus_addr, 0x7);
            int error = avago_sbus_rd(aapl, sbus_addr, 0x2a);

            if(((enable & 0x2) == 0x2) && (pc != 0x2) && (pc != 0xffff) && ((interrupt >> 16 & 0x3) == 0x0) && ((mem_bist & 0x1) == 0x00) && ((stepping&1) == 0) && ((error & 0x1f) != 0x1f))
                running = 1;
            AAPL_LOG_PRINT7(aapl, AVAGO_DEBUG7, __func__, __LINE__,
                "Running: %d, SBus %s, 0x25: 0x%08x, 0x04: 0x%08x, 0x09: 0x%08x, 0x20: 0x%x, 0x07: 0x%08x 0x2a: 0x%02x\n",
                running, aapl_addr_to_str(sbus_addr), pc, interrupt, mem_bist, stepping, enable, error);
        }
        else /* SBus Master SPICO running check */
        {
            /* TBD look at enable bit and error codes (possibly in addition to checking the PC) */
            int pc = avago_sbus_rd(aapl, sbus_addr, 0xa);
            int stepping = avago_sbus_rd(aapl, sbus_addr, 0x05);
            int mem_bist = avago_sbus_rd(aapl, sbus_addr, 0x0);
            int enable = avago_sbus_rd(aapl, sbus_addr, 0x1);
            int error = avago_sbus_rd(aapl, sbus_addr, 0xf);

            if((pc != 0x2) && (pc != 0xffff) && ((stepping & 1) == 0) && ((mem_bist & 0x4) == 0x00) && ((enable & 0x100) == 0x100) && ((error & 0x1f) != 0x1f))
                running = 1;
            AAPL_LOG_PRINT7(aapl, AVAGO_DEBUG7, __func__, __LINE__,
                            "Running: %d, SBus: %s, 0x0a: 0x%x, 0x05: 0x%08x, 0x00: 0x%08x, 0x01: 0x%08x 0x0f: 0x%02x\n",
                            running, aapl_addr_to_str(sbus_addr), pc, stepping, mem_bist, enable, error);
        }
        break;

    default:
        /* this case should never happen */
        aapl_fail(aapl, __func__, __LINE__, "SBus %s, IP type 0x%x, in process %s, is not supported.\n",
                    aapl_addr_to_str(sbus_addr), aapl_get_ip_type(aapl, sbus_addr),
                    aapl_get_process_id_str(aapl, sbus_addr));
        break;
    }
    return running;
}

/** @brief   Internal function. Returns the value of SPICO's program counter. */
/** @return  The PC value */
/** @see     avago_spico_status */
uint avago_spico_get_pc(Aapl_t *aapl, uint addr)
{
    switch( aapl_get_ip_type(aapl, addr) )
    {
    case AVAGO_P1:
    case AVAGO_M4:
    case AVAGO_SERDES: return avago_sbus_rd(aapl, addr, 0x25);
    case AVAGO_SPICO:  return avago_sbus_rd(aapl, addr, 0x0a)
                          | ((avago_sbus_rd(aapl, addr, 0x0e) & 0x3FF) << 16);
    default:           return 0;
    }
}

/** @brief   Internal function. Returns the current state of the processor. */
/** @return  SPICO's state byte */
/** @see     avago_spico_status */
uint avago_spico_get_state(Aapl_t *aapl, uint addr)
{
    switch( aapl_get_ip_type(aapl, addr) )
    {
    case AVAGO_P1:
    case AVAGO_M4:
    case AVAGO_SERDES: return avago_sbus_rd(aapl, addr, 0x2a);
    case AVAGO_SPICO:  return avago_sbus_rd(aapl, addr, 0x0f) & 0x1f;
    default:           return 0;
    }
}


/*============================================================================= */
/* SPICO STATUS */
/** */
/** @brief    Gets the current state of the processor */
/** @return   aapl->return_code */
/** @details  Create a spico_status struct, if spico is not running or it's an invalid */
/** IP or Process the struct is returned with a default configuration (state = SPICO_RESET */
/** and PC=2, all other members = 0).  Otherwise the Avago_spico_status_t is updated with the */
/** current information for the processor. */
int avago_spico_status(
    Aapl_t *aapl,                   /**< [in] Pointer to AAPL structure */
    uint sbus_addr,                 /**< [in] SBus address of SerDes */
    BOOL no_cache,                  /**< [in] Don't use AAPL cache for returning firmware rev and build information */
    Avago_spico_status_t *state)    /**< [out] Pointer to structure to fill in */
{
    if( aapl_get_spico_running_flag(aapl,sbus_addr) )
    {
        if( aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, AVAGO_SPICO) )
            state->clk = AVAGO_SERDES_SPICO_REFCLK;  /* Only one clock option */
        else /* SERDES */
            state->clk = avago_serdes_get_spico_clk_src(aapl, sbus_addr);

        if (no_cache) /* clear cache */
        {
            Avago_addr_t addr_struct;
            avago_addr_to_struct(sbus_addr, &addr_struct);
            aapl->firm_rev[AAPL_3D_ARRAY_ADDR(addr_struct)] = 0;
            aapl->firm_build[AAPL_3D_ARRAY_ADDR(addr_struct)] = 0;
        }
        state->revision = aapl_get_firmware_rev(aapl,sbus_addr);
        state->build    = aapl_get_firmware_build(aapl,sbus_addr);
        state->pc       = avago_spico_get_pc(aapl, sbus_addr);
        state->enabled  = 1;
        switch( avago_spico_get_state(aapl,sbus_addr) )
        {
            case 0x00 : { state->state = AVAGO_SPICO_RESET; break;}
            case 0x12 : { state->state = AVAGO_SPICO_PAUSE; break;}
            case 0x1f : { state->state = AVAGO_SPICO_ERROR; break;}
            default   : { state->state = AVAGO_SPICO_RUNNING; break;}
        }
    }
    else /* SPICO OFF, return */
    {
        state->enabled  = 0;
        state->pc       = 2;
        state->revision = 0;
        state->build    = 0;
        state->state    = AVAGO_SPICO_RESET;
        state->clk      = AVAGO_SERDES_SPICO_REFCLK;  /* Only one clock option */
    }
    return aapl->return_code;
}

/* Supports lane broadcast write. */
/* Converts lane broadcast read to single lane. */
static int add_int_slice_sel(Aapl_t *aapl, uint addr, int int_num)
{
    /* Map Read/Write Low-quad  => read/write lane 0 */
    /* Map Read/Write High-quad => read/write lane 4 */
    /* Map Read/Write All       => read/write lane 0 */
    /* Map Read/Write lane N    => read/write lane N */
    /* */
    /* Map Interrupt  lane N    => interrupt lane N */
    /* Map Interrupt Low-Quad   => interrupt low-quad */
    /* Map Interrupt High-Quad  => interrupt high-quad */
    /* Map Interrupt All-Quad   => interrupt all-quad */
    /*                    LQ,   HQ, BOTH         lane 0, 1, ... */
    char tab[16] = { 0, 0x08, 0x10, 0x18, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7 };
    int slice = tab[(addr >> 16) & 0xf];
    if( slice == 0 || aapl_get_ip_type(aapl,addr) != AVAGO_P1 )
        return 0;
    if( int_num & 0xc000 )  /* Memory read or write */
    {
        /* Map LOW-QUAD to 0, HIGH-QUAD to 4, ALL to 0: */
        if( slice == 0x10 ) slice = 4;
        return (slice & 7) << 10;
    }
    /* Preserve passed in lane selection: */
    return slice << 8;      /* Interrupt */
}

/** @cond INTERNAL */

/* Function that implements SerDes SPICO interrupts via the Avago Link Emulator, which is available on some Avago testchips */
uint avago_serdes_spico_int_le_fn(
    Aapl_t *aapl,   /**< [in] Pointer to AAPL structure */
    uint sbus_addr, /**< [in] SBus address of SBus Master SPICO */
    int int_num,    /**< [in] Interrupt code */
    int param)      /**< [in] Interrupt data */
{
    uint le_addr;
    int loops = 0;
    uint data = 0;

    for (le_addr = sbus_addr; le_addr <= aapl_get_max_sbus_addr(aapl, le_addr); le_addr++)
    {
        if (aapl_get_ip_type(aapl, le_addr) == AVAGO_LINK_EMULATOR) break;
    }

    avago_sbus_wr(aapl, le_addr, 0x1, int_num | (param << 16));
    avago_sbus_wr(aapl, le_addr, 0x2, 1);
    for (loops = 0; loops < aapl->serdes_int_timeout; loops++)        /* poll until interrupt done */
    {
        data = avago_sbus_rd(aapl, le_addr, 0x07);
        if ((data & 0x10000) == 0) break;   /* check interrupt status and break if in progress is low */
    }
    avago_sbus_wr(aapl, le_addr, 0x2, 0);
    if (loops >= aapl->serdes_int_timeout)  /* did we timeout? */
    {
        aapl_set_spico_running_flag(aapl,sbus_addr,0);          /* this SPICO must not be running */
        aapl_fail(aapl, __func__, __LINE__, "Interrupt 0x%02x,0x%04x timed out after %d loops on SBus address %s -> 0x%x.\n", int_num, param, aapl->serdes_int_timeout, aapl_addr_to_str(sbus_addr), data);
        return 0;
    }
    return data;
}

/** @brief   Implements SerDes SPICO interrupts via the SBus, which is the default method. */
/** @details If sbus_addr is a broadcast address, executes the interrupt on */
/**          each selected SerDes.  A failure is returned if all results are not identical. */
/** @return  On success, returns the interrupt result. */
/** @return  On failure, decrements aapl->return_code and returns 0. */
uint avago_serdes_spico_int_sbus_fn(
    Aapl_t *aapl,   /**< [in] Pointer to AAPL structure */
    uint sbus_addr, /**< [in] SBus address of SBus Master SPICO */
    int int_num,    /**< [in] Interrupt code */
    int param)      /**< [in] Interrupt data */
{
    BOOL st;
    Avago_addr_t addr_struct, start, stop, next;
    uint dev_count = 0;
    uint prev_data = 0;
    int loops = 0;
    uint data = 0;

    avago_sbus_wr(aapl, sbus_addr, 0x03, (int_num << 16) | param); /* send the actual interrupt */
    avago_addr_to_struct(sbus_addr, &addr_struct);

    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, AAPL_BROADCAST_IGNORE_LANE);
         st;
         st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_IGNORE_LANE) )
    {
        uint sbus_addr = avago_struct_to_addr(&next);
        if (!aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1)) continue;
        for (loops = 0; loops < aapl->serdes_int_timeout; loops++)        /* poll until interrupt done */
        {
            data = avago_sbus_rd(aapl, sbus_addr, 0x04);
            if ((data & 0x30000) == 0) break;   /* check interrupt status and break if in progress and disabled are low */
            if (aapl_get_spico_running_flag(aapl, sbus_addr) == AVAGO_SPICO_HALT)
            {
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__,
                    "SBus %s in halted state, so return value may not be valid for interrupt 0x%02x,0x%04x.\n", aapl_addr_to_str(sbus_addr), int_num, param);
                break;
            }
        }
        if (dev_count > 0 && prev_data != data)
        {
            aapl_fail(aapl, __func__, __LINE__, "Broadcast interrupt failed because not all SerDes responded with the same answer. Previous answers: %04x. Current answer from SBus address %s: %04x.\n", prev_data, aapl_addr_to_str(sbus_addr), data);
            return 0;
        }
        prev_data = data;
        dev_count ++;

        AAPL_LOG_PRINT8(aapl, AVAGO_DEBUG8, __func__, __LINE__, "Interrupt: %04x %04x took %4d loops to complete.\n", int_num, param, loops);
        if (loops >= aapl->serdes_int_timeout)  /* did we timeout? */
        {
            uint bits = (data >> 16) & 3;
            const char *msg = bits == 3 ? "disabled & in_progress" : bits == 2 ? "disabled" : "in_progress";
            aapl_set_spico_running_flag(aapl,sbus_addr,0);          /* this SPICO must not be running */
            aapl_fail(aapl, __func__, __LINE__, "Interrupt 0x%02x,0x%04x timed out after %d loops on SBus address %s -> 0x%x (%s).\n", int_num, param, aapl->serdes_int_timeout, aapl_addr_to_str(sbus_addr), data, msg);
            return data;
        }
    }

    /* Read again for AVAGO_LSB_01 & 02 since the read is un-triggered, this means the data read when the */
    /* status changed to "done" may not be valid. So read again to get a valid result data. */
    if( aapl_get_process_id(aapl, sbus_addr) == AVAGO_TSMC_28 && aapl_get_lsb_rev(aapl, sbus_addr) <= 2 ) data = avago_sbus_rd(aapl, sbus_addr, 0x04);
    return data;
}

/** @brief  Calls a user-provided function to execute a SerDes interrupt. */
/** @details Note that the default function uses SBus calls. */
/** @return  Returns the lower 16 bits of the interrupt function return value. */
static uint avago_serdes_spico_int(
    Aapl_t *aapl,   /**< [in] Pointer to AAPL structure */
    uint sbus_addr, /**< [in] SBus address of SBus Master SPICO */
    int int_num,    /**< [in] Interrupt code */
    int param)      /**< [in] Interrupt data */
{
    uint data = 0;
    if (!aapl_check_ip_type(aapl,sbus_addr, __func__, __LINE__, TRUE, 4,AVAGO_SERDES_BROADCAST,AVAGO_SERDES,AVAGO_M4,AVAGO_P1)) return 0;

    param &= 0xffff; /* mask out 16 bits */
    int_num |= add_int_slice_sel(aapl, sbus_addr, int_num); /* Incorporate any lane */
    sbus_addr &= 0xffff;    /* Remove lane */

    if (aapl->serdes_int_fn)
        data = aapl->serdes_int_fn(aapl, sbus_addr, int_num, param); /* avago_serdes_spico_int_sbus_fn or user supplied fn */

    AAPL_LOG_PRINT7(aapl, AVAGO_DEBUG7, __func__, __LINE__, "SBus %s, int: 0x%02x 0x%04x -> 0x%04x.\n", aapl_addr_to_str(sbus_addr), int_num, param, data);
    return (data & 0xffff);  /* return lower 16 bits from SBus read */
}

/** @brief   Where possible, executes interrupt on all addresses in list, returning when all have been completed. */
/** @details Will write the interrupt request once to each unique non-zero */
/**          group_addr value in list, assuming identical group_addr values */
/**          are sequential in list. */
/**          If group_addr is zero, writes to SerDes address. */
/** @return  Individual return values are saved into results field in each addr_list entry. */
/** @return  Returns 1 if all interrupts successfully return the same value. */
/** @return  Returns 0 if all interrupts successfully return with non-identical values. */
/** @return  Returns -1 and decrements aapl->return_code if any failure. */
int avago_parallel_serdes_int_sbus_fn(
    Aapl_t *aapl,            /**< [in] Pointer to AAPL structure. */
    Avago_addr_t *addr_list, /**< [in,out] List of addresses and results. */
    int int_num,             /**< [in] Interrupt code. */
    int int_data)            /**< [in] Interrupt data. */
{
    int loops = 0;
    int rc;
    int return_code = aapl->return_code;
    BOOL identical_results = TRUE;
    Avago_addr_t *addr_struct;

#if 1   /* Parallel implementation */
    int count = 0;

    /* Initialize results: */
    for( addr_struct = addr_list; addr_struct != 0; addr_struct = addr_struct->next )
    {
        addr_struct->results = 0x30000; /* Set in_progress bits */
        count++;
    }
    /* Start interrupts: */
    for( addr_struct = addr_list; addr_struct != 0; addr_struct = avago_group_get_next(addr_struct) )
    {
        uint addr = avago_group_get_addr(addr_struct);
        int inter_num = int_num | add_int_slice_sel(aapl, addr, int_num); /* Incorporate any lane */
        avago_sbus_wr(aapl, addr, 0x03, (inter_num << 16) | int_data); /* send the interrupt */
        aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "int_start(%s,0x%x,0x%x)\n", aapl_addr_to_str(addr),int_num,int_data);
    }

    /* Query for results: */
#if AAPL_ALLOW_AACS
    if( aapl->sbus_fn_2 == &aapl_aacs_sbus_fn && aapl->max_cmds_buffered >= count+aapl->cmds_buffered )
    {
        for( loops = 0; loops < aapl->serdes_int_timeout; loops++ )        /* poll until interrupt done */
        {
            BOOL in_progress = FALSE;
            char *ptr;
            /* Do array read: */
            /* NOTE: Reads from all addresses every time through loop. */
            for( addr_struct = addr_list; addr_struct != 0; addr_struct = addr_struct->next )
            {
                uint addr = avago_struct_to_addr(addr_struct);
                int recv_data_back = addr_struct->next ? 2 : 3; /* 2 = queue request, get return value later. */
                                                                     /* 3 = send commands, return all results. */
                addr_struct->results = avago_sbus(aapl, addr, 0x04, 0x02, 0x00000000, recv_data_back);
            }

            /* Using the default aapl_aacs_sbus_fn implementation so unpack the array of results: */
            /* The results are in the aapl->data_char string. */
            ptr = aapl->data_char;
            /*printf("aapl->data_char = \"%s\"\n", ptr); */
            while( *ptr == ';' || (*ptr != '0' && *ptr != '1') )    /* Simulation doesn't suppress unwanted return values, so need to skip them. */
                ptr++;          /* Skip output of any preceding buffered writes */
            for( addr_struct = addr_list; addr_struct != 0; addr_struct = addr_struct->next )
            {
                uint addr = avago_struct_to_addr(addr_struct);
                addr_struct->results = aapl_strtol(ptr, &ptr, 2);
                ptr++;
                AAPL_LOG_PRINT7(aapl, AVAGO_DEBUG7, __func__, __LINE__, "sbus %04x 04 02 0x00000000 -> 0x%08x\n", addr, addr_struct->results);

                /* See if all results are complete: */
                if( (addr_struct->results & 0x30000) == 0 ) /* Done if in progress and disabled are low */
                {
                    addr_struct->results &= 0xffff;
                    if( addr_struct->results != addr_list->results )
                        identical_results = FALSE;
                }
                else
                {
                    identical_results = FALSE;
                    in_progress = TRUE;
                    if( aapl_get_spico_running_flag(aapl, addr) == AVAGO_SPICO_HALT )
                    {
                        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__,
                            "SBus %s in halted state, so return value may not be valid for interrupt 0x%02x,0x%04x.\n", aapl_addr_to_str(addr), int_num, int_data);
                    }
                    break;
                }
            }
            if( !in_progress ) break;
            identical_results = TRUE;
        }
    }
    else
#endif  /* AAPL_ALLOW_AACS */
    {
        /* Query for results one at a time: */
        int loops = 0;
        for( addr_struct = addr_list; addr_struct != 0; addr_struct = addr_struct->next )
        {
            uint addr = avago_struct_to_addr(addr_struct);
            for(        ; loops < aapl->serdes_int_timeout; loops++ ) /* poll until all interrupts are done */
            {
                addr_struct->results = avago_sbus_rd(aapl, addr, 0x04);
                if( (addr_struct->results & 0x30000) == 0 ) /* Done if in progress and disabled are low */
                {
                    addr_struct->results &= 0xffff;
                    if( addr_struct->results != addr_list->results )
                        identical_results = FALSE;
                    break;
                }

                if( aapl_get_spico_running_flag(aapl, addr) == AVAGO_SPICO_HALT )
                {
                    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__,
                        "SBus %s in halted state, so return value may not be valid for interrupt 0x%02x,0x%04x.\n", aapl_addr_to_str(addr), int_num, int_data);
                    break;
                }
            }
        }
    }

#else /* Non-parallel implementation: */

    for( addr_struct = addr_list; addr_struct != 0; addr_struct = addr_struct->next )
    {
        uint addr = avago_struct_to_addr(addr_struct);
        addr_struct->results = avago_serdes_spico_int(aapl, addr, int_num, int_data);
        if( addr_struct->results != addr_list->results )
            identical_results = FALSE;
    }

#endif

    rc = aapl->return_code == return_code ? (identical_results ? 1 : 0) : -1;
    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "int: 0x%02x, 0x%04x -> 0x%x (%s); int_ret = 0x%x; loops=%d\n", int_num, int_data, rc, rc==1 ? "all same" : rc==0 ? "some differences" : "error", addr_list->results, loops);
    return rc;
}


/** @brief   Implement using sequential calls to the registered serdes_int function. */
/** @details Register this function to handle parallel serdes_int requests */
/**          as a series of individual serdes_int calls.  This is useful if a */
/**          serdes_int function is registered and calling this sequentially */
/**          is preferred over a parallel sbus implementation. */
/** @return  Individual return values are saved into results field in each addr_list entry. */
/** @return  Returns 1 if all interrupts successfully return the same value. */
/** @return  Returns 0 if all interrupts successfully return with non-identical values. */
/** @return  Returns -1 and decrements aapl->return_code if any failure. */
int avago_parallel_core_serdes_int_sbus_fn(
    Aapl_t *aapl,            /**< [in] Pointer to AAPL structure. */
    Avago_addr_t *addr_list, /**< [in,out] List of addresses and results. */
    int int_num,             /**< [in] Interrupt code. */
    int int_data)            /**< [in] Interrupt data. */
{
    int loops = 0;
    int rc;
    int return_code = aapl->return_code;
    BOOL identical_results = TRUE;
    Avago_addr_t *addr_struct;

    for( addr_struct = addr_list; addr_struct != 0; addr_struct = addr_struct->next )
    {
        uint addr = avago_struct_to_addr(addr_struct);
        addr_struct->results = avago_serdes_spico_int(aapl, addr, int_num, int_data);
        if( addr_struct->results != addr_list->results )
            identical_results = FALSE;
    }

    rc = aapl->return_code == return_code ? (identical_results ? 1 : 0) : -1;
    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "parallel_int(0x%x, 0x%x) -> 0x%x (%s); int_ret = 0x%x; loops=%d\n", int_num, int_data, rc, rc==1 ? "all same" : rc==0 ? "some differences" : "error", addr_list->results, loops);
    return rc;
}

/** @endcond */


/** @brief   Executes interrupt on all addresses in addr_list. */
/** @details Where possible, executes interrupt in parallel on all */
/**          SerDes in addr_list, returning when all have completed. */
/** @return  Individual return values are saved into addr_list results fields. */
/** @return  Returns 1 if all interrupts successfully return the same value. */
/** @return  Returns 0 if all interrupts successfully return with non-identical values. */
/** @return  Returns -1 and decrements aapl->return_code if any failure. */
int avago_parallel_serdes_int(
    Aapl_t *aapl,            /**< [in] Pointer to AAPL structure. */
    Avago_addr_t *addr_list, /**< [in,out] List of addresses and results. */
    int int_num,             /**< [in] Interrupt code. */
    int int_data)            /**< [in] Interrupt data. */
{
    if( aapl->parallel_serdes_int_fn )
        return aapl->parallel_serdes_int_fn(aapl, addr_list, int_num, int_data);   /* avago_parallel_serdes_int_sbus_fn */
    return aapl_fail(aapl, __func__, __LINE__, "No parallel_serdes_int_fn registered.\n");
}

/** @brief  Issues parallel interrupts and verifies that the */
/**         return values match the interrupt number. */
/** @return Returns TRUE if all interrupt returns match the interrupt number. */
/** @return Returns FALSE and decrements aapl->return_code if any failure. */
BOOL avago_parallel_serdes_int_check(
    Aapl_t *aapl,            /**< [in] Pointer to AAPL structure. */
    const char *caller,      /**< Caller function, usually __func__ */
    int line,                /**< Caller line number, usually __LINE__ */
    Avago_addr_t *addr_list, /**< [in,out] List of addresses and results. */
    int int_num,             /**< [in] Interrupt code. */
    int int_data)            /**< [in] Interrupt data. */
{
    int rc = avago_parallel_serdes_int(aapl, addr_list, int_num, int_data);
    if( rc != 1 || (addr_list->results & 0xff) != (int_num & 0xff) )
    {
        aapl_fail(aapl, caller, line, "%s(0x%x, 0x%x) returning incorrect value: %d (0x%x)\n", __func__, int_num, int_data, rc, addr_list->results);
        return FALSE;
    }
    AAPL_LOG_PRINT7(aapl, AVAGO_DEBUG7, __func__, __LINE__, "parallel_int: 0x%02x 0x%04x -> 0x%04x.\n", int_num, int_data, rc);
    return TRUE;
}

/** @return  On success, returns 0; */
/** @return  On error, decrements aapl->return_code and returns -1. */
static int spico_int_array_nobatch(Aapl_t *aapl, uint sbus_addr, int num_elements, Avago_spico_int_t *ints)
{
    int i;
    int return_code = aapl->return_code;
    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "num_elements = %d\n",num_elements);
    for( i = 0; i < num_elements; i++ )
    {
        Avago_spico_int_t *it = &ints[i];
        if( it->flags & AVAGO_SPICO_INT_NOT_FIRST )
        {
            it->ret = 0;    /* Initialize for not-executed cmds. */
            continue;
        }
        it->ret = avago_spico_int(aapl, sbus_addr, it->interrupt, it->param);
        if( aapl->return_code != return_code )
            break;
    }
    return aapl->return_code == return_code ? 0 : -1;
}

/** @return  On success, returns 0; */
/** @return  On error, decrements aapl->return_code and returns -1. */
static int spico_int_array_batch(Aapl_t *aapl, uint sbus_addr, int num_elements, Avago_spico_int_t *ints)
{
    int loops;
    int return_code = aapl->return_code;

    if( !aapl_is_aacs_communication_method(aapl) )
        return spico_int_array_nobatch(aapl, sbus_addr, num_elements, ints);

    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "num_elements = %d\n",num_elements);
    for( loops = 0; loops < aapl->serdes_int_timeout; loops++ ) /* poll until interrupt done */
    {
        BOOL timeout = FALSE;
        char *ptr;
        int i;
        for( i = 0; i < num_elements; i++ )
        {
            int int_num;
            int recv_data_back;
            Avago_spico_int_t *it = &ints[i];
            if( ((it->flags & AVAGO_SPICO_INT_FIRST) && loops != 0) ||
                ((it->flags & AVAGO_SPICO_INT_NOT_FIRST) && loops == 0) )
                continue;
            int_num = it->interrupt | add_int_slice_sel(aapl, sbus_addr, it->interrupt); /* Incorporate any lane */
            avago_sbus_wr(aapl, sbus_addr, 0x03, (int_num << 16) | it->param); /* send the actual interrupt */
            recv_data_back = (i == num_elements-1) ? 3 : 2;
            /* A caching form of sbus_rd: */
            avago_sbus(aapl, sbus_addr, 0x04, 0x02, 0x00000000, recv_data_back);
        }
        ptr = aapl->data_char;
        for( i = 0; i < num_elements; i++ )
        {
            Avago_spico_int_t *it = &ints[i];
            if( ((it->flags & AVAGO_SPICO_INT_FIRST) && loops != 0) ||
                ((it->flags & AVAGO_SPICO_INT_NOT_FIRST) && loops == 0) )
            {
                it->ret = 0;    /* Initialize for not-executed cmds. */
                continue;
            }
            ptr += strspn(ptr,";");
            it->ret = aapl_strtoul(ptr, &ptr, 2);
            if( it->ret & 0x30000 )
            {
                timeout = TRUE;
                break;
            }
        }
        if( !timeout )
            break;
        aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Array operation timeout retry; count = %d\n",loops);
    }
    if( loops >= aapl->serdes_int_timeout )  /* did we timeout? */
    {
        aapl_set_spico_running_flag(aapl,sbus_addr,0);          /* this SPICO must not be running */
        return aapl_fail(aapl, __func__, __LINE__, "SBus %s, Interrupt array action timed out after %d loops.\n", aapl_addr_to_str(sbus_addr), aapl->serdes_int_timeout);
    }

    return aapl->return_code == return_code ? 0 : -1;
}


/** @cond INTERNAL */

/** @return  On success, returns 0; */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_spico_int_array(Aapl_t *aapl, uint sbus_addr, int num_elements, Avago_spico_int_t *ints)
{
    int return_code = aapl->return_code;
    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, num_elements = %d\n",aapl_addr_to_str(sbus_addr), num_elements);
    /* TBD update for 28nm SBus master SPICO */
    if (!aapl_check_process(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28)) return -1;
    if (!aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, TRUE, 4, AVAGO_SPICO, AVAGO_SERDES, AVAGO_M4, AVAGO_P1)) return -1;

    if (!aapl_get_spico_running_flag(aapl,sbus_addr))
        aapl_set_spico_running_flag(aapl,sbus_addr, avago_spico_running(aapl, sbus_addr)); /* if spico was not running, check and see if it is now */

    if (!aapl_get_spico_running_flag(aapl,sbus_addr)) /* If SPICO is still not running, don't bother sending the interrupt, and just return 0 */
    {
        /* It's questionable if this should be a failure: */
        return aapl_fail(aapl, __func__, __LINE__, "Interrupt array not executed because SPICO not running on SBus address %s.\n", aapl_addr_to_str(sbus_addr));
    }

    if( aapl->max_cmds_buffered >= num_elements && aapl_is_aacs_communication_method(aapl) )
        spico_int_array_batch(aapl,sbus_addr,num_elements,ints);
    else
        spico_int_array_nobatch(aapl,sbus_addr,num_elements,ints);

    return return_code == aapl->return_code ? 0 : -1;
}

/** @endcond */

/*============================================================================= */
/* SPICO Interrupt Issue Routine */
/** @brief    Issue the provided interrupt to a SBM SPICO. */
/* */
static uint avago_sbm_spico_int(
    Aapl_t *aapl,   /**< [in] Pointer to AAPL structure */
    uint sbus_addr, /**< [in] SBus address of SBus Master SPICO */
    int int_num,    /**< [in] Interrupt code */
    int param)      /**< [in] Interrupt data */
{
    int loops;
    int int_data;
    uint data = 0;
    param &= 0xffff; /* mask out 16 bits */

    if (!aapl_check_ip_type(aapl,sbus_addr, __func__, __LINE__, TRUE, 1, AVAGO_SPICO)) return 0;

    avago_sbus_wr(aapl, sbus_addr, 0x02, (param << 16) | int_num);
    int_data = avago_sbus_rd(aapl, sbus_addr, 0x07);  /* read current state of 0x07 */

    int_data = int_data | 0x01;                 /* Assert interrupt */
    avago_sbus_wr(aapl, sbus_addr, 0x07, int_data);   /* Issue interrupt */
    int_data = int_data ^ 0x01;                 /* Clear interrupt bit */
    avago_sbus_wr(aapl, sbus_addr, 0x07, int_data);   /* Lower interrupt */

    loops = 0;

    if (aapl_get_ip_rev(aapl, avago_make_sbus_controller_addr(sbus_addr)) <= 0xbd) /* TODO-16NM esb/ip rev for 16nm is 0x02 so we need logic for process type */
    {
        for (loops = 0; loops <= aapl->serdes_int_timeout; loops++)
        {
            if (avago_sbus_rd(aapl, sbus_addr, 0x08) & 0x3ff)
                break;  /* if status is non-zero, break */
            if( loops > 10 )
                ms_sleep(1);
        }
    }
    else
    {
        for (loops = 0; loops <= aapl->serdes_int_timeout; loops++)
        {
            if ((avago_sbus_rd(aapl, sbus_addr, 0x08) & 0x8000)==0)
                break;  /* if in progress is zero */
            if( loops > 10 )
                ms_sleep(1);
        }
    }

    if (loops >= aapl->serdes_int_timeout) /* did we timeout */
    {
        aapl_set_spico_running_flag(aapl,sbus_addr,0); /* this SPICO must not be running */
        aapl_fail(aapl, __func__, __LINE__, "Interrupt 0x%02x,0x%04x timed out after %d loops on SBus address %s -> 0x%x.\n", int_num, param, aapl->serdes_int_timeout, aapl_addr_to_str(sbus_addr), data);
        return 0;
    }

    /* Read again for since the read is un-triggered, this means the data read when the */
    /* status changed to "done" may not be valid. So read again to get a valid result data. */
    data = avago_sbus_rd(aapl, sbus_addr, 0x08);

    AAPL_LOG_PRINT7(aapl, AVAGO_DEBUG7, __func__, __LINE__, "SBus %s, loops: %d, int: 0x%02x 0x%04x -> 0x%04x.\n", aapl_addr_to_str(sbus_addr), loops, int_num, param, (data >> 16) & 0xffff);
    if ((data & 0x7fff) == 1) return (data >> 16) & 0xffff; /* if status is 1, return just data */
    else                      return ((data >> 16) & 0xffff) | ((data & 0x7fff) << 16); /* if status is not 1 (failed), return status in upper 16 bits */
}


/** @brief  Issues the interrupt and verifies that the */
/**         return value matches the interrupt number. */
/** @return Returns TRUE if interrupt return matches the interrupt number. */
/** @return Returns FALSE and decrements aapl->return_code if any failure. */
BOOL avago_spico_int_check(
    Aapl_t *aapl,           /**< [in] Pointer to AAPL structure */
    const char *caller,     /**< Caller function, usually __func__ */
    int line,               /**< Caller line number, usually __LINE__ */
    uint addr,              /**< [in] SBus address of SerDes */
    int int_num,            /**< [in] Interrupt code */
    int param)              /**< [in] Interrupt data */
{
    int rc = avago_spico_int(aapl, addr, int_num, param);
    if( (rc & 0xff) != (int_num & 0xff) )
    {
        aapl_fail(aapl, caller, line, "spico_int returned incorrect value. SBus %s, spico_int(0x%x, 0x%x) returned 0x%x\n",aapl_addr_to_str(addr), int_num, param, rc);
        return FALSE;
    }
    return TRUE;
}


/** @brief  Issue the interrupt to the SPICO processor. */
/** @return The return value depends on the interrupt. */
/**         For 28nm, it is often the same as the interrupt number. */
/**         See the firmware documentation for details. */
uint avago_spico_int(
    Aapl_t *aapl,   /**< [in] Pointer to AAPL structure */
    uint sbus_addr, /**< [in] SBus address of SerDes */
    int int_num,    /**< [in] Interrupt code */
    int param)      /**< [in] Interrupt data */
{
    BOOL st;
    int rc = 0;
    int return_code = aapl->return_code;

    Avago_addr_t addr_struct, start, stop, next;
    avago_addr_to_struct(sbus_addr, &addr_struct);

    aapl_sigint_check(aapl);

    AAPL_SPICO_INT_LOCK;
    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, AAPL_BROADCAST_IGNORE_LANE);
         st;
         st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_IGNORE_LANE) )
    {
        uint sbus_addr = avago_struct_to_addr(&next);
        if (aapl_get_ip_type(aapl, sbus_addr) != AVAGO_SERDES &&
            aapl_get_ip_type(aapl, sbus_addr) != AVAGO_M4 &&
            aapl_get_ip_type(aapl, sbus_addr) != AVAGO_P1 &&
            aapl_get_ip_type(aapl, sbus_addr) != AVAGO_SPICO ) continue;

        /* if spico was not running, check and see if it is now: */
        if( !aapl_get_spico_running_flag(aapl,sbus_addr) )
            aapl_set_spico_running_flag(aapl,sbus_addr,avago_spico_running(aapl, sbus_addr));

        /* If SPICO is still not running, don't bother sending the interrupt, and just return 0 */
        if( !aapl_get_spico_running_flag(aapl,sbus_addr) )
        {
            /* It's questionable if this should be a failure: */
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__,
                "SBus %s, Interrupt 0x%02x,0x%04x not executed because SPICO not running.\n", aapl_addr_to_str(sbus_addr), int_num, param);
            AAPL_SPICO_INT_UNLOCK;
            return 0;
        }
    }

    if (aapl->capabilities & AACS_SERVER_SPICO_INT) /* does the remote AACS server support the spico_int command? */
    {
        char spico_cmd_buffer[64];
        uint ret;
        if( aapl->capabilities & AACS_SERVER_NO_CRC )   /* Verilog simulation */
        {
            uint addr = sbus_addr & 0xffff; /* Remove lane */
            int_num |= add_int_slice_sel(aapl, sbus_addr, int_num); /* Incorporate any lane */
            snprintf(spico_cmd_buffer, 63, "spico_int 0x%02x 0x%04x 0x%04x", addr, int_num, param); /* simple hex numbers */
        }
        else /* Full AAPL AACS server: */
            snprintf(spico_cmd_buffer, 63, "spico_int %s 0x%04x 0x%04x", aapl_addr_to_str(sbus_addr), int_num, param);

        avago_aacs_send_command_options(aapl, spico_cmd_buffer, /* recv_data_back */ 1, /* strtol */ 16);
        ret = aapl->data;
        AAPL_LOG_PRINT7(aapl, AVAGO_DEBUG7, __func__, __LINE__, "%s -> 0x%04x\n", spico_cmd_buffer, ret);
        AAPL_SPICO_INT_UNLOCK;
        return ret;
    }

    switch( aapl_get_process_id(aapl, sbus_addr) )
    {
    case AVAGO_TSMC_07:
    case AVAGO_TSMC_16:
    case AVAGO_TSMC_28:
        switch( aapl_get_ip_type(aapl, sbus_addr) )
        {
        case AVAGO_SERDES_BROADCAST:
        case AVAGO_P1:
        case AVAGO_M4:
        case AVAGO_SERDES: rc = avago_serdes_spico_int(aapl,sbus_addr,int_num,param); break;
        case AVAGO_SPICO:  rc = avago_sbm_spico_int(aapl,sbus_addr,int_num,param); break;
        default: break;
        }
        break;

    default:
        /* This case should never happen */
        aapl_fail(aapl, __func__, __LINE__, "SBus %s, IP type 0x%x, in process %s, is not supported.\n",
                    aapl_addr_to_str(sbus_addr), aapl_get_ip_type(aapl, sbus_addr),
                    aapl_get_process_id_str(aapl,sbus_addr));
        AAPL_SPICO_INT_UNLOCK;
        return 0;
        break;
    }

 /* Logging is done by called functions: */
 /* aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "SBus %s, Executed interrupt 0x%02x,0x%04x -> 0x%04x\n", aapl_addr_to_str(sbus_addr), int_num, param, rc); */

    AAPL_SPICO_INT_UNLOCK;

#if AAPL_ENABLE_MAIN && AAPL_ENABLE_DIAG
    if (aapl->diag_on_failure && return_code != aapl->return_code)
    {
        Avago_diag_config_t *config = avago_diag_config_construct(aapl);
        avago_diag(aapl, sbus_addr, config);
        avago_diag_config_destruct(aapl, config);
        aapl->diag_on_failure--;
    }
#else
    (void) return_code; /* to prevent compiler warnings */
#endif /* AAPL_ENABLE_MAIN && AAPL_ENABLE_DIAG */

    return rc;
}


/* Executes the given SPICO interrupt on the supplied SBus addresses */
/* For example: avago_spico_broadcast_int(aapl, 0x05, 2, 0x08, 0xaa);  // Executes */
/* SPICO interrupt 0x05 on SBus addresses 0x08, and 0xaa. */
/** */
/** @brief TBD: Documentation to be completed */
/** @return TBD: Documentation to be completed */
/** */
uint avago_spico_broadcast_int(Aapl_t *aapl, int int_num, int param, int args, ...)
{
    int i;
    va_list sbus_rx_list;
    va_start(sbus_rx_list, args);

    for( i=0; i<args; i++ )      /* Perform the spico interrupt on each slice passed to the function */
        avago_spico_int(aapl, va_arg(sbus_rx_list, uint), int_num, param);

    va_end(sbus_rx_list);
    return aapl->return_code;
}


/* Executes the given SPICO interrupt on the supplied SBus addresses */
/* For example: avago_spico_broadcast_int(aapl, 0x05, 2, 0x08, 0xaa);  // Executes */
/* SPICO interrupt 0x05 on SBus addresses 0x08, and 0xaa. */
/* Also includes a bitmask to pick and choose slices from a list since */
/* many of our lists are pre-defined to cover a larger selection */
/* than is always necessary. */
/** */
/** @brief TBD: Documentation to be completed */
/** @return TBD: Documentation to be completed */
/** */
uint avago_spico_broadcast_int_w_mask(Aapl_t *aapl, uint addr_mask, int int_num, int param, int args, ...)
{
    int i;
    va_list sbus_rx_list;
    va_start(sbus_rx_list, args);

    for( i=0; i<args; i++ )      /* Perform the spico interrupt on each slice passed to the function */
    {
        uint this_addr = va_arg(sbus_rx_list, uint);
        if( (addr_mask & (1U << i)) == (1U << i) )
        {
            avago_spico_int(aapl, this_addr, int_num, param);
        }
    }

    va_end(sbus_rx_list);
    return aapl->return_code;
}

#if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO
/* internal function used for MDIO burst uploads to SerDes and SBus master SPICO (from serdes_upload_image()) */
static void mdio_burst_upload(Aapl_t *aapl, Avago_addr_t addr_struct, int words, const int rom[])
{
    uint burst_word = 0x00000000;
    int word, burst_cnt = 0;

    if (addr_struct.sbus == 0xfd)
    {
        avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, 32779, 0x14fd);   /* Setup [15:8]=AVAGO_IMEM addr and [7:0]=sbus_addr */
        avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, 32778, 0x0001);   /* Enable upload */
    }
    else
    {
        avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, 32781, (0x0a00 | (0x00ff & addr_struct.sbus)));   /* Setup [15:8]=AVAGO_IMEM addr and [7:0]=sbus_addr */
        avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, 32780, 0x0001);   /* Enable upload */
    }
    avago_mdio(aapl, AVAGO_MDIO_ADDR, addr_struct.chip, AVSP_DEVAD, 32771); /* Set the address to upload register (same as DATA_IN of SBUS-OVER-MDIO */

    for(  word = 0; word < words; word++ )
    {
        burst_word = burst_word | (rom[word] << (10 * burst_cnt));
        if (burst_cnt == 2)
        {
            burst_word = burst_word | 0xc0000000;                                                   /* Add the count to the top end of word */
            avago_mdio(aapl, AVAGO_MDIO_WRITE, addr_struct.chip, AVSP_DEVAD, (burst_word & 0x0000ffff));               /* Write lower 16 bits */
            avago_mdio(aapl, AVAGO_MDIO_WRITE, addr_struct.chip, AVSP_DEVAD, ((burst_word & 0xffff0000) >> 16));       /* Write upper 16 bits */
            burst_cnt = 0;                                                  /* Reset the burst_cnt */
            burst_word = 0x00000000;                                        /* Reset the burst_word */
        }
        else burst_cnt++;
    }

    if (burst_cnt != 0)
    {
        burst_word = burst_word | (burst_cnt << 30);                                            /* Add the count to the top end of word */
        avago_mdio(aapl, AVAGO_MDIO_WRITE, addr_struct.chip, AVSP_DEVAD, (burst_word & 0x0000ffff));         /* Write lower 16 bits */
        avago_mdio(aapl, AVAGO_MDIO_WRITE, addr_struct.chip, AVSP_DEVAD, ((burst_word & 0xffff0000) >> 16)); /* Write upper 16 bits */
    }

    if (addr_struct.sbus == 0xfd) avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, 32778, 0x0000);  /* Disable upload */
    else                          avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, 32780, 0x0000);  /* Disable upload */
}
#endif

/* Upload 12 bit instructions: */
static void spico_burst_upload_12bit(Aapl_t *aapl, uint sbus, uint reg, uint rom_size, const int *rom)
{
    uint word;
    aapl_log_printf(aapl,AVAGO_DEBUG7,__func__,__LINE__,"sbus=0x%02x, reg=0x%x, rom_size=%u\n",sbus,reg,rom_size);
    for( word = 0; word < rom_size; word += 8 )
    {
        uint buf;
        buf  = rom[word+0] <<  0;
        buf |= rom[word+1] << 12;
        buf |= rom[word+2] << 24;
        avago_sbus_wr(aapl, sbus, reg, buf);
        buf  = rom[word+2] >>  8 & 0xf;
        buf |= rom[word+3] <<  4;
        buf |= rom[word+4] << 16;
        buf |= rom[word+5] << 28;
        avago_sbus_wr(aapl, sbus, reg, buf);
        buf  = rom[word+5] >>  4 & 0xff;
        buf |= rom[word+6] <<  8;
        buf |= rom[word+7] << 20;
        avago_sbus_wr(aapl, sbus, reg, buf);
    }
}

static void spico_burst_upload(Aapl_t *aapl, uint sbus, uint reg, uint rom_size, const int *rom)
{
    uint word;
    aapl_log_printf(aapl,AVAGO_DEBUG7,__func__,__LINE__,"sbus=0x%02x, reg=0x%x, rom_size=%u\n",sbus,reg,rom_size);
    for( word=0; word < rom_size-2; word += 3 )
        avago_sbus_wr(aapl, sbus, reg, 0xc0000000 | rom[word] | (rom[word+1] << 10) | (rom[word+2] << 20));
    if( rom_size - word == 2 )
        avago_sbus_wr(aapl, sbus, reg, 0x80000000 | rom[word] | (rom[word+1] << 10));
    else if( rom_size - word == 1 )
        avago_sbus_wr(aapl, sbus, reg, 0x40000000 | rom[word]);
}

/** @brief   Internal function that uploads the ROM blindly to the sbus_addr. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
static int spico_upload_image(Aapl_t *aapl, uint sbus_addr, int words, const int rom[])
{
    int return_code = aapl->return_code;

    if (aapl_check_process(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28))
    {
        Avago_addr_t addr_struct;
        avago_addr_to_struct(sbus_addr,&addr_struct);
        if( aapl_check_ip_type(aapl,sbus_addr, __func__, __LINE__, FALSE, 6,
                AVAGO_SERDES, AVAGO_SERDES_D6_BROADCAST,
                AVAGO_M4, AVAGO_SERDES_M4_BROADCAST,
                AVAGO_P1, AVAGO_SERDES_P1_BROADCAST) )
        {
            /* Prepare SerDes for upload: */
            avago_sbus_wr(aapl, sbus_addr, 0x07, 0x00000011);     /* Set GLOBAL_RESET & SPICO_CLK_GATE_DISABLE */
            avago_sbus_wr(aapl, sbus_addr, 0x07, 0x00000010);     /* Clear GLOBAL_RESET */
            avago_sbus_wr(aapl, sbus_addr, 0x08, 0x00000030);     /* Set DISABLE_HDW_INTERRUPT, DISABLE_CORE_INTERRUPT */
            avago_sbus_wr(aapl, sbus_addr, 0x00, 0xc0000000);     /* Set IMEM_CNTL_EN & IMEM_LOAD */

            /* Upload: */
#if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO
            if( aapl_is_mdio_communication_method(aapl) )
                mdio_burst_upload(aapl, addr_struct, words, rom);
            else
#endif /* AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO */
            {
                if( aapl_get_process_id(aapl, sbus_addr) == AVAGO_TSMC_07 )
                {
                    spico_burst_upload_12bit(aapl, sbus_addr, 0x0a, words, rom);
                }
                else if( aapl_get_process_id(aapl, sbus_addr) == AVAGO_TSMC_28 && aapl_get_lsb_rev(aapl, sbus_addr) <= 2 )
                {
                    int word;
                    for (word=0; word < words; word++)
                        avago_sbus_wr(aapl, sbus_addr, 0x00, 0xc0000000 | (rom[word] << 16) | word);
                }
                else /* Newer AVAGO_LSBs support burst uploading */
                    spico_burst_upload(aapl, sbus_addr, 0x0a, words, rom);
            }

            /* Start SerDes processor: */
            avago_sbus_wr(aapl, sbus_addr, 0x00, 0x00000000);     /* Clr IMEM_CNTL_EN */
            avago_sbus_wr(aapl, sbus_addr, 0x0b, 0x000c0000);     /* Set IMEM_ECC_ENAB and DMEM_ECC_ENAB */
            avago_sbus_wr(aapl, sbus_addr, 0x0c, 0xc0000000);     /* Clear any ECC errors that occurred previously */
            avago_sbus_wr(aapl, sbus_addr, 0x07, 0x00000002);     /* Set SPICO_ENABLE, Clr SPICO_CLK_GATE_DISABLE */
            avago_sbus_wr(aapl, sbus_addr, 0x08, 0x00000000);     /* Enable HDW and CORE interrupts */
        }
        /* TRUE forces error message if no match: */
        else if (aapl_check_ip_type(aapl,sbus_addr, __func__, __LINE__, TRUE, 2, AVAGO_SPICO, AVAGO_SPICO_BROADCAST))
        {
            /* Prepare SBus Master for upload: */
            avago_sbus_wr(aapl, sbus_addr, 0x01, 0x000000c0); /* Reset high */
            avago_sbus_wr(aapl, sbus_addr, 0x01, 0x00000040); /* Reset low */
            avago_sbus_wr(aapl, sbus_addr, 0x01, 0x00000240); /* imem_cntl_en */

            /* Upload: */
#if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO
            if( aapl_is_mdio_communication_method(aapl) )
                mdio_burst_upload(aapl, addr_struct, words, rom);
            else
#endif /* AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO */
            {
                int rev = aapl_get_ip_rev(aapl, avago_make_sbus_controller_addr(sbus_addr));
                if( rev >= 0xbe )
                {
                    avago_sbus_wr(aapl, sbus_addr, 0x03, 0x00000000);   /* Clear imem write enable */
                    avago_sbus_wr(aapl, sbus_addr, 0x03, 0x80000000);   /* Set imem address for burst writes */
                    if( aapl_get_process_id(aapl, sbus_addr) == AVAGO_TSMC_07 )
                        spico_burst_upload_12bit(aapl, sbus_addr, 0x14, words, rom);
                    else
                        spico_burst_upload(aapl, sbus_addr, 0x14, words, rom);
                }
                else    /* if( rev <= 0xbd ) // 28nm test chips and all 40nm */
                {
                    int word;
                    for( word=0; word < words; word++ )
                        avago_sbus_wr(aapl, sbus_addr, 0x03, 0x80000000 | (rom[word] << 16) | word);
                }
                /* Initialize the IMEM that SBM checks to see if a table is appended. */
                /* Also prevents imem ECC errors when no table is appended and mem_bist hasn't ran. */
                /* SBus Master revisions through 0x1023 require this. */
                avago_sbus_wr(aapl, sbus_addr, 0x03, 0x80000000 | words);
                avago_sbus_wr(aapl, sbus_addr, 0x03, 0x80000000 | (words+1));
                avago_sbus_wr(aapl, sbus_addr, 0x03, 0x80000000 | (words+2));
                avago_sbus_wr(aapl, sbus_addr, 0x03, 0x80000000 | (words+3));
            }

            /* Start SBus Master processor: */
            avago_sbus_wr(aapl, sbus_addr, 0x01, 0x00000040); /* Disable imem_cntl_en */
            avago_sbus_wr(aapl, sbus_addr, 0x16, 0x000c0000); /* Enable ECC */
            avago_sbus_wr(aapl, sbus_addr, 0x01, 0x00000140); /* Enable SPICO */
        }
    }
    return aapl->return_code == return_code ? 0 : -1;
}


/** @cond INTERNAL */

/** @brief   Internal function that uploads SWAP image into SBM. */
/** @return  Returns 1 on success, 0 on failure. */
int avago_spico_upload_swap_image(
    Aapl_t *aapl,       /**< [in] Pointer to AAPL structure. */
    uint sbus_addr_in,  /**< [in] SBus address of SerDes. */
    int words,          /**< [in] Number of elements in rom. */
    const int *rom)     /**< [in] Swap image to upload. */
{
    int crc = 0;
    BOOL st;
    Avago_addr_t addr_struct, start, stop, next;

    if( !aapl_check_ip_type(aapl, sbus_addr_in, __func__, __LINE__, TRUE, 4, AVAGO_SERDES, AVAGO_SERDES_BROADCAST, AVAGO_M4, AVAGO_P1) ||
        !aapl_check_process(aapl, sbus_addr_in, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28) )
        return 0;

    avago_addr_to_struct(avago_make_sbus_master_addr(sbus_addr_in), &addr_struct); /* change sbus_addr_in to SPICO for the provided chip,ring */

    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, AAPL_BROADCAST_IGNORE_LANE);
         st;
         st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_IGNORE_LANE) )
    {
        uint sbus_addr = avago_struct_to_addr(&next);

        if( !aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, AVAGO_SPICO) )
            continue; /* Skip entries that don't exist or are unknown */

        avago_firmware_get_rev(aapl, sbus_addr); /* check rev, which will update spico_running */
        if( !aapl_get_spico_running_flag(aapl,sbus_addr) )
        {
            aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Swap image can not be uploaded because the SPICO at address %s is not running.\n", aapl_addr_to_str(sbus_addr));
            continue;
        }

        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "SBus %s, Uploading %d bytes of SerDes swap machine code.\n", aapl_addr_to_str(sbus_addr), words);

        avago_sbus_rmw(aapl, sbus_addr, 7, 0, 2); /* Enable swap by disabling spico_int_0 gate */

        /* Check Sbus Controller revision to know where to place swap image */
        if( aapl_get_ip_rev(aapl, avago_make_sbus_controller_addr(sbus_addr)) >= 0x00be ) /* TODO-16NM esb/ip rev for 16nm is 0x02 so we need logic for process type */
        {
            /* Production SBM, swap image loaded into AVAGO_IMEM */
            int base_addr = avago_spico_int(aapl, sbus_addr, 0x1c, 0); /* Retrieve end of ROM from loaded image */
            aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "SBus %s, Loading Swap Image to production SBM, base_addr=0x%x \n",aapl_addr_to_str(sbus_addr), base_addr);

            avago_sbus_wr( aapl, sbus_addr, 0x05, 0x01);            /* Assert Single-Step Enable to halt processor */
            avago_sbus_rmw(aapl, sbus_addr, 0x01, 0x0200, 0x0200);  /* Set imem_cntl_en to enable writing imem */
            avago_sbus_wr(aapl, sbus_addr, 0x03, 0x00000000 | base_addr); /* Clr imem_write_en */
            avago_sbus_wr(aapl, sbus_addr, 0x03, 0x80000000 | base_addr); /* Set imem_write_en and upload address */

            spico_burst_upload(aapl, sbus_addr, 0x14, words, rom);

            avago_sbus_wr(aapl, sbus_addr, 0x03, 0x00000000);       /* Clr imem_write_en */
            avago_sbus_rmw(aapl, sbus_addr, 0x01, 0x0000, 0x0200);  /* Clr imem_cntl_en */
            avago_sbus_wr( aapl, sbus_addr, 0x05, 0x00);            /* Lower Single-Step Enable to enable processor */
            crc = avago_spico_int(aapl, sbus_addr, 0x1a, 0);        /* Run CRC on swap image */
        }
        else    /* Test chip SBM, swap image loaded to XDMEM */
        {
            int base_addr = 0x400;
            int word;
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "SBus %s, Loading Swap Image to test chip SBM, base_addr=0x%x \n",aapl_addr_to_str(sbus_addr), base_addr);
            avago_sbus_wr( aapl, sbus_addr, 0x05, 0x01);            /* Assert Single-Step Enable to halt processor */
            avago_sbus_rmw(aapl, sbus_addr, 0x01, 0x0C00, 0x0C00);  /* Set dmem_cntl_en and dmem_extended_cntl_en */
            for( word=0; word < words; word++ )
                avago_sbus_wr(aapl, sbus_addr, 0x04, 0x8000 | (rom[word] << 16) | (base_addr+word));
            avago_sbus_rmw(aapl, sbus_addr, 0x01, 0x0000, 0x0C00);  /* Clr dmem_cntl_en and dmem_extended_cntl_en */
            avago_sbus_wr( aapl, sbus_addr, 0x05, 0x00);            /* Lower Single-Step Enable to enable processor */
            crc = avago_spico_int(aapl, sbus_addr, 0x04, 0);        /* Run CRC on swap image */
        }
        if( crc == 1 )
            aapl_log_printf(aapl, AVAGO_DEBUG2, __func__,__LINE__,"SBus %s, Swap CRC passed\n", aapl_addr_to_str(sbus_addr));
        else
        {
            aapl_fail(aapl, __func__, __LINE__, "SBus %s, Swap CRC failed, interrupt returned %04x\n", aapl_addr_to_str(sbus_addr), crc);
            crc = 0;
        }
    }
    return crc;
}

void aapl_crc_one_byte(int *crc_ptr, int value)
{
    int crc = *crc_ptr;
    crc += value;
    crc ^= 0xd8;
    if( crc & 0x80000000 )
        crc = (crc << 1) + 229;
    else
        crc <<= 1;
    *crc_ptr = crc;
}

int aapl_crc_rom(int *memory, int length)
{
    int i, crc = 0;
    for (i = 0; i < length; i++)
        aapl_crc_one_byte(&crc, memory[i]);
    return crc ^ 0xdeadbeef;
}

/** @brief Checks that last address in list is ready for interrupts. */
/** @details Assumes that if last address is ready, all addresses will be ready. */
static void wait_for_serdes_ready_for_interrupt(Aapl_t *aapl, Avago_addr_t *addr_list)
{
    int ms;
    uint addr;

    /* Find last address in list: */
    while( addr_list->next )
        addr_list = addr_list->next;
    addr = avago_struct_to_addr(addr_list);

#if 1
    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) )
        return;
#else
    /* I think this may be unnecessary with the 0x101F and newer SBus Master */
    /* firmware release which fixes a first-interrupt race condition */
    /* immediately after upload/startup in 0x101D and older. */
    if( aapl_get_ip_type(aapl, addr) == AVAGO_SPICO )
    {
        ms_sleep(50);   /* For lack of anything better to do. */
        return;
    }
#endif

    for( ms = 0; ms < 50; ms++ )    /* 34 should be sufficient if no overhead */
    {
        int o_core_status = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB_DIRECT, 0x27);
        if( o_core_status & (1<<5) )
            break;
        ms_sleep(1);
    }
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "SBus %s wait %d ms for interrupts to be enabled.\n", aapl_addr_to_str(addr), ms);
}

/** @endcond */


/** @brief   Upload SPICO machine code in parallel to all SPICOs in list and check CRC. */
/**          Works for broadcast and individual addresses. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_parallel_spico_upload(
    Aapl_t *aapl,               /**< Pointer to Aapl_t structure */
    Avago_addr_t *addr_list,    /**< List of Sbus address to upload to */
    BOOL ram_bist,              /**< If TRUE, perform spico_ram_bist prior to upload */
    int words,                  /**< Length of ROM image */
    const int *rom)             /**< Avago-supplied ROM image */
{
    int return_code = aapl->return_code;
    Avago_addr_t *addr_struct;

    if( words <= 0 )
    {
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "0 byte image specified. Skipping upload.\n");
        return 0;
    }

    /* Verify that address list has only SerDes devices (no broadcast addresses): */
    for( addr_struct = addr_list; addr_struct != 0; addr_struct = addr_struct->next )
    {
        uint addr = avago_struct_to_addr(addr_struct);

        if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 4, AVAGO_SPICO, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) ||
            !aapl_check_process(aapl, addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_28, AVAGO_TSMC_16, AVAGO_TSMC_07) )
            return 0;
    }

    /* Execute SBus reset and ram bist on each SerDes: */
    for( addr_struct = addr_list; addr_struct != 0; addr_struct = addr_struct->next )
    {
        uint addr = avago_struct_to_addr(addr_struct);

        avago_sbus_reset(aapl, addr, 0);
        aapl_set_spico_running_flag(aapl, addr, 0); /* SPICO is dead now that we've reset memory */
        if( ram_bist )
            avago_spico_ram_bist(aapl, addr);
    }

    /* Setup broadcast group */
    avago_group_clear(aapl, addr_list); /* group_1 addresses are invalid after reset, so update addr_list to match reality */
    avago_group_setup(aapl, addr_list); /* These functions are no-ops for predefined broadcast addresses. */

    /* Upload image to all SPICOs using broadcast group: */
    for( addr_struct = addr_list; addr_struct != 0; addr_struct = avago_group_get_next(addr_struct) )
    {
        uint addr = avago_group_get_addr(addr_struct);
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Uploading %d bytes of SPICO machine code to SBus address %s.\n", words, aapl_addr_to_str(addr));
        spico_upload_image(aapl, addr, words, rom);
    }

    wait_for_serdes_ready_for_interrupt(aapl, addr_list);

    /* Check CRC using parallel interrupt */
    avago_parallel_serdes_crc(aapl, addr_list);

    return return_code == aapl->return_code ? 0 : -1;
}

/** @brief   Upload SPICO machine code and check CRC. */
/**          Works for broadcast and individual addresses. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_spico_upload(
    Aapl_t *aapl,       /**< Pointer to Aapl_t structure */
    uint sbus_addr_in,  /**< Sbus address */
    BOOL ram_bist,      /**< If TRUE, perform spico_ram_bist prior to upload */
    int words,          /**< Length of ROM image */
    const int *rom)     /**< Avago-supplied ROM image */
{
    int return_code = aapl->return_code;
    BOOL st;
    Avago_addr_t addr_struct, start, stop, next;

    if( !aapl_check_ip_type(aapl, sbus_addr_in, __func__, __LINE__, TRUE, 8, AVAGO_SPICO, AVAGO_SERDES, AVAGO_SERDES_BROADCAST, AVAGO_SPICO_BROADCAST, AVAGO_M4, AVAGO_SERDES_M4_BROADCAST, AVAGO_P1, AVAGO_SERDES_P1_BROADCAST) ||
        !aapl_check_process(aapl, sbus_addr_in, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_28, AVAGO_TSMC_16) )
        return 0;

    if (words <= 0)
    {
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "0 byte image specified. Skipping upload to %s.\n", aapl_addr_to_str(sbus_addr_in));
        return 0;
    }

    avago_addr_to_struct(sbus_addr_in, &addr_struct);

    /* Call avago_sbus_reset() once for each SerDes, this way we do not */
    /* inadvertently reset a device that we will not be uploading firmware to. */
    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, AAPL_BROADCAST_IGNORE_LANE);
         st;
         st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_IGNORE_LANE) )
    {
        BOOL ignore = FALSE;
        uint sbus_addr = avago_struct_to_addr(&next);

        /* Don't call further functions if not a match: */
        if( !aapl_addr_selects_fw_device(aapl, &addr_struct, sbus_addr, &ignore) )
        {
            if( ignore )
                aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Skipping reset of SBus address %s because an upload was requested to %s and the ignore broadcast bit on this SerDes was set.\n", aapl_addr_to_str(sbus_addr), aapl_addr_to_str(sbus_addr_in));
            continue; /* Don't call further functions if not a match. */
        }

        /* Reset the device and run rambist if applicable. */
        avago_sbus_reset(aapl, sbus_addr, 0);
        aapl_set_spico_running_flag(aapl,sbus_addr,0); /* SPICO is dead now that we've reset memory */
        if( ram_bist )
            avago_spico_ram_bist(aapl, sbus_addr);
    }

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Uploading %d bytes of SPICO machine code to SBus address %s.\n", words, aapl_addr_to_str(sbus_addr_in));
    spico_upload_image(aapl, sbus_addr_in, words, rom); /* upload image to all SPICOs (including broadcast addresses) */

    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, AAPL_BROADCAST_IGNORE_LANE);
         st;
         st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_IGNORE_LANE) )
    {
        BOOL ignore = FALSE;
        uint sbus_addr = avago_struct_to_addr(&next);

        if( !aapl_addr_selects_fw_device(aapl, &addr_struct, sbus_addr, &ignore) )
        {
            if( ignore )
                aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Skipping CRC check of SBus address %s because an upload was requested to %s and the ignore broadcast bit on this SerDes was set.\n", aapl_addr_to_str(sbus_addr), aapl_addr_to_str(sbus_addr_in));
            continue; /* Don't call further functions if not a match. */
        }
        wait_for_serdes_ready_for_interrupt(aapl, &next);

        aapl_set_spico_running_flag(aapl, sbus_addr, 1);      /* Set the running flag to on */
        if( avago_spico_crc(aapl, sbus_addr) )
            aapl_set_ip_type(aapl, sbus_addr); /* this will set the firmware rev, spico running, etc... */
        if (!(aapl->capabilities & AACS_SERVER_NO_CRC) && aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, AVAGO_SPICO) )
        {
            /* If sbm image has an append SDI, check its CRC: */
            /* Retrieve end of ROM location from loaded image: */
            int end_addr = avago_spico_int(aapl, sbus_addr, 0x1c, 0);
            aapl_set_spico_running_flag(aapl, sbus_addr, 1);      /* Set the running flag to on */
            if( end_addr < words ) /* If more uploaded than just SBM image: */
            {
                int crc = avago_spico_int(aapl, sbus_addr, 0x1a, 0);        /* Run CRC on swap image */
                if( crc )
                    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "SBus %s, SDI CRC passed.\n", aapl_addr_to_str(sbus_addr));
                else
                    aapl_fail(aapl, __func__, __LINE__, "SBus %s, SDI CRC failed. CRC interrupt returned 0x%04x\n", aapl_addr_to_str(sbus_addr), crc);
            }
        }
    }
    return return_code == aapl->return_code ? 0 : -1;
}


/** @brief   Runs RAM BIST on given SBus address. */
/** @details Works for broadcast and individual addresses. */
/** @return  On success, returns 0. */
/**          On error, decrements aapl->return_code and returns -1. */
int avago_spico_ram_bist(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure */
    uint sbus_addr_in)      /**< Sbus address */
{
    int return_code = aapl->return_code;
    int loops;
    uint data = 0;
    BOOL st;
    Avago_addr_t addr_struct, start, stop, next;

    if( !aapl_check_ip_type(aapl, sbus_addr_in, __func__, __LINE__, TRUE, 8, AVAGO_SERDES, AVAGO_SPICO,
            AVAGO_SERDES_BROADCAST, AVAGO_SPICO_BROADCAST, AVAGO_M4, AVAGO_SERDES_M4_BROADCAST, AVAGO_P1, AVAGO_SERDES_P1_BROADCAST) ||
        !aapl_check_process(aapl, sbus_addr_in, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28) )
        return 0;

    avago_addr_to_struct(sbus_addr_in, &addr_struct);
    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, AAPL_BROADCAST_IGNORE_LANE);
         st;
         st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_IGNORE_LANE) )
    {
        uint rambist_mask = 0;
        uint sbus_addr = avago_struct_to_addr(&next);
        Avago_process_id_t process_id = aapl_get_process_id(aapl,sbus_addr);
        int lsb_rev = aapl_get_lsb_rev(aapl, sbus_addr);

        if( aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, AVAGO_SPICO) )
        {
            avago_sbus_wr(aapl, sbus_addr, 0x00, 0x03);
            aapl_set_spico_running_flag(aapl,sbus_addr,0); /* SPICO is dead now that we've reset memory */
            avago_sbus_rmw(aapl, sbus_addr, 0x01, 0x080, 0x180); /* Force processor into reset */
            avago_sbus_wr(aapl, sbus_addr, 0x00, 0x05);
            for( loops=0; loops<=aapl->serdes_int_timeout; loops++ )
            {
                data = avago_sbus_rd(aapl, sbus_addr, 0x00);
                if( data & 0x18 ) break; /* check for PASS and/or fail and break out if set */
            }

            if( loops >= aapl->serdes_int_timeout )  /* did we timeout? */
                aapl_fail(aapl, __func__, __LINE__, "SBus master SPICO RAM BIST timed out on SBus address %s -> 0x%x.\n", aapl_addr_to_str(sbus_addr), data);
            else if( (data & 0x18) == 0x08 )   /* If it passes */
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "SBus master SPICO RAM BIST test on SBus address %s passed.\n", aapl_addr_to_str(sbus_addr));
            else
                aapl_fail(aapl, __func__, __LINE__, "SBus master SPICO RAM BIST on SBus %s failed -> 0x%x.\n", aapl_addr_to_str(sbus_addr), data);

            avago_sbus_wr(aapl, sbus_addr, 0x00, 0x01); /* disable RAM BIST */
            continue;
        }

        if( !aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) )
            continue;  /* skip non-serdes */

        /* If a broadcast request, skip any serdes that have the ignore broadcast bit set: */
        if( start.sbus != stop.sbus && (avago_sbus_rd(aapl, sbus_addr, 0xfd) & 0x1) == 0x1 )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Skipping RAM BIST check of SBus address %s because a RAM BIST test was requested to %s and the ignore broadcast bit on this serdes was set.\n", aapl_addr_to_str(sbus_addr), aapl_addr_to_str(sbus_addr_in));
            continue;
        }

        aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Performing RAM BIST check of SBus address %s because a RAM BIST test was requested to %s.\n", aapl_addr_to_str(sbus_addr), aapl_addr_to_str(sbus_addr_in));
        if( lsb_rev < 5 && process_id == AVAGO_TSMC_28 )
            rambist_mask = 8; /* 28nm GEN1 [4:3] are RWM field, others [3] is CORE_MEM_RST so can't set that, lsb_rev 4 in 16nm is Hertz & Lorentz */

        avago_sbus_wr(aapl, sbus_addr, 0x09, 0x00 | rambist_mask); /* disable RAM BIST */
        data = avago_sbus_rd(aapl, sbus_addr, 0x09);

        if ((data & 0x001f) != rambist_mask)
        {
            aapl_fail(aapl, __func__, __LINE__, "0x%02x, RAM BIST setup failed. Returned value: 0x%08x, expecting: 0x%08x.\n", sbus_addr, data, rambist_mask);
            avago_sbus_wr(aapl, sbus_addr, 0x09, rambist_mask); /* disable RAM BIST */
            continue;
        }

        aapl_set_spico_running_flag(aapl,sbus_addr,0); /* SPICO is dead now that we've reset memory */
        avago_sbus_wr(aapl, sbus_addr, 0x07, 0x11);    /* Force processor into reset */
        avago_sbus_wr(aapl, sbus_addr, 0x09, 0x03 | rambist_mask); /* start RAM BIST test */

        for( loops=0; loops<=aapl->serdes_int_timeout; loops++ )
        {
            data = avago_sbus_rd(aapl, sbus_addr, 0x09);
            if( data & 0x3f0060 )   /* If any failure or all pass */
                break;

            if( lsb_rev >= 3 && lsb_rev < 8 && process_id != AVAGO_TSMC_07 )
            {
                /* For AVAGO_LSB 3 - 7, you must check the individual pass bits as the */
                /* the TEST__MEM_BIST_PASS_OUT bit isn't set. */
                /* But we can only check for 2 bits as that's all the bits (memory) some chips set. */
                if( (data & 0x3f00) == 0x0300 )
                    break; /* break if all passed */
            }
        }

        if (loops >= aapl->serdes_int_timeout)  /* did we timeout? */
        {
            aapl_fail(aapl, __func__, __LINE__, "SBus %s, RAM BIST timed out -> 0x%x\n", aapl_addr_to_str(sbus_addr), data);
        }
        /* REG     5    0  R     TEST__MEM_BIST_PASS_OUT */
        /* REG     6    0  R     TEST__MEM_BIST_FAIL_OUT */
        /* REG  13:8    0  R     BIST_DONE_PASS_OUT */
        /* REG  21:16   0  R     BIST_DONE_FAIL_OUT */
        else if ((data & 0x3f0040) != 0x0) /* we're done, so just check for fail */
            aapl_fail(aapl, __func__, __LINE__, "SBus %s, RAM BIST failed -> 0x%x.\n", aapl_addr_to_str(sbus_addr), data);
        else
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "SBus %s, RAM BIST test passed. %x\n", aapl_addr_to_str(sbus_addr), data);

        avago_sbus_wr(aapl, sbus_addr, 0x09, rambist_mask); /* disable RAM BIST */
    }
    return return_code == aapl->return_code ? 0 : -1;
}

/** @brief  Gets the revision of the firmware loaded into the SPICO processor. */
/** @return  On success, returns the firmware revision. */
/**          If SPICO is stopped, returns 0. */
/** @see avago_firmware_get_build_id(). */
uint avago_firmware_get_rev(
    Aapl_t *aapl,   /**< Pointer to Aapl_t structure */
    uint addr)      /**< Sbus address of the SPICO to check. */
{
    uint rc = 0;
    Avago_process_id_t process_id = aapl_get_process_id(aapl,addr);
    if( process_id == AVAGO_TSMC_28 || process_id == AVAGO_TSMC_16 || process_id == AVAGO_TSMC_07 )
    {
        if( aapl_check_ip_type(aapl,addr, __func__, __LINE__, TRUE, 4, AVAGO_SERDES, AVAGO_SPICO, AVAGO_M4, AVAGO_P1) )
            rc = avago_spico_int(aapl, addr, 0, 0);
    }
    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, fw_rev = 0x%04x.\n", aapl_addr_to_str(addr), rc);
    return rc;
}

/** @brief  Gets the engineering release count id of the firmware loaded into the SPICO processor. */
/** @return On success, returns the engineering release count id of loaded firmware. */
/**         If SPICO is stopped, returns 0. */
/** @see    avago_firmware_get_build_id(). */
uint avago_firmware_get_engineering_id(
    Aapl_t *aapl,   /**< Pointer to Aapl_t structure */
    uint addr)      /**< Sbus address of the SPICO to check. */
{
    uint rc = 0;
    Avago_process_id_t process_id = aapl_get_process_id(aapl,addr);
    if( process_id == AVAGO_TSMC_16 || process_id == AVAGO_TSMC_07 )
    {
        if( aapl_check_ip_type(aapl,addr, __func__, __LINE__, FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) )
        {
            rc = avago_spico_int(aapl, addr, 0x00, 1);
            /* Engineering release will be zero when int 0x00 returns revision ID, as older firmware doesn't support reading an engineering release */
            rc = ( rc == (uint) aapl_get_firmware_rev(aapl, addr) ) ? 0 : rc;
        }
    }

    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, eng_rel_cnt_id = 0x%04x.\n", aapl_addr_to_str(addr), rc);
    return rc;
}

/** @brief  Gets the build id of the firmware loaded into the SPICO processor. */
/** @return On success, returns the firmware build id. */
/**         If SPICO is stopped, returns 0. */
/** @see    avago_firmware_get_rev(). */
uint avago_firmware_get_build_id(
    Aapl_t *aapl,   /**< Pointer to Aapl_t structure */
    uint addr)      /**< Sbus address of the SPICO to check. */
{
    uint rc = 0;
    {
        if( aapl_check_ip_type(aapl,addr, __func__, __LINE__, TRUE, 4, AVAGO_SERDES, AVAGO_SPICO, AVAGO_M4, AVAGO_P1) )
        {
            if( aapl_check_ip_type(aapl,addr, __func__, __LINE__, FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) )
                rc = avago_spico_int(aapl, addr, 0x3f, 0);
            else
                rc = avago_spico_int(aapl, addr, 0x01, 0);
        }
    }
    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, fw_build_id = %04X.\n", aapl_addr_to_str(addr), rc);
    return rc;
}

/** @brief   Verifies the CRC checksum of the firmware image on sbus_addr. */
/** @return  Returns TRUE if checksum is valid, FALSE if not. */
BOOL avago_spico_crc(
    Aapl_t *aapl,       /**< Pointer to Aapl_t structure */
    uint sbus_addr)     /**< Sbus address */
{
    int crc_status = 0;
    int crc = 1;
    int return_code = aapl->return_code;
    int running;

    if (!aapl_check_process(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28)) return 0;
    if (aapl->capabilities & AACS_SERVER_NO_CRC)
    {
        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "SBus %s, CRC skipped due to aapl->capabilities AACS_SERVER_NO_CRC set. CRC passed.\n", aapl_addr_to_str(sbus_addr));
        return 1; /* skip CRC checking */
    }

    switch( aapl_get_process_id(aapl, sbus_addr) )
    {
    case AVAGO_TSMC_07:
    case AVAGO_TSMC_16:
    case AVAGO_TSMC_28:
        if(!aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, TRUE, 7, AVAGO_SERDES, AVAGO_SERDES_BROADCAST, AVAGO_SPICO, AVAGO_M4, AVAGO_SERDES_M4_BROADCAST, AVAGO_P1, AVAGO_SERDES_P1_BROADCAST)) return 0;
        if(aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 6, AVAGO_SERDES, AVAGO_SERDES_BROADCAST, AVAGO_M4, AVAGO_SERDES_M4_BROADCAST, AVAGO_P1, AVAGO_SERDES_P1_BROADCAST))
        {
            /* 0x00 == Valid */
            /* 0xFF == Fail */
            /* 0x3C == Not run, CRC check is currently in progress */
            crc = avago_spico_int(aapl, sbus_addr, 0x3c, 0);
            crc_status = crc == 0;
        }
        else if (aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, AVAGO_SPICO))
        {
            /*  1 == Valid */
            /* -1 == Fail */
            /*  0 == CRC check is currently in progress (ie, timeout) */
            crc = avago_spico_int(aapl, sbus_addr, 0x2, 0);
            crc_status = crc == 1;
        }
        /* else not needed as it's covered by check_ip_type above, which returns upon failure */
        break;

    default: break;
    }

    running = aapl_get_spico_running_flag(aapl,sbus_addr);
    if( crc_status && return_code == aapl->return_code && running )
    {
        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "SBus %s, CRC passed.\n", aapl_addr_to_str(sbus_addr));
        return 1;
    }
    aapl_fail(aapl, __func__, __LINE__, "SBus %s, CRC failed. CRC interrupt returned 0x%04x. Running: %d.\n", aapl_addr_to_str(sbus_addr), crc, running);
    return 0; /* fail */
}

/** @brief   Verifies the CRC checksum of the firmware images in <i>addr_list</i>. */
/** @return  Returns TRUE if all checksums are valid, FALSE if not. */
/**          Individual interrupt status values are written into the results field of addr_list. */
BOOL avago_parallel_serdes_crc(
    Aapl_t *aapl,            /**< Pointer to Aapl_t structure */
    Avago_addr_t *addr_list) /**< SerDes addresses to check */
{
    int return_code = aapl->return_code;
    BOOL crc_pass;
    Avago_addr_t *addr_struct;
    const uint CRC_OK = 0;

    if( aapl->capabilities & AACS_SERVER_NO_CRC ) /* Simulation */
    {
        for( addr_struct = addr_list; addr_struct; addr_struct = addr_struct->next )
        {
            uint addr = avago_struct_to_addr(addr_struct);
            /* Provide a little stimulation to insure that SPICO */
            /* interrupts are enabled before continuing. */
            int i = 0, last_pc = 0;
            for( i = 0; i < 200; i++ )
            {
                int pc = avago_sbus_rd(aapl, addr, 0x25);
                if( pc == last_pc && (avago_sbus_rd(aapl, addr, 0x4) & 0x30000) == 0 )
                    break;
                last_pc = pc;
            }
            addr_struct->results = CRC_OK;
            aapl_set_spico_running_flag(aapl, addr, 1);      /* Set the running flag to on */
        }
        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "CRC skipped due to aapl->capabilities AACS_SERVER_NO_CRC set. CRC passed.\n");
        return TRUE; /* skip CRC checking */
    }

    /* Execute on SerDes. */
    for( addr_struct = addr_list; addr_struct; addr_struct = addr_struct->next )
    {
        uint addr = avago_struct_to_addr(addr_struct);
        aapl_set_spico_running_flag(aapl, addr, 1);      /* Set the running flag to on */
    }

    if( addr_list->sbus == 0xfd )   /* SBus Master upload */
    {
        crc_pass = TRUE;
        for( addr_struct = addr_list; addr_struct; addr_struct = addr_struct->next )
        {
            uint addr = avago_struct_to_addr(addr_struct);
            crc_pass &= 1 == avago_spico_int(aapl, addr, 2, 0);  /* Execute CRC. */
        }
    }
    else
        crc_pass = 1 == avago_parallel_serdes_int(aapl, addr_list, 0x3c, 0) && addr_list->results == CRC_OK;

    if( crc_pass && return_code == aapl->return_code )
    {
        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "CRC passed.\n");
        return TRUE;
    }

    /* Log failures here: */
    for( addr_struct = addr_list; addr_struct; addr_struct = addr_struct->next )
    {
        if( addr_struct->results != CRC_OK )
            aapl_fail(aapl, __func__, __LINE__, "CRC failed: SBus %s returned %d.\n", aapl_addr_to_str(avago_struct_to_addr(addr_struct)), addr_struct->results);
    }
    return FALSE;
}

/** @brief   Resets a SerDes SPICO processor. */
/** @details Supports broadcast addresses. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_spico_reset(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr)     /**< [in] SBus slice address. */
{
    int return_code = aapl->return_code;
    if (!aapl_check_process(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28))
        return -1;
    aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "Executing SPICO reset on %s\n", aapl_addr_to_str(sbus_addr));

    if (aapl->spico_int_only && aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) )
    {
        avago_spico_int(aapl, sbus_addr, 0x39, 0); /* have SBM reset the serdes */
        return return_code == aapl->return_code ? 0 : -1;
    }
    if( aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) )
    {
        /* ADDR  7/0x07    sbus_clk  RESET REG RESERVED */
        /* REG   0      1  RW        GLOBAL_RESET     Resets the SerDes */
        /* REG   1      0  RW        SPICO_ENABLE */
        /* REG   4      1  RW        SPICO_CLK_GATE_DISABLE  forces clock going to processor to always run */
        avago_sbus_wr(aapl, sbus_addr, 0x07, 0x00000011); /* Reset high */
        /* Need 100 refclk cycles between these! */
        avago_sbus_wr(aapl, sbus_addr, 0x07, 0x00000010); /* Reset low */
        avago_sbus_wr(aapl, sbus_addr, 0x0b, 0x000c0000); /* Enable ECC */
        avago_sbus_wr(aapl, sbus_addr, 0x0c, 0xc0000000); /* Clear any ECC errors that occurred previously */
        avago_sbus_wr(aapl, sbus_addr, 0x07, 0x00000002); /* Enable SPICO */
        avago_sbus_wr(aapl, sbus_addr, 0x08, 0x00000000); /* Enable interrupts */
    }
    /* TRUE forces error message if no match: */
    else if( aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, TRUE, 1, AVAGO_SPICO) )
    {
        avago_sbus_wr(aapl, sbus_addr, 0x01, 0x000000c0); /* Reset high */
        avago_sbus_wr(aapl, sbus_addr, 0x01, 0x00000040); /* Reset low */
        avago_sbus_wr(aapl, sbus_addr, 0x16, 0x000c0000); /* Enable ECC */
        avago_sbus_wr(aapl, sbus_addr, 0x01, 0x00000140); /* Enable SPICO */
    }
    return return_code == aapl->return_code ? 0 : -1;
}

#if AAPL_ENABLE_FILE_IO

/** @brief   Load a valid Avago-supplied ROM image into memory. */
/** @details Caller should call aapl_free(aapl, rom_ptr, __func__) */
/**          when finished with the ROM image. */
/** */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_load_rom_from_file(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure */
    const char *filename,   /**< Full path to a valid Avago-supplied ROM image */
    int *rom_size,          /**< [out] Address to receive length of image */
    int **rom_ptr)          /**< [out] Address to receive ROM image */
{
    int alloc_size;
    int *rom, addr = 0;
    char mem_buffer[6];
    FILE *file = NULL;

    if( filename )
        file = fopen(filename, "r");  /* Open file as read only */

    *rom_size = 0;
    *rom_ptr = 0;
    if( !file )                         /* Alert user to any read issues */
        return aapl_fail(aapl, __func__, __LINE__, "## ERROR opening file %s: %s\n",filename,strerror(errno));

    fseek(file, 0, SEEK_END);       /* obtain file size: */
    alloc_size = ftell(file) / 4;   /* number of words (three ASCII characters plus newline) */
    rewind(file);
    if( alloc_size < 50 )            /* Sanity check */
    {
        fclose(file);
        return aapl_fail(aapl, __func__, __LINE__, "## ERROR: invalid file: %s\n",filename);
    }

    /* allocate memory to contain the whole file: */
    /* 7 extra words needed to prevent memory access errors, as writes are done 3 bytes at a time. */
    alloc_size += 7;
    rom = (int*) aapl_malloc(aapl, sizeof(int) * alloc_size, filename);
    if( !rom )
    {
        fclose(file);       /* couldn't malloc memory, so close file and return */
        return -1;          /* aapl_malloc will have already set the return code */
    }

    while( fgets(mem_buffer, 6, file) && addr < alloc_size ) /* read line from file */
    {
        char *ptr;
        rom[addr] = aapl_strtol(mem_buffer, &ptr, 16);   /* convert to hex */
        /* Error if not three hex digits followed by "\n" or "\r\n" */
        if( ptr != mem_buffer+3 && (ptr != mem_buffer+4 || mem_buffer[3] != '\r') )
        {
            fclose(file);
            free(rom);
            return aapl_fail(aapl, __func__, __LINE__, "## ERROR: %s has invalid file format\n",filename);
        }
        addr ++;
    }
    *rom_size = addr;  /* Adjust returned size for presence of any '\r' chars */

    /* Insure that extra words are zeros. */
    while( addr < alloc_size )
        rom[addr++] = 0;

    fclose(file);
    *rom_ptr = rom;     /* Return valid value */
    return 0;
}

/** @brief Search for existing swap file. */
/** @details The swap name is assumed to have the same path as the SerDes */
/**          ROM file, but with the ".rom" suffix replaced with ".swap". */
/** @return Name of existing swap file, or NULL if no swap file. */
/**         A non-NULL return value should be released using aapl_free(). */
char *avago_find_swap_file(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure */
    const char *filename)   /**< Path to a valid Avago-supplied SerDes ROM image */
{
    uint name_len = strlen(filename);
    char *swap_file = (char *)aapl_malloc(aapl, name_len + 8, __func__);
    if( swap_file )
    {
        FILE *file;
        strcpy(swap_file, filename);
        /* Remove trailing .rom: */
        if( name_len >= 4 && 0 == strcmp(swap_file + name_len - 4,".rom") )
            name_len -= 4;
        strcpy(swap_file + name_len, ".swap"); /* Append ".swap" */
        file = fopen(swap_file, "r");  /* Open file as read only */
        if( file )
        {
            fclose(file);
            return swap_file;
        }
        aapl_free(aapl, swap_file, __func__);
    }
    return NULL;
}

/** @brief   Upload SPICO machine code in parallel to all SPICOs in list and check CRC. */
/** @details Works for broadcast and individual addresses. */
/** @return  On success, returns the number of words in the ROM image. */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_parallel_spico_upload_file(
    Aapl_t *aapl,             /**< Pointer to Aapl_t structure */
    Avago_addr_t *addr_list,  /**< List of Sbus address to upload to */
    BOOL ram_bist,            /**< Perform spico_ram_bist prior to upload */
    const char *filename)     /**< Full path to a valid Avago-supplied ROM image */
{
    int return_code = aapl->return_code;
    int rom_size = -1, *rom;

    if( avago_load_rom_from_file(aapl, filename, &rom_size, &rom) == 0 )
    {
        aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "Uploading SPICO machine code: %s\n", filename);
        if( avago_parallel_spico_upload(aapl, addr_list, ram_bist, rom_size, rom) == 0 )
        {
            /* Check if a swap image exists for this firmware revision and */
            /* build, if one exists upload the swap image to the device. */
            char *swap_file = avago_find_swap_file(aapl, filename);
            if( swap_file )
            {
                int swap_size, *swap;
                if( avago_load_rom_from_file(aapl, swap_file, &swap_size, &swap) == 0 )
                {
                    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "Uploading swap image: %s\n", swap_file);
                    if( avago_spico_upload_swap_image(aapl, avago_struct_to_addr(addr_list), swap_size, swap) < 0 )  /* TODO */
                        aapl_fail(aapl, __func__, __LINE__, "CRC of swap image failed (%s)\n.",swap_file);
                    aapl_free(aapl, swap, __func__);
                }
                aapl_free(aapl, swap_file, __func__);
            }
        }
        aapl_free(aapl, rom, __func__);
    }
    return return_code == aapl->return_code ? rom_size : -1;
}


/** @brief   Upload SPICO machine code and check CRC. */
/** @details Works for broadcast and individual addresses. */
/** */
/** @return  On success, returns the number of 10 bit words in the ROM image. */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_spico_upload_file(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure */
    uint sbus_addr,         /**< Sbus address of device to upload to */
    BOOL ram_bist,          /**< Perform spico_ram_bist prior to upload */
    const char *filename)   /**< Full path to a valid Avago-supplied ROM image */
{
    int return_code = aapl->return_code;
    int rom_size = -1, *rom;

    if( avago_load_rom_from_file(aapl, filename, &rom_size, &rom) == 0 )
    {
        aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "Uploading SPICO machine code: %s\n", filename);
        if( avago_spico_upload(aapl, sbus_addr, ram_bist, rom_size, rom) == 0 )
        {
            /* Check if a swap image exists for this firmware revision and */
            /* build, if one exists upload the swap image to the device. */
            char *swap_file = avago_find_swap_file(aapl, filename);
            if( swap_file )
            {
                int swap_size, *swap;
                if( avago_load_rom_from_file(aapl, swap_file, &swap_size, &swap) == 0 )
                {
                    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "Uploading swap image: %s\n", swap_file);
                    if( avago_spico_upload_swap_image(aapl, sbus_addr, swap_size, swap) < 0 )
                        aapl_fail(aapl, __func__, __LINE__, "CRC of swap image failed (%s)\n.",swap_file);
                    aapl_free(aapl, swap, __func__);
                }
                aapl_free(aapl, swap_file, __func__);
            }
            {
                BOOL st;
                Avago_addr_t addr_struct, start, stop, next;
                avago_addr_to_struct(sbus_addr, &addr_struct);
                for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, AAPL_BROADCAST_IGNORE_LANE); st;
                     st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_IGNORE_LANE) )
                {
                    aapl->firmware_file[next.chip][next.ring][next.sbus] = (char *)aapl_malloc(aapl, strlen(filename)+1, __func__);
                    if (aapl->firmware_file[next.chip][next.ring][next.sbus])
                        strncpy(aapl->firmware_file[next.chip][next.ring][next.sbus], filename, strlen(filename)+1);
                    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Uploaded firmware to %s from file: %s.\n", aapl_addr_to_str(avago_struct_to_addr(&next)), filename);
                }
            }
        }
        aapl_free(aapl, rom, __func__);
    }
    return return_code == aapl->return_code ? rom_size : -1;
}

#endif /* AAPL_ENABLE_FILE_IO */


/** @brief   Check to see if any uploads are in progress, and waits for them to complete */
/** */
void avago_twi_wait_for_complete(
    Aapl_t *aapl,    /**< Pointer to Aapl_t structure */
    uint sbus_addr)  /**< Sbus address of device to check for current upload */
{
    if( !aapl_check_process(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28) ||
         aapl_check_broadcast_address(aapl, sbus_addr, __func__, __LINE__, TRUE) ||
        !aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, TRUE, 2, AVAGO_SBUS_CONTROLLER)  ) return;

    /* is this SBus controller 06 (TWI master)? */
    if (aapl_get_ip_rev(aapl, avago_make_sbus_controller_addr(sbus_addr)) == 0xbf)
    {
        int initial = avago_sbus_rmw(aapl, sbus_addr, 0x40, 1<<13, 1<<13); /* set bit 13 */
        int twi_status = avago_sbus_rd(aapl, sbus_addr, 0x81);
        aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "TWI status: 0x%08x.\n", twi_status);

        if (((twi_status >> 18) & 0x3) == 0x1)
        {
            int loops;
            aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "SPICO upload in progress on %s. Waiting for completion (0x%08x).\n",  aapl_addr_to_str(sbus_addr), twi_status);
            for( loops = 0; loops <= AAPL_SPICO_UPLOAD_WAIT_TIMEOUT; loops++ )
            {
                ms_sleep(1);
                twi_status = avago_sbus_rd(aapl, sbus_addr, 0x81);
                if (((twi_status >> 18) & 0x3) != 0x1) break;
            }
            if (loops>= AAPL_SPICO_UPLOAD_WAIT_TIMEOUT)
                aapl_fail(aapl, __func__, __LINE__, "Timed out after %d loops while waiting for TWI upload to complete (0x%02x).\n", loops, twi_status);
            aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "Waited %d loops for pending upload to complete (0x%02x).\n" , loops, twi_status);
        }
        avago_sbus_wr(aapl, sbus_addr, 0x40, initial);
        if (((twi_status >> 18) & 0x3) == 0x2)
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "TWI status indicates failure: 0x%08x.\n", twi_status);
    }
}


/** @brief   Check to see if any uploads are in progress, and waits for them to complete */
/** */
void avago_spico_wait_for_upload(
    Aapl_t *aapl,    /**< Pointer to Aapl_t structure */
    uint sbus_addr)  /**< Sbus address of device to check for current upload */
{
    uint imem_cntl = 0;
    uint imem_cntl_orig = 0;
    uint imem_cntl_orig_0xa = 0;
    uint loops;

    if( !aapl_check_process(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28) ||
         aapl_check_broadcast_address(aapl, sbus_addr, __func__, __LINE__, TRUE) ||
        !aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, TRUE, 4, AVAGO_SERDES, AVAGO_SPICO, AVAGO_M4, AVAGO_P1)  ) return;

    if (aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1))
    {
        if (aapl_get_process_id(aapl, sbus_addr) != AVAGO_TSMC_28 ) return; /* For 16nm bit 30 is not readable, so just return */

        imem_cntl = avago_sbus_rd(aapl, sbus_addr, 0x00); /* this potentially could cause Xs in verilog if the read is done after a firmware upload, then it will read the last IMEM address + 1, causing Xs to be read out */
        imem_cntl_orig = imem_cntl;
        imem_cntl_orig_0xa = avago_sbus_rd(aapl, sbus_addr, 0x0a);
        if (imem_cntl & 0x40000000)  /* is IMEM cntl en set? */
        {
            aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "SPICO upload in progress on %s. Waiting for completion (0x%08x).\n",  aapl_addr_to_str(sbus_addr), imem_cntl);
            for( loops = 0; loops <= AAPL_SPICO_UPLOAD_WAIT_TIMEOUT; loops++ )
            {
                ms_sleep(1);
                if ((avago_sbus_rd(aapl, sbus_addr, 0x07) & 0x02) || !(imem_cntl & 0x40000000)) /* wait for enable, or IMEM cntl to go low */
                    break;
                imem_cntl = avago_sbus_rd(aapl, sbus_addr, 0x00);
                if (loops > 10 && imem_cntl == imem_cntl_orig && imem_cntl_orig_0xa == avago_sbus_rd(aapl, sbus_addr, 0x0a)) break; /* break if we've waiting more than 10ms and nothing has changed */
            }
            if (loops>= AAPL_SPICO_UPLOAD_WAIT_TIMEOUT)
                aapl_fail(aapl, __func__, __LINE__, "Timed out after %d loops while waiting for SPICO upload to complete (0x%02x 0x%08x).\n",
                    loops, avago_sbus_rd(aapl, sbus_addr, 0x07), imem_cntl);
            aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "Waited %d loops for pending upload to complete (0x%02x 0x%08x).\n" ,
                loops, avago_sbus_rd(aapl, sbus_addr, 0x07), imem_cntl);
        }
    }
    else if (aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, AVAGO_SPICO))
    {
        imem_cntl = avago_sbus_rd(aapl, sbus_addr, 0x01);
        imem_cntl_orig = imem_cntl;
        imem_cntl_orig_0xa = avago_sbus_rd(aapl, sbus_addr, 0x0a);
        if (imem_cntl & 0x200)  /* is IMEM cntl en set? */
        {
            aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "SPICO upload in progress on %s. Waiting for completion (0x%08x).\n",  aapl_addr_to_str(sbus_addr), imem_cntl);
            for( loops = 0; loops <= AAPL_SPICO_UPLOAD_WAIT_TIMEOUT; loops++ )
            {
                ms_sleep(1);
                if ((imem_cntl & 0x100) || !(imem_cntl & 0x200)) /* wait for enable, or IMEM cntl to go low */
                    break;
                imem_cntl = avago_sbus_rd(aapl, sbus_addr, 0x01);
                if (loops > 10 && imem_cntl == imem_cntl_orig && imem_cntl_orig_0xa == avago_sbus_rd(aapl, sbus_addr, 0x0a)) break; /* break if we've waiting more than 10ms and nothing has changed */
            }
            if (loops>= AAPL_SPICO_UPLOAD_WAIT_TIMEOUT)
                aapl_fail(aapl, __func__, __LINE__, "Timed out after %d loops while waiting for SPICO upload to complete (0x%02x 0x%08x).\n",
                    loops, avago_sbus_rd(aapl, sbus_addr, 0x01), imem_cntl);
            aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "Waited %d loops for pending upload to complete (0x%02x 0x%08x).\n" ,
                loops, avago_sbus_rd(aapl, sbus_addr, 0x01), imem_cntl);
        }
    }
}

/** @cond INTERNAL */

static void serdes_spico_halt_fix(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] Device address number. */
    int initial_value_0x20)
{
    if( aapl_get_process_id(aapl, addr) != AVAGO_TSMC_07
        && aapl_get_lsb_rev(aapl, addr) < 5                     /* A susceptible version */
        && (avago_sbus_rd(aapl, addr, 0x27) & 0x3ff) == 0x142 ) /* and on adi #2 instruction */
    {
        avago_sbus_wr(aapl, addr, 0x20, initial_value_0x20 | 0x3);  /* single step */
        if ((avago_sbus_rd(aapl, addr, 0x27) & 0x3ff) == 0x047)     /* if on rti instruction */
        {
            uint addr_0x00;
            aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "Stepping processor and clearing HDW interrupt. %04x %08x %08x\n", avago_sbus_rd(aapl, addr, 0x25), avago_sbus_rd(aapl, addr, 0x27), avago_sbus_rd(aapl, addr, 0x28));
            avago_sbus_wr(aapl, addr, 0x20, initial_value_0x20 | 0x3); /* single step past rti */
            addr_0x00 = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB_DIRECT, 0x00);
            avago_serdes_mem_wr(aapl, addr, AVAGO_LSB_DIRECT, 0x00, addr_0x00 | 0x2); /* set CLEAR_INTERRUPT_HDW_CORE */
        }
    }
}

/** @brief   Safely halts the SPICO processor. */
/** @details Checks that the processor did not halt on the clear interrupt */
/**          command which is right before the rti. The two commands must be */
/**          atomic.  If we stopped between them, we need to step the */
/**          processor past the RTI and then clear the interrupts again so */
/**          that any pending hardware interrupts will be seen. */
/** @details The halt/resume functions can be safely nested: */
/**          It's safe to call halt when already halted, and resume will only */
/**          resume if SPICO was running prior to the corresponding halt. */
/** @return  A SPICO run state variable to pass to avago_spico_resume(). */
/** @see avago_spico_resume(). */
uint avago_spico_halt(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Device address number. */
{
    uint initial_value = 0;
    uint spico_running = aapl_get_spico_running_flag(aapl, addr);

    if( !aapl_check_process(aapl, addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28) ||
        !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 4, AVAGO_SPICO, AVAGO_SERDES, AVAGO_M4, AVAGO_P1)  ) return 0;

    if ( (aapl_get_ip_type(aapl, addr) == AVAGO_SERDES) || (aapl_get_ip_type(aapl, addr) == AVAGO_M4)
                                                        || (aapl_get_ip_type(aapl, addr) == AVAGO_P1) )
    {
        initial_value = avago_sbus_rmw(aapl, addr, 0x20, 0x01, 0x01); /* single step SPICO to halt it */
        if( 0 == (initial_value & 0x01))                           /* If was running */
            serdes_spico_halt_fix(aapl, addr, initial_value);

        /* When the P1 processor pauses with nothing to do, the clocks are */
        /* stopped to save power.  However, without the clock running, sbus */
        /* memory reads don't work.  We can't force the clock to */
        /* always run as processor memory accesses use clock stopping to */
        /* sync with memory.  So, we must both stop the processor and keep */
        /* the clock running for Sbus access to memory. */
        if( aapl_get_ip_type(aapl, addr) == AVAGO_P1 ) /* Applies to P1 rev 01 only. */
        {
            /* Lower reset if it's set, set clk gate disable if not set: */
            uint reset_status = avago_sbus_rd(aapl, addr, 0x07);
            if( (reset_status & 0x01) || !(reset_status & 0x10) )
                /*printf("Do reg 7 write: 0x%x\n", (reset_status & ~1) | 0x10), */
                avago_sbus_wr(aapl, addr, 0x07, (reset_status & ~1) | 0x10);
            initial_value |= reset_status << 16;
        }
    }
    else if (aapl_get_ip_type(aapl, addr) == AVAGO_SPICO)
    {
        initial_value = avago_sbus_rmw(aapl, addr, 0x5, 0x01, 0x03); /* single step SPICO to halt it */
        /* Unknown if this is needed: */
        /*if( 0 == (initial_value & 0x01))                           // If was running */
        /*    serdes_spico_halt_fix(aapl, addr, initial_value); */
    }
    /*aapl_set_spico_running_flag(aapl, addr, AVAGO_SPICO_HALT); */
    aapl_set_spico_running_flag(aapl, addr, 0);
    return initial_value | (spico_running << 31);
}


/** @brief   Resume the SPICO run state after avago_spico_halt(). */
/** @details The halt/resume functions can be safely nested: */
/**          It's safe to call halt when already halted, and resume will only */
/**          resume if SPICO was running prior to the corresponding halt. */
/** @return  0 on success, -1 on error. */
/** @see     avago_spico_halt(). */
int avago_spico_resume(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint addr,              /**< [in] Device address number. */
    uint spico_run_state)   /**< [in] Value returned from halt function. */
{
    if( !aapl_check_process(aapl, addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28) ||
        !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 4, AVAGO_SPICO, AVAGO_SERDES, AVAGO_M4, AVAGO_P1)  ) return 0;

    if( aapl_get_ip_type(aapl, addr) == AVAGO_P1 ) /* Applies to P1 rev 01 only. */
    {
        /* restore reset, clk gate: */
        int reset_status = (spico_run_state >> 16) & 0x7fff;
        if( (reset_status & 0x01) || !(reset_status & 0x10) )
            /*printf("Do reg 7 write restore: 0x%x\n", reset_status), */
            avago_sbus_wr(aapl, addr, 0x07, reset_status);
    }

    if( 0 == (spico_run_state & 0x01) ) /* If was running */
    {
        if ( (aapl_get_ip_type(aapl, addr) == AVAGO_SERDES) || (aapl_get_ip_type(aapl, addr) == AVAGO_M4)
                                                            || (aapl_get_ip_type(aapl, addr) == AVAGO_P1) )
        {
            serdes_spico_halt_fix(aapl, addr, spico_run_state);
            avago_sbus_wr(aapl, addr, 0x20, spico_run_state); /* resume processor */
        }
        if (aapl_get_ip_type(aapl, addr) == AVAGO_SPICO)
        {
            /*serdes_spico_halt_fix(aapl, addr, spico_run_state); */
            avago_sbus_wr(aapl, addr, 0x05, spico_run_state); /* resume processor */
        }
        if( spico_run_state & 0x80000000 ) aapl_set_spico_running_flag(aapl, addr, 1);
    }
    return 0;
}


/** @endcond */
