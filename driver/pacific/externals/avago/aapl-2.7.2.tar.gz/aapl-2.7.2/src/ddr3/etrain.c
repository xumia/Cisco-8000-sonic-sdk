/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* AAPL (ASIC and ASSP Programming Layer) diagnostic/test support. */

/** Doxygen File Header */
/** @file */
/** @brief DDR3 functions. */
/** @defgroup DDR3 DDR3 Training Functions */
/** @{ */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_DDR3_ETRAIN

/*============================================================================= */
/* AVAGO DDR3 CHANNEL TO SBUS ADDR */
/** */
/** @brief  Convert a channel number to an sbus address.  This is done by */
/** walking through each sbus device looking for eTrain address macros. */
/** */
/** @param  aapl       Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @param  channel    DDR3 channel number  */
/** */
/** @return Sbus address of the first DDR3 device in the channel.  If the */
/**         channel is not valid 0 is return. */
int avago_ddr3_channel_to_sbus_addr(Aapl_t *aapl, uint spico_addr, uint channel)
{
  uint addr;
  uint current_channel = -1;
  uint max_sbus_addr = aapl_get_max_sbus_addr(aapl, spico_addr);

  for (addr = 1; addr < max_sbus_addr; addr++) {
    const char *ip_type = aapl_ip_type_to_str(aapl_get_ip_type(aapl,addr));

    if (strcmp(ip_type, "DDR train") == 0) {
      current_channel += 1;
      if (current_channel == channel) {
        return addr;
      }
    }
  }

  aapl_fail(aapl, __func__, __LINE__, "Failed to find sbus address for DDR3 channel %d.\n", channel);
  return -1;
}

/*============================================================================= */
/* AVAGO DDR3 GET CHANNEL COUNT */
/** */
/** @brief  Returns the number of DDR3 channels on an sbus ring */
/** */
/** @param  aapl       Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico */
/** */
/** @return Count of channels of sbus ring */
int avago_ddr3_get_channel_count(Aapl_t *aapl, uint spico_addr)
{
  uint addr;
  uint channel_count = 0;
  uint max_sbus_addr = aapl_get_max_sbus_addr(aapl, spico_addr);

  Avago_addr_t addr_struct;
  avago_addr_to_struct(spico_addr, &addr_struct);

  for (addr = 1; addr < max_sbus_addr; addr++) {
    const char *ip_type;
    addr_struct.sbus = addr;
    ip_type = aapl_ip_type_to_str(aapl_get_ip_type(aapl, avago_struct_to_addr(&addr_struct)));

    if (strcmp(ip_type, "DDR train") == 0) {
      channel_count += 1;
    }
  }

  return channel_count;
}


/*============================================================================= */
/* AVAGO DDR3 SET PARAMETER */
/** */
/** @brief  Sets a ddr3 training parameter */
/** */
/** @param  aapl       Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @param  param      Parameter number to set */
/** @param  value      Parameter value to set */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_ddr3_set_parameter(Aapl_t *aapl, uint spico_addr, Avago_ddr3_parameter_t param, uint value)
{
  uint result;
  uint status;

  /* Set the parameter number */
  result = avago_spico_int(aapl, spico_addr, 0x3b, param);
  status = result >> 16;

  if (status == 0x7fff) {
    aapl_fail(aapl, __func__, __LINE__, "Illegal ddr3 parameter number, %d.\n", param);
    return -1;
  }

  /* Set the parameter value */
  avago_spico_int(aapl, spico_addr, 0x3c, value);

  return 0;
}


/*============================================================================= */
/* AVAGO DDR3 GET PARAMETER */
/** */
/** @brief  Gets a ddr3 training parameter */
/** */
/** @param  aapl       Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @param  param      Parameter number to get */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_ddr3_get_parameter(Aapl_t *aapl, uint spico_addr, Avago_ddr3_parameter_t param)
{
  uint result;
  uint data;
  uint status;

  /* Set the parameter number */
  result = avago_spico_int(aapl, spico_addr, 0x3a, param);
  data = result & 0xffff;
  status = result >> 16;

  if (status == 0x7fff) {
    aapl_fail(aapl, __func__, __LINE__, "Illegal ddr3 parameter number, %d.\n", param);
    return -1;
  }

  return data;
}


/*============================================================================= */
/* AVAGO DDR3 SET FREQUENCY CONFIG */
/** */
/** @brief  Configures eTrain with predefined settings for a specific DRAM */
/** frequency and cas latency */
/** */
/** @param  aapl        Aapl_t struct */
/** @param  spico_addr  sbus_address of the sbus master spico */
/** @param  freq_config Frequency configuration setting */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_ddr3_set_frequency_config(Aapl_t *aapl, uint spico_addr, Avago_ddr3_frequency_config_t freq_config)
{
  uint result;
  uint status;

  /* Set the parameter number */
  result = avago_spico_int(aapl, spico_addr, 0x39, freq_config);
  status = result >> 16;

  if (status == 0x7fff) {
    aapl_fail(aapl, __func__, __LINE__, "Illegal ddr3 frequency config, %d.\n", freq_config);
    return -1;
  }

  return 0;
}


/*============================================================================= */
/* AVAGO DDR3 FORCE TRAINING COMPLETE */
/** */
/** @brief  Forces an end to training, lower DFI_PHYUPD_REQ.  This will not */
/** interrupt the training algorith and should only be used after training */
/** completes with errors that should be ignored. */
/** */
/** @param  aapl       Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @param  channel    DDR3 channel number  */
/** */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_ddr3_force_training_complete(Aapl_t *aapl, uint spico_addr, uint channel)
{
  uint result;
  uint status;

  result = avago_spico_int(aapl, spico_addr, 0x3d, channel);
  status = result >> 16;

  if (status == 0x7fff) {
    aapl_fail(aapl, __func__, __LINE__, "Can't force training complete while training is active");
    return -1;
  }

  return 0;
}

/*============================================================================= */
/* AVAGO DDR3 TRAIN ALL CHANNELS */
/** */
/** @brief  Performs DDR3 training for each DDR3 channel on the sbus ring.   */
/** */
/** @param  aapl      Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus sbus_master spico */
/** @return TBD */
int avago_ddr3_train_all_channels(Aapl_t *aapl, uint spico_addr)
{
  int max_timeout = 5000;
  int timeout = 0;
  uint result;
  uint status;

  Avago_addr_t addr_struct;
  avago_addr_to_struct(spico_addr, &addr_struct);

  /* Start training */
  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "Begin DDR3 training (all channels) on SBus ring %d \n", addr_struct.ring);
  result = avago_spico_int(aapl, spico_addr, 0x32, 0x00);
  status = result >> 16;

  if (status == 0x7fff) {
    aapl_fail(aapl, __func__, __LINE__, "DDR3 training already in progress on SBus ring %d.\n", addr_struct.ring);
    return aapl->return_code;
  }

  /* Wait for completion */
  /*   result[0] - Training Done */
  /*   result[1] - Training Active */
  /*   result[2] - Training Error Results */
  do {
    result = avago_spico_int(aapl, spico_addr, 0x33, 0x00);
    timeout += 1;
  } while ((result & 0x03) != 0x01 && timeout <= max_timeout);

  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "DDR3 training result code: 0x%02x\n", result);

  /* Error if training timed out */
  if (timeout >= max_timeout) {
    aapl_fail(aapl, __func__, __LINE__, "DDR3 training timed out on SBus ring %d.\n", addr_struct.ring);
    return aapl->return_code;
  }

  /* Error if training active/done not in expected state */
  if ((result & 0x03) != 0x01) {
    aapl_fail(aapl, __func__, __LINE__, "DDR3 training result produced an unexpected result: %d.\n", result);
    return aapl->return_code;
  }

  /* If an error was found, check each interface and generate a description of the erorr */
  if ((result & 0x04) == 0x04) {
    int channel;
    aapl_fail(aapl, __func__, __LINE__, "DDR3 training failed for a channel on SBus ring %d.\n", addr_struct.ring);
    for (channel = 0; channel < avago_ddr3_get_channel_count(aapl, spico_addr); channel++) { 
      avago_ddr3_query_training_status(aapl, spico_addr, channel);
    }
  } else {
    aapl_log_printf(aapl, AVAGO_INFO, "", 1, "DDR3 training successfully completed on all channels on SBus ring %d \n", addr_struct.ring);
  }

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO DDR3 TRAIN CHANNEL */
/** */
/** @brief  Performs DDR3 training on a single DDR3 channel on the sbus ring.   */
/** */
/** @param  aapl      Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus sbus_master spico */
/** @param  channel   DDR3 channel number (starting from 0) */
/** @return TBD */
int avago_ddr3_train_channel(Aapl_t *aapl, uint spico_addr, uint channel)
{
  int max_timeout = 500;
  int timeout = 0;
  int result;

  Avago_addr_t addr_struct;
  avago_addr_to_struct(spico_addr, &addr_struct);

  /* Start training */
  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "Begin DDR3 training channel %d on SBus ring %d \n", channel, addr_struct.ring);
  avago_spico_int(aapl, spico_addr, 0x36, channel);

  /* Wait for completion */
  /*   result[0] - Training Done */
  /*   result[1] - Training Active */
  /*   result[2] - Training Error Results */

  do {
    result = avago_spico_int(aapl, spico_addr, 0x33, 0x00);
    timeout += 1;
  } while ((result & 0x01) != 1 && timeout <= max_timeout);

  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "DDR3 channel %d training result code: 0x%02x\n", channel, result);

  /* Error if training timed out */
  if (timeout >= max_timeout) {
    aapl_fail(aapl, __func__, __LINE__, "DDR3 training timed out on SBus ring %d.\n", addr_struct.ring);
    return aapl->return_code;
  }

  /* Error if training active/done not in expected state */
  if ((result & 0x03) != 0x01) {
    aapl_fail(aapl, __func__, __LINE__, "DDR3 training result produced an unexpected result: %d.\n", result);
    return aapl->return_code;
  }

  /* If an error was found, check each interface and generate a description of the erorr */
  if ((result & 0x04) == 0x04) {
    aapl_fail(aapl, __func__, __LINE__, "DDR3 training failed for a channel on SBus ring %d.\n", addr_struct.ring);
    avago_ddr3_query_training_status(aapl, spico_addr, channel);
  } else {
    aapl_log_printf(aapl, AVAGO_INFO, "", 1, "DDR3 training successfully completed on channel %d on SBus ring %d \n", channel, addr_struct.ring);
  }

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO DDR3 QUERY CHANNEL TRAINING STATUS */
/** */
/** @brief  Creates a textual output of the training results for each ddr3 */
/** channel on the sbus ring */
/** */
/** @param  aapl      Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @return TBD */
int avago_ddr3_query_training_status(Aapl_t *aapl, uint spico_addr, uint channel)
{
  int status = avago_spico_int(aapl, spico_addr, 0x37, channel);
  char * desc = avago_ddr3_training_error_desc(status);
  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "DDR3 training status description for channel %d: %d (%s)\n", channel, status, desc);

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO DDR3 TRAINING ERROR DESC */
/** */
/** @brief  Returns a textual description for a training error code */
/** */
/** @param  result    Error code value */
/** @return Error code description */
char * avago_ddr3_training_error_desc(int result)
{
  char * desc;
  switch(result) {
    case 0:   { desc = (char *) "NO_ERRORS";                                             break; }
    case 100: { desc = (char *) "ERROR_TRAINING_MODE_EN_TIMEOUT";                        break; }
    case 101: { desc = (char *) "ERROR_CHANGE_SPEED_TIMEOUT";                            break; }
    case 102: { desc = (char *) "ERROR_REFRESH_ACTIVE_TIMEOUT";                          break; }
    case 103: { desc = (char *) "ERROR_MR_LOAD_TIMEOUT";                                 break; }
    case 104: { desc = (char *) "ERROR_DRAM_INIT_ACTIVE_TIMEOUT";                        break; }
    case 105: { desc = (char *) "ERROR_WRITE_READ_COMPARE_TIMEOUT";                      break; }
    case 106: { desc = (char *) "ERROR_WRITE_READ_COMPARE_ERRORS_FOUND";                 break; }
    case 107: { desc = (char *) "ERROR_READ_COMPARE_TIMEOUT";                            break; }
    case 108: { desc = (char *) "ERROR_READ_COMPARE_ERRORS_FOUND";                       break; }
    case 109: { desc = (char *) "ERROR_WRITE_READ_COMPARE_LOOP_ERROR";                   break; }
    case 200: { desc = (char *) "ERROR_WRLVL_VALUE_NOT_FOUND";                           break; }
    case 201: { desc = (char *) "ERROR_WRLVL_TRN_ACTIVE_TIMEOUT";                        break; }
    case 202: { desc = (char *) "ERROR_WRLVL_MODE_REG_DRAM_EN";                          break; }
    case 203: { desc = (char *) "ERROR_WRLVL_MODE_REG_DRAM_DISABLE";                     break; }
    case 300: { desc = (char *) "ERROR_RDLVL_TRN_ACTIVE_TIMEOUT";                        break; }
    case 301: { desc = (char *) "ERROR_RDLVL_VALUE_NOT_FOUND";                           break; }
    case 302: { desc = (char *) "ERROR_RDLVL_FINE_TRN_ACTIVE_TIMEOUT";                   break; }
    case 303: { desc = (char *) "ERROR_RDLVL_FINE_VALUE_NOT_FOUND";                      break; }
    case 400: { desc = (char *) "ERROR_PBDS_STROBE_DELAY_LOAD_TIMEOUT";                  break; }
    case 401: { desc = (char *) "ERROR_PBDS_DATA_DELAY_LOAD_TIMEOUT";                    break; }
    case 402: { desc = (char *) "ERROR_PBDS_WRITE_READ_TIMEOUT";                         break; }
    case 403: { desc = (char *) "ERROR_PBDS_READ_TIMEOUT";                               break; }
    case 404: { desc = (char *) "ERROR_PBDS_EXIT_REFRESH_ACTIVE_TIMEOUT";                break; }
    case 410: { desc = (char *) "ERROR_PBDS_DM_WRITE_READ_TIMEOUT";                      break; }
    case 411: { desc = (char *) "ERROR_PBDS_DM_WRITE_READ_COMPARE_ERRORS_FOUND_WO_DM";   break; }
    case 412: { desc = (char *) "ERROR_PBDS_DM_WRITE_READ_COMPARE_ERRORS_FOUND_WITH_DM"; break; }
    case 413: { desc = (char *) "ERROR_PBDS_DM_EXIT_REFRESH_ACTIVE_TIMEOUT";             break; }
    case 500: { desc = (char *) "ERROR_EXIT_SELF_REFRESH_ACTIVE_TIMEOUT";                break; }
    case 501: { desc = (char *) "ERROR_EXIT_READ_WRITE_ACTIVE_TIMEOUT";                  break; }
    case 502: { desc = (char *) "ERROR_EXIT_REFRESH_ACTIVE_TIMEOUT";                     break; }
    case 503: { desc = (char *) "ERROR_EXIT_HALF_FREQUENCY";                             break; }
    default:  { desc = (char *) "Unknown error";                                         break; }
  }
  return desc;
}

/*============================================================================= */
/* AVAGO DDR3 DIAGNOSTICS */
/** */
/** @brief  Perform diagnostics on all DDR3 channels */
/** */
/** @param  aapl      Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @return aapl->return_code */
int avago_ddr3_diagnostics(Aapl_t *aapl, uint spico_addr)
{
  int channel;

  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "\n");
  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "========== Begin DDR3 diagnostics ==========\n");

  /* Reset all sbus devices */
  avago_ddr3_reset_sbus(aapl, spico_addr);

  /* Report spico status */
  avago_ddr3_report_spico_status(aapl, spico_addr);

  for (channel = 0; channel <= 8; channel++) { 
    avago_ddr3_channel_diagnostics(aapl, spico_addr, channel);
  }
  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "========== Completed DDR3 diagnostics ==========\n");

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO DDR3 CHANNEL DIAGNOSTICS */
/** */
/** @brief  Perform diagnostics on a single DDR3 channel */
/** */
/** @param  aapl      Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @param  channel   DDR3 interface number */
/** @return This function will try to train the channel (assumes firmware is */
/**         uploaded and memory controller is initialized).  Once training has */
/**         completed, the CTC is run to verify that traffic can successfully be sent */
/**         between the channel and DRAM.  If any of those steps fail, training values */
/**         are hardcoded and CTC patterns run again. */
int avago_ddr3_channel_diagnostics(Aapl_t *aapl, uint spico_addr, uint channel)
{
  Avago_ddr3_training_values_t *training_values;
  int end_error;
  int start_error = aapl->return_code;

  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "\n");
  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "========== Begin channel %d diagnostics ==========\n", channel);


  /* Train the channel using spico firmware */
  avago_ddr3_train_channel(aapl, spico_addr, channel);

  /* Run patterns using trainning block */
  /* TODO: Adds pattern testing here TODO: */

  /* Report the current training values */
  training_values = avago_ddr3_training_values_construct(aapl);
  avago_ddr3_get_training_values(aapl, spico_addr, channel, training_values);
  avago_ddr3_report_training_values(aapl, spico_addr, channel, training_values);
  avago_ddr3_training_values_destruct(aapl, training_values);

  /* Report the contents of each device in channel */
  avago_ddr3_sbus_dump_channel_devices(aapl, spico_addr, channel);

  /* If the channel failed, try running some debug  */
  end_error = aapl->return_code;
  if (end_error != start_error) {
    aapl_log_printf(aapl, AVAGO_INFO, "", 1, "\n");
    aapl_log_printf(aapl, AVAGO_INFO, "", 1, "DDR3 training failed for channel %d.  Beginning debug.\n", channel);

    /* Hardcode training codes */
    aapl_log_printf(aapl, AVAGO_INFO, "", 1, "\n");
    aapl_log_printf(aapl, AVAGO_INFO, "", 1, "Forcing training values\n");
    training_values = avago_ddr3_training_values_construct(aapl);
    training_values->write_leveling[0] = 0x0c;
    training_values->write_leveling[1] = 0x0c;
    training_values->write_leveling[2] = 0x0c;
    training_values->write_leveling[3] = 0x0c;
    training_values->read_gate_delay[0] = 0x08;
    training_values->read_gate_delay[1] = 0x08;
    training_values->read_gate_delay[2] = 0x08;
    training_values->read_gate_delay[3] = 0x08;

    avago_ddr3_set_training_values(aapl, spico_addr, channel, training_values);
    avago_ddr3_report_training_values(aapl, spico_addr, channel, training_values);
    avago_ddr3_training_values_destruct(aapl, training_values);

  }

  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "========== Completed channel %d diagnostics ==========\n", channel);

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO DDR3 RESET SBUS */
/** */
/** @brief  Perform an sbus reset on all devices on sbu ring */
/** */
/** @param  aapl      Aapl_t struct */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @return TBD */
int avago_ddr3_reset_sbus(Aapl_t *aapl, uint spico_addr)
{
  /* Change sbus address to 0xff (all devices on ring) */
  Avago_addr_t addr_struct;
  avago_addr_to_struct(spico_addr, &addr_struct);
  addr_struct.sbus = 0xff;

  avago_sbus_reset(aapl, avago_struct_to_addr(&addr_struct), 1);

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO DDR3 REPORT SPICO STATUS */
/** */
/** @brief Report Spico firmware version */
/** */
/** @param aapl        aapl struct */
/** @param spico_addr   sbus address of the sbus master spico for the channel */
/** @return  TBD */
void avago_ddr3_report_spico_status(Aapl_t *aapl, uint spico_addr)
{
  Avago_spico_status_t state;
  avago_spico_status(aapl, spico_addr, 0, &state);

  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "SPICO Revision: 0x%04x\n", state.revision);
  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "SPICO Build ID: 0x%04x\n", state.build);
  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "SPICO Enabled: 0x%04x\n", state.enabled);
  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "\n");
}


/*============================================================================= */
/* AVAGO DDR3 TRAINING VALUES CONSTRUCT */
/** */
/** @brief   Creates a Avago_ddr3_training_values_t struct */
/** */
/** @param   aapl      Aapl_t struct */
/** @return  Avago_ddr3_training_values_t struct */
/** @details mallocs the memory for a Avago_ddr3_training_values_t and returns a pointer */
/**          to that memory location.    */
Avago_ddr3_training_values_t *avago_ddr3_training_values_construct(Aapl_t *aapl)
{
  Avago_ddr3_training_values_t * values;
  size_t bytes = sizeof(Avago_ddr3_training_values_t);

  values = (Avago_ddr3_training_values_t *) aapl_malloc(aapl, bytes, "Avago_ddr3_training_values_t struct");
  if (! values) {
    return(NULL);
  }
  memset(values, 0, sizeof(*values)); /* set all bytes to zero */

  return values;
} 


/*============================================================================= */
/* AVAGO DDR3 TRAINING VALUES DESTRUCT */
/** */
/** @brief Destroys the provided Avago_ddr3_training_values_t struct */
/** @param aapl aapl struct */
/** @param values struct to destroy */
/** @return void */
/** @details Frees the memory pointed to by the provided Avago_ddr3_training_values_t struct. */
void avago_ddr3_training_values_destruct(Aapl_t *aapl, Avago_ddr3_training_values_t *values)
{    
  aapl_free(aapl, values, "Avago_ddr3_training_values_t struct");
} 


/*============================================================================= */
/* AVAGO DDR3 GET TRAINING VALUES */
/** */
/** @brief Retrieves the training values for a DDR3 channel */
/** */
/** @param  aapl      aapl struct */
/** @param  spico_addr spico_addr of the sbus master spico */
/** @param  channel   DDR3 interface number */
/** @param  values    Avago_ddr3_training_values_t struct */
/** @return TBD */
int avago_ddr3_get_training_values(Aapl_t *aapl, uint spico_addr, uint channel, Avago_ddr3_training_values_t *values)
{
  uint byte;
  int lane;
  uint etrain_addr;
  uint last_byte;

  /* Get the sbus address for the channel */
  etrain_addr = avago_ddr3_channel_to_sbus_addr(aapl, spico_addr, channel);

  /* Get the number of bytes in the interface from LAST_BYTE */
  last_byte = avago_sbus_rd(aapl, etrain_addr, 0x43);

  for (byte = 0; byte <= last_byte; byte++) {
    avago_sbus_wr(aapl, etrain_addr, 0x29, byte);                              /* LD_OBS_BYTE_SEL selects byte */

    /* Get wrlvl result */
    avago_sbus_wr(aapl, etrain_addr, 0x40, 0x0b);                              /* OBSERVE_SELECT */
    values->write_leveling[byte] = avago_sbus_rd(aapl, etrain_addr, 0x41);     /* OBSERVE_REG */

    /* Get read gate result */
    avago_sbus_wr(aapl, etrain_addr, 0x40, 0x0a);                              /* OBSERVE_SELECT */
    values->read_gate_delay[byte] = avago_sbus_rd(aapl, etrain_addr, 0x41);     /* OBSERVE_REG */

    /* Get write data PBDS result for each lane */
    avago_sbus_wr(aapl, etrain_addr, 0x2d , 1);                                /* PBDS_WR_NRD_MODE */
    avago_sbus_wr(aapl, etrain_addr, 0x40, 0x0d);                              /* OBSERVE_SELECT */
    for (lane = 0; lane <= 8; lane++) {
      avago_sbus_wr(aapl, etrain_addr, 0x2f, lane);                            /* PBDS_DATA_SELECT */
      values->write_pbds[byte][lane] = avago_sbus_rd(aapl, etrain_addr, 0x41); /* OBSERVE_REG */
    }

    /* Get read data PBDS result for each lane */
    avago_sbus_wr(aapl, etrain_addr, 0x2d , 0);                                /* PBDS_WR_NRD_MODE */
    avago_sbus_wr(aapl, etrain_addr, 0x40, 0x0c);                              /* OBSERVE_SELECT */
    for (lane = 0; lane <= 8; lane++) {
      avago_sbus_wr(aapl, etrain_addr, 0x2f, lane);                            /* PBDS_DATA_SELECT */
      values->read_pbds[byte][lane] = avago_sbus_rd(aapl, etrain_addr, 0x41);  /* OBSERVE_REG */
    }

    /* Get write stb PBDS result for each byte */
    avago_sbus_wr(aapl, etrain_addr, 0x2d , 1);                                /* PBDS_WR_NRD_MODE */
    avago_sbus_wr(aapl, etrain_addr, 0x40, 0x0f);                              /* OBSERVE_SELECT */
    values->write_pbds_stb[byte] = avago_sbus_rd(aapl, etrain_addr, 0x41);     /* OBSERVE_REG */

    /* Get read stb PBDS result for each byte */
    avago_sbus_wr(aapl, etrain_addr, 0x2d , 1);                                /* PBDS_WR_NRD_MODE */
    avago_sbus_wr(aapl, etrain_addr, 0x40, 0x0e);                              /* OBSERVE_SELECT */
    values->read_pbds_stb[byte] = avago_sbus_rd(aapl, etrain_addr, 0x41);      /* OBSERVE_REG */
  }

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO DDR3 SET TRAINING VALUES */
/** */
/** @brief Retrieves the training values for a DDR3 channel */
/** */
/** @param  aapl      aapl struct */
/** @param  sbus_addr sbus_address of the sbus master spico */
/** @param  channel   DDR3 interface number */
/** @param  values    Avago_ddr3_training_values_t struct */
/** @return TBD */
int avago_ddr3_set_training_values(Aapl_t *aapl, uint sbus_addr, uint channel, Avago_ddr3_training_values_t *values) {
  uint etrain_addr = avago_ddr3_channel_to_sbus_addr(aapl, sbus_addr, channel);

  int byte;
  int lane;

  for (byte = 0; byte <= 3; byte++) {
    avago_ddr3_load_wrlvl_value(aapl, etrain_addr, byte, values->write_leveling[byte]);
    avago_ddr3_load_coarse_rdlvl_value(aapl, etrain_addr, byte, values->read_gate_delay[byte]);
    avago_ddr3_load_stb_pbds_value(aapl, etrain_addr, byte, 0, values->read_pbds_stb[byte]);
    avago_ddr3_load_stb_pbds_value(aapl, etrain_addr, byte, 1, values->write_pbds_stb[byte]);

    for (lane = 0; lane <= 7; lane++) {
      avago_ddr3_load_data_pbds_value(aapl, etrain_addr, byte, lane, 0, values->read_pbds[byte][lane]);
      avago_ddr3_load_data_pbds_value(aapl, etrain_addr, byte, lane, 1, values->write_pbds[byte][lane]);
    }
  }
  return aapl->return_code;
}

/*============================================================================= */
/* AVAGO DDR3 LOAD WRLVL VALUE */
/** */
/** @brief Programs a write leveling value for a single byte */
/** */
/** @param  aapl        aapl struct */
/** @param  etrain_addr sbus_address of the channels training block */
/** @param  byte        byte to program */
/** @param  value       write leveling value */
/** @return TBD */
int avago_ddr3_load_wrlvl_value(Aapl_t *aapl, uint etrain_addr, uint byte, uint value)
{
  int max_timeout = 500;
  int timeout = 0;
  uint result;

  avago_sbus_wr(aapl, etrain_addr, 0x29, byte);       /* LD_OBS_BYTE_SEL */
  avago_sbus_wr(aapl, etrain_addr, 0x2a, value);      /* LVL_VALUES */
  avago_sbus_wr(aapl, etrain_addr, 0x08, 0x02);       /* WRITE_LEVEL_TRAINING */

  do {
    result = avago_sbus_rd(aapl, etrain_addr, 0x03);  /* ACTIVE_OBSERVE (WRLVL_LD_ACTIVE) */
    timeout += 1;
  } while ((result & 0x80) != 0 && timeout <= max_timeout);

  avago_sbus_wr(aapl, etrain_addr, 0x08, 0x00);       /* WRITE_LEVEL_TRAINING */

  if (timeout >= max_timeout) {
    aapl_fail(aapl, __func__, __LINE__, "DDR3 loading write level values timed out at SBus address 0x%02x.\n", etrain_addr);
    return aapl->return_code;
  }

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO DDR3 LOAD COARSE RDLVL VALUE */
/** */
/** @brief Programs the read-gate training value for a single byte */
/** */
/** @param  aapl        aapl struct */
/** @param  etrain_addr sbus_address of the channels training block */
/** @param  byte        byte to program */
/** @param  value       read gate training value */
/** @return TBD */
int avago_ddr3_load_coarse_rdlvl_value(Aapl_t *aapl, uint etrain_addr, uint byte, uint value)
{
  int max_timeout = 500;
  int timeout = 0;
  uint result;

  avago_sbus_wr(aapl, etrain_addr, 0x29, byte);          /* LD_OBS_BYTE_SEL */
  avago_sbus_wr(aapl, etrain_addr, 0x2a, (value << 8));  /* LVL_VALUES */
  avago_sbus_wr(aapl, etrain_addr, 0x09, 0x02);          /* READ_GATE_TRAINING */

  do {
    result = avago_sbus_rd(aapl, etrain_addr, 0x03);     /* ACTIVE_OBSERVE (RDLVL_GATE_LD_ACTIVE) */
    timeout += 1;
  } while ((result & 0x400) != 0 && timeout <= max_timeout);

  avago_sbus_wr(aapl, etrain_addr, 0x09, 0x00);          /* READ_GATE_TRAINING */

  if (timeout >= max_timeout) {
    aapl_fail(aapl, __func__, __LINE__, "DDR3 loading coarse read gate values timed out at SBus address 0x%02x.\n", etrain_addr);
    return aapl->return_code;
  }

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO DDR3 LOAD FINE RDLVL VALUE */
/** */
/** @brief Programs the read-gate training value for a single byte */
/** */
/** @param  aapl        aapl struct */
/** @param  etrain_addr sbus_address of the channels training block */
/** @param  byte        byte to program */
/** @param  value       read gate training value */
/** @return TBD */
int avago_ddr3_load_fine_rdlvl_value(Aapl_t *aapl, uint etrain_addr, uint byte, uint value)
{
  int max_timeout = 500;
  int timeout = 0;
  uint result;

  avago_sbus_wr(aapl, etrain_addr, 0x29, byte);           /* LD_OBS_BYTE_SEL */
  avago_sbus_wr(aapl, etrain_addr, 0x2a, (value << 12));  /* LVL_VALUES */
  avago_sbus_wr(aapl, etrain_addr, 0x09, 0x08);           /* READ_GATE_TRAINING */

  do {
    result = avago_sbus_rd(aapl, etrain_addr, 0x03);      /* ACTIVE_OBSERVE (RDLVL_GATE_LD_ACTIVE) */
    timeout += 1;
  } while ((result & 0x2000) != 0 && timeout <= max_timeout);

  avago_sbus_wr(aapl, etrain_addr, 0x09, 0x00);           /* READ_GATE_TRAINING */

  if (timeout >= max_timeout) {
    aapl_fail(aapl, __func__, __LINE__, "DDR3 loading fine read gate values timed out at SBus address 0x%02x.\n", etrain_addr);
    return aapl->return_code;
  }

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO DDR3 LOAD STB PBDS VALUE */
/** */
/** @brief Programs the read or write strobe pbds value for a single byte */
/** */
/** @param  aapl        aapl struct */
/** @param  etrain_addr sbus_address of the channels training block */
/** @param  byte        byte to program */
/** @param  read_write 0 for read 1 for write */
/** @param  value       strobe training value */
/** @return TBD */
int avago_ddr3_load_stb_pbds_value(Aapl_t *aapl, uint etrain_addr, uint byte, uint read_write, uint value)
{
  int max_timeout = 500;
  int timeout = 0;
  uint result;

  avago_sbus_wr(aapl, etrain_addr, 0x29, byte);        /* LD_OBS_BYTE_SEL */
  avago_sbus_wr(aapl, etrain_addr, 0x2d, read_write);  /* PBDS_WR_NRD_MODE */
  avago_sbus_wr(aapl, etrain_addr, 0x2e, value);       /* PBDS_STROBE_COARSE_CONFIGURATION */
  avago_sbus_wr(aapl, etrain_addr, 0x0a, 0x04);        /* PBDS_TRAINING */

  do {
    result = avago_sbus_rd(aapl, etrain_addr, 0x04);   /* MORE_ACTIVE_OBSERVE (STB_PBDS_LOAD_ACTIVE) */
    timeout += 1;
  } while ((result & 0x20) != 0 && timeout <= max_timeout);

  avago_sbus_wr(aapl, etrain_addr, 0x0a, 0x01);        /* PBDS_TRAINING */

  if (timeout >= max_timeout) {
    aapl_fail(aapl, __func__, __LINE__, "DDR3 loading stb pbds values timed out at SBus address 0x%02x.\n", etrain_addr);
    return aapl->return_code;
  }

  return aapl->return_code;
}


/*============================================================================= */
/* AVAGO DDR3 LOAD DATA PBDS VALUE */
/** */
/** @brief Programs the read or write data pbds value for a single lane */
/** */
/** @param  aapl          aapl struct */
/** @param  etrain_addr   sbus_address of the channels training block */
/** @param  byte          byte to program */
/** @param  lane          lane within the byte to program */
/** @param  read_write    0 for read 1 for write */
/** @param  value         coarse and fine pbds data value */
/** @return TBD */
int avago_ddr3_load_data_pbds_value(Aapl_t *aapl, uint etrain_addr, uint byte, uint lane, uint read_write, uint value)
{
  int max_timeout = 500;
  int timeout = 0;
  uint result;

  avago_sbus_wr(aapl, etrain_addr, 0x29, byte);        /* LD_OBS_BYTE_SEL */
  avago_sbus_wr(aapl, etrain_addr, 0x2d, read_write);  /* PBDS_WR_NRD_MODE */
  avago_sbus_wr(aapl, etrain_addr, 0x2f, lane);        /* PBDS_DATA_SELECT */
  avago_sbus_wr(aapl, etrain_addr, 0x30, value);       /* PBDS_DATA_CONFIGURATION */
  avago_sbus_wr(aapl, etrain_addr, 0x0a, 0x02);        /* PBDS_TRAINING */

  do {
    result = avago_sbus_rd(aapl, etrain_addr, 0x04);   /* MORE_ACTIVE_OBSERVE (PBDS_LOAD_ACTIVE) */
    timeout += 1;
  } while ((result & 0x08) != 0 && timeout <= max_timeout);

  avago_sbus_wr(aapl, etrain_addr, 0x0a, 0x01);        /* PBDS_TRAINING */

  if (timeout >= max_timeout) {
    aapl_fail(aapl, __func__, __LINE__, "DDR3 loading data pbds values timed out at SBus address 0x%02x.\n", etrain_addr);
    return aapl->return_code;
  }

  return aapl->return_code;
}



/*============================================================================= */
/* AVAGO DDR3 REPORT TRAINING VALUES */
/** */
/** @brief Writes the training values to the AAPL log */
/** */
/** @param  aapl       aapl struct */
/** @param  spico_addr sbus_address of the sbus master spico */
/** @param  channel    DDR3 interface number */
/** @param  values     Avago_ddr3_training_values_t struct */
/** @return TBD */
int avago_ddr3_report_training_values(Aapl_t *aapl, uint spico_addr, uint channel, Avago_ddr3_training_values_t *values)
{
  uint byte;
  uint etrain_addr = avago_ddr3_channel_to_sbus_addr(aapl, spico_addr, channel);
  uint last_byte = avago_sbus_rd(aapl, etrain_addr, 0x43);

  Avago_addr_t addr_struct;
  avago_addr_to_struct(spico_addr, &addr_struct);

  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "\n");
  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "Training values dump for Sbus Ring %d DDR3 Channel %d\n", addr_struct.ring, channel);

  /* Write leveling values */
  for (byte = 0; byte <= last_byte; byte++) {
    aapl_log_printf(aapl, AVAGO_INFO, "", 1, "Byte:%d Write Leveling:0x%02x\n", byte, values->write_leveling[byte]);
  }

  /* Read gate delay values */
  for (byte = 0; byte <= last_byte; byte++) {
    aapl_log_printf(aapl, AVAGO_INFO, "", 1, "Byte:%d Read_Gate_Delay:0x%02x\n", byte, values->read_gate_delay[byte]);
  }

  /* PBDS values */
  for (byte = 0; byte <= last_byte; byte++) {
    int lane;
    aapl_log_printf(aapl, AVAGO_INFO, "", 1, "Byte:%d Read_Strobe_Delay:0x%02x\n", byte, values->read_pbds_stb[byte]);
    aapl_log_printf(aapl, AVAGO_INFO, "", 1, "Byte:%d Write_Strobe_Delay:0x%02x\n", byte, values->write_pbds_stb[byte]);

    for (lane = 0; lane <= 8; lane++) {
      aapl_log_printf(aapl, AVAGO_INFO, "", 1, "Byte:%d Lane:%d Read_Data_delay:0x%02x\n", byte, lane, values->read_pbds[byte][lane]);
    }

    for (lane = 0; lane <= 8; lane++) {
      aapl_log_printf(aapl, AVAGO_INFO, "", 1, "Byte:%d Lane:%d Write_Data_delay:0x%02x\n", byte, lane, values->write_pbds[byte][lane]);
    }
  }

  return 0;
}


/*============================================================================= */
/* AVAGO DDR3 SBUS DUMP */
/** */
/** @brief Report DDR3 sbus register values */
/** */
/** @param aapl        aapl struct */
/** @param spico_addr  sbus address of the sbus master spico for the channel */
/** @param channel     DDR3 channel number  */
/** @return  TBD */
void avago_ddr3_sbus_dump_channel_devices(Aapl_t *aapl, uint spico_addr, uint channel)
{
  uint last_byte;
  uint etrain_addr;
  uint addr;
  uint byte;
  char name[14];

  /* Get the sbus address for the etrain block in the channel */
  etrain_addr = avago_ddr3_channel_to_sbus_addr(aapl, spico_addr, channel);
  avago_ddr3_sbus_dump(aapl, etrain_addr, channel, (char *) "eTrain");

  last_byte = avago_sbus_rd(aapl, etrain_addr, 0x43);
  for (byte = 0; byte <= last_byte; byte++) {
    avago_sbus_wr(aapl, etrain_addr, 0x29, byte);    /* LD_OBS_BYTE_SEL selects byte */
    avago_sbus_wr(aapl, etrain_addr, 0x40, 0x05);    /* OBSERVE_SELECT (OBS_SEL_DM_SBS_ADDR) */
    addr = avago_sbus_rd(aapl, etrain_addr, 0x41);   /* OBSERVE_REG */

    sprintf(name, "Databist[%u]", byte);
    avago_ddr3_sbus_dump(aapl, addr, channel, name);
  }

  avago_sbus_wr(aapl, etrain_addr, 0x40, 0x06);    /* OBSERVE_SELECT (OBS_SEL_AM_SBS_ADDR) */
  addr = avago_sbus_rd(aapl, etrain_addr, 0x41);   /* OBSERVE_REG */
  avago_ddr3_sbus_dump(aapl, addr, channel, (char *) "AddressBist");
}


/*============================================================================= */
/* AVAGO DDR3 SBUS DUMP */
/** */
/** @brief Report DDR3 sbus register values */
/** */
/** @param aapl        aapl struct */
/** @param sbus_addr   sbus address of the device */
/** @param channel     DDR3 channel number  */
/** @param device_name Name of the sbus device */
/** @return  TBD */
void avago_ddr3_sbus_dump(Aapl_t *aapl, uint sbus_addr, uint channel, char *device_name)
{
  int addr;

  Avago_addr_t addr_struct;
  avago_addr_to_struct(sbus_addr, &addr_struct);

  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "\n");
  aapl_log_printf(aapl, AVAGO_INFO, "", 1, "SBus dump for Sbus ring %d, DDR3 Channel %d, Device %s, SBus address: 0x%02x\n", addr_struct.ring, channel, device_name, sbus_addr);

  for (addr=0; addr <= 0xff; addr++) {
    int data = avago_sbus_rd(aapl, sbus_addr, addr);
    if (aapl->data != 0) {
      aapl_hex_2_bin(aapl->data_char, aapl->data, 1, 32);
      aapl_log_printf(aapl, AVAGO_INFO, "", 1, "0x%02x/%03d: 0x%08x %s\n", addr, addr, data, aapl->data_char);
    }
  }
}

#endif /* AAPL_ENABLE_DDR3_ETRAIN */

/** @} */
