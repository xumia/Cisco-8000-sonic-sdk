/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* Support for AAPL handling of various sensors built into Avago IP. */

/** @file   sensor.c */
/** @brief  Functions for accessing Avago sensors (for temperature, voltage, etc.). */
/** @defgroup Sensor Sensor API for Measuring Temperature and Voltage */
/** @{ */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#define AAPL_LOG_PRINT5 if(aapl->debug >= 5) aapl_log_printf


static void avago_apb_start_read(Aapl_t *aapl, uint addr, int reg)
{
    if( (reg & ~0xffff) == 0 )
#if 1
    {
        /* Due to timing issues, must separate these commands on Alta and prior chips. */
        avago_sbus_wr(aapl, addr, 11, (reg & 0xffff) | (0<<16));    /* Write reg address and */
        avago_sbus_wr(aapl, addr, 11, (reg & 0xffff) | (1<<16));    /*                       start read command */
    }
#else
        /* This should work for all product chips: */
        avago_sbus_wr(aapl, addr, 11, (reg & 0xffff) | (1<<16));    /* Write reg address and start read command */
#endif
    else
    {
        avago_sbus_wr(aapl, addr, 10, reg);                         /* Write reg address to sbus */
        avago_sbus_wr(aapl, addr,  6, 1);                           /* Start a read operation. */
    }
}

static int avago_apb_read16(Aapl_t *aapl, uint addr, int reg)
{
    int i;
    avago_apb_start_read(aapl, addr, reg);

    for(i = 0; i < 10; i++ )
    {
        int data = avago_sbus_rd(aapl, addr, 21);
        if( (data & 7) == 0 )
            return data >> 16; /* Return data, sign extended */
        ms_sleep(1);
    }
    return -1;
}

#if 0
static int avago_apb_read32(Aapl_t *aapl, uint addr, int reg)
{
    avago_apb_start_read(aapl, addr, reg);

    for(;;)
    {
        int busy = avago_sbus_rd(aapl, addr, 2);
        if( (busy & 7) == 0 )                           /* Wait for read to complete */
            return avago_sbus_rd(aapl, addr, 20);       /* Read 32 bit data */
    }
}

static int avago_apb_write(Aapl_t *aapl, uint addr, int reg, int data)
{
    int busy;
    avago_sbus_wr(aapl, addr, 12, data); /* Write data to sbus */
    if( (addr & ~0xffff) == 0 )
    {
#if 1
        /* Due to timing issues, must separate these commands on Alta and prior chips. */
        avago_sbus_wr(aapl, addr, 11, reg | (0<<17));               /* Write reg address and */
        avago_sbus_wr(aapl, addr, 11, reg | (1<<17));               /* and start write command */
#else
        /* This should work for all product chips: */
        avago_sbus_wr(aapl, addr, 11, reg | (1<<17));               /* Write reg address and start write command */
#endif
        while( ((busy = avago_sbus_rd(aapl, addr, 21)) & 7) != 0 )  /* Wait for write to complete */
            printf("busy = 0x%x\n", busy);
    }
    else
    {
        avago_sbus_wr(aapl, addr, 10, reg);                         /* Write reg address to sbus */
        avago_sbus_wr(aapl, addr,  6, 2);                           /* Start a write operation */
        while( ((busy = avago_sbus_rd(aapl, addr,  2)) & 7) != 0 )  /* Wait for write to complete */
            printf("busy = 0x%x\n", busy);
    }
    return 0;
}
#endif

/** @brief Prepare sensor for measurement */
static void initialize_sensor(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] Sensor sbus address. */
    uint frequency) /**< [in] Sensor clock input frequency in Hertz. */
                    /**<      If non-zero, configures the sensor, */
                    /**<      which only need be done once. */
                    /**< For the 7nm sensor, if non-zero, this should be the sbus clock input frequency before being divided. */
{
    if( aapl_get_ip_type(aapl, addr) == AVAGO_SBUS2APB )
    {
        if( frequency > 0 )
        {
            Avago_addr_t addr_struct;
            int sbus_divider = avago_sbm_get_sbus_clock_divider(aapl, addr);
            uint adc_divider = (frequency / sbus_divider + 500000) / 1000000;
            uint pclk_divider = adc_divider / 20;

            if( pclk_divider == 0 ) pclk_divider = 1;
            if( adc_divider == 0 ) adc_divider = 1;

            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "in freq = %u kHz, sbus_freq = %u kHz, adc div=%u freq=%u kHz, pclk div=%u freq=%u kHz\n",
                    frequency/1000, frequency/sbus_divider/1000, adc_divider, frequency/sbus_divider/adc_divider/1000, pclk_divider, frequency/sbus_divider/pclk_divider/1000);

            /* By default, the input to these dividers is the sbus clock. */
            /* To use anything else, registers 30, 31 and 32 should be */
            /* configured appropriately outside this API and frequency */
            /* should be passed as zero. */
            avago_sbus_wr(aapl, addr, 30, adc_divider);  /* ADC frequency to sensor should be in range 0.5 to 2.0 MHz. */
            avago_sbus_wr(aapl, addr, 31, pclk_divider); /* PCLK frequency to sensor should be in range 10 to 200 MHz. */
            avago_sbus_wr(aapl, addr, 32, 0);            /* Select sbus as clock input. */

            /* Make sure it is taking measurements */
            avago_addr_to_struct(addr, &addr_struct);
            if( aapl->jtag_idcode[addr_struct.chip] == 0x1a08457f ) /* Beaver Creek 1.0 */
            {
                /* Sensor reset wiring was not inverted, invert it here. */
                avago_sbus_wr(aapl, addr, 0, 0x0f); /* Reset */
                avago_sbus_wr(aapl, addr, 0, 0x10); /* Re-enable */
            }
            else
            {
                /* Expected usage: */
                avago_sbus_wr(aapl, addr, 0, 0x1f); /* Reset all */
                avago_sbus_wr(aapl, addr, 0, 0x19); /* Take dividers out of reset */
             /* avago_sbus_wr(aapl, addr, 0, 0x10); // Take registers out of reset */
                avago_sbus_wr(aapl, addr, 0, 0x00); /* Re-enable all */
            }
        }
        return;
    }

    avago_sbus_wr(aapl, addr, 0x00, 0x01);                  /* apply reset */
    if( frequency > 0 )
    {
        /* Convert input frequency to a 2.0 MHz working sensor frequency: */
        uint divider = (frequency + 1000000) / 2000000;
        avago_sbus_wr(aapl, addr, 0x01, divider & 0x03FF);  /* setup divider */

        if( aapl_get_process_id(aapl, addr) == AVAGO_TSMC_16 )
        {
            /* Override default sensor calibration values for 16nm ASICs: */
            /* Updated TEMP_* values per RyanK who says these are the defaults in silicon, so only needed for very early silicon. */
            avago_sbus_wr(aapl, addr, 0x06, 0x50c1); /* TEMP_GAIN_OVRD_VAL */
            avago_sbus_wr(aapl, addr, 0x07, 0xb529); /* TEMP_OFFSET_OVRD_VAL */
            avago_sbus_wr(aapl, addr, 0x08, 0x1c);   /* TEMP_C_RES_OVRD_VAL */
            avago_sbus_wr(aapl, addr, 0x0b, 0x07);   /* TEMP_GAIN_OVRD, TEMP_OFFSET_OVRD, TEMP_C_RES_OVRD */
            avago_sbus_wr(aapl, addr, 0x0c, 0x5e70); /* VOLTAGE_GAIN_OVRD_VAL */
            avago_sbus_wr(aapl, addr, 0x0e, 0x2a);   /* VOLTAGE_C_RES_OVRD_VAL */
            avago_sbus_wr(aapl, addr, 0x10, 0x5);    /* VOLTAGE_GAIN_OVRD, VOLTAGE_C_RES_OVRD */
            /*avago_sbus_wr(aapl, addr, 0x11, 0x6e41); // REMOTE_GAIN_OVRD_VAL */
            /*//avago_sbus_wr(aapl, addr, 0x13, 0x0);    // REMOTE_C_RES_OVRD_VAL */
            /*//avago_sbus_wr(aapl, addr, 0x14, 0x5);    // REMOTE_GAIN_OVRD, REMOTE_C_RES_OVRD */
        }
    }
}

/** @brief   Starts a temperature measurement. */
/** @details Use this function to start measurements on multiple devices. */
/** @details Note that in 16 and 28 nm, each device (sensor sbus address) can perform only */
/**          one measurement (voltage or temperature) at a time. */
/** */
/**          In 7nm, sensor measurements need be started and initialized only once. */
/**          Thereafter, up-to-date values can be read at will. */
/** @see avago_sensor_wait_temperature(), avago_sensor_get_temperature(). */
void avago_sensor_start_temperature(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] Sensor sbus address.  Chip/ring broadcast OK. */
    int sensor,     /**< [in] Which sensor to access. A value of 0 selects */
                    /**<      the main sensor. Values of 1 through 8 */
                    /**<      select remote sensors 0 through 7. */
    uint frequency) /**< [in] Sensor clock input frequency in Hertz. */
                    /**<      If non-zero, configures the sensor, */
                    /**<      which only need be done once. */
{
    initialize_sensor(aapl, addr, frequency);

    if( aapl_get_ip_type(aapl, addr) == AVAGO_SBUS2APB )
        return;

    if( sensor > 8 ) sensor = 0;                        /* Range bound input */
    avago_sbus_wr(aapl, addr, 0x03, 0x01 << sensor );   /* Select sensor */
    avago_sbus_wr(aapl, addr, 0x00, 0x02);              /* Start measurement */
}

/** @cond INTERNAL */

/** @brief Convert raw sensor data to mC value. */
/** @details Only valid for 7nm designs. */
/** @return  Returns temperature in millidegrees C.  Valid range is [-40,000..120,000] (-40C to +120C). */
/**          Values outside of this range indicate an error (perhaps data from an unconnected sensor). */
int avago_sensor_to_mC(Aapl_t *aapl, uint addr, uint data)
{
    int temp;
    if( aapl_get_jtag_idcode(aapl, addr) == 0x1a08457f )    /* BC 1.0 */
    {
        /* Version 0.8 of documentation: */
        /*temp = ((int)((-0.2388 * (0x7ff & data) + 365.78) * 4.0 + 0.50)) * 250;   // Floating point version of equation */
        /*temp = ((-2388 * (0x7ff & data) + (3657800 + 1250)) / 2500) * 250;        // Integer version of equation */
        /* Version 1.X of documentation: */
        /*temp = ((int)((-0.247 * (0x7ff & data) + 356.18) * 4.0 + 0.50)) * 250;    // Linear floating point version of equation */
        /*temp = ((int)((-0.23951 * (0x7ff & data) + 357.55) * 4.0 + 0.50)) * 250;  // Linear floating point version of equation from Bob Elio for BC 1.0 */
        temp = ((-2395 * (0x7ff & (int)data) + (3575500 + 1250)) / 2500) * 250;          /* Linear integer version of equation */
    }
    else    /* ML3.1.0.2 for TCHIP, BC 2.0 and ALTA. */
    {
        /*temp = ((int)((-0.000008823*(0x7ff&data)*(0x7ff&data) - 0.21422*(0x7ff&data) + 341.01) * 4.0 + 0.50)) * 250;   // Poly floating point version of equation from 1.7 docs. */
        /*temp = ((int)((-0.23755 * (0x7ff & data) + 356.07) * 4.0 + 0.50)) * 250;  // Linear floating point version of equation from 1.7 docs. */
        /*temp = ((int)((-0.23740 * (0x7ff & data) + 355.91) * 4.0 + 0.50)) * 250;  // Linear floating point version of equation for TCHIP per Bob Elio. */
        temp = ((-2374 * (0x7ff & (int)data) + (3559100 + 1250)) / 2500) * 250;          /* Linear integer version of equation */
    }
    return temp;
}

/** @endcond */

/** @brief   Performs a blocking read on a temperature sensor, which is */
/**          assumed to be properly initialized. */
/** @return  On success, returns the temperature in milli-degrees C. */
/** @return  On error, decrements aapl->return_code and returns -1000000. */
/** @see avago_sensor_start_temperature(), avago_sensor_get_temperature(). */
int avago_sensor_wait_temperature(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] Sensor sbus address. */
    int sensor)     /**< [in] Which sensor to access. A value of 0 selects */
                    /**<      the main sensor. Values of 1 through 8 */
                    /**<      select remote sensors 0 through 7. */
{
    int return_code = aapl->return_code;
    int temp = -1000000;
    int data;
    if( aapl_get_ip_type(aapl, addr) == AVAGO_SBUS2APB )
    {
        /*                                         Equations from Robert Elio: */
        /* BC 1.0 used ML2.5.0.3 per Gayvin        degC = -0.23951 * data + 357.55 */
        /* BC 2.0 used ML3.1.0.2 per Gayvin */
        /* TChip  used ML3.1.0.2 per Robert Elio.  degC = -0.2374 * data + 355.91 */
        /* ALTA   used ML3.1.0.2 per Samuel Sum and Veerendra Nath. */

        int sensor_reg = sensor == 0 ? 7 : sensor + 8;
        int i;
        for( i = 0; i < 10; i++ )
        {
            data = avago_apb_read16(aapl, addr, sensor_reg);
            if( data & 0x800 ) break;
            if( i > 6 )
                ms_sleep(1);
        }
        temp = avago_sensor_to_mC(aapl, addr, data);
    }
    else
    {
        int i;
        for( i = 0; i < 16; i++ ) /* Retry a few times in case data not stable */
        {
            if( i > 0 ) ms_sleep(5);    /* The first read flushes the sbus writes */
            data = avago_sbus_rd(aapl, addr, 65 + sensor);
            if( data & 0x8000 ) /* If valid data */
            {
                /* Convert 1/8 degree value to milli-degrees. */
                if( data & 0x800 )
                    temp = data | ~0x7ff;  /* negative sign extension */
                else
                    temp = data & 0x7ff;
                temp *= 125;
                break;
            }
        }
    }

    if( temp < -40000 || temp > 125000 || aapl->return_code != return_code )
    {
        aapl_fail(aapl, __func__, __LINE__, "SBus 0x%02x, Temperature conversion failed (temp = %d milliC), returning -1000000.\n",addr,temp);
        temp = -1000000;
    }
    else
        AAPL_LOG_PRINT5(aapl, AVAGO_DEBUG5, __func__, __LINE__, "Temp = %7d mC (data=0x%x)\n", temp, data);

    return temp;
}


/** @brief   Performs a temperature measurement. */
/** @details Combines the start and wait functions into one blocking operation. */
/** @return  On success, returns the temperature in milli-degrees C. */
/** @return  On error, decrements aapl->return_code and returns -1000000. */
/** @see     avago_sensor_start_temperature(), avago_sensor_wait_temperature(). */
/** @see     avago_sensor_get_voltage(). */
int avago_sensor_get_temperature(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] Sensor sbus address. */
    int sensor,     /**< [in] Which sensor to access. A value of 0 selects */
                    /**<      the main sensor. Values of 1 through 8 */
                    /**<      select remote sensors 0 through 7. */
    uint frequency) /**< [in] Sensor clock input frequency in Hertz. */
                    /**<      If non-zero, configures the sensor, */
                    /**<      which only need be done once. */
{
    int temp;
    AAPL_SENSOR_LOCK;
    avago_sensor_start_temperature(aapl, addr, sensor, frequency);
    temp = avago_sensor_wait_temperature(aapl, addr, sensor);
    AAPL_SENSOR_UNLOCK;
    return temp;
}


/** @brief   Starts a voltage measurement. */
/** @details Use this function to start measurements on multiple devices. */
/** @details Note that in 16 and 28 nm, each device (sensor sbus address) can perform only */
/**          one measurement (voltage or temperature) at a time. */
/** */
/**          In 7nm, sensor measurements need be started and initialized only once. */
/**          Thereafter, up-to-date values can be read at will. */
/** @see     avago_sensor_wait_voltage(), avago_sensor_get_voltage(). */
void avago_sensor_start_voltage(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] Sensor sbus address.  Chip/ring broadcast OK. */
    int sensor,     /**< [in] Which sensor to access.  A value of 0 selects */
                    /**<      the VDD voltage, 1 selects CORE_VDD_VIN, and */
                    /**<      values [2..7] select SENSOR_A2D_VIN[0..5] */
                    /**< The 7nm block has remote sensors [0..7] without special designations. */
    uint frequency) /**< [in] Sensor clock input frequency in Hertz. */
                    /**<      If non-zero, configures the sensor, */
                    /**<      which only need be done once. */
{
    initialize_sensor(aapl, addr, frequency);

    if( aapl_get_ip_type(aapl, addr) == AVAGO_SBUS2APB )
        return;

    if( sensor > 7 ) sensor = 0;                        /* Range bound input */
    avago_sbus_wr(aapl, addr, 0x03, 0x200 << sensor );  /* Select sensor */
    avago_sbus_wr(aapl, addr, 0x00, 0x02);              /* Start measurement */
}

/** @brief   Performs a blocking read on a voltage sensor, which is */
/**          assumed to be properly initialized. */
/** @return  On success, returns the voltage in mV. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_sensor_start_voltage(), avago_sensor_get_voltage(). */
int avago_sensor_wait_voltage(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] Sensor sbus address. */
    int sensor)     /**< [in] Which sensor to access.  A value of 0 selects */
                    /**<      the VDD voltage, 1 selects CORE_VDD_VIN, and */
                    /**<      values [2..7] select SENSOR_A2D_VIN[0..5] */
                    /**< The 7nm block has remote sensors [0..7] without special designations. */
{
    int return_code = aapl->return_code;
    int data;
    int mV = -1;
    if( aapl_get_ip_type(aapl, addr) == AVAGO_SBUS2APB )
    {
        int A = (sensor == 6) ? 2 : (sensor == 7) ? 4 : 1;
        int sensor_reg = sensor + 0x11;
        data = avago_apb_read16(aapl, addr, sensor_reg);
        mV = A * 1020 * (data & 0x7ff) / 2048;
    }
    else
    {
        /* Retry a few times in case data not stable. */
        int i;
        for( i = 0; i < 8; i++ )
        {
            if( i > 0 ) ms_sleep(4);
            data = avago_sbus_rd(aapl, addr, 74 + sensor);
            if( data & 0x8000 ) /* If valid data */
            {
                mV = (data & 0xfff) / 2;
                break;
            }
        }
    }

    if( mV == -1 || aapl->return_code != return_code )
        return aapl_fail(aapl, __func__, __LINE__, "Voltage conversion failed, returning -1.\n");

    AAPL_LOG_PRINT5(aapl, AVAGO_DEBUG5, __func__, __LINE__, "Voltage = %4d mV (data=0x%x)\n",mV,data);
    return mV;
}

/** @brief   Performs a voltage measurement. */
/** @details Combines the start and wait functions into one blocking operation. */
/** @return  On success, returns the voltage in mV. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_sensor_start_voltage(), avago_sensor_wait_voltage(). */
/** @see     avago_sensor_get_temperature(). */
int avago_sensor_get_voltage(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] Sensor sbus address. */
    int sensor,     /**< [in] Which sensor to access.  A value of 0 selects */
                    /**<      the VDD voltage, 1 selects CORE_VDD_VIN, and */
                    /**<      values [2..7] select SENSOR_A2D_VIN[0..5] */
                    /**< The 7nm block has remote sensors [0..7] without special designations. */
    uint frequency) /**< [in] Sensor clock input frequency in Hertz. */
                    /**<      If non-zero, configures the sensor, */
                    /**<      which only need be done once. */
{
    int volt;
    AAPL_SENSOR_LOCK;
    avago_sensor_start_voltage(aapl, addr, sensor, frequency);
    volt = avago_sensor_wait_voltage(aapl, addr, sensor);
    AAPL_SENSOR_UNLOCK;
    return volt;
}


/** @} */


/* AVSP functions (to go into another file eventually): */


/** @defgroup Avsp Avsp Functions */
/** @{ */

/** @return Address of sensor for known AVSP devices. */
static uint avsp_sensor_get_addr(Aapl_t *aapl, uint prtad)
{
    int sensor_sbus = 1;    /* 1104, 4412/8801, 5410, 8812 */

    /* Update if any AVSP doesn't use sbus address 1: */
    uint jtag_idcode = aapl->jtag_idcode[prtad];
    if( jtag_idcode == 0x2964257f ||        /* 9104 */
        jtag_idcode == 0x1964257f ||        /* 9104 */
        jtag_idcode == 0x0964257f )         /* 9104 */
        sensor_sbus = 0x17;
    else if(
        jtag_idcode == 0x0990357f ||        /* 7401 */
        jtag_idcode == 0x0000057f )         /* 7412 */
        sensor_sbus = 0x02;

    return avago_make_addr3(prtad, 0, sensor_sbus);
}

/** @brief   Reads the sensor data for the AVSP device and converts to milli-degrees C. */
/** @return  On success, returns the temperature in milli-degrees C. */
/** @return  On error, decrements aapl->return_code and returns -1000000. */
/** @see     avago_sensor_get_temperature(), avsp_sensor_get_voltage(). */
int avsp_sensor_get_temperature(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint prtad,     /**< [in] Port address of the targeted device. */
    int sensor,     /**< [in] Which sensor to access. */
    uint frequency) /**< [in] Sensor clock input frequency in Hertz. */
                    /**<      If non-zero, configures the sensor, */
                    /**<      which only need be done once. */
{
    uint sensor_addr = avsp_sensor_get_addr(aapl, prtad);
    if( sensor > 2 )
        return -1000000; /* Not connected */
    return avago_sensor_get_temperature(aapl, sensor_addr, sensor, frequency);
}

/** @brief   Reads the sensor data for the AVSP device and converts to millivolts. */
/** @return  On success, returns the voltage in millivolts. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_sensor_get_voltage(), avsp_sensor_get_temperature(). */
int avsp_sensor_get_voltage(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint prtad,     /**< [in] Port address of the targeted device. */
    int sensor,     /**< [in] Which sensor to access. */
    uint frequency) /**< [in] Sensor clock input frequency in Hertz. */
                    /**<      If non-zero, configures the sensor, */
                    /**<      which only need be done once. */
{
    uint sensor_addr = avsp_sensor_get_addr(aapl, prtad);
    if( sensor > 2 )
        return -1;  /* Not connected */
    return avago_sensor_get_voltage(aapl, sensor_addr, sensor, frequency);
}

/** @} */

