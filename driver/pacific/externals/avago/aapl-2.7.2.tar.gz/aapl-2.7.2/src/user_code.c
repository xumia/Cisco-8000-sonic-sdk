/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* Template for the user_supplied functions. */
/* */

/** Doxygen File Header */
/** @file */
/** @brief Function registration documentation */

#define AAPL_CORE_FILE
#include "aapl.h"

/** @brief  Registers user supplied functions. */
/** @details Provides a single function from which user function registration */
/**          can be performed.  Used only by AAPL CLI functions to provide */
/**          a single location for user configuration without needing */
/**          to change every CLI main function. */
void aapl_register_user_supplied_functions(Aapl_t *aapl)
{
    (void) aapl;
    /* Place any calls to AAPL registration functions here. */
    /* If nothing is placed here, then AAPL will automatically */
    /* register functions based on the selected communication mode. */
    /* */
    /* You should need one of the following: */
    /*      aapl_register_sbus_fn(...); */
    /*      aapl_register_i2c_fn(...); */
    /*      aapl_register_bit_banged_jtag_fn(...); */
    /*      aapl_register_jtag_fn(...); */
    /* */
    /* And optionaly, any number of the following: */
    /*     aapl_register_spico_int_fn(...); */
    /*     aapl_register_jtag_idcode_fn(...); */
    /*     aapl_register_logging_fn(...); */
    /*     aapl_register_parallel_serdes_int_fn(...); */
    /* */
}

#if 0

Starting with AAPL 2.2, AAPL provides hooks to register user-written functions
for communicating with the hardware.  The previous user_supplied_*_functions
are no longer supported, though it should be straightforward to adapt the
existing functions to the new scheme.  Code previously provided in user_code.c
is now replaced with this documentation.

Registering user functions means that the user functions no longer need to be
compiled into AAPL, just callable from AAPL.  This greatly simplifies building
and should greatly simplify integration of new versions of AAPL into customer
environments.

If no user functions are registered, AAPL continues to provide several built-in
communication methods.  Information on registering user functions and using
built-in methods is shown below.


USING BUILT-IN COMMUNICATION METHODS
====================================
The following communication methods are built-into AAPL:
    1. AACS -- Uses the AACS TCP protocol to send commands to a remote server
           via TCP/IP.
    2. AVAGO_SYSTEM_I2C -- Uses system calls to /dev/i2c to send I2C commands
    3. AVAGO_GPIO_MDIO -- Uses system calls on a Raspberry PI to send MDIO
           commands via bit-banged GPIO
    4. AVAGO_JTAG -- Uses the AACS TCP protocol to send
           JTAG commands via TCP/IP to a remote server
    5. AVAGO_OFFLINE -- Uses a built-in server to emulate a device in software
    6. AVAGO_BB_GPIO_JTAG -- Uses /dev/mem to implement a bit-banged GPIO JTAG
           interface for the Raspberry Pi 2

To use these methods, configure AAPL in the following way:
    Aapl_t *aapl = aapl_construct();
    aapl->communication_mode = <MODE>; /* or set the default mode in aapl.h */
    aapl_connect(aapl,server,port); /* server=0 and port=0 for non-AACS communications. */
    ... code here ...
    aapl_destruct(aapl);


CONVERTING FROM USER SUPPLIED FUNCTIONS IN AAPL 2.0 - 2.1
=========================================================
If you supplied functions in user_code.c in AAPL 2.0.x and 2.1.x, it should be
straightforward to upgrade to AAPL 2.2 and later.

If you were supplying code that was called from user_supplied_sbus_function() in
user_code.c, and followed the example prototype, which is:
    command_succeeded = customer_sbus_function(addr, reg_addr, command, &sbus_data);
then all you need to do in AAPL 2.2 and later is

1. Update your function to include Aapl_t * as the first parameter. If you do not
   need anything from the struct, you can make this input a void * and ignore it.
2. Call the registration function (as shown in the section below) with the name
   of the function.

Your code to use AAPL would then be:

        Aapl_t *aapl = aapl_construct(); /* Create AAPL struct */

        /* note: open and close functions are optional */
        aapl_register_sbus_fn(aapl, &customer_sbus_function, &my_open, &my_close);

        /* insert code to override runtime variables, such as aapl->sbus_rings, etc */
        /* aapl->sbus_rings = 3; */

        aapl_connect(aapl,0,0); /* calls open (if supplied in the user registration function) */
        aapl_get_ip_info(aapl, reset);
        ... code here ...
        aapl_destruct(aapl);



USING USER SUPPLIED COMMUNICATION METHODS
=========================================
The following modes are supported via user registered functions. When calling
the user registration functions, the aapl->communication mode is set
automatically.

After one of the following registration functions are called, all
communications with the device will be done using that communication method.
Only one of these should be called.

    1. AVAGO_SBUS       -- aapl_register_sbus_fn()
    2. AVAGO_MDIO       -- aapl_register_mdio_fn()
    3. AVAGO_I2C        -- aapl_register_i2c_fn()
    4. AVAGO_JTAG       -- aapl_register_jtag_fn()
    5. AVAGO_BB_JTAG    -- aapl_register_bit_banged_jtag_fn()

See the prototypes for these functions in include/aapl_core.h to see what
function types AAPL is expecting for each of these registration functions.

The following registration function is optional, and allows SPICO interrupts to
be sent directly to a SerDes. If you have implemented a core interface to send
SerDes interrupts directly to a SerDes, register that function here.
If this function is not registered, SBus commands will be used to send
interrupts to SerDes, using the communication method registered above.

    aapl_register_spico_int_fn()

The following registration function is also optional, and allows the user
to register a function which returns the JTAG IDCODE for a specific device. 

    aapl_register_jtag_idcode_fn()

To configure and use AAPL with a user supplied function, do the following:

    Aapl_t *aapl = aapl_construct();

    /* Call one of the five registration functions listed above to register */
    /* your communication method. */
    /* For example to register an SBus function (the most common communication */
    /* method), call something like: */
    /*      aapl_register_sbus_fn(aapl, &my_sbus, &my_open, &my_close); */
    /* */
    /* The my_sbus() function must have the following prototype (as shown in */
    /* aapl_register_sbus_fn() from include/aapl_core.h)  */
    /* */
    /* uint (* sbus_fn)(Aapl_t *, uint addr, unsigned char reg_addr,  */
    /*     unsigned char command, uint *sbus_data); */
    /* */
    /* */
    /* NOTE: Calling a registration function is not required if using any of */
    /* AAPL's built in communication methods.  See the section above regarding */
    /* built-in communication methods for more details. */

    aapl_register_*_fn(aapl,...); /* see list above. */

    /* Optional: if applicable, register a SPICO interrupt function: */
    aapl_register_spico_int_fn(aapl, &my_interrupt_fn);

    aapl_connect(aapl,0,0); /* calls the open supplied to function registration */
    ... code here ...
    aapl_destruct(aapl); /* call the close supplied to function registration */


LOW LEVEL DETAILS
=================

FYI: This is mostly internal documentation here -- the user should generally not
need to know this level of detail.

Here is the calling stack for various AAPL functions. Functions with the "aapl->"
prefix indicate that a registered function is called.  Functions below that are
then the possible built-in functions that may be registered depending on what
registration function was called.

avago_spico_int()
    aapl->serdes_int_fn() /* Default: avago_serdes_spico_int_sbus_fn(), which */
                          /* sends sbus commands to invoke interrupts. */

avago_sbus_rd()           /* */
avago_sbus_wr()           /* These all call the registered sbus function. */
avago_sbus()              /* */
    aapl->sbus_fn() /* This can be supplied directly by the user.  Or */
                    /* one of several built-in versions are registered */
                    /* automatically: */
        avago_aacs_sbus_fn() /* Registered if using AACS communication method. */
        avago_i2c_sbus_fn()  /* Registered if using I2C communication method. */
        avago_mdio_sbus_fn() /* Registered if using MDIO communication method. */
        avago_jtag_sbus_fn() /* Registered if using JTAG communication method. */

avago_aacs_sbus_fn()
avago_i2c_sbus_fn()
    avago_i2c_read()
        aapl->i2c_read()
            /* If AVAGO_I2C, default is avago_aacs_i2c_read_fn */
            /* If AVAGO_SYSTEM_I2C, default is avago_system_i2c_read_fn */
    avago_i2c_write
        aapl->i2c_write()
            /* If AVAGO_I2C, default is avago_aacs_i2c_write_fn */
            /* If AVAGO_SYSTEM_I2C, default is avago_system_i2c_write_fn */
avago_mdio_sbus_fn()
    avago_mdio()
        aapl->mdio_fn()
            /* If AACS_MDIO, default is avago_aacs_mdio_fn() */
avago_jtag_sbus_fn()
    avago_jtag()
        aapl->jtag_fn()
            /* If AVAGO_JTAG, default is avago_aacs_jtag_fn() */

#endif
