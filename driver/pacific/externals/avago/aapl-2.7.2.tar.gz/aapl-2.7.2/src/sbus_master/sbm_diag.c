/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* AAPL (ASIC and ASSP Programming Layer) diagnostics */

/** Doxygen File Header */
/** @file */
/** @brief Functions for API-level diagnostics. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_DIAG

/** @brief  Reads the data from IMEM of Sbus master. */
/** @return Returns 0 on success, aapl->return_code (< 0) on error. */
BOOL avago_sbm_imem_read(
    Aapl_t *aapl,       /**< [in]  Pointer to Aapl_t structure. */
    uint sbus_addr,     /**< [in]  Device address number. */
    uint start_addr,    /**< [in]  Start address of IMEM. */
    uint *imem,         /**< [out] Data read from IMEM. */
    uint imem_length)   /**< [in]  Lenght of IMEM. */
{
    uint i;
    int return_code = aapl->return_code;

    avago_sbus_rmw(aapl, sbus_addr, 0x05, 0x01, 0x01); /* stop processor */
    avago_sbus_rmw(aapl, sbus_addr, 0x01, 0x200, 0x200); /* stop processor */
    for( i = 0; i < imem_length; i++ )
    {
        avago_sbus_wr(aapl, sbus_addr, 0x03, start_addr + i);
        imem[i] = avago_sbus_rd(aapl, sbus_addr, 0x09) & 0xffff;
    }
    avago_sbus_rmw(aapl, sbus_addr, 0x01, 0x000, 0x200); /* stop processor */
    avago_sbus_rmw(aapl, sbus_addr, 0x05, 0x00, 0x01); /* resume processor */

    return return_code == aapl->return_code;
}

static void sbm_dump(Aapl_t *aapl, uint sbus_addr, uint imem)
{
    int addr;
    int page_width = 16;
    char * buf;
    int stop_addr = 0;
    int buf_len;
    int old_reg1, old_reg5;
    stop_addr = (imem) ? (24 * 1024 - 1) : (9 * 1024 -1) ; /* 24k imem or 9k dmem */

    if (! (buf = (char *) aapl_malloc(aapl, page_width * 40 * stop_addr, __func__))) return;
    buf_len = sprintf(buf, "0x%04x: ", 0);

    old_reg5 = avago_sbus_rmw(aapl, sbus_addr, 0x05, 0x01, 0x01); /* stop processor */
    if( imem ) old_reg1 = avago_sbus_rmw(aapl, sbus_addr, 0x01, 0x240, 0x2c0); /* Enable IMEM access */
    else       old_reg1 = avago_sbus_rmw(aapl, sbus_addr, 0x01, 0x440, 0x4c0); /* Enable DMEM access */
    for (addr = 0; addr<=stop_addr; addr++)
    {
        uint data;
        if (!(addr % page_width) && addr > 0)
        {
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%s\n", buf);
            buf_len = sprintf(buf,"0x%04x: ", addr);
        }
        if( imem )
        {
            avago_sbus_wr(aapl, sbus_addr, 0x03, addr);
            data = avago_sbus_rd(aapl, sbus_addr, 0x09);
        }
        else
        {
            if( addr < 1024 )  /* upto 1k address, read memory directly */
            {
                avago_sbus_wr(aapl, sbus_addr, 0x04, addr);
                data = avago_sbus_rd(aapl, sbus_addr, 0x09) >> 16;
            }
            else if( addr == 1024 )  /* after 1k address, read memory indirectly */
            {
                avago_sbus_wr(aapl, sbus_addr, 0x01, old_reg1);    /* restore reg1 */
                avago_sbus_wr(aapl, sbus_addr, 0x05, old_reg5);    /* restore reg5 / resume processor */
                if( (old_reg5 & 1) || (old_reg1 & 0x100) == 0 )
                {
                    buf_len += sprintf(buf+buf_len-1, " Cannot read extended dmem (addresses >= 0x400) without firmware.\n");
                    break;  /* Cannot read more if SPICO is not running */
                }
                data = avago_sbm_read_mem(aapl, sbus_addr, addr);
            }
            else
                data = avago_sbm_read_next_mem(aapl, sbus_addr);
        }
        buf_len += sprintf(buf+buf_len, "%04x ", data & 0xffff);
    }
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%s\n", buf);
    if( imem )
    {
        avago_sbus_wr(aapl, sbus_addr, 0x01, old_reg1);    /* restore reg1 */
        avago_sbus_wr(aapl, sbus_addr, 0x05, old_reg5);    /* restore reg5 / resume processor */
    }

    aapl_free(aapl, buf, __func__);
}

/** @brief   Dumps IMEM data of Sbus master. */
/** @return  void. */
/** @see     sbm_dump(), avago_sbm_dmem_dump(). */
void avago_sbm_imem_dump(
    Aapl_t *aapl,   /**< [in] Pointer to AAPL structure. */
    uint addr)      /**< [in] Device address number. */
{
    sbm_dump(aapl, addr, 1);
}

/** @brief   Dumps DMEM data of Sbus master. */
/** @return  void. */
/** @see     sbm_dump(), avago_sbm_imem_dump(). */
void avago_sbm_dmem_dump(
    Aapl_t *aapl,   /**< [in] Pointer to AAPL structure. */
    uint addr)      /**< [in] Device address number. */
{
    sbm_dump(aapl, addr, 0);
}

/** @brief   Dumps ROM data of Sbus master. */
/** @return  void. */
void avago_sbm_rom_dump(
    Aapl_t *aapl,    /**< [in] Pointer to AAPL structure. */
    uint sbus_addr)  /**< [in] Device address number. */
{
    int addr;
    int page_width = 4;
    char * buf;
    int stop_addr = 24 * 1024 - 1; /* 24k memory */
    int initial_addr_30, buf_len;

    if (! (buf = (char *) aapl_malloc(aapl, page_width * 10 * stop_addr, __func__))) return;
    buf_len = sprintf(buf, "0x%04x: ", 0);

    initial_addr_30 = avago_sbus_rmw(aapl, sbus_addr, 0x30, 0x04, 0x04);
    for (addr = 0; addr<=stop_addr; addr++)
    {
        int high, low;
        if (!(addr % page_width) && addr > 0)
        {
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%s\n", buf);
            buf_len = sprintf(buf,"0x%04x: ", addr);
        }
        avago_sbus_wr(aapl, sbus_addr, 0x35, 0x30000 | addr);
        high = avago_sbus_rd(aapl, sbus_addr, 0x37);
        low = avago_sbus_rd(aapl, sbus_addr, 0x36);
        buf_len += sprintf(buf+buf_len, "%01x %02x %02x %08x (%03x %03x %03x)  ", (low >> 30) & 0x3, (high >> 8) & 0xff, high & 0xff, low, low & 0x3ff, (low >> 10) & 0x3ff, (low >> 20) & 0x3ff);
    }
    aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "%s\n", buf);
    avago_sbus_wr(aapl, sbus_addr, 0x30, initial_addr_30);

    aapl_free(aapl, buf, __func__);
}

#endif /* AAPL_ENABLE_DIAG */
