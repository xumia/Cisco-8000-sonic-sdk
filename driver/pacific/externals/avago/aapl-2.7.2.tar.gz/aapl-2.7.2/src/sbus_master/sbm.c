/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* Support for AAPL (ASIC and ASSP Programming Layer) handling of SBus */
/* Master. */

/** Doxygen File Header */
/** @file */
/** @brief SBus Master / Controller functions. */

#include "aapl.h"

/** @brief   Gets the SBus clock divider value. */
/** @details The SBus clock frequency is set to the ref clock frequency */
/**          divided by the sbus clock divider. */
/**          Normally, a power of two is used, but this is not required. */
/** @return  On success, returns the SBus clock divider value. */
/**          On error, decrements aapl->return_code and returns -1. */
int avago_sbm_get_sbus_clock_divider(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr)          /**< [in] Device address, only chip & ring parts used. */
{
    int return_code = aapl->return_code;
    int divider = (int)avago_sbus_rd(aapl, addr = avago_make_sbus_controller_addr(addr), 0x0a);

    if( divider & (1 << 7) )    /* If non 2^n clock divider */
    {
        /* Read divider value: */
        divider = avago_sbus_rd(aapl, addr, 0x0b);
        divider++;
    }
    else
    {
        /* convert exponent to value: */
        divider = (divider >= 12) ? 4096 : (1 << divider);
    }
    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus %s, divider %u\n",aapl_addr_to_str(addr),divider);
    return return_code == aapl->return_code ? divider : -1;
}

/** @brief   Sets the SBus clock divider. */
/** @details The SBus clock frequency is the ref clock frequency */
/**          divided by the sbus clock divider. */
/**          Normally, a power of two is used, but this is not required. */
/**          Valid divider range is [1..4096]. */
/** @return  On success, returns 0. */
/**          On error, decrements aapl->return_code and returns -1. */
int avago_sbm_set_sbus_clock_divider(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr,          /**< [in] Device address, only chip & ring parts used. */
    uint divider)       /**< [in] New sbus divider value in range [1-4096]. */
{
    int return_code = aapl->return_code;
    uint exponent;
    addr = avago_make_sbus_controller_addr(addr);

    if( divider == 0 || divider > 4096 )
        return aapl_fail(aapl,__func__,__LINE__,"SBus %s, divider %u is out of valid range [1-4096].\n",aapl_addr_to_str(addr),divider);

    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus %s, divider %u\n",aapl_addr_to_str(addr),divider);

    /* Determine the smallest 2^exponent value > divider: */
    for( exponent = 1; (divider >> exponent) != 0; exponent++ )
        continue;
    if( (divider & (divider - 1)) == 0 ) /* Test if only one bit set in value */
    {
        /* Only one bit set: it was the next smaller exponent. */
        exponent--;
        /* Set bit position (exponent) into register 0x0A [3:0]: */
        avago_sbus_wr(aapl, addr, 0x0a, exponent);
    }
    else
    {
        /* Set arbitrary divider value: */
        avago_sbus_wr(aapl, addr, 0x0a, exponent);            /* Clears bit 7 */
        avago_sbus_wr(aapl, addr, 0x0b, divider - 1);         /* Call before setting bit 7 */
        avago_sbus_wr(aapl, addr, 0x0a, exponent | 0x0080);   /* Set bit 7 */
    }
    return return_code == aapl->return_code ? 0 : -1;
}


/*============================================================================= */
/* SBM GET TEMP DATA */
/** @brief  Gets the temperature data from a given AVAGO_THERMAL_SENSOR sensor */
/** @return Returns the temperature in milli-degrees C. */
/**         On error, returns 999999. */
/** @details Verifies that the process is 28nm, the #sensor_addr is */
/**          AVAGO_THERMAL_SENSOR, and the SBus Master SPICO for the sensor */
/**          is running, then issues the get_temp_data interrupt. */
/**          Takes the resulting 12b signed value and converts it to an integer. */
/** */
/** NOTE: THIS API IS INCOMPLETE AND SUBJECT TO CHANGE IN A FUTURE RELEASE. */
int avago_sbm_get_temperature(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint sensor_addr,   /**< [in] SBus address of the AVAGO_THERMAL_SENSOR */
    uint sensor)        /**< [in] Which sensor to get data for. */
{
    const int invalid_data = 999999;
    int data;
    Avago_addr_t addr_struct;
    uint addr = avago_make_sbus_master_addr(sensor_addr);

    if (!aapl_check_process(aapl, addr, __func__, __LINE__, TRUE, 2, AVAGO_TSMC_16, AVAGO_TSMC_28)) return invalid_data;
    if (!aapl_check_ip_type(aapl, sensor_addr, __func__, __LINE__, TRUE, 1, AVAGO_THERMAL_SENSOR))  return invalid_data;

    if( !avago_spico_running(aapl,addr) )
        return invalid_data;  /* spico not running return a bogus temp */

    avago_addr_to_struct(sensor_addr,&addr_struct);
    data = avago_spico_int(aapl, addr, 0x17, (sensor << 12) | (addr_struct.sbus & 0xff) );
    /* result is a 12b signed value in 1/8 degree increments */
    if( data & 0x8000 )
    {  /* bit[15] indicates result is good */
        data &= 0x0FFF;     /* Mask down to 12b temp value */
        if (data & 0x0800)  /* Negative 12b temp value, do sign extension */
            data = -1 * (((~data) & 0x0FFF) + 1);
        return data * (1000 / 8);   /* Scale to milli-degrees. */
    }
    return invalid_data;  /* Temperature not valid */
}

/** @brief   Write 16 bit data to dmem address mem_addr. */
/** @details Valid addresses are 0-1023 (0x0000-0x03FF). */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */

static int sbm_write_dmem(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] Device address, only chip & ring parts used. */
    uint mem_addr,  /**< [in] Memory location to write. */
    uint data)      /**< [in] 16-bit data to write. */
{
    int return_code = aapl->return_code;
    addr = avago_make_sbus_master_addr(addr);
    avago_spico_int(aapl, addr, 0x0011, mem_addr); /*write the dmem address */
    avago_spico_int(aapl, addr, 0x0012, data);     /*write the dmem data */
    return return_code == aapl->return_code ? 0 : -1;
}

/** @brief   Read the next 16 bit datum. */
/** @details Use with sbm_read_mem to efficiently read a block of memory. */
/** @return  Datum. On failure, aapl->return_code is decremented. */

uint avago_sbm_read_next_mem(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Device address, only chip & ring parts used. */
{
    return avago_spico_int(aapl, avago_make_sbus_master_addr(addr), 0x3, 0x13);
}

/** @brief   Read 16 bit datum from dmem address mem_addr. */
/** @details Valid addresses are 0-9216 (0x0000-0x23ff). */
/**          Use with sbm_read_next_mem to efficiently read a block of memory. */
/** @return  Datum. On failure, aapl->return_code is decremented. */

uint avago_sbm_read_mem(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,     /**< [in] Device address, only chip & ring parts used. */
    uint mem_addr)      /**< [in] Memory location to read. */
{
    sbm_write_dmem(aapl, sbus_addr, 0x12, mem_addr); /* Write mem_addr location into 0x12 */
    return avago_sbm_read_next_mem(aapl, sbus_addr);
}

/** @brief   Writes 16 bit datum to SBusMaster memory. */
/** @details Valid addresses are in the range [0..9215]. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */

int avago_sbm_write_mem(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr,          /**< [in] Device address, only chip & ring parts used. */
    uint mem_addr,      /**< [in] Memory location to write. */
    uint data)          /**< [in] 16-bit data to write. */
{
    int return_code = aapl->return_code;
    if( mem_addr < 1024 )
        return sbm_write_dmem(aapl, addr, mem_addr, data);
    /* Writes to dmem location 0x13 are redirected to the memory location */
    /*   stored in dmem location 0x12.  So we write our xdmem address */
    /*   to location 12.  But to do that, we must set the dmem address (12) */
    /*   using int 0x11.  Since we are writing to dmem addresses 12 and 13 */
    /*   sequentially, we do the write to 12 with auto increment, so the */
    /*   next write goes to 13 and indirectly to xdmem. */
    addr = avago_make_sbus_master_addr(addr);
    avago_spico_int(aapl, addr, 0x11, 0x12);     /* select 0x12 for write */
    avago_spico_int(aapl, addr, 0x13, mem_addr); /* write mem_addr to 0x12++ */
    avago_spico_int(aapl, addr, 0x12, data);     /* write xdmem data to 0x13 */
    return return_code == aapl->return_code ? 0 : -1;
}


/** @brief   Retrieves the SBus Master firmware revision. */
/** */
/** @return  Firmware revision. On error, aapl->return_code is set negative. */
uint avago_sbm_get_firmware_rev(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Device address, only chip & ring parts used. */
{
    return avago_firmware_get_rev(aapl, avago_make_sbus_master_addr(addr));
}

/** @brief   Retrieves the SBus Master firmware build id. */
/** */
/** @return  Firmware build id. On error, aapl->return_code is set negative. */
uint avago_sbm_get_firmware_build_id(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Device address, only chip & ring parts used. */
{
    return avago_firmware_get_build_id(aapl, avago_make_sbus_master_addr(addr));
}




/** @brief   Gets the DFE round-robin tuning mode for the given ring. */
/** @details Queries SBus master on the given chip and ring for the */
/**          current round-robin configuration. */
/** @return  Returns the number of parallel round-robins tunes enabled. */
/** @return  A return value of 0 indicates that round-robin is disabled. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_sbm_set_dfe_rr_mode(). */
int avago_sbm_get_dfe_rr_mode(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] SBus chip & ring address. */
{
    int return_code = aapl->return_code;
    int rv;

    addr = avago_make_sbus_master_addr(addr);

    /* RR support added in 0x100E and build id with bit 0 set. */
    if( !aapl_check_firmware_rev(aapl,addr, __func__, __LINE__, FALSE, 1, 0x100E) )
        return 0;

    rv = avago_spico_int(aapl, addr, 0x02b, 0x4000);

    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus Master %s round robin parallel tune count is %#04x\n",aapl_addr_to_str(addr),rv & 0xff);
    return return_code == aapl->return_code ? (rv & 0xff) : -1;
}

/** @brief   Sets the DFE round-robin tuning mode for the given ring. */
/** @details Configures the SBus master to continuously run up to count parallel */
/**          tunes on the specified SBus ring.  Only the SerDes which have */
/**          round-robin tuning enabled will participate. */
/**          Set count to 0 to disable round-robin tuning on the ring. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_sbm_get_dfe_rr_mode(). */
int avago_sbm_set_dfe_rr_mode(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] SBus chip & ring address. */
    int count)      /**< [in] Maximum number of parallel tunes. */
{
    int return_code = aapl->return_code;
    int cmd = (count == 0) ? 0 : (0x8000 | count);
    int rv;

    addr = avago_make_sbus_master_addr(addr);

    /* RR support added in 0x100E and build id with bit 0 set. */
    if( !aapl_check_firmware_rev(aapl,addr, __func__, __LINE__, TRUE, 1, 0x100E) )
        return -1;

    if( count < 0 || count > 255 )
        return aapl_fail(aapl,__func__,__LINE__,"SBus Master %s, number of parallel tunes %d is out of valid range [1-255].\n",aapl_addr_to_str(addr),count);

    rv = avago_spico_int (aapl, addr, 0x02b, cmd);
    if( rv != cmd )
        return aapl_fail(aapl,__func__,__LINE__,"SBus Master %s, failed to initialize round robin to %#06x, instead returned 0x%#010x\n",aapl_addr_to_str(addr),cmd,rv);

    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus Master %s, parallel tune count %d\n",aapl_addr_to_str(addr),count);
    return return_code == aapl->return_code ? 0 : -1;
}


#if AAPL_ENABLE_MAIN
#include "timer.h"

/** @brief   Measures the reference clock frequency */
/** @details Uses a counter in the SBus master and a high resolution timer on */
/**          on the machine running AAPL to compute the reference clock frequency. */
/** @return  Returns the reference clock frequency, in kHz. */
int avago_sbm_get_refclk(
    Aapl_t *aapl,
    uint addr)
{
    int loop_count = 0;
    int delay = 7;
    int loops = 0;
    int sbus_div = avago_sbm_get_sbus_clock_divider(aapl, addr);
    int skip_next = 0;
    int time_prev = 0;
    unsigned long first_time = 0;
    unsigned long second_time = 0;
    unsigned long third_time = 0;
    int cism_count = 0;
    int freq = 0;
    int max_cmds = aapl->max_cmds_buffered;
    aapl->max_cmds_buffered = 0; /* to prevent batching */

    while (delay < 31 && loop_count++ < 50)
    {
        long time = 0;  /* Must not be unsigned or chance of core dump */
        unsigned long temp;
        int data = 0;
        int rc;
        int sbc = avago_make_sbus_controller_addr(addr);
        Aapl_microtimer_t timer;
        loops = 0;

        if (!skip_next) delay += 1;
        avago_sbm_set_sbus_clock_divider(aapl, addr, sbus_div); /* sometimes this seems to get reset below, so always write it */

        /* Write all CISM registers as other code may use them: */
        avago_sbus_wr(aapl, sbc, 0x01, delay);
        avago_sbus_wr(aapl, sbc, 0x10, 0xfe); /* send commands to sbc */
        avago_sbus_wr(aapl, sbc, 0x11, 0x01); /* write command */
        avago_sbus_wr(aapl, sbc, 0x12, 0xff); /* write address 0xff (ie do nothing) */
        avago_sbus_wr(aapl, sbc, 0x13, 0x1a); /* write value 0x1a to 0xff (ie do nothing) */
        avago_sbus_wr(aapl, sbc, 0x14, 0x01); /* write command */
        avago_sbus_wr(aapl, sbc, 0x15, 0x13); /* write address 0x13 */
        avago_sbus_wr(aapl, sbc, 0x16, 0xff); /* write value 0xff to 0x13 */

        avago_sbus_wr(aapl, sbc, 0x00, 0x00); /* clear CISM start */
        AAPL_SUPPRESS_ERRORS_PUSH(aapl); /* we may get errors from the HS1 when the CISM completes, so ignore them */
        rc = aapl->return_code;
        aapl_timer_reset(&timer);
        aapl_timer_start(&timer);
        avago_sbus_wr(aapl, sbc, 0x00, 0x01); /* start the CISM */

        while ((temp = aapl_timer_get(&timer)) < 2000000)
        {
            data = avago_sbus_rd(aapl, sbc, 0x13); /* read result */
            if (data == 0xff || data == 0x87 || rc != aapl->return_code) break; /* quit when done or error detected */
            loops++;
        }
        time = (long)aapl_timer_get(&timer); /* get final time */
        AAPL_SUPPRESS_ERRORS_POP(aapl);

        if (skip_next) {skip_next = 0; continue;} /* repeat this delay again if we were to skip */
        if ((data != 0xff || rc != aapl->return_code) || (third_time != 0 && (time-temp) > first_time * 3 / 2))
        {
            skip_next = 1; /* if there was an error, skip the next value to help things settle */
            delay -= 1; /* repeat this delay value */
            aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "Refclk measurement failed: %d %d (%d %d %d) %x\n", rc, aapl->return_code, time, temp, first_time, data);
            continue;
        }

        /* first_time, second_time and third_time are used to find the median */
        /* of the first three accepted round-trip times, as a measure of fixed */
        /* communication overhead, which is used to improve accuracy of the */
        /* cism timer delay measurement. */
        if( first_time == 0 )
            first_time = (time + time_prev) / 2;
        else if( second_time == 0 )
            second_time = (time + time_prev) / 2;
        else if( third_time == 0 )
        {
            third_time = (time + time_prev) / 2;
            if( first_time < second_time && second_time < third_time )
                first_time = second_time;
            else if( first_time > second_time && second_time > third_time )
                first_time = second_time;
            else if( first_time < third_time && third_time < second_time )
                first_time = third_time;
            else if( first_time > third_time && third_time > second_time )
                first_time = third_time;
        }
        time_prev = time;
        time -= first_time;
        if( time < 1000 )
            continue;

        cism_count = (sbus_div << delay); /* + 39500; */

        freq = cism_count / ((time+50) / 100) * 10;

        if (time > 200000) break;
        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Delay setting: %3d Total div: %10d Loops: %3d Time: %5dms Freq: %dkHz\n", delay, cism_count, loops, time_prev/1000, freq);
    }
    aapl->max_cmds_buffered = max_cmds; /* restore value */
    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Delay setting: %3d Total div: %10d Loops: %3d Time: %5dms Freq: %dkHz\n", delay, cism_count, loops, time_prev/1000, freq);
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Refclk freq: %dkHz, Total loop count: %d\n", freq, loop_count);
    return freq;
}

#endif /* AAPL_ENABLE_MAIN */
