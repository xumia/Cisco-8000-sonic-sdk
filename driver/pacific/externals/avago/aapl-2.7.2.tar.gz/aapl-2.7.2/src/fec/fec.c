/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* Support for AAPL (ASIC and ASSP Programming Layer) generic handling of */
/* SerDes (Serializer/Deserializer) slices on ASIC SBus rings. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS

#undef AAPL_FEC_SIMULATION
#ifdef AAPL_FEC_SIMULATION
#define HOST_ALIGNER_SBUS_ADDR  0x1
#define HOST_D6_SBUS_ADDR       0x2
#define CM4_SBUS_START_ADDR     0x3
#define FIRST_CM4_SBUS_ADDR     CM4_SBUS_START_ADDR
#define SECOND_CM4_SBUS_ADDR    (CM4_SBUS_START_ADDR + 1)
#define MOD_ALIGNER_SBUS_ADDR   0x5
#define RSFEC_528_544_SBUS_ADDR 0x7
#define CONTROL_LOGIC_SBUS_ADDR 0x8
#else
#define HOST_ALIGNER_SBUS_ADDR  0x3
#define HOST_D6_SBUS_ADDR       0x4
#define CM4_SBUS_START_ADDR     0x8
#define FIRST_CM4_SBUS_ADDR     CM4_SBUS_START_ADDR
#define SECOND_CM4_SBUS_ADDR    (CM4_SBUS_START_ADDR + 1)
#define MOD_ALIGNER_SBUS_ADDR   0xA
#define RSFEC_528_544_SBUS_ADDR 0xE
#define CONTROL_LOGIC_SBUS_ADDR 0xF
#endif

#include "aapl.h"

/** @file   fec.c */
/** @brief  Generic SerDes functions. */
/** @defgroup FEC Generic API */
/** @{ */

/*============================================================================= */
/* Single lane PCS configuration */

/** @brief Single lane PCS configuration */
/** @return void */
/** @details Single lane PCS configuration */
static void avago_fec_config_pcs(
    Aapl_t *aapl,                  /**< [in] Pointer to Aapl_t structure. */
    uint addr,                     /**< [in] SBus address of FEC */
    Avago_fec_config_options_t fec_config_options, /**< [in] FEC config options */
    Avago_fec_config_t *fec_config /**< [in] Pointer to FEC config structure. */
)
{
    /* TBD */
    (void)fec_config;
    (void)fec_config_options;
    avago_sbus_rd(aapl, addr, 0xd0);
}

/*============================================================================= */
/* MLD configuration */

/** @brief MLD configuration */
/** @return void */
/** @details MLD configuration */
static void avago_fec_config_mld(
    Aapl_t *aapl,                   /**< [in] Pointer to Aapl_t structure. */
    uint addr,                      /**< [in] SBus address of FEC */
    Avago_fec_config_options_t fec_config_options, /**< [in] FEC config options */
    Avago_fec_config_t *fec_config  /**< [in] Pointer to FEC config structure. */
)
{
    /* TBD */
    (void)fec_config;
    (void)fec_config_options;
    avago_sbus_rd(aapl, addr, 0xd0);
}

/*============================================================================= */
/* Sapphire fec bridge configuration */
/** @brief Sapphire fec bridge configuration */
/** @return void */
/** @details Sapphire fec bridge configuration */
static void avago_fec_config_rsfec_bridge(
    Aapl_t *aapl,                  /**< [in] Pointer to Aapl_t structure. */
    uint addr,                     /**< [in] SBus address of FEC */
    Avago_fec_config_options_t fec_config_options, /**< [in] FEC config options */
    Avago_fec_config_t *fec_config /**< [in] Pointer to FEC config structure. */
)
{
    /* TBD */
    (void)fec_config;
    (void)fec_config_options;
    avago_sbus_rd(aapl, addr, 0xd0);
}

/*============================================================================= */
/* Tesla/Opal Core logic fec configuration */

/** @brief Tesla/Opal Core logic fec configuration */
/** @return void */
/** @details Tesla/Opal Core logic fec configuration */
static void avago_fec_config_rsfec_core(
    Aapl_t *aapl,                  /**< [in] Pointer to Aapl_t structure. */
    uint addr,                     /**< [in] SBus address of FEC */
    Avago_fec_config_options_t fec_config_options, /**< [in] FEC config options */
    Avago_fec_config_t *fec_config /**< [in] Pointer to FEC config structure. */
)
{
    int i;
    int data=0;

    switch(fec_config_options)
    {
        case AVAGO_FEC_CFG_ERR_COR_BYPASS:
            /* Read capability register */
            data = avago_sbus_rd(aapl, addr, 0xd0);

            /* Configuration for bypassing the error correction only when there is an error correction bypass ability */
            if ( (data & 0x04) && fec_config->error_correct_bypass_enable )
            {
                /* Decoder performs error detection without error correction */
                data |= 0x08;
                /* If there is a error indication disable ability feature available */
                if(data & 0x01)
                {
                   /* Make sure error indication should be enabled when bypassing the error correction */
                   data &= ~(0x02);
                }
            }
            /* If error correct bypass is disable */
            else if( (data & 0x04) && !fec_config->error_correct_bypass_enable )
            {
                /* Disable the error correct bypass */
                data &= ~(0x08);
            }
            /* Load the error correction bypass and error indication */
            avago_sbus_wr(aapl, addr, 0xd0, data);
            break;

            case AVAGO_FEC_CFG_ERR_INDICATION:
            /* Read capability register */
            data = avago_sbus_rd(aapl, addr, 0xd0);

            /* If error indication disable */
            if ( (data & 0x01) && !fec_config->error_indication_enable )
            {
                /* Disable the error indication */
                data |= 0x02;
                /* If there is a bypass error correction ability feature available */
                if(data & 0x04)
                {
                    /* Make sure we should disable the bypass error correction */
                    data &= ~(0x08);
                }
            }
            /* If error indication enable */
            else if ( (data & 0x01) && fec_config->error_indication_enable )
            {
                data &= ~(0x02);
            }

            /* Load the error correction bypass and error indication */
            avago_sbus_wr(aapl, addr, 0xd0, data);
            break;

        case AVAGO_FEC_CFG_LANE_TRACK:
            /* Read capability register */
            data = avago_sbus_rd(aapl, addr, 0xd0);

            /* configure lane mask */
            for(i=0; i<4; i++)
            {
                if(fec_config->consec_lane_track_enable[i])
                {
                    data |= 1U << (20+i);
                }
                else
                {
                    data &= ~(1 << (20+i));
                }
            }
            /* Load the consec lane enables */
            avago_sbus_wr(aapl, addr, 0xd0, data);
            break;

        case AVAGO_FEC_CFG_CLR_ON_READ:
            /* Set the clear_on_read bit to the desired setting */
            avago_sbus_rmw(aapl, addr, 0xee, fec_config->stats_clear_on_read ? 2 : 0, 0x2);
            break;

        case AVAGO_FEC_CFG_MODE:
            /* Set the RSFEC mode */
            data = (fec_config->mode == AVAGO_FEC_RS528) ? 0x2 : 0x4;
            avago_sbus_rmw(aapl, CONTROL_LOGIC_SBUS_ADDR, 0x0, data, 0x2);
            break;
    }
    return;
}

/*============================================================================= */
/* FEC get count information */

/** @brief Get FEC count information */
/** @return Count information */
/** @details Get FEC count information */
static uint fec_get_count(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] SBus address of FEC */
    uint daddr,     /**< [in] TODO */
    uint regs,      /**< [in] TODO */
    uint shift      /**< [in] TODO */
)
{
    uint i;
    uint count = 0;

    /* maybe spread over multiple regs, assume they're consecutive */
    for(i=0; i<regs; i++)
    {
        count += (avago_sbus_rd(aapl, addr, daddr+i) << (i*shift));
    }
    return count;
}

/*============================================================================= */
/* FEC CONFIG CONSTRUCTOR */
/* */
/** @brief Creates a Avago_fec_config_t */
/** @return Avago_fec_config_t struct */
/** @details mallocs the memory for a Avago_fec_config_t and returns a pointer */
/** to that memory location. */
Avago_fec_config_t *avago_fec_config_construct(
    Aapl_t *aapl /**< [in] Pointer to Aapl_t structure. */
)
{
    Avago_fec_config_t * fec_config;
    size_t bytes = sizeof(Avago_fec_config_t);

    if(! (fec_config = (Avago_fec_config_t *) aapl_malloc(aapl, bytes, __func__)))
    {
        return(NULL);
    }
/* set all bytes to zero */
    memset(fec_config, 0, sizeof(*fec_config));

    return(fec_config);
}

/*============================================================================= */
/* FEC CONFIG DESTRUCTOR */
/* */
/** @brief Destroys the provided Avago_fec_config_t struct. */
/** @details Frees the memory pointed to by the provided Avago_fec_config_t struct. */
/** @return void */
void avago_fec_config_destruct(
    Aapl_t *aapl,                  /**< [in] Pointer to Aapl_t structure. */
    Avago_fec_config_t *fec_config /**< [in] Struct to destruct/free. */
)
{
    aapl_free(aapl, fec_config, __func__);
}

/*============================================================================= */
/* FEC CONFIG */
/* */
/** @brief Configures the FEC engine */
/** @details Configures the addressed FEC engine based on the parameters */
/**          set in the configure struct */
/** @return void */
void avago_fec_config(
    Aapl_t *aapl,                   /**< [in] Pointer to Aapl_t structure. */
    uint    addr,                   /**< [in] SBus address of FEC. */
    Avago_fec_config_options_t fec_config_options, /**< [in] FEC config options */
    Avago_fec_config_t *fec_config) /**< [in] Pointer to FEC config structure. */
{
    if(!aapl_check_ip_type( aapl, addr, __func__, __LINE__, TRUE, 5,
                           AVAGO_PCS64B66B_FEC,
                           AVAGO_MLD,
                           AVAGO_RSFEC_BRIDGE,
                           AVAGO_OPAL_RSFEC528,
                           AVAGO_OPAL_RSFEC528_544
                          )
    )
    {
        return;
    }

    switch(aapl_get_ip_type(aapl, addr))
    {
        case AVAGO_PCS64B66B_FEC:
            avago_fec_config_pcs(aapl, addr, fec_config_options, fec_config);
            break;

        case AVAGO_MLD:
            avago_fec_config_mld(aapl, addr, fec_config_options, fec_config);
            break;

        case AVAGO_RSFEC_BRIDGE:
            avago_fec_config_rsfec_bridge(aapl, addr, fec_config_options, fec_config);
            break;

        case AVAGO_OPAL_RSFEC528:
            avago_fec_config_rsfec_core(aapl, addr, fec_config_options, fec_config);
            break;

        case AVAGO_OPAL_RSFEC528_544:
            avago_fec_config_rsfec_core(aapl, addr, fec_config_options, fec_config);
            break;

        default:
            aapl_fail(aapl, __func__, __LINE__, "HOW DID I GET HERE, validated IP type but not in case statement????.\n");
    }
}

/*============================================================================= */
/* FEC GET STATUS */

/** @brief   Retrieve the status of the FEC block */
/** @details Populates the provided stats struct with the current count values */
/** @return  On success, returns updated struct. */
/** @return  On error, decrements aapl->return_code and returns. */
void avago_fec_get_status(
    Aapl_t *aapl,              /**< [in] Pointer to Aapl_t structure. */
    uint addr,                 /**< [in] SBus address of FEC. */
    Avago_fec_status_t *status /**< [out] Pointer to fec status structure. */
)
{
    if(!aapl_check_ip_type( aapl, addr, __func__, __LINE__, TRUE, 5,
                           AVAGO_PCS64B66B_FEC,
                           AVAGO_MLD,
                           AVAGO_RSFEC_BRIDGE,
                           AVAGO_OPAL_RSFEC528,
                           AVAGO_OPAL_RSFEC528_544
                          )
    )
    {
        return;
    }
/* This is disabled by AJOY */
    /*avago_fec_get_stats(aapl, status->stats, addr, lane); */

    if( (aapl_get_ip_type(aapl, addr) == AVAGO_OPAL_RSFEC528_544) ||
        (aapl_get_ip_type(aapl, addr) == AVAGO_OPAL_RSFEC528 )
    )
    {
        int  data;
        int  i;
        status->clear_on_read_active = (avago_sbus_rd(aapl, addr, 238) & 2) ? TRUE : FALSE;

        data = avago_sbus_rd(aapl, addr, 208);
        status->fec_lane_map[0] = (data >>  8) & 0x3;
        status->fec_lane_map[1] = (data >> 10) & 0x3;
        status->fec_lane_map[2] = (data >> 12) & 0x3;
        status->fec_lane_map[3] = (data >> 14) & 0x3;
        status->error_indication_ability     = (data & 0x1) ? TRUE  : FALSE;
        status->error_correct_bypass_ability = (data & 0x4) ? TRUE  : FALSE;
        status->error_indication             = (data & 0x2) ? FALSE : TRUE;
        status->error_correct_bypass         = (data & 0x8) ? TRUE  : FALSE;

        data = avago_sbus_rd(aapl, MOD_ALIGNER_SBUS_ADDR, 22);
        if (aapl_get_ip_type(aapl, addr) == AVAGO_OPAL_RSFEC528)
        {
            data >>= 4; /* Track XL2 alignment status */
        }
        for (i=0; i<4; i++)
        {
            status->fec_align_status[i] = (data & (0x1 << i)) ? TRUE : FALSE;
        }
    }
}

/*============================================================================= */
/* FEC SET STATS HALT */

/** @brief   Configures the stats for RSFEC to halt */
/** @details Sets either the halt_now bit or halt_on_max_count bit based on on_max_count input */
/** @return  If halted returns TRUE, else FALSE */
void avago_fec_set_stats_halt(
    Aapl_t *aapl,  /**< [in] Pointer to Aapl_t structure. */
    uint addr,     /**< [in] SBus address of FEC. */
    BOOL now,      /**< [in] Halt FEC statistics right now */
    BOOL on_max_cw /**< [in] Halt based on on_max_cw otherwise just wait for a counter to max out */
)
{
    if( !aapl_check_ip_type( aapl, addr, __func__, __LINE__, TRUE, 2,
                             AVAGO_OPAL_RSFEC528,
                             AVAGO_OPAL_RSFEC528_544) )
    {
        return;
    }

    if(now)
    {
        /* Set [4] to halt stats right now! */
        avago_sbus_rmw(aapl, addr, 0xee, 0x10, 0x10);
    }
    else
    {
        /* Set [6:5] = 0x3 to halt when on_max_cw otherwise just wait for a counter to max out */
        int data = on_max_cw ? 0x60 : 0x40;
        avago_sbus_rmw(aapl, addr, 0xee, data, 0x60);
    }
    return;
}

/*============================================================================= */
/* FEC GET STATS HALT */

/** @brief   Checks if stats accumulation is halted */
/** @details Checks the HALT_STATUS flag to see if stats gathering is halted. */
/** @return  If halted returns TRUE, else FALSE */
BOOL avago_fec_get_stats_halt(
    Aapl_t *aapl, /**< [in] Pointer to Aapl_t structure. */
    uint addr     /**< [in] SBus address of FEC. */
    )
{
    int data;

    if( !aapl_check_ip_type( aapl, addr, __func__, __LINE__, TRUE, 2,
                             AVAGO_OPAL_RSFEC528,
                             AVAGO_OPAL_RSFEC528_544)
    )
    {
        return FALSE;
    }

    data = avago_sbus_rd(aapl, addr, 0xee);

    if(data & 1)
    {
        return TRUE; /* In reset */
    }
    return (data & 0x80) ? TRUE : FALSE; /* Check halt_status */
}

/*============================================================================= */
/* FEC RESET STATS */

/** @brief   Reset the FEC statistics */
/** @details Based on halt flag clear the halt status if halted otherwise reset counter */
/** @return  void */

void avago_fec_reset_stats(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] SBus address of FEC. */
    BOOL halt_flag  /**< [in] Based on halt_flag clear the halt status if halted otherwise reset counters */
)
{
    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 2,
                AVAGO_OPAL_RSFEC528,
                AVAGO_OPAL_RSFEC528_544)
    )
    {
        return;
    }

    if (halt_flag)
    {
        /* Only clear halt flag if halted */
        if(avago_fec_get_stats_halt(aapl, addr))
        {
            avago_sbus_rmw(aapl, addr, 0xee, 0x04, 0x04); /* Set [2] to clear hdw halt flag */
            avago_sbus_rmw(aapl, addr, 0xee, 0x00, 0x10); /* Remove the halt flag */
        }
    }
    else
    {
        /* Reset statistics */
        Avago_fec_stats_t stats;
        uint cur_reg = avago_sbus_rmw(aapl, addr, 0xee, 0x2, 0x2);  /* Set rs_stats reset High */
        avago_fec_get_stats(aapl, &stats, addr, 4);
        avago_sbus_wr(aapl, addr, 0xee, cur_reg);                   /* Restore */
    }
}

/*============================================================================= */
/* FEC GET STATISTICS */

/** @brief   Retrieve all the stats for the FEC block */
/** @details Populates the provided stats struct with the current count values */
/** @return */
/** @return */

void avago_fec_get_stats(
    Aapl_t *aapl,             /**< [in] Pointer to Aapl_t structure. */
    Avago_fec_stats_t *stats, /**< [out] Pointer to fec statistics structure. */
    uint addr,                /**< [in] SBus address of FEC. */
    uint lane                /**< [in] Lane select for MLD (0-3 Cl74 FEC, 4-RSFEC) */
)
{
    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 5,
                            AVAGO_PCS64B66B_FEC,
                            AVAGO_MLD,
                            AVAGO_RSFEC_BRIDGE,
                            AVAGO_OPAL_RSFEC528,
                            AVAGO_OPAL_RSFEC528_544)
    )
    {
        return;
    }

    stats->codewords    = avago_fec_get_codeword(aapl, addr, lane);
    stats->corrected    = avago_fec_get_corrected(aapl, addr, lane);
    stats->uncorrected  = avago_fec_get_uncorrected(aapl, addr, lane);

    /* RS-FEC engine has extra stats */
    if ((aapl_get_ip_type(aapl, addr) != AVAGO_PCS64B66B_FEC) && (lane >3))
    {
        /* RSFEC */
        uint i;
        uint consec_en = avago_fec_get_consec_lane_active(aapl, addr);
        uint range = 8;
        uint revision_id;
        uint total_cw_fixed = 0;
        stats->codeword_size = 528;
        stats->halted        = avago_fec_get_stats_halt(aapl, addr);

        if( (aapl_get_ip_type(aapl, addr) == AVAGO_OPAL_RSFEC528_544) &&
            (avago_sbus_rd(aapl, CONTROL_LOGIC_SBUS_ADDR, 0x0) & 0x4)
        )
        {
            stats->codeword_size = 544;
        }
        for(i=0; i<4; i++)
        {
            stats->rs_lane_sym_count[i]    = avago_rsfec_get_lane_sym_count(aapl, addr, i);
            stats->rs_sym_consec_active[i] = (consec_en & (1<<i)) ? TRUE : FALSE;
        }

        for(i=2; i<7; i++)
        {
            stats->rs_X_sym_consec[i] = avago_rsfec_get_consec_X_sym_count(aapl, addr, i);
        }

        revision_id = aapl_get_ip_rev(aapl, addr);
        if ( revision_id == 2 )    /* Fermi Chip */
            range = 16;
        else
            range = 8;

        for(i=1; i<range; i++)
        {
            stats->cw_X_sym_count[i]  = avago_rsfec_get_cw_X_sym_count(aapl, addr, i);
            total_cw_fixed += stats->cw_X_sym_count[i];
        }
        if ( revision_id == 2)     /* Fermi Chip */
          stats->corrected = total_cw_fixed;
    }
    else
    {
        /* FIRECODE */
        if( (aapl_get_ip_type(aapl, addr) == AVAGO_PCS64B66B_FEC) ||
            ((aapl_get_ip_type(aapl, addr) == AVAGO_MLD) && (lane <4))
        )
        {
            stats->codeword_size = 2112;
        }
        else
        {
            stats->codeword_size = 0; /* Unknown */
        }
    }
}

/*============================================================================= */
/* FEC GET CONSEC LANE ACTIVE */

/** @brief   Retrieve the field controlling which lanes are monitoring consecutive errors. */
/** @details Returns field that indicates which lanes are enabled for consecutive RS-symbols */
/**          in error counting. */
/** @return */
/** @return */

uint avago_fec_get_consec_lane_active(
    Aapl_t *aapl, /**< [in] Pointer to Aapl_t structure. */
    uint addr     /**< [in] SBus address of FEC. */
)
{
    int  data;
    uint daddr=0;

    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 4,
                            AVAGO_MLD,
                            AVAGO_RSFEC_BRIDGE,
                            AVAGO_OPAL_RSFEC528,
                            AVAGO_OPAL_RSFEC528_544)
    )
    {
        return 0;
    }

    switch( aapl_get_ip_type(aapl, addr) )
    {
        case AVAGO_MLD:
            if(aapl_get_ip_rev(aapl, addr) > 0)
                daddr = 208;
        break;

        case AVAGO_OPAL_RSFEC528:
        case AVAGO_OPAL_RSFEC528_544:
            daddr = 208;
            break;

        default:
            return 0;
    }
    /* if configurable read setting */
    if(daddr != 0)
    {
        data = (avago_sbus_rd(aapl, addr, daddr) >> 20 ) & 0xf;
    }
    else
    {
        data = 0xf;
    }
    return data;
}

/*============================================================================= */
/* FEC GET CODEWORD */

/** @brief   Retrieve the corrected error counter value. */
/** @details Returns FEC error corrected count. */
/**          For the MLD use lane=4 to access quad lane counter. */
/** @return  On success, returns count. */
/** @return  On error, decrements aapl->return_code and returns -1. */

bigint avago_fec_get_codeword(
    Aapl_t *aapl, /**< [in] Pointer to Aapl_t structure */
    uint addr,    /**< [in] SBus address of FEC */
    uint lane     /**< [in] Lane information */
)
{
    bigint value=0;
    uint daddr=0;

    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 5,
                            AVAGO_PCS64B66B_FEC,
                            AVAGO_MLD,
                            AVAGO_RSFEC_BRIDGE,
                            AVAGO_OPAL_RSFEC528,
                            AVAGO_OPAL_RSFEC528_544)
    )
    {
        return 0;
    }

    /* Get base address and number of registers field is split over */
    switch( aapl_get_ip_type(aapl, addr) )
    {
        case AVAGO_PCS64B66B_FEC:
        case AVAGO_RSFEC_BRIDGE:
            return 0;

        /* MLD has CODEWORDS with same bug too, but only for RSFEC */
        case AVAGO_MLD:
            if ( (lane < 4) || (aapl_get_ip_rev(aapl, addr) < 1) )
                return 0;

        /* Opal bug that assigns trigger for bits [47:32] to be 233 instead of 228 */
        case AVAGO_OPAL_RSFEC528:
        case AVAGO_OPAL_RSFEC528_544:
            daddr = 228;
            avago_sbus_rd(aapl, addr, 233);
            break;

        default:
            return 0;
    }
    value += avago_sbus_rd(aapl, addr, daddr);
    value += ((bigint) avago_sbus_rd(aapl, addr, daddr+1) << 32);
    return value;
}

/*============================================================================= */
/* FEC GET CORRECTED */

/** @brief   Retrieve the corrected error counter value. */
/** @details Returns FEC error corrected count. */
/**          For the MLD use lane=4 to access quad lane counter. */
/** @return  On success, returns count. */
/** @return  On error, decrements aapl->return_code and returns -1. */
uint avago_fec_get_corrected(
    Aapl_t *aapl, /**< [in] Pointer to Aapl_t structure */
    uint addr,    /**< [in] SBus address of FEC */
    uint lane     /**< [in] Lane information */
)
{
    uint daddr=0;
    uint regs=1;
    uint shift=16;

    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 5,
                            AVAGO_PCS64B66B_FEC,
                            AVAGO_MLD,
                            AVAGO_RSFEC_BRIDGE,
                            AVAGO_OPAL_RSFEC528,
                            AVAGO_OPAL_RSFEC528_544)
    )
    {
        return 0;
    }

    /* Get base address and number of registers field is split over */
    switch( aapl_get_ip_type(aapl, addr) )
    {
        case AVAGO_PCS64B66B_FEC:
            daddr = 129; regs = 4; shift= 8;
        break;

        case AVAGO_RSFEC_BRIDGE:
            daddr = 209; regs = 2;
        break;

        case AVAGO_OPAL_RSFEC528:
        case AVAGO_OPAL_RSFEC528_544:
            daddr = 209;
        break;

        case AVAGO_MLD:
            regs = 2;
            daddr = (lane < 4) ? 4 + lane*32 : 209;
            break;
        default:
            return 0;
    }
    /* accumulate count */
    return fec_get_count(aapl, addr, daddr, regs, shift);
}

/*============================================================================= */
/* FEC GET UNCORRECTED */

/** @brief   Retrieve the uncorrected error counter value. */
/** @details Returns FEC error uncorrected count. */
/**          For the MLD use lane=4 to access quad lane counter. */
/** @return  On success, returns count. */
/** @return  On error, decrements aapl->return_code and returns -1. */

uint avago_fec_get_uncorrected(
    Aapl_t *aapl, /**< [in] Pointer to Aapl_t structure */
    uint addr,    /**< [in] SBus address of FEC */
    uint lane     /**< [in] Lane information */
)
{
    uint daddr=0;
    uint regs=1;
    uint shift=16;

    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 5,
                            AVAGO_PCS64B66B_FEC,
                            AVAGO_MLD,
                            AVAGO_RSFEC_BRIDGE,
                            AVAGO_OPAL_RSFEC528,
                            AVAGO_OPAL_RSFEC528_544)
    )
    {
        return 0;
    }

    /* Get base address and number of registers field is split over */
    switch( aapl_get_ip_type(aapl, addr) )
    {
        case AVAGO_PCS64B66B_FEC:
            daddr = 133; regs = 4; shift= 8;
            break;

        case AVAGO_RSFEC_BRIDGE:
            daddr = 211; regs = 2;
            break;

        case AVAGO_OPAL_RSFEC528:
        case AVAGO_OPAL_RSFEC528_544:
            daddr = 210;
            break;

        case AVAGO_MLD:
            regs = 2;
            daddr =(lane < 4) ?  6 + lane*32 : 211;
            break;

        default:
            return 0;
  }
  return fec_get_count(aapl, addr, daddr, regs, shift); /* accumulate count */
}

/*============================================================================= */
/* RSFEC GET LANE SYM COUNT */

/** @brief   Retrieve the RS symbol lane error counter value. */
/** @details Returns RS Symbol corrected count. */
/** @return  On success, returns count. */
/** @return  On error, decrements aapl->return_code and returns -1. */
uint avago_rsfec_get_lane_sym_count(
    Aapl_t *aapl, /**< [in] Pointer to Aapl_t structure */
    uint addr,    /**< [in] SBus address of FEC */
    uint lane     /**< [in] Lane information */
)
{
    uint daddr=0;
    uint regs=1;
    uint shift=16;

    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 4,
                            AVAGO_MLD,
                            AVAGO_RSFEC_BRIDGE,
                            AVAGO_OPAL_RSFEC528,
                            AVAGO_OPAL_RSFEC528_544)
    )
    {
        return 0;
    }

    /* Bound select to valid range */
    if(lane > 3)
        lane = 3;

    /* Get base address and number of registers field is split over */
    switch( aapl_get_ip_type(aapl, addr) )
    {
        case AVAGO_MLD:
        case AVAGO_RSFEC_BRIDGE:
            daddr = 213; regs = 2;
            break;
        case AVAGO_OPAL_RSFEC528:
        case AVAGO_OPAL_RSFEC528_544:
            daddr = 212;
            break;
        default:
            return 0;
    }
/* adjust for selected field */
    daddr += lane*regs;

    /* accumulate count */
    return fec_get_count(aapl, addr, daddr, regs, shift);
}

/*============================================================================= */
/* RSFEC GET CW X SYM COUNT */

/** @brief   Retrieve the RS codewords with X symbols in error counter */
/** @details Returns RS codewords with X symbols in error count. */
/** @return  On success, returns count. */
/** @return  On error, decrements aapl->return_code and returns -1. */
uint avago_rsfec_get_cw_X_sym_count(
    Aapl_t *aapl, /**< [in] Pointer to Aapl_t structure */
    uint addr,    /**< [in] SBus address of FEC */
    uint num      /**< [in] Number information */
)
{
    uint daddr=0;
    uint regs=1;
    uint shift=16;
    uint range;
    uint revision_id;

    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 4,
                            AVAGO_MLD,
                            AVAGO_RSFEC_BRIDGE,
                            AVAGO_OPAL_RSFEC528,
                            AVAGO_OPAL_RSFEC528_544)
    )
    {
        return 0;
    }

    revision_id = aapl_get_ip_rev(aapl, addr);

    if ( revision_id == 2 )    /* Fermi Chip */
        range = 15;
    else
        range = 7;

    /* Bound select to valid range */
    if(num > range )
        num = range;
    num--;      /* base address reads "1", 0 not used */

    /* Get base address and number of registers field is split over */
    switch( aapl_get_ip_type(aapl, addr) )
    {
        case AVAGO_MLD:
        case AVAGO_RSFEC_BRIDGE:
            daddr = 226;
            if(num < 5)
                regs = 2;
            else
                daddr = 229;
            break;

        case AVAGO_OPAL_RSFEC528:
        case AVAGO_OPAL_RSFEC528_544:
            daddr = 221;
            break;

        default:
            return 0;
    }
    /* adjust for selected field */
    daddr += num*regs;

    /* accumulate count */
    if(num > 6)
    {
        daddr += 12;
    }
    return fec_get_count(aapl, addr, daddr, regs, shift);
}

/*============================================================================= */
/* RSFEC GET CONSEC X SYM COUNT */

/** @brief   Retrieve the RS X consecutive symbols in error counter */
/** @details Returns RS X consecutive symbols in error count. */
/** @return  On success, returns count. */
/** @return  On error, decrements aapl->return_code and returns -1. */
uint avago_rsfec_get_consec_X_sym_count(
    Aapl_t *aapl, /**< [in] Pointer to Aapl_t structure */
    uint addr,    /**< [in] SBus address of FEC */
    uint num      /**< [in] Number information */
)
{
    uint daddr=0;
    uint regs=1;
    uint shift=16;

    if(!aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 4,
                            AVAGO_MLD,
                            AVAGO_RSFEC_BRIDGE,
                            AVAGO_OPAL_RSFEC528,
                            AVAGO_OPAL_RSFEC528_544)
    )
    {
        return 0;
    }
    /* Bound select to valid range */
    if(num > 6)
      num = 6;
    /* only track 2+, so first reg read is 2 */
    if(num < 2)
      num = 2;
    /* base address reads "2", 0-1 not used */
      num -= 2;

    /* Get base address */
    switch( aapl_get_ip_type(aapl, addr) )
    {
        case AVAGO_MLD:
        case AVAGO_RSFEC_BRIDGE:
             daddr = 221;
             break;

        case AVAGO_OPAL_RSFEC528:
        case AVAGO_OPAL_RSFEC528_544:
             daddr = 216;
             break;

        default:
            return 0;
    }
    /* Adjust for selected field */
    daddr += num;

    /* accumulate count */
    return fec_get_count(aapl, addr, daddr, regs, shift);
}

/*============================================================================= */
/* CALCULATE CER */

/** @brief   Calculate CER. */
/** @return  Buffer containing the printed statistic value. */
static char *calc_cer(
    char *buffer, /**< [out] Buffer to hold results.  On success, this buffer is filled in and returned. */
    int  bufsize, /**< [in] Size of buffer. */
    uint value,   /**< [in] Value */
    bigint cw)    /**< [in] Code words */
{
    if( cw > 0 )
    {
#if AAPL_ENABLE_FLOAT_USAGE
        double rate = (double) value / cw;
        snprintf(buffer,bufsize,"%.3e",rate);
#else
        int exp=0;
        bigint rate = (value * 1000) / cw;
        while( rate > 10000 )
        {
            exp++;
            rate = rate / 10;
        }
        snprintf(buffer,bufsize,"%d.%03de-%d",(int)(rate/1000),(int)(rate%1000),exp);
#endif
    }
    else
    {
        snprintf(buffer,bufsize,"unknown");
    }
    return buffer;
}

/*============================================================================= */
/* CALCULATE SER */

/** @brief   Calculate SER. */
/** @return  Buffer containing the printed statistic value. */
static char *calc_ser(
    char *buffer, /**< [out] Buffer to hold results.  This buffer is filled in and returned. */
    int  bufsize, /**< [in] Size of buffer. */
    uint value,   /**< [in] Value */
    bigint cw,    /**< [in] Code words */
    BOOL rs544)   /**< [in] is cw size 544 */
{
    /* Calcualte number of symbols checked */
    bigint sym = cw * (rs544 ? 544/4 : 528/4);

    if( cw > 0 )
    {
#if AAPL_ENABLE_FLOAT_USAGE
        double rate = (double) value / sym;
        snprintf(buffer,bufsize,"%.3e",rate);
#else
        int exp=0;
        bigint rate = (value * 1000) / sym;
        while( rate > 10000 )
        {
            exp++;
            rate = rate / 10;
        }
        snprintf(buffer,bufsize,"%d.%03de-%d",(int)(rate/1000),(int)(rate%1000),exp);
#endif
    }
    else
    {
        snprintf(buffer,bufsize,"unknown");
    }
    return buffer;
}

/*============================================================================= */
/* RSFEC Statistics to string */

/** @brief   RSFEC statistics to string */
/** @return  Allocated buffer containing formatted FEC statistics.  Caller should pass returned value to aapl_free to release. */
char *avago_rsfec_stats_to_str(
    Aapl_t *aapl,             /**< [in] Pointer to Aapl_t structure */
    Avago_fec_stats_t *stats, /**< [in] Pointer to FEC statistics structure */
    uint addr)                /**< [in] SBus address of FEC */
{
    char tempbuf[32];
    const int bufsize = sizeof(tempbuf);
    char *buf = 0;
    char *buf_end = 0;
    int size = 0;

    aapl_buf_add(aapl, &buf, &buf_end, &size,"FEC Statistics for SbusRx: %s\n",aapl_addr_to_str(addr));
    aapl_buf_add(aapl, &buf, &buf_end, &size,"Statistics: %s\n\n",stats->halted ? "Halted" : "Accumulating");
    aapl_buf_add(aapl, &buf, &buf_end, &size,"%16s  %15s              %s\n","Value","Count","CER/SER");
    aapl_buf_add(aapl, &buf, &buf_end, &size,"---------------------------------------------------------\n");
    if(stats->codewords > 0)
    aapl_buf_add(aapl, &buf, &buf_end, &size,"%16s  %15s (0x%04x%08x)\n","Codewords",aapl_bigint_to_str(stats->codewords), stats->codewords >> 32, stats->codewords & 0xFFFFFFFF);
    aapl_buf_add(aapl, &buf, &buf_end, &size,"%16s  %15u (0x0000%08x) %s\n","Corrected",stats->corrected, stats->corrected, calc_cer(tempbuf,bufsize,stats->corrected,stats->codewords));
    aapl_buf_add(aapl, &buf, &buf_end, &size,"%16s  %15u (0x0000%08x) %s\n","Uncorrected",stats->uncorrected, stats->uncorrected, calc_cer(tempbuf,bufsize,stats->uncorrected,stats->codewords));
    if( aapl_get_ip_type(aapl, addr) != AVAGO_PCS64B66B_FEC )
    {
        uint i;
        for( i=0; i<=3; i++ )
            aapl_buf_add(aapl, &buf, &buf_end, &size,"%15s%d  %15u (0x0000%08x) %s\n","Sym_Err_LANE",i,stats->rs_lane_sym_count[i], stats->rs_lane_sym_count[i], calc_ser(tempbuf,bufsize,stats->rs_lane_sym_count[i],stats->codewords,stats->codeword_size == 544));

        if( aapl_get_ip_rev(aapl, addr) == 2 ) /* Fermi Chip */
            for( i=1; i<=15; i++ )
                aapl_buf_add(aapl, &buf, &buf_end, &size,"%14s%02d  %15u (0x0000%08x) %s\n","CW_sym_err_",i,stats->cw_X_sym_count[i], stats->cw_X_sym_count[i], calc_cer(tempbuf,bufsize,stats->cw_X_sym_count[i],stats->codewords));
        else
            for( i=1; i<=7; i++ )
                aapl_buf_add(aapl, &buf, &buf_end, &size,"%15s%d  %15u (0x0000%08x) %s\n","CW_sym_err_",i,stats->cw_X_sym_count[i], stats->cw_X_sym_count[i], calc_cer(tempbuf,bufsize,stats->cw_X_sym_count[i],stats->codewords));

        for( i=2; i<=6; i++ )
            aapl_buf_add(aapl, &buf, &buf_end, &size,"%15s%d  %15u (0x0000%08x) %s\n","Consec_sym_err_",i,stats->rs_X_sym_consec[i], stats->rs_X_sym_consec[i], "n/a");
    }
    return buf;
}

/*============================================================================= */
/* FEC GEARFIFO */

/** @brief Gets the status of the gearbox */
/** @details Populates the provided struct with current status of the gearbox found */
/**          in the given fec engine */
/** @return void */
void avago_fec_get_gearfifo(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure */
    uint addr,                          /**< [in] SBus address of FEC */
    Avago_fec_gearfifo_status_t *status /**< [out] Pointer to FEC gear fifo status structure */
)
{
    int  data;

    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 4,
                            AVAGO_MLD,
                            AVAGO_RSFEC_BRIDGE,
                            AVAGO_OPAL_RSFEC528,
                            AVAGO_OPAL_RSFEC528_544)
    )
    {
        return;
    }

    data = avago_sbus_rd(aapl, addr, 208);

    status->tx_overflow  = ((data >>  4) & 0x1) ? TRUE : FALSE;
    status->tx_underflow = ((data >>  5) & 0x1) ? TRUE : FALSE;
    status->rx_overflow  = ((data >>  6) & 0x1) ? TRUE : FALSE;
    status->rx_underflow = ((data >>  7) & 0x1) ? TRUE : FALSE;

    status->rx_rd_ptr = avago_sbus_rd(aapl, addr, 230); /* read latches rx wr_ptr */
    status->tx_wr_ptr = avago_sbus_rd(aapl, addr, 231); /* read latches tx rd_ptr */
    data = avago_sbus_rd(aapl, addr, 232);              /* retrieve rx wr_ptr and tx rd_ptr */

    status->rx_wr_ptr = (data >>  0) & 0xFFFF;
    status->tx_rd_ptr = (data >> 16) & 0xFFFF;
}

/*============================================================================= */
/* RESET GEARFIFO STATUS */

/** @brief Reset the gear fifo status based on provided options */
/** @details */
/** @return void */
/** */
void avago_fec_reset_gearfifo(
    Aapl_t *aapl,                                            /**< [in] Pointer to Aapl_t structure */
    uint addr,                                               /**< [in] SBus address of FEC */
    Avago_fec_gearfifo_reset_options_t gearfifo_reset_option /**< [in] Gear fifo reset option */
)
{
    if( !aapl_check_ip_type( aapl, addr, __func__, __LINE__, TRUE, 4,
                             AVAGO_MLD,
                             AVAGO_RSFEC_BRIDGE,
                             AVAGO_OPAL_RSFEC528,
                             AVAGO_OPAL_RSFEC528_544
                           )
    )
    {
        return;
    }

    /* Get base address */
    switch( aapl_get_ip_type(aapl, addr) )
    {
        case AVAGO_OPAL_RSFEC528:
        case AVAGO_OPAL_RSFEC528_544:
            if(gearfifo_reset_option == TX_GEARFIFO_OVERFLOW_RESET)
            {
                avago_sbus_rmw(aapl, addr, 0x01, 0x0004, 0x0004);
                avago_sbus_rmw(aapl, addr, 0x01, 0x0000, 0x0004);
            }
            else if(gearfifo_reset_option == TX_GEARFIFO_UNDERFLOW_RESET)
            {
                avago_sbus_rmw(aapl, addr, 0x01, 0x0008, 0x0008);
                avago_sbus_rmw(aapl, addr, 0x01, 0x0000, 0x0008);
            }
            else if(gearfifo_reset_option == RX_GEARFIFO_OVERFLOW_RESET)
            {
                avago_sbus_rmw(aapl, addr, 0x01, 0x0010, 0x0010);
                avago_sbus_rmw(aapl, addr, 0x01, 0x0000, 0x0010);
            }
            else if(gearfifo_reset_option == RX_GEARFIFO_UNDERFLOW_RESET)
            {
                avago_sbus_rmw(aapl, addr, 0x01, 0x0020, 0x0020);
                avago_sbus_rmw(aapl, addr, 0x01, 0x0000, 0x0020);
            }
            break;

        default:
            break;
    }
    return;
}

/*============================================================================= */
/* GET FEC ELASTIC BUFFER STATUS */
/* */
/** @brief Gets the status of the elastic buffer */
/** @details Populates the provided struct with current status of the elastic buffer */
/**          found in the given fec engine */
/** @return void */
/** */
void avago_fec_get_ebuf(
    Aapl_t *aapl,                   /**< [in] Pointer to Aapl_t structure */
    uint addr,                      /**< [in] SBus address of FEC */
    Avago_fec_ebuf_status_t *status /**< [out] Pointer to FEC gear fifo status structure */
)
{
    int  data;

    if( !aapl_check_ip_type( aapl, addr, __func__, __LINE__, TRUE, 4,
                             AVAGO_MLD,
                             AVAGO_RSFEC_BRIDGE,
                             AVAGO_OPAL_RSFEC528,
                             AVAGO_OPAL_RSFEC528_544
                           )
    )
    {
        return;
    }

    /* Get base address */
    switch( aapl_get_ip_type(aapl, addr) )
    {
        case AVAGO_OPAL_RSFEC528_544:
             data = avago_sbus_rd(aapl, addr, 0xcf);
             status->tx_sync_overflow  = ((data >>  16) & 0x1) ? TRUE : FALSE;
             status->tx_sync_underflow = ((data >>  17) & 0x1) ? TRUE : FALSE;
             status->tx_underflow      = ((data >>  18) & 0x1) ? TRUE : FALSE;
             status->tx_idle_err       = ((data >>  19) & 0x1) ? TRUE : FALSE;

             status->rx_sync_overflow  = ((data >>  0)  & 0x1) ? TRUE : FALSE;
             status->rx_sync_underflow = ((data >>  1)  & 0x1) ? TRUE : FALSE;
             status->rx_underflow      = ((data >>  2)  & 0x1) ? TRUE : FALSE;
             status->rx_idle_err       = ((data >>  3)  & 0x1) ? TRUE : FALSE;

             data = avago_sbus_rd(aapl, addr, 0xce);
             status->tx_idle_detect    = ((data >>  31)  & 0x1) ? TRUE : FALSE;
             status->tx_idle_force_out = ((data >>  27)  & 0x1) ? TRUE : FALSE;

             status->rx_idle_detect    = ((data >>  25)  & 0x1) ? TRUE : FALSE;
             status->rx_idle_force_out = ((data >>  21)  & 0x1) ? TRUE : FALSE;
             break;

        default:
            break;
    }
    return;
}

/*============================================================================= */
/* CONTROL ELASTIC BUFFER STATUS */

/** @brief Control the ebuf configuration based on provided options */
/** @details */
/** @return void */
/** */
void avago_fec_control_ebuf(
    Aapl_t *aapl,                                        /**< [in] Pointer to Aapl_t structure */
    uint addr,                                           /**< [in] SBus address of FEC */
    Avago_fec_ebuf_control_options_t ebuf_control_option /**< [in] Ebuf control option */
)
{
    if( !aapl_check_ip_type( aapl, addr, __func__, __LINE__, TRUE, 4,
                             AVAGO_MLD,
                             AVAGO_RSFEC_BRIDGE,
                             AVAGO_OPAL_RSFEC528,
                             AVAGO_OPAL_RSFEC528_544
                           )
    )
    {
        return;
    }

    /* Get base address */
    switch( aapl_get_ip_type(aapl, addr) )
    {
        case AVAGO_OPAL_RSFEC528_544:
            if(ebuf_control_option == TX_EBUF_ENABLE)
            {
                avago_sbus_rmw(aapl, addr, 0xce, 0x04000000, 0x04000000);
            }
            else if(ebuf_control_option == TX_EBUF_DISABLE)
            {
                avago_sbus_rmw(aapl, addr, 0xce, 0x00000000, 0x04000000);
            }
            else if(ebuf_control_option == TX_EBUF_FORCE_IDLE_OUTPUT_ENABLE)
            {
                avago_sbus_rmw(aapl, addr, 0xce, 0x08000000, 0x08000000);
            }
            else if(ebuf_control_option == TX_EBUF_FORCE_IDLE_OUTPUT_DISABLE)
            {
                avago_sbus_rmw(aapl, addr, 0xce, 0x00000000, 0x08000000);
            }
            else if(ebuf_control_option == TX_EBUF_IDLE_DETECT_ENABLE)
            {
                avago_sbus_rmw(aapl, addr, 0xce, 0x80000000, 0x80000000);
            }
            else if(ebuf_control_option == TX_EBUF_IDLE_DETECT_DISABLE)
            {
                avago_sbus_rmw(aapl, addr, 0xce, 0x00000000, 0x80000000);
            }
            else if(ebuf_control_option == RX_EBUF_ENABLE)
            {
                avago_sbus_rmw(aapl, addr, 0xce, 0x00100000, 0x00100000);
            }
            else if(ebuf_control_option == RX_EBUF_DISABLE)
            {
                avago_sbus_rmw(aapl, addr, 0xce, 0x00000000, 0x00100000);
            }
            else if(ebuf_control_option == RX_EBUF_FORCE_IDLE_OUTPUT_ENABLE)
            {
                avago_sbus_rmw(aapl, addr, 0xce, 0x00200000, 0x00200000);
            }
            else if (ebuf_control_option == RX_EBUF_FORCE_IDLE_OUTPUT_DISABLE)
            {
                avago_sbus_rmw(aapl, addr, 0xce, 0x00000000, 0x00200000);
            }
            else if(ebuf_control_option == RX_EBUF_IDLE_DETECT_ENABLE)
            {
                avago_sbus_rmw(aapl, addr, 0xce, 0x02000000, 0x02000000);
            }
            else if(ebuf_control_option == RX_EBUF_IDLE_DETECT_DISABLE)
            {
                avago_sbus_rmw(aapl, addr, 0xce, 0x00000000, 0x02000000);
            }
            break;

        default:
            break;
    }
    return;
}

/*============================================================================= */
/* RESET ELASTIC BUFFER STATUS */

/** @brief Reset the ebuf status based on provided options */
/** @details */
/** @return void */
/** */
void avago_fec_reset_ebuf(
    Aapl_t *aapl,                                    /**< [in] Pointer to Aapl_t structure */
    uint addr,                                       /**< [in] SBus address of FEC */
    Avago_fec_ebuf_reset_options_t ebuf_reset_option /**< [in] Ebuf reset option */
)
{
    if( !aapl_check_ip_type( aapl, addr, __func__, __LINE__, TRUE, 4,
                             AVAGO_MLD,
                             AVAGO_RSFEC_BRIDGE,
                             AVAGO_OPAL_RSFEC528,
                             AVAGO_OPAL_RSFEC528_544
                           )
    )
    {
        return;
    }

    /* Get base address */
    switch( aapl_get_ip_type(aapl, addr) )
    {
        case AVAGO_OPAL_RSFEC528_544:
            if(ebuf_reset_option == TX_EBUF_OVERFLOW_RESET)
            {
                avago_sbus_rmw(aapl, addr, 0x01, 0x0400, 0x0400);
                avago_sbus_rmw(aapl, addr, 0x01, 0x0000, 0x0400);
            }
            else if(ebuf_reset_option == TX_EBUF_UNDERFLOW_RESET)
            {
                avago_sbus_rmw(aapl, addr, 0x01, 0x0800, 0x0800);
                avago_sbus_rmw(aapl, addr, 0x01, 0x0000, 0x0800);
            }
            else if(ebuf_reset_option == RX_EBUF_OVERFLOW_RESET)
            {
                avago_sbus_rmw(aapl, addr, 0x01, 0x0100, 0x0100);
                avago_sbus_rmw(aapl, addr, 0x01, 0x0000, 0x0100);
            }
            else if(ebuf_reset_option == RX_EBUF_UNDERFLOW_RESET)
            {
                avago_sbus_rmw(aapl, addr, 0x01, 0x0200, 0x0200);
                avago_sbus_rmw(aapl, addr, 0x01, 0x0000, 0x0200);
            }
            break;

        default:
            break;
    }
    return;
}

/*============================================================================= */
/* GET ELASTIC BUFFER RESET STATUS */

/** @brief Get elastic buffer reset status */
/** @details */
/** @return The reset status of elastic buffer */
/** */
BOOL avago_fec_get_reset_ebuf(
    Aapl_t *aapl,
    uint addr,
    Avago_fec_ebuf_reset_options_t ebuf_reset_option
)
{
    BOOL status = FALSE;
int data;

    if( !aapl_check_ip_type( aapl, addr, __func__, __LINE__, TRUE, 4,
                             AVAGO_MLD,
                             AVAGO_RSFEC_BRIDGE,
                             AVAGO_OPAL_RSFEC528,
                             AVAGO_OPAL_RSFEC528_544
                           )
    )
    {
        return FALSE;
    }
data = avago_sbus_rd(aapl, addr, 0x01);

/* Get base address */
    switch( aapl_get_ip_type(aapl, addr) )
    {
        case AVAGO_OPAL_RSFEC528_544:
            if(ebuf_reset_option == TX_EBUF_OVERFLOW_RESET)
            {
                status = ((data >>  10) & 0x1) ? TRUE : FALSE;
            }
            else if(ebuf_reset_option == TX_EBUF_UNDERFLOW_RESET)
            {
                status = ((data >>  11) & 0x1) ? TRUE : FALSE;
            }
            else if(ebuf_reset_option == RX_EBUF_OVERFLOW_RESET)
            {
                status = ((data >>  8) & 0x1) ? TRUE : FALSE;
            }
            else if(ebuf_reset_option == RX_EBUF_UNDERFLOW_RESET)
            {
                status = ((data >>  9) & 0x1) ? TRUE : FALSE;
            }
            break;

        default:
            status = FALSE;
            break;
    }
    return(status);
}

/*============================================================================= */
/* FEC GET ALIGNMENT RESET STATUS */

/** @brief   Get the RSFEC lost alignment reset status */
/** @details Get the RSFEC lost alignment reset status */
/** @return  Lost alignment reset status */
BOOL avago_fec_get_alignment_reset_status(
    Aapl_t *aapl, /**< [in] Pointer to Aapl_t structure. */
    uint addr     /**< [in] SBus address of FEC. */
    )
{
    int data = 0;
    BOOL status = FALSE;
    if( !aapl_check_ip_type( aapl, addr, __func__, __LINE__, TRUE, 2,
                             AVAGO_OPAL_RSFEC528,
                             AVAGO_OPAL_RSFEC528_544)
    )
    {
        return FALSE;
    }

    data = avago_sbus_rd(aapl, addr, 0x02);

    status = ((data >>  4) & 0x1) ? TRUE : FALSE;

    return (status);
}

/*============================================================================= */
/* RESET RSFEC ALIGNMENT STATUS */

/** @brief Reset RSFEC alignment status */
/** @details */
/** @return void */
/** */
void avago_fec_reset_alignment_status(
    Aapl_t *aapl, /**< [in] Pointer to Aapl_t structure */
    uint addr     /**< [in] SBus address of FEC */
)
{
    if( !aapl_check_ip_type( aapl, addr, __func__, __LINE__, TRUE, 4,
                             AVAGO_MLD,
                             AVAGO_RSFEC_BRIDGE,
                             AVAGO_OPAL_RSFEC528,
                             AVAGO_OPAL_RSFEC528_544
                           )
    )
    {
        return;
    }
    avago_sbus_rmw(aapl, addr, 0x02, 0x10, 0x10);
    avago_sbus_rmw(aapl, addr, 0x02, 0x00, 0x10);
    return;
}

/*============================================================================= */
/* CLOCK ALIGNMENT OF RSFEC CORE */

/** @brief */
/** @details */
/** @return void */
/** */
static void clock_align(Aapl_t *aapl, uint sbus_addr)
{
  uint control_logic_addr;
  uint first_cm4_addr;
  uint second_cm4_addr;
  Avago_addr_t addr_struct;
  avago_addr_to_struct(sbus_addr, &addr_struct);

  control_logic_addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, CONTROL_LOGIC_SBUS_ADDR);
  first_cm4_addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, FIRST_CM4_SBUS_ADDR);
  second_cm4_addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, SECOND_CM4_SBUS_ADDR);

  avago_sbus_wr   (aapl, control_logic_addr, 0x01, 0x00000003);    /* Set host and mod reset */

  /* Fermi/Tesla RX_FIFO_CLK -> Data relationship */
  avago_spico_int(aapl, first_cm4_addr, 0xe, 0x0f00);  /* Rx phase slip count of 15 */
  avago_spico_int(aapl, second_cm4_addr, 0xe, 0x0f00); /* Rx phase slip count of 15 */

  avago_sbus_wr   (aapl, control_logic_addr, 0x01, 0x00000000);    /* Release resets, (tx_beacon reset by mod_reset) */
  /* Run tx_in phase calibration */
  avago_spico_int (aapl, first_cm4_addr, 0xb, 1);  /* Beacon running now, run phase_cal */
  avago_spico_int (aapl, second_cm4_addr, 0xb, 1); /* Beacon running now, run phase_cal */

  aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "SD%d: PHASE_CAL: %d\n", first_cm4_addr,  avago_spico_int(aapl, first_cm4_addr,  0x41ca, 0));  /* phase_cal watchdog */
  aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "SD%d: PHASE_CAL: %d\n", second_cm4_addr, avago_spico_int(aapl, second_cm4_addr, 0x41ca, 0));  /* phase_cal watchdog */
  avago_sbus_wr   (aapl, control_logic_addr, 0x01, 0x00000003);    /* Set host and mod reset */
  avago_sbus_wr   (aapl, control_logic_addr, 0x01, 0x00000002);    /* Remove host reset */
  avago_sbus_wr   (aapl, control_logic_addr, 0x01, 0x00000000);    /* Release resets (tx_beacon reset by mod_reset) */
}

/*============================================================================= */
/* CONFIGURE TESLA RSFEC 528 CORE */

/** @brief */
/** @details */
/** @return void */
/** */
static void configure_core_fec528_2x50g(Aapl_t *aapl, uint sbus_addr)
{
    uint addr;
    Avago_addr_t addr_struct;
    avago_addr_to_struct(sbus_addr, &addr_struct);

    /* Host Aligner */
    addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, HOST_ALIGNER_SBUS_ADDR);
    avago_sbus_reset(aapl, addr, 0 /*soft*/);

    /* Control Logic */
    addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, CONTROL_LOGIC_SBUS_ADDR);
    avago_sbus_reset(aapl, addr, 0 /*soft*/);
    avago_sbus_wr   (aapl, addr, 0x00, 0x00000002);
    avago_sbus_wr   (aapl, addr, 0x20, 0x00000330);
    avago_sbus_wr   (aapl, addr, 0x22, 0xffffffff);
    avago_sbus_wr   (aapl, addr, 0x23, 0x00000057);
    avago_sbus_wr   (aapl, addr, 0x25, 0x00000555);
    avago_sbus_wr   (aapl, addr, 0x26, 0x000000ff);

    /* Mod Aligner */
    addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, MOD_ALIGNER_SBUS_ADDR);
    avago_sbus_reset(aapl, addr, 0 /*soft*/);
    avago_sbus_wr   (aapl, addr, 0x00, 0x0000000A);
    avago_sbus_wr   (aapl, addr, 0x04, 0x00000c31);

    /* FEC */
    addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, RSFEC_528_544_SBUS_ADDR);
    avago_sbus_reset(aapl, addr, 0 /*soft*/);
    avago_sbus_wr   (aapl, addr, 0x01, 0x00000ff0);
    avago_sbus_wr   (aapl, addr, 0x01, 0x00000000);
    avago_sbus_wr   (aapl, addr, 0xce, 0xcc000000);  /* idle gen and chck on */

    /* Reset logic */
    addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, CONTROL_LOGIC_SBUS_ADDR);
    avago_sbus_wr   (aapl, addr, 0x01, 0x00000003);  /* host + mod reset on */
}

/*============================================================================= */
/* CONFIGURE TESLA RSFEC 544 CORE */

/** @brief */
/** @details */
/** @return void */
/** */
static void configure_core_fec544_2x50g(Aapl_t *aapl, uint sbus_addr)
{
    uint addr;
    Avago_addr_t addr_struct;
    avago_addr_to_struct(sbus_addr, &addr_struct);
    addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, HOST_ALIGNER_SBUS_ADDR);

    /* Host Aligner */
    avago_sbus_reset(aapl, addr, 0 /*soft*/);
    avago_sbus_wr   (aapl, addr, 0x01, 0x00000100);
    avago_sbus_wr   (aapl, addr, 0x1e, 0xffffffff);
    avago_sbus_wr   (aapl, addr, 0x20, 0x00000001);
    avago_sbus_wr   (aapl, addr,   13, 0x003f0000);

    /* Control Logic */
    addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, CONTROL_LOGIC_SBUS_ADDR);
    avago_sbus_reset(aapl, addr, 0 /*soft*/);
    avago_sbus_wr   (aapl, addr, 0x00, 0x00000006);
    avago_sbus_wr   (aapl, addr, 0x20, 0x00000330);
    avago_sbus_wr   (aapl, addr, 0x22, 0xffffffff);
    avago_sbus_wr   (aapl, addr, 0x21, 0x00000000);
    avago_sbus_wr   (aapl, addr, 0x25, 0x2222AAAA);
    avago_sbus_wr   (aapl, addr, 0x26, 0x000000ff);
    avago_sbus_wr   (aapl, addr, 0x23, 0x00000057);

    /* Mod Aligner */
    addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, MOD_ALIGNER_SBUS_ADDR);
    avago_sbus_reset(aapl, addr, 0 /*soft*/);
    avago_sbus_wr   (aapl, addr, 0x00, 0x021FFF0A);
    avago_sbus_wr   (aapl, addr, 0x04, 0x00000c31);

    /* FEC */
    addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, RSFEC_528_544_SBUS_ADDR);
    avago_sbus_reset(aapl, addr, 0 /*soft*/);
    avago_sbus_wr   (aapl, addr, 0x01, 0x00000ff0);
    avago_sbus_wr   (aapl, addr, 0x01, 0x00000000);
    avago_sbus_wr   (aapl, addr, 0xce, 0xcc000000);  /* idle gen and chck on */

    /* Reset logic */
    addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, CONTROL_LOGIC_SBUS_ADDR);
    avago_sbus_wr   (aapl, addr, 0x01, 0x00000003);  /* host + mod reset on */
}

/*============================================================================= */
/* CONFIGURE TESLA RSFEC 528 */

/** @brief */
/** @details */
/** @return void */
/** */
void avago_set_tesla_rsfec528_2x50g_div(Aapl_t *aapl, uint sbus_addr, uint cm4_count, int div)
{
    uint addr;
    uint cm4_addr;
    Avago_addr_t addr_struct;
    avago_addr_to_struct(sbus_addr, &addr_struct);

    addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, HOST_D6_SBUS_ADDR);
    avago_serdes_init_quick(aapl, addr, div);  /* Enable D6 slice to provide clock for EBUF packet gen */
    avago_spico_int(aapl, addr, 0x30, 0x4000); /* Rx PCS to div66 */

    cm4_addr = CM4_SBUS_START_ADDR;
    while (cm4_addr < (CM4_SBUS_START_ADDR + cm4_count))
    {
        /* Config CM4 slices to 25.8G */
        Avago_serdes_init_config_t *config = avago_serdes_init_config_construct(aapl);
        addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, cm4_addr);
        if (aapl_get_ip_rev(aapl, addr) == 0x0a) /* Tesla Chip */
        {
            config->sbus_reset   = FALSE;
            config->spico_reset  = FALSE;
            config->tx_phase_cal = FALSE;
            config->tx_divider   = div;
            config->rx_divider   = div;
            config->init_mode    = AVAGO_INIT_ONLY;
            avago_serdes_init(aapl, addr, config);

            avago_serdes_hal_set(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 0x09, 0xf);         /* pll_vernier to 15 */
            avago_serdes_hal_func(aapl, addr, AVAGO_HAL_RXCLK_VERNIER_APPLY);            /* apply new vernier setting */

            /*  Set ILB now runs a DVOS tuning */
            avago_serdes_hal_set(aapl, addr, AVAGO_HAL_DATA_CHANNEL_INPUTS, 0x00, -120); /* data_channel lower to -120 */
            avago_serdes_hal_set(aapl, addr, AVAGO_HAL_DATA_CHANNEL_INPUTS, 0x01, -120); /* data_channel lower to -120 */
            avago_serdes_hal_set(aapl, addr, AVAGO_HAL_DATA_CHANNEL_INPUTS, 0x02,    0); /* data_channel midle to    0 */
            avago_serdes_hal_set(aapl, addr, AVAGO_HAL_DATA_CHANNEL_INPUTS, 0x03,    0); /* data_channel midle to    0 */
            avago_serdes_hal_set(aapl, addr, AVAGO_HAL_DATA_CHANNEL_INPUTS, 0x04, +120); /* data_channel upper to +120 */
            avago_serdes_hal_set(aapl, addr, AVAGO_HAL_DATA_CHANNEL_INPUTS, 0x05, +120); /* data_channel upper to +120 */
            avago_serdes_hal_func(aapl, addr, AVAGO_HAL_DATA_CHANNEL_APPLY); /* apply new data channel setting */

            avago_serdes_set_rx_input_loopback(aapl, addr, TRUE);
            avago_serdes_set_rx_cmp_data(aapl, addr, AVAGO_SERDES_RX_CMP_DATA_PRBS31); /* Select RX compare data */
            avago_spico_int_check(aapl, __func__, __LINE__, addr, 0x03, AVAGO_SERDES_RX_CMP_MODE_MAIN_PATGEN | 0x0003);
        } else
        {
            config->sbus_reset   = TRUE;
            config->spico_reset  = TRUE;
            config->tx_phase_cal = FALSE;
            config->tx_divider   = div;
            config->rx_divider   = div;
            config->signal_ok_en = FALSE;
            config->init_mode    = AVAGO_PRBS31_ILB;
            avago_serdes_init(aapl, addr, config);
        }
        cm4_addr++;
    }
    configure_core_fec528_2x50g(aapl, sbus_addr);
    clock_align(aapl, sbus_addr);
}

static void set_tesla_rsfec528_2x50g(Aapl_t *aapl, uint sbus_addr, uint cm4_count)
{
    avago_set_tesla_rsfec528_2x50g_div(aapl, sbus_addr, cm4_count, 165);
}

/*============================================================================= */
/* CONFIGURE TESLA RSFEC 544 */

/** @brief */
/** @details */
/** @return void */
/** */
void avago_set_tesla_rsfec544_2x50g_div(Aapl_t *aapl, uint sbus_addr, uint cm4_count, int div)
{
    uint addr;
    uint cm4_addr;
    Avago_addr_t addr_struct;
    avago_addr_to_struct(sbus_addr, &addr_struct);

    /* Enable D6 slice to provide clock for EBUF packet gen */
    addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, HOST_D6_SBUS_ADDR);
    avago_serdes_init_quick(aapl, addr, (int) ((div * 165 / 170)  + 0.5));
    avago_spico_int(aapl, addr, 0x30, 0x4000); /* Rx PCS to div66 */

    cm4_addr = CM4_SBUS_START_ADDR;
    while (cm4_addr < (CM4_SBUS_START_ADDR + cm4_count))
    {
        /* Config CM4 slices to 26.6G and reconfigure PCS_FIFO_CLK to div68 */
        Avago_serdes_init_config_t *config = avago_serdes_init_config_construct(aapl);
        addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, cm4_addr);
        if (aapl_get_ip_rev(aapl, addr) == 0x0a) /* Tesla Chip */
        {
            config->sbus_reset   = FALSE;
            config->spico_reset  = FALSE;
            config->tx_phase_cal = FALSE;
            config->tx_divider   = div;
            config->rx_divider   = div;
            config->init_mode    = AVAGO_INIT_ONLY;
            avago_serdes_init(aapl, addr, config);

            avago_serdes_hal_set(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 0x09, 0xf);  /* pll_vernier to 15 */
            avago_serdes_hal_func(aapl, addr, AVAGO_HAL_RXCLK_VERNIER_APPLY);     /* apply new vernier setting */

            avago_spico_int (aapl, addr, 0x80c1, 0x10c9); /* Tesla Rx PCS */
            avago_spico_int (aapl, addr, 0x80a9, 0x1464); /* Tesla Tx PCS */

            /*  Set ILB now runs a DVOS tuning */
            avago_serdes_hal_set(aapl, addr, AVAGO_HAL_DATA_CHANNEL_INPUTS, 0x00, -120); /* data_channel lower to -120 */
            avago_serdes_hal_set(aapl, addr, AVAGO_HAL_DATA_CHANNEL_INPUTS, 0x01, -120); /* data_channel lower to -120 */
            avago_serdes_hal_set(aapl, addr, AVAGO_HAL_DATA_CHANNEL_INPUTS, 0x02,    0); /* data_channel midle to    0 */
            avago_serdes_hal_set(aapl, addr, AVAGO_HAL_DATA_CHANNEL_INPUTS, 0x03,    0); /* data_channel midle to    0 */
            avago_serdes_hal_set(aapl, addr, AVAGO_HAL_DATA_CHANNEL_INPUTS, 0x04, +120); /* data_channel upper to +120 */
            avago_serdes_hal_set(aapl, addr, AVAGO_HAL_DATA_CHANNEL_INPUTS, 0x05, +120); /* data_channel upper to +120 */
            avago_serdes_hal_func(aapl, addr, AVAGO_HAL_DATA_CHANNEL_APPLY); /* apply new data channel setting */

            avago_serdes_set_rx_input_loopback(aapl, addr, TRUE);
            avago_serdes_set_rx_cmp_data(aapl, addr, AVAGO_SERDES_RX_CMP_DATA_PRBS31); /* Select RX compare data */
            avago_spico_int_check(aapl, __func__, __LINE__, addr, 0x03, AVAGO_SERDES_RX_CMP_MODE_MAIN_PATGEN | 0x0003);
        } else
        {
            config->sbus_reset   = TRUE;
            config->spico_reset  = TRUE;
            config->tx_phase_cal = FALSE;
            config->tx_divider   = div;
            config->rx_divider   = div;
            config->signal_ok_en = FALSE;
            config->init_mode    = AVAGO_PRBS31_ILB;
            avago_serdes_init(aapl, addr, config);

            if (0xe4 == aapl_get_ip_rev(aapl, addr))
            {
                avago_spico_int (aapl, addr, 0x80c0, 0x1464); /* Coral Rx PCS */
                avago_spico_int (aapl, addr, 0x80e4, 0x1464); /* Coral Tx PCS */
            } else { /* Asssume Fermi and newer */
                avago_spico_int (aapl, addr, 0x80fb, 0x10c9); /* Fermi Rx PCS */
                avago_spico_int (aapl, addr, 0x80e9, 0x1464); /* Fermi Tx PCS */
            }
        }
        cm4_addr++; /* Do next slice */
    }
    configure_core_fec544_2x50g(aapl, sbus_addr);
    clock_align(aapl, sbus_addr);
}

static void set_tesla_rsfec544_2x50g(Aapl_t *aapl, uint sbus_addr, uint cm4_count)
{
    avago_set_tesla_rsfec544_2x50g_div(aapl, sbus_addr, cm4_count, 170);
}

#if AAPL_ENABLE_FILE_IO
/*============================================================================= */
/* RSFEC TESLA UP */

/** @brief */
/** @details */
/** @return void */
/** */
void avago_fec_tesla_upload(Aapl_t *aapl)
{
    uint addr;
    char firmware_file[512];
    const char *firmware_file_ptr = 0;

    snprintf(firmware_file,sizeof(firmware_file), AVAGO_FIRMWARE_PATH "serdes/%s/serdes.%s_%s.rom","0x1059","0x1059","2045");
    firmware_file_ptr = firmware_file;
    for(addr=4; addr<8; addr++)
    {
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Uploading file: %s to SBus address 0x%02x\n", firmware_file_ptr, addr);
        avago_spico_upload_file(aapl, addr, TRUE, firmware_file_ptr);
    }
    /*snprintf(firmware_file,sizeof(firmware_file), AVAGO_FIRMWARE_PATH "engineering_releases/serdes/2015_09_13_1442166439/serdes.A085.rom"); */
    /*snprintf(firmware_file,sizeof(firmware_file), AVAGO_FIRMWARE_PATH "engineering_releases/serdes/2015_09_21_1442854013/serdes.A085.rom"); */
    snprintf(firmware_file,sizeof(firmware_file), AVAGO_FIRMWARE_PATH "serdes/0x105B/serdes.0x105B_A085.rom");
    firmware_file_ptr = firmware_file;
    for(addr=8; addr<10; addr++)
    {
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Uploading file: %s to SBus address 0x%02x\n", firmware_file_ptr, addr);
        avago_spico_upload_file(aapl, addr, TRUE, firmware_file_ptr);
    }
}

/** @brief   Uploads rom file to CM4 and D6 slices of FEC chip. */
/** @return  void. */
void avago_fec_chip_upload(
    Aapl_t *aapl,            /**< [in] Pointer to Aapl_t structure. */
    uint addr,               /**< [in] Device address number. */
    const char * cm4_file,   /**< [in] Path to rom file for CM4 SerDes. */
    const char * d6_file)    /**< [in] Path to rom file for D6 SerDes. */
{
    uint sd_addr;
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr, &addr_struct);

    if( !aapl_check_ip_type( aapl, addr, __func__, __LINE__, TRUE, 2,
                             AVAGO_OPAL_RSFEC528,
                             AVAGO_OPAL_RSFEC528_544
                           )
    )
    {
        return;
    }

    /* Upload firmware to CM4 slices */
    for(sd_addr = CM4_SBUS_START_ADDR; sd_addr < (CM4_SBUS_START_ADDR + 2); sd_addr++)
    {
      uint addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, sd_addr);
      aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Uploading file: %s to SBus address 0x%02x\n", cm4_file, addr);
      avago_spico_upload_file(aapl, addr, TRUE, cm4_file);
    }

    /* Upload firmware to D6 slices */
    for(sd_addr = HOST_D6_SBUS_ADDR; sd_addr < CM4_SBUS_START_ADDR; sd_addr++)
    {
        uint addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, sd_addr);
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Uploading file: %s to SBus address 0x%02x\n", d6_file, addr);
        avago_spico_upload_file(aapl, addr, TRUE, d6_file);
    }
}

#endif /* AAPL_ENABLE_FILE_IO */

/*============================================================================= */
/* RSFEC TESLA Config */

/** @brief */
/** @details */
/** @return void */
/** */
void avago_fec_tesla_config(Aapl_t *aapl, uint sbus_addr, Avago_fec_mode_t mode)
{
    int cm4_count = 2;
    if(mode == AVAGO_FEC_RS528)
    {
        set_tesla_rsfec528_2x50g(aapl, sbus_addr, cm4_count);
    }
    else if(mode == AVAGO_FEC_RS544)
    {
        set_tesla_rsfec544_2x50g(aapl, sbus_addr, cm4_count);
    }
}


/*============================================================================= */
/* RSFEC Chip Config */

/** @brief */
/** @details */
/** @return void */
/** */
void avago_fec_chip_config(Aapl_t *aapl, uint sbus_addr, Avago_fec_mode_t mode)
{
    uint cm4_count = 2;
    if(mode == AVAGO_FEC_RS528)
    {
        /* Code to identify and configure the chip (Tesla/Fermi): */
        set_tesla_rsfec528_2x50g(aapl, sbus_addr, cm4_count);
    }
    else if(mode == AVAGO_FEC_RS544)
    {
        /* Code to configure the chip: */
        set_tesla_rsfec544_2x50g(aapl, sbus_addr, cm4_count);
    }
}

/*============================================================================= */
/* RSFEC FEC MODE */

/** @brief */
/** @details */
/** @return Avago_fec_mode_t */
/** */
Avago_fec_mode_t avago_rsfec_get_fec_mode( Aapl_t *aapl, uint sbus_addr)
{
    uint addr;
    Avago_addr_t addr_struct;
    int cnt_logic_reg_20;
    Avago_fec_mode_t fec_mode = AVAGO_FEC_UNCONFIGURED;
    avago_addr_to_struct(sbus_addr, &addr_struct);
    addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, CONTROL_LOGIC_SBUS_ADDR);

    cnt_logic_reg_20 = avago_sbus_rd(aapl, addr, 0x00);
    if (cnt_logic_reg_20 == 0x00000002)
        fec_mode = AVAGO_FEC_RS528;
    else if (cnt_logic_reg_20 == 0x00000006)
        fec_mode = AVAGO_FEC_RS544;
    else
        fec_mode = AVAGO_FEC_UNCONFIGURED;

    return fec_mode;
}

/*============================================================================= */
/* RSFEC TESLA FRAME LANE */

/** @brief */
/** @details */
/** @return void */
/** */
static int rsfec_frame_lane(Aapl_t *aapl, int addr, int pattern)
{
    int loop_count;
    uint mod_addr = avago_make_sbus_addr(addr, MOD_ALIGNER_SBUS_ADDR);

    for( loop_count = 0; loop_count < 200; loop_count++ )
    {
        int framed;

        avago_spico_int(aapl, addr, 0xc, 1);                   /* Bit slip */
        framed = avago_sbus_rd(aapl, mod_addr, 0x16) & 0xf;    /* Check for AM lock */
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "LOOP: %d FRAME: %d\n", loop_count, framed);

        /* Exit once AM lock is achieved */
        if( (framed == 0xf) || (framed == pattern) )
            break;
    }
    return loop_count;
}

/*============================================================================= */
/* RSFEC TESLA FRAME */

/** @brief */
/** @details */
/** @return void */
/** */
int avago_rsfec_frame(Aapl_t *aapl, uint sbus_addr)
{
  uint addr;
  Avago_addr_t addr_struct;
  avago_addr_to_struct(sbus_addr, &addr_struct);

  addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, CONTROL_LOGIC_SBUS_ADDR);
  avago_sbus_wr   (aapl, addr, 0x01, 0x00000001);    /* Mod reset on */

  addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, CONTROL_LOGIC_SBUS_ADDR);
  avago_sbus_wr   (aapl, addr, 0x01, 0x00000000);    /* Mod reset off */

  addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, FIRST_CM4_SBUS_ADDR);
  avago_serdes_set_tx_data_sel(aapl, addr, AVAGO_SERDES_TX_DATA_SEL_CORE);   /* Send Core Data */

  addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, SECOND_CM4_SBUS_ADDR);
  avago_serdes_set_tx_data_sel(aapl, addr, AVAGO_SERDES_TX_DATA_SEL_CORE);  /* Send Core Data */

  /* Frame first CM4 */
  addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, FIRST_CM4_SBUS_ADDR);
  if(rsfec_frame_lane(aapl, addr, 0x5) == 200) {
    aapl_log_printf(aapl, AVAGO_ERR, __func__, __LINE__, "Unable to frame!!!\n");
    return(1);
  }

  /* Frame second CM4 */
  addr = avago_make_addr3(addr_struct.chip, addr_struct.ring, SECOND_CM4_SBUS_ADDR);
  if(rsfec_frame_lane(aapl, addr, 0xf) == 200) {
    aapl_log_printf(aapl, AVAGO_ERR, __func__, __LINE__, "Unable to frame!!!\n");
    return(2);
  }
  return(0);
}

/** @} */
