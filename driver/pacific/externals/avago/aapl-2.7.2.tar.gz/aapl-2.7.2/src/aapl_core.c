/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* AAPL (ASIC and ASSP Programming Layer) "system level" calls (not AVAGO_SERDES, or */
/* SPICO, etc). */

/** Doxygen File Header */
/** @file */
/** @brief Core AAPL functions. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#define AAPL_CORE_FILE
#include "aapl.h"
#include "asic_info.h"      /* Include here to avoid multiple includes */

/* These values need to be distinct: */
#define AAPL_LSB_IGNORE (-1)        /* IP has no LSB */
#define AAPL_LSB_INIT (-2)          /* IP has LSB and cache not yet initialized */

/* Global default values: */
const char *aapl_default_server = "localhost";
const uint  aapl_default_port   = 90;

/* Forward declarations for private functions used in this file only */
#if AAPL_ALLOW_GPIO_JTAG
static BOOL avago_bit_banged_gpio_jtag_fn(Aapl_t *aapl, BOOL tms, BOOL tdi, BOOL trst_l, BOOL get_tdo);
static int avago_bit_banged_gpio_jtag_open_fn(Aapl_t *aapl);
static int avago_bit_banged_gpio_jtag_close_fn(Aapl_t *aapl);
#endif

#if AAPL_ALLOW_THREAD_SUPPORT
static AAPL_THREAD_STORAGE int ip_lock_count = 0; /* file scoped global that allows AAPL_IP_INFO_LOCK to be recursive */
#endif


volatile int aapl_sigint_detected = 0;

#if AAPL_ALLOW_SIGNALS
static void aapl_signal_handler(int dummy)
{
    (void)dummy;
    aapl_sigint_detected ++;
    if (aapl_sigint_detected >= 2)
    {
        printf("AAPL caught %d unhandled instances of SIGINT and is now exiting.\n", aapl_sigint_detected);
        exit(-2);
    }
    signal(SIGINT, aapl_signal_handler);
}
#endif /* AAPL_ALLOW_SIGNALS */

void aapl_sigint_check(Aapl_t *aapl)
{
    (void) aapl;
#if AAPL_ALLOW_SIGNALS
    if (aapl_sigint_detected > 0)
    {
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "%d SIGINT detected. Attemping to close connections.\n", aapl_sigint_detected);
        aapl->return_code --;
        /*aapl->debug = 0x19; // enable debug for diagnosing issues */
#if AAPL_ALLOW_THREAD_SUPPORT
        /* unlock everything in case it was in the middle of locking when the signal occurred */
        /* this is a little hokey, but we're already on the path of doing bad things -- this just helps AAPL to attempt a graceful exit */
        AAPL_SPICO_INT_UNLOCK;
        AAPL_CLOSE_UNLOCK;
        AAPL_AACS_UNLOCK;
        AAPL_IP_INFO_UNLOCK;
        AAPL_SENSOR_UNLOCK;
        AAPL_PRINTF_UNLOCK;
        AAPL_SBUS_UNLOCK;

        /*AAPL_SERDES_MEM_UNLOCK; // mem unlock has a global that we can not access, so just forcibly remove lock */
        pthread_mutex_unlock(&aapl->serdes_mem_mutex);
#endif /* AAPL_ALLOW_THREAD_SUPPORT */
        if (aapl->cmds_buffered) avago_aacs_flush(aapl); /* if there are any commands present flush them */
        if (aapl->socket != -1) aapl_close_connection(aapl);
        exit(-1);
    }
#endif /* AAPL_ALLOW_SIGNALS */
}


/** @brief   Checks if JTAG communication is used. */
/** @return  Returns TRUE if JTAG communication is used, FALSE otherwise. */
AAPL_INLINE BOOL aapl_is_jtag_communication_method(
    Aapl_t *aapl)  /**< [in] Pointer to AAPL structure. */
{
    return aapl->communication_method == AVAGO_BB_GPIO_JTAG ||
           aapl->communication_method == AVAGO_BB_JTAG ||
           aapl->communication_method == AVAGO_JTAG;
}

#if AAPL_ALLOW_I2C || AAPL_ALLOW_SYSTEM_I2C
/** @brief   Checks if I2C communication is used. */
/** @return  Returns TRUE if I2C communication is used, FALSE otherwise. */
BOOL aapl_is_i2c_communication_method(
    Aapl_t *aapl)  /**< [in] Pointer to AAPL structure. */
{
    return aapl->communication_method == AVAGO_I2C ||
           aapl->communication_method == AVAGO_SYSTEM_I2C;
}
#endif /* AAPL_ALLOW_I2C || AAPL_ALLOW_SYSTEM_I2C */

#if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO
/** @brief   Checks if MDIO communication is used. */
/** @return  Returns TRUE if MDIO communication is used, FALSE otherwise. */
BOOL aapl_is_mdio_communication_method(
    Aapl_t *aapl)  /**< [in] Pointer to AAPL structure. */
{
    return aapl->communication_method == AVAGO_MDIO ||
           aapl->communication_method == AVAGO_GPIO_MDIO;
}
#endif /* AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO */

/** @brief   Checks if SBus communication is used. */
/** @return  Returns TRUE if SBus communication is used, FALSE otherwise. */
BOOL aapl_is_sbus_communication_method(
    Aapl_t *aapl)   /**< [in] Pointer to AAPL structure. */
{
    return aapl->communication_method == AVAGO_SBUS ||
           aapl->communication_method == AVAGO_OFFLINE;
}

/** @brief   Checks if AACS communication is used. */
/** @return  Returns TRUE if AACS communication is used, FALSE otherwise. */
BOOL aapl_is_aacs_communication_method(
    Aapl_t *aapl)  /**< [in] Pointer to AAPL structure. */
{
    return aapl->aacs;
}

/** @cond INTERNAL */

void aapl_set_chip(Aapl_t *aapl, uint chipnum)
{
    if( aapl->chips > 1 )   /* Only needed if we have more than one chip. */
    {
        if( aapl->aacs )
        {
            char buf[16];
            snprintf(buf, 16, "chipnum %1u", chipnum);
            AAPL_SUPPRESS_ERRORS_PUSH(aapl);
            avago_aacs_send_command(aapl, buf);
            AAPL_SUPPRESS_ERRORS_POP(aapl);
        }
#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
        if( aapl->curr_chip != chipnum )
        {
            aapl->prev_opcode = 0;  /* Invalid after changing chips. */
            aapl->curr_chip = chipnum;
        }
#endif
    }
}

void aapl_set_chip_by_addr(Aapl_t *aapl, uint addr)
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr, &addr_struct);
    aapl_set_chip(aapl, addr_struct.chip);
}

/** @endcond */

#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
static char *avago_aacs_jtag_fn(
    Aapl_t *aapl,       /**< [in] Pointer to AAPL structure */
    int opcode,         /**< [in] The JTAG opcode. */
    int length,         /**< [in] The number of bits to be sent. */
    const char *tdi,    /**< [in] Data to be sent to scan chain. */
    BOOL get_tdo)       /**< [in] Is data back required? */
{
    int buf_size = length+1+32; /* +32 for the "jtag %d %04x" data that will get prepended */
    char *buffer = 0;
    (void) get_tdo;

    buffer = (char *)aapl_malloc(aapl, buf_size, __func__);

    if (buffer)
    {
        snprintf(buffer, buf_size, "jtag %d %04x %.*s", length, opcode, length, tdi);
        avago_aacs_send_command(aapl, buffer);
        aapl_free(aapl, buffer, __func__);
    }
    return aapl->data_char;
}

/* Send jtag opcode.  Handle caching to avoid setting same opcode redundantly. */
/* */
static void avago_jtag_set_opcode(Aapl_t *aapl, int opcode)
{
    if( opcode != aapl->prev_opcode ) /* do we need to send a new opcode? */
    {
        char op[64];
        aapl_hex_2_bin(op, opcode, 0, 10);
        avago_jtag_scan(aapl, 10, 2, op, NULL);
        aapl->prev_opcode = opcode;
    }
}

/* function that gets registered if in the proper mode -- do not call directly */
static char *avago_jtag_fn(
    Aapl_t *aapl,       /**< [in] Pointer to AAPL structure */
    int opcode,         /**< [in] The JTAG opcode. */
    int length,         /**< [in] The number of bits to be sent. */
    const char *tdi,    /**< [in] Data to be sent to scan chain. */
    BOOL get_tdo)       /**< [in] Is data back required? */
{
    char *buffer;
    /*if (get_tdo && (length < AAPL_LOG_PRINTF_BUF_SIZE - 1)) buffer = aapl->data_char; // use data char buffer if it's guaranteed to fit */
    if (get_tdo)  /* otherwise create a new buffer and use it */
        buffer = (char *)aapl_malloc(aapl, length+1+32, __func__); /* +32 for the "jtag %d %04x" data that will get prepended */
    else buffer = 0;

    avago_jtag_set_opcode(aapl, opcode);
    avago_jtag_scan(aapl, length, /* tms_cycles */ 1, tdi, buffer);
    aapl->data_char[0] = 0;

    if (buffer)
    {
        aapl_log_printf(aapl, AVAGO_DATA_CHAR, __func__, __LINE__, "%s", buffer);
        aapl_free(aapl, buffer, __func__);
    }
    return aapl->data_char;
}

/** @brief  Retrieves the jtag idcode from the device. */
/** @return Returns the jtag idcode value. */
static uint avago_get_jtag_idcode_fn(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint device)    /**< [in] Device number */
{
    aapl_set_chip(aapl, device);
    avago_jtag(aapl, 0x02b6, 32, "00000000000000000000000000000000");
    return aapl_strtoul(aapl->data_char, NULL, 2);
}
#endif /* AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS */


/** @brief   Sets the value of the async_cancel flag in Aapl_t. */
/** @details The async_cancel flag is used to terminate long AAPL */
/**          operations before they would otherwise return.  This is a */
/**          cooperative cancel, so only certain operations can be canceled. */
/**          The caller should clear this flag after use, before calling */
/**          another cancelable function. */
/** @see     aapl_get_async_cancel_flag(). */
/** @return  Returns the previous value of the flag. */
int aapl_set_async_cancel_flag(Aapl_t *aapl, int new_value)
{
    int old_value = aapl->async_cancel;
    aapl->async_cancel = new_value;
    ms_sleep(1);
    aapl->async_cancel = new_value;
    return old_value;
}

/** @brief   Gets the current value of the async_cancel flag from Aapl_t. */
/** @see     aapl_set_async_cancel_flag(). */
int aapl_get_async_cancel_flag(Aapl_t *aapl)
{
    return aapl->async_cancel;
}

#define FUNCTION_STRING(addr,a) if( addr == (fn_cast_t)a ) { aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "%-22s: %-s\n", label, #a); return; }
static void print_function(Aapl_t *aapl, const char *label, fn_cast_t addr)
{
    if( addr == 0 ) return;
#if AAPL_ALLOW_AACS
    FUNCTION_STRING(addr, avago_aacs_open_fn);
    FUNCTION_STRING(addr, avago_aacs_close_fn);
#  if AAPL_ALLOW_I2C || AAPL_ALLOW_SYSTEM_I2C
    FUNCTION_STRING(addr, avago_aacs_i2c_read_fn);
    FUNCTION_STRING(addr, avago_aacs_i2c_write_fn);
#  endif
#  if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO
    FUNCTION_STRING(addr, avago_aacs_mdio_fn);
    FUNCTION_STRING(addr, aapl_aacs_sbus_fn);
#  endif
#endif  /* AAPL_ALLOW_AACS */

#if AAPL_ALLOW_OFFLINE_SBUS
    FUNCTION_STRING(addr, avago_offline_sbus_fn);
#endif

#if AAPL_ALLOW_SYSTEM_I2C
    FUNCTION_STRING(addr, avago_system_i2c_open_fn);
    FUNCTION_STRING(addr, avago_system_i2c_close_fn);
    FUNCTION_STRING(addr, avago_system_i2c_read_fn);
    FUNCTION_STRING(addr, avago_system_i2c_write_fn);
#endif
#if AAPL_ALLOW_I2C || AAPL_ALLOW_SYSTEM_I2C
    FUNCTION_STRING(addr, avago_i2c_sbus_fn);
#endif
#if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO
    FUNCTION_STRING(addr, avago_mdio_sbus_fn);
#endif
#if AAPL_ALLOW_GPIO_MDIO
    FUNCTION_STRING(addr, avago_gpio_mdio_open_fn);
    FUNCTION_STRING(addr, avago_gpio_mdio_close_fn);
    FUNCTION_STRING(addr, avago_gpio_mdio_fn);
 /* FUNCTION_STRING(addr, avago_pmi_mdio_fn); */
#endif
#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
    FUNCTION_STRING(addr, avago_jtag_fn);
    FUNCTION_STRING(addr, avago_aacs_jtag_fn);
    FUNCTION_STRING(addr, avago_get_jtag_idcode_fn);
    FUNCTION_STRING(addr, avago_jtag_sbus_fn);
#endif
#if AAPL_ALLOW_GPIO_JTAG
    FUNCTION_STRING(addr, avago_bit_banged_gpio_jtag_open_fn);
    FUNCTION_STRING(addr, avago_bit_banged_gpio_jtag_close_fn);
    FUNCTION_STRING(addr, avago_bit_banged_gpio_jtag_fn);
#endif
    FUNCTION_STRING(addr, avago_serdes_spico_int_sbus_fn);
    FUNCTION_STRING(addr, avago_parallel_serdes_int_sbus_fn);
    FUNCTION_STRING(addr, avago_parallel_core_serdes_int_sbus_fn);
    FUNCTION_STRING(addr, avago_hard_sbus_reset_fn);
    FUNCTION_STRING(addr, aapl_built_in_logging_fn);
    aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "%-20s: function@0x%lx\n", label, addr);
}

#define PRINT_FUNCTION(aapl, member) print_function(aapl, #member, (fn_cast_t)aapl->member)
/* internal function used to print function registration information. */
static void aapl_print_registration_info(Aapl_t *aapl)
{
    aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__,  "Communication method:      %s (AACS: %x)\n", aapl_comm_method_to_str(aapl->communication_method), aapl->aacs);
    PRINT_FUNCTION(aapl, comm_open_fn);
    PRINT_FUNCTION(aapl, comm_close_fn);
    PRINT_FUNCTION(aapl, sbus_fn);
    PRINT_FUNCTION(aapl, sbus_fn_2);
    PRINT_FUNCTION(aapl, jtag_fn);
    PRINT_FUNCTION(aapl, bit_banged_jtag_fn);
    PRINT_FUNCTION(aapl, jtag_idcode_fn);
    PRINT_FUNCTION(aapl, i2c_read_fn);
    PRINT_FUNCTION(aapl, i2c_write_fn);
    PRINT_FUNCTION(aapl, mdio_fn);
    PRINT_FUNCTION(aapl, serdes_int_fn);
    PRINT_FUNCTION(aapl, parallel_serdes_int_fn);
    PRINT_FUNCTION(aapl, hard_sbus_reset_fn);
    PRINT_FUNCTION(aapl, pmi_fn);
#if AAPL_ENABLE_ATE_VEC
    PRINT_FUNCTION(aapl, ate_vec_fn);
#endif
    PRINT_FUNCTION(aapl, log_fn);
    PRINT_FUNCTION(aapl, log_open_fn);
    PRINT_FUNCTION(aapl, log_close_fn);
}


/* Internal function used to register common AAPL functions and built-in communication modes. Called by all of the other registration functions. */
static void aapl_register_common_fn(Aapl_t *aapl)
{
    /* register default functions that apply in most situations */
    aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Called %s() registration function.\n", __func__);
#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
    if (!aapl->jtag_fn && !aapl->aacs && aapl->bit_banged_jtag_fn) aapl->jtag_fn = &avago_jtag_fn; /* register standard JTAG function */
    if (!aapl->jtag_fn && aapl->aacs) aapl->jtag_fn = &avago_aacs_jtag_fn; /* register standard JTAG function */
    if (!aapl->jtag_idcode_fn) aapl_register_jtag_idcode_fn(aapl, &avago_get_jtag_idcode_fn);
#endif
    if( !aapl->parallel_serdes_int_fn )
    {
        if( aapl->serdes_int_fn )
            aapl_register_parallel_serdes_int_fn(aapl, &avago_parallel_core_serdes_int_sbus_fn);
        else
            aapl_register_parallel_serdes_int_fn(aapl, &avago_parallel_serdes_int_sbus_fn);
    }
    if (!aapl->serdes_int_fn) aapl_register_spico_int_fn(aapl, &avago_serdes_spico_int_sbus_fn);
}

/** @defgroup register Register User-supplied Communication Functions */
/** @{ */
/* */
/** @brief   Registers SBus functions. */
/** @details Open and close functions are optional, and can be NULL. */
/**          The arguments for the registered SBus function are: */
/**           - return: TRUE or FALSE to indicate if the command succeeded. */
/**           - addr: SBus address to operate on. Corresponds to the *_sbus_receiver_address ports of the SBus master. */
/**           - reg_addr: Data address within the given SBus address to operate on. Corresponds to the *_sbus_data_address ports on the SBus master. */
/**           - command: SBus command to send. Corresponds to the *_sbus_command ports on the SBus master. */
/**                 Required commands are: 1: write, 2: read, 0: reset */
/**           - sbus_data: Pointer to the SBus data to write. Results of SBus read operations will be placed here. */
void aapl_register_sbus_fn(Aapl_t *aapl,
    uint (* user_sbus_fn)(Aapl_t *, uint addr, unsigned char reg_addr, unsigned char command, uint *sbus_data),
    int (* comm_open_fn)(Aapl_t *),
    int (* comm_close_fn)(Aapl_t *)
)
{
    aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Called %s() registration function.\n", __func__);
    aapl->communication_method = AVAGO_SBUS;
    aapl->sbus_fn = user_sbus_fn;
    aapl->sbus_fn_2 = 0;

    aapl->comm_open_fn = comm_open_fn;
    aapl->comm_close_fn = comm_close_fn;

    aapl_register_common_fn(aapl); /* register common functions (ie spico_int, sbus) that can be automatically done */
}

#if AAPL_ENABLE_ATE_VEC
void aapl_register_ate_vec_fn(Aapl_t *aapl,
    int (* ate_vec_fn)(Aapl_t *, const char *command))
{
    aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Called %s() registration function.\n", __func__);
    aapl->ate_vec_fn = ate_vec_fn;

    aapl_register_common_fn(aapl); /* register common functions (ie spico_int, sbus) that can be automatically done */
}
#endif

#if AAPL_ALLOW_AACS
/** @brief   Registers SBus functions. */
/** @details Open and close functions are optional, and can be NULL. */
/**          The arguments for the registered SBus function are: */
/**             return: TRUE or FALSE to indicate if the command succeeded. */
/**             addr: SBus address to operate on. Corresponds to the *_sbus_receiver_address ports of the SBus master. */
/**             reg_addr: Data address within the given SBus address to operate on. Corresponds to the *_sbus_data_address ports on the SBus master. */
/**             command: SBus command to send. Corresponds to the *_sbus_command ports on the SBus master. */
/**                 Required commands are: 1: write, 2: read, 0: reset */
/**             sbus_data: Pointer to the SBus data to write. Results of SBus read operations will be placed here. */
/**             recv_data_back: When 0, the command may be queued for execution later. */
static void aapl_register_sbus_fn_2(Aapl_t *aapl,
    uint (* user_sbus_fn)(Aapl_t *, uint addr, unsigned char reg_addr, unsigned char command, uint *sbus_data, uint recv_data_back),
    int (* comm_open_fn)(Aapl_t *),
    int (* comm_close_fn)(Aapl_t *)
)
{
    aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Called %s() registration function.\n", __func__);
    aapl->communication_method = AVAGO_SBUS;
    aapl->sbus_fn = 0;
    aapl->sbus_fn_2 = user_sbus_fn;

    aapl->comm_open_fn = comm_open_fn;
    aapl->comm_close_fn = comm_close_fn;

    aapl_register_common_fn(aapl); /* register common functions (ie spico_int, sbus) that can be automatically done */
}
#endif

#if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO
/** @brief   Registers MDIO functions. */
/** @brief   This function will be used to implement SBus commands. */
/** @details Open and close functions are optional, and can be NULL. */
void aapl_register_mdio_fn(Aapl_t *aapl,
    uint (* mdio_fn)(Aapl_t *, Avago_mdio_cmd_t mdio_cmd, uint port_addr, uint dev_addr, uint reg_addr, uint data),
    int (* comm_open_fn)(Aapl_t *),
    int (* comm_close_fn)(Aapl_t *)
)
{
    aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Called %s() registration function.\n", __func__);
    aapl->communication_method = AVAGO_MDIO;
    aapl->sbus_fn = &avago_mdio_sbus_fn; /* shared SBus function for MDIO */
    aapl->sbus_fn_2 = 0;

    aapl->comm_open_fn = comm_open_fn;
    aapl->comm_close_fn = comm_close_fn;

    aapl->mdio_fn = mdio_fn;

    aapl_register_common_fn(aapl); /* register common functions (ie spico_int, sbus) that can be automatically done */
}
#endif

#if AAPL_ALLOW_I2C || AAPL_ALLOW_SYSTEM_I2C
/** @brief   Registers I2C functions. */
/** @brief   These functions will be used to implement SBus commands. */
/** @details Open and close functions are optional, and can be NULL. */
/**          The arguments for the registered I2C functions are: */
/**              return   length (>= 0) on success, -1 on failure. */
/**              aapl     Pointer to AAPL structure. */
/**              dev_addr I2C address to write/read. */
/**              length   Number of bytes to write/read from buffer. */
/**              *buffer  Pointer to the buffer containing bytes to be written/read to/from the device. */
void aapl_register_i2c_fn(Aapl_t *aapl,
    int (* i2c_read_fn)(Aapl_t *, unsigned int dev_addr, unsigned int length, unsigned char * buffer),
    int (* i2c_write_fn)(Aapl_t *, unsigned int dev_addr, unsigned int length, unsigned char * buffer),
    int (* comm_open_fn)(Aapl_t *),
    int (* comm_close_fn)(Aapl_t *)
)
{
    aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Called %s() registration function.\n", __func__);
    aapl->communication_method = AVAGO_I2C;
    aapl->sbus_fn = &avago_i2c_sbus_fn; /* implementation of SBus via I2C */
    aapl->sbus_fn_2 = 0;

    aapl->comm_open_fn = comm_open_fn;
    aapl->comm_close_fn = comm_close_fn;

    aapl->i2c_write_fn = i2c_write_fn;
    aapl->i2c_read_fn = i2c_read_fn;

    aapl_register_common_fn(aapl); /* register common functions (ie spico_int, sbus) that can be automatically done */
}
#endif

#if AAPL_ALLOW_JTAG
/** @brief   Registers JTAG functions. */
/** @brief   This function will be used to implement SBus commands. */
/** @details Open and close functions are optional, and can be NULL. */
void aapl_register_jtag_fn(Aapl_t *aapl,
    char *(* jtag_fn)(Aapl_t *, int opcode, int length, const char *tdi, BOOL get_tdo),
    int (* comm_open_fn)(Aapl_t *),
    int (* comm_close_fn)(Aapl_t *)
)
{
    aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Called %s() registration function.\n", __func__);
    aapl->communication_method = AVAGO_JTAG;
    aapl->sbus_fn = &avago_jtag_sbus_fn; /* implementation of SBus via JTAG */
    aapl->sbus_fn_2 = 0;

    aapl->comm_open_fn = comm_open_fn;
    aapl->comm_close_fn = comm_close_fn;

    aapl->jtag_fn = jtag_fn;

    aapl_register_common_fn(aapl); /* register common functions (ie spico_int, sbus) that can be automatically done */
}


/** @brief   Registers bit-banged JTAG functions. */
/** @brief   This function will be used to implement SBus commands. */
/** @details Open and close functions are optional, and can be NULL. */
void aapl_register_bit_banged_jtag_fn(Aapl_t *aapl,
    BOOL (* jtag_fn)(Aapl_t *, BOOL tms, BOOL tdi, BOOL trst_l, BOOL get_tdo),
    int (* comm_open_fn)(Aapl_t *),
    int (* comm_close_fn)(Aapl_t *)
)
{
    aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Called %s() registration function.\n", __func__);
    aapl->communication_method = AVAGO_BB_JTAG;
    aapl->sbus_fn = &avago_jtag_sbus_fn;
    aapl->sbus_fn_2 = 0;

    aapl->comm_open_fn = comm_open_fn;
    aapl->comm_close_fn = comm_close_fn;

    aapl->jtag_fn = &avago_jtag_fn; /* use the built in JTAG function, which will call the bit banged one at a lower level */
    aapl->bit_banged_jtag_fn = jtag_fn;

    aapl_register_common_fn(aapl); /* register common functions (ie spico_int, sbus) that can be automatically done */
}
#endif /* AAPL_ALLOW_JTAG */

/** @brief   Registers a function to obtain the JTAG IDCODE of a device. */
void aapl_register_jtag_idcode_fn(Aapl_t *aapl,
    uint (* jtag_idcode_fn)(Aapl_t *, uint device)
)
{
    aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Called %s() registration function.\n", __func__);
    aapl->jtag_idcode_fn = jtag_idcode_fn;
}

/** @brief   Registers a SerDes SPICO interrupt function. */
/** @brief   If registered, SPICO interrupts will be sent via this function, otherwise interrupts */
/**          will be sent via SBus commands. */
void aapl_register_spico_int_fn(Aapl_t *aapl,
    uint  (*serdes_int_fn)     (Aapl_t *aapl, uint addr, int int_code, int int_data)
)
{
    aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Called %s() registration function.\n", __func__);
    aapl->serdes_int_fn = serdes_int_fn;
}

/** @brief   Registers an SBus reset function. */
/** @brief   SBus resets will be sent via the registered function. */
/** @brief   This function performs an SBus reset operation on the chip of the addressed SerDes. */
void aapl_register_hard_sbus_reset_fn(Aapl_t *aapl,
    int  (*hard_sbus_reset_fn)(Aapl_t *aapl, uint addr)
)
{
    aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Called %s() registration function.\n", __func__);
    aapl->hard_sbus_reset_fn = hard_sbus_reset_fn;
}

/** @brief   Registers a function to execute an interrupt on multiple SerDes in parallel. */
/** @details If registered, parallel SPICO interrupts will be sent via this function; */
/**          otherwise parallel interrupts will be sent via SBus commands. */
/** @details Note that addr_list members contain a results field into which */
/**          should be written the return value from each SerDes. */
/** @details When called, the registered function should return 1 if all interrupts successfully return the same value, */
/**          return 0 if all interrupts successfully return with non-identical values, */
/**          and return -1 and decrement aapl->return_code if any failure. */
/** @details For an example implementation using SBus, see avago_parallel_serdes_int_sbus_fn(). */
/** @details For an example serial implementation, see avago_parallel_core_serdes_int_sbus_fn(). */
void aapl_register_parallel_serdes_int_fn(Aapl_t *aapl,
    int  (*parallel_serdes_int_fn) (Aapl_t *aapl, Avago_addr_t *addr_list, int int_code, int int_data))
{
    aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Called %s() registration function.\n", __func__);
    aapl->parallel_serdes_int_fn = parallel_serdes_int_fn;
}

/* */
/** @} */

/* Internal function called by aapl_connect to register built-i functions if the user hasn't registered anything */
static void aapl_register_built_in_fn(Aapl_t *aapl)
{
    /* this function only gets called if nothing was registered, therefore we are probably in AACS mode, */
    /* in which this function will register things, or we're in an AAPL supplied mode, which we will also auto-detect */

    Aapl_comm_method_t comm_method = aapl->communication_method; /* save for later */

    if( aapl->communication_method == AVAGO_GPIO_MDIO || aapl->communication_method == AVAGO_SYSTEM_I2C
        || aapl->communication_method == AVAGO_OFFLINE || aapl->communication_method == AVAGO_BB_GPIO_JTAG )
         aapl->aacs = 0;
    else aapl->aacs = 1; /* This function was called since nothing was pre-registered, which means we must be in AACS mode */

    aapl_print_registration_info(aapl);

    if( !aapl->hard_sbus_reset_fn) aapl_register_hard_sbus_reset_fn(aapl, &avago_hard_sbus_reset_fn);
    if( !aapl->log_fn ) aapl_register_logging_fn(aapl, &aapl_built_in_logging_fn, 0, 0);

#if AAPL_ALLOW_AACS
    if (aapl->aacs)
    {
        aapl_register_sbus_fn_2(aapl, &aapl_aacs_sbus_fn, &avago_aacs_open_fn, &avago_aacs_close_fn);
        aapl->communication_method = comm_method; /* restore original value in case the above call changed it (so we can register other functions later in this function) */
        /* now register AACS based MDIO and I2C functions so that the user can send raw I2C and MDIO commands using AACS */
#if AAPL_ALLOW_I2C
        aapl->i2c_write_fn = &avago_aacs_i2c_write_fn;
        aapl->i2c_read_fn = &avago_aacs_i2c_read_fn;
#endif
#if AAPL_ALLOW_MDIO
        aapl->mdio_fn = &avago_aacs_mdio_fn;
#endif
    }
#endif

#if AAPL_ALLOW_I2C || AAPL_ALLOW_SYSTEM_I2C
    if (aapl_is_i2c_communication_method(aapl))
    {
#if AAPL_ALLOW_AACS
        if (aapl->aacs)
            aapl_register_i2c_fn(aapl, &avago_aacs_i2c_read_fn, &avago_aacs_i2c_write_fn, &avago_aacs_open_fn, &avago_aacs_close_fn);
#endif
#if AAPL_ALLOW_SYSTEM_I2C
        if (!aapl->aacs)
            aapl_register_i2c_fn(aapl, &avago_system_i2c_read_fn, &avago_system_i2c_write_fn, &avago_system_i2c_open_fn, &avago_system_i2c_close_fn);
#endif
    }
#endif /* AAPL_ALLOW_I2C || AAPL_ALLOW_SYSTEM_I2C */

#if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO
    if(aapl_is_mdio_communication_method(aapl))
    {
#if AAPL_ALLOW_AACS
        if (aapl->aacs)
            aapl_register_mdio_fn(aapl, &avago_aacs_mdio_fn, &avago_aacs_open_fn, &avago_aacs_close_fn);
#endif
#if AAPL_ALLOW_GPIO_MDIO
    if( aapl->communication_method == AVAGO_GPIO_MDIO )
        aapl_register_mdio_fn(aapl, &avago_gpio_mdio_fn, &avago_gpio_mdio_open_fn, &avago_gpio_mdio_close_fn);
#endif
    }
#endif /* AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO */

#if AAPL_ALLOW_OFFLINE_SBUS
    if (aapl->communication_method == AVAGO_OFFLINE)
    {
        aapl->sbus_fn       = &avago_offline_sbus_fn;
        aapl->sbus_fn_2     = 0;
        aapl->comm_open_fn  = &avago_offline_open_fn;
        aapl->comm_close_fn = &avago_offline_close_fn;
        /* No JTAG function gets registered for JTAG mode */
    }
#endif

#if AAPL_ALLOW_JTAG && AAPL_ALLOW_AACS
#if AAPL_ALLOW_GPIO_JTAG
    if(aapl->communication_method == AVAGO_BB_GPIO_JTAG)
    {
        aapl_register_jtag_fn(aapl, &avago_jtag_fn, 0, 0);
        aapl_register_bit_banged_jtag_fn(aapl, &avago_bit_banged_gpio_jtag_fn, &avago_bit_banged_gpio_jtag_open_fn, &avago_bit_banged_gpio_jtag_close_fn);
    }
    else
#endif
    if(aapl->communication_method == AVAGO_JTAG)
        aapl_register_jtag_fn(aapl, &avago_aacs_jtag_fn, &avago_aacs_open_fn, &avago_aacs_close_fn);
    else if(aapl->communication_method == AVAGO_BB_JTAG)
        aapl_register_jtag_fn(aapl, &avago_jtag_fn, &avago_aacs_open_fn, &avago_aacs_close_fn);
#endif /* AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS */

    aapl->communication_method = comm_method; /* restore original value in case one of the registration functions changed it */
    aapl_print_registration_info(aapl);

    if (!aapl->sbus_fn && !aapl->sbus_fn_2) aapl_fail(aapl, __func__, __LINE__, "AAPL SBus function not registered.\n");
}

/** @brief   Opens a connection to an Avago device. */
/** @details If aacs_server is NULL, assumes that the aacs_server and tcp_port */
/**          fields of Aapl_t have already been set. */
/** @return  void, but decrements aapl->return_code value on error. */
void aapl_connect(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    const char *aacs_server,    /**< [in] AACS server name string. */
    int tcp_port)               /**< [in] TCP port number for AACS server. */
{
    (void)aacs_server;
    (void)tcp_port;

#if AAPL_ALLOW_AACS
    if( aacs_server )
    {
        uint len;
        if (!aapl->aacs_server)
        {
            aapl_fail(aapl, __func__, __LINE__, "aapl_connect() called using Aapl_t struct that wasn't initialized.\n");
            return;
        }
        len = strlen(aacs_server)+1;
        aapl->aacs_server = (char *) aapl_realloc(aapl, aapl->aacs_server, len, __func__);
        if( aapl->aacs_server ) strncpy(aapl->aacs_server, aacs_server, len);
    }
    if( tcp_port ) aapl->tcp_port = tcp_port;
#endif

    if (!aapl->sbus_fn && !aapl->sbus_fn_2)
    {
        aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "%s() called and no SBus function has been registered. Calling aapl_register_built_in_fn() to attempt to register built-in functions.\n", __func__);
        aapl_register_built_in_fn(aapl);
    }
    else
    {
        aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "%s() called and SBus function has been registered.\n", __func__);
        aapl_print_registration_info(aapl);
    }

    if (aapl->socket < 0 && aapl->comm_open_fn) aapl->comm_open_fn(aapl);  /* avago_aacs_open_fn, avago_aacs_close_fn */
    aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "Current aapl->socket: %d. return_code = %d\n", aapl->socket, aapl->return_code);
    aapl_sigint_check(aapl);
}

/** @cond INTERNAL */

/** @brief  Closes the current connection to the AAPL device. */
/** @detail Does not flush buffered commands to avoid infinite loops on error. */
/** @return void */
void aapl_close_connection2(
    Aapl_t *aapl)   /**< [in] Pointer to Aapl_t structure. */
{
    if (aapl->comm_close_fn) aapl->comm_close_fn(aapl); /* avago_aacs_close_fn */
}

/** @endcond */

/** @brief   Closes the current connection to the AAPL device. */
/** @details Will flush any buffered commands first. */
/** @return  void */
void aapl_close_connection(
    Aapl_t *aapl)   /**< [in] Pointer to Aapl_t structure. */
{
    AAPL_CLOSE_LOCK;
    AAPL_SUPPRESS_ERRORS_PUSH(aapl);
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Closing connection to %s:%d (socket #%d).\n", aapl->aacs_server, aapl->tcp_port, aapl->socket);
    if( aapl->socket >= 0 ) avago_aacs_flush(aapl); /* forces a flush */
    AAPL_SUPPRESS_ERRORS_POP(aapl);
    aapl_close_connection2(aapl);
    aapl->socket = -1; /* socket is now invalid */
    #if AAPL_ALLOW_AACS
    if( aapl->sbus_fn == 0 && aapl->sbus_fn_2 == aapl_aacs_sbus_fn )
        aapl->sbus_fn_2 = 0;
    #endif /* AAPL_ALLOW_AACS */
    AAPL_CLOSE_UNLOCK;
    aapl_sigint_check(aapl);
}

/** @brief Checks the socket status of aapl->socket */
/** */
/** @return 0 if the socket is still connected, -1 if it is closed */
int aapl_connection_status(
    Aapl_t *aapl)   /**< [in] Pointer to AAPL structure. */
{
    if( aapl->socket < 0 )
        return -1;
    #if AAPL_ALLOW_AACS
    if (aapl->aacs)
    {
        /* If the socket has closed, the only way of knowing is to send something and see if recv gets back 0, indicating the socket is closed. */
        /* If that happens, we will then close the socket descriptor. */
        int rc, error = 0;
        socklen_t len = sizeof (error);
        avago_aacs_send_command(aapl, "version");

        rc = getsockopt (aapl->socket, SOL_SOCKET, SO_ERROR, (void *)&error, &len );

        aapl_log_printf(aapl, AVAGO_DEBUG8, __func__, __LINE__, "socket: %d getsockopt: %d errno: %s\n", aapl->socket, rc, aapl_tcp_strerr());

        return rc;
    }
    #endif
    return 0;
}

/** @cond INTERNAL */

/* Internal function used to reconnect to a closed socket */
/* Returns -1 for failure, 1 if already connected, and 0 for successful reconnect. */
int aapl_reconnect(Aapl_t *aapl, const char * command)
{
    int rc = aapl->return_code;
    if (aapl->socket >= 0 || aapl->disable_reconnect)
        return 1;   /* Already connected. */
    aapl_connect(aapl, 0, 0);   /* try reconnecting once */
    if (aapl->return_code - rc != 0)
    {
        aapl_fail(aapl, __func__, __LINE__, "The command \"%s\" was sent to a closed socket.\n", command);
        aapl->data = 0;
        aapl_log_printf(aapl, AVAGO_DATA_CHAR, 0, 0, "");
        return -1;
    }
    return 0;
}

/** @endcond */

/*============================================================================= */
/* AAPL CONSTRUCT */
/** @brief Constructs the Aapl_t structure. Allocates memory and sets default values. */
/** @warning Generally the user should not read or modify any elements of this struct. */
/** Use functions provided to get and set information in this structure. */
/** @return A pointer to the Aapl_t struct */
Aapl_t *aapl_construct()
{
    int i;
/* TBD:  The malloc()s here can't call aapl_malloc() because it needs an aapl */
/* pointer with log buffer contents, so probably they should report an error */
/* somehow and exit(). */

    Aapl_t *aapl = (Aapl_t *) AAPL_MALLOC(sizeof(Aapl_t));
    if( !aapl ) return 0;

    memset(aapl, 0, sizeof(*aapl));   /* set all bytes to zero */

#if AAPL_ALLOW_SIGNALS
    signal(SIGINT, aapl_signal_handler);
#endif

#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
    memset(aapl->sbus_reg, '0', sizeof(aapl->sbus_reg));   /* set sbus_reg to ASCII '0' */
#endif

    for( i = 0; i < AAPL_MAX_CHIPS; i++ )
        aapl->chip_name[i] = aapl->chip_rev[i] = "";

    memset(aapl->lsb_rev,AAPL_LSB_INIT, sizeof(aapl->lsb_rev));

    aapl->socket         = -1;  /* No socket connected yet */
    aapl->aacs_server    = aapl_strdup(aapl_default_server);
    aapl->tcp_port       = aapl_default_port;

    aapl->data_char      = (char *) AAPL_MALLOC(AAPL_LOG_BUF_SIZE);
    if( !aapl->data_char ) { AAPL_FREE(aapl); return 0; }
    aapl->data_char_end  = aapl->data_char;
    aapl->data_char_size = AAPL_LOG_BUF_SIZE;
    *aapl->data_char     = '\0';

    aapl->debug = 0;            /* global debug level */

    aapl->enable_debug_logging      = AAPL_DEFAULT_ENABLE_DEBUG_LOGGING;
    aapl->enable_stream_logging     = AAPL_DEFAULT_ENABLE_STREAM_LOGGING;
    aapl->enable_stream_err_logging = AAPL_DEFAULT_ENABLE_STREAM_ERR_LOGGING;
    aapl->logging_file_path         = NULL; /* Logging of messages to file is stopped */

    aapl->chips                 = AAPL_NUMBER_OF_CHIPS_OVERRIDE;
    aapl->sbus_rings            = AAPL_NUMBER_OF_RINGS_OVERRIDE;

# ifdef AAPL_LOG_TIME_STAMPS
    aapl->log_time_stamps       = AAPL_LOG_TIME_STAMPS;
# endif
    aapl->serdes_int_timeout    = AAPL_SERDES_INT_TIMEOUT;
    aapl->sbus_mdio_timeout     = AAPL_SBUS_MDIO_TIMEOUT;
    aapl->max_cmds_buffered     = AAPL_MAX_CMDS_BUFFERED;
    aapl->communication_method  = AAPL_DEFAULT_COMM_METHOD;
    aapl->i2c_base_addr         = AAPL_DEFAULT_I2C_BASE_ADDR;
    aapl->mdio_base_port_addr   = AAPL_DEFAULT_MDIO_BASE_PORT_ADDR;
    aapl->ansi_colors           = AAPL_ALLOW_ANSI_COLORS;
    aapl->sbus_tdr_opcode_base  = AAPL_DEFAULT_SBUS_TDR_OPCODE_BASE;

#if AAPL_ALLOW_THREAD_SUPPORT
    /*pthread_mutex_init(&aapl->sbus_execute_mutex, NULL); */
    /*pthread_cond_init(&aapl->sbus_execute_cv, NULL); */
    pthread_mutex_init(&aapl->aacs_mutex, NULL);
    pthread_mutex_init(&aapl->spico_int_mutex, NULL);
    pthread_mutex_init(&aapl->serdes_mem_mutex, NULL);
    pthread_mutex_init(&aapl->ip_info_mutex, NULL);
    pthread_mutex_init(&aapl->sensor_mutex, NULL);
#endif

    return aapl;    /* returns pointer to newly created struct */
}


/*============================================================================= */
/* AAPL DESTRUCT */
/** */
/** @brief Frees memory of an aapl struct when it is no longer needed. */
/** @return void */
void aapl_destruct(
    Aapl_t *aapl)   /**< [in] Pointer to Aapl_t structure. */
{
#if AAPL_ENABLE_FILE_IO
    int chip, addr, ring;
    for (chip = 0; chip < AAPL_MAX_CHIPS; chip++)
        for (ring = 0; ring < AAPL_MAX_RINGS; ring++)
            for (addr = 0; addr <= 0xff; addr++)
                if (aapl->firmware_file[chip][ring][addr]) aapl_free(aapl, aapl->firmware_file[chip][ring][addr], __func__);
#endif

#if AAPL_ALLOW_THREADED_SBUS || AAPL_ALLOW_THREAD_SUPPORT
    aapl->destroy_thread = 1;
#endif
#if AAPL_ALLOW_THREADED_SBUS
    if (aapl->sbus_thread) pthread_join(aapl->sbus_thread, NULL);
#endif

    /* If the descriptor is open, close it. */
    aapl_close_connection(aapl); /* Handles flushing any buffered writes. */

#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
    if (aapl->buf_cmd)              AAPL_FREE(aapl->buf_cmd);
    aapl->buf_cmd = 0;
#endif

    if (aapl->data_char)            AAPL_FREE(aapl->data_char);
    if (aapl->log)                  AAPL_FREE(aapl->log);
    if (aapl->aacs_server)          AAPL_FREE(aapl->aacs_server);
    if (aapl->aacs_server_buffer)   AAPL_FREE(aapl->aacs_server_buffer);

    aapl->data_char = 0;
    aapl->log = 0;
    aapl->aacs_server = 0;
    aapl->aacs_server_buffer = 0;

#if AAPL_ALLOW_OFFLINE_SBUS
    if (aapl->offline_sbus_reg)     AAPL_FREE(aapl->offline_sbus_reg);
    aapl->offline_sbus_reg = 0;
#endif

    AAPL_FREE(aapl);
}

/*============================================================================= */
/* AAPL GET RETURN CODE */
/** */
/** @brief Returns the return code and then sets it to zero. */
/**    Values less than 0 indicate that some failure has occurred. */
/** @warning Calling this function clears the return code. */
/** @return The current value of the AAPL return code. */
int aapl_get_return_code(
    Aapl_t *aapl)   /**< [in] Pointer to Aapl_t structure. */
{
    int x;
    x = aapl->return_code;
    aapl->return_code = 0;
    return x;
}


/* The following functions return information from the AAPL struct. addr is used to return specific information for that element. */

/** @brief  Gets the number of chips found on the current ring. */
/** @return The number of chips on the current ring. */
uint aapl_get_chips(
    Aapl_t *aapl)   /**< [in] Pointer to Aapl_t structure. */
{
    return aapl->chips;
}

/** @brief  Gets the maximum sbus address for the specified chip and sbus ring within that chip. */
/** @return Maximum sbus address of the sbus ring and chip specified by the sbus address. */
uint aapl_get_max_sbus_addr(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr,&addr_struct);
    if( addr_struct.chip >= AAPL_MAX_CHIPS || addr_struct.ring >= AAPL_MAX_RINGS )
        return 0;
    return aapl->max_sbus_addr[addr_struct.chip][addr_struct.ring];
}

/** @brief Get the JTAG idcode of the specified chip */
/** @return JTAG idcode of the current sbus ring (specified by the sbus address) */
uint aapl_get_jtag_idcode(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr,&addr_struct);
    if( addr_struct.chip >= AAPL_MAX_CHIPS ) addr_struct.chip = 0;
    return aapl->jtag_idcode[addr_struct.chip];
}

/** @brief Get the chip name of the specified chip */
/** @return The chip name of the current chip (specified by the sbus address) */
/**        Returns the aapl->data_char string pointer, which is a C-string holding the command status. */
/**        aapl->data is set to length of the returned string. */
/** */
const char *aapl_get_chip_name(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr,&addr_struct);
    if( addr_struct.chip >= AAPL_MAX_CHIPS )
        return "unknown";
    return aapl->chip_name[addr_struct.chip];
}

/** @brief  Gets the chip revision number of the specified chip. */
/** @return The chip revision number of the current chip (specified by the sbus address). */
const char *aapl_get_chip_rev_str(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr,&addr_struct);
    if( addr_struct.chip >= AAPL_MAX_CHIPS )
        return "";
    return aapl->chip_rev[addr_struct.chip];
}



/** @brief Gets the Logical Sub Block (LSB) revision number of the device. */
/** @details */
/** Note: aapl_get_lsb_rev() stores the lowest lsb rev in [0][0][0xff] */
/** @return The Logical Sub Block (LSB) revision number of the addressed device. */
uint aapl_get_lsb_rev(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr,&addr_struct);

    if( aapl_check_broadcast_address(aapl, addr, __func__, __LINE__, FALSE) )
    {
        if (aapl->lsb_rev[0][0][addr_struct.sbus] == AAPL_LSB_INIT) /* if nothing has yet been discovered, then go check all addresses */
        {
            BOOL st;
            Avago_addr_t start, stop, next;
            for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, AAPL_BROADCAST_IGNORE_LANE);
                 st;
                 st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_IGNORE_LANE) )
            {
                uint addr = avago_struct_to_addr(&next);
                if (aapl_get_ip_type(aapl, addr) != AVAGO_SERDES) continue;
                aapl_get_lsb_rev(aapl, addr);
                break;
            }
        }
        /* return the "broadcast" LSB revision, which is the lowest revision */
        /* discovered for that type of device. */
        /* If not sbus broadcast, return rev for chip 0, ring 0. */
        return aapl->lsb_rev[0][0][addr_struct.sbus];
    }

    if( addr_struct.chip >= AAPL_MAX_CHIPS ||
        addr_struct.ring >= AAPL_MAX_CHIPS )
        return 0;

    if( aapl->lsb_rev[AAPL_3D_ARRAY_ADDR(addr_struct)] == AAPL_LSB_INIT )
    {
        signed char lsb_rev = avago_serdes_get_lsb_rev(aapl, addr);
        aapl->lsb_rev[AAPL_3D_ARRAY_ADDR(addr_struct)] = lsb_rev;
        if( lsb_rev >= 0 )
        {
            int baddr = 0;
            Avago_ip_type_t ip_type = aapl_get_ip_type(aapl, addr);
            if(      ip_type == AVAGO_SERDES ) baddr = AVAGO_SERDES_D6_BROADCAST;
            else if( ip_type == AVAGO_M4     ) baddr = AVAGO_SERDES_M4_BROADCAST;
            else if( ip_type == AVAGO_P1     ) baddr = AVAGO_SERDES_P1_BROADCAST;
            /* If the broadcast address LSB rev is 0 or higher than the current SerDes, set it to the current SerDes' value. */
            if( baddr > 0 && (aapl->lsb_rev[0][0][baddr] == AAPL_LSB_INIT || aapl->lsb_rev[0][0][baddr] > lsb_rev) )
                 aapl->lsb_rev[0][0][baddr] = lsb_rev;   /* set to current */
        }
        aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Setting aapl->lsb_rev for %s to 0x%04x\n", aapl_addr_to_str(0xff), aapl->lsb_rev[AAPL_3D_ARRAY_ADDR(addr_struct)]);
    }
    return aapl->lsb_rev[AAPL_3D_ARRAY_ADDR(addr_struct)];
}


/*============================================================================= */
/* IP REV */
/* Returns the IP revision number */
static int ip_rev(Aapl_t *aapl, uint sbus_addr)
{
    Avago_ip_type_t ip_type = aapl_get_ip_type(aapl, sbus_addr);
    if (!aapl_check_process(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28)) return -1;

    switch( ip_type )
    {
    case AVAGO_SERDES:
    case AVAGO_P1:
    case AVAGO_M4:
        switch( aapl_get_process_id(aapl, sbus_addr) )
        {
        case AVAGO_TSMC_28: {
            /* newer serdes have the data available from 0xfe */
            int ret_data = avago_sbus_rd(aapl, sbus_addr, 0xfe);
            if( 0 == ret_data )
            {
                /* Older (Denali, 521) SerDes must read the data from the ESB: */
                ret_data = avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, 0x0303);
            }
            return (ret_data >> 8) & 0xff;
            }
        case AVAGO_TSMC_16:
            {
                int iprev = (avago_sbus_rd(aapl, sbus_addr, 0xfe) >> 8) & 0xff;
                int orig_iprev = iprev;
                if( iprev == 0x22 )
                {
                    int sbus = sbus_addr & 0xff;
                    if( (sbus == 8 || sbus == 9) && aapl_get_jtag_idcode(aapl,0) == 0x09b1657f ) /* Fermi */
                        iprev = 0x28; /* sd16C_txpam4_rxcm4_nx_03 has wrong ip rev */
                    else if( aapl_get_jtag_idcode(aapl,0) == 0x09c2557f ) /* FermiB */
                        iprev = 0x28; /* sd16C_txpam4_rxcm4_nx_03 has wrong ip rev */
                    else if( aapl_get_jtag_idcode(aapl,0) == 0x19b0257f ) /* SkyboltTC Simulation */
                        iprev = 0x28; /* sd16C_txcpam4_rxcm4_ns_03 has wrong ip rev */
                }
                if( iprev == 0x51 && (sbus_addr&0xff) <= 7 && aapl_get_jtag_idcode(aapl, 0) == 0x49c2557f )   /* FermiB 2.0 */
                    iprev = 0x510; /* Duplicate Id. These addresses are the ones not going to customers, so remap them internally. */
                if( orig_iprev != iprev )
                    aapl_log_printf(aapl,AVAGO_DEBUG2,__func__,__LINE__,"SBus %s: Correcting SerDes iprev from 0x%02x -> 0x%02x\n", aapl_addr_to_str(sbus_addr), orig_iprev, iprev);
                return iprev;
            }
        case AVAGO_TSMC_07:
            return (avago_sbus_rd(aapl, sbus_addr, 0xfe) >> 8) & 0xff;
        default:
            return avago_sbus_rd(aapl, sbus_addr, 0xfe) & 0xff;
        }

    case AVAGO_PCIE_PCS:                return (avago_sbus_rd(aapl, sbus_addr, 0x00) >> 1) & 0xf;

    case AVAGO_AVSP_CONTROL_LOGIC:
    case AVAGO_PCS64B66B:
    case AVAGO_PCS64B66B_FEC:
    case AVAGO_SAPPH_GBX:               return (avago_sbus_rd(aapl, sbus_addr, 0x00) >> 5) & 7;

    case AVAGO_CORE_PLL:                return  avago_sbus_rd(aapl, sbus_addr, 0x00) >> 28;
    case AVAGO_AUTO_NEGOTIATION:        return  avago_sbus_rd(aapl, sbus_addr, 0x23) >> 1;
    case AVAGO_APC:                     return  avago_sbus_rd(aapl, sbus_addr,   62);

    case AVAGO_MLD:
    case AVAGO_OPAL_CONTROL:
    case AVAGO_OPAL_RSFEC528:
    case AVAGO_OPAL_RSFEC528_544:
    case AVAGO_PAD_CONTROL:
    case AVAGO_RSFEC_BRIDGE:            return (avago_sbus_rd(aapl, sbus_addr, 0xfc) >> 12) & 0xf;

    case AVAGO_OPAL_HOST_ALIGNER:
    case AVAGO_OPAL_MOD_ALIGNER:
    case AVAGO_GARNET_25GE_INTERFACE:   return avago_sbus_rd(aapl, sbus_addr, 0xfc) & 0xf;

    case AVAGO_SBUS2APB:                return avago_sbus_rd(aapl, sbus_addr, 0xfd);
    case AVAGO_SBUS_CONTROLLER:         return avago_sbus_rd(aapl, sbus_addr, 0xfe);
    case AVAGO_LINK_EMULATOR:           return 0;

                    /* Note that the revision register has moved around, but */
                    /* will stay at register 95 bits 7:4.  Also revisions */
                    /* prior to rev 2 (Franklin) are not meaningful. */
    case AVAGO_LINK_EMULATOR_2:         return avago_sbus_rd(aapl, sbus_addr, 0x5f) >> 4;
    default: break;
    }

    return -1;
}

static BOOL verify_addr_and_ip_type(Aapl_t *aapl, uint addr, Avago_addr_t *addr_struct)
{
    avago_addr_to_struct(addr,addr_struct);
    if( addr_struct->chip >= AAPL_MAX_CHIPS ||
        addr_struct->ring >= AAPL_MAX_RINGS )
        return FALSE;
    if (aapl->ip_type[AAPL_3D_ARRAY_ADDR(*addr_struct)] == 0xff) aapl_set_ip_type(aapl, addr);
    return TRUE;
}

/** @brief Gets the revision number of the sbus device for the specified chip */
/**        and sbus ring */
/** @return The revision number of the sbus device for the current chip and */
/**        sbus ring (specified by the sbus address) */
/** */
uint aapl_get_ip_rev(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    Avago_addr_t addr_struct;
    if( !verify_addr_and_ip_type(aapl, addr, &addr_struct) )
        return 0;

    if (aapl->ip_rev[AAPL_3D_ARRAY_ADDR(addr_struct)] == 0xfffe)
    {
        aapl->ip_rev[AAPL_3D_ARRAY_ADDR(addr_struct)] = ip_rev(aapl, addr) & 0xFFFF;
        aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Setting aapl->ip_rev for %s to 0x%04x\n", aapl_addr_to_str(addr), aapl->ip_rev[AAPL_3D_ARRAY_ADDR(addr_struct)]);
    }
    return aapl->ip_rev[AAPL_3D_ARRAY_ADDR(addr_struct)];
}


/** @brief  Returns the firmware rev from AAPL's cache */
/** @return Returns the firmware rev from AAPL's cache */
int aapl_get_firmware_rev(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    Avago_addr_t addr_struct;
    if( !verify_addr_and_ip_type(aapl, addr, &addr_struct) )
        return 0;

    if (!aapl->firm_rev[AAPL_3D_ARRAY_ADDR(addr_struct)])
    {
        aapl->firm_rev[AAPL_3D_ARRAY_ADDR(addr_struct)] = avago_firmware_get_rev(aapl, addr);
        aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Setting aapl->firm_rev for %s to 0x%04x\n", aapl_addr_to_str(addr), aapl->firm_rev[AAPL_3D_ARRAY_ADDR(addr_struct)]);
    }
    return aapl->firm_rev[AAPL_3D_ARRAY_ADDR(addr_struct)];
}


/** @brief  Returns the firmware build from AAPL's cache */
/** @return Returns the firmware build from AAPL's cache */
int aapl_get_firmware_build(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    Avago_addr_t addr_struct;
    if( !verify_addr_and_ip_type(aapl, addr, &addr_struct) )
        return 0;

    if (!aapl->firm_build[AAPL_3D_ARRAY_ADDR(addr_struct)])
    {
        aapl->firm_build[AAPL_3D_ARRAY_ADDR(addr_struct)] = avago_firmware_get_build_id(aapl, addr);
        aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Setting aapl->firm_build for %s to 0x%04x\n", aapl_addr_to_str(addr), aapl->firm_build[AAPL_3D_ARRAY_ADDR(addr_struct)]);
    }
    return aapl->firm_build[AAPL_3D_ARRAY_ADDR(addr_struct)];
}


/** @brief  Sets the client data pointer. */
/** @return void */
void aapl_bind_set(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    void *client_data)  /**< [in] Pointer to client data. */
{
    aapl->client_data = client_data;
}

/** @brief  Retrieves the client data pointer. */
/** @return Pointer to client data. */
void *aapl_bind_get(
    Aapl_t *aapl)   /**< [in] Pointer to Aapl_t structure. */
{
    return aapl->client_data;
}

/*============================================================================= */
/* AAPL GET IP TYPE */

/** @brief  Gets the IP type for the sbus address. */
/** @return The IP type of the sbus device for the current chip and */
/**         sbus ring as specified by the sbus address. */
Avago_ip_type_t aapl_get_ip_type(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    Avago_ip_type_t ip_type;
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr,&addr_struct);
    if( addr_struct.chip >= AAPL_MAX_CHIPS ) addr_struct.chip = 0;
    if( addr_struct.ring >= AAPL_MAX_RINGS ) addr_struct.ring = 0;

    AAPL_IP_INFO_LOCK; /* make sure aapl_set_ip_type from another thread is not attempting to set the current IP type (the IP_INFO_LOCK is present in aapl_set_ip_type) */
    if (aapl->ip_type[AAPL_3D_ARRAY_ADDR(addr_struct)] == 0xff) aapl_set_ip_type(aapl, addr);
    ip_type = (Avago_ip_type_t) aapl->ip_type[AAPL_3D_ARRAY_ADDR(addr_struct)];
    AAPL_IP_INFO_UNLOCK;
    return ip_type;
}

/** @brief Internal function that returns index from avago_chip_id array (from asic_info.h) */
static int avago_find_chip_index(uint jtag, int jtag_mask)
{
    int at;
    for( at = 0; at < AAPL_ARRAY_LENGTH(avago_chip_id); ++at )
    {
        if( jtag == (avago_chip_id[at].jtag_idcode & jtag_mask) )
            return at;
    }
    return -1;
}

/** @brief Internal function that returns the process id of a device. Can be used as a check to see if SBus is working. */
static Avago_process_id_t get_process_id(Aapl_t *aapl, uint chip)
{
    int rc = aapl->return_code;
    Avago_process_id_t ret = AVAGO_UNKNOWN_PROCESS;
    uint data = avago_sbus_rd(aapl, avago_make_addr3(chip, 0, 0xfe), 0xfe);

    if( aapl->return_code == rc )
    {
        switch (data)
        {
        default: aapl_log_printf(aapl,AVAGO_WARNING,__func__,__LINE__,"Unknown process id: 0x%x\n",data);
            /* fall through to search asic_info.h for process id: */
        case 0xbd: /* Search asic_info.h for process id: */
            /* 40nm (Rev 01, Rev 02, Rev 03). */
            /* 28nm (Rev 01, Rev 02) */
            {
                int id = avago_find_chip_index(aapl->jtag_idcode[chip], 0xffffffff);
                if( id >= 0 )   /* If idcode is found, set process id. */
                    ret = avago_chip_id[id].process_id;
                if( ret == AVAGO_UNKNOWN_PROCESS && data == 0xbd )
                    ret = AVAGO_TSMC_28; /* Default 0xbd code to 28nm */
            }
            break;

        case 0xbe: /* 28nm Rev 03,04,05,07 */
        case 0xbf: /* 28nm with I2C master (Rev 06) */
        case 0xc1: /* 28nm ASSP Rev 01,02 */
                   ret = AVAGO_TSMC_28; break;

        case 0xc0: /* 16nm Rev 01 null rom. */
        case 0xc2: /* 16nm Rev 01 rom 01, Rev 02 rom 01. */
        case 0xc3: /* 16nm Rev 03 */
                   ret = AVAGO_TSMC_16; break;
        case 0xc5: /* 07nm Rev 01 */
                   ret = AVAGO_TSMC_07; break;

  /*    case 0xc4: // 10nm Rev 01 */
        }
    }
    return ret;
}

/** @brief Returns cached value of chip process identifier. */
Avago_process_id_t aapl_get_process_id(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr,&addr_struct);

    /* If we have a broadcast chip, iterate through them all. If they're all the same, return that value */
    if( addr_struct.chip == AVAGO_BROADCAST )
    {
        Avago_process_id_t process = AVAGO_UNKNOWN_PROCESS;
        for (addr_struct.chip = 0; addr_struct.chip < aapl_get_chips(aapl); addr_struct.chip ++)
        {
            Avago_process_id_t curr_process = aapl_get_process_id(aapl, avago_struct_to_addr(&addr_struct));
            if( addr_struct.chip == 0 )
                process = curr_process;
            else if( curr_process != process )
                return AVAGO_UNKNOWN_PROCESS; /* return unknown if they are not all the same */
        }
        return process;
    }
    if( addr_struct.chip >= AAPL_MAX_CHIPS ) return AVAGO_UNKNOWN_PROCESS;
    if( aapl->process_id[addr_struct.chip] == AVAGO_UNKNOWN_PROCESS )
    {
        aapl->process_id[addr_struct.chip] = get_process_id(aapl, addr_struct.chip);
        aapl_log_printf(aapl, AVAGO_DEBUG6, __func__, __LINE__, "Setting aapl->process_id[%d] to 0x%04x\n", addr_struct.chip, aapl->process_id[addr_struct.chip]);
    }
    return aapl->process_id[addr_struct.chip];
}

BOOL aapl_get_spico_running_flag(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr, &addr_struct);
    if (aapl->spico_int_only) return TRUE; /* always assume SPICO is running */
    if (aapl_check_broadcast_address(aapl, addr, __func__, __LINE__, FALSE))
    {
        BOOL st;
        Avago_addr_t start, stop, next;
        char running = TRUE;    /* Match type of the spico_running member */
        for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, AAPL_BROADCAST_IGNORE_LANE);
             st;
             st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_IGNORE_LANE) )
        {
            uint sbus_addr = avago_struct_to_addr(&next);
            if (aapl_get_ip_type(aapl, sbus_addr) != AVAGO_SERDES) continue;
            running &= aapl->spico_running[next.chip][next.ring][next.sbus];
        }
        return (BOOL)running;
    }
    else /* default, non-broadcast case */
    {
        if( addr_struct.chip >= AAPL_MAX_CHIPS ||
            addr_struct.ring >= AAPL_MAX_RINGS )
            return FALSE;
        return aapl->spico_running[addr_struct.chip][addr_struct.ring][addr_struct.sbus];
    }
}

BOOL aapl_set_spico_running_flag(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] Address number. */
    BOOL running)   /**< [in] New running value */
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr,&addr_struct);
    if( addr_struct.chip >= AAPL_MAX_CHIPS ||
        addr_struct.ring >= AAPL_MAX_RINGS )
        return FALSE;
    return (aapl->spico_running[addr_struct.chip][addr_struct.ring][addr_struct.sbus] = running);
}

/** @brief  Get a string representation of the Process ID of the specified chip */
/**         and sbus ring */
/** @return The Process ID string of the sbus device for the current chip and */
/**         sbus ring (specified by the sbus address) */
const char *aapl_get_process_id_str(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr)      /**< [in] Address number. */
{
    return aapl_process_id_to_str(aapl_get_process_id(aapl, addr));
}


static int  try_tck_value(Aapl_t *aapl, uint chip, uint tck_delay_val)
{
    char buf[64];
    snprintf(buf, 64, "tck_delay %u", tck_delay_val);
    avago_aacs_send_command(aapl, buf);
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Trying tck_delay of %d\n", tck_delay_val);

    return avago_diag_sbus_rw_test(aapl, avago_make_addr3(chip, 0, 0xfe), 1); /* do a very quick r/w test to see if things are ok */
}


static int  hs1_try_mode(Aapl_t *aapl, uint chip, const char * mode)
{
    char hs1_mode[64];
    int rw;
    char *ptr;

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Checking %s mode in HS1\n", mode);
    snprintf (hs1_mode, 64, "sbus_mode %s", avago_aacs_send_command(aapl, "sbus_mode"));

    ptr = strstr(hs1_mode," I2C"); /* sbus_mode can return "slow I2C", but the extra I2C at end is illegal when restoring... */
    if( ptr ) *ptr = '\0'; /* end string after "i2c " */

    avago_aacs_send_command(aapl, mode); /* switch to new mode */

    AAPL_SUPPRESS_ERRORS_PUSH(aapl);
    rw = avago_diag_sbus_rw_test(aapl, avago_make_addr3(chip, 0, 0xfe), 1); /* do a very quick r/w test to see if things are ok */
    if (!rw && strstr("sbus_mode jtag", mode))
    {
        char tck_delay_orig[64];
        snprintf (tck_delay_orig, 64, "tck_delay %s", avago_aacs_send_command(aapl, "tck_delay")); /* get original tck_delay value */

        rw = try_tck_value(aapl, chip, 10); /* try 10 first */
        if( rw ) /* if 10 passed, then try incrementing values starting at 0 to see what faster value may work */
        {
            uint tck_delay_val = 0;
            while( tck_delay_val < 10 )
            {
                rw = try_tck_value(aapl, chip, tck_delay_val);
                if( rw ) break; /* passed */
                tck_delay_val ++; /* try next tck_delay */
            }
        }
        if( !rw )
        {
            avago_aacs_send_command(aapl, tck_delay_orig); /* If still failing, restore the original tck_delay value */
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Resetting original tck_delay of %s\n", tck_delay_orig);
        }
    }
    AAPL_SUPPRESS_ERRORS_POP(aapl);

    if( !rw ) avago_aacs_send_command(aapl, hs1_mode); /* If still failing, restore the HS1 communication method to it's original state */
    else      aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "The original HS1 communication method \"%s\" failed, changing HS1 communication method to %s.\n", hs1_mode, avago_aacs_send_command(aapl, "sbus_mode"));

    return rw;
}


/** @brief Sends and receives JTAG information. */
/** @details OPCODE is assumed to be 10 bits. Use avago_jtag_scan for more generic JTAG operations. */
/** @return Data received back from the JTAG command */
/**        Returns the aapl->data_char string pointer, which is a C-string holding the command status. */
/**        aapl->data is set to length of the returned string. */
char *avago_jtag(
    Aapl_t *aapl,       /**< [in] Pointer to AAPL structure */
    int opcode,         /**< [in] The JTAG opcode. */
    int length,         /**< [in] The number of bits to be sent. */
    const char *data)   /**< [in] Data to be sent to scan chain. */
{
    if (aapl_reconnect(aapl, __func__) < 0) return 0;
    if (!aapl->jtag_fn) aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "JTAG function function not registered.\n");
    else return aapl->jtag_fn(aapl, opcode, length, data, 1); /* avago_jtag_fn, avago_aacs_jtag_fn */
    return 0;
}

char *avago_jtag_options(
    Aapl_t *aapl,       /**< [in] Pointer to AAPL structure */
    int opcode,         /**< [in] The JTAG opcode. */
    int length,         /**< [in] The number of bits to be sent. */
    const char *data,   /**< [in] Data to be sent to scan chain. */
    BOOL get_tdo)
{
    if (aapl_reconnect(aapl, __func__) < 0) return 0;
    if (!aapl->jtag_fn) aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "JTAG function function not registered.\n");
    else return aapl->jtag_fn(aapl, opcode, length, data, get_tdo);
    return 0;
}



#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
/** Private function used by avago_jtag_scan and avago_jtag_rd */
static AAPL_INLINE char avago_bit_banged_jtag(Aapl_t *aapl, int cycles, int tms, int tdi, int trst_l, BOOL get_tdo)
{
    /*//////// NOTE: Copied to aacs_server.c. aapl_core.c wants this function to be static for performance. */
    /*//////// PLEASE MAKE SURE TO MAKE ANY CODE CHANGES IN BOTH PLACES!! */
    if (aapl->aacs) /* check for AACS communication mode */
    {
        char buf[64];

        snprintf(buf, 63, "jtag_cycle %d %d %d %d", cycles, tms, tdi, trst_l); /* cycles tms tdi trst */
        avago_aacs_send_command(aapl, buf);
        return aapl->data_char[0];
    }
    else
    {
        if (!aapl->bit_banged_jtag_fn)
        {
            aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Bit banged JTAG function function not registered.\n");
            return 0x30; /* return '0' */
        }
        while (cycles > 1) /* note: when doing multiple cycles, we only return the last tdo bit (avago_jtag_scan never looks at TDO when cycles > 1) */
        {
            aapl->bit_banged_jtag_fn(aapl, tms, tdi, trst_l, 0);
            cycles--;
        }
        return aapl->bit_banged_jtag_fn(aapl, tms, tdi, trst_l, get_tdo) + 0x30; /* get last bit */
    }
}

/** @brief  Reads JTAG information. */
/** @return Data received back from the JTAG command */
/**        Returns the aapl->data_char string pointer, which is a C-string holding the command status. */
/**        aapl->data is set to length of the returned string. */
char *avago_jtag_rd(
    Aapl_t *aapl,       /**< [in] Pointer to AAPL structure */
    int opcode,         /**< [in] The JTAG opcode. */
    int length)         /**< [in] The length of the JTAG chain specified by the opcode. */
{
    if (aapl->aacs)
    {
        char buffer[32];
        snprintf(buffer, sizeof(buffer), "jtag %d %04x read",length,opcode);
        avago_aacs_send_command(aapl, buffer);
    }
    else if (aapl_is_jtag_communication_method(aapl))
    {
        char *tdo = (char *)aapl_malloc(aapl, length+1, __func__);

        if( tdo )
        {
            int current_bit = 0;
            length --;
            memset(tdo, '0', length+1); /* prefill with ASCII "0" */

            avago_jtag_set_opcode(aapl, opcode);
            avago_bit_banged_jtag(aapl, 2, 0, 0, 1, 0); /* safety to make sure we're in rti */
            avago_bit_banged_jtag(aapl, 1, 1, 0, 1, 0); /* move to DR */
            avago_bit_banged_jtag(aapl, 2, 0, 0, 1, 0); /* move to shift IR/DR state */

            /* MODIFICATIONS required here for multiple devices */
            while (current_bit <= length) /* this is <= as we need one extra bit below to get the final TDI bit in (in jtag_scan we use < only) */
            {
                tdo[length - current_bit] = avago_bit_banged_jtag(aapl, 1, 0, tdo[length - current_bit + 1] - 0x30, 1, 1);
                current_bit++;
            }
            /* tdo is not saved here, as we already have all the bits */
            avago_bit_banged_jtag(aapl, 1, 1, tdo[length - current_bit + 1] - 0x30, 1, 1); /* shift last bit with TMS set to 1 to exit shift state */

            tdo[length+1] = 0; /* string terminator */

            avago_bit_banged_jtag(aapl, 1, 1, 0, 1, 0);
            avago_bit_banged_jtag(aapl, 1, 0, 0, 1, 0); /* return to RTI */

            aapl_log_printf(aapl, AVAGO_DEBUG8, __func__, __LINE__, "length: %d, tdo: %s\n", length+1, tdo);

            aapl_log_printf(aapl, AVAGO_DATA_CHAR, __func__, __LINE__, "%s", tdo);
            aapl_free(aapl, tdo, __func__);
        }
    }
    else
    {
        aapl_fail(aapl,__func__,__LINE__,"Implementation missing.\n");
    }
    return aapl->data_char;
}


/** @brief  Reads JTAG information and automatically determines the chain length. */
/** @return On success, returns the aapl->data_char string pointer, which is a C-string holding the JTAG information. */
/**         Both *length and aapl->data are set to the length of the returned string. */
char *avago_jtag_rd_len(
    Aapl_t *aapl,       /**< [in] Pointer to AAPL structure */
    int opcode,         /**< [in] The JTAG opcode. */
    int *length)        /**< [out] The length of the JTAG chain specified by the opcode. */
{
    int i;
    uint tdo_size = 100000;
    char *tdo = (char *)aapl_malloc(aapl, tdo_size, __func__);
    char pattern[] = "011001010001111011101100001100111000101001110110101100101101010001101000010010010110001010100110011010000100100101100010101001100010010000000110111011000101001";
    char *in_ptr = pattern + AAPL_ARRAY_LENGTH(pattern);
    char *out_ptr = tdo + tdo_size;
    pattern[AAPL_ARRAY_LENGTH(pattern)-1] = '0';    /* Need full, non-null terminated array. */

    avago_jtag_set_opcode(aapl, opcode);
    avago_bit_banged_jtag(aapl, 2, 0, 0, 1, 0); /* safety to make sure we're in rti */
    avago_bit_banged_jtag(aapl, 1, 1, 0, 1, 0); /* move to DR */
    avago_bit_banged_jtag(aapl, 2, 0, 0, 1, 0); /* move to shift IR/DR state */

    /* Shift pattern in. */
    *--out_ptr = '\0';
    for( i = 0; i < AAPL_ARRAY_LENGTH(pattern); i++ )
        *--out_ptr = avago_bit_banged_jtag(aapl, 1, 0, *--in_ptr - '0', 1, 1);

    in_ptr = tdo + tdo_size - 1;   /* Now shift original data back in and look for pattern coming out. */
    while( 0 != strncmp(pattern+1, out_ptr, AAPL_ARRAY_LENGTH(pattern)-1) && out_ptr > tdo )
        *--out_ptr = avago_bit_banged_jtag(aapl, 1, 0, *--in_ptr - '0', 1, 1);

    *--out_ptr = avago_bit_banged_jtag(aapl, 1, 1, *--in_ptr - '0', 1, 1); /* shift last bit with TMS set to 1 to exit shift state */
    *length = tdo_size - (in_ptr - tdo) - 1;

    /* Make adjustment for multiple chips: */
    *length -= aapl->chips - 1;                     /* Extra bit for each extra chip */
    in_ptr += aapl->chips - 1 - aapl->curr_chip;    /* Shift start based on current chip */
    in_ptr[*length] = '\0';                         /* Truncate result to drop trailing bits. */

    avago_bit_banged_jtag(aapl, 1, 1, 0, 1, 0);
    avago_bit_banged_jtag(aapl, 1, 0, 0, 1, 0); /* return to RTI */

    aapl_log_printf(aapl, AVAGO_DEBUG8, __func__, __LINE__, "chip: %u/%u, length: %d, tdo: %s\n", aapl->curr_chip, aapl->chips, *length, in_ptr);
    aapl_log_printf(aapl, AVAGO_DATA_CHAR, __func__, __LINE__, "%s", in_ptr);

    aapl_free(aapl, tdo, __func__);
    aapl->data = *length;
    return aapl->data_char;
}

/** @brief Performs jtag chip level reset. */
void avago_jtag_reset(
    Aapl_t *aapl,       /**< [in] Pointer to AAPL structure */
    int chip)
{
    aapl_log_printf(aapl, AVAGO_DEBUG9, __func__, __LINE__, "Performing JTAG reset (aacs: %x, jtag: %x)\n", aapl->aacs, aapl_is_jtag_communication_method(aapl));
    if( aapl->aacs )
    {
        aapl_set_sbus_tap_reset_sel(aapl, chip, 0); /* disable TAP__SBUS_RESET_SEL and TEST__SBUS_RESET */
        avago_aacs_send_command(aapl, "reset"); /* perform JTAG reset */
    }
    if( aapl->aacs || aapl_is_jtag_communication_method(aapl) )
    {
        avago_bit_banged_jtag(aapl, 10, 1, 0, 0, 0); /* hold trst_l low and TMS high for 10 cycles to reset TAP */
        avago_bit_banged_jtag(aapl, 10, 1, 0, 1, 0); /* pull trst_l back high */
        avago_bit_banged_jtag(aapl, 10, 0, 0, 1, 0); /* move to RTI state */
    }
    aapl->prev_opcode = 0;
    memset(aapl->recv_data_valid, 0, sizeof(aapl->recv_data_valid)); /* clear recv_data_valid */
}

/** @brief Sets single bit in JTAG scan chain */
void avago_jtag_set_bit(
    Aapl_t *aapl,       /**< [in] Pointer to AAPL structure */
    int opcode,         /**< [in] The JTAG opcode. */
    uint length,        /**< [in] The number of bits in the scan chain */
    uint set_bit,       /**< [in] Bit number to set */
    uint value)         /**< [in] Value to set */
{
    avago_jtag_rd(aapl, opcode, length);
    aapl->data_char[(length-1) - set_bit] = value;
    avago_jtag(aapl, opcode, length, aapl->data_char);
}

/** @brief   Does a JTAG scan of scan chain of arbitary type and length */
/** @details Scan length number of bits from tdi, writing output into tdo. */
/**          tms input specifies how many TMS cycles to toggle before starting scan. */
/**          1 would signify DR, 2 is IR. */
void avago_jtag_scan(
    Aapl_t *aapl,       /**< Pointer to AAPL structure */
    int length,         /**< Scan length number of bits from tdi. */
    int tms,            /**< How many TMS cycles to toggle before starting scan. */
    const char *tdi,    /**< [in] Bits to output, one per byte. ASCII '0' and '1' characters. */
    char *tdo)          /**< [out] Where bits are stored as ASCII '0' and '1' characters. */
{
    avago_jtag_scan_options(aapl, length, tms, tdi, tdo, AVAGO_RTI);
}

/** @brief   Does a JTAG scan of scan chain of arbitary type and length */
/** @details Scan length number of bits from tdi, writing output into tdo. */
/**          tms input specifies how many TMS cycles to toggle before starting scan. */
/**          1 would signify DR, 2 is IR. */
void avago_jtag_scan_options(
    Aapl_t *aapl,               /**< Pointer to AAPL structure */
    int length,                 /**< Scan length number of bits from tdi. */
    int tms,                    /**< How many TMS cycles to toggle before starting scan. */
    const char *tdi,            /**< [in] Bits to output, one per byte. ASCII '0' and '1' characters. */
    char *tdo,                  /**< [out] Where bits are stored as ASCII '0' and '1' characters. */
    Aapl_jtag_state_t state)    /**< Starting state, either AVAGO_SHIFT_DR or AVAGO_RTI. */
{
    int devices_before = 0;
    int current_bit = length - 1;
    int final_tms = 1;
    if (state == AVAGO_SHIFT_DR) final_tms = 0; /* stay in shift DR */

    /*printf("#### %d %d %d %s\n", aapl->curr_chip, tms, length, tdi); */
    /*avago_bit_banged_jtag(aapl, 2, 0, 0, 1, 0); // safety to make sure we're in rti */
    avago_bit_banged_jtag(aapl, tms, 1, 0, 1, 0); /* move to selected IR/DR */
    avago_bit_banged_jtag(aapl, 2, 0, 0, 1, 0);  /* move to shift IR/DR state */

    if (aapl->chips > 1) /* If there is more than 1 device, there must be devices either before and/or after this one */
    {
        int devices_after = aapl->curr_chip;
        devices_before = (aapl->chips - 1) - aapl->curr_chip;
        if (devices_before < 0) devices_before = 0;
        if (devices_before) final_tms = 0; /* final TMS will be done after dummy bits */

        /* scan extra bits for devices after this one */
        while (devices_after)
        {
            aapl_log_printf(aapl, AVAGO_DEBUG9, __func__, __LINE__, "## Shifting extra bits for devices after current one. tms_mode: %d curr_chip: %d before: %d after:%d\n", tms, aapl->curr_chip, devices_before, devices_after);
            if (tms == 2) /* IR scan, so send 0x3ff bypass instruction */
                avago_bit_banged_jtag(aapl, 10, /*tms*/ 0, /*tdi*/ 1, /*trst_l*/ 1, /*get_tdo*/ 0);
            else /* DR scan, so just shift the extra bit */
                avago_bit_banged_jtag(aapl, 1, /*tms*/ 0, /*tdi*/ 0, /*trst_l*/ 1, /*get_tdo*/ 0);
            devices_after --;
        }
    }

    if (tdo)
    {
        while (current_bit)
        {
            tdo[current_bit] = avago_bit_banged_jtag(aapl, 1, 0, tdi[current_bit] - 0x30, 1, 1);
            current_bit--;
        }
        tdo[current_bit] = avago_bit_banged_jtag(aapl, 1, final_tms, tdi[current_bit] - 0x30, 1, 1); /* shift last bit with TMS set to 1 to exit shift state */
        tdo[length] = 0; /* string terminator */
    }
    else
    {
        while (current_bit)
            avago_bit_banged_jtag(aapl, 1, 0, tdi[current_bit--] - 0x30, 1, 0);
        avago_bit_banged_jtag(aapl, 1, final_tms, tdi[current_bit] - 0x30, 1, 0); /* shift last bit with TMS set to 1 to exit shift state */
    }

    /* now scan extra bits for devices before this one */
    if (devices_before)
    {
        if (state != AVAGO_SHIFT_DR) final_tms = 1; /* restore final tms */
        while (devices_before)
        {
            aapl_log_printf(aapl, AVAGO_DEBUG9, __func__, __LINE__, "## Shifting extra bits for devices before current one. tms_mode: %d curr_chip: %d before: %d\n", tms, aapl->curr_chip, devices_before);
            if (tms == 2) /* IR scan, only shift 9 bits of the 10 bit bypass instruction */
                avago_bit_banged_jtag(aapl, 9, /*tms*/ 0, /*tdi*/ 1, /*trst_l*/ 1, /*get_tdo*/ 0);
            /*Shift the extra bit data bit, which may either be a dummy bit when in TDR mode, or the last bit of the bypass instruction if in IR mode */
            devices_before --; /* decrement now, so we can skip the very last bit, which needs TMS set high */
            if (devices_before) avago_bit_banged_jtag(aapl, 1, /*tms*/ 0, /*tdi*/ 1, /*trst_l*/ 1, /*get_tdo*/ 0);
        }
        /* now shift the final bit with TMS set appopriately */
        avago_bit_banged_jtag(aapl, 1, /*tms*/ final_tms, /*tdi*/ 1, /*trst_l*/ 1, /*get_tdo*/ 0);
    }

    if (state != AVAGO_SHIFT_DR)
    {
        avago_bit_banged_jtag(aapl, 1, 1, 0, 1, 0); /* move to update state */
        if (state == AVAGO_RTI) avago_bit_banged_jtag(aapl, 1, 0, 0, 1, 0); /* return to RTI */
    }

    if (aapl->debug >= 9)
    {
        aapl_log_printf(aapl, AVAGO_DEBUG9, __func__, __LINE__, "length: %d, tms: %d, tdi: %.*s\n", length, tms, length, tdi);
        aapl_log_printf(aapl, AVAGO_DEBUG9, __func__, __LINE__, "length: %d, tms: %d, tdo: %.*s\n", length, tms, length, tdo);
    }
}
#endif /* AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS */


/** @brief   Checks sbus_addr to see if it is a broadcast address (including the SerDes broadcast address) */
/** @details Checks to see if sbus_addr is a chip broadcast address (0xfXXX), */
/**          a ring broadcast address (0xXfXX), or the SerDes broadcast address (0xXXff) */
/** @return  TRUE if sbus_addr belongs to any of the above broadcast addresses */
BOOL aapl_check_broadcast_address(
    Aapl_t *aapl,           /**< AAPL structure pointer. */
    uint sbus_addr,         /**< [in] SBus slice address. */
    const char *caller,     /**< Caller function, usually __func__. */
    int line,               /**< Caller line number, usually __LINE__. */
    int error_on_match)     /**< Whether to print error on match. */
{
    BOOL match;
    Avago_addr_t addr_struct;
    avago_addr_to_struct(sbus_addr,&addr_struct);

    match = (addr_struct.chip == AVAGO_BROADCAST)
         || (addr_struct.ring == AVAGO_BROADCAST)
         || (addr_struct.sbus == AVAGO_BROADCAST)
         /* 0xfd and 0xfe are not "true" broadcast addresses */
         || (addr_struct.sbus > AVAGO_MAX_RING_ADDRESS && addr_struct.sbus <= 0xfc);

    if( match && error_on_match )
        aapl_fail(aapl, caller, line, "Broadcast address (0x%02x) not supported.\n", sbus_addr);

    return match;
}


/** @brief   Checks sbus_addr against firmware revisions given in args list. */
/** @details Checks if the device firmware revision is >= what is in the list. */
/**          If the revision has bit 19 set (0x80000), it must match */
/**          exactly (not >=) after ignoring bit 19. */
/** <pre> */
/** Example: To check that the firmware revision == 0x1234 or >= 0x5678, */
/**          and error if not, call: */
/**       aapl_check_firmware_rev(aapl,sbus_addr,__func__,__LINE__,TRUE,2,0x81234,0x5678); */
/** </pre> */
/** @return  TRUE if the firmware revision matches one of those listed, FALSE if not. */
/** */
BOOL aapl_check_firmware_rev(
    Aapl_t *aapl,           /**< AAPL structure pointer. */
    uint sbus_addr,         /**< [in] SBus slice address. */
    const char *caller,     /**< Caller function, usually __func__. */
    int line,               /**< Caller line number, usually __LINE__. */
    int error_on_no_match,  /**< Whether to print error on no match. */
    int arg_count,          /**< The number of firmware revision arguments which follow. */
    ...)                    /**< List of valid firmware revisions. */
{
    BOOL match = FALSE;
    int firmware_rev;
    int i;
    Avago_addr_t addr_struct;
    va_list firm_rev_type;
    avago_addr_to_struct(sbus_addr,&addr_struct);

    if (addr_struct.chip == AVAGO_BROADCAST) addr_struct.chip = 0; /* remove broadcast chip */
    if (addr_struct.ring == AVAGO_BROADCAST) addr_struct.ring = 0; /* remove broadcast ring */
    if (addr_struct.sbus == AVAGO_BROADCAST) addr_struct.sbus = 0xff; /* translate to hardware broadcast */
    sbus_addr = avago_struct_to_addr(&addr_struct);
    firmware_rev = aapl_get_firmware_rev(aapl, sbus_addr) & 0xFFF;
    if( firmware_rev == 0 ) return FALSE;

    va_start(firm_rev_type, arg_count);
    for( i=0; i < arg_count; i++ )
    {
        int firm_rev_check = va_arg(firm_rev_type, int);

        if( (!(firm_rev_check & 0x80000) && (firmware_rev >= (firm_rev_check & 0x0fff))) ||
                                            (firmware_rev == (firm_rev_check & 0x0fff)) )
        {
             match = 1;
             break;
        }
    }

    va_end(firm_rev_type);

    if( !match && error_on_no_match )
        aapl_fail(aapl, caller, line, "Unsupported firmware rev 0x%04X on SBus address %s.\n",
            aapl_get_firmware_rev(aapl, sbus_addr), aapl_addr_to_str(sbus_addr));

    return match;
}

/** @brief   Checks sbus_addr against firmware build given in args list. */
/** @details Checks if the device firmware build exactly matches an entry in the list. */
/** <pre> */
/** Example: To check that the firmware build == 0x1234 or == 0x5678, */
/**          and error if not, call: */
/**       aapl_check_firmware_build(aapl,sbus_addr,__func__,__LINE__,TRUE,2,0x1234,0x5678); */
/** </pre> */
/** @return  TRUE if the firmware build matches one of those listed, FALSE if not. */
BOOL aapl_check_firmware_build(
    Aapl_t *aapl,           /**< [in] AAPL structure pointer. */
    uint sbus_addr,         /**< [in] SBus slice address. */
    const char *caller,     /**< [in] Caller function, usually __func__. */
    int line,               /**< [in] Caller line number, usually __LINE__. */
    int error_on_no_match,  /**< [in] Whether to print error on no match. */
    int arg_count,          /**< [in] The number of firmware build arguments which follow. */
    ...)                    /**< [in] List of valid firmware builds. */
{
    BOOL match = FALSE;
    int i;
    Avago_addr_t addr_struct;
    va_list firm_build_type;
    int firmware_build;
    avago_addr_to_struct(sbus_addr,&addr_struct);

    if (addr_struct.chip == AVAGO_BROADCAST) addr_struct.chip = 0; /* remove broadcast chip */
    if (addr_struct.ring == AVAGO_BROADCAST) addr_struct.ring = 0; /* remove broadcast ring */
    if (addr_struct.sbus == AVAGO_BROADCAST) addr_struct.sbus = 0xff; /* translate to hardware broadcast */
    sbus_addr = avago_struct_to_addr(&addr_struct);
    firmware_build = aapl_get_firmware_build(aapl, sbus_addr);
    if( firmware_build == 0 ) return FALSE;

    va_start(firm_build_type, arg_count);
    for( i=0; i < arg_count; i++ )
    {
        int firm_build_check = va_arg(firm_build_type, int);

        if( firmware_build == firm_build_check )
        {
             match = TRUE;
             break;
        }
    }

    va_end(firm_build_type);

    if( !match && error_on_no_match )
        aapl_fail(aapl, caller, line, "SBus address %s is running firmware build 0x%x, which is not supported by %s.\n",
            aapl_addr_to_str(sbus_addr), aapl_get_firmware_build(aapl, sbus_addr), caller);

    return match;
}

/** @cond INTERNAL */

/** @brief   Checks device addr against list of supported devices. */
/** @details Args is the number of arguments passed in for ip_type or process\n */
/**          for example: aapl_check_ip_type(aapl, sbus_addr, __func__, __line__, TRUE, 2, AAPL_SDREV_D6_16, AAPL_SDREV_CM4_16); */
/** @return  Returns TRUE if the device is one of the listed types. returns FALSE if not. */
BOOL aapl_check_sdrev(
    Aapl_t *aapl,           /**< [in] AAPL structure pointer. */
    uint addr,              /**< [in] SBus slice address. */
    const char *caller,     /**< [in] Caller function, usually __func__. */
    int line,               /**< [in] Caller line number, usually __LINE__. */
    int error_on_no_match,  /**< [in] Whether to print error on no match. */
    int arg_count,          /**< [in] The number of ip_type arguments which follow. */
    ...)                    /**< [in] List of valid IP types. */
{
    BOOL match = FALSE;
    int i, my_sdrev = aapl_get_sdrev(aapl, addr);
    va_list sdrev_list;

    va_start(sdrev_list, arg_count);
    for( i = 0; i < arg_count; i++ )
    {
        int sdrev = (int)va_arg(sdrev_list, int);
        if( sdrev == my_sdrev )
        {
            match = TRUE;
            break;
        }
    }
    va_end(sdrev_list);

    /* if nothing matched, then this is a fail */
    if( !match && error_on_no_match )
        aapl_fail(aapl, caller, line, "SBus %s, of IP type 0x%x, in process %s, is not supported by %s.\n",
            aapl_addr_to_str(addr),
            aapl_get_ip_type(aapl,addr),
            aapl_get_process_id_str(aapl,addr),
            caller);

    return match;
}

/** @endcond */

/** @brief   Checks addr against list of supported IP types. */
/** @details Args is the number of arguments passed in for ip_type or process\n */
/**          for example: aapl_check_ip_type(aapl, addr, __FUNC__, __line__, TRUE, 2, AVAGO_SERDES, AVAGO_QPI); */
/** @return  TRUE if the device is one of the listed types, FALSE if not. */
BOOL aapl_check_ip_type(
    Aapl_t *aapl,           /**< [in] AAPL structure pointer. */
    uint addr,              /**< [in] SBus slice address. */
    const char *caller,     /**< [in] Caller function, usually __func__. */
    int line,               /**< [in] Caller line number, usually __LINE__. */
    int error_on_no_match,  /**< [in] Whether to print error on no match. */
    int arg_count,          /**< [in] The number of ip_type arguments which follow. */
    ...)                    /**< [in] List of valid IP types. */
{
    BOOL match = FALSE;
    int i;
    Avago_ip_type_t my_ip_type = aapl_get_ip_type(aapl, addr);
    Avago_addr_t addr_struct;
    va_list ip_types;
    va_start(ip_types, arg_count);

    avago_addr_to_struct(addr,&addr_struct);
    for( i=0; i < arg_count; i++ )   /* now check all of the options passed in. */
    {
        Avago_ip_type_t ip_type = (Avago_ip_type_t)va_arg(ip_types, int);
        if( (uint)ip_type == addr_struct.sbus && ip_type > AVAGO_MAX_RING_ADDRESS )
        {
            match = TRUE;
            break;
        }
        if( addr_struct.chip < AAPL_MAX_CHIPS &&
            addr_struct.ring < AAPL_MAX_RINGS &&
            addr_struct.sbus < 255 &&
            my_ip_type == ip_type )
        {
            match = TRUE;
            break;
        }
    }
    va_end(ip_types);

    /* if nothing matched, then this is a fail */
    if( !match && error_on_no_match )
        aapl_fail(aapl, caller, line, "SBus %s, of IP type 0x%x (%s), in process %s, is not supported by %s.\n",
            aapl_addr_to_str(addr),
            my_ip_type,
            aapl_ip_type_to_str(my_ip_type),
            aapl_get_process_id_str(aapl,addr),
            caller);

    return match;
}

/** @brief   Checks sbus_addr against list of supported IP types. */
/** @details Args is the number of arguments passed in for ip_type or process\n */
/**          for example: aapl_check_ip_type(aapl, sbus_addr, __FUNC__, __line__, TRUE, 2, AVAGO_SERDES, AVAGO_QPI); */
/** @return  TRUE if the device is one of the listed types, FALSE if not. */
/** */
BOOL aapl_check_ip_type_exists(
    Aapl_t *aapl,           /**< AAPL structure pointer. */
    uint sbus_addr,         /**< [in] SBus address to provide chip & ring to search. */
    const char *caller,     /**< Caller function, usually __func__. */
    int line,               /**< Caller line number, usually __LINE__. */
    int error_on_no_match,  /**< Whether to print error on no match. */
    int arg_count,          /**< The number of ip_type arguments which follow. */
    ...)                    /**< List of valid IP types. */
{
    BOOL match = FALSE;
    int i;
    Avago_addr_t addr_struct;
    va_list ip_types;
    va_start(ip_types, arg_count);

    avago_addr_to_struct(sbus_addr,&addr_struct);
    for( i=0; i < arg_count && !match; i++ )   /* now check all of the options passed in. */
    {
        Avago_ip_type_t ip_type = (Avago_ip_type_t)va_arg(ip_types, int);
        Avago_addr_t    start, stop, next;
        BOOL            st;

        /* iterate over sbus_addr and check for ip_type */
        for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, 0);
             st;
             st = aapl_broadcast_next(aapl, &next, &start, &stop, 0) )
        {
            if (aapl_get_ip_type(aapl, avago_struct_to_addr(&next)) == ip_type )
            {
                match = TRUE;
                break;
            }
        }
    }
    va_end(ip_types);

    /* if nothing matched, then this is a fail */
    if( !match && error_on_no_match )
        aapl_fail(aapl, caller, line, "SBus %s, of IP type 0x%x, in process %s, is not supported by %s.\n",
            aapl_addr_to_str(sbus_addr),
            aapl_get_ip_type(aapl,sbus_addr),
            aapl_get_process_id_str(aapl,sbus_addr),
            caller);

    return match;
}


/** @brief   Check sbus_addr against list of supported process types. */
/** @details Example:  Call aapl_check_process(aapl, sbus_addr, __func__, __LINE__, TRUE, 1, AVAGO_TSMC_28); */
/**          to check that the device at sbus_addr is of type AVAGO_TSMC_28. */
/** @return  TRUE if the device is one of the listed types, FALSE if not. */
BOOL aapl_check_process(
    Aapl_t *aapl,           /**< AAPL structure pointer. */
    uint sbus_addr,         /**< [in] SBus slice address. */
    const char *caller,     /**< Caller function, usually __func__. */
    int line,               /**< Caller line number, usually __LINE__. */
    int error_on_no_match,  /**< Whether to print error on no match. */
    int arg_count,          /**< The number of process_type arguments which follow. */
    ...)                    /**< List of valid processes. */
{
    BOOL match = FALSE;
    int i;
    va_list processes;
    Avago_addr_t addr_struct;
    Avago_process_id_t process_id;

    avago_addr_to_struct(sbus_addr,&addr_struct);

    if (addr_struct.chip == AVAGO_BROADCAST) addr_struct.chip = 0; /* remove broadcast chip */
    if (addr_struct.chip >= AAPL_MAX_CHIPS ) return 0;      /* no match if the chip number is too large */

    sbus_addr = avago_struct_to_addr(&addr_struct);
    process_id = aapl_get_process_id(aapl, sbus_addr);

    va_start(processes, arg_count);
    for( i=0; i < arg_count; i++ )
        if( process_id == (Avago_process_id_t)va_arg(processes, int) )
        {
            match = TRUE;
            break;
        }

    va_end(processes);

    if( !match && error_on_no_match )
        aapl_fail(aapl, caller, line, "SBus %s, IP type 0x%x, in process %s, is not supported by %s.\n",
            aapl_addr_to_str(sbus_addr),
            aapl_get_ip_type(aapl,sbus_addr),
            aapl_get_process_id_str(aapl,sbus_addr),
            caller);

    return match;
}

/** @brief Internal function that returns the tap_gen from an HS1 */
uint avago_get_tap_gen(Aapl_t *aapl)
{
    if (aapl->tap_gen) return aapl->tap_gen; /* used cached version */

    if (aapl->aacs)
    {
        avago_aacs_send_command(aapl, "status");

        aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "The status command returned: \"%s\".\n", aapl->data_char);

        if( strlen(aapl->data_char) >= 1 ) /* if a string was returned, check for "TAP generation: ..." string */
        {
            char *string = strstr(aapl->data_char, "TAP generation:");
            if( string )
            {
                string += 15; /* move past "TAP generation:" (15 chars) */
                aapl->tap_gen = aapl_strtoul(string, NULL, 10);    /* convert to int */
            }
            else aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Can not determine tap gen. Received: %s.\n", aapl->data_char);
            if (strstr(aapl->data_char, ";;;;;;;;;;"))
            {
                /* Print WARNING even if error suppression is active: */
                uint supp = aapl->suppress_errors;
                if (supp) aapl->suppress_errors -= 1;
                aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Invalid response received from HS1 (%s). This may be caused by an unsupported version of HS1 firmware. This may cause some issues, including the inability to reset the device.\n", aapl->data_char );
                if (supp) aapl->suppress_errors += 1;
            }
        }
    }
    else if (aapl->jtag_fn) /* non aacs mode -- discover length (only if a JTAG function is registered (to prevent errors)) */
    {
#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
        memset(aapl->data_char, 0, 5); /* in case avago_jtag doesn't exist -- we need to init the memory that we will read below */
        aapl->sbus_reg[1] = '1'; /* set some marker bits to look for */
        aapl->sbus_reg[3] = '1';
        avago_jtag(aapl, 0x0180, 126, aapl->sbus_reg);
        aapl->sbus_reg[1] = '0'; /* clear them */
        aapl->sbus_reg[3] = '0';
        avago_jtag(aapl, 0x0180, 126, aapl->sbus_reg);
        if (aapl->data_char[0] == '1' && aapl->data_char[1] == '0' && aapl->data_char[2] == '1' && aapl->data_char[3] == '0') aapl->tap_gen = 3;
        if (aapl->data_char[1] == '1' && aapl->data_char[2] == '0' && aapl->data_char[3] == '1' && aapl->data_char[4] == '0') aapl->tap_gen = 4;
#endif
    }

    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "TAP gen: %d\n", aapl->tap_gen);

    return aapl->tap_gen;
}


/*============================================================================= */
/* SYSTEM CHIP RESET */
/** @brief Reset the chip */
/** @details <pre> */
/** Performs a JTAG reset (if using AACS) */
/** Performs a MDIO reset (if using MDIO) */
/** Performs any necessary JTAG setup steps (if using AACS). */
/** </pre> */
/** @return void */
/** */
void avago_system_chip_setup(
    Aapl_t *aapl,   /**< [in] Pointer to AAPL structure. */
    int reset,      /**< [in] If set, send the "reset" command to the chip. */
    int chip)       /**< [in] The chip number. */
{
    /* Configure the HS1 for the correct chip number */
    BOOL rw;
    uint jtag_idcode = aapl->jtag_idcode[chip];
    (void) jtag_idcode;

    aapl_set_chip(aapl, chip);

#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
    if (reset) avago_jtag_reset(aapl, chip); /* Performs JTAG reset and removes TAP reset override */

    if( jtag_idcode == 0x18e5657f ) /* Aswan */
    {
        avago_jtag_set_bit(aapl, 0x02b4, 830, 80, '0');
        avago_jtag_set_bit(aapl, 0x02b4, 830, 425, '1');
    }
    else if( (jtag_idcode & 0x0fffffff) == 0x0995957f || /* Tesla rev X */
             (jtag_idcode & 0x0fffffff) == 0x09c2557f || /* Fermi B rev X */
             (jtag_idcode & 0x0fffffff) == 0x09b1657f )  /* Fermi rev X */
    {
        avago_jtag_set_bit(aapl, 0x02b4, 883, 2, '0'); /* REG_TEST__ASYNC_RESET_N                   TESTREGS[2]           1'b0 */
        avago_jtag_set_bit(aapl, 0x02b4, 883, 1, '1'); /* REG_TEST__ASYNC_RESET_N_OVERRIDE          TESTREGS[1]           1'b0 */
        avago_jtag_set_bit(aapl, 0x02b4, 883, 2, '1'); /* REG_TEST__ASYNC_RESET_N                   TESTREGS[2]           1'b0 */
        /* avago_jtag_set_bit(aapl, 0x02b4, 883, 2, '0'); // REG_TEST__ASYNC_RESET_N                   TESTREGS[2]           1'b0 // uncomment this line if you need to write to the padframe controller */
    }
    else if( (jtag_idcode & 0x0fffffff) == 0x0911457f ||   /* AVSP-521 rev X */
             (jtag_idcode & 0x0fffffff) == 0x090b957f )    /* AVSP-521 */
    {
        avago_jtag_set_bit(aapl, 0x02b4, 1293, 500, '1');
    }
#endif /* AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS */

#if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO
    if(aapl_is_mdio_communication_method(aapl))
    {
        uint reset_val = avago_mdio_rd(aapl, chip, AVSP_DEVAD, AVAGO_MDIO_REG_RESET); /* save current reset register */

        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Initial MDIO reset reg: 0x%0x\n", reset_val);

        reset_val &= 0x1; /* just get bit 0 */
        reset_val |= (reset_val << 1); /* make bit 1 a copy of bit 0 */

        AAPL_SUPPRESS_ERRORS_PUSH(aapl);
        rw = avago_diag_sbus_rw_test(aapl, avago_make_addr3(chip, 0, 0xfe), 1); /* do a very quick r/w test to see if things are ok */
        AAPL_SUPPRESS_ERRORS_POP(aapl);

        if( rw ) reset_val ^= 3; /* If the r/w test passed, the value to cause a reset is opposite what we already read (invert bits 0 and 1) */
        else /* if SBus isn't working, try unresetting the part */
        {
            int prev_timeout = aapl->sbus_mdio_timeout;

            avago_mdio_wr(aapl, chip, AVSP_DEVAD, AVAGO_MDIO_REG_RESET, 0x0100 | (reset_val ^ 3));
            aapl->sbus_mdio_timeout = 10000;        /* artificially bump  up the allotted time for completion of this sbus-over-mdio */

            avago_sbus_rd(aapl, avago_make_addr3(chip, 0, 0xfe), 0xfe);        /* Do an sbus-over-mdio read of a known register, this will poll until the sbus reset is clear */
            aapl->sbus_mdio_timeout = prev_timeout; /* Set the sbus_mdio_timeout back to the previous value */

            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Final MDIO reset reg: 0x%0x\n", 0x0100 | (reset_val ^ 3));
        }
        avago_mdio_wr(aapl, chip, AVSP_DEVAD, 32785, 0x0000);
    }
#endif /* AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO */

    AAPL_SUPPRESS_ERRORS_PUSH(aapl);
    if (reset) avago_sbus_reset(aapl, avago_make_addr3(chip, 0, AVAGO_BROADCAST), 1);
    rw = avago_diag_sbus_rw_test(aapl, avago_make_addr3(chip, 0, 0xfe), 1); /* do a very quick r/w test to see if things are ok */
    AAPL_SUPPRESS_ERRORS_POP(aapl);

    /* Try different HS1 communication methods. The original mode should be restored if none work */
    if (!rw && aapl->aacs) rw = hs1_try_mode(aapl, chip, "sbus_mode jtag");
    if (!rw && aapl->aacs) rw = hs1_try_mode(aapl, chip, "sbus_mode slow");
    if (!rw && aapl->aacs) rw = hs1_try_mode(aapl, chip, "sbus_mode mdio");

#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
    if( !rw )
    {
        aapl_set_sbus_tap_reset_sel(aapl, chip, 1); /* if we still can't communicate, attempt setting TEST__SBUS_RESET_SEL high */
        if (!rw && aapl->aacs) rw = hs1_try_mode(aapl, chip, "sbus_mode jtag");
        if (!rw && aapl->aacs) rw = hs1_try_mode(aapl, chip, "sbus_mode slow");
        if (!rw && aapl->aacs) rw = hs1_try_mode(aapl, chip, "sbus_mode mdio");
        if (!rw) aapl_set_sbus_tap_reset_sel(aapl, chip, 0); /* If we STILL can't communicate, revert HS1 setting back, as it may have set the wrong bit */
                                                             /* in the case where we couldn't even determine which TAP gen we were talking to */
    }
#endif /* AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS */

    if( !rw )
        avago_diag_sbus_rw_test(aapl, avago_make_addr3(chip, 0, 0xfe), 1); /* this time if there are errors, they will be reported to the user */

    if (reset) avago_sbus_reset(aapl, avago_make_addr3(chip, 0, AVAGO_BROADCAST), 1);
}

/** @brief Sets up name and ring info for chip. */
static void aapl_set_chip_name(Aapl_t *aapl, int chip)
{
    int at = avago_find_chip_index(aapl->jtag_idcode[chip], 0xffffffff);
    if( at >= 0 )
    {
        aapl->chip_name[chip] = avago_chip_id[at].name;
        aapl->chip_rev[chip]  = avago_chip_id[at].rev;
        aapl->process_id[chip] = avago_chip_id[at].process_id;

        /* set max_sbus_addr to 1 for rings that exist. The correct max value will be discovered later. */
        if( !aapl->sbus_rings ) /* if it hasn't already been overridden, then try to detect */
        {
            uint ring;
            aapl->sbus_rings = avago_chip_id[at].sbus_rings;
            for( ring = 0; ring < avago_chip_id[at].sbus_rings; ring++ )
                aapl->max_sbus_addr[chip][ring] = 1;
        }

        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__,  "IDCODE 0x%08x: %s %s\n", aapl->jtag_idcode[chip], aapl->chip_name[chip], aapl->chip_rev[chip]);
        return;
    }
    /* if you're here, the chip name was never found. We'll now assume only 1 SBus ring exists (unless it was overridden) */
    if( !aapl->sbus_rings )
    {
        aapl->sbus_rings = 1;
        aapl->max_sbus_addr[chip][0] = 1; /* set max_sbus_addr to 1 for ring 0 only */
    }
    aapl->chip_name[chip] = "";
    aapl->chip_rev[chip] = "";
    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__,  "IDCODE 0x%08x: %s %s\n", aapl->jtag_idcode[chip], aapl->chip_name[chip], aapl->chip_rev[chip]);
}

/** @brief Internal function that returns chip name from asic_info.h based on the JTAG idcode. */
static void get_chip_name(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    int chip)       /**< [in] Chip number. */
{
    const char *jtag_string = 0;
    uint ring;

    /* If override is specified use that value, otherwise query from device using send_command */
    aapl->data_char[0] = 0;

    #ifdef AAPL_CHIP_ID_OVERRIDE0
        if (chip == 0) jtag_string = AAPL_CHIP_ID_OVERRIDE0;
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE0
        if (chip == 0) aapl->jtag_idcode[chip] = AAPL_CHIP_ID_HEX_OVERRIDE0;
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE1
        if (chip == 1) jtag_string = AAPL_CHIP_ID_OVERRIDE1;
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE1
        if (chip == 1) aapl->jtag_idcode[chip] = AAPL_CHIP_ID_HEX_OVERRIDE1;
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE2
        if (chip == 2) jtag_string = AAPL_CHIP_ID_OVERRIDE2;
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE2
        if (chip == 2) aapl->jtag_idcode[chip] = AAPL_CHIP_ID_HEX_OVERRIDE2;
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE3
        if (chip == 3) jtag_string = AAPL_CHIP_ID_OVERRIDE3;
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE3
        if (chip == 3) aapl->jtag_idcode[chip] = AAPL_CHIP_ID_HEX_OVERRIDE3;
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE4
        if (chip == 4) jtag_string = AAPL_CHIP_ID_OVERRIDE4;
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE4
        if (chip == 4) aapl->jtag_idcode[chip] = AAPL_CHIP_ID_HEX_OVERRIDE4;
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE5
        if (chip == 5) jtag_string = AAPL_CHIP_ID_OVERRIDE5;
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE5
        if (chip == 5) aapl->jtag_idcode[chip] = AAPL_CHIP_ID_HEX_OVERRIDE5;
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE6
        if (chip == 6) jtag_string = AAPL_CHIP_ID_OVERRIDE6;
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE6
        if (chip == 6) aapl->jtag_idcode[chip] = AAPL_CHIP_ID_HEX_OVERRIDE6;
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE7
        if (chip == 7) jtag_string = AAPL_CHIP_ID_OVERRIDE7;
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE7
        if (chip == 7) aapl->jtag_idcode[chip] = AAPL_CHIP_ID_HEX_OVERRIDE7;
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE8
        if (chip == 8) jtag_string = AAPL_CHIP_ID_OVERRIDE8;
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE8
        if (chip == 8) aapl->jtag_idcode[chip] = AAPL_CHIP_ID_HEX_OVERRIDE8;
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE9
        if (chip == 9) jtag_string = AAPL_CHIP_ID_OVERRIDE9;
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE9
        if (chip == 9) aapl->jtag_idcode[chip] = AAPL_CHIP_ID_HEX_OVERRIDE9;
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE10
        if (chip == 10) jtag_string = AAPL_CHIP_ID_OVERRIDE10;
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE10
        if (chip == 10) aapl->jtag_idcode[chip] = AAPL_CHIP_ID_HEX_OVERRIDE10;
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE11
        if (chip == 11) jtag_string = AAPL_CHIP_ID_OVERRIDE11;
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE11
        if (chip == 11) aapl->jtag_idcode[chip] = AAPL_CHIP_ID_HEX_OVERRIDE11;
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE12
        if (chip == 12) jtag_string = AAPL_CHIP_ID_OVERRIDE12;
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE12
        if (chip == 12) aapl->jtag_idcode[chip] = AAPL_CHIP_ID_HEX_OVERRIDE12;
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE13
        if (chip == 13) jtag_string = AAPL_CHIP_ID_OVERRIDE13;
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE13
        if (chip == 13) aapl->jtag_idcode[chip] = AAPL_CHIP_ID_HEX_OVERRIDE13;
    #endif
    #ifdef AAPL_CHIP_ID_OVERRIDE14
        if (chip == 14) jtag_string = AAPL_CHIP_ID_OVERRIDE14;
    #endif
    #ifdef AAPL_CHIP_ID_HEX_OVERRIDE14
        if (chip == 14) aapl->jtag_idcode[chip] = AAPL_CHIP_ID_HEX_OVERRIDE14;
    #endif

    if (aapl->jtag_idcode[chip] == 0 && jtag_string) /* next priority is the defines from above */
        aapl->jtag_idcode[chip] = aapl_strtoul(jtag_string, NULL, 2);

    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__,  "User supplied IDCODE for device %d (from aapl->jtag_idcode[chip] or aapl.h defines): 0x%08x\n", chip, aapl->jtag_idcode[chip]);

    AAPL_SUPPRESS_ERRORS_PUSH(aapl);   /* turn errors/warnings into debug 1 */
    if (aapl->jtag_idcode[chip] == 0) /* If it wasn't provided above, attempt to retrieve it from the device using JTAG, then SBus */
    {
        int rc = aapl->return_code;

        aapl_set_chip(aapl, chip);

        if (aapl->jtag_idcode_fn) aapl->jtag_idcode[chip] = aapl->jtag_idcode_fn(aapl, chip); /* avago_get_jtag_idcode_fn */
        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__,  "IDCODE returned from avago_get_jtag_idcode for device %d: 0x%08x\n", chip, aapl->jtag_idcode[chip]);

        if ((rc != aapl->return_code) || ( aapl->jtag_idcode[chip] == 0) || (aapl->jtag_idcode[chip] == 0xffffffff)) /* if JTAG didn't work (or wasn't present), now try via SBus */
        {
            uint addr_80;
            uint cntl_addr = avago_make_addr3(chip, 0, 0xfe);

            addr_80 = avago_sbus_rd(aapl, cntl_addr, 0x80);

            aapl->jtag_idcode[chip] = 0; /* in case we fail on the next line */
            if ((addr_80 & 0x3) == 0x00) /* check to make sure 0x80[1:0] is 0 (the default). ie, no user has set it to something else */
            {
                aapl->jtag_idcode[chip] = (avago_sbus_rd(aapl, cntl_addr, 0x81) & 0xff) << 12;  /* read PART_NUM[7:0] */
                if ((avago_find_chip_index(aapl->jtag_idcode[chip], 0xff << 12) >= 0) && aapl->jtag_idcode[chip] != 0) /* partial match found, continue finding */
                {
                    avago_sbus_rmw(aapl, cntl_addr, 0x80, 0x1, 0x3);
                    aapl->jtag_idcode[chip] |= (avago_sbus_rd(aapl, cntl_addr, 0x81) & 0xff) << 20; /* read PART_NUM[15:8] */
                    avago_sbus_rmw(aapl, cntl_addr, 0x80, 0x2, 0x3);
                    aapl->jtag_idcode[chip] |= (avago_sbus_rd(aapl, cntl_addr, 0x81) & 0x0f) << 28; /* read REV_NUM[3:0] */
                    avago_sbus_rmw(aapl, cntl_addr, 0x80, 0x0, 0x3); /* Restore address 0x80[1:0] to 0 */

                    aapl->jtag_idcode[chip] |= 0x57f; /* 0101 0111 1111  Avago manufacterer ID */
                }
                else aapl->jtag_idcode[chip] = 0; /* first byte not found, so set JTAG to 0 (ie we couldn't find it through this method) */

                aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__,  "IDCODE read from SBus for device %d: 0x%08x\n", chip, aapl->jtag_idcode[chip]);
            }
        }
    }
    AAPL_SUPPRESS_ERRORS_POP(aapl);

    if (aapl->jtag_idcode[chip] == 0x0 && !aapl_is_aacs_communication_method(aapl)) /* No idcode found */
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "AAPL has not been configured to use AACS or a JTAG mode, and an override (AAPL_CHIP_ID_OVERRIDE, aapl->jtag_idcode[], or AAPL_CHIP_ID_HEX_OVERRIDE) has not been set for chip %d. This may cause AAPL to not function properly as it has no way of determining exactly what device it is communicating with.\n", chip);

    for( ring = 0; ring < AAPL_MAX_RINGS; ring++ )           /* clear max SBus address for all rings */
        aapl->max_sbus_addr[chip][ring] = 0;

    if (aapl->sbus_rings) /* if it has been overridden, then use that value */
    {
        for( ring = 0; ring < aapl->sbus_rings; ring++ ) aapl->max_sbus_addr[chip][ring] = 1;
    }

    aapl_set_chip_name(aapl, chip);
}


/* Query the AACS server for the number of die connected to it. */
static int get_number_of_chips(
    Aapl_t *aapl)   /**< [in] Pointer to AAPL structure. */
{
    if (aapl->chips == 0) /* has it already been overridden? */
    {
#if AAPL_ALLOW_AACS || AAPL_ALLOW_OFFLINE_SBUS
        if(aapl_is_aacs_communication_method(aapl) || aapl->communication_method == AVAGO_OFFLINE)
        {
            avago_aacs_send_command(aapl, "status");    /* the status command returns number of chips (on the "Current chip: ...." line). */

            aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "The status command returned: \"%s\".\n", aapl->data_char);

            if( strlen(aapl->data_char) >= 1 ) /* if a string was returned, check for "Current chip: ..." string */
            {
                const char *current_chip = "Current chip:";
                char *string = strstr(aapl->data_char,current_chip);
                if( string ) string = strstr(string,"..");
                if( string )
                {
                    string += 2;    /* Skip ".." */
                    aapl->chips = aapl_strtoul(string, NULL, 10);    /* convert to int */
                    aapl->chips += 1; /* Number from status is 0 based, so add 1 here. */
                }
                else
                    aapl->chips = 0;  /* No "Current chip:" string found, so we're assuming 0. */
            }
        }
        else
#endif /* AAPL_ALLOW_AACS || AAPL_ALLOW_OFFLINE_SBUS */
#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
        if (aapl_is_jtag_communication_method(aapl))
        {
            avago_bit_banged_jtag(aapl, 2, 0, 0, 1, 0); /* generate several TCK clocks to get things going (needed for GPIO JTAG modes) */

            avago_bit_banged_jtag(aapl, 2, 1, 0, 1, 0); /* move to select IR */
            avago_bit_banged_jtag(aapl, 2, 0, 0, 1, 0); /* move to shift IR/DR state */

            avago_bit_banged_jtag(aapl, 10 * AAPL_MAX_CHIPS, /*tms*/ 0, /*tdi*/ 1, /*trst_l*/ 1, /*get_tdo*/ 0); /* set all devices to bypass (0x3ff) */

            avago_bit_banged_jtag(aapl, 2, 1, 1, 1, 0); /* move to update state (with last TDI bit set to 1) */
            avago_bit_banged_jtag(aapl, 1, 0, 0, 1, 0); /* return to RTI */

            avago_bit_banged_jtag(aapl, 1, 1, 0, 1, 0); /* move to select DR */
            avago_bit_banged_jtag(aapl, 2, 0, 0, 1, 0); /* move to shift DR state */

            avago_bit_banged_jtag(aapl, AAPL_MAX_CHIPS * 2, /*tms*/ 0, /*tdi*/ 1, /*trst_l*/ 1, /*get_tdo*/ 0); /* shift in ones */

            for (aapl->chips = 0; aapl->chips <= AAPL_MAX_CHIPS - 1; aapl->chips++)
            {
                char x = avago_bit_banged_jtag(aapl, 1, /*tms*/ 0, /*tdi*/ 0, /*trst_l*/ 1, /*get_tdo*/ 1); /* scan in zeros until we get zeros back */
                aapl_log_printf(aapl, AVAGO_DEBUG9, __func__, __LINE__, "Chip %d: %c\n", aapl->chips, x);
                if (x == '0') break;
            }

            avago_bit_banged_jtag(aapl, 2, 1, 0, 1, 0); /* move to update state */
            avago_bit_banged_jtag(aapl, 1, 0, 0, 1, 0); /* return to RTI */

            if (aapl->chips == 0)
            {
                aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "No devices found when autodetecting via JTAG. Assuming there is 1 device.\n");
                aapl->chips = 1;
            }
        }
        else
#endif /* AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS */
        {
            aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "AAPL is not using AACS (TCP) to communicate with devices and AAPL_NUMBER_OF_CHIPS_OVERRIDE has not been defined in aapl.h. Since AACS is the only method to auto-detect the number of devices present, AAPL is assuming there is 1 device.\n");
            aapl->chips = 1;
        }
    }
    if (aapl->chips > AAPL_MAX_CHIPS)
    {
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "AAPL discovered %d devices, but AAPL is compiled to support a maximum of %d devices. Setting aapl->chips to %d.\n", aapl->chips, AAPL_MAX_CHIPS, AAPL_MAX_CHIPS);
        aapl->chips = AAPL_MAX_CHIPS;
    }

    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "aapl->chips set to: %d\n", aapl->chips);
    return aapl->chips;
}

/** @cond INTERNAL */

/** @return Returns an Aapl_sdrev_t for the design of the SerDes. */
/** @return If unrecognized device, logs an error message, decrements aapl->return_code and returns AAPL_SDREV_UNKNOWN. */
int aapl_get_sdrev(Aapl_t *aapl, uint addr)
{
    /* Recursion warning: */
    /* The *_rev functions call avago_serdes_mem_rd, which then calls */
    /*   this function, resulting in recursion issues. */
    /* The current solution is to detect this recursion and return an */
    /*   incomplete value which is "good enough" for avago_serdes_mem_rd. */
    /* As new chips come on board, this solution needs to be reviewed. */
    Avago_process_id_t process_id = AVAGO_TSMC_16;
    static AAPL_THREAD_STORAGE BOOL recursing = FALSE;
    Avago_ip_type_t ip_type = aapl_get_ip_type(aapl,addr); /* Only calls sbus */
    if( ip_type == AVAGO_P1 ) return AAPL_SDREV_P1;

    process_id = aapl_get_process_id(aapl,addr);
    if( ip_type == AVAGO_M4 )
    {
        uint ip_rev;
        if( process_id == AVAGO_TSMC_16 )
            return AAPL_SDREV_CM4_16;
        if( recursing )
            return AAPL_SDREV_CM4; /* Good enough for mem_rd */

        recursing = TRUE;
        ip_rev = aapl_get_ip_rev(aapl,addr); /* Can call avago_serdes_mem_rd */
        recursing = FALSE;

        return (ip_rev == 0xe4) ? AAPL_SDREV_CM4 : AAPL_SDREV_OM4;
    }
    if( ip_type == AVAGO_SERDES )
    {
        uint lsb_rev;
        if( process_id == AVAGO_TSMC_16 )
        {
            uint ip_rev;
            if( recursing )
                return AAPL_SDREV_16;   /* Good enough for mem_rd */

            recursing = TRUE;
            ip_rev = aapl_get_ip_rev(aapl,addr); /* Can call avago_serdes_mem_rd */
            recursing = FALSE;

            /* NOTE: Any new PON Slice revs need to be added here: */
            return (ip_rev == 0x59 || ip_rev == 0x56 || ip_rev == 0x4b || ip_rev == 0x48 || ip_rev == 0x39) ? AAPL_SDREV_PON : AAPL_SDREV_16;
        }
        else if( process_id == AVAGO_TSMC_07 )
            return AAPL_SDREV_D6_07;

        if( recursing ) return AAPL_SDREV_D6;
        recursing = TRUE;
        lsb_rev = aapl_get_lsb_rev(aapl,addr); /* Calls avago_serdes_mem_rd */
        recursing = FALSE;

        return (lsb_rev == 8) ? AAPL_SDREV_HVD6 : AAPL_SDREV_D6;
    }
    aapl_fail(aapl, __func__, __LINE__, "Addr = 0x%x, Unknown SerDes design.\n", addr);
    return AAPL_SDREV_UNKNOWN;
}

/* Returns revision number of the given interrupt. */
int aapl_get_interrupt_rev(Aapl_t *aapl, uint addr, int int_num)
{
    switch( int_num )
    {
    case 0x25:  /* DFE EYE */
        {
            int sdrev = aapl_get_sdrev(aapl, addr);
            if( sdrev == AAPL_SDREV_PON ) return 2;
            if( sdrev == AAPL_SDREV_D6_07 ) return 2;
            if( aapl_get_ip_type(aapl, addr) == AVAGO_M4 && aapl_check_firmware_rev(aapl,addr,0,0,FALSE,1,0x1056) )
                return 2;
            /* Verify current list of builds supporting V2 by running "wdgrep INT25_V2 | grep Makefile" in the firmware tree. */
            break;
        }
    default: break;
    }
    return 1;
}
/** @endcond */

/** @brief Fills out the AAPL struct with information about all devices it can communicate with */
/** @return void */
void aapl_get_ip_info(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    int chip_reset) /**< [in] Reset the chip if non-zero. */
{
    int chip, chips;
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "AAPL Version " AAPL_VERSION ", " AAPL_COPYRIGHT "\n");

    if (aapl->spico_int_only) /* if interrupts only are allowed (ie no SBus access), then get_ip_info can not auto discover anything. */
                              /* The following code sets the cache to "not found". The user will then be responsible for manually adding appropriate information */
    {
        int sbus;
        for( sbus = 1; sbus <= 0xff; sbus++ )
        {
            aapl->ip_type[0][0][sbus] = 0xff; /* set all IP types to "not found" */
            aapl->spico_running[0][0][sbus] = 0;
        }

        /* The user needs to manually set the following parameters as appropriate for their device as these can now not be discovered automatically. */
        /* The following is an example to add a 16nm CM4 SerDes of type 0x57 (sd16C_txcpam4_rxcm4_ns_09) */
        /* This should be set before calling aapl_get_ip_info(). */
        /*     aapl->spico_int_only      = TRUE; */
        /* These should be set after calling aapl_get_ip_info(). */
        /*     aapl->process_id[0]       = AVAGO_TSMC_16; */
        /*     aapl->max_sbus_addr[0][0] = 1; */
        /*     aapl->ip_type[0][0][1]    = AVAGO_M4; */
        /*     aapl->ip_rev[0][0][1]     = 0x57; */
        /*     aapl->lsb_rev[0][0][1]    = 0xe; */
        return;
    }

    {
        AAPL_SUPPRESS_ERRORS_PUSH(aapl);
        avago_aacs_send_command(aapl, "chip"); /* send the chip command to the HS1, which sets TAP_GEN among other things */
        AAPL_SUPPRESS_ERRORS_POP(aapl);
    }

    chips = get_number_of_chips(aapl);
    for (chip=0; chip<chips; chip++)        /* go from 0 to chips -1 */
    {
        int ring;
        AAPL_SUPPRESS_ERRORS_PUSH(aapl); /* don't generate errors the first time we try */
        get_chip_name(aapl, chip);
        AAPL_SUPPRESS_ERRORS_POP(aapl);

        avago_system_chip_setup(aapl, chip_reset, chip);
        if (aapl->jtag_idcode[chip] == 0) get_chip_name(aapl, chip);  /* try again in case we needed SBus access to get the chip name */

        if( !(aapl->capabilities & AACS_SERVER_NO_CRC) ) /* Skip this on a simulation, where all addresses may not exist. */
        {
            /* Fix JTAG idcodes here: */
            if( 0x0995957f == aapl->jtag_idcode[chip] ) /* Tesla or Fermi? */
            {
                /* Look at address 4 SerDes to distinguish these: */
                uint addr = avago_make_addr3(chip, 0, 4);
                int iprev = (avago_sbus_rd(aapl, addr, 0xfe) >> 8) & 0xff;
                if( iprev == 0x17 ) /* 0x10 == Tesla, 0x17 == Fermi */
                {
                    aapl->jtag_idcode[chip] = 0x09b1657f;   /* Fermi jtag */
                    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Correcting IDCODE to 0x%x\n",aapl->jtag_idcode[chip]);
                    aapl_set_chip_name(aapl, chip);
                }
            }
            if( 0x0964257f == aapl->jtag_idcode[chip] ) /* 9104 rev 1 or 5410 rev 1? */
            {
                uint addr = avago_make_addr3(chip, 0, 6);
                int iprev = (avago_sbus_rd(aapl, addr, 0xfe) >> 8) & 0xff;
                if( iprev == 0xde ) /* 0xde == 5410 rev 1, 0xda == 9104 rev 1 */
                {
                    aapl->jtag_idcode[chip] = 0x099a557f;   /* 5410 rev 1 */
                    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Correcting IDCODE to 0x%x\n",aapl->jtag_idcode[chip]);
                    aapl_set_chip_name(aapl, chip);
                }
            }
        }

        #ifdef AAPL_PROCESS_ID_OVERRIDE    /* If override is specified use that value, otherwise try to determine process automatically */
            aapl->process_id[chip] = AAPL_PROCESS_ID_OVERRIDE;
        #else
            {
                Avago_process_id_t process_id;
                AAPL_SUPPRESS_ERRORS_PUSH(aapl);
                process_id = get_process_id(aapl, chip);
                AAPL_SUPPRESS_ERRORS_POP(aapl);
                if (aapl->process_id[chip] == AVAGO_UNKNOWN_PROCESS)
                    aapl->process_id[chip] = process_id;
                else if( process_id != aapl->process_id[chip] )
                {
                    /* Suppress converting of warnings into errors for this */
                    /* particular issue. */
                    int old = aapl->upgrade_warnings;
                    aapl->upgrade_warnings = 0;
                    aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__,  "Chip %d has inconsistent process id information: Ids as both %s and %s.\n",
                        chip, aapl_process_id_to_str(aapl->process_id[chip]), aapl_process_id_to_str(process_id));
                    aapl->upgrade_warnings = old;
                }
            }
        #endif

        for( ring=0; ring < AAPL_MAX_RINGS; ring++ )
        {
            /* if rings exists, check its max SBus address */
            /*  (get_chip_name sets which rings are valid): */
            if( 0 != aapl->max_sbus_addr[chip][ring] )
            {
                uint data;
                int rc = aapl->return_code;
                Avago_addr_t addr_struct;
                avago_addr_init(&addr_struct);
                addr_struct.chip = chip;
                addr_struct.ring = ring;
                addr_struct.sbus = AVAGO_SBUS_CONTROLLER_ADDRESS;
                addr_struct.lane = AVAGO_BROADCAST;

                AAPL_SUPPRESS_ERRORS_PUSH(aapl);
                data = avago_sbus_rd(aapl, avago_struct_to_addr(&addr_struct), 0x02);     /* read and set max sbus address for this ring */
                AAPL_SUPPRESS_ERRORS_POP(aapl);

                aapl->max_sbus_addr[chip][ring] =
                    (aapl->return_code < rc || data == 0)
                        ? 0                 /* read failed */
                        : data - 1;   /* set max sbus address for ring */

                aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__,  "Chip %d (%s %s), ring %d, SBus devices: %d\n", chip, aapl->chip_name[chip], aapl->chip_rev[chip], ring, aapl->max_sbus_addr[chip][ring]);

                if( aapl->max_sbus_addr[chip][ring] >= 0xfe) aapl->max_sbus_addr[chip][ring] = 0; /* set to zero in the case of bogus data received back */

                if( aapl->max_sbus_addr[chip][ring] == 0 )
                {
                    aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Error occurred while trying to determine the number of devices on chip %d, SBus ring %d. aapl->return_code: %d, 0xfe 0x02 0x02 0x00: %d.\n", chip, ring, rc, data);
                    continue; /* this ring is broken, so skip to the next one */
                }

                for( addr_struct.sbus = 1; addr_struct.sbus <= aapl->max_sbus_addr[chip][ring]; addr_struct.sbus++ )
                {
                    aapl->ip_type[chip][ring][addr_struct.sbus] = 0xff; /* set all IP types to "not found" */
                    aapl->spico_running[chip][ring][addr_struct.sbus] = 0;
                }

                /* set IP types for broadcast addresses (0xe0-0xff) */
                for( addr_struct.sbus = 0xff; addr_struct.sbus > AVAGO_MAX_RING_ADDRESS; addr_struct.sbus-- )
                {
                    aapl->firm_rev     [chip][ring][addr_struct.sbus] = 0;
                    aapl->firm_build   [chip][ring][addr_struct.sbus] = 0;
                    aapl->ip_rev       [chip][ring][addr_struct.sbus] = 0xfffe;
                    aapl->spico_running[chip][ring][addr_struct.sbus] = 0;
                    /* Identify these as broadcast addresses: */
                    aapl->ip_type      [chip][ring][addr_struct.sbus] = addr_struct.sbus;
                }

                aapl->ip_type[chip][ring][0xfd] = 0xff; /* Not found -- ie, discover later, if needed */
                aapl->ip_type[chip][ring][0xe0] = 0xff; /* Not found -- used as group_1 broadcast */

                addr_struct.sbus = AVAGO_SBUS_CONTROLLER_ADDRESS;
                aapl_set_ip_type(aapl,avago_struct_to_addr(&addr_struct));
                avago_twi_wait_for_complete(aapl, avago_struct_to_addr(&addr_struct));
            }
        }
    }
    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "End of get_ip_info.\n");
}


/** @brief Sets the ip_type, ip_rev, spico_running, firm_rev, and lsb_rev fields of aapl. */
/** @param aapl Aapl_t struct */
/** @param sbus_addr sbus address of the sbus device, sbus ring, and chip */
/** @return void */
void aapl_set_ip_type(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr) /**< [in] SBus slice address. */
{
    uint data;
    uint jtag_idcode;
    Avago_addr_t addr_struct;
    if (aapl_check_broadcast_address(aapl, sbus_addr, __func__, __LINE__, FALSE)) return; /* broadcast addresses are handled in get_ip_info */

    AAPL_IP_INFO_LOCK;

    avago_addr_to_struct(sbus_addr,&addr_struct);
    if( addr_struct.chip >= AAPL_MAX_CHIPS ) addr_struct.chip = 0;
    if( addr_struct.ring >= AAPL_MAX_RINGS ) addr_struct.ring = 0;

    /* Clear everything out first */
    aapl->ip_type      [AAPL_3D_ARRAY_ADDR(addr_struct)] = AVAGO_UNKNOWN_IP;
    aapl->ip_rev       [AAPL_3D_ARRAY_ADDR(addr_struct)] = 0xfffe; /* have 1st call to ip_rev set it */
    aapl->spico_running[AAPL_3D_ARRAY_ADDR(addr_struct)] = 0;
    aapl->firm_rev     [AAPL_3D_ARRAY_ADDR(addr_struct)] = 0;
    aapl->firm_build   [AAPL_3D_ARRAY_ADDR(addr_struct)] = 0;
    aapl->lsb_rev      [AAPL_3D_ARRAY_ADDR(addr_struct)] = AAPL_LSB_INIT;

    /* First read SBus address 0xff, to look up IP type. */
    data = avago_sbus_rd(aapl, sbus_addr, 0xff);
    jtag_idcode = aapl->jtag_idcode[addr_struct.chip];

    /* Apply IP type corrections based on HW that mis-identifies itself: */
    switch( data )
    {
    case 0x00: /* Should be invalid */
        if(    jtag_idcode == 0x0912557f    /* McKinley 15 */
            || jtag_idcode == 0x0954857f    /* McKinley 25 */
            || jtag_idcode == 0x0954957f    /* McKinley XTAL */
            || jtag_idcode == 0x0972357f    /* Pandora */
            || jtag_idcode == 0x0975457f    /* Pandora P1 */
            || jtag_idcode == 0x0901457f    /* Denali */
            || jtag_idcode == 0x0912257f    /* Denali B15 */
            || jtag_idcode == 0x090b857f    /* Denali B25 */
            || jtag_idcode == 0x0911657f    /* Denali Bx */
            || jtag_idcode == 0x18e5657f    /* Aswan */
            || jtag_idcode == 0x0985357f    /* Borah-Peak */
            || jtag_idcode == 0x099a757f    /* Buck-Hill */
            )
            data = AVAGO_LINK_EMULATOR;
        break;

    case 0x01: /* Hide unconnected SerDes */
        if(    jtag_idcode == 0x099a557f &&   /* AVSP-5410 */
               addr_struct.sbus == 0x04       /* SerDes not pinned out */
            )
            data = AVAGO_UNKNOWN_IP;
        break;
    case 0x08:
        if( jtag_idcode == 0x14211001 &&    /* Hertz */
            (addr_struct.sbus == 0x05 || addr_struct.sbus == 0x06)
            )
            data = AVAGO_MLD;
        break;

    case 0x0b:
        if( jtag_idcode == 0x14211001 && addr_struct.sbus == 0x1c ) /* Hertz */
            data = AVAGO_RAM_PMRO;
        break;

    case 0x11:  /* Should be Thermal Sensor */
        if(    (jtag_idcode == 0x1911357f && addr_struct.sbus < 0x17) /* AVSP-521 1.1 */
            || (jtag_idcode == 0x090b957f && addr_struct.sbus < 0x16) /* AVSP-521 1 */
            || (jtag_idcode == 0x0911457f && addr_struct.sbus < 0x16) /* AVSP-521 x */
            )
            data = AVAGO_AVSP_CONTROL_LOGIC;
        break;

    case 0x83:
        if( aapl_get_process_id(aapl, sbus_addr) == AVAGO_TSMC_16 )
            data = AVAGO_SLE;
        if( aapl_get_process_id(aapl, sbus_addr) == AVAGO_TSMC_28 )
            data = AVAGO_RAM_PMRO;
        break;

    case 0xc1:
        if( aapl_get_process_id(aapl, sbus_addr) == AVAGO_TSMC_28 )
            data = AVAGO_PANDORA_LSB; /* Special IP type for Pandora */
        break;
    }

    if (data <= AVAGO_IP_TYPE_MAX || (data >= AVAGO_IP_TYPE_ALT_RANGE_LO && data < AVAGO_IP_TYPE_ALT_RANGE_HI))
        aapl->ip_type[AAPL_3D_ARRAY_ADDR(addr_struct)] = (Avago_ip_type_t) data;
    else
    {
        aapl->ip_type[AAPL_3D_ARRAY_ADDR(addr_struct)] = AVAGO_UNKNOWN_IP;            /* address 0xff returned an invalid value */
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "IP type 0x%02x unrecognized for SBus address %s.\n", data, aapl_addr_to_str(sbus_addr));
    }

    AAPL_IP_INFO_UNLOCK; /* wait for upload below will cause deadlock */
    /* Now set firm_rev and ip_rev */
    switch (aapl->ip_type[AAPL_3D_ARRAY_ADDR(addr_struct)])
    {
    case AVAGO_P1:
    case AVAGO_M4:
    case AVAGO_SERDES:
        switch (aapl_get_process_id(aapl, sbus_addr))
        {
        case AVAGO_TSMC_07:
        case AVAGO_TSMC_16:
        case AVAGO_TSMC_28:
            avago_spico_wait_for_upload(aapl, sbus_addr);
            avago_sbus_wr(aapl, sbus_addr, 0x01, 0x20000000); /* Ensure AVAGO_DMEM_EN_CNTL2 is high so we can do DMA writes (avago_serdes_dma_* needs this) */
            break;
        default:
            aapl->firm_rev  [AAPL_3D_ARRAY_ADDR(addr_struct)] = 0xffff;
            aapl->firm_build[AAPL_3D_ARRAY_ADDR(addr_struct)] = 0xffff;
            break;
        }
        break;
    case AVAGO_SPICO:
        switch (aapl_get_process_id(aapl, sbus_addr))
        {
        case AVAGO_TSMC_07:
        case AVAGO_TSMC_16:
        case AVAGO_TSMC_28:
            avago_spico_wait_for_upload(aapl, sbus_addr);
            break;
        default:
            aapl->firm_rev  [AAPL_3D_ARRAY_ADDR(addr_struct)] = 0xffff;
            aapl->firm_build[AAPL_3D_ARRAY_ADDR(addr_struct)] = 0xffff;
            aapl->ip_rev    [AAPL_3D_ARRAY_ADDR(addr_struct)] = 0xffff;
            break;
        }
        aapl->lsb_rev   [AAPL_3D_ARRAY_ADDR(addr_struct)] = AAPL_LSB_IGNORE;
        break;
    case AVAGO_SBUS_CONTROLLER:
        aapl->firm_rev  [AAPL_3D_ARRAY_ADDR(addr_struct)] = 0xffff;
        aapl->firm_build[AAPL_3D_ARRAY_ADDR(addr_struct)] = 0xffff;
        aapl->lsb_rev   [AAPL_3D_ARRAY_ADDR(addr_struct)] = AAPL_LSB_IGNORE;
        break;
    default:
        aapl->spico_running[AAPL_3D_ARRAY_ADDR(addr_struct)] = 0;
        aapl->firm_rev     [AAPL_3D_ARRAY_ADDR(addr_struct)] = 0xffff;
        aapl->firm_build   [AAPL_3D_ARRAY_ADDR(addr_struct)] = 0xffff;
        aapl->lsb_rev      [AAPL_3D_ARRAY_ADDR(addr_struct)] = AAPL_LSB_IGNORE;
    }
}


#if AAPL_ALLOW_GPIO_JTAG

#define BCM2708_PERI_BASE   0x3F000000
#define AVAGO_GPIO_BASE           (BCM2708_PERI_BASE + 0x200000)

#if 0 /* original HS2 */
#define AVAGO_GPIO_TDO 5
#define AVAGO_GPIO_TCK 6
#define AVAGO_GPIO_TMS 13
#define AVAGO_GPIO_TDI 19
#define AVAGO_GPIO_TRST_L 26
#else /* Newer HS2 with ribbon cable */
#define AVAGO_GPIO_TDO 26
#define AVAGO_GPIO_TCK 19
#define AVAGO_GPIO_TMS 13
#define AVAGO_GPIO_TDI 6
#define AVAGO_GPIO_TRST_L 5
#endif

/* Set pullup/down */
static void aapl_gpio_pud(Aapl_t *aapl, uint8_t pud)
{
    volatile uint32_t* paddr = aapl->rpi_gpio_access + BCM2835_GPPUD/4;
    *paddr = pud;
}

/* Pullup/down clock */
/* Clocks the value of pud into the GPIO pin */
static void aapl_gpio_pudclk(Aapl_t *aapl, uint8_t pin, uint8_t on)
{
    volatile uint32_t* paddr = aapl->rpi_gpio_access + BCM2835_GPPUDCLK0/4 + pin/32;
    uint8_t shift = pin % 32;
    *paddr = (on ? 1 : 0) << shift;
}

static void aapl_set_pud(Aapl_t *aapl, int pin, int pud)
{
    aapl_gpio_pud(aapl, pud);
    delayMicroseconds(10);
    aapl_gpio_pudclk(aapl, pin, 1);
    delayMicroseconds(10);
    aapl_gpio_pud(aapl, BCM2835_GPIO_PUD_OFF);
    aapl_gpio_pudclk(aapl, pin, 0);
}


/* Set up a memory regions to access GPIO */
/* Returns >= 0 on success, -1 on failure. */
static int avago_bit_banged_gpio_jtag_open_fn(Aapl_t *aapl)
{
    void *gpio_map;
    const char *device = "/dev/gpiomem";
    struct flock lockinfo;

    aapl->rpi_gpio_access = 0;

    if( (aapl->socket = open(device, O_RDWR|O_SYNC)) < 0 )
       return aapl_fail(aapl, __func__, __LINE__, "can't open /dev/gpiomem \n");

    /* Allow only one-at-a-time blocking access to device: */
    lockinfo.l_type = F_WRLCK;
    lockinfo.l_whence = SEEK_SET;
    lockinfo.l_start  = 0;
    lockinfo.l_len    = 0;
    if( 0 != fcntl(aapl->socket, F_SETLKW, &lockinfo) )
    {
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Lock on %s failed: %s\n", device, strerror(errno));
        close(aapl->socket);
        return aapl->socket = -1;
    }

    /* mmap GPIO */
    gpio_map = mmap(
       NULL,             /*Any adddress in our space will do */
       4*1024,           /*Map length */
       PROT_READ|PROT_WRITE,/* Enable reading & writting to mapped memory */
       MAP_SHARED,       /*Shared with other processes */
       aapl->socket,     /*File to map */
       AVAGO_GPIO_BASE   /*Offset to GPIO peripheral */
    );

    if (gpio_map == MAP_FAILED) {
        aapl_fail(aapl, __func__, __LINE__, "mmap error %s (%d)\n", strerror(errno), gpio_map);
        close(aapl->socket);
        return aapl->socket = -1;
    }

    aapl->rpi_gpio_access = (volatile unsigned *)gpio_map; /* volatile pointer required */

    /* Set optimal pull up/down state so won't float after being released: */
    aapl_set_pud(aapl, AVAGO_GPIO_TRST_L, BCM2835_GPIO_PUD_UP);
    aapl_set_pud(aapl, AVAGO_GPIO_TCK,    BCM2835_GPIO_PUD_UP);
  /*aapl_set_pud(aapl, AVAGO_GPIO_TDI,    BCM2835_GPIO_PUD_UP); */
  /*aapl_set_pud(aapl, AVAGO_GPIO_TMS,    BCM2835_GPIO_PUD_UP); */

    /* GPIO setup macros. Always use INP_GPIO(x) before using OUT_GPIO(x) or SET_GPIO_ALT(x,y) */
    #define AVAGO_INP_GPIO(g) *(aapl->rpi_gpio_access+((g)/10)) &= ~(7<<(((g)%10)*3))
    #define AVAGO_OUT_GPIO(g) *(aapl->rpi_gpio_access+((g)/10)) |=  (1<<(((g)%10)*3))
    #define AVAGO_SET_GPIO_ALT(g,a) *(aapl->rpi_gpio_access+(((g)/10))) |= (((a)<=3?(a)+4:(a)==4?3:2)<<(((g)%10)*3))

    AVAGO_INP_GPIO(AVAGO_GPIO_TRST_L); /* must use INP_GPIO before we can use OUT_GPIO */
    AVAGO_OUT_GPIO(AVAGO_GPIO_TRST_L);
    AVAGO_INP_GPIO(AVAGO_GPIO_TDI); /* must use INP_GPIO before we can use OUT_GPIO */
    AVAGO_OUT_GPIO(AVAGO_GPIO_TDI);
    AVAGO_INP_GPIO(AVAGO_GPIO_TMS); /* must use INP_GPIO before we can use OUT_GPIO */
    AVAGO_OUT_GPIO(AVAGO_GPIO_TMS);
    AVAGO_INP_GPIO(AVAGO_GPIO_TCK);  /* must use INP_GPIO before we can use OUT_GPIO */
    AVAGO_OUT_GPIO(AVAGO_GPIO_TCK);
    return 0;
}

/* Returns 0. */
static int avago_bit_banged_gpio_jtag_close_fn(Aapl_t *aapl)
{
    munmap((void *)aapl->rpi_gpio_access, 4*1024);
    if (aapl->socket) close(aapl->socket);
    aapl->socket = -1;
    aapl->rpi_gpio_access = 0;
    return 0;
}

static BOOL avago_bit_banged_gpio_jtag_fn(Aapl_t *aapl, BOOL tms, BOOL tdi, BOOL trst_l, BOOL get_tdo)
{
    #define AAPL_GPIO_SET *(aapl->rpi_gpio_access+7)  /* sets   bits which are 1 ignores bits which are 0 */
    #define AAPL_GPIO_CLR *(aapl->rpi_gpio_access+10) /* clears bits which are 1 ignores bits which are 0 */
    #define AVAGO_GET_GPIO(g) (*(aapl->rpi_gpio_access+13)&(1<<g)) /* 0 if LOW, (1<<g) if HIGH */

    #define AAPL_GPIO_PULL *(aapl->rpi_gpio_access+37) /* Pull up/pull down */
    #define AAPL_GPIO_PULLCLK0 *(aapl->rpi_gpio_access+38) /* Pull up/pull down clock */

    /* if( aapl->debug == 10 ) printf("### %x %x\n", tms, tdi); */
    int data_set = 1<<AVAGO_GPIO_TRST_L;        /* trst_l high by default */
    int data_clr = 1<<AVAGO_GPIO_TMS | 1<<AVAGO_GPIO_TCK; /* tck and tms low by default, as that is the case in the shift IR and DR states */

    if( !aapl->rpi_gpio_access )
    {
        aapl_fail(aapl, __func__, __LINE__, "GPIO access pointer not defined.\n");
        return 0;
    }

    if (tms) /* tms set low by default above since it's uncommon for it to be high (especially during data scanning) */
    {
        data_set |= 1<<AVAGO_GPIO_TMS; /* set tms high */
        data_clr ^= 1<<AVAGO_GPIO_TMS; /* clear TMS low bit that was set above */
    }

    if (!trst_l) /* trst_l set high by default above */
    {
        data_clr |= 1<<AVAGO_GPIO_TRST_L; /* set trst_l low */
        data_set ^= 1<<AVAGO_GPIO_TRST_L; /* clear trst_l high bit that was set above */
    }

    if (tdi)    data_set |= 1<<AVAGO_GPIO_TDI; /* set TDI either high or low */
    else        data_clr |= 1<<AVAGO_GPIO_TDI;

    if (!aapl->tck_delay) /* fastest possible */
    {
        AAPL_GPIO_CLR = data_clr; /* set TCK low and other bits low */
        AAPL_GPIO_SET = data_set; /* set data bits high */
        AAPL_GPIO_SET = 1<<AVAGO_GPIO_TCK;     /* set tck high */
        if (get_tdo && AVAGO_GET_GPIO(AVAGO_GPIO_TDO)) return 1;
        return 0;
    }
    /* fall through for the slower case and declare needed variables below too, to save time */
    {
        int ret = 0;
        get_tdo |= aapl->tck_delay & 0xff0000;
        aapl->tck_delay &= 0xffff;
        if (aapl->tck_delay == 1)
        {
            uint delay = 1;
            while (delay--) AAPL_GPIO_CLR = data_clr; /* set TCK and other bits low */
            AAPL_GPIO_SET = data_set; /* set data bits high and wait */
            AAPL_GPIO_SET = 1<<AVAGO_GPIO_TCK;     /* set tck high */
            if (get_tdo) ret = AVAGO_GET_GPIO(AVAGO_GPIO_TDO);
        }
        else if (!(aapl->tck_delay & 0xff00))
        {
            uint delay = aapl->tck_delay;
            while (delay--) AAPL_GPIO_CLR = data_clr; /* set TCK and other bits low */
            AAPL_GPIO_SET = data_set; /* set data bits high and wait */
            AAPL_GPIO_SET = 1<<AVAGO_GPIO_TCK;     /* set tck high */
            if (get_tdo) ret = AVAGO_GET_GPIO(AVAGO_GPIO_TDO);
        }
        else
        {
            uint delay = aapl->tck_delay & 0xff;
            while (delay--) AAPL_GPIO_CLR = data_clr; /* set TCK and other bits low */
            delay = aapl->tck_delay & 0xff;
            while (delay--) AAPL_GPIO_SET = data_set; /* set data bits high and wait */
            delay = (aapl->tck_delay & 0x00ff00) >> 8;
            while (delay--) AAPL_GPIO_SET = 1<<AVAGO_GPIO_TCK;     /* set tck high */
            if (get_tdo) ret = AVAGO_GET_GPIO(AVAGO_GPIO_TDO);
            delay = (aapl->tck_delay & 0x00ff00) >> 8;
            while (delay--) AAPL_GPIO_SET = 1<<AVAGO_GPIO_TCK;     /* set tck high */
        }
        if (ret) return 1;
        else return 0;
    }
}
#endif /*AAPL_ALLOW_GPIO_JTAG */

