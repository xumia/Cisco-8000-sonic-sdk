/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* MAIN program for the sbm (sbus master) sub-command. */
/* */

/** Doxygen File Header */
/** @file */
/** @brief Launch wrapper for sbm command. */


#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_MAIN 
#if AAPL_ENABLE_HBM

static int show_hbm_help()
{
    aapl_common_main_help(TRUE);

printf(
"At least one of the following is required:\n"
"-hbm-diag                    Run full diagnostics on the HBM interface.\n"
"-operation <op>              Run an HBM operation.\n"
"-reset                       Resets the PHY/HBM interface.\n"
"-id                          Display the HBM device ID.\n"
"-temp                        Display the HBM temperature.\n"
"-temp-diag <count>           Run HBM temperature diagnostics.  Loops <count> times.\n"
); 

printf(
"-init-nwl                    Initializes the NWL memory controller.\n"
"-ctc-diag                    Runs full CTC diagnostics with reset and NWL initialization.\n"
"-ctc-init  [-pattern #]      Start HBM CTC running in continuous mode. Runs reset and NWL init.\n"
"-ctc-start [-pattern #]      Start HBM CTC running in continuous mode. No reset or NWL init performed.\n"
);

printf(
"-ctc-stop                    Stop HBM CTC.\n"
"-ctc-status                  Print the HBM CTC status.\n"
"-mbist-diag                  Run HBM MBIST diagnostics.\n"
);

printf(
"-mmt-diag                    Runs full MMT diagnostics.\n"
"-mmt-start [-pattern #]      Start HBM MMT running in continuous mode.\n"
"-mmt-stop                    Stop HBM MMT.\n"
"-mmt-status [-state]         Print the HBM MMT status with optional state information.\n"
);

printf(
"-mrs [-channel #]            Read the HBM mode register values.\n"
"-tmrs [-safety] [-channel #] Load a TMRS code to one or all channels with optional safety\n"
"-param # -value #            Sets an HBM parameter and value pair\n"
"-op-timeout <value>          Changes the default operation timeout\n"
"-read-lane-repairs           Reads the hard lane repair codes\n"
"-read-spares                 Reads the spare result registers\n"
);

    return 1;
}


/** @brief main program for sbus_master subcommand. */
/** */
/** @return 0 on success, > 0 on failure. */

int aapl_hbm_main(int argc, char *argv[], Aapl_t *aapl)
{
    /* Set default values: */
    Avago_addr_t addr_struct;
    uint         addr;
    uint         sbm_addr;
    uint         apc_addr;
    BOOL hbm_diag           = FALSE;
    BOOL operation          = FALSE;
    BOOL device_id          = FALSE;
    BOOL temp               = FALSE;
    BOOL temp_diag          = FALSE;
    BOOL ctc_init           = FALSE;
    BOOL ctc_start          = FALSE;
    BOOL ctc_stop           = FALSE;
    BOOL ctc_status         = FALSE;
    BOOL ctc_diag           = FALSE;
    BOOL mmt_start          = FALSE;
    BOOL mmt_stop           = FALSE;
    BOOL mmt_status         = FALSE;
    BOOL mmt_diag           = FALSE;
    BOOL mbist_diag         = FALSE;
    BOOL mrs                = FALSE;
    BOOL tmrs               = FALSE;
    BOOL reset              = FALSE;
    BOOL param_set          = FALSE;
    BOOL timeout_set        = FALSE;
    BOOL init_nwl           = FALSE;
    BOOL read_spares        = FALSE;
    BOOL read_lane_repairs  = FALSE;
    uint timeout            = 0;
    uint state              = 0;
    uint channel            = 0xf;
    uint safety             = 0x0;
    uint pattern            = 0x1;
    uint param              = 0x0;
    uint param_value        = 0x0;
    uint param_read         = 0x1;
    const char *tmrs_code   = 0x0;
    int rc, index, op       = 0;
    int count               = 0;
    Avago_addr_t start, stop, next;
    BOOL st;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"hbm-diag",   0, NULL, 'D'}, /* Run full hbm diagnostics */
        {"operation",  1, NULL, 'o'}, /* Run an HBM operation */
        {"id",         0, NULL, 'd'}, /* Display the HBM device ID */
        {"temp",       0, NULL, 't'}, /* Display the HBM temp */
        {"temp-diag",  1, NULL, 'T'}, /* Run temperature diagnostics */
        {"init-nwl",   0, NULL, 'i'}, /* Init NWL MC */
        {"ctc-init",   0, NULL, 'c'}, /* Start CTC with initialization */
        {"ctc-start",  0, NULL, 'C'}, /* Start CTC w/o initialization */
        {"ctc-stop",   0, NULL, 's'}, /* Stop CTC */
        {"ctc-status", 0, NULL, 'S'}, /* CTC Status */
        {"ctc-diag",   0, NULL, 'k'}, /* CTC diagnostics */
        {"mmt-start",  0, NULL, 'a'}, /* Start MMT */
        {"mmt-stop",   0, NULL, 'A'}, /* Stop MMT */
        {"mmt-status", 0, NULL, 'b'}, /* MMT Status */
        {"mmt-diag",   0, NULL, 'B'}, /* MMT diagnostics */
        {"mbist-diag", 0, NULL, 'm'}, /* Run MBIST diagnostics */
        {"mrs",        0, NULL, 'X'}, /* MRS */
        {"tmrs",       1, NULL, 'x'}, /* TMRS */
        {"channel",    1, NULL, 'y'}, /* TMRS channel */
        {"safety",     0, NULL, 'z'}, /* TMRS safety */
        {"pattern",    1, NULL, 'p'}, /* CTC/MMT Pattern */
        {"reset",      0, NULL, 'r'}, /* Reset */
        {"param",      1, NULL, 'v'}, /* param */
        {"value",      1, NULL, 'V'}, /* param value */
        {"state",      0, NULL, 'Z'}, /* mmt state */
        {"op-timeout", 1, NULL, 'e'}, /* timeout */
        {"read-spares", 1, NULL, 'f'}, /* read spare registers */
        {"read-lane-repairs", 1, NULL, 'F'}, /* read lane repair codes */
        {0,            0, NULL, 0}
    };

    avago_addr_to_struct(aapl_default_device_addr, &addr_struct);
    if( aapl_common_main_options(aapl, argc, argv, &addr_struct) < 0 )
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_hbm_help();
    }
    addr = avago_struct_to_addr(&addr_struct);
    sbm_addr = avago_make_sbus_master_addr(addr);
    if( addr == aapl_default_device_addr || addr_struct.sbus != 0xfd )
        avago_addr_to_struct(sbm_addr, &addr_struct);

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch( rc ) {
          case 'D': hbm_diag   = TRUE; break;
          case 'o': operation   = TRUE; op = aapl_num_from_str(optarg,name,0); break;
          case 'd': device_id   = TRUE; break;
          case 't': temp        = TRUE; break;
          case 'T': temp_diag   = TRUE; count = aapl_num_from_str(optarg,name,0); break;
          case 'i': init_nwl    = TRUE; break;
          case 'c': ctc_init    = TRUE; break;
          case 'C': ctc_start   = TRUE; break;
          case 's': ctc_stop    = TRUE; break;
          case 'S': ctc_status  = TRUE; break;
          case 'k': ctc_diag    = TRUE; break;
          case 'a': mmt_start   = TRUE; break;
          case 'A': mmt_stop    = TRUE; break;
          case 'b': mmt_status  = TRUE; break;
          case 'B': mmt_diag    = TRUE; break;
          case 'm': mbist_diag  = TRUE; break;
          case 'X': mrs         = TRUE; break;
          case 'x': tmrs        = TRUE; tmrs_code = optarg; break;
          case 'y': channel     = aapl_num_from_str(optarg,name,0); break;
          case 'z': safety      = 1;    break;
          case 'p': pattern     = aapl_num_from_str(optarg,name,0); break;
          case 'r': reset       = TRUE; break;
          case 'v': param_set   = TRUE; param = aapl_num_from_str(optarg,name,0); break;
          case 'V': param_value = aapl_num_from_str(optarg,name,0); param_read=0; break;
          case 'Z': state       = 1; break;
          case 'e': timeout_set = TRUE; timeout = aapl_num_from_str(optarg,name,0); break;
          case 'f': read_spares = TRUE; break;
          case 'F': read_lane_repairs = TRUE; break;

          default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                   break;
        }
    }

    if( !hbm_diag && !operation && !device_id && !temp && !temp_diag && !mbist_diag && !ctc_diag && !ctc_init && !ctc_start && !ctc_stop && !ctc_status && !mrs && !tmrs && !reset && !param_set && !init_nwl && !mmt_start && !mmt_stop && !mmt_diag && !mmt_status && !read_spares && !read_lane_repairs)
    {
        aapl_log_printf(aapl, AVAGO_ERR, 0, 0, "No action selected.\n");
        avago_addr_delete(aapl, &addr_struct);
        return show_hbm_help();
    }

    if( operation && ((argc-optind) != 0) )
    {
        aapl_fail(aapl, 0, 0, "The -operation command require one parameters:\n"
                              "    -operation <op_num>\n");
    }

    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
    aapl_get_ip_info(aapl,0);


    if(timeout_set) {
      avago_hbm_default_timeout = timeout;
    }

    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, 0);
        st;
        st = aapl_broadcast_next(aapl, &next, &start, &stop, 0 ) )
    {
      uint sbus_addr = avago_struct_to_addr(&next);

      /* Allow all diag commands to be run from a single command line */
      /* i */
      if (hbm_diag || ctc_diag || mmt_diag || mbist_diag) {
        if (hbm_diag) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Begin HBM diagnostics for HBM on SBus ring %d \n", next.ring);
          avago_hbm_run_diagnostics(aapl, sbus_addr);
        }

        if (ctc_diag) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Begin HBM CTC diagnostics for HBM on SBus ring %d \n", next.ring);
          avago_hbm_run_ctc_diagnostics(aapl, sbus_addr, 1, 1);
        }

        if (mmt_diag) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Begin HBM MMT diagnostics for HBM on SBus ring %d \n", next.ring);
          avago_hbm_run_mmt_diagnostics(aapl, sbus_addr);
        }

        if (mbist_diag) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Begin HBM MBIST diagnostics for HBM on SBus ring %d \n", next.ring);
          avago_hbm_run_mbist_diagnostics(aapl, sbus_addr);
        }

      } else {

        /* All other operations must be run one at a time */
        if (operation) {
          Avago_hbm_operation_results_t results;
          Avago_hbm_operation_t op_enum;
          op_enum = (Avago_hbm_operation_t) op;
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Begin HBM operation 0x%02x for all channels on SBus ring %d \n", op, next.ring);
          avago_hbm_launch_operation(aapl, sbus_addr, op_enum, &results, 5000);
          avago_hbm_print_operation_results(aapl, &results);

        } else if (device_id) {
          Avago_hbm_device_id_t device_id;
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Reading device ID for HBM on SBus ring %d \n", next.ring);
          avago_hbm_read_device_id(aapl, sbus_addr, &device_id);
          avago_hbm_print_device_id(aapl, sbus_addr);

        } else if (temp) {
          int temp;
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Reading temperature for HBM on SBus ring %d \n", next.ring);
          temp = avago_hbm_read_device_temp(aapl, sbus_addr);
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "HBM Temp: %d\n", temp);

        } else if (temp_diag) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Begin temperature diagnostics for HBM on SBus ring %d \n", next.ring);
          avago_hbm_run_temp_diagnostics(aapl, sbus_addr, count);

        } else if (init_nwl) {
          Avago_hbm_operation_results_t results;
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Initializing NWL memory controllers on SBus ring %d \n", next.ring);
          avago_hbm_launch_operation(aapl, sbus_addr, AVAGO_HBM_OP_INITIALIZE_NWL_MCS, &results, 5000);
          avago_hbm_print_operation_results(aapl, &results);


        } else if (ctc_start) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Begin CTC continuous mode (pattern %d) for HBM on SBus ring %d \n", pattern, next.ring);
          avago_hbm_ctc_start(aapl, sbus_addr, pattern, 0);

        } else if (ctc_init) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Begin CTC continuous mode (pattern %d) for HBM on SBus ring %d \n", pattern, next.ring);
          avago_hbm_ctc_start(aapl, sbus_addr, pattern, 1);

        } else if (ctc_stop) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Stopping CTC for HBM on SBus ring %d \n", next.ring);
          avago_hbm_ctc_stop(aapl, sbus_addr);

        } else if (ctc_status) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Begin CTC status for HBM on SBus ring %d \n", next.ring);
          avago_hbm_get_apc_addr(aapl, sbus_addr, &apc_addr);
          avago_hbm_print_ctc_results(aapl, apc_addr);

        } else if (mmt_start) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Begin MMT continuous mode (pattern %d) for HBM on SBus ring %d \n", pattern, next.ring);
          avago_hbm_mmt_start(aapl, sbus_addr, pattern);

        } else if (mmt_stop) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Stopping MMT for HBM on SBus ring %d \n", next.ring);
          avago_hbm_mmt_stop(aapl, sbus_addr);

        } else if (mmt_status) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Begin MMT status for HBM on SBus ring %d \n", next.ring);
          avago_hbm_print_mmt_results(aapl, sbus_addr, state);

        } else if (mrs) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Reading MRS for HBM on SBus ring %d \n", next.ring);
          avago_hbm_print_mrs(aapl, sbus_addr, channel);

        } else if (tmrs) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Sending TMRS to HBM on SBus ring %d \n", next.ring);
          avago_hbm_run_tmrs(aapl, sbus_addr, tmrs_code, channel, safety);

        } else if (reset) {
          Avago_hbm_operation_results_t results;
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Sending reset to PHY/HBM on SBus ring %d \n", next.ring);
          avago_hbm_launch_operation(aapl, sbus_addr, AVAGO_HBM_OP_RESET, &results, 5000);
          avago_hbm_print_operation_results(aapl, &results);

        } else if (param_set) {
          if (param_read == 0x1) {
            Avago_hbm_parameter_t param_enum;
            param_enum = (Avago_hbm_parameter_t) param;
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Reading HBM firmware param %u from SBus ring %d \n", param, next.ring);
            param_value = avago_hbm_get_parameter(aapl, sbus_addr, param_enum);
            printf("%u\n", param_value);
          } else {
            Avago_hbm_parameter_t param_enum;
            param_enum = (Avago_hbm_parameter_t) param;
            aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Writing HBM firmware param %u to %d SBus ring %d \n", param, param_value, next.ring);
            avago_hbm_set_parameter(aapl, sbus_addr, param_enum, param_value);
            param_value = avago_hbm_get_parameter(aapl, sbus_addr, param_enum);
            printf("%u\n", param_value);
          }

        } else if (read_spares) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Reading HBM firmware spare registers for SBus ring %d \n", param, param_value, next.ring);
          avago_hbm_print_spare_results(aapl, sbus_addr);

        } else if (read_lane_repairs) {
          aapl_log_printf(aapl, AVAGO_INFO, 0, 1, "Reading HBM hard lane repairs for SBus ring %d \n", param, param_value, next.ring);
          avago_hbm_print_hard_lane_repairs(aapl, sbus_addr);
        }
      }
    }

    if( aapl->return_code ) aapl_fail(aapl, 0, 1, "ERROR: HBM function failed\n");

    rc = aapl->return_code != 0;
    avago_addr_delete(aapl, &addr_struct);
    return rc;
}

#endif /* AAPL_ENABLE_HBM */
#endif /* AAPL_ENABLE_MAIN */
