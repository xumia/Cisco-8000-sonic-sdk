/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* Customers first AAPL program.  This is a simple example of how to user */
/* AAPL.  A TCP connection is made, SerDes firmware is uploaded and a SerDes */
/* device is initialized. */
/* */
/* For step-by-step instructions on compiling the aapl hello world example,  */
/* see the AAPL Getting Started Guide, "A User's First Program". */
/* */
/* REQUIRED: The user is required to set the ip address of their device.  */
/*           Find "YOUR_IP_ADDRESS" below and change it. */
/* */

#include "aapl.h"

int main(int argc, char *argv[])
{
    /* Set default values: */
    Aapl_comm_method_t comm_method = AVAGO_SBUS; /* See aapl.h for possible options */
    /* If the communication method, set above is AACS_*, you need to provide an */
    /* IP address and port, otherwise they can be left as is. */
    char        ip_address[] = "YOUR_HOSTNAME_OR_IP_ADDRESS";
    int         tcp_port     = 90; /* Default port for Avago HS1/PS1 */

    uint        sbus_addr    = 0x6; /* Default SBus address */
    uint        divider      = 10;
    uint        debug        = 1; /* default debug level */
    Aapl_t     *aapl         = aapl_construct();
    (void)argc;
    (void)argv;

    aapl->communication_method = comm_method;
    aapl->debug = debug;

    /* Make a connection to the device. IP address and port are only used if */
    /* the communication method if AVAGO_AACS_* */
    aapl_connect(aapl, ip_address, tcp_port); if( aapl->return_code < 0 ) AAPL_EXIT(1); 

    /* Gather information about the device and place into AAPL struct */
    aapl_get_ip_info(aapl,1);                 if( aapl->return_code < 0 ) AAPL_EXIT(1);

    /* Initialize serdes (requires that firmware has already been loaded) */
    avago_serdes_init_quick(aapl, sbus_addr, divider);

    if( aapl->return_code ) printf("ERROR: Failed to initialize SerDes\n");
    aapl_destruct(aapl);
    return 0;
}
