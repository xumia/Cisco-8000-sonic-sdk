/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* AAPL (ASIC and ASSP Programming Layer) support for AVSP */

/** Doxygen File Header */
/** @file */
/** @brief Functions specific to retimers, including AVSP-4412 and AVSP-8801.  */

#include "aapl.h"

#if AAPL_ENABLE_AVSP_4412 || AAPL_ENABLE_AVSP_8801

/* This file is intentionally left empty... */

#endif /* AAPL_ENABLE_AVSP_4412 || AAPL_ENABLE_AVSP_8801 */
