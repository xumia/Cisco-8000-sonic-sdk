/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* MAIN program for the avsp_state command. */
/* */

/** Doxygen File Header */
/** @file */
/** @brief Launch wrapper for the avsp_state command. */


#include "aapl.h"

#if AAPL_ENABLE_MAIN && AAPL_ENABLE_AVSP_STATE

static int show_state_help()
{
    aapl_common_main_help(FALSE);
    printf(
"-chip <num>             Chip number upon which to operate.\n"
"-serdes-firmware <file> SerDes firmware to add to sdi output.\n"
"\n"
"-init <mode>           Create default state for mode, where <mode> is one of\n"
"                         REPEATER_DUPLEX, REPEATER_SIMPLEX or GEARBOX_10:4.\n"
);
    printf(
"-div0 <div>            Set divider for first half of AVSP-8812 i.e SD_0..3, 8..11.\n"
"-div1 <div>            Set divider for second half of AVSP-8812 i.e SD_4..7, 9..15.\n"
"-divider <divider>     Set divider value.\n"
);
    printf(
"-half0 <mode>          Select mode for AVSP-8812 SD_0..3, 8..11, where <mode>\n"
"                          REPEATER_DUPLEX, GEARBOX_2:1, GEARBOX_2:1_MOD_HOST, RS_FEC \n"
"-half1 <mode>          Select mode for AVSP-8812 SD_4..7, 9..15, where <mode>\n"
"                          REPEATER_DUPLEX, GEARBOX_2_1, GEARBOX_2_1_MOD_HOST, RS_FEC \n"
);
    printf(
"-xp <tx_source_15:0>   Configure the crosspoint.  Each hex character sets\n"
"                       source Rx for a Tx.  Values are ordered Tx SD_15 to\n"
"                       SD_0.'x' indicates to preserve current Tx source.\n"
"                       Example: 8:8 mode '-xp 7654_3210_fedc_ba98'\n"
);
    printf(
"-read-device           Read state from the device.\n"
"-read-memory           Read state from the device memory.\n"
"-read-sdi <name.sdi>   Read state from a SerDes device image file.\n"
"-read-txt <name.txt>   Read state from a SerDes state description text file.\n"
);
    printf(
"-write-device          Write state directly to the device.\n"
"-write-memory          Write state to the device memory.\n"
"-write-sdi <name.sdi>  Write state to a SerDes device image file.\n"
"-write-txt <name.txt>  Write state to a SerDes state description text file.\n"
"-print                 Print state summary to stdout.\n"
);
    printf(
"-state                 State the device based on the tables in device memory.\n"
"-get-ical              Retrieve the iCal value for the first device.\n"
"-get-pcal              Retrieve the pCal value for the first device.\n"
"-ical <0|1|2>          Set ical value for all SerDes on device, where\n"
"                         0==Do not run iCal, 1==Run iCal, 2==Run w/o dfe tuning.\n"
);
    printf(
"-ical-host <0|1|2>     Set ical value for all host SerDes on device.\n"
"-ical-mod <0|1|2>      Set ical value for all mod SerDes on device.\n"
"-pcal <0|1|2>          Set pcal value for all SerDes on device, where\n"
"                         0==Do not run pCal, 1==Run once, 2==Run continuously.\n"
"-pcal-host <0|1|2>     Set pcal value for all host SerDes on device.\n"
"-pcal-mod <0|1|2>      Set pcal value for all mod SerDes on device.\n"
);
    return 1;
}

int aapl_state_main(int argc, char *argv[], Aapl_t *aapl)
{
    int retval = 0;

/* Parse options: */
    uint        chip = 0;
    uint        addr = 0;
    int         rc, index = 0;
    int         open_device  = 0;
    BOOL        read_device  = FALSE;
    BOOL        write_device = FALSE;
    BOOL        read_memory  = FALSE;
    BOOL        write_memory = FALSE;
    BOOL        print_state  = FALSE;
    BOOL        print_dfe    = FALSE;
    BOOL        get_ical     = FALSE;
    BOOL        get_pcal     = FALSE;
    BOOL        state_device = FALSE;
#if AAPL_ENABLE_AVSP_8812
    BOOL        half0        = FALSE;
    BOOL        half1        = FALSE;
    BOOL        xp           = FALSE;
#endif
#if AAPL_ENABLE_AVSP_8801 && AAPL_AVSP_COUNT == 1
    Avsp_mode_t mode   = AVSP_REPEATER_SIMPLEX;
#else
    Avsp_mode_t mode   = AVSP_REPEATER_DUPLEX;
#endif

#if AAPL_ENABLE_AVSP_8812
    Avsp_mode_t half0_mode      = AVSP_REPEATER_DUPLEX;
    Avsp_mode_t half1_mode      = AVSP_REPEATER_DUPLEX;

    char *crosspoint_settings   = 0;
    int half0_div = -1;
    int half1_div = -1;
#endif
    const char *serdes_name = 0;
    const char *read_txt_name = 0;
    const char *write_txt_name = 0;
    const char *read_sdi_name = 0;
    const char *write_sdi_name = 0;
    const char *avsp_name = "AVSP-4412/8801";

    int readers = 0;
    int writers = 0;
    int ical      = -1;
    int ical_host = -1;
    int ical_mod  = -1;
    int pcal      = -1;
    int pcal_host = -1;
    int pcal_mod  = -1;
    int divider   = 0;
    Avsp_state_t  *state = 0;


    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,

        {"read-device",      0, NULL,  2 },  /* Read struct from configured device */
        {"read-memory",      0, NULL,  4 },  /* Read struct from memory */
        {"read-sdi",         1, NULL,  5 },  /* Read struct from sdi file */
        {"read-txt",         1, NULL,  6 },  /* Read struct from <file name> */
        {"sbm-firmware",     1, NULL,  8 },  /* Upload <file name> to SBM. */
        {"serdes-firmware",  1, NULL,  9 },  /* Upload <file name> to SerDes. */

        {"write-device",     0, NULL, 12 },  /* Write struct to configured device */
        {"write-memory",     0, NULL, 14 },  /* Write struct to memory */
        {"write-sdi",        1, NULL, 15 },  /* Write struct to <sdi file name> */
        {"write-txt",        1, NULL, 16 },  /* Write struct to <file name> */

        {"ical",             1, NULL, 20 },  /* Set ical values */
        {"ical-host",        1, NULL, 21 },
        {"ical-mod",         1, NULL, 22 },
        {"pcal",             1, NULL, 23 },  /* Set pcal values */
        {"pcal-host",        1, NULL, 24 },
        {"pcal-mod",         1, NULL, 25 },
        {"get-ical",         0, NULL, 26 },  /* Get ical values */
        {"get-pcal",         0, NULL, 27 },  /* Get pcal values */
        {"divider",          1, NULL, 28 },  /* Set non-default divider. */

        {"chip",             1, NULL, 30 },  /* <chip number> for device selection. */
        {"init",             1, NULL, 31 },  /* <mode> for device configuration. */
        {"state",            0, NULL, 32 },  /* State serdes into given mode. */
        {"print",            0, NULL, 34 },  /* Print serdes state. */
        {"print-dfe",        0, NULL, 35 },  /* Print serdes dfe state. */
        {"xp",               1, NULL, 40 },  /* crosspoint configuration  */
        /* 8812 specific options */
        {"div0",             1, NULL, 36 },  /* Set non-default divider for half0. */
        {"div1",             1, NULL, 37 },  /* Set non-default divider for half1. */
        {"half0",            1, NULL, 38 },  /* <mode> for half0 of 8812 */
        {"half1",            1, NULL, 39 },  /* <mode> for half1 of 8812 */


        {NULL,               0, NULL, 0  },  /* sentinel entry. */
    };

    if( aapl_common_main_options(aapl, argc, argv, 0) < 0 )
        return show_state_help();

    if( aapl->return_code < 0 ) AAPL_EXIT(1);  /* assume anomalies already reported. */

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch( rc )
        {
        case  2 : read_device = 1; open_device++;   readers++; break;
        case  4 : read_memory = 1; open_device++;   readers++; break;
        case  5 : read_sdi_name = optarg;           readers++; break;
        case  6 : read_txt_name = optarg;           readers++; break;
        case  9 : serdes_name = optarg; break;

        case 12 : write_device = 1;open_device++;   writers++; break;
        case 14 : write_memory = 1;open_device++;   writers++; break;
        case 15 : write_sdi_name = optarg;          writers++; break;
        case 16 : write_txt_name = optarg;          writers++; break;

        case 20:  ical      = aapl_num_from_str(optarg,name,0); break;
        case 21:  ical_host = aapl_num_from_str(optarg,name,0); break;
        case 22:  ical_mod  = aapl_num_from_str(optarg,name,0); break;
        case 23:  pcal      = aapl_num_from_str(optarg,name,0); break;
        case 24:  pcal_host = aapl_num_from_str(optarg,name,0); break;
        case 25:  pcal_mod  = aapl_num_from_str(optarg,name,0); break;
        case 26:  get_ical  = TRUE; break;
        case 27:  get_pcal  = TRUE; break;
        case 28 : divider = aapl_num_from_str(optarg, name,0); break;

        case 30:  chip      = aapl_num_from_str(optarg,name,0); break;
        case 31:  mode = aapl_avsp_mode_from_str(optarg,name);
                  open_device++;
                  readers++;
                  break;
        case 32 : state_device = 1; open_device++;             break;
        case 34 : print_state = 1;                  writers++; break;
        case 35 : print_state = print_dfe = 1;      writers++; break;
#if AAPL_ENABLE_AVSP_8812
        case 36 : half0_div  = aapl_num_from_str(optarg, name,0); break;
        case 37 : half1_div  = aapl_num_from_str(optarg, name,0); break;
        case 38:  half0_mode = aapl_avsp_mode_from_str(optarg,name);
                  half0 = TRUE;
                  break;
        case 39:  half1_mode = aapl_avsp_mode_from_str(optarg,name);
                  half1 = TRUE;
                  break;
        case 40 : xp = TRUE; 
                  crosspoint_settings = optarg;  break;
#endif


/* Note:  opterr = 0 => getopt*() reports the invalid option letter itself, so */
/* this is a followup: */

        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

#if AAPL_ENABLE_AVSP_8812
    /* The default value of half1_div is the same as half0_div */
    if( half1_div < 0 )
        half1_div = half0_div;

    /* if any of the half is configured enable actions */
    if( half0 || half1 )
    {
        open_device++;
        readers++;
    }
#endif
    if( writers == 0 && readers == 0 && !state_device )
        return show_state_help();

    if( writers > 0 && readers != 1 )
        aapl_main_error("Exactly one -init or -read-* option is required when writing state.");

    if( writers == 0 && readers == 1 )
        aapl_main_error("At least one -write-* or -print* option is required when reading state.");

    if( state_device && writers > 0 && !write_memory )
        aapl_main_error("The -state option must be used alone or with the -write-memory option.");

/* No args are allowed beyond options: */

    if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    addr = avago_make_addr3(chip,0,0);
    if( open_device )
    {
        aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
        aapl_get_ip_info(aapl,0);

        avsp_name = aapl_get_chip_name(aapl, addr);
    }

    state = avsp_state_construct(aapl, chip, avsp_name, mode);

    if( state )
    {
        if( open_device )
        {
            state->sbm_fw_revision = avago_sbm_get_firmware_rev(aapl, addr);
            state->sbm_fw_build_id = avago_sbm_get_firmware_build_id(aapl, addr);
        }

        if( read_device )
            avsp_state_read_from_device(aapl, state);
        else if( read_memory )
            avsp_state_read_from_memory(aapl, state);
        else if( read_txt_name )
            avsp_state_read_from_text_file(aapl, read_txt_name, state);
        else if( read_sdi_name )
            avsp_state_read_from_sdi_file(aapl, read_sdi_name, state);

        if( divider > 0 )
            avsp_state_set_divider(aapl, state, divider);

#if AAPL_ENABLE_AVSP_8812
        if( xp )
            avsp_state_set_crosspoint( aapl, state, crosspoint_settings );
        if( half0 )
            avsp_8812_configure_half(aapl, state, half0_mode, half0_div, 0); 
        if( half1 )
            avsp_8812_configure_half(aapl, state, half1_mode, half1_div, 1); 
#endif

        if( ical      != -1 ) avsp_state_set_ical     (state, ical     );
        if( ical_host != -1 ) avsp_state_set_ical_host(state, ical_host);
        if( ical_mod  != -1 ) avsp_state_set_ical_mod (state, ical_mod );
        if( pcal      != -1 ) avsp_state_set_pcal     (state, pcal     );
        if( pcal_host != -1 ) avsp_state_set_pcal_host(state, pcal_host);
        if( pcal_mod  != -1 ) avsp_state_set_pcal_mod (state, pcal_mod );
        if( get_ical ) printf("iCal = %d\n",avsp_state_get_ical(state));
        if( get_pcal ) printf("pCal = %d\n",avsp_state_get_pcal(state));

        if( write_device )
            avsp_state_write_to_device(aapl, state);
        if( write_memory )
            avsp_state_write_to_memory(aapl, state);
        if( write_txt_name )
            avsp_state_write_to_text_file(aapl, write_txt_name, state);
        if( write_sdi_name )
            avsp_state_write_to_sdi_file(aapl, serdes_name, write_sdi_name, state);
        if( print_state )
            avsp_state_print(aapl, state, print_dfe);

        if( state_device )
            avsp_state_device_from_memory(aapl, chip);

        avsp_state_destruct(aapl, state);
    }

    retval = aapl->return_code != 0;

    return retval;
}

#endif /* AAPL_ENABLE_MAIN && AAPL_ENABLE_AVSP_STATE */


#if AAPL_ENABLE_MAIN && AAPL_ENABLE_EEPROM && AAPL_ENABLE_AVSP_STATE

static int show_eeprom_help()
{
    aapl_common_main_help(FALSE);
    printf(
"-i2c-divider <value>        Set I2C clock control byte for image; default=0.\n"
"-d6-serdes-firmware <file>  Select D6 SerDes firmware for image.\n"
"-m4-serdes-firmware <file>  Select M4 SerDes firmware for image.\n"
"-p1-serdes-firmware <file>  Select P1 SerDes firmware for image.\n"
"-sbm-firmware    <file>     Select SBus Master firmware for image.\n"
"-sdi <name.sdi>             Select state from a SerDes device image file.\n"
"-txt <name.txt>             Select state from a SerDes state text file.\n"
);
    printf(
"-auto-state <TRUE|FALSE>    Add auto stating instructions to image; default=FALSE.\n"
"-address-mask <mask>        Create an image for the i2c addresses selected by\n"
"                            <mask>.  Bits [15..0] each represent one address.\n"
"                            Example: a mask of 0x000a selects addresses 1 & 3.\n"
"\n"
);
    printf(
"-write-abi    <name>[_5#.abi] Write firmware and state to an eeprom image file.\n"
"-dump-abi     <name>[_5#.abi] Print formatted dump of an abi.\n"
"-write-device <name>[_5#.abi] Write abi commands to device.\n"
"-write-eeprom <name>[_5#.abi] Write abi file to device's EEPROM.\n"
);
    printf(
"\n"
"Creates one or more EEPROM (.abi) files and/or programs an EEPROM.\n"
"An EEPROM can contain multiple images.\n"
"Each image consists of SerDes and SBus Master firmware, a state (from either\n"
" an .sdi or a .txt file), and an address mask.  One image can apply to all\n"
" devices, or up to 8 unique images can be stored in a 2 MB EEPROM.\n"
);
    printf(
"Notes:\n"
"* An image is created using the option values present when the -address-mask\n"
"    option is parsed.  Therefore, order of options is important.  This also\n"
"    means that if an image uses the same firmware as the previous image, the\n"
"    firmware need not be specified again.  Example:\n"
"\n"
"  aapl eeprom <image1 opts> -address-mask 0xf <image2 opts> -address-mask 0xf0\n"
"\n"
"* Addresses not selected by any address mask are assigned to the first image.\n"
);
    return 1;
}

int aapl_eeprom_main(int argc, char *argv[], Aapl_t *aapl)
{
    int retval = 0;

/* Parse options: */
    uint        chip = ~0U;
    int         rc, index = 0;
    int         i2c_freq_control = 0;
    int         address_mask     = 0;
    const char *sbm_name = 0;
    const char *d6_serdes_name = 0;
    const char *m4_serdes_name = 0;
    const char *p1_serdes_name = 0;
    BOOL        auto_state  = FALSE;
    const char *sdi_name = 0;
    const char *txt_name = 0;
    const char *write_abi_name = 0;

    const char *eeprom_abi_name = 0;
    const char *stream_abi_name = 0;
    const char *dump_abi = 0;
    int         actions = 0;

    #define MAX_IMAGES 8
    Avsp_state_abi_config_t config[MAX_IMAGES];
    Avsp_state_t             state[MAX_IMAGES];
    const char           *filename[MAX_IMAGES];
    int image_count = 0;
    const char  *image_opt_name = 0;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,

        {"i2c-divider",          1, NULL,  1 },  /* Specify clock control byte */
        {"sbm-firmware",         1, NULL,  2 },  /* Upload <file name> to SBM. */
        {"serdes-firmware",      1, NULL,  3 },  /* Upload <file name> to SerDes. */
        {"d6-serdes-firmware",   1, NULL,  3 },  /* Upload <file name> to SerDes. */
        {"m4-serdes-firmware",   1, NULL,  7 },  /* Upload <file name> to SerDes. */
        {"p1-serdes-firmware",   1, NULL,  8 },  /* Upload <file name> to SerDes. */
        {"sdi",                  1, NULL,  4 },  /* Read struct from sdi file */
        {"txt",                  1, NULL,  5 },  /* Read struct from <file name> */
        {"auto-state",           1, NULL,  6 },  /* Add auto-state instructions to abi output. */
        {"address-mask",         1, NULL,  9 },  /* Mask selecting image addresses */

        {"write-abi",        1, NULL, 11 },  /* Write abi output file */
        {"write-device",     1, NULL, 12 },  /* Write abi commands to device */
        {"write-eeprom",     1, NULL, 13 },  /* Write abi to EEPROM. */

        {"chip",             1, NULL, 30 },  /* <chip number> for device selection. */
        {"dump-abi",         1, NULL, 31 },  /* Validate and display info about an ABI file. */

        {NULL,               0, NULL, 0  },  /* sentinel entry. */
    };

    if( aapl_common_main_options(aapl, argc, argv, 0) < 0 )
        return show_eeprom_help();

    if( aapl->return_code < 0 ) AAPL_EXIT(1);  /* assume anomalies already reported. */

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        if( rc >= 0 && rc <= 6 )
            image_opt_name = name;
        switch( rc )
        {
        case  1: i2c_freq_control = aapl_num_from_str(optarg,name,0);   break;
        case  2: sbm_name    = optarg;                                  break;
        case  3: d6_serdes_name = optarg;                               break;
        case  4: sdi_name = optarg;                                     break;
        case  5: txt_name = optarg;                                     break;
        case  6: auto_state = aapl_bool_from_str(optarg,name);          break;
        case  7: m4_serdes_name = optarg;                               break;
        case  8: p1_serdes_name = optarg;                               break;
        case  9: address_mask = aapl_num_from_str(optarg,name,0);
                 if( image_count >= MAX_IMAGES ) aapl_main_error("A maximum of %d images can be specified.\n",MAX_IMAGES);
                 if( !sbm_name ) aapl_main_error("-sbm-firmware option required (before -address-mask) to create an abi file.\n");
                 if( !d6_serdes_name && !m4_serdes_name && !p1_serdes_name )
                     aapl_main_error("-serdes-firmware option required (before -address-mask) to create an abi file.\n");
                 if( !sdi_name && !txt_name ) aapl_main_error("An -sdi-name or -txt-name option is required (before -address-mask) to create an abi file.\n");
                 config[image_count].sbm_fw_path       = sbm_name;
                 config[image_count].d6_serdes_fw_path = d6_serdes_name;
                 config[image_count].m4_serdes_fw_path = m4_serdes_name;
                 config[image_count].p1_serdes_fw_path = p1_serdes_name;
                 config[image_count].i2c_freq_control = i2c_freq_control;
                 config[image_count].auto_state = auto_state;
                 config[image_count].address_mask = address_mask;
                 config[image_count].state = &state[image_count];
                 if( sdi_name )
                 {
                     filename[image_count] = sdi_name;
                     avsp_state_read_from_sdi_file(aapl, sdi_name, config[image_count].state);
                 }
                 else
                 {
                     filename[image_count] = txt_name;
                     avsp_state_read_from_text_file(aapl, txt_name, config[image_count].state);
                 }
                 image_count++;
                 image_opt_name = 0;
                 break;

        case 11: write_abi_name = optarg; actions++; break;
        case 12: stream_abi_name= optarg; actions++; break;
        case 13: eeprom_abi_name= optarg; actions++; break;
        case 31: dump_abi       = optarg; actions++; break;

        case 30: chip = aapl_num_from_str(optarg,name,0); break;


/* Note:  opterr = 0 => getopt*() reports the invalid option letter itself, so */
/* this is a followup: */

        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    if( actions == 0 )
        return show_eeprom_help();

    if( actions != 1 )
        aapl_main_error("Exactly one of -write-abi, -dump-abi, -write-eeprom and -write-device options required.\n");

    if( write_abi_name && image_count == 0 )
        aapl_main_error("Must commit at least one image using -address-mask option to write an abi file.");

    if( stream_abi_name && chip == ~0U )
        aapl_main_error("-write-device option requires -chip option.");

    if( image_opt_name )
        aapl_main_error("image option -%s has no effect after the last -address-mask option.", image_opt_name);

/* No args are allowed beyond options: */

    if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    if( stream_abi_name || eeprom_abi_name )
    {
        aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
        aapl_get_ip_info(aapl,0);
    }

    if( write_abi_name )
    {
        retval = avsp_state_write_to_abi_files(aapl, image_count, config, write_abi_name);
        if( retval == 0 )
        {
            int i, div_table[] = { 3494, 3216, 2000, 1748, 1564, 1000, 874, 782, 438, 392, 350, 314, 220, 196, 176, 158 };
            printf("Output ABI: %s\n",write_abi_name);
            for( i = 0; i < image_count; i++ )
            {
                int j;
                printf("Image: %d\n",i);
                printf("  Clock byte: %d (Divide by %d)\n",config[i].i2c_freq_control,div_table[0xf & config[i].i2c_freq_control]);
                printf("  SBM:        %s\n",config[i].sbm_fw_path);
                printf("  D6 SerDes:     %s\n",config[i].d6_serdes_fw_path);
                printf("  M4 SerDes:     %s\n",config[i].m4_serdes_fw_path);
                printf("  P1 SerDes:     %s\n",config[i].p1_serdes_fw_path);
                printf("  State from: %s\n",filename[i]);
                printf("  Auto state: %s\n",aapl_bool_to_str(config[i].auto_state));
                printf("  Addresses:  ");
                for( j = 0; j < 16; j++ )
                    if( config[i].address_mask & (1 << j) )
                        printf(" %d",j);
                printf("\n");
            }
        }
    }
    (void) eeprom_abi_name;
#if AAPL_ALLOW_I2C || AAPL_ALLOW_SYSTEM_I2C
    if( eeprom_abi_name )
        avsp_abi_write_to_eeprom(aapl, eeprom_abi_name);
#endif

    if( stream_abi_name )
        avsp_abi_write_to_device(aapl, chip, stream_abi_name);

    if( dump_abi )
        avsp_state_dump_abi(aapl,dump_abi);

    retval = aapl->return_code != 0;

    return retval;
}

#endif /* AAPL_ENABLE_MAIN && AAPL_ENABLE_EEPROM */
