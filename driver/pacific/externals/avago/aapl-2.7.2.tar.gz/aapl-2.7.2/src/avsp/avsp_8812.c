/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* AAPL (ASIC and ASSP Programming Layer) support for AVSP */

/** Doxygen File Header */
/** @file */
/** @brief Functions specific to the AVSP-8812 */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_AVSP_8812

/** @brief   Get the SD number of the Rx connected to the given SerDes. */
/** @return  On success, returns SerDes [0..15] connected to the given SD's Tx. */
/** @return  On failure, decrements aapl->return_code and returns -1. */
int avsp_8812_crosspoint_get(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint prtad,         /**< [in] Port address of the targeted device. */
    uint to_sd)         /**< [in] SerDes number of the Tx to query. */
{
    if( to_sd < 16 )
    {
        /* Register 0 of sbus addr 0x14 selects source for 8 SerDes: 76543210 */
        /* [3..0]   Rx connected to SD 0 Tx */
        /* [7..4]   Rx connected to SD 1 Tx */
        /* [11..8]  Rx connected to SD 2 Tx */
        /* [15..12] Rx connected to SD 3 Tx */
        /* [19..16] Rx connected to SD 4 Tx */
        /* [23..20] Rx connected to SD 5 Tx */
        /* [27..24] Rx connected to SD 6 Tx */
        /* [31..28] Rx connected to SD 7 Tx */
        /* Register 0 of sbus addr 0x1b selects source for 8 SerDes: fedcba98 */
        /* [3..0]   Rx connected to SD 8 Tx */
        /* [7..4]   Rx connected to SD 9 Tx */
        /* [11..8]  Rx connected to SD 10 Tx */
        /* [15..12] Rx connected to SD 11 Tx */
        /* [19..16] Rx connected to SD 12 Tx */
        /* [23..20] Rx connected to SD 13 Tx */
        /* [27..24] Rx connected to SD 14 Tx */
        /* [31..28] Rx connected to SD 15 Tx */

        int return_code = aapl->return_code;
        uint addr = avago_make_addr3(prtad,0,to_sd < 8 ? 0x14: 0x1b);
        int shift = (to_sd & 7) * 4;
        int from_sd = (avago_sbus_rd(aapl, addr, 0) >> shift) & 0x0f;
        aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Rx SD%d connected to SD%u\n",from_sd,to_sd);
        return aapl->return_code == return_code ? from_sd : -1;
    }
    return aapl_fail(aapl,__func__,__LINE__,"Parameter out of range: %u\n", to_sd);
}

/** @brief   Routes output of from_sd's Rx (possibly after FEC and/or Gearbox */
/**          processing) to the core input of to_sd's Tx. */
/** @details Configures the crosspoint, but does not configure the FEC or */
/**          Gearbox for any particular mode, or the SerDes on either end. */
/** @return  On success, returns 0. */
/** @return  On failure, decrements aapl->return_code and returns -1. */
int avsp_8812_crosspoint_connect(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint prtad,         /**< [in] Port address of the targeted device. */
    uint from_sd,       /**< [in] SerDes number */
    uint to_sd)         /**< [in] SerDes number */
{
    if( from_sd < 16 && to_sd < 16 )
    {
        /* Register 0 of sbus addr 0x14 selects source for 8 SerDes: 76543210 */
        /* [3..0]   Select Rx to connect to SD 0 Tx */
        /* [7..4]   Select Rx to connect to SD 1 Tx */
        /* [11..8]  Select Rx to connect to SD 2 Tx */
        /* [15..12] Select Rx to connect to SD 3 Tx */
        /* [19..16] Select Rx to connect to SD 4 Tx */
        /* [23..20] Select Rx to connect to SD 5 Tx */
        /* [27..24] Select Rx to connect to SD 6 Tx */
        /* [31..28] Select Rx to connect to SD 7 Tx */
        /* Register 0 of sbus addr 0x1b selects source for 8 SerDes: fedcba98 */
        /* [3..0]   Select Rx to connect to SD 8 Tx */
        /* [7..4]   Select Rx to connect to SD 9 Tx */
        /* [11..8]  Select Rx to connect to SD 10 Tx */
        /* [15..12] Select Rx to connect to SD 11 Tx */
        /* [19..16] Select Rx to connect to SD 12 Tx */
        /* [23..20] Select Rx to connect to SD 13 Tx */
        /* [27..24] Select Rx to connect to SD 14 Tx */
        /* [31..28] Select Rx to connect to SD 15 Tx */

        int return_code = aapl->return_code;
        uint addr = avago_make_addr3(prtad,0,to_sd < 8 ? 0x14: 0x1b);
        uint ret;
        int shift = (to_sd & 7) * 4;
        ret = avago_sbus_rmw(aapl, addr, 0, from_sd << shift, 0xf << shift);
        aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "XP from %u to %u: before=%x, after=%x\n",from_sd,to_sd,ret,avago_sbus_rd(aapl, addr, 0));
        return aapl->return_code == return_code ? 0 : -1;
    }
    return aapl_fail(aapl,__func__,__LINE__,"Parameter out of range: %u, %u\n",from_sd, to_sd);
}

/** @brief   Retrieves all crosspoint values. */
/** @details The crosspoint array specifies the receiver output */
/**          to which each transmitter is listening. That is, */
/**          crosspoint[tx_sd] = rx_sd for each tx_sd in [0..15]. */
/** @return  On success, returns 0. */
/** @return  On failure, decrements aapl->return_code and returns -1. */
int avsp_8812_crosspoint_get_all(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint prtad,         /**< [in] Port address of the targeted device. */
    char crosspoint[16])/**< [in] Rx selection for each Tx */
{
    int return_code = aapl->return_code;

    int i;
    uint value = avago_sbus_rd(aapl, avago_make_addr3(prtad,0,0x14), 0);
    for( i = 0; i < 8; i++ )
        crosspoint[i] = (value >> (i*4)) & 0xf;

    value = avago_sbus_rd(aapl, avago_make_addr3(prtad,0,0x1b), 0);
    for( i = 0; i < 8; i++ )
        crosspoint[i+8] = (value >> (i*4)) & 0xf;

    return aapl->return_code == return_code ? 0 : -1;
}

/** @brief   Sets all crosspoint values. */
/** @details The crosspoint array specifies the receiver output */
/**          to which each transmitter should listen. That is, */
/**          crosspoint[tx_sd] = rx_sd for each tx_sd in [0..15]. */
/** @return  On success, returns 0. */
/** @return  On failure, decrements aapl->return_code and returns -1. */
int avsp_8812_crosspoint_connect_all(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint prtad,         /**< [in] Port address of the targeted device. */
    char crosspoint[16])/**< [in] Rx selection for each Tx */
{
    int return_code = aapl->return_code;

    uint addr = avago_make_addr3(prtad,0,0x14);
    int i, value = 0;

    for( i = 0; i < 8; i++ )
        value |= (crosspoint[i] & 0xf) << (i * 4);
    avago_sbus_wr(aapl, addr, 0, value);

    addr = avago_make_addr3(prtad,0,0x1b);
    value = 0;
    for( i = 0; i < 8; i++ )
        value |= (crosspoint[i+8] & 0xf) << (i * 4);
    avago_sbus_wr(aapl, addr, 0, value);

    return aapl->return_code == return_code ? 0 : -1;
}

/** @brief   Retrieves whether the selected device is enabled or disabled. */
/** @details The sbus parameter selects which gearbox or FEC block to check. */
/** @return  Returns 0 if the device is in pass-through mode. */
/** @return  Returns 1 if the device's functionality is enabled. */
/** @return  Returns -1 if the device is in an unknown state. */
int avsp_8812_get_enabled(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint prtad,     /**< [in] Port address of the targeted device. */
    uint sbus)      /**< [in] Select the device on which to report. */
{
    uint ctl_addr = avago_make_addr3(prtad, 0, sbus);
    Avago_ip_type_t ip_type = aapl_get_ip_type(aapl, ctl_addr);
    if( ip_type == AVAGO_SAPPH_GBX )    /* 0x15 - 0x18 */
    {
        uint reg03 = avago_sbus_rd(aapl, ctl_addr,  3);
        uint reg18 = avago_sbus_rd(aapl, ctl_addr, 18);
        uint reg19 = avago_sbus_rd(aapl, ctl_addr, 19);
        aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"prtad=%u, sbus=%u, reg03=0x%x, reg18=0x%x\n",prtad, sbus, reg03, reg18);
        if(  reg03 == 0 && (reg18 & 0xf00) == 0 && (reg19 & 0xf00) == 0 ) return 0;   /* Repeater, reg18 and reg19 check fast and slow muxes in pass-through */
        if( (reg03 == 7 && reg18 == 0x0500) 
         || (reg03 == 7 && reg18 == 0x0200) ) return 1; /* In gearbox mode */
        return -1;
    }
    if( ip_type == AVAGO_RSFEC_BRIDGE ) /* 0x19 - 0x1a */
    {
        uint reg00 = avago_sbus_rd(aapl, ctl_addr, 0x00);
        uint reg20 = avago_sbus_rd(aapl, ctl_addr, 0x20);
        uint reg40 = avago_sbus_rd(aapl, ctl_addr, 0x40);
        uint reg60 = avago_sbus_rd(aapl, ctl_addr, 0x60);
        uint reg80 = avago_sbus_rd(aapl, ctl_addr, 0x80);
        aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"prtad=%u, sbus=%u, reg00=0x%x, reg20=0x%x, reg40=0x%x, reg60=0x%x, reg80=0x%x\n",prtad, sbus, reg00, reg20, reg40, reg80);
        if( (reg80 & 0xf) == 0x0f ) return 0;   /* In pass through mode */
        if( (reg80 & 0x3ff) == 0x310 
         && (reg00 & 0x0ff) == 0x051
         && (reg20 & 0x0ff) == 0x051
         && (reg40 & 0x0ff) == 0x051
         && (reg60 & 0x0ff) == 0x051
          ) return 1; /* In FEC mode */
        return -1;
    }
    return aapl_fail(aapl, __func__, __LINE__, "Sbus 0x%02x, Invalid device queried.\n", sbus);
}

/** @brief   Retrieves the mode of the selected gearbox. */
/** @details The sbus parameter selects which gearbox block to check. */
/** @details The mode can be pass-through, host-to-mode, or mod-host. */
/** @return  Returns 0 if the device is in pass-through mode. */
/** @return  Returns 1 if gearbox is enabled and is in host-to-mod */
/** @return  Returns 2 if gearbox is enabled and is in mod-to-host */
/** @return  Returns -1 if the device is in an unknown state, or a failure */
/**          occured. */
int avsp_8812_get_gearbox_mode(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint prtad,     /**< [in] Port address of the targeted device. */
    uint sbus)      /**< [in] Select the device on which to report. */
{
    uint ctl_addr = avago_make_addr3(prtad, 0, sbus);
    Avago_ip_type_t ip_type = aapl_get_ip_type(aapl, ctl_addr);

    if( ip_type == AVAGO_SAPPH_GBX )    /* 0x15 - 0x18 */
    {
        int fec_addr;
        int gearbox_value =  avsp_8812_get_enabled(aapl, prtad, sbus);
        if( gearbox_value == 0 ) return 0; /* Bypass mode */

        if( sbus == AVSP_8812_GB2_ADDR || sbus == AVSP_8812_GB3_ADDR ) /* Figure out the address of the related FEC block */
            fec_addr = AVSP_8812_FEC1_ADDR;
        else
            fec_addr = AVSP_8812_FEC0_ADDR;
     
        /* Determine what mode the device is in. */
        if( gearbox_value == 1)
        {
            uint fec_mode = avago_sbus_rd(aapl, avago_make_addr3(prtad, 0, fec_addr), 0x80);
            uint reg18 = avago_sbus_rd(aapl, sbus, 18);
            uint reg19 = avago_sbus_rd(aapl, sbus, 19);
            aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"State of Gearbox: address=0x%02x, GB=%d, reg18=0x%x, reg19=0x%x, FEC=0x%x\n", sbus, gearbox_value, reg18, reg19, fec_mode);
            if( (fec_mode & 0x3000) == 0x1000 /* This is for host to mod */
             && (reg18    & 0xf00)  == 0x0500
             && (reg19    & 0xf00)  == 0x0200)
                return 1;
            if( (fec_mode & 0x3000) == 0x3000  /* This if for mod to host */
             && (reg18    & 0xf00)  == 0x0200
             && (reg19    & 0xf00)  == 0x0500)
                return 2;
        }
        aapl_log_printf(aapl,AVAGO_DEBUG3,__func__, __LINE__, "The queired Gearbox (at address: 0x%02x), is in an uknown configuration.\n", sbus);
        return -1;
    }
    return aapl_fail(aapl, __func__, __LINE__, "Sbus 0x%02x, Invalid device queried.\n", sbus);
}

/** @brief  Configure FEC modes. */
/** @return Returns 0 on success. */
/** @return On error, decrements aapl->return_code and returns -1. */
int avsp_8812_set_control(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    uint prtad,                 /**< [in] The port address of the device to modify. */
    uint which,                 /**< [in] Which FEC block to access [0 or 1]. */
    Avsp_fec_register_t type,   /**< [in] Select register to update. */
    int value)                  /**< [in] New value to set. */
{
    uint ctl_logic = avago_make_addr3(prtad, 0, which == 0 ? 0x19 : 0x1a);
    switch( type )
    {
    case AVSP_FEC_ERROR_INDICATION_DISABLE:
        avago_sbus_rmw(aapl, ctl_logic, 0xd0, value ? 0x02 : 0, 0x02);
        return 0;
    case AVSP_FEC_ERROR_CORRECTION_BYPASS_ENABLE:
        avago_sbus_rmw(aapl, ctl_logic, 0xd0, value ? 0x08 : 0, 0x08);
        return 0;
    default: break;
    }
    return aapl_fail(aapl, __func__, __LINE__, "Unsupported Avsp_fec_register_t type: %d\n", type);
}

#define COMBINE_LO_HI(a,b) ((a & 0xffff) | (b << 16))
/** @brief */
int avsp_8812_get_status(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    uint prtad,                 /**< [in] The port address of the device to read. */
    uint which,                 /**< [in] Which FEC block to access [0 or 1]. */
    Avsp_fec_register_t type,   /**< [in] Status type to retrieve.  For multi-value types, lane and/or host provide the index. */
    uint lane,                  /**< [in] Select lane number. Range [0-3] for symbol errors, */
                                /**<      [0-19] for BIP errors, [0-6] for symbol errors per codeword. */
    BOOL host)                  /**< [in] Select host(TRUE) or mod(FALSE) slices */
{
    uint ctl_logic = avago_make_addr3(prtad, 0, which == 0 ? 0x19 : 0x1a);
    uint version = 2;
    if (avago_sbus_rd(aapl, ctl_logic, 0xed) == 0x5a0) version = 1;

    switch( type )
    {
    case AVSP_PCS_LANE_MAPPING:     /* Select which lane to read, then read: */
                                             avago_sbus_wr(aapl, ctl_logic, 0xa3, (lane & 0x1f));
                                     return (avago_sbus_rd(aapl, ctl_logic, 0xa3) >>  5) & 0x1f;
    case AVSP_PCS_LANE_ALIGNMENT:    return  avago_sbus_rd(aapl, ctl_logic, 0xa4);  /* bits [19:0] */
    case AVSP_PCS_BLOCK_LOCK:        return  avago_sbus_rd(aapl, ctl_logic, 0xa5);  /* bits [19:0] */
/*  case AVSP_FEC_HIGH_SER: */

    case AVSP_FEC_ERROR_INDICATION_DISABLE_ABILITY: return (avago_sbus_rd(aapl, ctl_logic, 0xd0) >> 0) & 1;
    case AVSP_FEC_ERROR_INDICATION_DISABLE:         return (avago_sbus_rd(aapl, ctl_logic, 0xd0) >> 1) & 1;
    case AVSP_FEC_ERROR_CORRECTION_BYPASS_ABILITY:  return (avago_sbus_rd(aapl, ctl_logic, 0xd0) >> 2) & 1;
    case AVSP_FEC_ERROR_CORRECTION_BYPASS_ENABLE:   return (avago_sbus_rd(aapl, ctl_logic, 0xd0) >> 3) & 1;
    case AVSP_FEC_LANE_ALIGNMENT:                   return  avago_sbus_rd(aapl, ctl_logic, 0xa6);  /* 8812 */
    case AVSP_FEC_LANE_MAPPING:  /* Return hex value with lane maps for 3-0 stored in a hex value as 0x3210 */
    {
        int ret = avago_sbus_rd(aapl, ctl_logic, 0xd0);
        return ((ret >> 8) & 3) | ((ret >> 6) & 0x30) | ((ret >> 4) & 0x300) | ((ret >> 2) & 0x3000);
    }
    case AVSP_FEC_CORRECTED:
    {
        if (version == 1) return COMBINE_LO_HI(avago_sbus_rd(aapl, ctl_logic, 0xd1),avago_sbus_rd(aapl, ctl_logic, 0xd2));
        else return avago_sbus_rd(aapl, ctl_logic, 0xd1);
    }
    case AVSP_FEC_UNCORRECTED:
    {
        if (version == 1) return COMBINE_LO_HI(avago_sbus_rd(aapl, ctl_logic, 0xd3),avago_sbus_rd(aapl, ctl_logic, 0xd4));
        else return avago_sbus_rd(aapl, ctl_logic, 0xd2);
    }
    case AVSP_FEC_SYMBOL_ERRORS: lane &= 3;
    {
        if (version == 1) return COMBINE_LO_HI(avago_sbus_rd(aapl, ctl_logic, 0xd5 + 2*lane), avago_sbus_rd(aapl, ctl_logic, 0xd6 + 2*lane));
        else return avago_sbus_rd(aapl, ctl_logic, 0xd4 + lane);
    }
    case AVSP_FEC_SYMBOL_ERRORS_CW: lane &= 7;
    {
        if (lane < 5)
        {
            /* 32 bit stats */
            if (version == 1) return COMBINE_LO_HI(avago_sbus_rd(aapl, ctl_logic, 0xe2 + 2*lane), avago_sbus_rd(aapl, ctl_logic, 0xe3 + 2*lane));
            else return avago_sbus_rd(aapl, ctl_logic, 0xdd + lane); /* effectively start from 0xea */
        }
        else
        {
            /* 16 bit stats */
            if (version == 1) return avago_sbus_rd(aapl, ctl_logic, 0xe5 + lane);
            else return avago_sbus_rd(aapl, ctl_logic, 0xdc + lane); /* effectively start from 0xe1 */
        }
    }
/*  case AVSP_HI_BER:            return (avago_sbus_rd(aapl, ctl_logic, 0x31) >> (host ? 6 : 7)) & 1; */
    case AVSP_BIP_ERRORS:        /* Select which host/lane to read, then read: */
                                         avago_sbus_wr(aapl, ctl_logic, (version == 1) ? 0xee : 0xed, (host & 0x1) | ((lane & 0x1f) << 1));
                                 return (avago_sbus_rd(aapl, ctl_logic, (version == 1) ? 0xee : 0xed) >> 16) & 0xffff;
    case AVSP_ALL_ERRORS:
    {
        int lane;
        int symbls;
        int errors = 0;

        int errors_1 = avsp_8812_get_status(aapl, prtad, which, AVSP_FEC_CORRECTED, 0, 0);
        int errors_2 = avsp_8812_get_status(aapl, prtad, which, AVSP_FEC_UNCORRECTED, 0, 0);
        errors += errors_1 + errors_2;
        if( aapl->verbose )
        {
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"Corrected codewords:                      %11u\n",errors_1);
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"Uncorrectable codewords:                  %11u\n",errors_2);
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"\n");
        }

        for( symbls = 0; symbls < 7; symbls++ )
        {
            /* symbols in error within codeword, not to be confused with per lanei, nor with consecutive symbols counts */
            int sym_errors_cw = avsp_8812_get_status(aapl, prtad, which, AVSP_FEC_SYMBOL_ERRORS_CW, symbls, 0);
            errors += sym_errors_cw;
            if( aapl->verbose )
            {
                if (symbls < 5)
                {
                    /* 32 bit stats */
                    aapl_log_printf(aapl,AVAGO_INFO,0,0,"Codewords with %1d errored symbols:         %11u\n",symbls + 1,sym_errors_cw);
                }
                else
                {
                    /* 16 bit stats */
                    aapl_log_printf(aapl,AVAGO_INFO,0,0,"Codewords with %1d errored symbols:              %6u\n",symbls + 1,sym_errors_cw);
                }
            }
        }
        if( aapl->verbose ) aapl_log_printf(aapl,AVAGO_INFO,0,0,"\n");

        for( lane = 0; lane < 4; lane++ )
        {
            int errors_lane = avsp_8812_get_status(aapl, prtad, which, AVSP_FEC_SYMBOL_ERRORS, lane, 0);
            errors += errors_lane;
            if( aapl->verbose )
                aapl_log_printf(aapl,AVAGO_INFO,0,0,"Errored symbols on FEC lane %1d:            %11u\n",lane,errors_lane);
        }
        if( aapl->verbose ) aapl_log_printf(aapl,AVAGO_INFO,0,0,"\n");

        for (lane = 0; lane < 20; lane++)
        {
            int errors_m = avsp_8812_get_status(aapl, prtad, which, AVSP_BIP_ERRORS, lane, 0);
            int errors_h = avsp_8812_get_status(aapl, prtad, which, AVSP_BIP_ERRORS, lane, 1);
            errors += errors_m + errors_h;
            if( aapl->verbose )
                aapl_log_printf(aapl,AVAGO_INFO,0,0,"BIP[host %2d]: %11d,   BIP[mod %2d]: %11d\n", lane, errors_h, lane, errors_m);
        } 
 
        if( aapl->verbose )
        {
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"\n");
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"PCS Block Lock     = 0x%05x\n", avsp_8812_get_status(aapl, prtad, which, AVSP_PCS_BLOCK_LOCK, 0, 0));
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"PCS Lane Alignment = 0x%05x\n", avsp_8812_get_status(aapl, prtad, which, AVSP_PCS_LANE_ALIGNMENT, 0, 0));
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"FEC Lane Alignment = 0x%05x\n", avsp_8812_get_status(aapl, prtad, which, AVSP_FEC_LANE_ALIGNMENT, 0, 0));
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"\n");
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"PCS Lane Mapping   =");
            for( lane = 0; lane < 20; lane++ )
                aapl_log_printf(aapl,AVAGO_INFO,0,0,"%3d", avsp_8812_get_status(aapl, prtad, which, AVSP_PCS_LANE_MAPPING, lane, 0));
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"\n");
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"FEC Lane Mapping   = 0x%05x\n", avsp_8812_get_status(aapl, prtad, which, AVSP_FEC_LANE_MAPPING, 0, 0));
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"\n");
        }
        return errors;
    }
    default: break;
    }
    return aapl_fail(aapl, __func__, __LINE__, "Unsupported Avsp_fec_register_t type: %d\n", type);
}

/** @brief: Clears FEC error counters */
void avsp_8812_fec_error_reset(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    uint prtad,                 /**< [in] The port address of the device to read. */
    uint which)                 /**< [in] Which FEC block to access [0 or 1]. */
{
    uint ctl_logic = avago_make_addr3(prtad, 0, which == 0 ? 0x19 : 0x1a);
    uint version = 2;
    if (avago_sbus_rd(aapl, ctl_logic, 0xed) == 0x5a0) version = 1;

    if (version == 1) 
    {
        /* version 1 reset statistics via FEC engine reset */
        avago_sbus_wr(aapl, ctl_logic, 0x84, 0x02);
        avago_sbus_wr(aapl, ctl_logic, 0xfe, 0x8000);
        avago_sbus_wr(aapl, ctl_logic, 0x84, 0x00); 
        avago_sbus_wr(aapl, ctl_logic, 0xfe, 0x00); 
    } 
    else
    { 
        /* version 2 reset statistics via clear on read */
        avago_sbus_rmw(aapl, ctl_logic, 0xeb, 0x200, 0x200); /* set clear on read */
        avago_sbus_rd(aapl, ctl_logic, 0xd0); /* perform reads */
        avago_sbus_rd(aapl, ctl_logic, 0xd1);
        avago_sbus_rd(aapl, ctl_logic, 0xd2);
        avago_sbus_rd(aapl, ctl_logic, 0xd3);
        avago_sbus_rd(aapl, ctl_logic, 0xd4);
        avago_sbus_rd(aapl, ctl_logic, 0xd5);
        avago_sbus_rd(aapl, ctl_logic, 0xd6);
        avago_sbus_rd(aapl, ctl_logic, 0xd7);
        avago_sbus_rmw(aapl, ctl_logic, 0xeb, 0x000, 0x200); /* clear clear on read */
    }
}

static void phase_cal_8812_serdes(Aapl_t *aapl, uint prtad, uint *addr, uint len)
{
    uint i = 0;
    for( i = 0; i < len; i++ )
    {
         uint sbus_addr = avago_make_addr3(prtad, 0, addr[i]);
         avago_spico_int_check(aapl, __func__, __LINE__, sbus_addr, 0xb, 1);     /* Tx Phase Cal */
    }
}

/** @brief   get serdes address for the half selected as per crosspoint setup configured */
/** @details The half parameter selects which half to check. */
static void avsp_8812_half_serdes_addr(Aapl_t *aapl, uint prtad, uint half, uint *addr )
{
    uint begin = 0, end = 0;
    char crosspoint[16];
    static uint serdes_addrs[] = { AVSP_8812_LIST };
    uint xp, n;
    uint i = 0;
    avsp_8812_crosspoint_get_all( aapl, prtad, crosspoint );

     begin = ( half == 0 ) ? 0 : 4; /* select beginning serdes number according to the selected half */
     end = ( half == 0 ) ? 4 : 8; /* select ending serdes number according to the selected half */
     i = 0;
     for( n = begin; n < end; n++ )
     {
          xp = crosspoint[n]; /* get configured crosspoint */
          addr[i] = serdes_addrs[xp];
          i++;
     }
     for( n = begin+8; n < end+8; n++ )
     {
          xp = crosspoint[n]; /* get configured crosspoin */
          addr[i] = serdes_addrs[xp];
          i++;
     }
}

/** @brief   Bring up device according to rx signal */
/** @return  On success, returns 0. */
/** @return  On error, returns -1. */
int avsp_8812_bring_up(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    uint prtad,             /**< [in] Port address of the targeted device. */
    uint half,              /**< [in] half for which do bring up  */
    const char * direction, /**< [in] direction for bring up */
    const char * sel_tuning)       /**< [in] perform tuning or not */
{

    uint count = 0, begin = 0;
    uint i = 0, n = 0;
    uint addr[8];
    uint len = 8;
    Avsp_mode_t mode;
    Avago_serdes_dfe_state_t *dfe = avago_serdes_dfe_state_construct(aapl);
    uint path_addr[4];

    if(!(half == 0 || half == 1))
         return aapl_fail(aapl, __func__, __LINE__, "Invalid half selected\n");
    if(!(( strcmp( direction, "slow") == 0) || (strcmp( direction, "both") == 0) || (strcmp( direction, "fast") == 0 )))
         return aapl_fail(aapl, __func__, __LINE__, "Invalid direction value: %s for half %d \n", direction, half);
         
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, " Performing bring up for %s direction of half%d.\n", direction, half);

    for( count = 0; count < 2; count ++ )
    {
    if( half == count ){ 
    mode = avsp_8812_get_mode(aapl, prtad, count); /* get mode for the half selected */
    switch( mode ){
    case AVSP_GEARBOX_2_1:
         
         begin = ( count == 0 ) ? 0 : 4;
         avsp_8812_half_serdes_addr( aapl, prtad, count, addr );
         for( i = 0; i < 8; i++ )
         {
              avago_serdes_initialize_signal_ok( aapl, addr[i], 0 );
              if( avago_serdes_get_signal_ok( aapl, addr[i], 1 ) == 0 ) continue;
              else
                  aapl_log_printf(aapl,AVAGO_WARNING,__func__,__LINE__,"Signal OK fail for SerDes: 0x%04x\n", addr[i]);
         }
         if( strcmp( direction, "slow") == 0 || strcmp( direction, "both") == 0) /* if opt for bringup slow path */
         {
             if( strcmp( sel_tuning, "TUNE") == 0 )
             {
                 n = 0;
                 aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing ical tuning on slow Rx of half%d.\n", half);
                 for( i = begin; i < begin+4; i++ ) 
                 {
                      path_addr[n] = 0x13 - i;
                      n++;
                 }
                 avago_serdes_dfe_batch_tune(aapl, dfe, 4, path_addr, 500, 400, 10000); /* tune slow Rx of selected half */
             }
             n = 0;
             aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing Tx phase calibration on fast Tx of selected half%d.\n", half);
             for( i = begin; i < begin+4; i++ ) /* phase cal fast tx */
             {
                  path_addr[n] = addr[n];
                  n++;
             }
             phase_cal_8812_serdes(aapl, prtad, path_addr, 4); /* phase cal fast tx of selected half */
         }
         if( strcmp( direction, "fast") == 0 || strcmp( direction, "both") == 0) /* if opt for bringup fast path */
         {
             if( strcmp( sel_tuning, "TUNE") == 0 )
             {
                 n = 0;
                 aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing ical tuning on fast Rx of selected half%d.\n", half);
                 for( i = begin; i < begin+4; i++ )
                 {
                      path_addr[n] = 0x0b - i;
                      n++;
                 }
                 avago_serdes_dfe_batch_tune(aapl, dfe, 4, path_addr, 500, 400, 10000); /* tune fast Rx of selected half */
             }
             n = 0;
             aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing Tx phase calibration on slow Tx of selected half%d.\n", half);
             for( i = begin; i < begin+4; i++ )
             {
                  path_addr[n] = addr[n+4];
                  n++;
             }
             phase_cal_8812_serdes(aapl, prtad, path_addr, 4); /* phase cal slow tx of selected half */
             
         }
         break;
    case AVSP_GEARBOX_2_1_MOD_HOST:
         begin = ( count == 0 ) ? 0 : 4;
         avsp_8812_half_serdes_addr( aapl, prtad, count, addr );
         for( i = 0; i < 8; i++ )
         {
              avago_serdes_initialize_signal_ok( aapl, addr[i], 0 );
              if( avago_serdes_get_signal_ok( aapl, addr[i], 1 ) == 0 ) continue;
              else
                  aapl_log_printf(aapl,AVAGO_WARNING,__func__,__LINE__,"Signal OK fail for SerDes: 0x%04x\n", addr[i]);
         }
         if( strcmp( direction, "fast") == 0 || strcmp( direction, "both") == 0) /* if opt for bringup fast path */
         {
             if( strcmp( sel_tuning, "TUNE") == 0 )
             {
                 n = 0;
                 aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing ical tuning on fast Rx of selected half%d.\n", half);
                 for( i = begin; i < begin+4; i++ )
                 {
                      path_addr[n] = 0x0b - i;
                      n++;
                 }
                 avago_serdes_dfe_batch_tune(aapl, dfe, 4, path_addr, 500, 400, 10000); /* tune fast Rx of selected half */
             }
             n = 0;
             aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing Tx phase calibration on slow Tx of selected half%d.\n", half);
             for( i = begin; i < begin+4; i++ )
             {
                  path_addr[n] = addr[n+4];
                  n++;
             }
             phase_cal_8812_serdes(aapl, prtad, path_addr, 4); /* phase cal slow tx of selected half */
             
         }
         if( strcmp( direction, "slow") == 0 || strcmp( direction, "both") == 0) /* if opt for bringup slow path */
         {
             if( strcmp( sel_tuning, "TUNE") == 0 )
             {
                 n = 0;
                 aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing ical tuning on slow Rx of half%d.\n", half);
                 for( i = begin; i < begin+4; i++ ) 
                 {
                      path_addr[n] = 0x13 - i;
                      n++;
                 }
                 avago_serdes_dfe_batch_tune(aapl, dfe, 4, path_addr, 500, 400, 10000); /* tune slow Rx of selected half */
             }
             n = 0;
             aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing Tx phase calibration on fast Tx of selected half%d.\n", half);
             for( i = begin; i < begin+4; i++ ) /* phase cal fast tx */
             {
                  path_addr[n] = addr[n];
                  n++;
             }
             phase_cal_8812_serdes(aapl, prtad, path_addr, 4); /* phase cal fast tx of selected half */
         }
         break;
    case AVSP_REPEATER_DUPLEX:
         avsp_8812_half_serdes_addr( aapl, prtad, count, addr );
         for( i = 0; i < 8; i++ )
         {
              avago_serdes_initialize_signal_ok( aapl, addr[i], 0 );
              if( avago_serdes_get_signal_ok( aapl, addr[i], 1 ) == 0 ) {}
              else
                  aapl_log_printf(aapl,AVAGO_WARNING,__func__,__LINE__,"Signal OK fail for SerDes: 0x%04x\n", addr[i]);
         }
         if( strcmp( sel_tuning, "TUNE") == 0 ) /* if opt for tuning */
         {
             aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing ical tuning on selected slices.\n");
             avago_serdes_dfe_batch_tune(aapl, dfe, len, addr, 500, 400, 10000);
         }
         if( ( strcmp( direction, "slow") == 0 ) || ( strcmp( direction, "fast") == 0 ) || strcmp( direction, "both") == 0 )
         {
             aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing Tx phase calibration on selected slices.\n");
             phase_cal_8812_serdes(aapl, prtad, addr, len);
         }
         break;
    case AVSP_RS_FEC_4x4:
         avsp_8812_half_serdes_addr( aapl, prtad, count, addr );
          /* Put MOD slices into ELB */
          for( i = 0; i < 4; i++ )
          {
               avago_spico_int(aapl, avago_make_addr3(prtad, 0, addr[i]), 0x08, 0x0100);
          }
          
         if( strcmp( sel_tuning, "TUNE") == 0 ) /* if opt for tuning */
         {
             aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing ical tuning on selected slices.\n");
             avago_serdes_dfe_batch_tune(aapl, dfe, len, addr, 500, 400, 10000);
         }
         /* Do phase calibration */
         if( ( strcmp( direction, "slow") == 0 ) || ( strcmp( direction, "fast") == 0 ) || strcmp( direction, "both") == 0 )
         {
             aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Performing Tx phase calibration on selected slices.\n");
             phase_cal_8812_serdes(aapl, prtad, addr, len);
         }
         break;
         
    default:
         break;
    }
    }
    }
    avago_serdes_dfe_state_destruct(aapl, dfe);
    return 0;
}
                                                                                                
/** @brief  Retrieves the mode into which the core logic is configured. */
/** @details The half parameter selects for which half to return mode. */
/** @return Returns the core logic configuration mode. */
Avsp_mode_t avsp_8812_get_mode(
    Aapl_t *aapl,      /**< [in] Pointer to Aapl_t structure. */
    uint prtad,        /**< [in] port address of device */
    uint half)         /**< [in] sel half for which reading mode */
{
    int gearbox_value = 0;
    int fec_value = 0;
    Avsp_mode_t mode = AVSP_ADHOC;

    if( half == 0 )
    {
        gearbox_value =  avsp_8812_get_gearbox_mode(aapl, prtad, AVSP_8812_GB0_ADDR); /* Only need to use gearbox0 address,  */
                                                                                      /* because we assume gearbox1 is the same configuration */
        fec_value = avsp_8812_get_enabled(aapl, prtad, AVSP_8812_FEC0_ADDR);
    }
    else if(half == 1 )
    {
        gearbox_value =  avsp_8812_get_gearbox_mode(aapl, prtad, AVSP_8812_GB2_ADDR); /* Only need to use gearbox2 address,  */
                                                                                      /*because we assume gearbox3 is the same configuration */
        fec_value = avsp_8812_get_enabled(aapl, prtad, AVSP_8812_FEC1_ADDR);
    }
    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"Chip \"mode\" settings for half = %d, GB = %d, FEC = %d\n", half, gearbox_value, fec_value);

    /* Check if any of the devices are in an unknown state, and report an Error */
    if( gearbox_value < 0 || fec_value < 0 )
    {
        aapl_log_printf(aapl,AVAGO_DEBUG3,__func__,__LINE__, "Failed to get the current state of the Gearbox and/or FEC block, for half%d.\n", half);
        return AVSP_ADHOC;
    }

    /* Determine what mode the device is in. */
    if ((gearbox_value == 0) && (fec_value == 0))
        mode = AVSP_REPEATER_DUPLEX; /* fec and gb block in pass through mode */
    else if ((gearbox_value == 1) && (fec_value == 0))
            mode = AVSP_GEARBOX_2_1;
    else if ((gearbox_value == 2) && (fec_value == 0))
            mode = AVSP_GEARBOX_2_1_MOD_HOST;
    else if ((gearbox_value == 0) && (fec_value == 1))
        mode = AVSP_RS_FEC_4x4;
    else
    {
        aapl_fail(aapl, __func__,__LINE__, "The chip is in an unsupported mode for half%d, at least the Gearbox or FEC needs to be in bypass.\n", half);
        return AVSP_ADHOC;
    }

    aapl_log_printf(aapl,AVAGO_DEBUG3,__func__,__LINE__,"Mode %s configured in half%d of 8812\n",aapl_avsp_mode_to_str(mode), half );
    return mode;     
       

}


/** @brief   Configure internal logic for the given mode. */
/** @details Assumes that the crosspoint configured externally. */
/** @return  On success, returns 0. */
/** @return  On failure, decrements aapl->return_code and returns -1. */
int avsp_8812_set_mode(
    Aapl_t *aapl,         /**< [in] Pointer to Aapl_t structure. */
    Avsp_state_t *state,  /**< State structure to write. */
    uint half)            /**< half on which to configure mode */
{
    static uint gb0_gb1_addr[] = { AVSP_8812_GB0_GB1_ADDRS_LIST }; /* address of gearbox0 and gearbox1 */
    static uint gb2_gb3_addr[] = { AVSP_8812_GB2_GB3_ADDRS_LIST }; /* address of gearbox2 and gearbox3 */
    static uint fec_addr[] = { AVSP_8812_FEC_ADDRS_LIST }; /* FEC block address  */
    uint gb = 0, addr = 0;

    switch( state->u.a8812.half_mode[half] )
    {
    case AVSP_REPEATER_DUPLEX: { /* Bypass FEC and gearboxes: */
        for( gb = 0; gb < 2; gb++ )
        {
             addr = ( half == 0 ) ? avago_make_addr3(state->prtad, 0, gb0_gb1_addr[gb]) : avago_make_addr3(state->prtad, 0, gb2_gb3_addr[gb]);
             avago_sbus_wr(aapl, addr,  3, 0x0000);  /* Un-reset all pass through phase beacons */

             /* The following are power-on defaults: */
             avago_sbus_wr(aapl, addr,  1, 0x3044);  /* Hold gearbox clocks in reset */
             avago_sbus_wr(aapl, addr, 18, 0x0000);  /* Select pass-through on fast muxes  */
             avago_sbus_wr(aapl, addr, 19, 0x0060);  /* Select pass-through on slow muxes */
                                                      /* Hold two2one mux in reset     */
             avago_sbus_wr(aapl, addr, 39, 0x8282);  /* Hold one2two muxes in reset */
        } 
         
        if( half == 0 ) avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0,0x19), 0x80, 0xf);
        if( half == 1 ) avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0,0x1a), 0x80, 0xf);
        break;
    }
    
    case AVSP_GEARBOX_2_1: { /* Bypass FEC, enable gearboxes: */
         /* configure gearboxex in the selected half */
         avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0,fec_addr[half]), 0x80, 0x100f); /* bypass FEC for the selected half */
         /* Configure gearboxes registers */
         for( gb = 0; gb < 2; gb++ )
         { 
              addr = ( half == 0 ) ? avago_make_addr3(state->prtad, 0, gb0_gb1_addr[gb]) : avago_make_addr3(state->prtad, 0, gb2_gb3_addr[gb]); /* get serdes address of the selected half */
              avago_sbus_wr(aapl, addr,  1, 0x3044);
              avago_sbus_wr(aapl, addr,  2, 0x000a);  /* Select i_tx_fifo_clk_{slow,fast}_0 */
              avago_sbus_wr(aapl, addr,  3, 0x0007);  /* Hold in reset all pass through phase beacons */
              avago_sbus_wr(aapl, addr, 19, 0x0060);  /* Reset */
              avago_sbus_wr(aapl, addr, 39, 0x8282);  /* Reset */
              avago_sbus_wr(aapl, addr, 19, 0x0020);  /* Clear Resets */
              avago_sbus_wr(aapl, addr, 39, 0x0202);  /* Clear Resets */
              avago_sbus_wr(aapl, addr, 49, 0x0000);  /* Select slow inputs to slow fifos */
              avago_sbus_wr(aapl, addr, 19, 0x0202);  /* Set two2one to output interleaved data to slow0 output, slow1 input passthrough to slow1 output */
              avago_sbus_wr(aapl, addr, 48, 0x0001);  /* Select fast0 input to fast fifo */
              avago_sbus_wr(aapl, addr, 39, 0x0706);  /* Set one2two to demux interleaved data. */
              avago_sbus_wr(aapl, addr, 18, 0x0500);  /* Select one2two output to fast0, fast1 */
         }
         break;
    }
    case AVSP_GEARBOX_2_1_MOD_HOST: { /* Bypass FEC, enable gearboxes: */
        /* configure gearboxex in the selected half */
        avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0,fec_addr[half]), 0x80, 0x300f); /* bypass FEC for the selected half */
        /* Configure gearboxes registers */
        for( gb = 0; gb < 2; gb++ )
        { 
             addr = ( half == 0 ) ? avago_make_addr3(state->prtad, 0, gb0_gb1_addr[gb]) : avago_make_addr3(state->prtad, 0, gb2_gb3_addr[gb]); /* get serdes address of the selected half */
             avago_sbus_wr(aapl, addr,  1, 0x3044);
             avago_sbus_wr(aapl, addr,  2, 0x000a);  /* Select i_tx_fifo_clk_{slow,fast}_0 */
             avago_sbus_wr(aapl, addr,  3, 0x0007);  /* Hold in reset all pass through phase beacons */
             avago_sbus_wr(aapl, addr, 19, 0x0060);  /* Reset */
             avago_sbus_wr(aapl, addr, 39, 0x8282);  /* Reset */
             avago_sbus_wr(aapl, addr, 19, 0x0020);  /* Clear Resets */
             avago_sbus_wr(aapl, addr, 39, 0x0202);  /* Clear Resets */
             avago_sbus_wr(aapl, addr, 49, 0x0003);  /* Select fast inputs  */
             avago_sbus_wr(aapl, addr, 19, 0x0502);  /* Set one2two to output interleaved data to slow0 output, slow1 input passthrough to slow1 output */
             avago_sbus_wr(aapl, addr, 48, 0x0000);  /* Select slow0 input to fast fifo */
             avago_sbus_wr(aapl, addr, 39, 0x0706);  /* Set one2two to demux interleaved data. */
             avago_sbus_wr(aapl, addr, 18, 0x0200);  /* Select two2one output to fast0, fast1 */
        }
        break;
    }
  
    case AVSP_RS_FEC_4x4: { /*Bypass gearboxes and enable 4x4 FEC */
         int sbus;
         Avago_serdes_dfe_state_t *dfe = avago_serdes_dfe_state_construct(aapl);
         uint serdes_addr[8];

         /*addr = (half == 0) ? 0x1a : 0x19; // get fec block address of the unselected half to bypass */
         /*avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0,addr), 0x80, 0x100f); // bypass fec block of the unselected half */

         /* Enable RS-FEC mode */
         /* Select LAN specific Control */
         /* nosync/66bsyn/100G/40G/Other/RS = 1XXX/0000/0X01/0X10/0X11/01XX */
         avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0,fec_addr[half]), 0x00, 0x51);
         avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0,fec_addr[half]), 0x20, 0x51);
         avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0,fec_addr[half]), 0x40, 0x51);
         avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0,fec_addr[half]), 0x60, 0x51);
         /* Put FEC in RESET state */
         avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0,fec_addr[half]), 0x84, 0x03);
         /* Configure RS FEC and disable FEC Bypass */
         avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0,fec_addr[half]), 0x80, 0x310);
         /* Put 2:1 gearbox in Reset state and select FEC block serdes addr */
         if( half == 0 ) /*FEC0 selection */
         {  
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB0_ADDR),  3, 0x0000); /* Un-reset all pass through phase beacons */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB0_ADDR),  1, 0x3044);  /* Hold gearbox clocks in reset */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB0_ADDR), 18, 0x0000);  /* Select pass-through on fast muxes  */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB0_ADDR), 19, 0x0060);  /* Select pass-through on slow muxes, two2one mux in reset */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB0_ADDR), 39, 0x8282);  /* Hold one2two muxes in reset */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB1_ADDR),  3, 0x0000);  /* Un-reset all pass through phase beacons */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB1_ADDR),  1, 0x3044);  /* Hold gearbox clocks in reset */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB1_ADDR), 18, 0x0000);  /* Select pass-through on fast muxes  */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB1_ADDR), 19, 0x0060);  /* Select pass-through on slow muxes, two2one mux in reset */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB1_ADDR), 39, 0x8282);  /* Hold one2two muxes in reset */
             avsp_8812_half_serdes_addr( aapl, state->prtad, 0, serdes_addr );
         }
         else if( half == 1 ) /*FEC1 selection */
         {
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB2_ADDR),  3, 0x0000);  /* Un-reset all pass through phase beacons */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB2_ADDR),  1, 0x3044);  /* Hold gearbox clocks in reset */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB2_ADDR), 18, 0x0000);  /* Select pass-through on fast muxes  */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB2_ADDR), 19, 0x0060);  /* Select pass-through on slow muxes, two2one mux in reset */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB2_ADDR), 39, 0x8282);  /* Hold one2two muxes in reset */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB3_ADDR),  3, 0x0000);  /* Un-reset all pass through phase beacons */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB3_ADDR),  1, 0x3044);  /* Hold gearbox clocks in reset */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB3_ADDR), 18, 0x0000);  /* Select pass-through on fast muxes  */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB3_ADDR), 19, 0x0060);  /* Select pass-through on slow muxes, two2one mux in reset */
             avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0, AVSP_8812_GB3_ADDR), 39, 0x8282);  /* Hold one2two muxes in reset */
             avsp_8812_half_serdes_addr( aapl, state->prtad, 1, serdes_addr );
         }

         /* Put MOD slices into ILB */
         for( sbus = 0; sbus < 4; sbus++ )
         {
              avago_spico_int(aapl, avago_make_addr3(state->prtad, 0, serdes_addr[sbus]), 0x08, 0x0301);
         }

         /* clear HOST side FEC reset */
         avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0,fec_addr[half]), 0x84, 0x02);

         /* Do Big data reg operation, to select PCS FIFO clk */
         for( sbus = 0; sbus < 8; sbus++ )
         {
              avago_spico_int(aapl, avago_make_addr3(state->prtad, 0, serdes_addr[sbus]), 0x18, 0x4073);
              avago_spico_int(aapl, avago_make_addr3(state->prtad, 0, serdes_addr[sbus]), 0x18, 0x4073);
              avago_spico_int(aapl, avago_make_addr3(state->prtad, 0, serdes_addr[sbus]), 0x19, 0x0e61);
              avago_spico_int(aapl, avago_make_addr3(state->prtad, 0, serdes_addr[sbus]), 0x18, 0x4073);
              avago_spico_int(aapl, avago_make_addr3(state->prtad, 0, serdes_addr[sbus]), 0x0c, 0x0300);
         }

         /* Clear Mod FEC reset */
         avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0,fec_addr[half]), 0x84, 0x00);

         /*Set broadcast address to 0, to display Corrected/Uncorreected error count */
         avago_sbus_wr(aapl, avago_make_addr3(state->prtad,0,fec_addr[half]), 0xfe, 0x0000);
         avago_serdes_dfe_state_destruct(aapl, dfe);
         /* END of FEC configuration */
         break;
    }
    default:
    break;
    }
    return 0;
}

int avsp_8812_channel_swap(Aapl_t *aapl, uint prtad, uint gb)
{
    uint gb_addr;
    uint current_val;
    uint new_val;

    gb_addr = avago_make_addr3(prtad, 0, 0x15 + gb);
    current_val = avago_sbus_rd(aapl, gb_addr, 39);
    switch( current_val )
    {
    case 0x706 : new_val = 0x0607; break;
    case 0x607 : new_val = 0x0706; break;
    default    : return aapl_fail(aapl, __func__,__LINE__,"Unexpected configuration value: 0x%x\n",current_val);
    }
    return avago_sbus_wr(aapl, gb_addr, 39, new_val);  /* Set one2two to demux interleaved data. */
}

/** @brief   Aligns all gearbox configured channels. */
/** @details If gb is -1, select all 2:1 / 1:2 channels. */
/**          If slip_count is 0, attempts to automatically align output */
/**          channels. Otherwise, simply slips the output by the given count. */
/**          Automatic alignment assumes that the high-speed output is looped */
/**          back to self. */
/** @returns 0 on success, -1 on failure. */
int avsp_8812_channel_align(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint prtad)         /**< [in] Port address of the targeted device. */
{ 

    uint xp = 0, ind;
    int i = 0;
    uint orig, gb = 0, count;
    uint gb2_1_addr = 0;
    uint gb1_2_addr = 0;
    int return_code = aapl->return_code;
    Avsp_mode_t half_mode[2];
    char crosspoint[16];
    const int max_loop_count = 3;

    half_mode[0] = avsp_8812_get_mode(aapl, prtad, 0); /* get mode configured in half 0  */
    half_mode[1] = avsp_8812_get_mode(aapl, prtad, 1); /* get mode configured in half 1 */
/*
    if( slip_count )
    {
        uint gb_addr = avago_make_addr3(prtad, 0, 0x15 + gb);
        return avsp_8812_channel_swap(aapl, gb_addr);
    }
*/
    /* get crosspoint settings */
    avsp_8812_crosspoint_get_all( aapl, prtad, crosspoint );

    /* Attempt automatic alignment: */
    for( count = 0; count < 2; count++ )
    {
    uint begin = (count == 0) ? 0 : 2;
    uint end = (count == 0) ? 2 : 4;

    if( half_mode[count] == AVSP_GEARBOX_2_1 || half_mode[count] == AVSP_GEARBOX_2_1_MOD_HOST ) /* alignment takes place only in gearbox mode */
    {   
        for( ind = begin; ind < end; ind++ )
        {
             xp = crosspoint[2*ind]; /* get  */
             gb2_1_addr = avago_make_addr3(prtad, 0, 0x15+ind); 
             switch( xp ){ /* update gearbox address and channel number according to the crosspoint settings */
             case 0x8:
             case 0x9:
                   gb1_2_addr = avago_make_addr3(prtad, 0, 0x15); gb = 0;
                   break;
             case 0xa:
             case 0xb:
                   gb1_2_addr = avago_make_addr3(prtad, 0, 0x16); gb = 1;
                   break;
             case 0xc:
             case 0xd:
                   gb1_2_addr = avago_make_addr3(prtad, 0, 0x17); gb = 2;
                   break;
             case 0xe:
             case 0xf:
                   gb1_2_addr = avago_make_addr3(prtad, 0, 0x18); gb = 3;
                   break;
             default:
                   break;
             }  
             /* Set high-speed gearbox to output a unique pattern on each channel: */
             avago_sbus_wr(aapl, gb2_1_addr, 21, 0x00dd);      /* Load high bits of pattern into 2:1 output// 21 */
             avago_sbus_wr(aapl, gb2_1_addr, 20, 0xc88ddc88);  /* Load low bits of pattern// 20 */
             orig = avago_sbus_rmw(aapl, gb2_1_addr, 19, 0, 0x007f);  /* Switch output to pattern */
             for( i = 0; i < max_loop_count; i++ )
             {
                  uint val0 = avago_sbus_rd(aapl, gb1_2_addr, 44);
                  uint val1 = avago_sbus_rd(aapl, gb1_2_addr, 46);

                  if( val0 == 0x55555 || val0 == 0xaaaaa )    /* pattern on channel 0 */
                      avsp_8812_channel_swap(aapl, prtad, gb);
                  if( val1 == 0x55555 || val1 == 0xaaaaa )    /* pattern on channel 1 */
                      break;  /* Aligned */
                  ms_sleep(1);
             }
             avago_sbus_wr(aapl, gb2_1_addr, 19, orig);  /* Switch back to original configuration */
             if( i >= max_loop_count )
                 aapl_fail(aapl,__func__,__LINE__,"gb%d: Automatic alignment failed after %d loops.\n",gb,i);
             else
                 aapl_log_printf(aapl,AVAGO_DEBUG3,__func__,__LINE__,"gb%d: Alignment complete after %d loops.\n",gb,i);
        }
     }
     }
     return aapl->return_code == return_code ? 0 : -1;
}

/** @brief   Directly resets the core logic for #mode. */
/** @return  On success, returns 0. */
/** @return  On failure, decrements aapl->return_code and returns -1. */
BOOL avsp_8812_control_logic_reset_direct(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint prtad,        /**< [in] Port address of the targeted device. */
    Avsp_mode_t mode,       /**< [in] The desired operating mode: */
                            /**<   - AVSP_PMA: Set 2:1  mode for each half */
                            /**<   - AVSP_RPT: Set 4:4  mode for each half */
    uint half)              /**< - select half for which to reset control logic */
{   
    uint addr;
    if( half == 0 ){ /* reset logic for half 0 */
        if( mode == AVSP_GEARBOX_2_1 )
        {
            addr = avago_make_addr3(prtad, 0, 0x15);
            avago_sbus_wr(aapl, addr, 4, 0x0007);  /* reset pulse for slow0 slow 1 and fast gearfifos */

            addr = avago_make_addr3(prtad, 0, 0x16);
            avago_sbus_wr(aapl, addr, 4, 0x0007);  /* reset pulse for slow0 slow 1 and fast gearfifos */

            avsp_8812_bring_up(aapl, prtad, 0, (const char*)"both", (const char*)"NO_TUNE");
        }
        if( mode == AVSP_RS_FEC_4x4 )
        {
            addr = avago_make_addr3(prtad, 0, 0x19);
            avago_sbus_wr(aapl, addr, 0x84, 0x0003);  /* Put FEC in reset */
            avago_sbus_wr(aapl, addr, 0x84, 0x0002);  /* Clear host FEC reset */
            avago_sbus_wr(aapl, addr, 0x84, 0x0000);  /* Clear mod FEC reset */
        }
    }  
    
    if( half == 1 ){ /* reset logic for half1 */
        if( mode == AVSP_GEARBOX_2_1 )
        {
            addr = avago_make_addr3(prtad, 0, 0x17);
            avago_sbus_wr(aapl, addr, 4, 0x0007);  /* reset pulse for slow0 slow 1 and fast gearfifos */

            addr = avago_make_addr3(prtad, 0, 0x18);
            avago_sbus_wr(aapl, addr, 4, 0x0007);  /* reset pulse for slow0 slow 1 and fast gearfifos */

            avsp_8812_bring_up(aapl, prtad, 1, (const char*)"both", (const char*)"NO_TUNE");
        }
        if( mode == AVSP_RS_FEC_4x4 )
        {
            addr = avago_make_addr3(prtad, 0, 0x1a);
            avago_sbus_wr(aapl, addr, 0x84, 0x0003);  /* Put FEC in reset */
            avago_sbus_wr(aapl, addr, 0x84, 0x0002);  /* Clear host FEC reset */
            avago_sbus_wr(aapl, addr, 0x84, 0x0000);  /* Clear mod FEC reset */
        }
    }
    return 0;
}

#if 0
/* Suppress Doxygen generation for non-existent functions: */
/** @cond INTERNAL */

/** @brief   Enables or disables FEC. */
/** @return  On success, returns 0. */
/** @return  On failure, decrements aapl->return_code and returns -1. */
int avsp_8812_fec_enable(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint prtad,         /**< [in] Port address of the targeted device. */
    uint fec,           /**< [in] Which FEC block to enable [0 or 1]. */
    BOOL enable)        /**< [in] TRUE to enable, false to bypass. */
{
    int return_code = aapl->return_code;
    uint addr = avago_make_addr3(prtad,0, fec ? 0x1a : 0x19);   /* 0x19 is fec0, 0x1a is fec1. */
    int en = enable ? 0 : 0xf;
    avago_sbus_wr(aapl, addr, 0x80, en);
    return aapl->return_code == return_code ? 0 : -1;
}

/** @brief   Disables FEC and Gearbox operation. */
/** @return On success, returns 0. */
/** @return On failure, decrements aapl->return_code and returns -1. */
int avsp_8812_set_bypass_mode(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint prtad)         /**< [in] Port address of the targeted device. */
{
    int return_code = aapl->return_code;

    avsp_8812_fec_enable(aapl, prtad, 0, FALSE);        /* Bypass fec0 */
    avsp_8812_fec_enable(aapl, prtad, 1, FALSE);        /* Bypass fec1 */

    /* Set Gearbox bypass mode: */
    for( sbus = 0x15; sbus < 0x19; sbus++ )
    {
        uint addr = avago_make_addr3(prtad,0,sbus);
        avago_sbus_wr(aapl, addr,  1, 0x0949);
        avago_sbus_wr(aapl, addr,  3, 0x0000);
        avago_sbus_wr(aapl, addr, 19, 0x0020);
        avago_sbus_wr(aapl, addr, 39, 0x4040);
    }
    return aapl->return_code == return_code ? 0 : -1;
}

static int avsp_8812_bypass_fec(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint prtad,         /**< [in] Port address of the targeted device. */
    uint fec)           /**< [in] Which FEC block to bypass */
{
    int return_code = aapl->return_code;
    uint addr = avago_make_addr3(prtad,0, fec ? 0x1a : 0x19);     /* TODO: Confirm addr 0x19 controls sd[0..3] and 0x1a sd[4..7] */
    avago_sbus_wr(aapl, addr, 0x80, 0xf);
    return aapl->return_code == return_code ? 0 : -1;
}

static int avsp_8812_bypass_gearbox(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint prtad,         /**< [in] Port address of the targeted device. */
    uint sd)            /**< [in] SerDes number */
{
    int return_code = aapl->return_code;
    int array[4] = { 0x15, 0x16, 0x17, 0x18 };
    uint addr = avago_make_addr3(prtad,0, array[sd/2]);     /* TODO: Confirm these addresses are correct */

    avago_sbus_wr(aapl, addr,  1, 0x0949);
    avago_sbus_wr(aapl, addr,  3, 0x0000);
    avago_sbus_wr(aapl, addr, 19, 0x0020);
    avago_sbus_wr(aapl, addr, 39, 0x4040);

    return aapl->return_code == return_code ? 0 : -1;
}

/** @brief   Configures the crosspoint for bi-directional */
/**          communication between the two SerDes. */
/** @details Sets passthrough mode on associated FEC and Gearbox elements used */
/**          by these SerDes. */
/** @return On success, returns 0. */
/** @return On failure, decrements aapl->return_code and returns -1. */
int avsp_8812_crosspoint_biconnect(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint prtad,         /**< [in] Port address of the targeted device. */
    int sdA,            /**< [in] SerDes number */
    int sdB)            /**< [in] SerDes number */
{
    /* Convert the sd numbers to sbus addresses */
    uint len, *addrs;
    if( !aapl_get_addr_list(aapl, prtad, 0, AVSP_ALL, &len, &addrs) )
        return aapl_fail(aapl,__func__,__LINE__,"Failed to retrieve addresses.\n");

    avsp_8812_crosspoint_connect(aapl, prtad, sdA, sdB);
    avsp_8812_crosspoint_connect(aapl, prtad, sdB, sdA);

    avsp_8812_bypass_fec(aapl, prtad, sdA);
    avsp_8812_bypass_fec(aapl, prtad, sdB);

    avsp_8812_bypass_gearbox(aapl, prtad, sdA);
    avsp_8812_bypass_gearbox(aapl, prtad, sdB);
}

/** @brief   Configures the named SerDes devices for bi-directional */
/**          communication through the crosspoint. */
/** @details Also sets associated FEC and Gearbox elements used by these SerDes */
/**          to passthrough mode. */
/** @return On success, returns 0. */
/** @return On failure, decrements aapl->return_code and returns -1. */
int avsp_8812_serdes_connect(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint prtad,         /**< [in] Port address of the targeted device. */
    int sdA,            /**< [in] SerDes number */
    int sdB,            /**< [in] SerDes number */
    int divider)        /**< [in] Divider for external communication. */
{
    /* Convert the sd numbers to sbus addresses */
    uint len, *addrs;
    if( !aapl_get_addr_list(aapl, prtad, 0, AVSP_ALL, &len, &addrs) )
        return aapl_fail(aapl,__func__,__LINE__,"Failed to retrieve addresses.\n");

    avsp_8812_crosspoint_biconnect(aapl,prtad, sdA, sdB);

    /* Call serdes_init on the two named SerDes, setting dividers and width mode */
    Avago_serdes_init_config_t *config = avago_serdes_init_config_construct(aapl);

    config->init_mode = AVAGO_INIT_ONLY;
    config->tx_divider = divider;
    config->tx_width = 40;
    config->tx_phase_cal = TRUE;

    config->rx_divider = divider;
    config->rx_width = 40;
    config->signal_ok_en = TRUE;
    BOOL refclk_sync_master;

    errors = avago_serdes_init(aapl, addrs[sdA], config);
    errors = avago_serdes_init(aapl, addrs[sdB], config);
    avago_serdes_init_config_destruct(aapl, config);

    /* Setup the core clocks: */
    avago_serdes_set_pcs_fifo_clk_div(aapl, addrs[sdA], AVAGO_SERDES_PCS_FIFO_F50);
    avago_serdes_set_pcs_fifo_clk_div(aapl, addrs[sdB], AVAGO_SERDES_PCS_FIFO_F50);

    avago_serdes_set_tx_data_sel(aapl, addrs[sdA], AVAGO_SERDES_TX_DATA_SEL_CORE);
    avago_serdes_set_tx_data_sel(aapl, addrs[sdB], AVAGO_SERDES_TX_DATA_SEL_CORE);

    /* Configure the phase slips for the SerDes */
    /* Bypass associated FEC */
    /* Set bypass mode in associated Gearbox(s) */
    /* Verify communication */
        /* Set up PRBS on one TX, loopback to RX, CORE on other TX, loopback */
        /* to RX and RX PRBS compare and verify zero errors. */
        /* Inject error on first TX and verify detected on receiving RX. */
        /* Repeat in other direction. */
        /* Disable loop backs, turn off comparators and set TX source to CORE. */
    /* Do necessary cleanup and return status. */
    return -1;
}
/** @endcond */
#endif

#endif /* AAPL_ENABLE_AVSP_8812 */

