/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* MAIN program for the avsp-xxxx commands. */
/* */

/** Doxygen File Header */
/** @file */
/** @brief Launch wrapper for ASSP functions */


#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_MAIN && AAPL_ENABLE_AVSP && AAPL_ENABLE_FILE_IO

#if AAPL_ENABLE_AVSP_1104 || AAPL_ENABLE_AVSP_5410 || AAPL_ENABLE_AVSP_7412 || AAPL_ENABLE_AVSP_8812 || AAPL_ENABLE_AVSP_9104
static void phase_cal_serdes(Aapl_t *aapl, uint prtad, Avsp_addr_list_t list)
{
    uint len, *addrs;
    if( aapl_get_addr_list(aapl, prtad, 0, list, &len, &addrs) )
    {
        uint i;
        for( i = 0; i < len; i++ )
        {
            uint addr = avago_make_addr3(prtad, 0, addrs[i]);
            avago_spico_int_check(aapl, __func__, __LINE__, addr, 0xb, 1);     /* Tx Phase Cal */
        }
    }
}
#endif

#if AAPL_ENABLE_AVSP_1104

static int show_avsp_1104_help()
{
    aapl_common_main_help(FALSE);
printf(
"-chip <chip_number>    The chip number to access; range [0-15]; default = 0.\n"
"-halve                 Halve REFCLK frequency within the clock pad.\n"
"-serdes-upload <file>  Upload SerDes firmware file.\n"
"-sbm-upload    <file>  Upload SBus Master firmware file.\n"
"\n"
);

printf(
"-mode  <RPT|PMA> <div>         Configure mode and divider using SBus Master.\n"
"-reset                         Reset the core control logic using SBus Master.\n"
"-reset-host-to-mod             Reset half the control logic using SBus Master.\n"
"-reset-mod-to-host             Reset half the control logic using SBus Master.\n"
);
printf(
"-direct-mode <RPT|PMA> <div>          Same actions as previous 4 options\n"
"-direct-reset <RPT|PMA>                except do action directly\n"
"-direct-reset-host-to-mod <RPT|PMA>    rather than using the\n"
"-direct-reset-mod-to-host <RPT|PMA>    SBus Master processor.\n"
);

printf(
"\n"
"-batch-tune                    Tune all slices.\n"
"-host-batch-tune               Tune host slices.\n"
"-mod-batch-tune                Tune mod slices.\n"
"-tune-mode <ICAL|PCAL>         DFE tune mode to use; default = iCal.\n"
);

    return 1;
}

int aapl_avsp_1104_main(int argc, char *argv[], Aapl_t *aapl)
{
    int retval = 0;

/* Parse options: */
    uint        chip        = 0;
    int         rc, index   = 0;
    const char *serdes_filename = 0;
    const char *sbm_filename = 0;
    Avsp_mode_t mode        = AVSP_RPT;
    BOOL do_mode            = FALSE;
    BOOL do_reset           = FALSE;
    BOOL do_reset_host_to_mod = FALSE;
    BOOL do_reset_mod_to_host = FALSE;
    BOOL do_direct_mode     = FALSE;
    BOOL do_direct_reset    = FALSE;
    BOOL do_direct_reset_host_to_mod = FALSE;
    BOOL do_direct_reset_mod_to_host = FALSE;
    BOOL halve              = FALSE;
    BOOL batch_tune_host    = FALSE;
    BOOL batch_tune_mod     = FALSE;
    Avago_serdes_dfe_tune_mode_t tune_mode = AVAGO_DFE_ICAL;
    int divider = 0;
    int actions = 0;
    const char *device_name = 0;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,

        {"serdes-upload",    1, NULL, 10 },  /* Upload <file name> to SerDes. */
        {"sbm-upload",       1, NULL, 11 },  /* Upload <file name> to SBM. */
        {"halve",            0, NULL, 12 },  /* Halve the ref clock */

        {"batch-tune",       0, NULL, 15 },  /* Tune all */
        {"host-batch-tune",  0, NULL, 16 },  /* Tune host Rx */
        {"mod-batch-tune",   0, NULL, 17 },  /* Tune mod Rx */
        {"tune-mode",        1, NULL, 18 },  /* Set tune mode */

        {"mode",             1, NULL, 20 },  /* Mode and hostside divider value. */
        {"reset",            0, NULL, 21 },  /* Use SBM */
        {"reset-host-to-mod",0, NULL, 22 },  /* Use SBM */
        {"reset-mod-to-host",0, NULL, 23 },  /* Use SBM */
        {"direct-mode",      1, NULL, 30 },  /* Mode and div; operate directly */
        {"direct-reset",     1, NULL, 31 },  /* Mode; operate directly */
        {"direct-reset-host-to-mod",1, NULL, 32 },  /* Mode; operate directly */
        {"direct-reset-mod-to-host",1, NULL, 33 },  /* Mode; operate directly */

        {"chip",             1, NULL, 'c'},  /* <chip number> for device selection. */
        {NULL,               0, NULL, 0  },  /* sentinel entry. */
    };

    if( aapl_common_main_options(aapl, argc, argv, 0) < 0 )
        return show_avsp_1104_help();

    if( aapl->return_code < 0 ) AAPL_EXIT(1);  /* assume anomalies already reported. */

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch( rc )
        {
        case 'c': chip   = aapl_num_from_str(optarg, name, 0); break;

        case 10 : serdes_filename = optarg; break;
        case 11 : sbm_filename    = optarg; break;
        case 12 : halve = TRUE; break;

        case 15 : batch_tune_host = batch_tune_mod = TRUE; break;
        case 16 : batch_tune_host = TRUE; break;
        case 17 : batch_tune_mod  = TRUE; break;
        case 18 : tune_mode       = aapl_dfe_tune_mode_from_str(optarg, name); break;

        case 20 : do_mode         = TRUE; mode = aapl_avsp_mode_from_str(optarg, name); actions++; break;
        case 21 : do_reset        = TRUE;                                               actions++; break;
        case 22 : do_reset_host_to_mod = TRUE;                                          actions++; break;
        case 23 : do_reset_mod_to_host = TRUE;                                          actions++; break;
        case 30 : do_direct_mode  = TRUE; mode = aapl_avsp_mode_from_str(optarg, name); actions++; break;
        case 31 : do_direct_reset = TRUE; mode = aapl_avsp_mode_from_str(optarg, name); actions++; break;
        case 32 : do_direct_reset_host_to_mod = TRUE;
                  mode = aapl_avsp_mode_from_str(optarg, name);                         actions++; break;
        case 33 : do_direct_reset_mod_to_host = TRUE;
                  mode = aapl_avsp_mode_from_str(optarg, name);                         actions++; break;

        case '?':
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    if( !serdes_filename && !sbm_filename && actions == 0 && !batch_tune_host && !batch_tune_mod )
        return show_avsp_1104_help();

    if( halve && (!serdes_filename || !sbm_filename) )
        aapl_main_error("The halve option requires SerDes and SBus master firmware.\n");

    if( actions > 1 )
        aapl_main_error("Only one of -mode, -reset, -direct-mode and -direct-reset allowed.\n");

    if( do_mode || do_direct_mode )
    {
        if( (argc-optind) != 1 )
            aapl_main_error("The mode command requires a divider parameter.\n");
        divider = aapl_num_from_str(argv[optind++],"mode",0);
    }

    if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
    aapl_get_ip_info(aapl,0);
    device_name = aapl_get_chip_name(aapl, avago_make_addr3(chip,0,0));

    if( serdes_filename && sbm_filename )
    {
        printf("Uploading firmware files to %s device %u.\n", device_name, chip);
        avsp_upload_firmware_file(aapl, chip, halve, serdes_filename, sbm_filename);
    }
    else if( serdes_filename )
    {
        uint broadcast_addr = avago_make_serdes_broadcast_addr(avago_make_addr3(chip,0,0));
        printf("Uploading spico code to %s SerDes.\n", device_name);
        avago_spico_upload_file(aapl, broadcast_addr, TRUE, serdes_filename);
    }
    else if( sbm_filename )
    {
        uint sbm_addr = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
        printf("Uploading spico code to the %s SBus Master.\n", device_name);
        avago_spico_upload_file(aapl, sbm_addr, TRUE, sbm_filename);
    }

    if( do_mode )
    {
        printf("Stating device into %s mode with divider ratio %d.\n", aapl_avsp_mode_to_str(mode), divider);
        avsp_state_device_from_defaults(aapl, chip, mode, divider);
    }
    else if( do_reset )
    {
        printf("Resetting control logic for current mode.\n");
        avsp_control_logic_reset(aapl, chip);
    }
    else if( do_reset_host_to_mod )
    {
        printf("Resetting control logic for current mode.\n");
        avsp_control_logic_reset_host_to_mod(aapl, chip, 0x3ff);
    }
    else if( do_reset_mod_to_host )
    {
        printf("Resetting control logic for current mode.\n");
        avsp_control_logic_reset_mod_to_host(aapl, chip, 0x3ff);
    }
    else if( do_direct_mode )
    {
        /* State device by directly writing to device: */
        Avsp_state_t state;
        printf("Directly stating device into %s mode with divider ratio %d.\n", aapl_avsp_mode_to_str(mode), divider);
        avsp_state_init(aapl, chip, NULL, mode, &state);
        avsp_state_set_divider(aapl, &state, divider);
        avsp_state_write_to_device(aapl, &state);
    }
    else if( do_direct_reset )
    {
        printf("Directly resetting control logic into %s mode.\n", aapl_avsp_mode_to_str(mode));
        avsp_control_logic_reset_direct(aapl, chip, mode);
    }
    else if( do_direct_reset_host_to_mod )
    {
        printf("Resetting control logic for current mode.\n");
        avsp_control_logic_reset_host_to_mod_direct(aapl, chip, mode, 0x3ff);
    }
    else if( do_direct_reset_mod_to_host )
    {
        printf("Resetting control logic for current mode.\n");
        avsp_control_logic_reset_mod_to_host_direct(aapl, chip, mode, 0x3ff);
    }

    if( batch_tune_host || batch_tune_mod )
    {
        Avago_serdes_dfe_state_t *dfe = avago_serdes_dfe_state_construct(aapl);
        Avsp_mode_t mode = avsp_1104_get_mode(aapl, chip); /* Get current mode. */
        BOOL batch_tune_mod4 = batch_tune_mod && mode == AVSP_GEARBOX_10_4;
        Avsp_addr_list_t list = AVSP_MODX;
        const char *which = (batch_tune_host && batch_tune_mod) ? "all active" : batch_tune_host ? "host" : "mod";

        dfe->tune_mode = tune_mode;
        /* Note: "ALL" here is host and mod4 slices if in Gearbox mode: */
        printf("Performing %s tuning on %s slices.\n", aapl_dfe_tune_mode_to_str(dfe->tune_mode), which);

        if(      batch_tune_host && batch_tune_mod4 ) list = AVSP_HOST_MOD4;
        else if( batch_tune_host && batch_tune_mod )  list = AVSP_ALL;
        else if( batch_tune_host )                    list = AVSP_HOST;
        else if( batch_tune_mod4 )                    list = AVSP_MOD4;
        else if( batch_tune_mod )                     list = AVSP_MOD;
        avsp_batch_tune(aapl, chip, list, dfe, 500, 400, 10000);

        avago_serdes_dfe_state_destruct(aapl, dfe);

        if( do_direct_mode )
        {
            printf("Performing Tx Phase Cal on %s slices.\n", which);
            phase_cal_serdes(aapl, chip, list);
            printf("Resetting control logic.\n");
            avsp_control_logic_reset_direct(aapl, chip, mode);
        }
    }

    /* Cleanup and exit: */
    retval = aapl->return_code != 0;
    if( retval )
        printf("ERROR in operation.\n");
    return retval;
}

#endif /* AAPL_ENABLE_AVSP_1104 */

#if AAPL_ENABLE_AVSP_9104

static int show_avsp_9104_help()
{
    aapl_common_main_help(FALSE);
printf(
"-chip <chip_number>    The chip number to access; range [0-15]; default = 0.\n"
"-halve                 Halve REFCLK frequency within the clock pad.\n"
"-serdes-upload <file>  Upload SerDes firmware file.\n"
"-sbm-upload    <file>  Upload SBus Master firmware file.\n"
"\n"
);

printf(
"-mode  <RPT|PMA|RS_FEC|MLG> <div> Configure mode and divider using SBus Master.\n"
"-reset                         Reset the core control logic using SBus Master.\n"
"-reset-host-to-mod             Reset half the control logic using SBus Master.\n"
"-reset-mod-to-host             Reset half the control logic using SBus Master.\n"
);
printf(
"-direct-mode <RPT|PMA> <div>          Same actions as previous 4 options\n"
"-direct-reset <RPT|PMA>                except do action directly\n"
"-direct-reset-host-to-mod <RPT|PMA>    rather than using the\n"
"-direct-reset-mod-to-host <RPT|PMA>    SBus Master processor.\n"
);

printf(
"\n"
"-fec-disable              Don't use FEC.\n"
"-fec-disable-mod          Disable mod Tx during RS FEC setup.\n"
"-fec-disable-host         Disable host Tx during RS FEC setup.\n"
"-fec-run-an-before-fec    Run auto-negotiation before RS FEC setup.\n"
"-fec-run-an-after-fec     Run auto-negotiation after RS FEC setup.\n"
"-fec-run-kr-after-an      Run kr after auto-negotiation.\n"
"-fec-enable-workaround    Enable 9104 r2 BIP error workaround.\n"
"-fec-extra-opts <int>     Set additional flags in SBM call.\n"
);

printf(
"\n"
"-batch-tune               Tune all slices.\n"
"-host-batch-tune          Tune host slices.\n"
"-mod-batch-tune           Tune mod slices.\n"
"-tune-mode <ICAL|PCAL>    DFE tune mode to use; default = iCal.\n"
"-tune-timeout <ms_max>    Set batch tune timeout value.\n"
);

printf(
"-errors                   Retrieve RS FEC error counts.\n"
);

#if AAPL_ENABLE_AVSP_AUTO_NEG
printf(
"\n"
"-an-enable              Enable Auto NEgotiation.\n"
"-host-mask              slices on host side will AN.\n"
"-mod-mask               sloces on mod side will AN.\n"
"-an-speed               speed at which AN will occur.\n"
"-an-side                host side or mod side.\n"
);
printf(
"-rx-clk                 Use the ref_clk, instead of the RX recovered clock.\n"
"-n-ports                number of ports plugged into AASP.\n"
"-cap-in                 capability list.\n"
"-user-cap               user's capability list.\n"
"-kr-training-disable    disable KR training after AN.\n"
"-enable-symmetric       enable symmetric KR training.\n"
);
#endif

    return 1;
}

int aapl_avsp_9104_main(int argc, char *argv[], Aapl_t *aapl)
{
    int retval = 0;

/* Parse options: */
    uint        chip        = 0;
    int         rc, index   = 0;
    const char *serdes_filename = 0;
    const char *sbm_filename = 0;
    Avsp_mode_t mode        = AVSP_RPT;
    BOOL do_mode            = FALSE;
    BOOL do_reset           = FALSE;
    BOOL do_reset_host_to_mod = FALSE;
    BOOL do_reset_mod_to_host = FALSE;
    BOOL do_direct_mode     = FALSE;
    BOOL do_direct_reset    = FALSE;
    BOOL do_direct_reset_host_to_mod = FALSE;
    BOOL do_direct_reset_mod_to_host = FALSE;
    BOOL halve              = FALSE;
    BOOL batch_tune_host    = FALSE;
    BOOL batch_tune_mod     = FALSE;
    Avago_serdes_dfe_tune_mode_t tune_mode = AVAGO_DFE_ICAL;
    int tune_timeout = 10000;   /* default */
    int divider = 0;
    int actions = 0;
    BOOL errors             = FALSE;
    BOOL an_enable            = FALSE;
    const char *device_name = 0;
    Avsp_state_options_t state_options;

#if AAPL_ENABLE_AVSP_AUTO_NEG
    Avsp_an_config_t *config = avsp_an_config_construct(aapl);
#endif

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,

        {"serdes-upload",    1, NULL, 10 },  /* Upload <file name> to SerDes. */
        {"sbm-upload",       1, NULL, 11 },  /* Upload <file name> to SBM. */
        {"halve",            0, NULL, 12 },  /* Halve the ref clock */

        {"batch-tune",       0, NULL, 15 },  /* Tune all */
        {"host-batch-tune",  0, NULL, 16 },  /* Tune host Rx */
        {"mod-batch-tune",   0, NULL, 17 },  /* Tune mod Rx */
        {"tune-mode",        1, NULL, 18 },  /* Set tune mode */
        {"tune-timeout",     1, NULL, 19 },  /* Set tune timeout */

        {"mode",             1, NULL, 20 },  /* Mode and hostside divider value. */
        {"reset",            0, NULL, 21 },  /* Use SBM */
        {"reset-host-to-mod",0, NULL, 22 },  /* Use SBM */
        {"reset-mod-to-host",0, NULL, 23 },  /* Use SBM */
        {"direct-mode",      1, NULL, 30 },  /* Mode and div; operate directly */
        {"direct-reset",     1, NULL, 31 },  /* Mode; operate directly */
        {"direct-reset-host-to-mod",1, NULL, 32 },  /* Mode; operate directly */
        {"direct-reset-mod-to-host",1, NULL, 33 },  /* Mode; operate directly */

        {"fec-disable-mod",        0, NULL, 1 },
        {"fec-disable-host",       0, NULL, 2 },
        {"fec-run-an-before-fec",  0, NULL, 3 },
        {"fec-run-an-after-fec",   0, NULL, 4 },
        {"fec-run-kr-after-an",    0, NULL, 5 },
        {"fec-enable-workaround",  0, NULL, 6 },
        {"fec-disable",            0, NULL, 7 },
        {"fec-extra-opts <int>",   1, NULL, 8 },

        {"chip",             1, NULL, 'c'},  /* <chip number> for device selection. */
        {"errors",           0, NULL, 'r'},  /* retrieve FEC errors for 9104 */

#if AAPL_ENABLE_AVSP_AUTO_NEG
        {"an-enable",                  0, NULL, 34},  /* Enable Auto Negotiation */
        {"host-mask",                  1, NULL, 35},  /* Enable Auto Negotiation */
        {"mod-mask",                   1, NULL, 36},  /* Enable Auto Negotiation */
        {"an-speed",                   1, NULL, 37},  /* Enable Auto Negotiation */
        {"an-side",                    1, NULL, 38},  /* Enable Auto Negotiation */
        {"rx-clk",                     1, NULL,  9},  /* Enable Auto Negotiation */
        {"n-ports",                    1, NULL, 40},  /* Enable Auto Negotiation */
        {"cap-in",                     1, NULL, 41},  /* Enable Auto Negotiation */
        {"user-cap",                   1, NULL, 42},  /* Enable Auto Negotiation */
        {"kr-training-disable",        1, NULL, 43},  /* Enable Auto Negotiation */
        {"enable-symmetric",           1, NULL, 44},  /* Enable Auto Negotiation */
#endif

        {NULL,               0, NULL, 0  },  /* sentinel entry. */
    };

    if( aapl_common_main_options(aapl, argc, argv, 0) < 0 )
        return show_avsp_9104_help();

    if( aapl->return_code < 0 ) AAPL_EXIT(1);  /* assume anomalies already reported. */

    avsp_state_options_init(aapl, &state_options); /* Set up defaults */

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch( rc )
        {
        case 'c': chip   = aapl_num_from_str(optarg, name, 0); break;

        case  1 : state_options.disable_mod_during_fec_setup    = TRUE; break;
        case  2 : state_options.disable_host_during_fec_setup   = TRUE; break;
        case  3 : state_options.run_an_before_fec_setup         = TRUE; break;
        case  4 : state_options.run_an_after_fec_setup          = TRUE; break;
        case  5 : state_options.run_kr_after_an                 = TRUE; break;
        case  6 : state_options.enable_fec_bip_error_workaround = TRUE; break;
        case  7 : state_options.disable_fec                     = TRUE; break;
        case  8 : state_options.extra_opts = aapl_num_from_str(optarg, name, 0); break;

        case 10 : serdes_filename = optarg; break;
        case 11 : sbm_filename    = optarg; break;
        case 12 : halve = TRUE; break;

        case 15 : batch_tune_host = batch_tune_mod = TRUE; break;
        case 16 : batch_tune_host = TRUE; break;
        case 17 : batch_tune_mod  = TRUE; break;
        case 18 : tune_mode       = aapl_dfe_tune_mode_from_str(optarg, name); break;
        case 19 : tune_timeout    = aapl_num_from_str(optarg, name, 0); break;

        case 20 : do_mode         = TRUE; mode = aapl_avsp_mode_from_str(optarg, name); actions++; break;
        case 21 : do_reset        = TRUE;                                               actions++; break;
        case 22 : do_reset_host_to_mod = TRUE;                                          actions++; break;
        case 23 : do_reset_mod_to_host = TRUE;                                          actions++; break;
        case 30 : do_direct_mode  = TRUE; mode = aapl_avsp_mode_from_str(optarg, name); actions++; break;
        case 31 : do_direct_reset = TRUE; mode = aapl_avsp_mode_from_str(optarg, name); actions++; break;
        case 32 : do_direct_reset_host_to_mod = TRUE;
                  mode = aapl_avsp_mode_from_str(optarg, name);                         actions++; break;
        case 33 : do_direct_reset_mod_to_host = TRUE;
                  mode = aapl_avsp_mode_from_str(optarg, name);                         actions++; break;

        case 'r': errors          = TRUE; break;

#if AAPL_ENABLE_AVSP_AUTO_NEG
        case 34: an_enable                       = TRUE; break;
        case 35: config->host_mask               = aapl_num_from_str(optarg, name, 0); break;
        case 36: config->mod_mask                = aapl_num_from_str(optarg, name, 0); break;
        case 37: config->an_speed                = aapl_num_from_str(optarg, name, 0); break;
        case 38: config->an_side                 = aapl_num_from_str(optarg, name, 0); break;
        case  9: config->rx_clk                  = aapl_num_from_str(optarg, name, 0); break;
        case 40: config->n_ports                 = aapl_num_from_str(optarg, name, 0); break;
        case 41: config->cap_in                  = aapl_num_from_str(optarg, name, 0); break;
        case 42: config->user_cap                = aapl_num_from_str(optarg, name, 0); break;
        case 43: config->kr_training_disable     = aapl_num_from_str(optarg, name, 0); break;
        case 44: config->enable_symmetric        = aapl_num_from_str(optarg, name, 0); break;
#endif

        case '?':
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    if( !serdes_filename && !sbm_filename && actions == 0 && !batch_tune_host && !batch_tune_mod && !errors && !an_enable)
        return show_avsp_9104_help();

    if( halve && (!serdes_filename || !sbm_filename) )
        aapl_main_error("The halve option requires SerDes and SBus master firmware.\n");

    if( actions > 1 )
        aapl_main_error("Only one of -mode, -reset, -direct-mode and -direct-reset allowed.\n");

    if( do_mode || do_direct_mode )
    {
        if( (argc-optind) != 1 )
            aapl_main_error("The mode command requires a divider parameter.\n");
        divider = aapl_num_from_str(argv[optind++],"mode",0);
        state_options.mode = mode;
        state_options.divider = divider;
    }

    if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
    aapl_get_ip_info(aapl,0);
    device_name = aapl_get_chip_name(aapl, avago_make_addr3(chip,0,0));

    if( serdes_filename && sbm_filename )
    {
        printf("Uploading firmware files to %s device %u.\n", device_name, chip);
        avsp_upload_firmware_file(aapl, chip, halve, serdes_filename, sbm_filename);
    }
    else if( serdes_filename )
    {
        uint broadcast_addr = avago_make_serdes_broadcast_addr(avago_make_addr3(chip,0,0));
        printf("Uploading spico code to %s SerDes.\n", device_name);
        avago_spico_upload_file(aapl, broadcast_addr, TRUE, serdes_filename);
    }
    else if( sbm_filename )
    {
        uint sbm_addr = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
        printf("Uploading spico code to the %s SBus Master.\n", device_name);
        avago_spico_upload_file(aapl, sbm_addr, TRUE, sbm_filename);
    }

#if AAPL_ENABLE_AVSP_AUTO_NEG
    if( an_enable )
        avsp_an_start(aapl,chip,config);

    avsp_an_config_destruct(aapl,config);
#endif

    if( do_mode )
    {
        printf("Stating device into %s mode with divider ratio %d.\n", aapl_avsp_mode_to_str(mode), divider);
        avsp_state_device_with_options(aapl, chip, &state_options);
    }
    else if( do_reset )
    {
        printf("Resetting control logic for current mode.\n");
        avsp_control_logic_reset(aapl, chip);
    }
    else if( do_reset_host_to_mod )
    {
        printf("Resetting control logic for current mode.\n");
        avsp_control_logic_reset_host_to_mod(aapl, chip, 0x3ff);
    }
    else if( do_reset_mod_to_host )
    {
        printf("Resetting control logic for current mode.\n");
        avsp_control_logic_reset_mod_to_host(aapl, chip, 0x3ff);
    }
    else if( do_direct_mode )
    {
        /* State device by directly writing to device: */
        Avsp_state_t state;
        printf("Directly stating device into %s mode with divider ratio %d.\n", aapl_avsp_mode_to_str(mode), divider);
        avsp_state_init(aapl, chip, NULL, mode, &state);
        avsp_state_set_divider(aapl, &state, divider);
        avsp_state_write_to_device(aapl, &state);
    }
    else if( do_direct_reset )
    {
        printf("Directly resetting control logic into %s mode.\n", aapl_avsp_mode_to_str(mode));
        avsp_control_logic_reset_direct(aapl, chip, mode);
    }
    else if( do_direct_reset_host_to_mod )
    {
        printf("Resetting control logic for current mode.\n");
        avsp_control_logic_reset_host_to_mod_direct(aapl, chip, mode, 0x3ff);
    }
    else if( do_direct_reset_mod_to_host )
    {
        printf("Resetting control logic for current mode.\n");
        avsp_control_logic_reset_mod_to_host_direct(aapl, chip, mode, 0x3ff);
    }

    if( batch_tune_host || batch_tune_mod )
    {
        Avago_serdes_dfe_state_t *dfe = avago_serdes_dfe_state_construct(aapl);
        Avsp_mode_t mode = avsp_1104_get_mode(aapl, chip); /* Get current mode. */
        BOOL batch_tune_mod4 = batch_tune_mod && mode == AVSP_GEARBOX_10_4;
        Avsp_addr_list_t list = AVSP_MODX;
        const char *which = (batch_tune_host && batch_tune_mod) ? "all active" : batch_tune_host ? "host" : "mod";

        dfe->tune_mode = tune_mode;
        /* Note: "ALL" here is host and mod4 slices if in Gearbox mode: */
        printf("Performing %s tuning on %s slices.\n", aapl_dfe_tune_mode_to_str(dfe->tune_mode), which);

        if(      batch_tune_host && batch_tune_mod4 ) list = AVSP_HOST_MOD4;
        else if( batch_tune_host && batch_tune_mod )  list = AVSP_ALL;
        else if( batch_tune_host )                    list = AVSP_HOST;
        else if( batch_tune_mod4 )                    list = AVSP_MOD4;
        else if( batch_tune_mod )                     list = AVSP_MOD;
        avsp_batch_tune(aapl, chip, list, dfe, 500, 400, tune_timeout);

        avago_serdes_dfe_state_destruct(aapl, dfe);

        if( do_direct_mode )
        {
            printf("Performing Tx Phase Cal on %s slices.\n", which);
            phase_cal_serdes(aapl, chip, list);
            printf("Resetting control logic.\n");
            avsp_control_logic_reset_direct(aapl, chip, mode);
        }
    }

    if (errors)
    {
        aapl->verbose += 1;
        avsp_9104_get_status(aapl, chip, AVSP_ALL_ERRORS, 0, 0);
        aapl->verbose -= 1;
    }


    /* Cleanup and exit: */
    retval = aapl->return_code != 0;
    if( retval )
        printf("ERROR in operation.\n");
    return retval;
}

#endif /* AAPL_ENABLE_AVSP_9104 */

/*////////////////////////////////////////////////////////////////////////// */

#if AAPL_ENABLE_AVSP_4412 || AAPL_ENABLE_AVSP_8801

static int show_avsp_retimer_help()
{
    aapl_common_main_help(FALSE);
printf(
"-chip <chip_number>    The chip number to access; range [0-15]; default = 0.\n"
"-halve                 Halve REFCLK frequency within the clock pad.\n"
"-serdes-upload <file>  Upload SerDes firmware file.\n"
"-sbm-upload    <file>  Upload SBus Master firmware file.\n"
"\n"
);

printf(
"-divider  <div>        Configure retimer using SBus Master.\n"
"-direct-divider <div>  Directly configure retimer.\n"
);

printf(
"\n"
"-batch-tune                    Tune all slices.\n"
"-host-batch-tune               Tune host slices.\n"
"-mod-batch-tune                Tune mod slices.\n"
"-tune-mode <ICAL|PCAL>         DFE tune mode to use; default = iCal.\n"
);

#if AAPL_ENABLE_AVSP_KR_TRAINING
printf(
"\n"
"-kr-enable             Enable KR Training.\n"
"-kr-status             Report current kr status.\n"
"-channel               Channels to perform KR Training.\n"
"-report-kr-failure     Report KR training failure.\n"
"-report-frame-lock     Report frame lock failure.\n"
"-report-signal-detect  Report signal detect failure.\n"
"-enable-symmetric      Force KR training to be symmetric.\n"
);
#endif

    return 1;
}

int aapl_avsp_retimer_main(int argc, char *argv[], Aapl_t *aapl)
{
    int retval = 0;
    Avsp_mode_t mode    = AVSP_REPEATER_DUPLEX;

/* Parse options: */
    uint        chip        = 0;
    int         rc, index   = 0;
    const char *serdes_filename = 0;
    const char *sbm_filename = 0;
    BOOL halve             = FALSE;
    BOOL direct            = FALSE;
    BOOL kr_enable         = FALSE;
    BOOL kr_status         = FALSE;
#if AAPL_ENABLE_AVSP_KR_TRAINING
    BOOL report_kr_failure = FALSE;
    BOOL report_frame_lock = FALSE;
    BOOL report_sig_detect = FALSE;
    BOOL enable_symmetric  = FALSE;
    uint channels          = 0x000F;
#endif
    BOOL batch_tune_host    = FALSE;
    BOOL batch_tune_mod     = FALSE;
    Avago_serdes_dfe_tune_mode_t tune_mode = AVAGO_DFE_ICAL;

    int divider = -1;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,

        {"serdes-upload",    1, NULL, 10 },  /* Upload <file name> to SerDes. */
        {"sbm-upload",       1, NULL, 11 },  /* Upload <file name> to SBM. */
        {"halve",            0, NULL, 12 },  /* Halve the ref clock */

        {"batch-tune",       0, NULL, 15 },  /* Tune all */
        {"host-batch-tune",  0, NULL, 16 },  /* Tune host Rx */
        {"mod-batch-tune",   0, NULL, 17 },  /* Tune mod Rx */
        {"tune-mode",        1, NULL, 18 },  /* Set tune mode */

        {"divider",          1, NULL, 20 },  /* <divider> to set. */
        {"direct-divider",   1, NULL, 21 },  /* <divider> to set. */

        {"chip",             1, NULL, 'c'},  /* <chip number> for device selection. */

#if AAPL_ENABLE_AVSP_KR_TRAINING
        {"kr-enable",        0, NULL, 'K'}, /* Enable KR Training */
        {"kr-status",        0, NULL, 't'}, /* Enable KR Training */
        {"channel",          1, NULL, 'C'}, /* Enable KR Training */
        {"report-kr-failure",     0, NULL, 'F'}, /* Enable KR Training */
        {"report-frame-lock",     0, NULL, 'L'}, /* Enable KR Training */
        {"report-signal-detect",  0, NULL, 'P'}, /* Enable KR Training */
        {"enable-symmetric",      0, NULL, 'y'}, /* Enable KR Training */
#endif
        {NULL,               0, NULL, 0  },  /* sentinel entry. */
    };

    if( aapl_common_main_options(aapl, argc, argv, 0) < 0 )
        return show_avsp_retimer_help();

    if( aapl->return_code < 0 ) AAPL_EXIT(1);  /* assume anomalies already reported. */

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch( rc )
        {
        case 'c': chip   = aapl_num_from_str(optarg, name, 0); break;

        case 10 : serdes_filename = optarg; break;
        case 11 : sbm_filename    = optarg; break;
        case 12 : halve = TRUE; break;

        case 15 : batch_tune_host = batch_tune_mod = TRUE; break;
        case 16 : batch_tune_host = TRUE; break;
        case 17 : batch_tune_mod  = TRUE; break;
        case 18 : tune_mode       = aapl_dfe_tune_mode_from_str(optarg, name); break;

        case 20 : divider = aapl_num_from_str(optarg, name, 0); break;
        case 21 : divider = aapl_num_from_str(optarg, name, 0); direct = TRUE; break;

#if AAPL_ENABLE_AVSP_KR_TRAINING
        case 'K': kr_enable = TRUE; break;
        case 'F': report_kr_failure = TRUE; break;
        case 'L': report_frame_lock = TRUE; break;
        case 'P': report_sig_detect = TRUE; break;
        case 'C': channels = aapl_num_from_str(optarg,name,16); break;
        case 'y': enable_symmetric = TRUE; break;
        case 't': kr_status = TRUE; break;
#endif

        case '?':
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    if( !serdes_filename && !sbm_filename && divider <= 0 && !kr_enable && !kr_status && !batch_tune_host && !batch_tune_mod )
        return show_avsp_retimer_help();

    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
    aapl_get_ip_info(aapl,0);

    if( serdes_filename && sbm_filename )
    {
        printf("Uploading and initializing retimer...\n");
        avsp_upload_firmware_file(aapl, chip, halve, serdes_filename, sbm_filename);
    }
    else if( serdes_filename )
    {
        uint broadcast_addr = avago_make_serdes_broadcast_addr(avago_make_addr3(chip,0,0));
        printf("Uploading spico code to the retimer SerDes.\n");
        avago_spico_upload_file(aapl, broadcast_addr, TRUE, serdes_filename);
    }
    else if( sbm_filename )
    {
        uint sbm_addr = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
        printf("Uploading spico code to the retimer SBus Master.\n");
        avago_spico_upload_file(aapl, sbm_addr, TRUE, sbm_filename);
    }

    if( divider > 0 && !direct )
    {
        printf("Stating retimer with divider ratio %d.\n", divider);
        avsp_state_device_from_defaults(aapl, chip, mode, divider);
    }
    if( divider > 0 && direct )
    {
        /* State device by directly writing to device: */
        Avsp_state_t state;
        printf("Directly stating retimer with divider ratio %d.\n", divider);
        avsp_state_init(aapl, chip, NULL, mode, &state);
        avsp_state_set_divider(aapl, &state, divider);
        avsp_state_write_to_device(aapl, &state);
    }

#if AAPL_ENABLE_AVSP_KR_TRAINING
    if(kr_enable)
    {
        /*uint kr_temp; */
        Avago_kr_config_t *config = avago_kr_config_construct(aapl);
        config->channels = channels;
        config->enable_symmetric = enable_symmetric;
        config->report_kr_failure = report_kr_failure;
        config->report_frame_lock = report_frame_lock;
        config->report_signal_detect = report_sig_detect;
        avsp_kr_enable(aapl, chip, config);
        /*printf("KR Return Value: %x\n", kr_temp); */
        avago_kr_config_destruct(aapl, config);
    }

    if(kr_status)
    {
        uint kr_temp;
        Avago_kr_config_t *config = avago_kr_config_construct(aapl);
        config->report_kr_failure = report_kr_failure;
        config->report_frame_lock = report_frame_lock;
        config->report_signal_detect = report_sig_detect;
        kr_temp = avsp_kr_status(aapl, chip, config);
        printf("KR Return Value: %x\n", kr_temp);
        avago_kr_config_destruct(aapl, config);
    }
#endif

    if( batch_tune_host || batch_tune_mod )
    {
        Avago_serdes_dfe_state_t *dfe = avago_serdes_dfe_state_construct(aapl);
        dfe->tune_mode = tune_mode;
        printf("Performing %s tuning on %s slices.\n", aapl_dfe_tune_mode_to_str(dfe->tune_mode),
                (batch_tune_host && batch_tune_mod) ? "all" : batch_tune_host ? "host" : "mod");

        if( batch_tune_host && batch_tune_mod ) avsp_batch_tune(aapl, chip, AVSP_ALL , dfe, 500, 400, 10000);
        else if( batch_tune_host )              avsp_batch_tune(aapl, chip, AVSP_HOST, dfe, 500, 400, 10000);
        else if( batch_tune_mod )               avsp_batch_tune(aapl, chip, AVSP_MOD , dfe, 500, 400, 10000);

        avago_serdes_dfe_state_destruct(aapl, dfe);
    }

    /* Cleanup and exit: */
    retval = aapl->return_code != 0;
    if( retval )
        printf("ERROR\n");
    return retval;
}

#endif /* AAPL_ENABLE_AVSP_4412 || AAPL_ENABLE_AVSP_8801 */


#if AAPL_ENABLE_AVSP_7412

static int show_avsp_7412_help()
{
    aapl_common_main_help(FALSE);
printf(
"-chip <chip_number>    The chip number to access; range [0-15]; default = 0.\n"
/* "-halve                 Halve REFCLK frequency within the clock pad.\n" */
"-serdes-upload <file>  Upload SerDes firmware file.\n"
"-sbm-upload    <file>  Upload SBus Master firmware file.\n"
"\n"
);

printf(
"-direct-mode <RPT|PMA|FEC> <div>       Directly configure device in given mode\n"
"-mode  <RPT|PMA|RS_FEC|> <div>         Configure mode and divider using SBus Master.\n"
);
printf(
"\n"
"-batch-tune                    Tune all slices.\n"
"-host-batch-tune               Tune host slices.\n"
"-mod-batch-tune                Tune mod slices.\n"
"-tune-mode <ICAL|PCAL>         DFE tune mode to use; default = iCal.\n"
);

    return 1;
}
int aapl_avsp_7412_main(int argc, char *argv[], Aapl_t *aapl)
{
    int retval = 0;

/* Parse options: */
    uint        chip        = 0;
    int         rc, index   = 0;
    const char *serdes_filename = 0;
    const char *sbm_filename = 0;
    Avsp_mode_t mode        = AVSP_RPT;
    BOOL do_mode            = FALSE;
    BOOL do_direct_mode     = FALSE;
    BOOL halve              = FALSE;
    BOOL batch_tune_host    = FALSE;
    BOOL batch_tune_mod     = FALSE;
    Avago_serdes_dfe_tune_mode_t tune_mode = AVAGO_DFE_ICAL;
    int divider = 0;
    int actions = 0;
    BOOL errors             = FALSE;
    const char *device_name = 0;
    Avsp_state_options_t state_options;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,

        {"serdes-upload",    1, NULL, 10 },  /* Upload <file name> to SerDes. */
        {"sbm-upload",       1, NULL, 11 },  /* Upload <file name> to SBM. */
        {"halve",            0, NULL, 12 },  /* Halve the ref clock */

        {"batch-tune",       0, NULL, 15 },  /* Tune all */
        {"host-batch-tune",  0, NULL, 16 },  /* Tune host Rx */
        {"mod-batch-tune",   0, NULL, 17 },  /* Tune mod Rx */
        {"tune-mode",        1, NULL, 18 },  /* Set tune mode */

        {"mode",             1, NULL, 20 },  /* Mode and hostside divider value. */
        {"reset",            0, NULL, 21 },  /* Use SBM */
        {"direct-mode",      1, NULL, 30 },  /* Mode and div; operate directly */

        {"chip",             1, NULL, 'c'},  /* <chip number> for device selection. */
        {"errors",           0, NULL, 'r'},  /* retrieve FEC errors for 7412 */
        {NULL,               0, NULL, 0  },  /* sentinel entry. */
    };

    if( aapl_common_main_options(aapl, argc, argv, 0) < 0 )
        return show_avsp_7412_help();

    if( aapl->return_code < 0 ) AAPL_EXIT(1);  /* assume anomalies already reported. */

    avsp_state_options_init(aapl, &state_options); /* Set up defaults */

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch( rc )
        {
        case 'c': chip   = aapl_num_from_str(optarg, name, 0); break;

        case 10 : serdes_filename = optarg; break;
        case 11 : sbm_filename    = optarg; break;
        case 12 : halve = TRUE; break;

        case 15 : batch_tune_host = batch_tune_mod = TRUE; break;
        case 16 : batch_tune_host = TRUE; break;
        case 17 : batch_tune_mod  = TRUE; break;
        case 18 : tune_mode       = aapl_dfe_tune_mode_from_str(optarg, name); break;

        case 20 : do_mode         = TRUE; mode = aapl_avsp_mode_from_str(optarg, name); actions++; break;
        case 30 : do_direct_mode  = TRUE; mode = aapl_avsp_mode_from_str(optarg, name); actions++; break;

        case '?':
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }
    if( !serdes_filename && !sbm_filename && actions == 0 && !batch_tune_host && !batch_tune_mod && !errors)
        return show_avsp_7412_help();

    if( halve && (!serdes_filename || !sbm_filename) )
        aapl_main_error("The halve option requires SerDes and SBus master firmware.\n");
    if( actions > 1 )
        aapl_main_error("Only one of -mode, -reset, -direct-mode and -direct-reset allowed.\n");

    if( do_mode || do_direct_mode )
    {
        if( (argc-optind) != 1 )
            aapl_main_error("The mode command requires a divider parameter.\n");
        divider = aapl_num_from_str(argv[optind++],"mode",0);
        state_options.mode = mode;
        state_options.divider = divider;
    }

    if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
    aapl_get_ip_info(aapl,0);
    device_name = aapl_get_chip_name(aapl, avago_make_addr3(chip,0,0));

    if( serdes_filename && sbm_filename )
    {
        printf("Uploading firmware files to %s device %u.\n", device_name, chip);
        avsp_upload_firmware_file(aapl, chip, halve, serdes_filename, sbm_filename);
    }
    else if( serdes_filename )
    {
        uint broadcast_addr = avago_make_serdes_broadcast_addr(avago_make_addr3(chip,0,0));
        printf("Uploading spico code to %s SerDes.\n", device_name);
        avago_spico_upload_file(aapl, broadcast_addr, TRUE, serdes_filename);
     }
    else if( sbm_filename )
    {
        uint sbm_addr = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
        printf("Uploading spico code to the %s SBus Master.\n", device_name);
        avago_spico_upload_file(aapl, sbm_addr, TRUE, sbm_filename);
    }

    if( do_mode )
    {
        printf("Stating device into %s mode with divider ratio %d.\n", aapl_avsp_mode_to_str(mode), divider);
        avsp_state_device_with_options(aapl, chip, &state_options);
    }
    else if( do_direct_mode )
    {
        /* State device by directly writing to device: */
        Avsp_state_t state;
        printf("Directly stating device into %s mode with divider ratio %d.\n", aapl_avsp_mode_to_str(mode), divider);
        avsp_state_init(aapl, chip, NULL, mode, &state);
        avsp_state_set_divider(aapl, &state, divider);
        avsp_state_write_to_device(aapl, &state);
    }
    if( batch_tune_host || batch_tune_mod )
    {
        Avago_serdes_dfe_state_t *dfe = avago_serdes_dfe_state_construct(aapl);
        Avsp_addr_list_t list = AVSP_MODX;
        const char *which = (batch_tune_host && batch_tune_mod) ? "all active" : batch_tune_host ? "host" : "mod";

        dfe->tune_mode = tune_mode;
        /* Note: "ALL" here is host and mod4 slices if in Gearbox mode: */
        printf("Performing %s tuning on %s slices.\n", aapl_dfe_tune_mode_to_str(dfe->tune_mode), which);

        if( batch_tune_host && batch_tune_mod )  list = AVSP_ALL;
        else if( batch_tune_host )                    list = AVSP_HOST;
        else if( batch_tune_mod )                     list = AVSP_MOD;
        avsp_batch_tune(aapl, chip, list, dfe, 500, 400, 10000);

        avago_serdes_dfe_state_destruct(aapl, dfe);

        if( do_direct_mode )
        {
            printf("Performing Tx Phase Cal on %s slices.\n", which);
            phase_cal_serdes(aapl, chip, list);
        }
    }

    if (errors)
    {
    }

 /* Cleanup and exit: */
    retval = aapl->return_code != 0;
    if( retval )
        printf("ERROR in operation.\n");
    return retval;
}
#endif /* AAPL_ENABLE_AVSP_7412 */

#if AAPL_ENABLE_AVSP_5410

static int show_avsp_5410_help()
{
    aapl_common_main_help(FALSE);
printf(
"-chip <chip_number>    The chip number to access; range [0-15]; default = 0.\n"
"-halve                 Halve REFCLK frequency within the clock pad.\n"
"-serdes-upload <file>  Upload SerDes firmware file.\n"
"-sbm-upload    <file>  Upload SBus Master firmware file.\n"
"\n"
);

printf(
"-direct-mode <RPT|PMA|FEC> <div>       Directly configure device in given mode\n"
"-mode  <RPT|PMA|RS_FEC|> <div>         Configure mode and divider using SBus Master.\n"
);
printf(
"-direct-reset <direction>              Reset the core control logic writing registers directly.\n"
"                                       Example: -direct-reset host_to_mod\n"
"                                       where host_to_mod =  host to mod direction \n"
"                                       mod_to_host = mod to host direction and \n"
"                                       both = host_to_mod and mod_to_host\n"
);
printf(
"-bring-up <dir>         Perform SerdDes cal, [DFE tuning]\n"
"                        where host = bring up host mod path, mod = mod host path \n"
"                        both = host-mod and mod-host path.\n"
"                        Example: -bring-up host\n"
);

#if AAPL_ENABLE_AVSP_KR_TRAINING
printf(
"\n"
"-kr-enable              Enable KR Training.\n"
"-kr-status              Report current kr status.\n"
"-channel                Channels to perform KR Training.\n"
"-report-kr-failure      Report KR training failure.\n"
"-report-frame-lock      Report frame lock failure.\n"
"-report-signal-detect   Report signal detect failure.\n"
"-enable-symmetric       Force KR training to be symmetric.\n"
);
#endif
printf(
"\n"
"-batch-tune                    Tune all slices.\n"
"-host-batch-tune               Tune host slices.\n"
"-mod-batch-tune                Tune mod slices.\n"
"-tune-mode <ICAL|PCAL>         DFE tune mode to use; default = iCal.\n"
);

    return 1;
}

int aapl_avsp_5410_main(int argc, char *argv[], Aapl_t *aapl)
{
    int retval = 0;

/* Parse options: */
    uint        chip        = 0;
    int         rc, index   = 0;
    const char *serdes_filename = 0;
    const char *sbm_filename = 0;
    char *data               = 0;
    char *direction          = 0;
    Avsp_mode_t mode        = AVSP_RPT;
    BOOL do_mode            = FALSE;
    BOOL do_direct_mode     = FALSE;
    BOOL halve              = FALSE;
    BOOL batch_tune_host    = FALSE;
    BOOL batch_tune_mod     = FALSE;
    BOOL bring_up          = FALSE;
    BOOL do_direct_reset   = FALSE;
#if AAPL_ENABLE_AVSP_KR_TRAINING
    BOOL kr_enable              = FALSE;
    BOOL kr_status              = FALSE;
    BOOL report_kr_failure = FALSE;
    BOOL report_frame_lock = FALSE;
    BOOL report_sig_detect = FALSE;
    BOOL enable_symmetric  = FALSE;
    uint channels          = 0x000F;
#endif
    Avago_serdes_dfe_tune_mode_t tune_mode = AVAGO_DFE_ICAL;
    int divider = 0;
    int actions = 0;
    BOOL errors             = FALSE;
    const char *device_name = 0;
    Avsp_state_options_t state_options;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,

        {"serdes-upload",    1, NULL, 10 },  /* Upload <file name> to SerDes. */
        {"sbm-upload",       1, NULL, 11 },  /* Upload <file name> to SBM. */
        {"halve",            0, NULL, 12 },  /* Halve the ref clock */

        {"batch-tune",       0, NULL, 15 },  /* Tune all */
        {"host-batch-tune",  0, NULL, 16 },  /* Tune host Rx */
        {"mod-batch-tune",   0, NULL, 17 },  /* Tune mod Rx */
        {"tune-mode",        1, NULL, 18 },  /* Set tune mode */
        {"bring-up",         1, NULL, 19 },  /* do device bring up  */
        {"mode",             1, NULL, 20 },  /* Mode and hostside divider value. */
        {"reset",            0, NULL, 21 },  /* Use SBM */
        {"direct-reset",     1, NULL, 31 },  /* Mode; operate directly */
        {"direct-mode",      1, NULL, 30 },  /* Mode and div; operate directly */

        {"chip",             1, NULL, 'c'},  /* <chip number> for device selection. */
        {"errors",           0, NULL, 'r'},  
#if AAPL_ENABLE_AVSP_KR_TRAINING
        {"kr-enable",        0, NULL, 'K'}, /* Enable KR Training */
        {"kr-status",        0, NULL, 't'}, /* Enable KR Training */
        {"channel",          1, NULL, 'C'}, /* Enable KR Training */
        {"report-kr-failure",     0, NULL, 'F'}, /* Enable KR Training */
        {"report-frame-lock",     0, NULL, 'L'}, /* Enable KR Training */
        {"report-signal-detect",  0, NULL, 'P'}, /* Enable KR Training */
        {"enable-symmetric",      0, NULL, 'y'}, /* Enable KR Training */
#endif
        {NULL,               0, NULL, 0  },  /* sentinel entry. */
    };

    if( aapl_common_main_options(aapl, argc, argv, 0) < 0 )
        return show_avsp_5410_help();

    if( aapl->return_code < 0 ) AAPL_EXIT(1);  /* assume anomalies already reported. */

    avsp_state_options_init(aapl, &state_options); /* Set up defaults */

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch( rc )
        {
        case 'c': chip   = aapl_num_from_str(optarg, name, 0); break;

        case 10 : serdes_filename = optarg; break;
        case 11 : sbm_filename    = optarg; break;
        case 12 : halve = TRUE; break;

        case 15 : batch_tune_host = batch_tune_mod = TRUE; break;
        case 16 : batch_tune_host = TRUE; break;
        case 17 : batch_tune_mod  = TRUE; break;
        case 18 : tune_mode       = aapl_dfe_tune_mode_from_str(optarg, name); break;
        case 19 : bring_up        = TRUE; data =  optarg; actions++; break;

        case 20 : do_mode         = TRUE; mode = aapl_avsp_mode_from_str(optarg, name); actions++; break;
        case 30 : do_direct_mode  = TRUE; mode = aapl_avsp_mode_from_str(optarg, name); actions++; break;
        case 31 : do_direct_reset = TRUE; direction =  optarg; actions++; break;

#if AAPL_ENABLE_AVSP_KR_TRAINING
        case 'K': kr_enable = TRUE; break;
        case 'F': report_kr_failure = TRUE; break;
        case 'L': report_frame_lock = TRUE; break;
        case 'P': report_sig_detect = TRUE; break;
        case 'C': channels = aapl_num_from_str(optarg,name,16); break;
        case 'y': enable_symmetric = TRUE; break;
        case 't': kr_status = TRUE; break;
#endif
        case '?':
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }
    if( !serdes_filename && !sbm_filename && actions == 0 && !batch_tune_host && !batch_tune_mod && !errors
#if AAPL_ENABLE_AVSP_KR_TRAINING
        && !kr_enable && !kr_status
#endif
        )
        return show_avsp_5410_help();

    if( halve && (!serdes_filename || !sbm_filename) )
        aapl_main_error("The halve option requires SerDes and SBus master firmware.\n");

    if( actions > 1 )
        aapl_main_error("Only one of -mode, -reset, -direct-mode and -direct-reset allowed.\n");

    if( do_mode || do_direct_mode )
    {
        if( (argc-optind) != 1 )
            aapl_main_error("The mode command requires a divider parameter.\n");
        divider = aapl_num_from_str(argv[optind++],"mode",0);
        state_options.mode = mode;
        state_options.divider = divider;
    }

    if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
    aapl_get_ip_info(aapl,0);
    device_name = aapl_get_chip_name(aapl, avago_make_addr3(chip,0,0));

    if( serdes_filename && sbm_filename )
    {
        printf("Uploading firmware files to %s device %u.\n", device_name, chip);
        avsp_upload_firmware_file(aapl, chip, halve, serdes_filename, sbm_filename);
    }
    else if( serdes_filename )
    {
        uint broadcast_addr = avago_make_serdes_broadcast_addr(avago_make_addr3(chip,0,0));
        printf("Uploading spico code to %s SerDes.\n", device_name);
        avago_spico_upload_file(aapl, broadcast_addr, TRUE, serdes_filename);
    }
    else if( sbm_filename )
    {
        uint sbm_addr = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
        printf("Uploading spico code to the %s SBus Master.\n", device_name);
        avago_spico_upload_file(aapl, sbm_addr, TRUE, sbm_filename);
    }
#if AAPL_ENABLE_AVSP_KR_TRAINING
    if( kr_enable )
    {
        /*uint kr_temp; */
        Avago_kr_config_t *config = avago_kr_config_construct(aapl);
        config->channels = channels;
        config->enable_symmetric = enable_symmetric;
        config->report_kr_failure = report_kr_failure;
        config->report_frame_lock = report_frame_lock;
        config->report_signal_detect = report_sig_detect;
        avsp_kr_enable(aapl, chip, config);
        /*printf("KR Return Value: %x\n", kr_temp); */
        avago_kr_config_destruct(aapl, config);
    }

    if( kr_status )
    {
        uint kr_temp;
        Avago_kr_config_t *config = avago_kr_config_construct(aapl);
        config->report_kr_failure = report_kr_failure;
        config->report_frame_lock = report_frame_lock;
        config->report_signal_detect = report_sig_detect;
        kr_temp = avsp_kr_status(aapl, chip, config);
        printf("KR Return Value: %x\n", kr_temp);
        avago_kr_config_destruct(aapl, config);
    }
#endif
    if( do_mode )
    {
        printf("Stating device into %s mode with divider ratio %d.\n", aapl_avsp_mode_to_str(mode), divider);
        avsp_state_device_with_options(aapl, chip, &state_options);
    }
    else if( do_direct_mode )
    {
        /* State device by directly writing to device: */
        Avsp_state_t state;
        printf("Directly stating device into %s mode with divider ratio %d.\n", aapl_avsp_mode_to_str(mode), divider);
        avsp_state_init(aapl, chip, NULL, mode, &state);
        avsp_state_set_divider(aapl, &state, divider);
        avsp_state_write_to_device(aapl, &state);
    }
    else if( do_direct_reset )
    {
            printf("Directly resetting control logic in %s direction \n", direction);
            avsp_5410_control_logic_reset_direct(aapl, chip, direction);
    }
    if( batch_tune_host || batch_tune_mod )
    {
        Avago_serdes_dfe_state_t *dfe = avago_serdes_dfe_state_construct(aapl);
        Avsp_addr_list_t list = AVSP_MODX;
        const char *which = (batch_tune_host && batch_tune_mod) ? "all" : batch_tune_host ? "host" : "mod";
        dfe->tune_mode = tune_mode;
        /* Note: "ALL" here is host and mod4 slices if in Gearbox mode: */
        printf("Performing %s tuning on %s slices.\n", aapl_dfe_tune_mode_to_str(dfe->tune_mode), which);

        if( batch_tune_host && batch_tune_mod )  list = AVSP_ALL;
        else if( batch_tune_host )                    list = AVSP_HOST;
        else if( batch_tune_mod )                     list = AVSP_MOD;
        avsp_batch_tune(aapl, chip, list, dfe, 500, 400, 10000);

        avago_serdes_dfe_state_destruct(aapl, dfe);

        if( do_direct_mode )
        {
            printf("Performing Tx Phase Cal on %s slices.\n", which);
            phase_cal_serdes(aapl, chip, list);
        }
    }

    if( bring_up )
    {
        if( strcmp(data,"both")  == 0 )
        {
            avsp_5410_bring_up(aapl, chip, "both");
        }
        else if( strcmp(data,"host")  == 0 )
        {
            avsp_5410_bring_up(aapl, chip, "HOST");
        }
        else if( strcmp(data,"mod")  == 0 )
        {
            avsp_5410_bring_up(aapl, chip, "MOD");
        }

    }
    if (errors)
    {
    }


    /* Cleanup and exit: */
    retval = aapl->return_code != 0;
    if( retval )
        printf("ERROR in operation.\n");
    return retval;
}
#endif /* AAPL_ENABLE_AVSP_5410 */

#if AAPL_ENABLE_AVSP_8812

static int show_avsp_8812_help()
{
    aapl_common_main_help(FALSE);
printf(
"-chip <chip_number>     The chip number to access; range [0-15]; default = 0.\n"
"-halve                  Halve REFCLK frequency within the clock pad.\n"
"-serdes-upload <file>   Upload SerDes firmware file.\n"
"-sbm-upload    <file>   Upload SBus Master firmware file.\n"
"\n"
);

printf(
"-mode                              State device using SBus Master. -half0/-half1, -div0 also required.\n"
"                                   Example: -mode -half0 <mode> -div0 <div>\n"
"                                   -mode -half0 <mode> -half1 <mode> -div0 <div0> -div1 <div0>\n"
"\n"
);

printf(
"-half0 <RPT>                       Select mode for SD_0..3, 8..11. Default: RPT\n"
"-half1 <RPT>                       Select mode for SD_4..7, 9..15. Default: RPT\n"
"-direct-reset <RPT|PMA> <half_sel> Reset the core control logic writing registers directly.\n"
"                                   Example: -direct-reset GEARBOX_2_1 0\n"
"                                   where 0 is the half for which to reset the logic for GEARBOX_2_1 mode.\n"                  
"\n"
);

printf(
"-div0 <div>             Set divider for first half of chip.\n"
"-div1 <div>             Set divider for second half of chip. Default: div0.\n"
"-tune                   Perform tuning during bring-up. Valid with -bring-up.\n"
);

#if AAPL_ENABLE_AVSP_STATE
printf(
"-lanes <lane_no>        mask bits for 8 slices on host and associated mod slices.\n"
"                        Providing one bit for each lane\n"
"                        For example: to change speed of lane 0\n"
"                        lane_no = 0x01 \n"
"-divider <div>          Set divider for the lanes(s) selected\n"
);
#endif /* AAPL_ENABLE_AVSP_STATE */

printf(
"-bring-up <half,dir>    Perform SerdDes cal, [DFE tuning], alignment.\n"
"                        <half,dir> is Comma separated list of parameters where:\n"
"                        half must be followed by direction.\n"
"                        0=half0, 1=half1, slow=slow_path, fast=fast_path\n"
"                        both=slow&fast direction, all=both half and both direction.\n"
"                        Example: -bring-up 0,1,slow\n"
);

printf(
"-channel-align          Align all output channel in Gearbox mode \n"
"-channel-swap <gb>      Swaps the channel specified in <gb> (<gb> = 0/1/2/3).\n"
);

printf(
"-xp <tx_source_15:0>    Configure the crosspoint.  Each hex character sets\n"
"                        source Rx for a Tx.  Values are ordered Tx SD_15 to\n"
"                        SD_0.  Chars '_' and ',' are ignored and 'x'\n"
"                        indicates to preserve current Tx source.\n"
"                        Example: 8:8 mode '-xp 7654_3210_fedc_ba98'\n"
);

printf(
"\n"
"-batch-tune             Tune all slices.\n"
"-host-batch-tune        Tune host slices.\n"
"-mod-batch-tune         Tune mod slices.\n"
"-tune-mode <ICAL|PCAL>  DFE tune mode to use; default = iCal.\n"
"-errors                 Retrieve RS FEC error counts.\n"
"-errors-half0           Retrieve RS FEC error counts for half 0.\n"
"-errors-half1           Retrieve RS FEC error counts for half 1.\n"
"-reset-errors-half0     Clear RS FEC half 0 error counts.\n"
"-reset-errors-half1     Clear RS FEC half 1 error counts.\n"
);

#if AAPL_ENABLE_AVSP_KR_TRAINING
printf(
"\n"
"-kr-enable              Enable KR Training.\n"
"-kr-status              Report current kr status.\n"
"-channel                Channels to perform KR Training.\n"
"-report-kr-failure      Report KR training failure.\n"
"-report-frame-lock      Report frame lock failure.\n"
"-report-signal-detect   Report signal detect failure.\n"
"-enable-symmetric       Force KR training to be symmetric.\n"
);
#endif

#if AAPL_ENABLE_AVSP_AUTO_NEG
printf(
"\n"
"-an-enable              Enable Auto NEgotiation.\n"
"-host-mask              slices on host side will AN.\n"
"-mod-mask               sloces on mod side will AN.\n"
"-an-speed               speed at which AN will occur.\n"
"-an-side                host side or mod side.\n"
);
printf(
"-rx-clk                 Use the ref_clk, instead of the RX recovered clock.\n"
"-n-ports                number of ports plugged into AASP.\n"
"-cap-in                 capability list.\n"
"-user-cap               user's capability list.\n"
"-kr-training-disable    disable KR training after AN.\n"
"-enable-symmetric       enable symmetric KR training.\n"
);
#endif

    return 1;
}

int aapl_avsp_8812_main(int argc, char *argv[], Aapl_t *aapl)
{
    int retval                  = 0;
    Avago_serdes_dfe_tune_mode_t tune_mode = AVAGO_DFE_ICAL;

/* Parse options: */
    uint chip                   = 0;
    int rc, index               = 0;
    const char *serdes_filename = 0;
    const char *sbm_filename    = 0;
    char *crosspoint_settings   = 0;
    int half0_div               = -1;
    int half1_div               = -1;
    int gearbox                 = -1;
    int actions                 = 0;
    int half_select             = 0;
#if AAPL_ENABLE_AVSP_STATE
    int divider                 = -1;
    uint lane_no                = 0;
#endif
    const char *device_name     = 0;
    char *data                  = 0;
    Avsp_mode_t half0_mode      = AVSP_RPT;
    Avsp_mode_t half1_mode      = AVSP_RPT;
    BOOL do_mode                = FALSE;
/*  BOOL do_reset               = FALSE; */
/*    BOOL do_direct_mode         = FALSE; */
    BOOL half0                  = FALSE;
    BOOL half1                  = FALSE;
    BOOL lanes                  = FALSE;
    BOOL bring_up               = FALSE;
    BOOL tune                   = FALSE;
    BOOL do_direct_reset        = FALSE;
    BOOL halve                  = FALSE;
    BOOL batch_tune_host        = FALSE;
    BOOL batch_tune_mod         = FALSE;
    BOOL batch_tune_half0       = FALSE;
    BOOL batch_tune_half1       = FALSE;
    BOOL xp                     = FALSE;
    BOOL errors                 = FALSE;
    BOOL errors_half0           = FALSE;
    BOOL errors_half1           = FALSE;
    int reset_errors_half0      = FALSE;
    int reset_errors_half1      = FALSE;
    BOOL channel_swap           = FALSE;
    BOOL channel_align          = FALSE;

    BOOL an_enable            = FALSE;
    BOOL kr_enable              = FALSE;
    BOOL kr_status              = FALSE;
#if AAPL_ENABLE_AVSP_KR_TRAINING
    BOOL report_kr_failure = FALSE;
    BOOL report_frame_lock = FALSE;
    BOOL report_sig_detect = FALSE;
    BOOL enable_symmetric  = FALSE;
    uint channels          = 0x000F;
#endif
#if AAPL_ENABLE_AVSP_AUTO_NEG
    Avsp_an_config_t *config = avsp_an_config_construct(aapl);
#endif

    Avsp_state_options_t state_options;
  /*  uint from[16], to[16]; */

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"serdes-upload",    1, NULL, 10 },  /* Upload <file name> to SerDes. */
        {"sbm-upload",       1, NULL, 11 },  /* Upload <file name> to SBM. */
        {"halve",            0, NULL, 12 },  /* Halve the ref clock */

        {"batch-tune",       0, NULL, 15 },  /* Tune all */
        {"host-batch-tune",  0, NULL, 16 },  /* Tune host Rx */
        {"mod-batch-tune",   0, NULL, 17 },  /* Tune mod Rx */
        {"half0-batch-tune", 0, NULL, 19 },  /* Tune host Rx */
        {"half1-batch-tune", 0, NULL, 21 },  /* Tune host Rx */
        {"tune-mode",        1, NULL, 18 },  /* Set tune mode */

        {"mode",             4, NULL, 20 },  /* Mode and divider value. */
/*      {"reset",            0, NULL, 21 },  // Use SBM */
/*      {"direct-mode",      1, NULL, 22 },  // Mode and div; operate directly */
        {"direct-reset",     1, NULL, 22 },  /* Mode; operate directly */
        {"half0",            1, NULL, 23 },  /* select mode and divider for the first half of the chip */
        {"half1",            1, NULL, 24 },  /* select mode and divider for the second half of the chip */
        {"div0",             1, NULL, 27 },  /* <divider> to set. */
        {"div1",             1, NULL, 28 },  /* <divider> to set. */
        {"lanes",            1, NULL, 32 },  /* lane no for which speed need to be changed. */
        {"divider",          1, NULL, 33 },  /* <divider> to set in the specified lane. */


        {"bring-up",         1, NULL, 25 },  /* do device bring up with optional tuning parameter */

        {"xp",               1, NULL, 26 },  /* crosspoint connections */
        {"channel-swap",     1, NULL, 29 },  /* do channel swap on the given gearbox */
        {"channel-align",    0, NULL, 30 },  /* do channel alignment on output channel */
        {"tune",             0, NULL, 31 },  /* do channel alignment on output channel */
        {"chip",             1, NULL, 'c'},  /* <chip number> for device selection. */

#if AAPL_ENABLE_AVSP_8812
        {"errors",           0, NULL, 'r'},  /* retrieve FEC errors for 8812 */
        {"errors-half0",     0, NULL, 34},  /* retrieve FEC errors for 8812 */
        {"errors-half1",     0, NULL, 35},  /* retrieve FEC errors for 8812 */
        {"reset-errors-half0", 0, NULL, 's'},  /* retrieve FEC errors for 8812 */
        {"reset-errors-half1", 0, NULL, 'u'},  /* retrieve FEC errors for 8812 */
#endif

#if AAPL_ENABLE_AVSP_KR_TRAINING
        {"kr-enable",        0, NULL, 'K'}, /* Enable KR Training */
        {"kr-status",        0, NULL, 't'}, /* Enable KR Training */
        {"channel",          1, NULL, 'C'}, /* Enable KR Training */
        {"report-kr-failure",     0, NULL, 'F'}, /* Enable KR Training */
        {"report-frame-lock",     0, NULL, 'L'}, /* Enable KR Training */
        {"report-signal-detect",  0, NULL, 'P'}, /* Enable KR Training */
        {"enable-symmetric",      0, NULL, 'y'}, /* Enable KR Training */
#endif

#if AAPL_ENABLE_AVSP_AUTO_NEG
        {"an-enable",                  0, NULL, 36},  /* Enable Auto Negotiation */
        {"host-mask",                  1, NULL, 37},  /* Enable Auto Negotiation */
        {"mod-mask",                   1, NULL, 38},  /* Enable Auto Negotiation */
        {"an-speed",                   1, NULL,  9},  /* Enable Auto Negotiation */
        {"an-side",                    1, NULL, 40},  /* Enable Auto Negotiation */
        {"rx-clk",                     1, NULL, 41},  /* Enable Auto Negotiation */
        {"n-ports",                    1, NULL, 42},  /* Enable Auto Negotiation */
        {"cap-in",                     1, NULL, 43},  /* Enable Auto Negotiation */
        {"user-cap",                   1, NULL, 44},  /* Enable Auto Negotiation */
        {"kr-training-disable",        1, NULL, 45},  /* Enable Auto Negotiation */
        {"enable-symmetric",           1, NULL, 46},  /* Enable Auto Negotiation */
#endif
        {NULL,               0, NULL, 0  },  /* sentinel entry. */
    };

    if( aapl_common_main_options(aapl, argc, argv, 0) < 0 )
        return show_avsp_8812_help();

    if( aapl->return_code < 0 ) AAPL_EXIT(1);  /* assume anomalies already reported. */

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch( rc )
        {
        case 'c': chip   = aapl_num_from_str(optarg, name, 0); break;

        case 10 : serdes_filename = optarg; break;
        case 11 : sbm_filename    = optarg; break;
        case 12 : halve = TRUE; break;

        case 15 : batch_tune_host = batch_tune_mod = TRUE; break;
        case 16 : batch_tune_host = TRUE; break;
        case 17 : batch_tune_mod  = TRUE; break;
        case 19 : batch_tune_half0  = TRUE; break;
        case 21 : batch_tune_half1  = TRUE; break;
        case 18 : tune_mode       = aapl_dfe_tune_mode_from_str(optarg, name); break;

        case 20 : do_mode         = TRUE; actions++; break;
/*      case 21 : do_reset        = TRUE;                                               actions++; break; */
/*        case 22 : do_direct_mode  = TRUE; mode = aapl_avsp_mode_from_str(optarg, name); actions++; break; */
        case 22 : do_direct_reset = TRUE; half0_mode = aapl_avsp_mode_from_str(optarg, name); actions++; break;
        case 23 : half0           = TRUE; half0_mode =  aapl_avsp_mode_from_str(optarg, name); actions++; break;
        case 24 : half1           = TRUE; half1_mode =  aapl_avsp_mode_from_str(optarg, name); actions++; break;
        case 25 : bring_up        = TRUE; data =  optarg; actions++; break;
        case 26 : xp              = TRUE; crosspoint_settings = optarg; break;
        case 27 : half0_div       = aapl_num_from_str(optarg, name, 0); break;
        case 28 : half1_div       = aapl_num_from_str(optarg, name, 0); break;
        case 29 : channel_swap    = TRUE; gearbox = aapl_num_from_str(optarg, name, 0); break;
        case 30 : channel_align   = TRUE; break;
        case 31 : tune            = TRUE; break;
#if AAPL_ENABLE_AVSP_STATE
        case 32 : lanes           = TRUE; lane_no = aapl_num_from_str(optarg, name, 0); break;
        case 33 : divider         = aapl_num_from_str(optarg, name, 0); break;
#endif

        case 'r': errors          = TRUE; break;
        case 34: errors_half0     = TRUE; break;
        case 35: errors_half1     = TRUE; break;
        case 's': reset_errors_half0    = TRUE; break;
        case 'u': reset_errors_half1    = TRUE; break;

  /*      case 'X': if( xp_count == 16 ) aapl_main_error("-xp option repeated more that 16 times.\n");
                  else
                  {
                      char *str2 = 0, *str3 = 0;
                      from[xp_count] = strtol(optarg,&str2,0);
                      if( *str2 == ',' )
                          to  [xp_count] = strtol(str2+1,&str3,0);
                      if( *str2 != ',' || *str3 )
                          aapl_main_error("-%s option requires a comma separated number pair; got: \"%s\".", name, optarg);
                      xp_count++;
                  }
                  break;*/

#if AAPL_ENABLE_AVSP_KR_TRAINING
        case 'K': kr_enable = TRUE; break;
        case 'F': report_kr_failure = TRUE; break;
        case 'L': report_frame_lock = TRUE; break;
        case 'P': report_sig_detect = TRUE; break;
        case 'C': channels = aapl_num_from_str(optarg,name,16); break;
        case 'y': enable_symmetric = TRUE; break;
        case 't': kr_status = TRUE; break;
#endif

#if AAPL_ENABLE_AVSP_AUTO_NEG
        case 36: an_enable                       = TRUE; break;
        case 37: config->host_mask               = aapl_num_from_str(optarg, name, 0); break;
        case 38: config->mod_mask                = aapl_num_from_str(optarg, name, 0); break;
        case  9: config->an_speed                = aapl_num_from_str(optarg, name, 0); break;
        case 40: config->an_side                 = aapl_num_from_str(optarg, name, 0); break;
        case 41: config->rx_clk                  = aapl_num_from_str(optarg, name, 0); break;
        case 42: config->n_ports                 = aapl_num_from_str(optarg, name, 0); break;
        case 43: config->cap_in                  = aapl_num_from_str(optarg, name, 0); break;
        case 44: config->user_cap                = aapl_num_from_str(optarg, name, 0); break;
        case 45: config->kr_training_disable     = aapl_num_from_str(optarg, name, 0); break;
        case 46: config->enable_symmetric        = aapl_num_from_str(optarg, name, 0); break;
#endif
        case '?':
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    /* The default value of half1_div is the same as half0_div */
    if( half1_div < 0 )
        half1_div = half0_div;

    /* Verify the user has specified the correct command line options */
    if( halve && (!serdes_filename || !sbm_filename) )
        aapl_main_error("The \"-halve\" option requires SerDes and SBus master firmware.\n");
    if( (half0_div < 0 && half0) || (half1_div < 0 && half1) || (half0_div < 0 && do_mode) )
        aapl_main_error("The \"-half0\", \"-half1\", and \"-mode\" require a divider.\n");


/*   if( actions > 1 ) */
  /*      aapl_main_error("Only one of -mode, -reset, -direct-mode and -direct-reset allowed.\n"); */
    if( do_direct_reset )
    {
        if( (argc-optind) != 1 )
            aapl_main_error("The direct-reset command requires a half-select parameter.\n");
        half_select = aapl_num_from_str(argv[optind++],"do_direct_reset",0);
    }

#if 0
    if( half0 )
    {
        if( (argc-optind) < 1 )
            aapl_main_error("half0 command requires a divider parameter.\n");

        printf ("half 0divider %d\n\n", half0_div);
        /*half0_div = aapl_num_from_str(argv[optind++],"half0",0); */
    }

    if( half1 )
    {
        if( (argc-optind) < 1 )
            aapl_main_error("half1 command requires a divider parameter.\n");
        half1_div = aapl_num_from_str(argv[optind++],"half1",0);
    }
#endif

    if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    if( !serdes_filename && !sbm_filename && actions == 0 && !batch_tune_host && !batch_tune_mod && !errors && !errors_half0 && !errors_half1
        && !kr_enable && !kr_status && !channel_swap && !channel_align && !lanes && !reset_errors_half0 && !reset_errors_half1 && !an_enable)
        return show_avsp_8812_help();

    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
    aapl_get_ip_info(aapl,0);
    device_name = aapl_get_chip_name(aapl, avago_make_addr3(chip,0,0));

    if( serdes_filename && sbm_filename )
    {
        printf("Uploading firmware files to %s device %u.\n", device_name, chip);
        avsp_upload_firmware_file(aapl, chip, halve, serdes_filename, sbm_filename);
    }
    else if( serdes_filename )
    {
        uint broadcast_addr = avago_make_serdes_broadcast_addr(avago_make_addr3(chip,0,0));
        printf("Uploading spico code to %s SerDes on device %u.\n", device_name, chip);
        avago_spico_upload_file(aapl, broadcast_addr, TRUE, serdes_filename);
    }
    else if( sbm_filename )
    {
        uint sbm_addr = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
        printf("Uploading spico code to the %s SBus Master on device %u.\n", device_name, chip);
        avago_spico_upload_file(aapl, sbm_addr, TRUE, sbm_filename);
    }


#if AAPL_ENABLE_AVSP_KR_TRAINING
    if( kr_enable )
    {
        /*uint kr_temp; */
        Avago_kr_config_t *config = avago_kr_config_construct(aapl);
        config->channels = channels;
        config->enable_symmetric = enable_symmetric;
        config->report_kr_failure = report_kr_failure;
        config->report_frame_lock = report_frame_lock;
        config->report_signal_detect = report_sig_detect;
        avsp_kr_enable(aapl, chip, config);
        /*printf("KR Return Value: %x\n", kr_temp); */
        avago_kr_config_destruct(aapl, config);
    }

    if( kr_status )
    {
        uint kr_temp;
        Avago_kr_config_t *config = avago_kr_config_construct(aapl);
        config->report_kr_failure = report_kr_failure;
        config->report_frame_lock = report_frame_lock;
        config->report_signal_detect = report_sig_detect;
        kr_temp = avsp_kr_status(aapl, chip, config);
        printf("KR Return Value: %x\n", kr_temp);
        avago_kr_config_destruct(aapl, config);
    }
#endif

#if AAPL_ENABLE_AVSP_AUTO_NEG
    if( an_enable )
        avsp_an_start(aapl,chip,config);

    avsp_an_config_destruct(aapl,config);
#endif

    if( do_mode )
    {
        printf("Stating half0 into %s mode with divider ratio %d.\n", aapl_avsp_mode_to_str(half0_mode), half0_div);
        printf("Stating half1 into %s mode with divider ratio %d.\n", aapl_avsp_mode_to_str(half1_mode), half1_div);
        state_options.half_mode[0] = half0_mode;
        state_options.half_mode[1] = half1_mode;
        state_options.half0_div = half0_div;
        state_options.half1_div = half1_div;
        avsp_state_device_with_options(aapl, chip, &state_options);
    }


    /* "half0" and "half1" options are equivalent to the direct-mode for the AVSP_4412 */
    else if( half0 || half1 )
    {
        /* State device by directly writing to device: */
        Avsp_state_t state;

        avsp_state_init(aapl, chip, NULL, half0_mode, &state);

        if( xp )
            avsp_state_set_crosspoint( aapl, &state, crosspoint_settings );

        printf("Stating half0 into %s mode with divider ratio %d.\n", aapl_avsp_mode_to_str(half0_mode), half0_div);
        avsp_8812_configure_half(aapl, &state, half0_mode, half0_div, 0);
        printf("Stating half1 into %s mode with divider ratio %d.\n", aapl_avsp_mode_to_str(half1_mode), half1_div);
        avsp_8812_configure_half(aapl, &state, half1_mode, half1_div, 1);

        avsp_state_write_to_memory(aapl, &state);
        avsp_state_device_from_memory(aapl, state.prtad);
        /*avsp_8812_state_write_to_device(aapl, &state, 0); */
        /*avsp_8812_state_write_to_device(aapl, &state, 1); */
    }
    else if( do_direct_reset )
    {
            printf("Directly resetting control logic into %s mode for half %d.\n", aapl_avsp_mode_to_str(half0_mode), half_select);
            avsp_8812_control_logic_reset_direct(aapl, chip, half0_mode, half_select);
    }
#if AAPL_ENABLE_AVSP_STATE
    if( lanes )
    {
        avsp_8812_configure_lane_speed(aapl, chip, lane_no, divider);
    }
#endif /* AAPL_ENABLE_AVSP_STATE */
    if( batch_tune_host || batch_tune_mod || batch_tune_half0 || batch_tune_half1 )
    {
        Avago_serdes_dfe_state_t *dfe = avago_serdes_dfe_state_construct(aapl);
        BOOL batch_tune_mod4 = batch_tune_mod && half0_mode == AVSP_GEARBOX_2_1;
        Avsp_addr_list_t list = AVSP_MODX;
        const char *which = (batch_tune_host && batch_tune_mod) ? "all" : batch_tune_host ? "host" : "mod";
        dfe->tune_mode = tune_mode;
        /* Note: "ALL" here is host and mod4 slices if in Gearbox mode: */
        printf("Performing %s tuning on %s slices.\n", aapl_dfe_tune_mode_to_str(dfe->tune_mode), which);

        if(      batch_tune_host && batch_tune_mod4 ) list = AVSP_HOST_MOD4;
        else if( batch_tune_host && batch_tune_mod )  list = AVSP_ALL;
        else if( batch_tune_host )                    list = AVSP_HOST;
        else if( batch_tune_mod4 )                    list = AVSP_MOD4;
        else if( batch_tune_mod )                     list = AVSP_MOD;
        else if( batch_tune_half0 )                   list = AVSP_HALF0;
        else if( batch_tune_half1 )                   list = AVSP_HALF1;
        avsp_batch_tune(aapl, chip, list, dfe, 500, 400, 10000);

        avago_serdes_dfe_state_destruct(aapl, dfe);

        if( half0 || half1 )
        {
            printf("Performing Tx Phase Cal on %s slices.\n", which);
            phase_cal_serdes(aapl, chip, list);
        }
    }
    /*if( do_direct_mode && mode == AVSP_GEARBOX_2_1 )
    {
        printf("Aligning output channels.\n");
        avsp_8812_channel_align(aapl, chip, -1, 0);
        printf("Performing Tx Phase Cal on host&mod4 slices.\n");
        phase_cal_serdes(aapl, chip, AVSP_HOST_MOD4);
    }*/
    if( bring_up )
    {
        const char *sel_tuning = tune ? "TUNE" : "NO_TUNE";
        char temp[10];
        size_t charcnt = strlen(data);
        uint i=0,j=0,varcnt=0;
        const char * var[5]={NULL};

        for( i = 0; i < charcnt; i++ ) 
        {
             if(( data[i] != ',' ))
                 temp[j++] = data[i];

             if(( data[i] == ',' ) || ( i == charcnt-1 ))
             {
                 temp[j] = '\0';
                 if(      strcmp(temp,"0")     == 0)                                   var[varcnt++] = "0";
                 else if( strcmp(temp,"1")     == 0)                                   var[varcnt++] = "1";
                 else if(( strcmp(temp,"slow") == 0) || ( strcmp(temp,"SLOW") == 0))   var[varcnt++] = "slow";
                 else if(( strcmp(temp,"fast") == 0) || ( strcmp(temp,"FAST") == 0))   var[varcnt++] = "fast";
                 else if(( strcmp(temp,"both") == 0) || ( strcmp(temp,"BOTH") == 0))   var[varcnt++] = "both";
                 else if(( strcmp(temp,"all" ) == 0) || ( strcmp(temp,"ALL")  == 0))   var[varcnt++] = "all";
                 else aapl_main_error("Invalid parameter with \"bring-up\" option. Run with -h for a usage summary.");

                 j = 0; 
             }
        }
        if( varcnt == 1 )  
        {
            if( strcmp(var[0],"all") == 0 )
            {
                avsp_8812_bring_up(aapl, chip, 0, (const char*)"both", sel_tuning);
                avsp_8812_bring_up(aapl, chip, 1, (const char*)"both", sel_tuning);
            }
            else
                aapl_main_error("Invalid sequence in parameter with \"bring-up\" option. Run with -h for a usage summary.");
        }
        else if((( strcmp(var[0],"0") == 0) || ( strcmp(var[0],"1") == 0)) && 
                (( strcmp(var[1],"0") == 0) || ( strcmp(var[1],"1") == 0))) 
        {
            if(( varcnt > 3) && (( strcmp(var[3],"fast") == 0) || (strcmp(var[3],"slow") == 0) || (strcmp(var[3],"both") == 0)))
            { 
                avsp_8812_bring_up(aapl, chip, strtol(var[0],NULL,10), var[2], sel_tuning);
                avsp_8812_bring_up(aapl, chip, strtol(var[1],NULL,10), var[3], sel_tuning);
            }
            else if( varcnt == 3 ) 
            {
                avsp_8812_bring_up(aapl, chip, strtol(var[0],NULL,10), var[2], sel_tuning);
                avsp_8812_bring_up(aapl, chip, strtol(var[1],NULL,10), var[2], sel_tuning);
            }
            else
                aapl_main_error("Invalid sequence in parameter with \"bring-up\" option. Run with -h for a usage summary.");
        }
        else if(( strcmp(var[1],"1") != 0) && (strcmp(var[1],"0") != 0) && 
               (( strcmp(var[0],"0") == 0) || ( strcmp(var[0],"1") == 0)) && ( varcnt == 2 ))
        {
                avsp_8812_bring_up(aapl, chip, strtol(var[0],NULL,10), var[1], sel_tuning);

        }
        else
            aapl_main_error("Invalid sequence in parameter with \"bring-up\" option. Run with -h for a usage summary.");
    }
    if( channel_swap )
    {
        avsp_8812_channel_swap(aapl, chip, gearbox);
    }
    if( channel_align )
    {
        avsp_8812_channel_align(aapl, chip); /* alignment */
    }

    if( errors || errors_half0 || errors_half1)
    {
        aapl->verbose += 1;
        if (errors || errors_half0) printf("---------- Half0 Status ----------\n");
        if (errors || errors_half0) avsp_8812_get_status(aapl, chip, 0, AVSP_ALL_ERRORS, 0, 0);
        if (errors || errors_half1) printf("---------- Half1 Status ----------\n");
        if (errors || errors_half1) avsp_8812_get_status(aapl, chip, 1, AVSP_ALL_ERRORS, 0, 0);
        aapl->verbose -= 1;
    }

    if(reset_errors_half0) avsp_8812_fec_error_reset(aapl, chip, 0);
    if(reset_errors_half1) avsp_8812_fec_error_reset(aapl, chip, 1);

    /* Cleanup and exit: */
    retval = aapl->return_code != 0;
    if( retval )
        printf("ERROR\n");
    return retval;
}

#endif /* AAPL_ENABLE_AVSP_8812 */

static int show_supervisor_help()
{
    aapl_common_main_help(FALSE);
    printf(
"-chip <chip_num>  The chip number to access; range [0-15]; default = 0.\n"
"-start            Start supervisor link monitoring.\n"
"-stop             Stop supervisor link monitoring.\n"
"-display          Show supervisor state.\n"
"-clear-interr-io  Clear the sticky interr_io pin.\n"
    );
    printf(
"-select <select>  Supervisor SerDes selection.\n"
"                    <select> is any SerDes SBus address, or an AVSP broadcast\n"
"                    address.  :2f selects all, :20 link 0, :21 link 1, ...,\n"
"                    :2a all host, :2b 25G mod, :2c 10G mod, :2d all mod.\n"
"                    May repeat.  Default: :2f (all).\n"
"-enable           Enable <select> selected SerDes.  Others are disabled.\n"
"-threshold <val>  Set signal OK threshold for <select> selected SerDes.\n"
"\n"
    );
    printf(
"-mode <TUNE_IF_SIGNAL|TUNE_IF_LOCKED_SIGNAL|NO_TUNE>\n"
"                  Configure supervisor operating mode.\n"
"Supervisor mode options:\n"
"-adaptive         Run adaptive during normal operation.\n"
"-reuse-ical       Reuse initial valid iCal during recovery.\n"
"-squelch-tx       Disable TX output until valid incoming signal.\n"
    );

    return 1;
}

static Avsp_supervisor_mode_t supervisor_mode_from_str(const char *str, const char *opt)
{
    Avsp_supervisor_mode_t value;
    if( !aapl_str_to_supervisor_mode(str, &value) )
        aapl_main_error("-%s option must be {TUNE_IF_SIGNAL|TUNE_IF_LOCKED_SIGNAL|NO_TUNE}; got %s\n",opt,str);
    return value;
}

int aapl_supervisor_main(int argc, char *argv[], Aapl_t *aapl)
{
    int retval = 0;

/* Parse options: */
    uint chip        = 0;
    int  rc, index   = 0;
    BOOL have_user_options = FALSE;
    BOOL display = FALSE;
    BOOL start = FALSE;
    BOOL stop = FALSE;
    BOOL clear_interr_io = FALSE;
    BOOL squelch_tx = FALSE;
    BOOL reuse_ical = FALSE;
    BOOL run_adaptive = FALSE;
    BOOL do_configure = FALSE;
    BOOL enable       = FALSE;
    Avsp_supervisor_mode_t run_mode = AVSP_SUPERVISOR_MODE_NO_TUNE;
    uint selections[20] = { 0x2f };
    int  sel_count = 0;
    int  threshold = -1;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,

        {"chip",             1, NULL, 'c'},  /* <chip number> for device selection. */
        {"display",          0, NULL, 'd'},  /* display */
        {"start",            0, NULL, 's'},  /* */
        {"stop",             0, NULL, 'p'},  /* */
        {"clear-interr-io",  0, NULL, 'x'},  /* */
        {"squelch-tx",       0, NULL, 'q'},  /* */
        {"reuse-ical",       0, NULL, 'i'},  /* */
        {"adaptive",         0, NULL, 'a'},  /* */
        {"mode",             1, NULL, 'm'},  /* */
        {"select",           1, NULL, 'S'},  /* */
        {"enable",           0, NULL, 'E'},  /* */
        {"threshold",        1, NULL, 'T'},  /* */
        {NULL,               0, NULL, 0  },  /* sentinel entry. */
    };

    if( aapl_common_main_options(aapl, argc, argv, 0) < 0 )
        return show_supervisor_help();

    if( aapl->return_code < 0 ) AAPL_EXIT(1);  /* assume anomalies already reported. */

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        have_user_options = TRUE;
        switch( rc )
        {
        case 'c': chip   = aapl_num_from_str(optarg, name, 0); break;

        case 'd': display = TRUE; break;
        case 's': start = TRUE; break;
        case 'p': stop = TRUE; break;
        case 'x': clear_interr_io = TRUE; break;

        case 'm': run_mode = supervisor_mode_from_str(optarg,name);
                  do_configure = TRUE; break;
        case 'q': squelch_tx   = TRUE; break;
        case 'i': reuse_ical   = TRUE; break;
        case 'a': run_adaptive = TRUE; break;

        case 'S': if( sel_count < AAPL_ARRAY_LENGTH(selections) )
                      selections[sel_count++] = aapl_addr_from_str(optarg,name);
                  break;
        case 'E': enable    = TRUE; break;
        case 'T': threshold = aapl_num_from_str(optarg,name,0); break;

        case '?':
        default: if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    if( !have_user_options )
        return show_supervisor_help();

    if( !do_configure && (squelch_tx || reuse_ical || run_adaptive) )
        aapl_main_error("-mode option required with -squelch-tx, -adaptive and -reuse-ical.");

    if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) AAPL_EXIT(1);
    aapl_get_ip_info(aapl,0);

    if( stop )
    {
        printf("Stopping supervisor.\n");
        avsp_supervisor_enable(aapl, chip, FALSE);
        display = TRUE;
    }
    if( threshold >= 0 )
    {
        int i;
        if( sel_count == 0 )
            sel_count = 1;
        for( i = 0; i < sel_count; i++ )
        {
            printf("Setting threshold to %d for SerDes selection 0x%x\n", threshold, selections[i]);
            avsp_supervisor_set_signal_ok(aapl, chip, selections[i], threshold);
        }
    }
    if( enable )
    {
        if( sel_count == 0 )
            sel_count = 1;
        avsp_supervisor_set_slices(aapl, chip, sel_count, selections);
        display = TRUE;
    }
    if( start )
    {
        printf("Starting supervisor.\n");
        avsp_supervisor_enable(aapl, chip, TRUE);
        display = TRUE;
    }
    if( do_configure )
    {
        Avsp_supervisor_config_t config;
        avsp_supervisor_config_init(aapl, run_mode, squelch_tx, reuse_ical, run_adaptive, &config);
        avsp_supervisor_set_config(aapl, chip, &config);
        display = TRUE;
    }
    if( clear_interr_io )
    {
        printf("Clearing interrupt pin.\n");
        avsp_supervisor_clear_interr_io(aapl, chip);
        display = TRUE;
    }

    if( display )
    {
        int i;
        Avsp_supervisor_config_t config;
        Avsp_supervisor_mode_t mode = AVSP_SUPERVISOR_MODE_NO_TUNE;
        avsp_supervisor_config_init(aapl, AVSP_SUPERVISOR_MODE_NO_TUNE, TRUE, TRUE, TRUE, &config);
        avsp_supervisor_get_config(aapl, chip, &config);
        printf("Supervisor is %s.\n", config.enabled ? "running" : "stopped");
        if( config.assp_control_0 & 0x20 )
            mode = AVSP_SUPERVISOR_MODE_NO_TUNE;
        else if( config.assp_control_0 & 0x02 )
            mode = AVSP_SUPERVISOR_MODE_TUNE_IF_SIGNAL;
        else
            mode = AVSP_SUPERVISOR_MODE_TUNE_IF_LOCKED_SIGNAL;
        printf("  mode:       %s\n", aapl_supervisor_mode_to_str(mode));
        printf("  squelch-tx: %s\n", aapl_bool_to_str(config.assp_control_0 & 0x04));
        printf("  reuse-ical: %s\n", aapl_bool_to_str(config.assp_control_0 & 0x10));
        printf("  adaptive:   %s\n", aapl_bool_to_str(config.assp_control_0 & 0x40));

        for( i = 0; i < config.serdes_count; i++ )
        {
            printf("Slice %d: 0x%08x:",i,config.status[i]);
            if( !(config.status[i] & 0x0040) )
                printf("(held in reset).\n");
            else
            {
                /* Reg 0x31 bits: */
                if( config.status[i] & 0x00000020 ) printf(" SH-en ");
                if( config.status[i] & 0x00000001 ) printf(" iCal  ");
                if( config.status[i] & 0x00000002 ) printf(" iCalOk");
                if( config.status[i] & 0x00000010 ) printf(" TX-off");

                /* Reg 0x32 bits: */
                if( config.status[i] & 0x00000200 ) printf(" *idle ");
                if( config.status[i] & 0x00000400 ) printf(" *flock");
                if( config.status[i] & 0x00000800 ) printf(" *iCal+");
                if( config.status[i] & 0x00001000 ) printf(" *pCal+");
                if( config.status[i] & 0x00100000 ) printf(" *SH-en");

                /* Reg 0x34 bits: */
                if( config.status[i] & 0x04000000 ) printf(" sig-OK");
                if( config.status[i] & 0x08000000 ) printf(" flock ");
                if( config.status[i] & 0x01000000 ) printf(" LinkUP");
                if( config.status[i] & 0x10000000 ) printf(" iCal+ ");
                if( config.status[i] & 0x02000000 ) printf(" iCalOK");
                if( config.status[i] & 0x20000000 ) printf(" pCal+ ");
                printf("\n");
            }
        }
        printf("Interrupt pin is %s.\n", config.interr_io ? "active" : "clear");
    }


    /* Cleanup and exit: */
    retval = aapl->return_code != 0;
    if( retval )
        printf("ERROR in operation.\n");
    return retval;
}

#endif /* AAPL_ENABLE_MAIN && AAPL_ENABLE_AVSP && AAPL_ENABLE_FILE_IO */
