/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* AAPL (ASIC and ASSP Programming Layer) support for AVSP */

/** Doxygen File Header */
/** @file */
/** @brief Functions common to ASSPs. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_AVSP
#define EQS(str1,str2) (0==strcmp(str1,str2))

/** @defgroup Avsp Avsp Functions */
/** @{ */

static void avsp_set_refclk_halve(Aapl_t *aapl, uint prtad, BOOL refclk_halve)
{
    uint addr = avago_make_addr3(prtad,0,0);
    uint sbc_addr = avago_make_sbus_controller_addr(addr);

    /* Perform soft reset: */
    avago_sbus_reset(aapl, sbc_addr, 0);    /* Resets refclk_halve value */

    if( refclk_halve )
    {
        /* Change the REFCLK pad configuration to cut the frequency in half. */
        /* Then give the clock change time to settle before next operations. */
        const char *avsp_name = aapl_get_chip_name(aapl, addr);
        if( EQS(avsp_name,"AVSP-1104") )
            avago_sbus_rmw(aapl, sbc_addr, 0x0080, 0x0002, 0x0002);  /* 1104, bit 1 */
        else if( EQS(avsp_name,"AVSP-8812") )
            avago_sbus_rmw(aapl, sbc_addr, 0x0080, 0x000c, 0x000c);  /* 8812, bit 3 (and 2?) */
        else if( EQS(avsp_name,"AVSP-5410") )
            avago_sbus_rmw(aapl, sbc_addr, 0x0080, 0x0008, 0x0008);  /* 5410, bit 3 */
        else
            avago_sbus_rmw(aapl, sbc_addr, 0x0080, 0x0004, 0x0004);  /* 4412/8801/9104, bit 2 */

/* NOTE: This doesn't seem to apply to the 7412: */

        /* TBD: Adjust or remove this delay: */
        ms_sleep(1);   /* milliseconds wait time */
    }
}

/** @brief  Returns REFCLK divider. */
/** @details The REFCLK can be divided in half before passing to the SerDes. */
/**          Note: This setting does not divide REFCLK for AN. */
/** @return Returns 1 if the REFCLK DIV2 divider is not enabled. */
/** @return Returns 2 if the REFCLK DIV2 divider is enabled. */
/** @return On error, decrements aapl->return_code and returns -1. */
int avsp_get_refclk_divisor(
    Aapl_t *aapl,   /**< Pointer to Aapl_t structure. */
    uint    prtad)  /**< Port address of the targeted device. */
{
    int return_code = aapl->return_code;
    uint addr = avago_make_addr3(prtad,0,0);
    uint sbc_addr = avago_make_sbus_controller_addr(addr);
    const char *avsp_name = aapl_get_chip_name(aapl,addr);
    uint addr_80 = avago_sbus_rd(aapl, sbc_addr, 0x80);
    int ret = 1;
    if(    (EQS(avsp_name,"AVSP-1104")      &&  (addr_80 & 0x02))
        || (EQS(avsp_name,"AVSP-4412/8801") &&  (addr_80 & 0x04))
        || (EQS(avsp_name,"AVSP-5410")      &&  (addr_80 & 0x08))
        || (EQS(avsp_name,"AVSP-8812")      && ((addr_80 & 0x18) == 0x08 || (addr_80 & 0x14) == 0x14))
        || (EQS(avsp_name,"AVSP-9104")      &&  (addr_80 & 0x04)) )
        ret = 2;
    return (return_code == aapl->return_code) ? ret : -1;
}


/** @brief   Resets and uploads all the Avago firmware for the device. */
/** @details Makes the device ready for additional configuration by performing */
/**          soft resets and sequencing the uploads for correct operation. */
/** @details The SerDes ROM image is directly loaded to the SerDes on the */
/**          addressed chip(s) and ring(s).  The SBM ROM image is directly */
/**          uploaded to the SBus Master processor.  If specified, the SDI ROM */
/**          image is appended to the SBus Master image in the target processor */
/**          memory.  If the SBM ROM image already has an SDI (with swap and/or */
/**          a state table) appended, or no SDI image is needed, the sbm_rom */
/**          pointer should be NULL. */
/** */
/**          The SDI ROM contains SerDes swap images, an AVSP state table, */
/**          or both.  Note that SerDes swap images are already in the SDI */
/**          format. */
/** */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_firmware_upload_file(). */
int avago_firmware_upload(
    Aapl_t    *aapl,            /**< Pointer to Aapl_t structure. */
    uint       addr,            /**< SerDes/chip/ring addresses targeted. */
    int        serdes_rom_size, /**< Size of SerDes ROM image. */
    const int *serdes_rom,      /**< Pointer to SerDes ROM image. */
    int        sbm_rom_size,    /**< Size of SBM ROM image. */
    const int *sbm_rom,         /**< Pointer to SBM ROM image. */
    int        sdi_rom_size,    /**< Size of sdi (swap) ROM image. */
    const int *sdi_rom)         /**< Pointer to sdi (swap) ROM image. */
{
    int return_code = aapl->return_code;
    uint sbm_addr = avago_make_sbus_master_addr(addr);

    /* Load SerDes and SBus Master firmware: */
    /* Required order: */
    /*  1. SerDes: must be running for SBM to auto-state on startup. */
    /*  2. SBus Master: */
    /*  3. SerDes sdi: SBM must be loaded before sdi can be loaded. */
    /*     Or, sdi must be part of (appended to) the SBM image. */
    /*     Also, any SerDes swap image must be loaded before calling a SerDes */
    /*      interrupt that requires it. */
    avago_spico_upload(aapl, addr, TRUE, serdes_rom_size, serdes_rom);
    if( 0 == avago_spico_upload(aapl, sbm_addr, TRUE, sbm_rom_size, sbm_rom)
        && sdi_rom && sdi_rom_size > 0 )
    {
        /* Only upload this image if no image is already appended to the SBM. */
        /* TODO-16NM esb/ip rev for 16nm is 0x02 so we need logic for process type */
        if( aapl_get_ip_rev(aapl, avago_make_sbus_controller_addr(addr)) >= 0x00be )
        {
            /* Retrieve end of ROM location from loaded image: */
            int end_addr = avago_spico_int(aapl, sbm_addr, 0x1c, 0);
            if( end_addr == sbm_rom_size )
                avago_spico_upload_swap_image(aapl, addr, sdi_rom_size, sdi_rom);
            else
                aapl_log_printf(aapl, AVAGO_WARNING, __func__,__LINE__,
                    "Skipping swap/SDI ROM upload because SBus Master image already contains an SDI image.\n");
        }
        else /* Always upload as old/test chips do not support an appended SDI: */
            avago_spico_upload_swap_image(aapl, addr, sdi_rom_size, sdi_rom);
    }

    return return_code == aapl->return_code ? 0 : -1;
}

/** @brief   Puts the AVSP device into a known good state and uploads firmware. */
/** @details Makes the device ready for additional configuration by performing */
/**          soft resets, adjusting the refclk pad frequency if requested, and */
/**          uploading firmware. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avsp_upload_firmware(
    Aapl_t    *aapl,            /**< Pointer to Aapl_t structure. */
    uint       prtad,           /**< Port address of the targeted device. */
    BOOL       refclk_halve,    /**< Cut REFCLK frequency in half within the clock pad. */
    int        serdes_rom_size, /**< Size of SerDes ROM image. */
    const int *serdes_rom,      /**< Pointer to SerDes ROM image. */
    int        sbm_rom_size,    /**< Size of SBM ROM image. */
    const int *sbm_rom,         /**< Pointer to SBM ROM image. */
    int        swap_rom_size,   /**< Size of SDI(swap) ROM image. */
    const int *swap_rom)        /**< Pointer to SDI(swap) ROM image. */
{
    int return_code = aapl->return_code;
    uint addr = avago_make_addr3(prtad,0,0);
    uint broadcast_addr = avago_make_serdes_broadcast_addr(addr);

    avsp_set_refclk_halve(aapl, prtad, refclk_halve);
    avago_firmware_upload(aapl, broadcast_addr, serdes_rom_size, serdes_rom,
                          sbm_rom_size, sbm_rom, swap_rom_size, swap_rom);

    return (return_code == aapl->return_code) ? 0 : -1;
}

#if AAPL_ENABLE_FILE_IO

/** @brief   Verifies the CRC on a single ROM image. */
/** @return  TRUE if the CRC is valid, FALSE if not valid. */
static BOOL aapl_verify_rom_crc(int rom_size, int *rom)
{
    int crc = aapl_crc_rom(rom,rom_size-4);
    int *ptr = rom + rom_size - 5;
    return  ptr[0] == 0x4e
         && ptr[1] == ((crc >>  0) & 0xff)
         && ptr[2] == ((crc >>  8) & 0xff)
         && ptr[3] == ((crc >> 16) & 0xff)
         && ptr[4] == ((crc >> 24) & 0xff);
}

static BOOL aapl_sbm_rom_has_sdi(int sbm_rom_size, int *sbm_rom)
{
    /* SBM rom has an SDI if the CRC on the whole rom is wrong. */
    return !aapl_verify_rom_crc(sbm_rom_size, sbm_rom);
}

/** @details NOTE: May modify sbm_rom and sdi_rom values on return. */
/** */
/** @return 0 if there were no conflicts. */
/** @return -1 and decrement aapl->return_code if conflicting swap images or tables were given. */
static int merge_sdi_files(
    Aapl_t *aapl,
    int *sbm_rom_size, int **sbm_rom,
    int *sdi_rom_size, int **sdi_rom,
    int *swap_rom_size, int **swap_rom)
{
    /*TODO:  If only one unique swap and one unique table, merge them for upload. */

    /* If SBM ROM has SDI image identical to swap rom or sdi rom, then ignore the extra ROMS. */
    if( (*sdi_rom_size > 0 || *swap_rom_size > 0) && aapl_sbm_rom_has_sdi(*sbm_rom_size, *sbm_rom) )
    {
        /* If end of sbm_rom matches sdi_rom, ignore sdi_rom. */
        if( *sbm_rom_size > *sdi_rom_size && *sdi_rom_size > 0 )
        {
            if( 0 == memcmp(*sbm_rom + *sbm_rom_size - *sdi_rom_size, *sdi_rom, *sdi_rom_size) )
            {
                aapl_free(aapl, *sdi_rom, __func__);
                *sdi_rom = 0;
                *sdi_rom_size = 0;
            }
            else
                return aapl_fail(aapl,__func__,__LINE__,"SDI ROM cannot be uploaded because SBM already has an appended SDI.\n");
        }

        /* If end of sbm_rom matches swap_rom, ignore swap_rom. */
        if( *sbm_rom_size > *swap_rom_size && *swap_rom_size > 0 )
        {
            if( 0 == memcmp(*sbm_rom + *sbm_rom_size - *swap_rom_size, *swap_rom, *swap_rom_size) )
            {
                aapl_free(aapl, *swap_rom, __func__);
                *swap_rom = 0;
                *swap_rom_size = 0;
            }
            else
                return aapl_fail(aapl,__func__,__LINE__,"SWAP ROM cannot be uploaded because SBM already has an appended SDI.\n");
        }
    }

    /* If sdi_rom and swap_rom are identical, ignore swap. */
    if( *sdi_rom_size == *swap_rom_size
        && *sdi_rom_size > 0
        && 0 == memcmp(*sdi_rom,*swap_rom,*sdi_rom_size) )
    {
        aapl_free(aapl, *swap_rom, __func__);
        *swap_rom = 0;
        *swap_rom_size = 0;
    }
    else if( *swap_rom && !*sdi_rom ) /* swap and no SDI: */
    {
        /* Move swap image into sdi parameter: */
        *sdi_rom = *swap_rom;
        *swap_rom = 0;
        *sdi_rom_size = *swap_rom_size;
        *swap_rom_size = 0;
    }
    if( *swap_rom && *sdi_rom )
        return aapl_fail(aapl,__func__,__LINE__,"SWAP and SDI ROM cannot both be uploaded!\n");

    return 0;
}

/** @brief   Puts the Avago device into a known good state and uploads firmware. */
/** @details Makes the device ready for additional configuration by performing */
/**          soft resets, and uploading firmware. */
/** @details The SerDes ROM image is directly loaded to the SerDes on the */
/**          addressed chip(s) and ring(s).  The SBM ROM image is directly */
/**          uploaded to the SBus Master processor.  The sdi_rom_file, if not */
/**          NULL, or the SerDes swap image if any, is appended to the SBus */
/**          Master image in the target processor memory.  If the user creates a custom SBM ROM image with the SDI */
/**          image already appended, or if no SDI image is needed, the sbm_rom */
/**          pointer should be NULL. */
/** */
/**          The SDI ROM contains SerDes swap images, an AVSP state table, */
/**          or both.  Note that SerDes swap images are already in the SDI */
/**          format. */
/** */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_firmware_upload(). */
int avago_firmware_upload_file(
    Aapl_t *aapl,                   /**< Pointer to Aapl_t structure */
    uint addr,                      /**< Sbus address of device to upload to */
    const char *serdes_rom_file,    /**< Path name of SerDes .rom file. */
    const char *sbm_rom_file,       /**< Path name of SBus Master .rom file. */
    const char *sdi_rom_file)       /**< Path name of SDI file, or NULL. */
{
    int status = -1, serdes_rom_size = 0, *serdes_rom = 0;
    if( 0 == avago_load_rom_from_file(aapl, serdes_rom_file, &serdes_rom_size, &serdes_rom) )
    {
        int sbm_rom_size = 0, *sbm_rom = 0;
        if( sbm_rom_file && 0 == avago_load_rom_from_file(aapl, sbm_rom_file, &sbm_rom_size, &sbm_rom) )
        {
            char *swap_file = avago_find_swap_file(aapl, serdes_rom_file);
            int swap_rom_size = 0, *swap_rom = 0;
            int sdi_rom_size = 0, *sdi_rom = 0;

            if( (!sdi_rom_file || 0 == avago_load_rom_from_file(aapl, sdi_rom_file, &sdi_rom_size, &sdi_rom))
                && (!swap_file || 0 == avago_load_rom_from_file(aapl, swap_file, &swap_rom_size, &swap_rom)) )
            {
                /* At this point, everything is loaded.  Now figure out what to do with it all: */
                if( 0 == merge_sdi_files(aapl, &sbm_rom_size, &sbm_rom, &sdi_rom_size, &sdi_rom, &swap_rom_size, &swap_rom) )
                {
                    status = avago_firmware_upload(aapl, addr, serdes_rom_size, serdes_rom, sbm_rom_size, sbm_rom, sdi_rom_size, sdi_rom);
                }
            }
            {
                BOOL st;
                Avago_addr_t addr_struct, start, stop, next;
                avago_addr_to_struct(addr, &addr_struct);
                for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, AAPL_BROADCAST_IGNORE_LANE); st;
                     st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_IGNORE_LANE) )
                {
                    aapl->firmware_file[next.chip][next.ring][next.sbus] = (char *)aapl_malloc(aapl, strlen(serdes_rom_file)+1, __func__);
                    if (aapl->firmware_file[next.chip][next.ring][next.sbus])
                        strncpy(aapl->firmware_file[next.chip][next.ring][next.sbus], serdes_rom_file, strlen(serdes_rom_file)+1);
                    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Uploaded firmware to %s from file: %s.\n", aapl_addr_to_str(avago_struct_to_addr(&next)), serdes_rom_file);
                }
            }

            if( swap_file ) aapl_free(aapl, swap_file, __func__);
            if( swap_rom ) aapl_free(aapl, swap_rom, __func__);
            if( sdi_rom ) aapl_free(aapl, sdi_rom, __func__);
            if( sbm_rom ) aapl_free(aapl, sbm_rom, __func__);
        }
        if( serdes_rom ) aapl_free(aapl, serdes_rom, __func__);
    }
    return status;
}

/** @brief   Puts the AVSP device into a known good state and uploads firmware. */
/** @details Makes the device ready for additional configuration by performing */
/**          soft resets, adjusting the refclk pad frequency if requested, and */
/**          uploading firmware. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avsp_upload_firmware_file(
    Aapl_t *aapl,               /**< Pointer to Aapl_t structure. */
    uint prtad,                 /**< Port address of the targeted device. */
    BOOL refclk_halve,          /**< Cut REFCLK frequency in half within the clock pad. */
    const char *serdes_filepath,/**< Full path to a valid Avago-supplied SerDes ROM image */
    const char *sbm_filepath)   /**< Full path to a valid Avago-supplied sbus master ROM image */
{
    int return_code = aapl->return_code;
    uint addr = avago_make_addr3(prtad,0,0);
    uint broadcast_addr = avago_make_serdes_broadcast_addr(addr);

    avsp_set_refclk_halve(aapl, prtad, refclk_halve);
    avago_firmware_upload_file(aapl, broadcast_addr, serdes_filepath, sbm_filepath, NULL);

    return (return_code == aapl->return_code) ? 0 : -1;
}
#endif /* AAPL_ENABLE_FILE_IO */

/* Add prtad field to passed in address array. */
static void avsp_edit_addrs(Aapl_t *aapl, uint prtad, size_t len, uint *addrs)
{
    size_t i;
    (void)aapl;
    for( i = 0; i < len; i++ )
    {
        Avago_addr_t addr_struct;
        avago_addr_to_struct(addrs[i],&addr_struct);
        addr_struct.chip = prtad;
        addrs[i] = avago_struct_to_addr(&addr_struct);
    }
}

#if AAPL_ENABLE_AVSP_1104
static uint a1104_host_addrs[] = { AVSP_1104_HOST_LIST };
static uint a1104_pma_addrs[]  = { AVSP_1104_HOST_LIST, AVSP_1104_MOD4_LIST };
static uint a1104_mod4_addrs[] = { AVSP_1104_MOD4_LIST };
static uint a1104_mod6_addrs[] = { AVSP_1104_MOD6_LIST };
static uint a1104_mod_addrs[]  = { AVSP_1104_MOD_LIST };
static uint a1104_addrs[]      = { AVSP_1104_HOST_LIST, AVSP_1104_MOD_LIST };
static const char *a1104_names[] = {0, 0, "H10G9", "H10G8", "H10G7", "H10G6", "H10G5", "H10G4", "H10G3", "H10G2", "H10G1", "H10G0",
                                    0, 0, "M10G4", "M10G5", "M10G6", "M25G0", "M25G1", "M25G2", "M25G3", "M10G7", "M10G8", "M10G9" };
#endif
#if AAPL_ENABLE_AVSP_9104
static uint a9104_host_addrs[] = { AVSP_9104_HOST_LIST };
static uint a9104_pma_addrs[]  = { AVSP_9104_HOST_LIST, AVSP_9104_MOD4_LIST };
static uint a9104_mod4_addrs[] = { AVSP_9104_MOD4_LIST };
static uint a9104_mod6_addrs[] = { AVSP_9104_MOD6_LIST };
static uint a9104_mod_addrs[]  = { AVSP_9104_MOD_LIST };
static uint a9104_addrs[]      = { AVSP_9104_HOST_LIST, AVSP_9104_MOD_LIST };
/*static uint a9104_an_addrs[]   = { AVSP_9104_HOST_AN_LIST, AVSP_9104_MOD_AN_LIST }; */
static const char *a9104_names[] = {0, 0, "M10G6", "M10G8", "M10G5", "M25G3", "M25G2", "M25G1", "M25G0", "M10G9", "M10G4", "M10G7",
                                    "M7", "M4", "M9", "M0", "M1", "M2", "M3", "M5", "M8", "M6",
                                    0, 0, "H10G6", "H10G8", "H10G5", "H10G3", "H10G2", "H10G1", "H10G0", "H10G9", "H10G4", "H10G7",
                                    "H7", "H4", "H9", "H0", "H1", "H2", "H3", "H5", "H8", "H6" };
#endif
#if AAPL_ENABLE_AVSP_4412 || AAPL_ENABLE_AVSP_8801
static uint a4412_host_addrs[] = { AVSP_4412_SD0, AVSP_4412_SD1, AVSP_4412_SD2, AVSP_4412_SD3 };
static uint a4412_mod_addrs[]  = { AVSP_4412_SD4, AVSP_4412_SD5, AVSP_4412_SD6, AVSP_4412_SD7 };
static uint a4412_8801_addrs[] = { AVSP_4412_LIST };
static const char *a4412_names[] = { 0, 0, 0, 0, "7", "6", "5", "4", "3", "2", "1", "0" };
#endif
#if AAPL_ENABLE_AVSP_7412
static uint a7412_host_addrs[] = { AVSP_7412_HOST_LIST };
static uint a7412_mod_addrs[]  = { AVSP_7412_MOD_LIST };
static uint a7412_addrs[]      = { AVSP_7412_LIST };
static const char *a7412_names[] = { 0, 0, 0, 0, 0, 0, 0 };
#endif
#if AAPL_ENABLE_AVSP_8812
static uint a8812_host_addrs[]             = { AVSP_8812_HOST_LIST };
static uint a8812_gearbox_2_1_addrs[]      = { AVSP_8812_HOST_LIST, AVSP_8812_MOD4_LIST };
static uint a8812_gearbox_2_1_mod_host_addrs[] = { AVSP_8812_MOD_LIST, AVSP_8812_HOST4_LIST };
static uint a8812_mod4_addrs[]             = { AVSP_8812_MOD4_LIST };
static uint a8812_gb01_host_mod_addrs[]    = { AVSP_8812_GB01_HOST_MOD_LIST };
static uint a8812_gb23_host_mod_addrs[]    = { AVSP_8812_GB23_HOST_MOD_LIST };
static uint a8812_gb01_mod_host_addrs[]    = { AVSP_8812_GB01_MOD_HOST_LIST };
static uint a8812_gb23_mod_host_addrs[]    = { AVSP_8812_GB23_MOD_HOST_LIST };
static uint a8812_half0_addrs[]            = { AVSP_8812_HALF0_LIST };
static uint a8812_half1_addrs[]            = { AVSP_8812_HALF1_LIST };
static uint a8812_modx_addrs[]             = { AVSP_8812_MODX_LIST };
static uint a8812_mod_addrs[]              = { AVSP_8812_MOD_LIST };
static uint a8812_addrs[]                  = { AVSP_8812_LIST };
/*static uint a8812_an_addrs[] = { AVSP_8812_AN_LIST }; */
static const char *a8812_names[] = { 0, 0, 0, 0, "f", "e", "d", "c", "b", "a", "9", "8", "7", "6", "5", "4", "3", "2", "1", "0",
                                    "0", "0", "1", "2", "3", "0", "1", "1",
                                    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };
#endif
#if AAPL_ENABLE_AVSP_5410
static uint a5410_host_addrs[] = { AVSP_5410_HOST_LIST };
static uint a5410_mod_addrs[]  = { AVSP_5410_MOD_LIST };
static uint a5410_addrs[]      = { AVSP_5410_LIST };
static const char *a5410_names[] = { 0, 0, 0, 0, 0, "M25G0", "H10G3", "H10G2", "H10G1", "H10G0", 0, "0", "1" };
#endif

/** @} */


#define AVSP_ARRAY_INIT(var,len,list) ((*var = list), (*len = AAPL_ARRAY_LENGTH(list)))

/** @brief  Get SerDes addresses for an AVSP device. */
/** @details The #type field specifies whether to get all SerDes address, or */
/**           just the host or mod addresses.  Note that host/mod distinctions */
/**           do not make sense for all AVSP devices, and AVSP_ALL should be */
/**           passed in those cases. */
/** @return TRUE if known device and updates addrs and len, FALSE otherwise. */
BOOL aapl_get_addr_list(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint prtad,             /**< [in] Port address of the targeted device. */
    const char *avsp_name,  /**< [in] Name of AVSP device, if known. */
    Avsp_addr_list_t list,  /**< [in] AVSP_ALL, AVSP_HOST, AVSP_MOD, ... */
    uint *len,              /**< [out] Number of addresses in returned #addrs. */
    uint **addrs)           /**< [out] Addresses of requested SerDes. */
{
    if( !avsp_name )
        avsp_name = aapl_get_chip_name(aapl, avago_make_addr3(prtad,0,0));

#if AAPL_ENABLE_AVSP_1104
    if( 0 == strcmp(avsp_name, "AVSP-1104") )
    {
        if(      list == AVSP_HOST      ) AVSP_ARRAY_INIT(addrs,len,a1104_host_addrs);
        else if( list == AVSP_HOST_MOD4 ) AVSP_ARRAY_INIT(addrs,len,a1104_pma_addrs);
        else if( list == AVSP_MOD       ) AVSP_ARRAY_INIT(addrs,len,a1104_mod_addrs);
        else if( list == AVSP_MOD4      ) AVSP_ARRAY_INIT(addrs,len,a1104_mod4_addrs);
        else if( list == AVSP_MODX      ) AVSP_ARRAY_INIT(addrs,len,a1104_mod6_addrs);
        else                              AVSP_ARRAY_INIT(addrs,len,a1104_addrs);
    }
    else
#endif
#if AAPL_ENABLE_AVSP_4412 || AAPL_ENABLE_AVSP_8801
    if( 0 == strcmp(avsp_name, "AVSP-4412/8801") )
    {
        if(      list == AVSP_HOST ) AVSP_ARRAY_INIT(addrs,len,a4412_host_addrs);
        else if( list == AVSP_MOD  ) AVSP_ARRAY_INIT(addrs,len,a4412_mod_addrs);
        else                         AVSP_ARRAY_INIT(addrs,len,a4412_8801_addrs);
    }
    else
#endif
#if AAPL_ENABLE_AVSP_7412
    if( 0 == strcmp(avsp_name, "AVSP-7412") )
    {
        if(      list == AVSP_HOST ) AVSP_ARRAY_INIT(addrs,len,a7412_host_addrs);
        else if( list == AVSP_MOD  ) AVSP_ARRAY_INIT(addrs,len,a7412_mod_addrs);
        else                         AVSP_ARRAY_INIT(addrs,len,a7412_addrs);
    }
    else
#endif
#if AAPL_ENABLE_AVSP_8812
    if( 0 == strcmp(avsp_name, "AVSP-8812") )
    {
        if(      list == AVSP_HOST          ) AVSP_ARRAY_INIT(addrs,len,a8812_host_addrs);
        else if( list == AVSP_HOST_MOD4     ) AVSP_ARRAY_INIT(addrs,len,a8812_gearbox_2_1_addrs);
        else if( list == AVSP_MOD_HOST4     ) AVSP_ARRAY_INIT(addrs,len,a8812_gearbox_2_1_mod_host_addrs);
        else if( list == AVSP_MOD           ) AVSP_ARRAY_INIT(addrs,len,a8812_mod_addrs);
        else if( list == AVSP_MOD4          ) AVSP_ARRAY_INIT(addrs,len,a8812_mod4_addrs);
        else if( list == AVSP_GB01_HOST_MOD ) AVSP_ARRAY_INIT(addrs,len,a8812_gb01_host_mod_addrs);
        else if( list == AVSP_GB23_HOST_MOD ) AVSP_ARRAY_INIT(addrs,len,a8812_gb23_host_mod_addrs);
        else if( list == AVSP_GB01_MOD_HOST ) AVSP_ARRAY_INIT(addrs,len,a8812_gb01_mod_host_addrs);
        else if( list == AVSP_GB23_MOD_HOST ) AVSP_ARRAY_INIT(addrs,len,a8812_gb23_mod_host_addrs);
        else if( list == AVSP_HALF0         ) AVSP_ARRAY_INIT(addrs,len,a8812_half0_addrs);
        else if( list == AVSP_HALF1         ) AVSP_ARRAY_INIT(addrs,len,a8812_half1_addrs);
        else if( list == AVSP_MODX          ) AVSP_ARRAY_INIT(addrs,len,a8812_modx_addrs);
        else                                  AVSP_ARRAY_INIT(addrs,len,a8812_addrs);
    }
    else
#endif
#if AAPL_ENABLE_AVSP_9104
    if( 0 == strcmp(avsp_name, "AVSP-9104") )
    {
        if(      list == AVSP_HOST      ) AVSP_ARRAY_INIT(addrs,len,a9104_host_addrs);
        else if( list == AVSP_HOST_MOD4 ) AVSP_ARRAY_INIT(addrs,len,a9104_pma_addrs);
        else if( list == AVSP_MOD       ) AVSP_ARRAY_INIT(addrs,len,a9104_mod_addrs);
        else if( list == AVSP_MOD4      ) AVSP_ARRAY_INIT(addrs,len,a9104_mod4_addrs);
        else if( list == AVSP_MODX      ) AVSP_ARRAY_INIT(addrs,len,a9104_mod6_addrs);
        else                              AVSP_ARRAY_INIT(addrs,len,a9104_addrs);
    }
    else
#endif
#if AAPL_ENABLE_AVSP_5410
    if( 0 == strcmp(avsp_name, "AVSP-5410") )
    {
        if(      list == AVSP_HOST ) AVSP_ARRAY_INIT(addrs,len,a5410_host_addrs);
        else if( list == AVSP_MOD  ) AVSP_ARRAY_INIT(addrs,len,a5410_mod_addrs);
        else                         AVSP_ARRAY_INIT(addrs,len,a5410_addrs);
    }
    else
#endif
    {
        (void)avsp_name;
        *len = 0;
        *addrs = 0;
        return FALSE;
    }

    avsp_edit_addrs(aapl, prtad, *len, *addrs);
    return TRUE;
}

BOOL avsp_get_name_list(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint prtad,             /**< [in] Port address of the targeted device. */
    const char *avsp_name,  /**< [in] Name of AVSP device, if known. */
    uint *len,              /**< [out] Number of addresses in returned #addrs. */
    const char ***names)    /**< [out] Names of devices */
{
    if( !avsp_name )
        avsp_name = aapl_get_chip_name(aapl, avago_make_addr3(prtad,0,0));

#if AAPL_ENABLE_AVSP_1104
    if( 0 == strcmp(avsp_name, "AVSP-1104") )
        AVSP_ARRAY_INIT(names, len, a1104_names);
    else
#endif
#if AAPL_ENABLE_AVSP_4412 || AAPL_ENABLE_AVSP_8801
    if( 0 == strcmp(avsp_name, "AVSP-4412/8801") )
        AVSP_ARRAY_INIT(names, len, a4412_names);
    else
#endif
#if AAPL_ENABLE_AVSP_7412
    if( 0 == strcmp(avsp_name, "AVSP-7412") )
        AVSP_ARRAY_INIT(names, len, a7412_names);
    else
#endif
#if AAPL_ENABLE_AVSP_8812
    if( 0 == strcmp(avsp_name, "AVSP-8812") )
        AVSP_ARRAY_INIT(names, len, a8812_names);
    else
#endif
#if AAPL_ENABLE_AVSP_9104
    if( 0 == strcmp(avsp_name, "AVSP-9104") )
        AVSP_ARRAY_INIT(names, len, a9104_names);
    else
#endif
#if AAPL_ENABLE_AVSP_5410
    if( 0 == strcmp(avsp_name, "AVSP-5410") )
        AVSP_ARRAY_INIT(names, len, a5410_names);
    else
#endif
    {
        (void)avsp_name;
        *len = 0;
        *names = 0;
        return FALSE;
    }
    return TRUE;
}

/** @defgroup Avsp Avsp Functions */
/** @{ */

/** @brief   Enables idle detection on all devices. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_serdes_initialize_signal_ok(). */
int avsp_enable_signal_ok(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    uint prtad,             /**< Port address of the targeted device. */
    Avsp_addr_list_t list,  /**< [in] Which list to tune. */
    int threshold)          /**< [0-15] */
{
    uint len, *addrs;
    if( aapl_get_addr_list(aapl, prtad, 0, list, &len, &addrs) )
    {
        int ret = 0;
        uint i;
        for( i = 0; i < len; i++ )
            ret |= avago_serdes_initialize_signal_ok(aapl, addrs[i], threshold);
        return ret;
    }
    return aapl_fail(aapl, __func__,__LINE__, "Device %d has unsupported or unknown type: %s\n",
                        prtad, aapl_get_chip_name(aapl, avago_make_addr3(prtad,0,0)));
}

/** @brief   Starts dfe tunes on the selected SerDes */
/**          and waits for them to finish. */
/** @details Only waits for AVAGO_DFE_ICAL and AVAGO_DFE_PCAL tunes. */
/**          Will initiate, but not wait for, other types of tunes. */
/** */
/**          When waiting is performed, #start_delay is the initial wait time */
/**          after all tunes are started before the checking pass begins, */
/**          while #loop_delay is the time between checking passes. */
/** */
/**          Returns after all tunes are complete, or #timeout is reached. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avsp_batch_tune(
    Aapl_t *aapl,                   /**< [in] Pointer to Aapl_t structure. */
    uint prtad,                     /**< [in] Port address of the targeted device. */
    Avsp_addr_list_t list,          /**< [in] Which list to tune. */
    Avago_serdes_dfe_state_t *dfe,  /**< [in] DFE settings for tuning.  If NULL, */
                                    /**<      a default ICAL tune is performed. */
    int start_delay,                /**< [in] ms to wait before checking DFE status */
    int loop_delay,                 /**< [in] ms to wait between polling checks */
    int timeout)                    /**< [in] ms to wait for all to finish */
{
    uint len, *addrs;
    if( aapl_get_addr_list(aapl, prtad, 0, list, &len, &addrs) )
        return avago_serdes_dfe_batch_tune(aapl, dfe, len, addrs, start_delay, loop_delay, timeout);

    return aapl_fail(aapl, __func__,__LINE__, "Device %d has unsupported or unknown type: %s\n",
                        prtad, aapl_get_chip_name(aapl, avago_make_addr3(prtad,0,0)));
}

/** @} */

#if AAPL_ENABLE_AVSP_AUTO_NEG
/** @brief   Constructs an auto-negotiation structure. */
/** @details Allocates and initializes memory for configuring AN. */
/** @return  Allocated structure.  Call avsp_an_config_destruct() to free it. */
Avsp_an_config_t *avsp_an_config_construct(Aapl_t *aapl)
{
    size_t bytes = sizeof(Avsp_an_config_t);
    Avsp_an_config_t *config;

    if( ! (config = (Avsp_an_config_t *) aapl_malloc(aapl, bytes, __func__)) )
        return NULL;
    memset(config, 0, sizeof(*config));         /* set all bytes to zero */
    return config;
}
/** @brief   Releases the resources associated with config. */
/** @see     avsp_an_config_construct(). */
void avsp_an_config_destruct(Aapl_t *aapl, Avsp_an_config_t *config)
{
   aapl_free(aapl, config, "Avsp_an_config_t struct");
}

/** @brief  Function to start Auto Negotiation */
/** @see    avsp_an_config_construct(), avsp_an_config_destruct(). */
uint avsp_an_start(
    Aapl_t *aapl,            /**< [in] Pointer to Aapl_t structure. */
    uint chip,               /**< [in] Sets chip for enabling AN. */
    Avsp_an_config_t *config /**< [in] The input configuration struct */
)
{
    uint addr = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
    int AN_input = 0x001; /* Enable AN */
    uint ret;

    /* Send the configuration for the host mask, mod mask, and SerDes capibilites */
    avago_spico_int(aapl, addr, 0x0022, 0x8000 | (config->host_mask & 0x3ff));
    avago_spico_int(aapl, addr, 0x0022, 0xc000 | (config->mod_mask & 0x3ff));
    if (config->cap_in != 0x00)
         avago_spico_int(aapl, addr, 0x0022, 0x3000 | (config->user_cap & 0x1be));

    /* Given the user settings from teh config struct, set the parameters for Auto Negotiation. */
    AN_input |= (config->an_speed            & 0x3) <<  1;
    AN_input |= (config->kr_training_disable & 0x1) <<  3;
    AN_input |= (config->enable_symmetric    & 0x1) <<  4;
    AN_input |= (config->rx_clk              & 0x1) <<  7;
    AN_input |= (config->n_ports             & 0xf) <<  8;
    AN_input |= (config->cap_in              & 0x3) << 12;
    AN_input |= (config->an_side             & 0x1) << 14;

    /* Final call to configure and execute Auto Negotiation */
    ret = avago_spico_int(aapl, addr, 0x0022, AN_input);
    aapl_log_printf(aapl,AVAGO_DEBUG1, __func__,__LINE__,"Prtad %u, AN_input=0x%x, host mask=0x%x, mod mask=0x%x, user_cap=0x%x, ret=%u\n", chip, AN_input, config->host_mask, config->mod_mask,config->user_cap,ret);
    return ret;
}
#endif /* AAPL_ENABLE_AVSP_AUTO_NEG */


#if AAPL_ENABLE_AVSP_KR_TRAINING
/** @brief   Constructs a KR training configuration structure. */
/** @details Allocates and initializes memory for configuring KR training. */
/** @return  Allocated structure.  Call avago_kr_config_destruct() to free it. */
/** @see     avago_kr_config_destruct(). */
Avago_kr_config_t *avago_kr_config_construct(
    Aapl_t *aapl)               /**< [in] Pointer to Aapl_t structure. */
{
    size_t bytes = sizeof(Avago_kr_config_t);
    Avago_kr_config_t *config;

    if( ! (config = (Avago_kr_config_t *) aapl_malloc(aapl, bytes, "Avago_kr_config_t struct")) )
        return NULL;
    memset(config, 0, sizeof(*config));         /* set all bytes to zero */

    config->report_kr_failure    = TRUE;
    config->report_frame_lock    = TRUE;
    config->report_signal_detect = TRUE;
    config->enable_symmetric     = FALSE;
    config->channels             = 0x000F;
    return config;
}
/** @brief   Releases the resources associated with #config. */
/** @see     avago_kr_config_construct(). */
void avago_kr_config_destruct(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    Avago_kr_config_t *config)  /**< [in] Structure to initialize. */
{
   aapl_free(aapl, config, "Avago_kr_config_t struct");
}
/*============================================================================= */
/* A V S P   K R   E N A B L E */
/** @details   Enables the KR Training interrupt. */
/** @param config The Avago_kr_config_t struct that contains */
/**               the necessary information like which */
/**               channels one wishes to perform training on. */
/**               Important information is channels and */
/**               potentially 'enable_symmetric' */
/** @return 0 on success. */
int avsp_kr_enable(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    uint chip,                  /**< [in] Sets chip for enabling KR. */
    Avago_kr_config_t *config)  /**< [in] Configuration structure. */
{
    uint addr       = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
    uint input_data = config->channels & 0x3FF;
    uint ret;
    /*printf(" Address: %x\n Channel: %x\n Symmetric: %x\n", addr, config->channels, config->enable_symmetric); */
    /*if (config->report_kr_failure)       {input_data |= 0x0400;} */
    /*if (config->report_frame_lock)       {input_data |= 0x0800;} */
    /*if (config->report_signal_detect)    {input_data |= 0x1000;} */
    if (config->enable_symmetric)        {input_data |= 0x2000;}
    if (config->side_select)             {input_data |= 0x4000;}    
    ret = avago_spico_int(aapl, addr, 0x0020, input_data);
    aapl_log_printf(aapl,AVAGO_DEBUG5, __func__,__LINE__,"Prtad %u, input_data=0x%x, ret=0x%x\n", chip, input_data, ret);
    return ret;
}

/*============================================================================= */
/* A V S P   K R   S T A T U S */
/** @details Retrieves KR status for the selected device. */
/** @return  Status for all ALL channels. If a channel */
/**          didn't run KR, an error will be reported. */
/**          The format of the channels is similar to */
/**          the input for KR Enable. */
/** */
/**          - Channel 1 : Serdes 0 and Serdes 4 */
/**          - Channel 2 : Serdes 1 and Serdes 5 */
/**          - Channel 3 : Serdes 2 and Serdes 6 */
/**          - Channel 4 : Serdes 3 and Serdes 7 */
/**          - Channel 5 : Serdes 4 and Serdes 0 */
/**          - Channel 6 : Serdes 5 and Serdes 1 */
/**          - Channel 7 : Serdes 6 and Serdes 2 */
/**          - Channel 8 : Serdes 7 and Serdes 3 */
/** */
/**          For each channel, '1' represents error and '0' is successful. */
int avsp_kr_status(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    uint chip,                  /**< [in] Port address of the targeted device. */
    Avago_kr_config_t *config)  /**< [in] Configuration structure selecting one report. */
{
    uint addr = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
    uint input_data = 0x0000;
    uint ret;
    if      (config->report_kr_failure)    input_data = 0x0001;
    else if (config->report_frame_lock)    input_data = 0x0002;
    else if (config->report_signal_detect) input_data = 0x0003;
    ret = avago_spico_int(aapl, addr, 0x0021, input_data);
    aapl_log_printf(aapl,AVAGO_DEBUG5, __func__,__LINE__,"Prtad %u, input_data=0x%x, ret=0x%x\n", chip, input_data, ret);
    return ret;
}
#endif /* AAPL_ENABLE_AVSP_KR_TRAINING */


/** @defgroup Supervisor Avsp Supervisor Functions */
/** @{ */

/** @brief   Enables supervisor monitoring of the SerDes for failure conditions. */
/** @details When failure is recognized, the hardware interr_io pin */
/**          and/or self-healing functionality is activated. */
/** @return  0 on success, -1 on failure. */
int avsp_supervisor_enable(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint chip,          /**< [in] Chip on which to enable monitoring. */
    BOOL enable)        /**< [in] Enable or disable monitoring. */
{
    uint addr = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
    uint data = enable ? 0x4400 : 0x4500;
    uint val;
    int i;
    BOOL enabled = !enable;

    avago_spico_int(aapl, addr, 0x0026, data);  /* Set new run state */
    /* Wait for supervisor to process run state change: */
    for( i = 0; i <= 30; i++ )
    {
        val = avsp_supervisor_status(aapl, chip, &enabled);
        if( val != 0  || enabled == enable ) break;
        ms_sleep(10);
    }
    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"Chip %d, loop=%d, enable=%s, status=0x%x\n", chip, i, aapl_bool_to_str(enable), val);

    if (enabled != enable || val != 0) return -1;
    return 0;
}

/** @brief   Retrieves whether the supervisor is enabled. */
/** @return  0 on success, -1 on failure. */
int avsp_supervisor_status(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint chip,          /**< [in] Chip on which to enable monitoring. */
    BOOL *enabled)      /**< [out] *enabled returns TRUE if monitor is running. */
{
    int return_code = aapl->return_code;
    uint addr = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
    uint data = 0x3400;
    uint val  = avago_spico_int(aapl, addr, 0x0026, data);
    *enabled = 0 != (val & 0x1000);
    aapl_log_printf(aapl,AVAGO_DEBUG6,__func__,__LINE__,"Chip %d, enabled=%s, status=0x%x\n", chip, aapl_bool_to_str(*enabled), val);
    return (return_code == aapl->return_code) ? 0 : -1;
}

/*============================================================================= */
/* A V S P   C L E A R   I N T E R R _ I O */
/* */
/** @brief    Clears the interr_io (interr_l) supervisor flag. */
/** @details  If the conditions for activating this flag continue to exist, and */
/**           monitoring is enabled, the pin will be immediately re-activated. */
/** @details  Note: The interr_io supervisor flag propagates to the hardware */
/**           pin via the core port and mdio state machine polling.  Core */
/**           port interrupts must be enabled for this propagation to occur. */
/** @return   0 on success, -1 on failure. */
int avsp_supervisor_clear_interr_io(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint    chip)   /**< [in] Chip upon which to operate. */
{
    uint addr = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
    uint data = 0x4700;
    uint val  = avago_spico_int(aapl, addr, 0x0026, data);
    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus %s, val=0x%x\n", aapl_addr_to_str(addr), val);
    return (val & 0x10) ? -1 : 0;
}

/** @brief    Reads the hardware interr_io (interr_l) supervisor flag. */
/** @return   0 on success, -1 on failure. */
int avsp_supervisor_get_interr_io(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint    chip,   /**< [in] Chip upon which to operate. */
    BOOL   *active) /**< [out] State of interr_io pin. */
{
    uint addr = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
    int return_code = aapl->return_code;
    int val = avago_spico_int(aapl, addr, 0x0026, 0x3700);
    *active = val & 1;
    return (return_code == aapl->return_code) ? 0 : -1;
}

static int avsp_get_serdes_count(Aapl_t *aapl, uint chip)
{
    uint addr = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
    const char *avsp_name = aapl_get_chip_name(aapl, addr);
    int serdes_count;
    if( EQS(avsp_name,"AVSP-1104") || EQS(avsp_name,"AVSP-9104") )
        serdes_count = 20;  /* x104 */
    else if( EQS(avsp_name,"AVSP-8812") )
        serdes_count = 16;   /* 8812 */
    else
        serdes_count = 8;   /* 4412/8801 */

    return serdes_count;
}


static void avsp_supervisor_clear_slice_participation(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint chip)      /**< [in] Port address of the targeted device. */
{
    int i;
    int serdes_count = avsp_get_serdes_count(aapl, chip);
    BOOL enabled = FALSE;
    uint addr = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));

    avsp_supervisor_status(aapl, chip, &enabled);
    if( enabled )
        avsp_supervisor_enable(aapl, chip, FALSE);

    for( i = 0; i < serdes_count; i++ )
    {
        int mem_addr = 0x0400 + 0x31 + 0x40 * i;
        /* Perform read-modify-write to clear RX polling enabled: */
        int status = avago_sbm_read_mem(aapl, addr, mem_addr);
        avago_sbm_write_mem(aapl, addr, mem_addr, status & ~0x20);
/*      printf("status[%d] = 0x%02x\n",i,status); */
    }

    if( enabled )
        avsp_supervisor_enable(aapl, chip, TRUE);
}

/** @return 0 on success, -1 on failure. */
static int write_state_memory(
    Aapl_t *aapl,   /**< [in] Pointer to Aapl_t structure. */
    uint addr,      /**< [in] SBM address. */
    uint select,    /**< [in] Supervisor SerDes selection. */
    int  mem,       /**< [in] Which memory location to write. */
    int  data)      /**< [in] Data to write. */
{
    int return_code = aapl->return_code;
    avago_spico_int(aapl, addr, 0x25, 0x00 | (select & 0x3f));
    avago_spico_int(aapl, addr, 0x25, 0x40 | (mem    & 0x3f));
    avago_spico_int(aapl, addr, 0x25, 0x80 | (data   & 0x7f));
    return (return_code == aapl->return_code) ? 0 : -1;
}

/** @details Set the slices participating in interr_io and self-healing monitoring. */
/** @return  0 on success, -1 on failure. */
int avsp_supervisor_set_slices(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint chip,          /**< [in] Port address of the targeted device. */
    int  count,         /**< [in] Count of entries in selection array. */
    uint *selection)    /**< [in] List of SerDes SBus addresses. */
                        /**< Valid values are any SerDes slice SBus */
                        /**<      address, or one of the handful of part */
                        /**<      specific broadcast addresses.  Bit[5] */
                        /**<      of selection indicates it's a broadcast. */
                        /**<      0x2F is always the global broadcast to */
                        /**<      target every slice. */
                        /**<      The 4412/8801 supports these broadcast selections: */
                        /**<      - 0x20 selects RPT channel SD0-SD4 */
                        /**<      - 0x21 selects RPT channel SD1-SD5 */
                        /**<      - 0x22 selects RPT channel SD2-SD6 */
                        /**<      - 0x23 selects RPT channel SD3-SD7 */
                        /**<      - 0x2F selects all slices */
                        /**<      The 1104 supports these broadcast selections: */
                        /**<      - 0x20 selects RPT channel H10G0-M25G0. */
                        /**<      - 0x21 selects RPT channel H10G1-M25G1. */
                        /**<      - 0x22 selects RPT channel H10G2-M25G2. */
                        /**<      - and so on through 0x29. */
                        /**<      - 0x2A selects all host slices. */
                        /**<      - 0x2B selects all 25G mod slices. */
                        /**<      - 0x2C selects all 10G mod slices. */
                        /**<      - 0x2D selects all mod slices. */
                        /**<      - 0x2E&0x2F select all slices. */
{
    uint addr = avago_make_sbus_master_addr(avago_make_addr3(chip,0,0));
    int i;
    avsp_supervisor_clear_slice_participation(aapl, chip);
    for( i = 0; i < count; i++ )
    {
        /* Add specified slice participation: */
        write_state_memory(aapl, addr, selection[i], 0x31, 0x60);
    }
    return 0;
}

/** @brief   Sets the signal OK threshold value for the device. */
/** @details Updates the state configuration in the supervisor, which applies */
/**          the updated values to the SerDes when it starts or heals a link. */
/** @return  0 on succes, -1 on failure. */
int avsp_supervisor_set_signal_ok(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint prtad,         /**< [in] Port address of the device. */
    uint select,        /**< [in] Supervisor SerDes selection. 0x2f=all. */
    int threshold)      /**< [in] Threshold for signal OK (0-15). */
{
    uint addr = avago_make_sbus_master_addr(avago_make_addr3(prtad,0,0));
    int thresh_reg = 0x2c;
    return write_state_memory(aapl, addr, select, thresh_reg, threshold & 0xf);
}

/** @brief   Initializes an AVSP supervisor structure to the given settings. */
/** @details Provides configuration options for how to initialize self-healing */
/**          features, including options for what to do on initial link bring */
/**          up, what to do on future link down events, and some independent */
/**          options. */
/** @return TRUE if mode is a valid value, FALSE otherwise. */
BOOL avsp_supervisor_config_init(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    Avsp_supervisor_mode_t mode,        /**< [in] Select a configuration mode. */
    BOOL squelch_tx,                    /**< [in] Squelch tx while rx data is bad. */
    BOOL reuse_ical,                    /**< [in] Reuse initial iCal values during signal recovery. */
    BOOL adaptive,                      /**< [in] Run continuous adaptive tuning during normal operation. */
    Avsp_supervisor_config_t *config)   /**< [out] Configuration to initialize. */
{
    memset(config,0,sizeof(*config));

    switch( mode )
    {
    case AVSP_SUPERVISOR_MODE_TUNE_IF_SIGNAL:
        config->assp_control_0 = 0x02;  /* Tune before flock */
        break;
    case AVSP_SUPERVISOR_MODE_TUNE_IF_LOCKED_SIGNAL:
        config->assp_control_0 = 0x00;  /* Tune after flock */
        break;
    case AVSP_SUPERVISOR_MODE_NO_TUNE:
        config->assp_control_0 = 0x20;  /* Skip all tuning. */
        break;
    default:
        aapl_fail(aapl, __func__,__LINE__,"Invalid mode value: %d\n",mode);
        return FALSE;
    }
    if( squelch_tx )
        config->assp_control_0 |= 0x04; /* Enable TX squelch. */
    if( reuse_ical )
        config->assp_control_0 |= 0x10; /* Enable reuse iCal. */
    if( adaptive )
        config->assp_control_0 |= 0x40; /* Enable adaptive. */

    config->assp_control_1 = 0x24;
    config->assp_control_2 = 0x00;
    config->assp_control_3 = 0x00;

    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"control = %x, %x, %x, %x\n",
        config->assp_control_0, config->assp_control_1,
        config->assp_control_2, config->assp_control_3);
    return TRUE;
}

/** @brief   Constructs an AVSP supervisor structure with the given settings. */
/** @details Provides configuration options for how to initialize self-healing */
/**          features, including options for what to do on initial link bring */
/**          up, what to do on future link down events, and some independent */
/**          options. */
/** */
/** @return  Allocated structure.  Call avago_supervisor_config_destruct() to free it. */
/** @see     avsp_supervisor_config_destruct(), avsp_supervisor_config_init(). */
Avsp_supervisor_config_t *avsp_supervisor_config_construct(
    Aapl_t *aapl,                   /**< [in] Pointer to Aapl_t structure. */
    Avsp_supervisor_mode_t mode,    /**< [in] Select a configuration mode. */
    BOOL squelch_tx,                /**< [in] Squelch tx while rx data is bad. */
    BOOL reuse_ical,                /**< [in] Reuse initial iCal values during signal recovery. */
    BOOL adaptive)                  /**< [in] Run continuous adaptive tuning during normal operation. */
{
    size_t bytes = sizeof(Avsp_supervisor_config_t);
    Avsp_supervisor_config_t *config = (Avsp_supervisor_config_t *) aapl_malloc(aapl, bytes, __func__);

    if( config == 0 )
        return NULL;

    aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "Construct supervisor state %d\n",mode);

    if( avsp_supervisor_config_init(aapl, mode, squelch_tx, reuse_ical, adaptive, config) )
        return config;

    avsp_supervisor_config_destruct(aapl, config);
    return NULL;
}

/** @brief   Releases the resources associated with #config. */
/** @see     avsp_supervisor_config_construct(). */
void avsp_supervisor_config_destruct(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    Avsp_supervisor_config_t *config)   /**< [in] Supervisor struct to destroy. */
{
    aapl_free(aapl, config, __func__);
}

/** @brief   Retrieves the supervisor configuration values. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avsp_supervisor_get_config(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    uint prtad,                         /**< [in] Port address of the device. */
    Avsp_supervisor_config_t *config)   /**< [out] Structure to hold results. */
{
    int return_code = aapl->return_code;
    uint addr = avago_make_sbus_master_addr(avago_make_addr3(prtad,0,0));
    int i;

    avsp_supervisor_status(aapl, prtad, &config->enabled);
    if( config->enabled )
        avsp_supervisor_enable(aapl, prtad, FALSE);

    config->assp_control_0 = avago_spico_int(aapl, addr, 0x26, 0x2200) & 0x7f;
    config->assp_control_1 = avago_spico_int(aapl, addr, 0x26, 0x2300) & 0x7f;
    config->assp_control_2 = avago_spico_int(aapl, addr, 0x26, 0x3200) & 0x7f;
    config->assp_control_3 = avago_spico_int(aapl, addr, 0x26, 0x3300) & 0x7f;

    if( config->enabled )
        config->assp_control_0 &= ~0x01;

    config->serdes_count = avsp_get_serdes_count(aapl, prtad);

    for( i = 0; i < config->serdes_count; i++ )
    {
        int mem_addr = 0x0400 + 0x40 * i;
        int reg31 = avago_sbm_read_mem(aapl, addr, mem_addr+0x31) & 0x007f;
        int reg32 = avago_sbm_read_mem(aapl, addr, mem_addr+0x32) & 0x1fff;
        int reg34 = avago_sbm_read_mem(aapl, addr, mem_addr+0x34) & 0x003f;
        config->status[i] = reg31 | (reg32 << 8) | (reg34 << 24);
        /*printf("slice %d (from memory 0x%03x): val = 0x%03x\n",i,mem_addr,val); */
    }
    avsp_supervisor_get_interr_io(aapl, prtad, &config->interr_io);
    if( config->enabled )
        avsp_supervisor_enable(aapl, prtad, TRUE);

    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"Chip %d, Config = (0x%02x, 0x%02x, 0x%02x, 0x%02x)\n",
        prtad, config->assp_control_0, config->assp_control_1, config->assp_control_2, config->assp_control_3);

    return (return_code == aapl->return_code) ? 0 : -1;
}

/** @brief   Sets the supervisor configuration. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avsp_supervisor_set_config(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    uint prtad,                         /**< [in] Port address of the device. */
    Avsp_supervisor_config_t *config)   /**< [in] Values to write to device. */
{
    int return_code = aapl->return_code;
    uint addr = avago_make_sbus_master_addr(avago_make_addr3(prtad,0,0));

    config->serdes_count = avsp_get_serdes_count(aapl, prtad);

    avsp_supervisor_enable(aapl, prtad, FALSE);
    avago_spico_int(aapl, addr, 0x26, 0x6200 | (config->assp_control_0 & 0xff));
    avago_spico_int(aapl, addr, 0x26, 0x6300 | (config->assp_control_1 & 0xff));
    avago_spico_int(aapl, addr, 0x26, 0x7200 | (config->assp_control_2 & 0xff));
    avago_spico_int(aapl, addr, 0x26, 0x7300 | (config->assp_control_3 & 0xff));

    if( (config->assp_control_0 & 1) == 0 )  /* bit 0 disables polling */
        avsp_supervisor_enable(aapl, prtad, TRUE);

    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"Chip %d, Config = (0x%02x, 0x%02x, 0x%02x, 0x%02x)\n",
        prtad, config->assp_control_0, config->assp_control_1, config->assp_control_2, config->assp_control_3);
    return (return_code == aapl->return_code) ? 0 : -1;
}

/** @} */


/** @brief   Tells the user is self healing is enabled. */
/** @return  TRUE if it is running, FALSE otherwise */
BOOL avsp_get_self_healing(Aapl_t *aapl, uint prtad)
{
    uint addr = avago_make_sbus_master_addr(avago_make_addr3(prtad,0,0));
    if (avago_spico_int(aapl, addr, 0x26, 0x3500) & 0x1fff) return TRUE;
    return FALSE;
}

/** @brief   Allows the user to enable/disable self healing */
void avsp_set_self_healing(Aapl_t *aapl, uint prtad, BOOL self_heal_enable)
{
    uint addr = avago_make_sbus_master_addr(avago_make_addr3(prtad,0,0));
    if (self_heal_enable) avago_spico_int(aapl, addr, 0x26, 0x4400);
    else                  avago_spico_int(aapl, addr, 0x26, 0x4500);
}

#endif /* AAPL_ENABLE_AVSP */

