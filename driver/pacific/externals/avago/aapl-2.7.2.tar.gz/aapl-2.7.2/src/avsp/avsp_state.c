/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* avsp_state.c */

/** Doxygen File Header */
/** @file */
/** @brief Functions for reading, writing and saving AVSP state. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#define AAPL_USE_MDIO_WRITES 0

#define AAPL_ENABLE_AVSP_STATE_MIN AAPL_ENABLE_AVSP_STATE || AAPL_ENABLE_AVSP

#if AAPL_ENABLE_AVSP_STATE_MIN

#define PROD_IMEM_MAGIC_NUM0_E (0x312)  /* 4412/8801 */
#define PROD_IMEM_MAGIC_NUM0_O (0x11e)  /* 4412/8801 */
#define PROD_IMEM_MAGIC_NUM0_V (0x18c)  /* 1104 */
#define PROD_IMEM_MAGIC_NUM0_M (0x24d)  /* 9104 */
#define PROD_IMEM_MAGIC_NUM1_E (0x1bc)  /* 4412/8801 */
#define PROD_IMEM_MAGIC_NUM1_O (0x10f)  /* 4412/8801 */
#define PROD_IMEM_MAGIC_NUM1_V (0x064)  /* 1104 */
#define PROD_IMEM_MAGIC_NUM1_M (0x315)  /* 9104 */
#define ASSP_IMEM_MAGIC_NUM    (0x3a1)
#define MDIO_IMEM_MAGIC_NUM    (0x25f)

#define XDMEM_TABLE_BASE_ADDR  (0x400)

#define EQS(str1,str2) (0==strcmp(str1,str2))

static int last_active_index_read  = 0x2d;
static int last_active_index_write = 0x2d;
int v2_type_sel_7412        = 0x28;
/** @cond INTERNAL */
typedef void (*Avago_state_tx_rx_fn_t)(Aapl_t *aapl, void *user, Avago_serdes_tx_state_t *tx, Avago_serdes_rx_state_t *rx);
/** @endcond */

/* Return 0 on success, -1 on error. */
static int process_serdes_state(
    Aapl_t *aapl,               /**< Pointer to Aapl_t structure. */
    Avago_state_tx_rx_fn_t fn,  /**< Function pointer */
    void *user_ptr,             /**< User pointer */
    Avsp_state_t *state)        /**< State structure to update. */
{
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__,__LINE__,"Processing AVSP-%d/%s\n", state->device, aapl_avsp_mode_to_str(state->mode));
    if( state == 0 )
        return aapl_fail(aapl, __func__, __LINE__, "ERROR: state parameter is NULL\n");

    if(    (state->mode == AVSP_REPEATER_DUPLEX)
        || (state->mode == AVSP_REPEATER_SIMPLEX)
        || (state->mode == AVSP_GEARBOX_10_4                         && (state->device == 9104 || state->device == 1104))
#if AAPL_ENABLE_AVSP_9104
        || (state->mode == AVSP_GEARBOX_10_4_RS_FEC                  &&  state->device == 9104)
        || (state->mode == AVSP_GEARBOX_10_4_MLG                     &&  state->device == 9104)
#endif
#if AAPL_ENABLE_AVSP_8812
        || (state->u.a8812.half_mode[0] == AVSP_GEARBOX_2_1          &&  state->device == 8812)
        || (state->u.a8812.half_mode[1] == AVSP_GEARBOX_2_1          &&  state->device == 8812)
        || (state->u.a8812.half_mode[0] == AVSP_REPEATER_DUPLEX      &&  state->device == 8812)
        || (state->u.a8812.half_mode[1] == AVSP_REPEATER_DUPLEX      &&  state->device == 8812)
        || (state->u.a8812.half_mode[0] == AVSP_GEARBOX_2_1_MOD_HOST &&  state->device == 8812)
        || (state->u.a8812.half_mode[1] == AVSP_GEARBOX_2_1_MOD_HOST &&  state->device == 8812)
        || (state->u.a8812.half_mode[0] == AVSP_RS_FEC_4x4           &&  state->device == 8812)
        || (state->u.a8812.half_mode[1] == AVSP_RS_FEC_4x4           &&  state->device == 8812)
#endif
#if AAPL_ENABLE_AVSP_7412
        || (state->mode == AVSP_RS_FEC_528                           &&  state->device == 7412)
        || (state->mode == AVSP_RS_FEC_544                           &&  state->device == 7412)
        || (state->mode == AVSP_GEARBOX_2_1                          &&  state->device == 7412)
        || (state->mode == AVSP_ADHOC)
#endif
#if AAPL_ENABLE_AVSP_5410
        || (state->mode == AVSP_GEARBOX_4_1                          &&  state->device == 5410)
        || (state->mode == AVSP_RS_FEC                               &&  state->device == 5410)
#endif
        )
    {
        uint i;
        for( i = 0; i < state->serdes_count; i++ )
             fn(aapl, user_ptr, &state->serdes[i].tx, &state->serdes[i].rx);
        return 0;
    }
    return aapl_fail(aapl, __func__, __LINE__, "Support for device AVSP-%d in %s mode not implemented.\n",
            state->device, aapl_avsp_mode_to_str(state->mode));
}

static void init_rx_serdes_state(Avago_serdes_rx_state_t *rx, uint addr)
{
    rx->sbus_addr           = addr;
    rx->divider             = 10;
    rx->width               = 20;
    rx->encoding         = AVAGO_SERDES_NRZ;
    rx->enable              = TRUE;
    rx->polarity_invert     = FALSE;
    rx->input_loopback      = FALSE;
    rx->pcs_fifo_clk_divider= AVAGO_SERDES_PCS_FIFO_F66;
    rx->term                = AVAGO_SERDES_RX_TERM_AVDD;
    rx->cmp_data            = AVAGO_SERDES_RX_CMP_DATA_PRBS7;
    rx->cmp_mode            = AVAGO_SERDES_RX_CMP_MODE_OFF;
    rx->signal_ok_enable    = TRUE;
    rx->signal_ok_threshold = 3;
    rx->phase_slip          = 0x10;

    rx->signal_ok           = FALSE;    /* Status, not state */
    rx->data_qual           = AVAGO_SERDES_RX_DATA_QUAL_UNQUAL; /* Status */
    rx->bypass_ctle         = FALSE;    /* Directive, not state, but we try */
    rx->run_vsr_tune        = FALSE;    /* Directive, not state, but we try */
    rx->run_ical            = FALSE;    /* Directive, not state, but we try */
    rx->run_pcal            = FALSE;    /* Directive, not state, but we try */
    rx->run_adaptive        = FALSE;    /* Directive, not state, but we try */

    rx->dfe.dc              =  56;
    rx->dfe.lf              =  15;
 /* rx->dfe.lf              =  12; */
    rx->dfe.hf              =   0;
    rx->dfe.bw              =   0;
 /* rx->dfe.bw              =  13; */
    rx->dfe.dfeGAIN_min     =   0;
    rx->dfe.dfeGAIN_max     =  15;
    rx->dfe.dwell_bits      = 0x00010001;
    rx->dfe.error_threshold =   4;

    rx->flags               = 0;    /* bookkeeping */
}

static void init_tx_serdes_state(Avago_serdes_tx_state_t *tx, uint addr)
{
    tx->sbus_addr           = addr;
    tx->divider             = 10;
    tx->width               = 20;
    tx->encoding         = AVAGO_SERDES_NRZ;
    tx->enable              = TRUE;
    tx->polarity_invert     = FALSE;
    tx->output_enable       = TRUE;
    tx->pll_clk_source      = AVAGO_SERDES_TX_PLL_REFCLK;
    tx->data_sel            = AVAGO_SERDES_TX_DATA_SEL_CORE;
    tx->eq.pre              = 0;
    tx->eq.atten            = 0;
    tx->eq.post             = 0;
    tx->eq.slew             = 0;
/*  tx->thermal_mask        = 0; */
}

#if AAPL_ENABLE_AVSP_1104
static BOOL init_1104_state(Aapl_t *aapl, Avsp_state_t *state)
{
    uint *addrs;
    uint n;
    state->magic[0] = PROD_IMEM_MAGIC_NUM0_V;
    state->magic[1] = PROD_IMEM_MAGIC_NUM1_V;
    state->magic[2] = ASSP_IMEM_MAGIC_NUM;
    state->magic[3] = MDIO_IMEM_MAGIC_NUM;
    state->device_var1     = 9;     /* host_clk_sel, [0-9] (9 is accessible on test boards) */
    state->device_var2     = 3;     /* mod_clk_sel,  [0-3] (3 is accessible on test boards) */
    state->device_var3     = 0x0f;  /* speed select, Only valid value */
    state->assp_control[2] = 0;     /* Reserved */
    state->assp_control[3] = 0;     /* Reserved */
    state->prod_var_cnt    = 6;     /* 6 for 1104, 0 otherwise. */
    state->device = 1104;

    aapl_get_addr_list(aapl, state->prtad, "AVSP-1104", AVSP_ALL, &state->serdes_count, &addrs);

    for( n = 0; n < state->serdes_count; n++ )
    {
        init_rx_serdes_state(&state->serdes[n].rx, addrs[n]);
        init_tx_serdes_state(&state->serdes[n].tx, addrs[n]);
        state->serdes[n].rx.mem_addr = XDMEM_TABLE_BASE_ADDR + 64 * n;
    }

    avsp_state_set_divider(aapl, state, 66);

    /* Initialize a 10:4 multiplexer / 4:10 demultiplexer: */
    if( state->mode == AVSP_GEARBOX_10_4 )
    {
        /* Override any values from the init functions: */
        for( n = 0; n < state->serdes_count; n++ )
        {
            Avago_serdes_rx_state_t *rx = &state->serdes[n].rx;
            Avago_serdes_tx_state_t *tx = &state->serdes[n].tx;

            rx->pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;
            rx->phase_slip = 0x12;

            tx->pll_clk_source = AVAGO_SERDES_TX_PLL_PCIE_CORE_CLK;
            tx->data_sel = AVAGO_SERDES_TX_DATA_SEL_CORE;
            if( n >= 14 )       /* Turn off MOD6 slices */
                rx->enable = tx->enable = FALSE;
        }
    }

    else /* Initialize a 10-to-10 bidirectional retimer / repeater: */
    {
        Avsp_1104_state_t *st = &state->u.a1104;
        state->mode = AVSP_REPEATER_DUPLEX;
        /* Override any values from the init functions: */
        for( n = 0; n < state->serdes_count; n++ )
        {
            Avago_serdes_rx_state_t *rx = &state->serdes[n].rx;
            Avago_serdes_tx_state_t *tx = &state->serdes[n].tx;

            rx->pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;

            tx->pll_clk_source = AVAGO_SERDES_TX_PLL_PCIE_CORE_CLK;
            tx->data_sel = AVAGO_SERDES_TX_DATA_SEL_CORE;
        }

        /* Map links to SerDes: */
        st->link_cnt = state->serdes_count / 2;
        for( n = 0; n < st->link_cnt; n++ )
        {
            /* SerDes n:          Host SerDes: host_rx --> host_tx */
            /* SerDes mod_tbl[n]: Mod  SerDes: mod_rx  --> mod_tx */
            st->link[n].host_rx = &state->serdes[n].rx;
            st->link[n].host_tx = &state->serdes[n].tx;
            st->link[n].mod_rx = &state->serdes[n + st->link_cnt].rx;
            st->link[n].mod_tx = &state->serdes[n + st->link_cnt].tx;
        }
    }
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "port=%u, mode=%s\n", state->prtad, aapl_avsp_mode_to_str(state->mode));
    return TRUE;
}
#endif /* AAPL_ENABLE_AVSP_1104 */

#if AAPL_ENABLE_AVSP_9104
static BOOL init_9104_state(Aapl_t *aapl, Avsp_state_t *state)
{
    char a9104_slip_table[20] = { 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10,
                                  0x0b, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0b, 0x12, 0x11 };
    uint *addrs;
    uint n;
    int dynamic_signal_ok_threshold = state->serdes[0].rx.signal_ok_threshold;
    uint sbm_addr = avago_make_sbus_master_addr(state->serdes[0].rx.sbus_addr);
    state->magic[0] = PROD_IMEM_MAGIC_NUM0_M;
    state->magic[1] = PROD_IMEM_MAGIC_NUM1_M;
    state->magic[2] = ASSP_IMEM_MAGIC_NUM;
    state->magic[3] = MDIO_IMEM_MAGIC_NUM;
    state->device_var1     = 9;     /* host_clk_sel, [0-9] (9 is accessible on test boards) */
    state->device_var2     = 3;     /* mod_clk_sel,  [0-3] (3 is accessible on test boards) */
    state->device_var3     = 0x0f;  /* speed select, Only valid value */
    state->assp_control[2] = 16;    /* Reserved */
    state->assp_control[3] = 2;     /* Reserved */
    state->prod_var_cnt    = 6;     /* 6 for 1104, 0 otherwise. */
    state->device = 9104;

    if( aapl_check_firmware_rev(aapl, sbm_addr, 0, 0, FALSE,1,0x1015) )
        dynamic_signal_ok_threshold = 0;

    aapl_get_addr_list(aapl, state->prtad, "AVSP-9104", AVSP_ALL, &state->serdes_count, &addrs);

    for( n = 0; n < state->serdes_count; n++ )
    {
        init_rx_serdes_state(&state->serdes[n].rx, addrs[n]);
        init_tx_serdes_state(&state->serdes[n].tx, addrs[n]);
        state->serdes[n].rx.mem_addr = XDMEM_TABLE_BASE_ADDR + 64 * n;
        state->serdes[n].rx.phase_slip = a9104_slip_table[n];
    }

    avsp_state_set_divider(aapl, state, 66);

    if( aapl_check_firmware_rev(aapl, sbm_addr, 0, 0, FALSE,1,0x1015) )
        state->device_var1     = 7;

    /* Initialize a 10:4 multiplexer / 4:10 demultiplexer: */
    if( state->mode == AVSP_GEARBOX_10_4 )
    {
        if( aapl_check_firmware_rev(aapl, sbm_addr, 0, 0, FALSE,1,0x1015) )
            state->assp_control[2] = state->assp_control[3] = 0;

        /* Override any values from the init functions: */
        for( n = 0; n < state->serdes_count; n++ )
        {
            Avago_serdes_rx_state_t *rx = &state->serdes[n].rx;
            Avago_serdes_tx_state_t *tx = &state->serdes[n].tx;

            rx->pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;

            tx->pll_clk_source = AVAGO_SERDES_TX_PLL_PCIE_CORE_CLK;
            tx->data_sel = AVAGO_SERDES_TX_DATA_SEL_CORE;
            if( n >= 14 )       /* Turn off MOD6 slices */
            {
                rx->phase_slip = 0x0e;
                rx->enable = tx->enable = FALSE;
            }
            else if( n >= 10 )  /* Put MOD4 slices into 40 bit mode */
            {
                rx->width = tx->width = 40;
                rx->phase_slip = 0x14;
            }
        }
    }
    else if( state->mode == AVSP_GEARBOX_10_4_RS_FEC )
    {
        if( aapl_check_firmware_rev(aapl, sbm_addr, 0, 0, FALSE,1,0x101D) )
            state->assp_control[2] = 28;
        /* Override any values from the init functions: */
        for( n = 0; n < state->serdes_count; n++ )
        {
            Avago_serdes_rx_state_t *rx = &state->serdes[n].rx;
            Avago_serdes_tx_state_t *tx = &state->serdes[n].tx;

            rx->pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F66;
            rx->signal_ok_threshold = dynamic_signal_ok_threshold;

            tx->pll_clk_source = AVAGO_SERDES_TX_PLL_PCIE_CORE_CLK;
            tx->data_sel = AVAGO_SERDES_TX_DATA_SEL_CORE;
            if( n == 17 )
                rx->enable = FALSE;
            else if( n >= 14 )       /* Turn off MOD6 slices */
            {
                rx->phase_slip = 0xd;
                rx->enable = tx->enable = FALSE;
            }
            else if( n >= 10 )  /* Put MOD4 slices into 40 bit mode */
            {
                rx->width = tx->width = 40;
                rx->phase_slip = 0xf;
            }
        }
    }
    else if( state->mode == AVSP_GEARBOX_10_4_MLG )
    {
        state->assp_control[2] = state->assp_control[3] = 0;

        /* Override any values from the init functions: */
        for( n = 0; n < state->serdes_count; n++ )
        {
            Avago_serdes_rx_state_t *rx = &state->serdes[n].rx;
            Avago_serdes_tx_state_t *tx = &state->serdes[n].tx;

            rx->cmp_mode = AVAGO_SERDES_RX_CMP_MODE_XOR;
            rx->dfe.bw = 13;
            rx->dfe.lf = 12;
            rx->pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F66;

            tx->pll_clk_source = AVAGO_SERDES_TX_PLL_REFCLK;
            tx->data_sel = AVAGO_SERDES_TX_DATA_SEL_CORE;
            if( n >= 14 )      /* Turn off most MOD6 slices */
            {
                rx->phase_slip = 0xd;
                if( n != 14 && n != 17 )
                    rx->enable = tx->enable = FALSE;
                else
                {
                    rx->input_loopback = TRUE;
                    rx->term     = AVAGO_SERDES_RX_TERM_AVDD;
                    rx->cmp_data = AVAGO_SERDES_RX_CMP_DATA_PRBS31;
                    rx->cmp_mode = AVAGO_SERDES_RX_CMP_MODE_MAIN_PATGEN;
                }
                tx->data_sel = AVAGO_SERDES_TX_DATA_SEL_PRBS31;
            }
            else if( n >= 10 )  /* Put MOD4 slices into 40 bit mode */
            {
                rx->width = tx->width = 40;
                rx->phase_slip = 0xf;
            }
        }
    }

    /* Initialize a 10-to-10 bidirectional retimer / repeater: */
    else
    {
        Avsp_9104_state_t *st = &state->u.a9104;
        state->mode = AVSP_REPEATER_DUPLEX;

        if( aapl_check_firmware_rev(aapl, sbm_addr, 0, 0, FALSE,1,0x1015) )
            state->assp_control[2] = state->assp_control[3] = 0;

        /* Override any values from the init functions: */
        for( n = 0; n < state->serdes_count; n++ )
        {
            Avago_serdes_rx_state_t *rx = &state->serdes[n].rx;
            Avago_serdes_tx_state_t *tx = &state->serdes[n].tx;

            rx->pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;

            tx->pll_clk_source = AVAGO_SERDES_TX_PLL_PCIE_CORE_CLK;
            tx->data_sel = AVAGO_SERDES_TX_DATA_SEL_CORE;
        }

        /* Map links to SerDes: */
        st->link_cnt = state->serdes_count / 2;
        for( n = 0; n < st->link_cnt; n++ )
        {
            /* SerDes n:          Host SerDes: host_rx --> host_tx */
            /* SerDes mod_tbl[n]: Mod  SerDes: mod_rx  --> mod_tx */
            st->link[n].host_rx = &state->serdes[n].rx;
            st->link[n].host_tx = &state->serdes[n].tx;
            st->link[n].mod_rx = &state->serdes[n + st->link_cnt].rx;
            st->link[n].mod_tx = &state->serdes[n + st->link_cnt].tx;
        }
    }
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "port=%u, mode=%s\n", state->prtad, aapl_avsp_mode_to_str(state->mode));
    return TRUE;
}
#endif /* AAPL_ENABLE_AVSP_9104 */


#if AAPL_ENABLE_AVSP_4412
/* Initialize a 4-to-4 bidirectional retimer / repeater: */
static BOOL init_4412_state(Aapl_t *aapl, Avsp_state_t *state)
{
    uint *addrs;
    uint n;
    Avsp_4412_state_t *st = &state->u.a4412;
    uint sbm_addr = avago_make_sbus_master_addr(state->serdes[0].rx.sbus_addr);

    state->mode = AVSP_REPEATER_DUPLEX;
    state->magic[0] = PROD_IMEM_MAGIC_NUM0_E;
    state->magic[1] = PROD_IMEM_MAGIC_NUM1_E;
    state->magic[2] = ASSP_IMEM_MAGIC_NUM;
    state->magic[3] = MDIO_IMEM_MAGIC_NUM;
    state->device = 4412;
    aapl_get_addr_list(aapl, state->prtad, "AVSP-4412/8801", AVSP_ALL, &state->serdes_count, &addrs);

    for( n = 0; n < state->serdes_count; n++ )
    {
        init_rx_serdes_state(&state->serdes[n].rx, addrs[n]);
        init_tx_serdes_state(&state->serdes[n].tx, addrs[n]);
        state->serdes[n].rx.mem_addr = XDMEM_TABLE_BASE_ADDR + 64 * n;
        state->serdes[n].tx.pll_clk_source = AVAGO_SERDES_TX_PLL_RX_DIVX;
        state->serdes[n].tx.data_sel = AVAGO_SERDES_TX_DATA_SEL_LOOPBACK;
        state->serdes[n].tx.output_enable = FALSE;
        if( aapl_check_firmware_rev(aapl, sbm_addr, 0, 0, FALSE, 1, 0x1018) )
            state->serdes[n].tx.output_enable = TRUE;
    }

    /* Map links to sbus addresses: */
    st->link_cnt = state->serdes_count / 2;
    for( n = 0; n < st->link_cnt; n++ )
    {
        /* SerDes n:   host_rx --> mod_tx */
        /* SerDes n+4: host_tx <-- mod_rx */
        st->link[n].host_rx = &state->serdes[n].rx;
        st->link[n].mod_tx = &state->serdes[n].tx;
        st->link[n].mod_rx = &state->serdes[n + st->link_cnt].rx;
        st->link[n].host_tx = &state->serdes[n + st->link_cnt].tx;
    }
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "port=%u, mode=DUPLEX\n", state->prtad);
    return TRUE;
}
#endif /* AAPL_ENABLE_AVSP_4412 */

#if AAPL_ENABLE_AVSP_7412
/* Initialize a 16-to-16 uni- / 8-to-8 bi-directional retimer/repeater: */
static BOOL init_7412_state(Aapl_t *aapl, Avsp_state_t *state)
{
    uint *addrs;
    uint n;
    char a7412_slip_table20[16] = { 15,  5, 15, 15, 15, 15, 15, 15,
                                    15, 15, 15, 15, 15, 15, 15, 15 };
    char a7412_slip_table40[16] = { 20, 12, 20, 20, 20, 20, 20, 20,
                                    25, 25, 25, 25, 25, 25, 25, 25 };


    Avsp_7412_state_t *st = &state->u.a7412;
    state->magic[0] = PROD_IMEM_MAGIC_NUM0_O;
    state->magic[1] = PROD_IMEM_MAGIC_NUM1_O;
    state->magic[2] = ASSP_IMEM_MAGIC_NUM;
    state->magic[3] = MDIO_IMEM_MAGIC_NUM;
    state->device_var1     = 0;     /* applicable only to 9104 */
    state->device_var2     = 0;     /* applicable only to 9104 */
    state->device_var3     = 0x0f;  /* speed select, Only valid value */
    state->assp_control[2] = 16;    /* Reserved */
    state->assp_control[3] = 2;     /* Reserved */
    state->prod_var_cnt    = 6;
    state->device = 7412;


    aapl_get_addr_list(aapl, state->prtad, "AVSP-7412", AVSP_ALL, &state->serdes_count, &addrs);

    for( n = 0; n < state->serdes_count; n++ )
    {
        /* Configure mode-agnostic values: */
        init_rx_serdes_state(&state->serdes[n].rx, addrs[n]);
        init_tx_serdes_state(&state->serdes[n].tx, addrs[n]);
        state->serdes[n].rx.mem_addr = XDMEM_TABLE_BASE_ADDR + 64 * n;
        state->serdes[n].tx.pll_clk_source = AVAGO_SERDES_TX_PLL_PCIE_CORE_CLK;
        state->serdes[n].tx.data_sel = AVAGO_SERDES_TX_DATA_SEL_CORE;
        state->serdes[n].tx.output_enable = TRUE;
        state->serdes[n].tx.sd_num = n;
    }
    avsp_state_set_divider(aapl, state, 66);

    if( state->mode == AVSP_REPEATER_DUPLEX ) /* Repeater mode */
    {
        for( n = 0; n < state->serdes_count; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 40;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;
            state->serdes[n].rx.phase_slip = a7412_slip_table40[n];
        }
    }
    else if( state->mode == AVSP_RS_FEC_528 )    /* FEC */
    {
        for( n = 0; n < state->serdes_count; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 40;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F66;
            state->serdes[n].rx.phase_slip = a7412_slip_table40[n];
        }
    }
    else if( state->mode == AVSP_RS_FEC_544 )    /* FEC */
    {
        state->serdes[0].rx.width = state->serdes[0].tx.width = 40;
        state->serdes[0].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F66;
        state->serdes[0].rx.phase_slip = a7412_slip_table40[n];
        state->serdes[0].rx.phase_slip = a7412_slip_table40[n];
        state->serdes[0].rx.encoding = state->serdes[0].tx.encoding = AVAGO_SERDES_PAM2;
        for( n = 1; n < state->serdes_count; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 80;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F66;
            state->serdes[n].rx.phase_slip = a7412_slip_table40[n];
            state->serdes[0].rx.encoding = state->serdes[0].tx.encoding = AVAGO_SERDES_PAM4;
        }
    }
    else if( state->mode == AVSP_GEARBOX_2_1 )    /* Gearbox in 2:1 mode */
    {
        for( n = 0; n < 4; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 20;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;
            state->serdes[n].rx.phase_slip = a7412_slip_table20[n];
        }
        for( n = 4; n < 6; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 40;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;
            state->serdes[n].rx.phase_slip = a7412_slip_table40[n];
        }
    }
    /* Map links to sbus addresses: */
    st->link_cnt = state->serdes_count / 2;
    for( n = 0; n < st->link_cnt; n++ )
    {
        /* SerDes n <--> SerDes n+8 */
        st->link[n].host_rx = &state->serdes[n].rx;
        st->link[n].host_tx = &state->serdes[n].tx;
        st->link[n].mod_tx = &state->serdes[n + st->link_cnt].tx;
        st->link[n].mod_rx = &state->serdes[n + st->link_cnt].rx;
    }
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "port=%u, mode=%s\n", state->prtad, aapl_avsp_mode_to_str(state->mode));
    return TRUE;
}
#endif /* AAPL_ENABLE_AVSP_7412 */
#if AAPL_ENABLE_AVSP_8801
/* Initialize an 8-to-8 unidirectional retimer / repeater: */
static BOOL init_8801_state(Aapl_t *aapl, Avsp_state_t *state)
{
    uint *addrs;
    uint n;
    Avsp_8801_state_t *st = &state->u.a8801;
    uint sbm_addr = avago_make_sbus_master_addr(state->serdes[0].rx.sbus_addr);

    state->mode = AVSP_REPEATER_SIMPLEX;
    state->magic[0] = PROD_IMEM_MAGIC_NUM0_E;
    state->magic[1] = PROD_IMEM_MAGIC_NUM1_E;
    state->magic[2] = ASSP_IMEM_MAGIC_NUM;
    state->magic[3] = MDIO_IMEM_MAGIC_NUM;
    state->device = 8801;

    aapl_get_addr_list(aapl, state->prtad, "AVSP-4412/8801", AVSP_ALL, &state->serdes_count, &addrs);

    for( n = 0; n < state->serdes_count; n++ )
    {
        init_rx_serdes_state(&state->serdes[n].rx, addrs[n]);
        init_tx_serdes_state(&state->serdes[n].tx, addrs[n]);
        state->serdes[n].rx.mem_addr = XDMEM_TABLE_BASE_ADDR + 64 * n;
        state->serdes[n].tx.pll_clk_source = AVAGO_SERDES_TX_PLL_RX_DIVX;
        state->serdes[n].tx.data_sel = AVAGO_SERDES_TX_DATA_SEL_LOOPBACK;
        state->serdes[n].tx.output_enable = FALSE;
        if( aapl_check_firmware_rev(aapl, sbm_addr, 0, 0, FALSE, 1, 0x1018) )
            state->serdes[n].tx.output_enable = TRUE;
    }

    /* Map links to SerDes: */
    st->link_cnt = state->serdes_count;
    for( n = 0; n < st->link_cnt; n++ )
    {
        /* SerDes n: rx --> tx */
        st->link[n].rx = &state->serdes[n].rx;
        st->link[n].tx = &state->serdes[n].tx;
    }
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "port=%u, mode=SIMPLEX\n", state->prtad);
    return TRUE;
}
#endif /* AAPL_ENABLE_AVSP_8801 */

#if AAPL_ENABLE_AVSP_8812
/* Initialize a 16-to-16 uni- / 8-to-8 bi-directional retimer/repeater: */
static BOOL init_8812_state(Aapl_t *aapl, Avsp_state_t *state)
{
    uint *addrs;
    uint n;
    Avsp_8812_state_t *st = &state->u.a8812;
    last_active_index_read  = 0x2d;
    last_active_index_write = 0x2d;
    state->magic[0] = PROD_IMEM_MAGIC_NUM0_E;
    state->magic[1] = PROD_IMEM_MAGIC_NUM1_E;
    state->magic[2] = ASSP_IMEM_MAGIC_NUM;
    state->magic[3] = MDIO_IMEM_MAGIC_NUM;
    state->device_var1     = 9;     /* host_clk_sel, [0-9] (9 is accessible on test boards) */
    state->device_var2     = 3;     /* mod_clk_sel,  [0-3] (3 is accessible on test boards) */
    state->device_var3     = 0x0f;  /* speed select, Only valid value */
    state->prod_var_cnt    = 6;     /* 6 for 1104, 0 otherwise. */
    state->device = 8812;
    aapl_get_addr_list(aapl, state->prtad, "AVSP-8812", AVSP_ALL, &state->serdes_count, &addrs);

    for( n = 0; n < state->serdes_count; n++ )
    {
        /* Configure mode-agnostic values: */
        init_rx_serdes_state(&state->serdes[n].rx, addrs[n]);
        init_tx_serdes_state(&state->serdes[n].tx, addrs[n]);
        state->serdes[n].rx.mem_addr = XDMEM_TABLE_BASE_ADDR + 64 * n;
        state->serdes[n].tx.pll_clk_source = AVAGO_SERDES_TX_PLL_PCIE_CORE_CLK;
        state->serdes[n].tx.data_sel = AVAGO_SERDES_TX_DATA_SEL_CORE;
        state->serdes[n].tx.output_enable = TRUE;
        state->serdes[n].tx.source_rx = (n + 8) & 0xf;  /* repeater */
        state->serdes[n].tx.sd_num = n;
    }
    /* Configure mode-specific values: */
    /*avsp_8812_configure_half(aapl, state, state->mode, 66, 0); */
    /*avsp_8812_configure_half(aapl, state, state->mode, 66, 1); */

    /* Map links to sbus addresses: */
    st->link_cnt = state->serdes_count / 2;
    for( n = 0; n < st->link_cnt; n++ )
    {
        /* SerDes n <--> SerDes n+8 */
        st->link[n].host_rx = &state->serdes[n].rx;
        st->link[n].host_tx = &state->serdes[n].tx;
        st->link[n].mod_tx = &state->serdes[n + st->link_cnt].tx;
        st->link[n].mod_rx = &state->serdes[n + st->link_cnt].rx;
    }
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "port=%u, mode=%s\n", state->prtad, aapl_avsp_mode_to_str(state->mode));
    return TRUE;
}
#endif /* AAPL_ENABLE_AVSP_8812 */

#if AAPL_ENABLE_AVSP_5410
static BOOL init_5410_state(Aapl_t *aapl, Avsp_state_t *state)
{
    uint *addrs;
    uint n;
    char a5410_slip_table20[16] = { 15,  5, 15, 15, 15, 15, 15, 15,
                                    15, 15, 15, 15, 15, 15, 15, 15 };
    char a5410_slip_table40[16] = { 20, 12, 20, 20, 20, 20, 20, 20,
                                    25, 25, 25, 25, 25, 25, 25, 25 };
    Avsp_5410_state_t *st = &state->u.a5410;
    state->magic[0] = PROD_IMEM_MAGIC_NUM0_M;
    state->magic[1] = PROD_IMEM_MAGIC_NUM1_M;
    state->magic[2] = ASSP_IMEM_MAGIC_NUM;
    state->magic[3] = MDIO_IMEM_MAGIC_NUM;
    state->device_var1     = 7;     /* applicable only to 9104 */
    state->device_var2     = 3;     /* applicable only to 9104 */
    state->device_var3     = 0x0f;  /* speed select, Only valid value */
    state->assp_control[2] = 0;    /* Reserved */
    state->assp_control[3] = 0;     /* Reserved */
    state->prod_var_cnt    = 6;
    state->device = 5410;
    aapl_get_addr_list(aapl, state->prtad, "AVSP-5410", AVSP_ALL, &state->serdes_count, &addrs);
    for( n = 0; n < state->serdes_count; n++ )
    {
        /* Configure mode-agnostic values: */
        init_rx_serdes_state(&state->serdes[n].rx, addrs[n]);
        init_tx_serdes_state(&state->serdes[n].tx, addrs[n]);
        state->serdes[n].rx.mem_addr = XDMEM_TABLE_BASE_ADDR + 64 * n;
        state->serdes[n].tx.pll_clk_source = AVAGO_SERDES_TX_PLL_PCIE_CORE_CLK;
        state->serdes[n].tx.data_sel = AVAGO_SERDES_TX_DATA_SEL_CORE;
        state->serdes[n].tx.output_enable = TRUE;
        state->serdes[n].tx.sd_num = n;
    }
    avsp_state_set_divider(aapl, state, 66);

    if( state->mode == AVSP_REPEATER_DUPLEX ) /* Repeater mode */
    {
        for( n = 0; n < state->serdes_count; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 40;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;
            state->serdes[n].rx.phase_slip = a5410_slip_table40[n];
        }
    }
    else if( state->mode == AVSP_RS_FEC )    /* FEC */
    {
        for( n = 0; n < 4; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 20;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F66;
            state->serdes[n].rx.phase_slip = a5410_slip_table20[n];
        }
        for( n = 4; n < 5; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 40;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F66;
            state->serdes[n].rx.phase_slip = a5410_slip_table40[n];
        }
    }
    else if( state->mode == AVSP_GEARBOX_4_1 )    /* Gearbox in 4:1 mode */
    {
        for( n = 0; n < 4; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 20;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;
            state->serdes[n].rx.phase_slip = a5410_slip_table20[n];
        }
        for( n = 4; n < 5; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 40;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;
            state->serdes[n].rx.phase_slip = a5410_slip_table40[n];
        }
    }

    for( n = 0; n < state->serdes_count; n++ )
    {
        /* Configure mode-agnostic values: */
        init_rx_serdes_state(&state->serdes[n].rx, addrs[n]);
        init_tx_serdes_state(&state->serdes[n].tx, addrs[n]);
        state->serdes[n].rx.mem_addr = XDMEM_TABLE_BASE_ADDR + 64 * n;
        state->serdes[n].tx.pll_clk_source = AVAGO_SERDES_TX_PLL_PCIE_CORE_CLK;
        state->serdes[n].tx.data_sel = AVAGO_SERDES_TX_DATA_SEL_CORE;
        state->serdes[n].tx.output_enable = TRUE;
        state->serdes[n].tx.sd_num = n;
    }

    /* Map links to sbus addresses: */
    st->link_cnt = state->serdes_count / 2;
    for( n = 0; n < st->link_cnt; n++ )
    {
        /* SerDes n <--> SerDes n+8 */
        st->link[n].host_rx = &state->serdes[n].rx;
        st->link[n].host_tx = &state->serdes[n].tx;
        st->link[n].mod_tx = &state->serdes[n + st->link_cnt].tx;
        st->link[n].mod_rx = &state->serdes[n + st->link_cnt].rx;
    }
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "port=%u, mode=%s\n", state->prtad, aapl_avsp_mode_to_str(state->mode));
    return TRUE;
}
#endif /* AAPL_ENABLE_AVSP_5410 */

#if AAPL_ENABLE_AVSP_8812
/** @brief   Updates the #state for individual half of 8812. Selects divider and mode */
/** @details #mode is the mode selection #divider is the divider for the individual half of the 8812 */
/** @return  On success, updates the #state structure and returns 0. */
/** @return  On error, returns -1.  The only error is a bad mode selection. */
int avsp_8812_configure_half(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    Avsp_state_t *state,    /**< State structure to update. */
    Avsp_mode_t mode,       /**< mode selection for selected half of chip */
    int divider,            /**< divider for selected half of the chip */
    uint half_sel)          /**< select individual half of the chip */
{
    uint n, addr;
    uint begin, end;

    char a8812_slip_table20[16] = { 15,  5, 15, 15, 15, 15, 15, 15,
                                    15, 15, 15, 15, 15, 15, 15, 15 };
    char a8812_slip_table40[16] = { 20, 12, 20, 20, 20, 20, 20, 20,
                                    25, 25, 25, 25, 25, 25, 25, 25 };

    addr = state->serdes[0].rx.sbus_addr;
    if( !avago_serdes_is_valid_divider(aapl,addr,divider) )
        return aapl_fail(aapl, __func__, __LINE__, "Invalid divider value: %d\n", divider);
    if( half_sel & ~1 )
        return aapl_fail(aapl, __func__, __LINE__, "Invalid half_sel value: %d\n", half_sel);

    aapl_log_printf(aapl, AVAGO_DEBUG3, __func__,__LINE__,"Set half%d divider to %d\n", half_sel, divider);

    state->u.a8812.half_mode[half_sel] = mode;

    begin = half_sel * 4;  /* select beginning serdes number according to the selected half */
    end = begin + 4;

    if( mode == AVSP_REPEATER_DUPLEX ) /* Repeater mode */
    {
        for( n = begin; n < end; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 40;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;
            state->serdes[n].tx.divider = 50;
            state->serdes[n].rx.divider = divider;
            state->serdes[n].rx.phase_slip = a8812_slip_table40[n];
        }
        for( n = begin+8; n < end+8; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 40;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;
            state->serdes[n].tx.divider = 50;
            state->serdes[n].rx.phase_slip = a8812_slip_table40[n];
            state->serdes[n].rx.divider = divider;
        }
    }
    else if( mode == AVSP_RS_FEC_4x4 )    /* FEC */
    {
        for( n = begin; n < end; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 40;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F66;
            state->serdes[n].tx.divider = 66;
            state->serdes[n].rx.divider = divider;
            state->serdes[n].rx.phase_slip = a8812_slip_table40[n];
        }
        for( n = begin+8; n < end+8; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 40;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F66;
            state->serdes[n].tx.divider = 66;
            state->serdes[n].rx.divider = divider;
            state->serdes[n].rx.phase_slip = a8812_slip_table40[n];
        }
    }
    else if( mode == AVSP_GEARBOX_2_1 )    /* Gearbox in 2:1 mode */
    {
        for( n = begin; n < end; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 20;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;
            state->serdes[n].tx.divider = 50;
            state->serdes[n].rx.divider = divider;
            state->serdes[n].rx.phase_slip = a8812_slip_table20[n];
        }
        for( n = begin+8; n < end+8; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 40;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;
            state->serdes[n].tx.divider = 100;
            state->serdes[n].rx.divider = divider * 2;
            state->serdes[n].rx.phase_slip = a8812_slip_table40[n];
        }
    }
    else if( mode == AVSP_GEARBOX_2_1_MOD_HOST )    /* Gearbox in 2:1 mode from mod to host */
    {
        for( n = begin; n < end; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 40;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;
            state->serdes[n].tx.divider = 100;
            state->serdes[n].rx.divider = divider * 2;
            state->serdes[n].rx.phase_slip = a8812_slip_table40[n];
        }
        for( n = begin+8; n < end+8; n++ )
        {
            state->serdes[n].rx.width = state->serdes[n].tx.width = 20;
            state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;
            state->serdes[n].tx.divider = 50;
            state->serdes[n].rx.divider = divider;
            state->serdes[n].rx.phase_slip = a8812_slip_table20[n];
        }
    }
    avsp_8812_configure_crosspoint(aapl, state);
    return 0;
}

/** @brief   Updates the crosspoint configurations  in #state. */
/** @details #get crosspoint connections and update divider accordingly for all modes if required */
/** @return  On success, updates the #state structure and returns 0. */
/** @return  On error, returns -1. */
BOOL avsp_8812_configure_crosspoint(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    Avsp_state_t *state)    /**< State structure to update. */
{
    char crosspoint[16];
    uint xp, n;
    uint count = 0;
    aapl_log_printf(aapl, AVAGO_DEBUG3, __func__,__LINE__,"Set divider with respect to the crosspoiint connections. \n");

    for( n = 0; n < 16; n++ )
         crosspoint[n] = state->serdes[n].tx.source_rx; /* get crosspoint connections */

    for( count = 0; count < 2; count++ )
    {
         uint begin = ( count == 0 ) ? 0 : 4; /* select beginning serdes number according to the selected half */
         uint end = ( count == 0 ) ? 4 : 8; /* select ending serdes number according to the selected half */

         if( state->u.a8812.half_mode[count] == AVSP_GEARBOX_2_1) /* set respective divider for crosspoint connections */
         {
             for( n = begin; n < end; n++ )
             {
                  xp = crosspoint[n]; /* get configured crosspoint */
                  state->serdes[xp].tx.width = 40;
                  state->serdes[xp].tx.divider = 100; /* 2 times the fifo clock for fast out */
             }
             for( n = begin+8; n < end+8; n++ )
             {
                  xp = crosspoint[n]; /* get configured crosspoint */
                  state->serdes[xp].tx.width = 20;
                  state->serdes[xp].tx.divider = 50; /* same as fifo clock for slow out */
             }
         }
         if( state->u.a8812.half_mode[count] == AVSP_GEARBOX_2_1_MOD_HOST) /* set respective divider for crosspoint connections */
         {
             for( n = begin; n < end; n++ )
             {
                  xp = crosspoint[n]; /* get configured crosspoint */
                  state->serdes[xp].tx.width = 20;
                  state->serdes[xp].tx.divider = 50; /* same as fifo clock for slow out */
             }
             for( n = begin+8; n < end+8; n++ )
             {
                  xp = crosspoint[n]; /* get configured crosspoint */
                  state->serdes[xp].tx.width = 40;
                  state->serdes[xp].tx.divider = 100;/* 2 times the fifo clock for fast out */
             }
         }
    }
    return TRUE;
}

/** @brief   Updates the crosspoint values in #state. */
/** @details The crosspoint settings are passed in as bit 15 (MSB) to bit 0 (LSB) */
/** @return  On success, updates the #state structure and returns 0. */
/** @return  On error, returns -1.  The only error is a bad divider value. */
BOOL avsp_state_set_crosspoint(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    Avsp_state_t *state,    /**< State structure to update. */
    char *xp)               /**< Crosspoint value bits 15 down to 0 */
{
    uint to;
    int bits_set = 0; /* The total number of bits set */
    size_t charcnt = strlen(xp);
    char buff[2];
    buff[1] = '\0';
    aapl_log_printf(aapl, AVAGO_DEBUG3, __func__,__LINE__,"Setup Crosspoint to state structure as: %s\n", xp);

    if( strspn(xp,"0123456789abcdefABCDEF_,xX") != charcnt )
    {
        aapl_log_printf(aapl,AVAGO_ERR,__func__,__LINE__,"Illegal character in crosspoint value: %s\n",xp);
        return FALSE;
    }
    for( to = 0; to < charcnt; to++ ) /* Most significant bit is first */
    {
        buff[0] = xp[to];
        if(( strcmp(buff,",") == 0) || ( strcmp(buff,"_") == 0)) continue; /* Ignore "," or "_" */
        if( strcmp(buff,"x") == 0 || strcmp(buff,"X") == 0 ) /*  keep crosspoint unchanged for the slices given with "x" */
            bits_set++;
        else
        {
            int from = aapl_strtol(buff,NULL,16);
            int index = (state->serdes_count-1)-bits_set++;
            if( index >= 0 )
                  state->serdes[index].tx.source_rx = from; /* Crosspoint */
            else
                  aapl_log_printf(aapl,AVAGO_WARNING,__func__,__LINE__,"Setting bits beyond total number of crosspoint settings available.\n");
        }
    }
    if( (state->serdes_count - bits_set) > 0 )
        aapl_log_printf(aapl,AVAGO_WARNING,__func__,__LINE__,"Only %d bits out of %d have been changed for the 8812 crosspoint\n",bits_set, state->serdes_count);
    return TRUE;
}
#endif /* AALP_ENABLE_AVSP_8812 */

/** @defgroup Avsp Avsp Functions */
/** @{ */

/** @brief   Updates the divider values in #state. */
/** @details #divider is the host-side divider; the others are calculated. */
/** @return  On success, updates the #state structure and returns 0. */
/** @return  On error, returns -1.  The only error is a bad divider value. */
int avsp_state_set_divider(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    Avsp_state_t *state,    /**< State structure to update. */
    int divider)            /**< Divider to configure. */
{
    uint addr = state->serdes[0].rx.sbus_addr;
    if( !avago_serdes_is_valid_divider(aapl,addr,divider) )
        return aapl_fail(aapl, __func__, __LINE__, "Invalid divider value: %d\n", divider);

    aapl_log_printf(aapl, AVAGO_DEBUG3, __func__,__LINE__,"Set divider to %d\n",divider);

#if AAPL_ENABLE_AVSP_1104 || AAPL_ENABLE_AVSP_9104
    if( state->device == 1104 || state->device == 9104 )
    {
        if( state->mode == AVSP_GEARBOX_10_4_RS_FEC || state->mode == AVSP_GEARBOX_10_4_MLG )
            divider = 66;   /* Only supported divider */
        if( state->mode == AVSP_GEARBOX_10_4        ||
            state->mode == AVSP_GEARBOX_10_4_RS_FEC ||
            state->mode == AVSP_GEARBOX_10_4_MLG    )
        {
            uint n;
            int divider_x = divider + divider + divider / 2;

            if( (divider & 1) || !avago_serdes_is_valid_divider(aapl,addr,divider_x) )
                return aapl_fail(aapl, __func__, __LINE__, "Invalid divider value: %d\n", divider);

            for( n = 0; n < 10; n++ )
            {
                state->serdes[n].rx.divider = divider;
                if( state->mode == AVSP_GEARBOX_10_4_RS_FEC )
                    state->serdes[n].tx.divider = 16;
                else if( state->mode == AVSP_GEARBOX_10_4_MLG )
                    state->serdes[n].tx.divider = 66;
                else
                    state->serdes[n].tx.divider = 20;   /* word width */
            }
            for( n = 10; n < 14; n++ )
            {
                state->serdes[n].rx.divider = divider_x;
                if( state->mode == AVSP_GEARBOX_10_4_MLG || state->mode == AVSP_GEARBOX_10_4_RS_FEC )
                    state->serdes[n].tx.divider = divider_x;
                else
                    state->serdes[n].tx.divider = 50;   /* 2.5x word width */
            }
            /* Extra SerDes, not used in 10:4 mode: */
            for( n = 14; n < state->serdes_count; n++ )
            {
                state->serdes[n].rx.divider = 0;    /* Turn off */
                state->serdes[n].tx.divider = 0;    /* Turn off */
            }
            if( state->mode == AVSP_GEARBOX_10_4_RS_FEC )
                state->serdes[17].tx.divider = 50;
            else if( state->mode == AVSP_GEARBOX_10_4_MLG )
            {
                state->serdes[14].tx.divider = state->serdes[14].rx.divider = 50;
                state->serdes[17].tx.divider = state->serdes[17].rx.divider = 66;
            }
/*          for( n = 0; n < 20; n++ ) */
/*              printf("divider[%d]: rx = %3d, tx = %3d\n",n,state->serdes[n].rx.divider,state->serdes[n].tx.divider); */
            return 0;
        }
        else
        {
            uint n;
            for( n = 0; n < state->serdes_count; n++ )
            {
                state->serdes[n].rx.divider = divider;
                state->serdes[n].tx.divider = 20;   /* word width */
            }
            return 0;
        }
    }
    else
#endif
#if AAPL_ENABLE_AVSP_4412 || AAPL_ENABLE_AVSP_8801
    if( state->device == 4412 || state->device == 8801 )
    {
        uint n;
        for( n = 0; n < state->serdes_count; n++ )
            state->serdes[n].rx.divider = state->serdes[n].tx.divider = divider;
        return 0;
    }
    else
#endif
#if AAPL_ENABLE_AVSP_8812
    if( state->device == 8812 )
    {
        if( state->mode == AVSP_REPEATER_DUPLEX )
        {
            uint n;
            for( n = 0; n < state->serdes_count; n++ )
            {
                 state->serdes[n].rx.width = state->serdes[n].tx.width = 40;
                 state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;
                 state->serdes[n].tx.divider = 50;
                 state->serdes[n].rx.divider = divider;
            }
            return 0;
        }
    }
#endif
#if AAPL_ENABLE_AVSP_7412
    if( state->device == 7412 )
    {
        if( state->mode == AVSP_REPEATER_DUPLEX )
        {
            uint n;
            for( n = 0; n < state->serdes_count; n++ )
            {
                 state->serdes[n].rx.width = state->serdes[n].tx.width = 40;
                 state->serdes[n].rx.pcs_fifo_clk_divider = AVAGO_SERDES_PCS_FIFO_F50;
                 state->serdes[n].tx.divider =40;
                 state->serdes[n].rx.divider = divider;
            }
            return 0;
        }
        if( state->mode == AVSP_RS_FEC_528 || state->mode == AVSP_RS_FEC_544 )
        {
            uint n;
            /* configuration settings for P1 Serdes */
            state->serdes[0].tx.divider = state->serdes[0].rx.divider = divider;
            state->serdes[0].rx.width = state->serdes[0].tx.width = 40;
            state->serdes[0].rx.encoding = state->serdes[0].tx.encoding = AVAGO_SERDES_PAM2;
            /* configuration settings for OM4 serdes */
            for( n = 1; n < state->serdes_count; n++ )
            {
                 state->serdes[n].tx.divider = state->serdes[n].rx.divider = 170;
                 state->serdes[n].rx.width = state->serdes[n].tx.width = 80;
                 state->serdes[n].rx.encoding = state->serdes[n].tx.encoding = AVAGO_SERDES_PAM4;
            }

            return 0;
        }

    }
#endif

#if AAPL_ENABLE_AVSP_5410
    if( state->device == 5410 )
    {
        uint n;
        if( state->mode == AVSP_REPEATER_DUPLEX )
        {
            for( n = 0; n < state->serdes_count; n++ )
            {
                 state->serdes[n].tx.divider = 20;
                 state->serdes[n].rx.divider = divider;
            }
        }
        else if( state->mode == AVSP_RS_FEC )    /* FEC */
        {
            for( n = 0; n < 4; n++ )
            {
                 state->serdes[n].tx.divider = 20;
                 state->serdes[n].rx.divider = divider;
            }
            for( n = 4; n < 5; n++ )
            {
                 state->serdes[n].tx.divider = 50;
                 state->serdes[n].rx.divider = divider;
            }
        }
        else if( state->mode == AVSP_GEARBOX_4_1 )    /* Gearbox in 4:1 mode */
        {
            for( n = 0; n < 4; n++ )
            {
                 state->serdes[n].tx.divider = 20;
                 state->serdes[n].rx.divider = divider;
            }
            for( n = 4; n < 5; n++ )
            {
                 state->serdes[n].tx.divider = 50;
                 state->serdes[n].rx.divider = divider;
            }
        }
        return 0;
    }
#endif

    return aapl_fail(aapl, __func__, __LINE__, "Unknown device/mode\n");
}

/** @brief   Initializes an AVSP state structure for a given device. */
/** @details Initializes all state to reasonable defaults, */
/**          which can then be customized before applying. */
/** @details Supported values for #avsp_name and #mode are: */
/** - AVSP-1104 supports modes AVSP_GEARBOX_10_4 and AVSP_REPEATER_DUPLEX. */
/** - AVSP-4412 supports the AVSP_REPEATER_DUPLEX mode. */
/** - AVSP-8801 supports the AVSP_REPEATER_SIMPLEX mode. */
/** - AVSP-9104 supports modes AVSP_GEARBOX_10_4, AVSP_GEARBOX_10_4_RS_FEC and AVSP_REPEATER_DUPLEX. */
/** */
/** @return TRUE if #avsp_name and #mode are a supported configuration, FALSE otherwise. */
BOOL avsp_state_init(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    uint prtad,             /**< Port address of the target device. */
    const char *avsp_name,  /**< Chip name to configure. */
    Avsp_mode_t mode,       /**< Device mode to configure. */
    Avsp_state_t *state)    /**< State structure to update. */
{
    int i;
    uint sbm_addr = avago_make_sbus_master_addr(avago_make_addr3(prtad,0,0));
    memset(state, 0, sizeof(*state));         /* set all bytes to zero */
    state->mode = mode;
    state->prtad = prtad;

    for( i = 0; i < AVSP_MAX_SLICE_COUNT; i++ )
        state->serdes[i].tx.sd_num = -1;

    if( !avsp_name )
        avsp_name = aapl_get_chip_name(aapl, avago_make_addr3(prtad,0,0));

/*  Initialize the ASSP variables (which are not zero): */
/*  state->assp_user_var_0 = 0x00; */
    state->assp_user_var_1 = 0x7f;
    state->assp_control[0] = 0x01;  /* 0x1010 default */
    state->assp_control[1] = 0x00;  /* 0x1010 default */
    state->assp_int_cnt    = 0x09502f90;
    if( aapl->jtag_idcode[prtad] && aapl_check_firmware_rev(aapl, sbm_addr, 0, 0, FALSE, 1, 0x1011) )
    {
        state->assp_control[1] = 0x24;
        if( EQS(avsp_name, "AVSP-1104") || EQS(avsp_name,"AVSP-9104") )
            state->assp_control[0] |= 0x08;
        state->assp_int_cnt /= 10;
        if( EQS(avsp_name, "AVSP-9104") || EQS(avsp_name,"AVSP-5410") )
            state->assp_int_cnt = 1956554;
        if( EQS(avsp_name, "AVSP-8812") )
            state->assp_control[0] |= 0x04;

        if( mode == AVSP_GEARBOX_10_4_RS_FEC && aapl_check_firmware_rev(aapl, sbm_addr, 0, 0, FALSE, 1, 0x1016) )
            state->assp_control[0] = 0x08;
        if( mode == AVSP_GEARBOX_10_4_MLG && aapl_check_firmware_rev(aapl, sbm_addr, 0, 0, FALSE, 1, 0x1018) )
            state->assp_control[0] |= 0x04;
        if( aapl_check_firmware_rev(aapl, sbm_addr, 0, 0, FALSE, 1, 0x81011) && EQS(avsp_name,"AVSP-4412/8801") )
            state->assp_control[0] |= 0x08;
        if( EQS(avsp_name, "AVSP-9104") ){
            if( mode == AVSP_GEARBOX_10_4 && aapl_check_firmware_rev(aapl, sbm_addr, 0, 0, FALSE, 1, 0x1018) )
                state->assp_control[0] |= 0x04;
            if( mode == AVSP_REPEATER_DUPLEX && aapl_check_firmware_rev(aapl, sbm_addr, 0, 0, FALSE, 1, 0x1018) )
                state->assp_control[0] |= 0x04;
        }
        if( EQS(avsp_name, "AVSP-5410") )
                state->assp_control[0] = 0x0d;

    }
    state->assp_delay[0]   = 0x10;
    state->assp_delay[1]   = 0x10;
    state->assp_delay_cnt  = 0x10;
    state->assp_var_cnt    = 14;

    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Initialize state for device=%d/%s, mode=%s\n",
        prtad, avsp_name, aapl_avsp_mode_to_str(mode));

#if AAPL_AVSP_COUNT == 1
# if AAPL_ENABLE_AVSP_1104
    if( init_1104_state(aapl, state) ) return TRUE;
# endif
# if AAPL_ENABLE_AVSP_4412
    if( init_4412_state(aapl, state) ) return TRUE;
# endif
# if AAPL_ENABLE_AVSP_7412
    if( init_7412_state(aapl, state) ) return TRUE;
# endif
# if AAPL_ENABLE_AVSP_5410
    if( init_5410_state(aapl, state) ) return TRUE;
# endif
# if AAPL_ENABLE_AVSP_8801
    if( init_8801_state(aapl, state) ) return TRUE;
# endif
# if AAPL_ENABLE_AVSP_8812
    if( init_8812_state(aapl, state) ) return TRUE;
# endif
# if AAPL_ENABLE_AVSP_9104
    if( init_9104_state(aapl, state) ) return TRUE;
# endif
#else   /* AAPL_AVSP_COUNT > 1 */
# if AAPL_ENABLE_AVSP_1104
    if( EQS(avsp_name, "AVSP-1104") && init_1104_state(aapl, state) ) return TRUE;
# endif
# if AAPL_ENABLE_AVSP_8812
    if( EQS(avsp_name, "AVSP-8812") && init_8812_state(aapl, state) ) return TRUE;
# endif
# if AAPL_ENABLE_AVSP_7412
    if( EQS(avsp_name, "AVSP-7412") && init_7412_state(aapl, state) ) return TRUE;
# endif
# if AAPL_ENABLE_AVSP_5410
    if( EQS(avsp_name, "AVSP-5410") && init_5410_state(aapl, state) ) return TRUE;
# endif
# if AAPL_ENABLE_AVSP_9104
    if( EQS(avsp_name, "AVSP-9104") && init_9104_state(aapl, state) ) return TRUE;
# endif

# if AAPL_ENABLE_AVSP_4412 || AAPL_ENABLE_AVSP_8801
    if( EQS(avsp_name, "AVSP-4412/8801") )
    {
#   if AAPL_ENABLE_AVSP_4412 && !AAPL_ENABLE_AVSP_8801
        if( init_4412_state(aapl, state) )
            return TRUE;
#   elif !AAPL_ENABLE_AVSP_4412 && AAPL_ENABLE_AVSP_8801
        if( init_8801_state(aapl, state) )
            return TRUE;
#   else   /* Both */
        if( mode == AVSP_REPEATER_DUPLEX  && init_4412_state(aapl, state) )
            return TRUE;
        if( mode == AVSP_REPEATER_SIMPLEX && init_8801_state(aapl, state) )
            return TRUE;
#   endif
    }
# endif
#endif /* AAPL_AVSP_COUNT */

    aapl_fail(aapl,__func__,__LINE__,"Stating %s device in %s mode not supported.\n",avsp_name,aapl_avsp_mode_to_str(mode));
    return FALSE;
}

static int mode_to_type_sel(Avsp_mode_t mode)
{
    return mode == AVSP_GEARBOX_10_4        ? 0x02a : /* 9104 */
           mode == AVSP_GEARBOX_10_4_RS_FEC ? 0x03a : /* 9104  // TODO: Update 0x02a to correct value */
           mode == AVSP_REPEATER_DUPLEX     ? 0x028 : /* common to all chip */
           mode == AVSP_REPEATER_SIMPLEX    ? 0x028 :
           mode == AVSP_GEARBOX_2_1         ? 0x002 : /* 8812 */
           mode == AVSP_GEARBOX_2_1_MOD_HOST? 0x004 : /* 8812 */
           mode == AVSP_GEARBOX_4_1         ? 0x02e : /* 5410 */
           mode == AVSP_RS_FEC              ? 0x03e : /* 5410 */
           mode == AVSP_RS_FEC_4x4          ? 0x003 : /* 8812 */
           mode == AVSP_RS_FEC_528          ? 0x02c : /* 7412 */
           mode == AVSP_RS_FEC_544          ? 0x02b : 0; /* 7412 */

}

static void avsp_write_sbm_control_vars(Aapl_t *aapl, Avsp_state_t *state)
{
    uint sbm_addr = avago_make_sbus_master_addr(state->serdes[0].rx.sbus_addr);
    int v2_type_sel = mode_to_type_sel(state->mode);
#if AAPL_ENABLE_AVSP_8812
    if( state->device == 8812 )
    {
        if( state->u.a8812.half_mode[0] == AVSP_REPEATER_DUPLEX ) /* update lower 4 bits of v2_type_sel with the given mode for half0 */
            v2_type_sel = 0x001;
        else
            v2_type_sel = mode_to_type_sel(state->u.a8812.half_mode[0]);

        if( state->u.a8812.half_mode[1] == AVSP_REPEATER_DUPLEX ) /* update upper 4 bits of v2_type_sel with the given mode for half1 */
            v2_type_sel = v2_type_sel | (0x001 << 4);
        else
            v2_type_sel = v2_type_sel | (mode_to_type_sel(state->u.a8812.half_mode[1]) << 4);
    }
#endif
    /* General AVSP configuration values: */
    avago_spico_int(aapl, sbm_addr, 0x26, 0x6000 | (0x7f & state->assp_user_var_0));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x6100 | (0x7f & state->assp_user_var_1));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x6200 | (0x7f & state->assp_control[0]));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x6300 | (0x7f & state->assp_control[1]));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x6400 | (0x7f & state->assp_delay[0]));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x6500 | (0x7f & state->assp_delay[1]));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x6600 | (0x7f & state->assp_delay_cnt));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x6700 | (0x7f & state->assp_int_cnt >>  0));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x6800 | (0x7f & state->assp_int_cnt >>  7));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x6900 | (0x7f & state->assp_int_cnt >> 14));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x6a00 | (0x7f & state->assp_int_cnt >> 21));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x6b00 | (0x7f & state->assp_int_cnt >> 28));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x6c00 | (0x7f & state->assp_int_cnt >> 35));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x6d00 | (0x7f & state->assp_int_cnt >> 42));

    avago_spico_int(aapl, sbm_addr, 0x26, 0x6e00 | (0x7f & state->device_var1));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x6f00 | (0x7f & state->device_var2));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x7000 | (0x7f & state->device_var3));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x7100 | (0x7f & v2_type_sel));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x7200 | (0x7f & state->assp_control[2]));
    avago_spico_int(aapl, sbm_addr, 0x26, 0x7300 | (0x7f & state->assp_control[3]));
}

static void serdes_write_to_device(Aapl_t *aapl, void *user_ptr, Avago_serdes_tx_state_t *tx, Avago_serdes_rx_state_t *rx)
{
    uint addr = tx->sbus_addr;
    Avago_serdes_init_config_t *cfg = avago_serdes_init_config_construct(aapl);
    (void)user_ptr;
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Write to device\n");

    cfg->init_tx             = tx->enable && tx->divider != 0;
    cfg->init_rx             = rx->enable && rx->divider != 0;
    cfg->init_mode           = AVAGO_INIT_ONLY;
    cfg->tx_divider          = rx->divider?rx->divider:10; /* RX here is intentional */
    cfg->rx_divider          = rx->divider?rx->divider:10;
    cfg->tx_width            = tx->width;
    cfg->rx_width            = rx->width;
    cfg->tx_encoding         = tx->encoding;
    cfg->rx_encoding         = rx->encoding;
    cfg->tx_phase_cal        = FALSE;
    cfg->tx_output_en        = tx->output_enable;
    cfg->signal_ok_en        = rx->signal_ok_enable;
    cfg->signal_ok_threshold = rx->signal_ok_threshold;
    avago_serdes_init(aapl, addr, cfg);
    avago_serdes_init_config_destruct(aapl, cfg);

    /* Now set correct TX divider, but without calibration (was done above): */
    avago_serdes_set_pcs_fifo_clk_div( aapl, addr, rx->pcs_fifo_clk_divider);
    if( tx->divider != rx->divider )
        avago_spico_int_check(aapl, __func__, __LINE__, addr, 0x05, (tx->divider & 0xff) | (1<<13));
    avago_serdes_set_rx_input_loopback(aapl, addr, rx->input_loopback);
    avago_serdes_set_rx_term(          aapl, addr, rx->term);
    avago_serdes_set_rx_invert(        aapl, addr, rx->polarity_invert);
    avago_serdes_set_rx_cmp_data(      aapl, addr, rx->cmp_data);
    avago_serdes_set_rx_cmp_mode(      aapl, addr, rx->cmp_mode);
    avago_serdes_set_rx_data_qual(     aapl, addr, rx->data_qual);
    avago_spico_int_check(aapl, __func__, __LINE__, addr, 0x0E, 0x8000 | ((rx->phase_slip & 0x3f) << 8)); /* Set the RX Phase Slip */

    /* Only write some of the dfe values, treat others as read-only: */
    avago_serdes_set_dfe_state_ext(    aapl, addr, &rx->dfe, AVAGO_DFE_MODE_CTLE); /* DC HF LF BW */
    avago_serdes_set_dfe_state_ext(    aapl, addr, &rx->dfe, AVAGO_DFE_MODE_DFE);  /* Taps */
    avago_serdes_set_dfe_state_ext(    aapl, addr, &rx->dfe, AVAGO_DFE_MODE_PARAM);/* GAINs, fixed* */
 /* avago_serdes_set_dfe_state_ext(    aapl, addr, &rx->dfe, AVAGO_DFE_MODE_VOS); */
 /* avago_serdes_set_dfe_state_ext(    aapl, addr, &rx->dfe, AVAGO_DFE_MODE_TESTLEV); */
 /* avago_serdes_set_dfe_state_ext(    aapl, addr, &rx->dfe, AVAGO_DFE_MODE_DATALEV); */

    avago_serdes_set_tx_pll_clk_src(   aapl, addr, tx->pll_clk_source);
    avago_serdes_set_tx_data_sel(      aapl, addr, tx->data_sel);
    avago_serdes_set_tx_invert(        aapl, addr, tx->polarity_invert);
    avago_serdes_set_tx_eq(            aapl, addr, &tx->eq);
}
#if AAPL_ENABLE_AVSP_9104 || AAPL_ENABLE_AVSP_8812
static void serdes_tx_phase_cal(Aapl_t *aapl, void *user_ptr, Avago_serdes_tx_state_t *tx, Avago_serdes_rx_state_t *rx)
{
    (void)user_ptr;
    (void)rx;
    avago_spico_int_check(aapl, __func__, __LINE__, tx->sbus_addr, 0x0b, 0x01);
}
#endif

/** @brief   Directly configures the device to match #state. */
/** @return  On success, returns 0. */
/** @return  On error, returns -1. */
int avsp_state_write_to_device(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    Avsp_state_t *state)    /**< State structure to write. */
{
    int return_value;
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Write to device %d (AVSP-%d)\n",state->prtad, state->device);
    avsp_write_sbm_control_vars(aapl, state);

#if AAPL_ENABLE_AVSP_8812
    if( state->device == 8812 )
    {
        int i;
        char crosspoint[16];
        for( i = 0; i < 16; i++ )
            crosspoint[i] = state->serdes[i].tx.source_rx;
        avsp_8812_crosspoint_connect_all(aapl, state->prtad, crosspoint);
    }
#endif

    /* Configure the SerDes devices: */
    return_value = process_serdes_state(aapl, serdes_write_to_device, NULL, state);

    /* Set CORE logic: */
#if AAPL_ENABLE_AVSP_1104
    if( state->device == 1104 )
        avsp_control_logic_reset_direct(aapl, state->prtad, state->mode);
#endif

#if AAPL_ENABLE_AVSP_9104
    if( state->device == 9104 )
    {
        if( state->mode == AVSP_GEARBOX_10_4_RS_FEC )
            avsp_9104_fec_control_logic_reset_direct(aapl, state->prtad);
        else if( state->mode == AVSP_GEARBOX_10_4_MLG )
            return avsp_9104_mlg_state(aapl, state->prtad), 0;
        else
            avsp_control_logic_reset_direct(aapl, state->prtad, state->mode);

        /* Recal the Tx phase as we should have a valid recovered clock coming in: */
        return_value |= process_serdes_state(aapl, serdes_tx_phase_cal, NULL, state);

        /* Reset the control logic as recalibrating the Tx Phase confuses it: */
        avsp_control_logic_reset_direct(aapl, state->prtad, state->mode);
    }
#endif

#if AAPL_ENABLE_AVSP_8812
    if( state->device == 8812 )
    {
        avsp_8812_set_mode(aapl, state, 0);
        avsp_8812_set_mode(aapl, state, 1);
        return_value |= process_serdes_state(aapl, serdes_tx_phase_cal, NULL, state);
    }
#endif
#if AAPL_ENABLE_AVSP_5410
    if( state->device == 5410 )
    {
        Avsp_state_options_t state_options;
        state_options.mode = state->mode;
        state_options.divider = state->serdes[0].rx.divider;
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Stating device into %s mode with divider ratio %d.\n", aapl_avsp_mode_to_str(state->mode), state->serdes[0].rx.divider);
        avsp_state_device_with_options(aapl, state->prtad, &state_options);
        /*avsp_5410_set_mode(aapl, state->prtad, state->mode); */
        /*return_value |= process_serdes_state(aapl, serdes_tx_phase_cal, NULL, state); */
    }
#endif
#if AAPL_ENABLE_AVSP_7412
    if( state->device == 7412 )
    {
        Avsp_state_options_t state_options;
        state_options.mode = state->mode;
        state_options.divider = state->serdes[0].rx.divider;
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "Stating device into %s mode with divider ratio %d.\n", aapl_avsp_mode_to_str(state->mode), state->serdes[0].rx.divider);
        avsp_state_device_with_options(aapl, state->prtad, &state_options);
/*        avsp_7412_set_mode(aapl, state); */
/*        return_value |= process_serdes_state(aapl, serdes_tx_phase_cal, NULL, state); */
    }
#endif


    return return_value;
}

/** @brief   Directly configures the device to match #state. */
/** @return  On success, returns 0. */
/** @return  On error, returns -1. */
int avsp_8812_state_write_to_device(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    Avsp_state_t *state,    /**< State structure to write. */
    uint half)
{

    uint i;
    Avago_state_tx_rx_fn_t fn;

    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Write to device %d (AVSP-%d)\n",state->prtad, state->device);

   /* the below code is written specifically for CISCO customer */
   /* as while configuring FEC mode avsp_write_sbm_control_vars was affecting */
   /* the other half of chip */
#if AAPL_ENABLE_AVSP_8812
    if (state->u.a8812.half_mode[half] != AVSP_RS_FEC_4x4)
        avsp_write_sbm_control_vars(aapl, state);
#endif

#if AAPL_ENABLE_AVSP_8812
    if (half == 0) /* configure crosspoint for half0 slices */
    {
         for( i = 0; i < 4; i++ )
              avsp_8812_crosspoint_connect(aapl, state->prtad, i, state->serdes[i].tx.source_rx);
         for( i = 8; i < 12; i++ )
              avsp_8812_crosspoint_connect(aapl, state->prtad, i, state->serdes[i].tx.source_rx);
    }
    else if (half == 1) /* configure crosspoint for half1 slices */
    {
         for( i = 4; i < 8; i++ )
              avsp_8812_crosspoint_connect(aapl, state->prtad,i, state->serdes[i].tx.source_rx);
         for( i = 12; i < 16; i++ )
              avsp_8812_crosspoint_connect(aapl, state->prtad, i, state->serdes[i].tx.source_rx);
    }
#endif

    fn = serdes_write_to_device;
    if (half == 0) /* perform serdes write for half0 slices */
    {
        for( i = 0; i < 4; i++ )
             fn(aapl, NULL, &state->serdes[i].tx, &state->serdes[i].rx);

        for( i = 8; i < 12; i++ )
             fn(aapl, NULL, &state->serdes[i].tx, &state->serdes[i].rx);
    }
    else if( half == 1) /* perform serdes write for half1 slices */
    {
        for( i = 4; i < 8; i++ )
             fn(aapl, NULL, &state->serdes[i].tx, &state->serdes[i].rx);
        for( i = 12; i < 16; i++ )
             fn(aapl, NULL, &state->serdes[i].tx, &state->serdes[i].rx);

    }
#if AAPL_ENABLE_AVSP_8812
    /* configure mode for selected half */
    avsp_8812_set_mode(aapl, state, half);
#endif
    return 0;
}

#if AAPL_ENABLE_AVSP_8812 && AAPL_ENABLE_AVSP_STATE
/** @brief   Configures individual lane speed */
/** @return  On success, returns 0. */
/** @return  On error, returns -1. */
int avsp_8812_configure_lane_speed(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    uint prtad,             /**< Port address of the target device */
    uint lane,              /**< mask bits for 8 lanes, one bit for each lane */
    int divider)            /**< divider of the specified lane */
{
    uint lane_no, sbus_addr;
    char crosspoint[16];

    /* get state structure updated with current state of the device */
    Avsp_state_t *state = avsp_state_get(aapl, prtad);
    Avago_state_tx_rx_fn_t fn;

    uint addr = state->serdes[0].rx.sbus_addr;
    if( !avago_serdes_is_valid_divider(aapl,addr,divider) )
    {
        avsp_state_destruct(aapl,state);
        return aapl_fail(aapl, __func__, __LINE__, "Invalid divider value: %d\n", divider);
    }

    /* get crosspoint settings */
    avsp_8812_crosspoint_get_all( aapl, prtad, crosspoint );

    for( lane_no = 0; lane_no < 8; lane_no++ ) /* scan 8 lanes of 8812 for the lane(s) which is selected by the user */
    {
        uint xp_sd = crosspoint[lane_no]; /* get corresponding crosspoint slice for the lane specified */
        if( lane & (1<<lane_no) ) /* check if bit is set */
        {
            aapl_log_printf(aapl, AVAGO_DEBUG0, __func__, __LINE__, "Setting divider of lane %d: 0x%02x <-> 0x%02x \n",lane_no, state->serdes[lane_no].rx.sbus_addr, state->serdes[xp_sd].rx.sbus_addr);

            /* update divider of serdes for the specified lane */
            state->serdes[lane_no].rx.divider = divider;
            state->serdes[xp_sd].rx.divider = divider;

            /* write the serdes setting to device */
            fn = serdes_write_to_device;
            fn(aapl, NULL, &state->serdes[lane_no].tx, &state->serdes[lane_no].rx);
            fn(aapl, NULL, &state->serdes[xp_sd].tx, &state->serdes[xp_sd].rx);

            sbus_addr = avago_make_addr3(prtad, 0, state->serdes[lane_no].rx.sbus_addr);
            avago_spico_int_check(aapl, __func__, __LINE__, sbus_addr, 0xb, 1);     /* Tx Phase Cal */
            avago_spico_int_check(aapl, __func__, __LINE__, sbus_addr, 0xa, 1);     /* tuning */

            sbus_addr = avago_make_addr3(prtad, 0, state->serdes[xp_sd].rx.sbus_addr);
            avago_spico_int_check(aapl, __func__, __LINE__, sbus_addr, 0xb, 1);     /* Tx Phase Cal */
            avago_spico_int_check(aapl, __func__, __LINE__, sbus_addr, 0xa, 1);     /* tuning */
        }
    }
    avsp_state_destruct(aapl,state);
    return 0;
}
#endif /* AAPL_ENABLE_AVSP_8812 && AAPL_ENABLE_AVSP_STATE */

/* Function to prepare the SerDes of an AVSP device for a state change. */
/* This works around a problem in the SBus Master interaction with the SerDes */
/* swap build. */
static void prepare_for_mode_change(Aapl_t *aapl, uint prtad)
{
    uint i, len = 0, *list = 0;
    aapl_get_addr_list(aapl, prtad, 0, AVSP_ALL, &len, &list);

    /* Assumes that all SerDes have same build: */
    if( aapl_get_firmware_build(aapl, avago_make_addr3(prtad,0,list[0])) != 0x0045 )
        return;    /* Work around not needed */

    /* Stop DFE on all running SerDes: */
    for( i = 0; i < len; i++ )
    {
        uint addr = avago_make_addr3(prtad, 0, list[i]);
        aapl_set_spico_running_flag(aapl, addr, avago_spico_running(aapl, addr));
        if( aapl_get_spico_running_flag(aapl,addr) )
            avago_spico_int(aapl, addr, 0x0a, 0);
    }

    /* Wait for DFE to stop: */
    for( i = 0; i < len; i++ )
    {
        uint addr = avago_make_addr3(prtad, 0, list[i]);
        if( aapl_get_spico_running_flag(aapl,addr) )
            avago_serdes_dfe_wait(aapl, addr);
    }

    /* Force CAL swap in: */
    for( i = 0; i < len; i++ )
    {
        uint addr = avago_make_addr3(prtad, 0, list[i]);
        if( aapl_get_spico_running_flag(aapl,addr) )
            avago_serdes_set_rx_input_loopback(aapl, addr, FALSE);
    }

    /* Now OK to change PMA/RPT mode: */
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBM/SerDes swap issue workaround complete\n");
}

/** @brief  Initializes an Avsp_state_options_t structure to default values. */
/** @return void. */
void avsp_state_options_init(
    Aapl_t *aapl,                    /**< [in] Pointer to Aapl_t structure. */
    Avsp_state_options_t *options)   /**< [out] Address of structure to populate. */
{
    (void)aapl;
    memset(options,0,sizeof(*options));

    options->mode = AVSP_REPEATER_DUPLEX;
    options->divider = 66;

    /*8812 mode config options */
    options->half_mode[0] = AVSP_REPEATER_DUPLEX;
    options->half_mode[1] = AVSP_REPEATER_DUPLEX;
    options->half0_div = 66;
    options->half1_div = 66;

    /* 9104 FEC options: */
    options->enable_fec_bip_error_workaround = FALSE;
    options->disable_mod_during_fec_setup    = FALSE;
    options->disable_host_during_fec_setup   = FALSE;
    options->run_an_before_fec_setup         = FALSE;
    options->run_an_after_fec_setup          = FALSE;
    options->run_kr_after_an                 = FALSE;
    options->extra_opts                      = 0;
}

static int wait_for_status_ok(Aapl_t *aapl, uint sbm_addr, int ret, int mask, int success)
{
    int i;
    aapl_log_printf(aapl, AVAGO_DEBUG3, __func__,__LINE__,"ret = 0x%x\n",ret);
    for( i = 0; i < 15 && (ret & mask) != success; i++ )
    {
        ret = avago_spico_int(aapl, sbm_addr, 0x26, 0x3400);
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__,__LINE__,"ret = 0x%x\n",ret);
        ms_sleep(100);
    }
    return ret;
}

/** @brief  Requests SBus master to state device into specified mode with */
/**         specified options. */
/** @return 0 on success, -1 on error. */
int avsp_state_device_with_options(
    Aapl_t *aapl,                   /**< [in] Pointer to Aapl_t structure. */
    uint prtad,                     /**< [in] Port address of the target device. */
    Avsp_state_options_t *options)  /**< [in] Configuration settings */
{
    uint sbm_addr = avago_make_sbus_master_addr(avago_make_addr3(prtad,0,0));
    const char *chip_name = aapl_get_chip_name(aapl, sbm_addr);
    Avsp_mode_t mode = options->mode;
    Avsp_mode_t half_mode[2];
    int divider = options->divider;
    int half0_div = 0;
    int half1_div = 0;

    /* get 8812 specific options */
    if( EQS(chip_name,"AVSP-8812") )
    {
        half_mode[0] = options->half_mode[0]; /* mode to configure for half0 */
        half_mode[1] = options->half_mode[1]; /* mode to configure for half1 */
        half0_div = options->half0_div; /* half0 divider */
        half1_div = options->half1_div; /* half1 divider */
        /* validate half0_div and half1_div */
        if( !avago_serdes_is_valid_divider(aapl, sbm_addr, half1_div) )
            return aapl_fail(aapl, __func__, __LINE__,
                "Attempt to state the part with an out-of-range half0 divider ratio: %d\n", half0_div);
        if( !avago_serdes_is_valid_divider(aapl, sbm_addr, half1_div) )
            return aapl_fail(aapl, __func__, __LINE__,
                "Attempt to state the part with an out-of-range half1 divider ratio: %d\n", half1_div);
    }
    else /* if not AVSP-8812 validate divider */
    {
        if( !avago_serdes_is_valid_divider(aapl, sbm_addr, divider) )
            return aapl_fail(aapl, __func__, __LINE__,
                 "Attempt to state the part with an out-of-range host divider ratio: %d\n", divider);
    }

    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Stating device %d/%s into mode %s\n",
                    prtad,chip_name,aapl_avsp_mode_to_str(mode));


    if( EQS(chip_name,"AVSP-1104") || EQS(chip_name,"AVSP-9104") )
    {
        if( (EQS(chip_name,"AVSP-1104") && !aapl_check_firmware_build(aapl, sbm_addr, __func__, __LINE__, TRUE, 1, 0x0004)) ||
            (EQS(chip_name,"AVSP-9104") && !aapl_check_firmware_build(aapl, sbm_addr, __func__, __LINE__, TRUE, 1, 0x0304)) )
            return -1;

        prepare_for_mode_change(aapl, prtad);
        /* SBus Master Int 0x24 36, Set 1104 mode: */
        /* CODE[15:6]  - In RPT mode, select which channels to configure. */
        /*         0x0 - Select all */
        /* DATA[15]    - 1=PMA, 0=RPT */
        /* DATA[7:0]   - divider (mod is 2.5x this in PMA mode) */

        /*     return status is: */
        /*     [0]:  return code issue in one of the sbus actions */
        /*     [1]:  Timeout waiting for cal&init completion on a host slice */
        /*     [2]:  Invalid DFE setting on a slice */
        /*     [3]:  IMEM load failure (only updated if IMEM load was enabled) */
        /*     [4]:  User request result error */
        /*   * [5]:  signal ok issue */
        /*     [6]:  PMA mode (only used if bit 8 set) */
        /*   * [7]:  iCal in progress */
        /*     [8]:  Invalid mode selection (not pma or rpt) */
        /*     [9]:  Request is done */
        /*   * [10]: adaptive tuning running on a slice */
        /*   * [11]: manual tx output enable ready */
        /*   * [12]: polling running */

        /* ret == 0x240 ==> PMA type */
        /* ret == 0x200 ==> RPT type */
        /* ret == 0x300 ==> non-valid type */
        if( mode == AVSP_GEARBOX_10_4 )
        {
            int ret = 0;
            if( (divider & 1) || !avago_serdes_is_valid_divider(aapl, sbm_addr, divider + divider + divider/2) )
                return aapl_fail(aapl, __func__, __LINE__,
                    "Attempt to state the part with a host divider that would result in an out-of-range module-side divider ratio: %d\n",
                    divider);

            /* For old versions of the firmware 0x1009, and 0x100a, it is */
            /* necessary to set a long time out delay. The address to set the */
            /* assp_delay, is different for each version of the firmware. */
            if( aapl_check_firmware_rev(aapl, sbm_addr, __func__, __LINE__, FALSE, 1, 0x81009) )
            {
                avago_spico_int(aapl, sbm_addr, 0x0011, 0x005e);/* Set assp_delay address */
                avago_spico_int(aapl, sbm_addr, 0x0012, 0xffff);/* Set long delay */
            }
            else if( aapl_check_firmware_rev(aapl, sbm_addr, __func__, __LINE__, FALSE, 1, 0x8100a) )
            {
                avago_spico_int(aapl, sbm_addr, 0x0011, 0x0061);/* Set assp_delay address */
                avago_spico_int(aapl, sbm_addr, 0x0012, 0xffff);/* Set long delay */
            }
            else if( aapl_check_firmware_rev(aapl, sbm_addr, __func__, __LINE__, FALSE, 1, 0x8100b) )
            {
                return aapl_fail(aapl, __func__, __LINE__, "The 0x100B version of the sbus master firmware, is unsupported for the AVSP-1104.\n");
            }

            ret = avago_spico_int(aapl, sbm_addr, 0x0024, 0x8000 | divider);
            ret = wait_for_status_ok(aapl, sbm_addr, ret, 0x35f, 0x240);
            if( (ret & 0x35f) != 0x240 )    /* PMA type */
            {
                return aapl_fail(aapl, __func__, __LINE__, "Expected 0x240, got 0x%x\n",ret&0x35f);
            }
        }
        else if( mode == AVSP_REPEATER_DUPLEX )
        {
            /* Increase timeout since repeater mode on the 1104/9104 can take longer to state than PMA mode. */
            int ret;
            int save_timeout = aapl->serdes_int_timeout;
            aapl->serdes_int_timeout *= 2;
            ret = avago_spico_int(aapl, sbm_addr, 0x0024, 0x0000 | divider);
            ret = wait_for_status_ok(aapl, sbm_addr, ret, 0x35f, 0x200);
            aapl->serdes_int_timeout = save_timeout;
            if( (ret & 0x35f) != 0x200 )    /* RPT type */
            {
                if(EQS(chip_name, "AVSP-9104")) /* skipping return code check for firmware revision 1016 and 1015 in 9104 */
                {
                   if(aapl_check_firmware_rev(aapl, sbm_addr, 0, 0, FALSE, 1, 0x1017)) 
                      return aapl_fail(aapl, __func__, __LINE__, "Expected 0x200, got 0x%x (0x%x)\n",ret&0x35f,ret);
                   else
                      return 0;
                }
 
                return aapl_fail(aapl, __func__, __LINE__, "Expected 0x200, got 0x%x (0x%x)\n",ret&0x35f,ret);
            }
        }
#if AAPL_ENABLE_AVSP_9104
        else if( mode == AVSP_GEARBOX_10_4_RS_FEC )
        {
            int ret;
            int fec_control = 0x4000;
            if( options->disable_mod_during_fec_setup    ) fec_control |= (1 << 6);    /* Disable CAUI-4 */
            if( options->disable_host_during_fec_setup   ) fec_control |= (1 << 5);    /* Disable CAUI-10 */
            if( options->enable_fec_bip_error_workaround ) fec_control |= (1 << 4);    /* Handle known 9104r2 BIP issue for alignment */
            if( options->run_kr_after_an                 ) fec_control |= (1 << 2);    /* Perform KR after AN */
            if( options->run_an_before_fec_setup         ) fec_control |= (1 << 1);    /* Run sequence 2 (AN before FEC setup) */
            if( options->run_an_after_fec_setup          ) fec_control |= (1 << 0);    /* Run sequence 1 (AN after FEC setup) */
            if( options->extra_opts                      ) fec_control |= options->extra_opts; /* Set extra bits */

            avago_spico_int(aapl, sbm_addr, 0x0022, 0xc004);
            if( options->disable_fec )
            {
                int an_control = options->run_kr_after_an ? 0x4111 : 0x4119;
                ret = avago_spico_int(aapl, sbm_addr, 0x0022, an_control);
                aapl_log_printf(aapl, AVAGO_DEBUG4, __func__,__LINE__,"%s: SBM state device: int(0x22,0x%x) = 0x%x\n",aapl_addr_to_str(sbm_addr),an_control,ret);
                /* ret = avago_sbus_rd(aapl, avago_make_addr3(prtad, 0, 0x11), 0x2b); */
            }
            else
            {
                ret = avago_spico_int(aapl, sbm_addr, 0x0024, fec_control);
                ret = wait_for_status_ok(aapl, sbm_addr, ret, 0x200, 0x200);
                aapl_log_printf(aapl, AVAGO_DEBUG4, __func__,__LINE__,"%s: SBM state device: int(0x24,0x%x) = 0x%x\n",aapl_addr_to_str(sbm_addr),fec_control,ret);
                if( (ret & 0x340) != 0x300 )    /* Gearbox */
                {
                    return aapl_fail(aapl, __func__, __LINE__, "Expected (ret & 0x340) == 0x300; got 0x%x; "
                        "assp_fec_status = 0x%04x; assp_fec_slip_cnt = 0x%04x; assp_fec_state = 0x%04x\n",
                        ret,
                        avago_spico_int(aapl, sbm_addr, 0x26, 0x3a00),
                        avago_spico_int(aapl, sbm_addr, 0x26, 0x3b00),
                        avago_spico_int(aapl, sbm_addr, 0x26, 0x3c00)
                        );
                }
            }
        }
        else if( mode == AVSP_GEARBOX_10_4_MLG )
        {
            avsp_9104_mlg_state(aapl, prtad);
        }
#endif
        else
        {
            return aapl_fail(aapl, __func__, __LINE__, "ERROR: Attempt to state part %d into an unsupported mode: %s\n",
                        prtad, aapl_avsp_mode_to_str(mode));
        }
    }
    else if( EQS(chip_name,"AVSP-8812") )
    {
        int ret,i;
        for( i = 0; i < 2; i++ )
        {
             int intr_data = 0; /* reset data for each half */
             divider = ( i == 0 ) ? half0_div : half1_div;
             if( i == 0 ) intr_data |= 1 << 8;
             else         intr_data |= 1 << 9;
             if( (half_mode[0] == AVSP_REPEATER_DUPLEX && half_mode[1] == AVSP_REPEATER_DUPLEX) || (half_mode[0] == AVSP_GEARBOX_2_1 && half_mode[1] == AVSP_GEARBOX_2_1) || (half_mode[0] == AVSP_RS_FEC_4x4 && half_mode[1] == AVSP_RS_FEC_4x4) )
             {
                 intr_data |= 0x0300; /* select both half */
                 i = 1; /*end loop */
             }
             if( half_mode[i] == AVSP_REPEATER_DUPLEX )
             {
                 intr_data |= 0 << 15;
                 ret = avago_spico_int(aapl, sbm_addr, 0x0024, intr_data | divider);
                 if( (ret & 0x35f) != 0x200 )    /* RPT type */
                 {
                      return aapl_fail(aapl, __func__, __LINE__, "Expected 0x200, got 0x%x\n",ret&0x35f);
                 }
             }
             else if( half_mode[i] == AVSP_GEARBOX_2_1 )
             {
                 intr_data |= 1 << 15;
                 ret = avago_spico_int(aapl, sbm_addr, 0x0024, intr_data | divider);
                 if( (ret & 0x35f) != 0x200 )    /* RPT type */
                 {
                      return aapl_fail(aapl, __func__, __LINE__, "Expected 0x200, got 0x%x\n",ret&0x35f);
                 }
             }
             else if( half_mode[i] == AVSP_RS_FEC_4x4 )
             {
                 intr_data |= 1 << 14;
                 ret = avago_spico_int(aapl, sbm_addr, 0x0024, intr_data | divider);
                 if( (ret & 0x35f) != 0x200 )    /* RPT type */
                 {
                      return aapl_fail(aapl, __func__, __LINE__, "Expected 0x200, got 0x%x\n",ret&0x35f);
                 }
             }
        }
    }
    else if( EQS(chip_name,"AVSP-4412/8801") )
    {
        int ret;
        prepare_for_mode_change(aapl, prtad);
        ret = avago_spico_int(aapl, sbm_addr, 0x0024, 0x0000 | divider);
        if( (ret & 0x35f) != 0x200 )    /* RPT type */
        {
            return aapl_fail(aapl, __func__, __LINE__, "Expected 0x200, got 0x%x\n",ret&0x35f);
        }
    }
    else if( EQS(chip_name,"AVSP-4412/8801") )
    {
        int ret;
        prepare_for_mode_change(aapl, prtad);
        ret = avago_spico_int(aapl, sbm_addr, 0x0024, 0x0000 | divider);
        if( (ret & 0x35f) != 0x200 )    /* RPT type */
        {
            return aapl_fail(aapl, __func__, __LINE__, "Expected 0x200, got 0x%x\n",ret&0x35f);
        }
    }
    else if( EQS(chip_name,"AVSP-5410") )
    {
        /*int ret; */
        if( mode == AVSP_REPEATER_DUPLEX )
        {
           /* int ret; */
/*            if( (divider & 1) || !avago_serdes_is_valid_divider(aapl, sbm_addr, divider + divider + divider/2) ) */
  /*              return aapl_fail(aapl, __func__, __LINE__,"Attempt to state the part with a host divider that would result in an out-of-range module-side divider ratio: %d\n",divider); */

           avago_spico_int(aapl, sbm_addr, 0x0024, 0x0000 | divider);
        }
        if( mode == AVSP_RS_FEC )
        {
            /*int ret ; */
    /*        if( (divider & 1) || !avago_serdes_is_valid_divider(aapl, sbm_addr, divider + divider + divider/2) ) */
      /*          return aapl_fail(aapl, __func__, __LINE__,"Attempt to state the part with a host divider that would result in an out-of-range module-side divider ratio: %d\n",divider); */

           avago_spico_int(aapl, sbm_addr, 0x0024, 0x4000 | divider);
        }
        if( mode == AVSP_GEARBOX_4_1 )
        {
          /*  int ret; */
        /*    if( (divider & 1) || !avago_serdes_is_valid_divider(aapl, sbm_addr, divider + divider + divider/2) ) */
          /*      return aapl_fail(aapl, __func__, __LINE__,"Attempt to state the part with a host divider that would result in an out-of-range module-side divider ratio: %d\n",divider); */

           avago_spico_int(aapl, sbm_addr, 0x0024, 0x8000 | divider);
        }
    }
    else if( EQS(chip_name,"AVSP-7412") )
    {
        int ret;
        if( mode == AVSP_REPEATER_DUPLEX )
        {
            if( (divider & 1) || !avago_serdes_is_valid_divider(aapl, sbm_addr, divider + divider + divider/2) )
                return aapl_fail(aapl, __func__, __LINE__,"Attempt to state the part with a host divider that would result in an out-of-range module-side divider ratio: %d\n",divider);

            ret = avago_spico_int(aapl, sbm_addr, 0x0024, 0x0000 | divider);
            if( (ret & 0x35f) != 0x200 )    /* RPT type */
            {
                 return aapl_fail(aapl, __func__, __LINE__, "Expected 0x200, got 0x%x\n",ret&0x35f);
            }
        }
        if( mode == AVSP_RS_FEC_528 )
        {
            if( (divider & 1) || !avago_serdes_is_valid_divider(aapl, sbm_addr, divider + divider + divider/2) )
                return aapl_fail(aapl, __func__, __LINE__,"Attempt to state the part with a host divider that would result in an out-of-range module-side divider ratio: %d\n",divider);

            prepare_for_mode_change(aapl, prtad);
            ret = avago_spico_int(aapl, sbm_addr, 0x0024, 0x8000 | divider);
            if( (ret & 0x340) != 0x300 )
            {
                 return aapl_fail(aapl, __func__, __LINE__, "Expected 0x300, got 0x%x\n",ret&0x340);
            }
        }
        if( mode == AVSP_RS_FEC_544 )
        {   
            prepare_for_mode_change(aapl, prtad);
            ret = avago_spico_int(aapl, sbm_addr, 0x0024, 0xC000 | divider);
            if( (ret & 0x35f) != 0x341 )
            {
                 return aapl_fail(aapl, __func__, __LINE__, "Expected 0x341, got 0x%x\n",ret&0x35f);
            }
        }
    }

    return 0;
}

int avsp_state_device_from_defaults(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    uint prtad,             /**< Port address of the target device. */
    Avsp_mode_t mode,       /**< Device mode to configure. */
    int divider)            /**< Divider to configure. */
{
    Avsp_state_options_t options;
    avsp_state_options_init(aapl, &options);
    options.mode = mode;
    options.divider = divider;
    /* 8812 specific variables */
    options.half_mode[0] = mode;
    options.half0_div = divider;
    return avsp_state_device_with_options(aapl, prtad, &options);
}


/** @} */
#endif /* AAPL_ENABLE_AVSP_STATE_MIN */


#if AAPL_ENABLE_AVSP_STATE || AAPL_ENABLE_AVSP_8812


/** @cond INTERNAL */

/* Input is a 2s complement number. */
/* Returned value is a mag_bits+1 bit value: */
/*    value[mag_bits]     = sign (1=negative) */
/*    value[mag_bits-1:0] = magnitude */
int aapl_sign_mag(int value, int mag_bits)
{
    int sign = value >> mag_bits;
    int sign_mask = (1 << mag_bits);
    return ((value + sign) ^ sign) | (value & sign_mask);
}

/* Input is a sign magnitude number. */
/*    bits[mag_bits]      = sign (1=negative) */
/*    bits[mag_bits-1..0] = magnitude */
/* Return 2s complement signed value. */
int aapl_twos_comp(int bits, int mag_bits)
{
    int sign_mask = (1 << mag_bits);
    int mag_mask = sign_mask - 1;
    int mag = bits & mag_mask;
    return (bits & sign_mask) ? -mag : mag;
}

/** @endcond */

/* Convert width to/from interrupt encoding: */
static int int_width_tab[] = {10,20,20,40,16,32,64,80};
static int width_to_int_bits(int width)
{
    int i;
    for( i = 0; i < AAPL_ARRAY_LENGTH(int_width_tab); i++ )
        if( int_width_tab[i] == width )
            return i;
    return -1;
}

static void avsp_state_to_memory(
    Aapl_t *aapl,
    Avago_serdes_tx_state_t *tx,
    Avago_serdes_rx_state_t *rx,
    short *mem)
{
    int temp;
    (void)aapl;
    if( !rx->enable ) rx->divider = 0;
    if( !tx->enable ) tx->divider = 0;
    mem[0x00] = (rx->divider >> 7) & 0x01;
    mem[0x01] =  rx->divider;
    mem[0x02] = (tx->divider >> 7) & 0x01;
    mem[0x03] =  tx->divider;
        temp = 0;
        if( tx->polarity_invert ) temp |= 0x01;
        if( rx->polarity_invert ) temp |= 0x02;
        if( rx->input_loopback  ) temp |= 0x04;
        if( tx->data_sel==AVAGO_SERDES_TX_DATA_SEL_LOOPBACK ) temp |= 0x08;
        if(      rx->term == AVAGO_SERDES_RX_TERM_FLOAT )     temp |= 3<<4;
        else if( rx->term == AVAGO_SERDES_RX_TERM_AVDD  )     temp |= 1<<4;
    mem[0x04] = temp;
    mem[0x05] = tx->eq.pre;
    mem[0x06] = tx->eq.atten;
    mem[0x07] = tx->eq.post;
        temp = 0;
        if( rx->bypass_ctle ) temp = 0x38;
        temp |= (rx->run_ical     != 0) << 0;
        temp |= (rx->dfe.fixed_dc != 0) << 3;
        temp |= (rx->dfe.fixed_hf != 0) << 4;
        temp |= (rx->dfe.fixed_lf != 0) << 5;
        temp |= (rx->run_vsr_tune != 0) << 6;
    mem[0x08] = temp;
        temp = 0;
        if( rx->bypass_ctle ) temp = 0x38;
        temp |= (rx->run_pcal     != 0) << 0;
        temp |= (rx->run_adaptive != 0) << 1;
        temp |= (rx->dfe.fixed_dc != 0) << 3;
        temp |= (rx->dfe.fixed_hf != 0) << 4;
        temp |= (rx->dfe.fixed_lf != 0) << 5;
        temp |= (rx->run_vsr_tune != 0) << 6;
    mem[0x09] = temp;
    mem[0x0a] = rx->dfe.dc >> 7;
    mem[0x0b] = rx->dfe.dc;
    mem[0x0c] = rx->dfe.hf;
    mem[0x0d] = rx->dfe.lf;
    mem[0x0e] = rx->dfe.bw;
    mem[0x0f] = rx->dfe.dfeGAIN;
    mem[0x10] = aapl_sign_mag(rx->dfe.dfeTAP[0],4);
    mem[0x11] = aapl_sign_mag(rx->dfe.dfeTAP[1],4);
    mem[0x12] = aapl_sign_mag(rx->dfe.dfeTAP[2],4);
    mem[0x13] = aapl_sign_mag(rx->dfe.dfeTAP[3],4);
    mem[0x14] = aapl_sign_mag(rx->dfe.dfeTAP[4],4);
    mem[0x15] = aapl_sign_mag(rx->dfe.dfeTAP[5],4);
    mem[0x16] = aapl_sign_mag(rx->dfe.dfeTAP[6],4);
    mem[0x17] = aapl_sign_mag(rx->dfe.dfeTAP[7],4);
    mem[0x18] = aapl_sign_mag(rx->dfe.dfeTAP[8],4);
    mem[0x19] = aapl_sign_mag(rx->dfe.dfeTAP[9],4);
    mem[0x1a] = aapl_sign_mag(rx->dfe.dfeTAP[10],4);
    mem[0x1b] = aapl_sign_mag((rx->dfe.vos[0] >> 7),4);
    mem[0x1c] = aapl_sign_mag(rx->dfe.vos[0],4);
    mem[0x1d] = aapl_sign_mag((rx->dfe.vos[1] >> 7),4);
    mem[0x1e] = aapl_sign_mag(rx->dfe.vos[1],4);
    mem[0x1f] = aapl_sign_mag((rx->dfe.vos[2] >> 7),4);
    mem[0x20] = aapl_sign_mag(rx->dfe.vos[2],4);
    mem[0x21] = aapl_sign_mag((rx->dfe.vos[3] >> 7),4);
    mem[0x22] = aapl_sign_mag(rx->dfe.vos[3],4);
    mem[0x23] = rx->dfe.dfeGAIN_min;
    mem[0x24] = rx->dfe.dfeGAIN_max;
    mem[0x25] = (tx->data_sel < 8) ? (tx->data_sel & 7) | 8 : 0;
        temp = rx->cmp_data & 0x07;/* prbs bits */
        if(      rx->cmp_mode == AVAGO_SERDES_RX_CMP_MODE_MAIN_PATGEN ) temp |= 1<<3;
        else if( rx->cmp_mode == AVAGO_SERDES_RX_CMP_MODE_XOR )         temp |= 2<<3;
    mem[0x26] = temp;
    mem[0x27] = (rx->pcs_fifo_clk_divider >> 8);
    mem[0x28] = (tx->pll_clk_source >> 4);
        temp = (width_to_int_bits(rx->width)<<4) | width_to_int_bits(tx->width); /* bit[2:0] = tx bit width bit[6:4] = rx bit width */
        if( tx->encoding == AVAGO_SERDES_PAM4 ) temp |= 1<<3; /* bit[3] = tx 1=PAM4, 0=PAM2/NRZ */
        if( rx->encoding == AVAGO_SERDES_PAM4 ) temp |= 1<<7; /* bit[7] = rx 1=PAM4, 0=PAM2/NRZ */
    mem[0x29] = temp;
/*mem[0x2a] = 0; //tx->thermal_mask; */
#if AAPL_ENABLE_AVSP_7412
    mem[0x2a] = v2_type_sel_7412;
#else
    mem[0x2a] = 0;
#endif
    mem[0x2b] = rx->phase_slip;
    mem[0x2c] = rx->signal_ok_threshold;
#if AAPL_ENABLE_AVSP_8812
    mem[0x2d] = tx->source_rx; /* Crosspoint setting */
#else
    mem[0x2d] = 0;
#endif
    /* NOTE: Update last_active_index values to match last active entry here! */
    mem[0x2e] = 0;
    mem[0x2f] = 0;
    mem[0x30] = 0;
    mem[0x31] = 0;
    mem[0x32] = 0;
    mem[0x33] = 0;
    mem[0x34] = 0;
    mem[0x35] = 0;
    mem[0x36] = 0;
    mem[0x37] = 0;
    mem[0x38] = 0;
    mem[0x39] = 0;
    mem[0x3a] = 0;
    mem[0x3b] = 0;
    mem[0x3c] = 0;
    mem[0x3d] = 0;
    mem[0x3e] = 0;
    mem[0x3f] = 0;
}

static void serdes_write_to_memory(Aapl_t *aapl, void *user_ptr, Avago_serdes_tx_state_t *tx, Avago_serdes_rx_state_t *rx)
{
    short memory[64];
    (void)user_ptr;

    avsp_state_to_memory(aapl, tx, rx, memory);

#if AAPL_USE_MDIO_WRITES
    {
        int i;
        mdio_write(aapl, tx->sbus_addr, 0, (slice->rx_divider >> 7) & 0x01);
        for( i = 1; i <= last_active_index_write; i++ )
            mdio_write_next(aapl, tx->sbus_addr, slice->rx_divider);
    }
#else
    {
        int i;
        uint mem_addr = rx->mem_addr;
        for( i = 0; i <= last_active_index_write; i++ )
            avago_sbm_write_mem(aapl, tx->sbus_addr, mem_addr++, memory[i]);
    }
#endif
}

/** @brief Writes state to SBus master memory. */
/** @return 0 on success, -1 on error. */
int avsp_state_write_to_memory(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    Avsp_state_t *state)    /**< State structure to write. */
{
    int ret;
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Write state to AVSP-%d memory on prtad %d.\n",state->device,state->prtad);

    /* Stop supervisor if running: */
    avsp_supervisor_enable(aapl, state->prtad, FALSE);

    if( state->device == 7412 )
    {
        v2_type_sel_7412 = mode_to_type_sel(state->mode);
    }
    else
        v2_type_sel_7412 = 0;
    ret = process_serdes_state(aapl, serdes_write_to_memory, NULL, state);

    avsp_write_sbm_control_vars(aapl, state);

    /* Restart supervisor if new state asks for it to be started: */
    if( (state->assp_control[0] & 1) == 0 ) /* bit 0 disables polling */
        avsp_supervisor_enable(aapl, state->prtad, TRUE);

    return ret;
}

/** @brief States the device using the values in the SBus master's memory tables. */
/** */
/** @return none. */
void avsp_state_device_from_memory(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint prtad)             /**< [in] Device address, only chip & ring parts used. */
{
    uint sbm_addr = avago_make_sbus_master_addr(avago_make_addr3(prtad,0,0));
    const char *chip_name = aapl_get_chip_name(aapl, sbm_addr);
    if( chip_name == 0 ) return;    /* Just in case... */
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "State device %u/%s from memory.\n",prtad,chip_name);
    avago_spico_int(aapl, sbm_addr, 0x26, 0x4100);
}

#endif /* AAPL_ENABLE_AVSP_STATE || AAPL_ENABLE_AVSP_8812 */


#if AAPL_ENABLE_AVSP_STATE


#if AAPL_USE_MDIO_WRITES
/* Write data to the next offset location after that most previously written. */
static int mdio_write_next(Aapl_t *aapl, uint data)
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(sbus_addr,&addr_struct);
    return avago_mdio_wr(aapl, addr_struct.chip, 8, 32786, 0x0080 | (data & 0x007f));
}

/* Write data to the offset location in the table for sbus_addr. */
static int mdio_write(Aapl_t *aapl, uint sbus_addr, uint offset, uint data)
{
    Avago_addr_t addr_struct;
    avago_addr_to_struct(sbus_addr,&addr_struct);
    avago_mdio_wr(aapl, addr_struct.chip, 8, 32786, addr_struct.sbus);
    avago_mdio_wr(aapl, addr_struct.chip, 8, 32786, 0x0040 | offset);
    return mdio_write_next(aapl, sbus_addr, data);
}
#endif


static int sign_ext(int val, int mag_bits)
{
    int sign_mask = (1 << mag_bits);
    int mag_mask = sign_mask - 1;
    int mag = val & mag_mask;
    return (val & sign_mask) ? mag|~mag_mask : mag;
}

static int get_rx_ical(Avago_serdes_rx_state_t *rx)
{
    if( !rx->run_ical     ) return 0;
    if( !rx->run_vsr_tune ) return 1;
    return 2;
}
static void set_rx_ical(Avago_serdes_rx_state_t *rx, int newValue)
{
    rx->run_ical     = newValue >= 1 ? 1 : 0;
    rx->run_vsr_tune = newValue == 2 ? 1 : 0;
}

static int get_rx_pcal(Avago_serdes_rx_state_t *rx)
{
    if( rx->run_pcal     == 0 ) return 0;
    if( rx->run_adaptive == 0 ) return 1;
    return 2;                       /* Continuous pCal */
}
static void set_rx_pcal(Avago_serdes_rx_state_t *rx, int newValue)
{
    rx->run_pcal     = newValue >= 1 ? 1 : 0;
    rx->run_adaptive = newValue == 2 ? 1 : 0;
}

/** @defgroup Avsp Avsp Functions */
/** @{ */

/** @brief   Retrieves iCal value for slice 0. */
/** */
/** @return  0 for static iCal. */
/** @return  1 for normal iCal. */
/** @return  2 for iCal & VSR (iCal w/o DFE tuning). */

int avsp_state_get_ical(
    Avsp_state_t *state)    /**< [in,out] Configuration to modify */
{
    return get_rx_ical(&state->serdes[0].rx);
}


/** @brief   Configures host slices iCal value to newValue. */
/** @details newValue can take the following values: */
/**       -  0 for static iCal, */
/**       -  1 for normal iCal, */
/**       -  2 for iCal & VSR (iCal w/o DFE tuning). */
/** */
/** @return  void */

void avsp_state_set_ical_host(
    Avsp_state_t *state,    /**< [in,out] Configuration to modify */
    int newValue)           /**< [in] pCal setting to apply */
{
    /* host slices are first, mod slices follow */
    int i;
    for( i = 0; i < AVSP_1104_HOST_NUM; i++ )
        set_rx_ical(&state->serdes[i].rx,newValue);
}

/** @brief   Configures mod slices iCal value to newValue. */
/** @details newValue can take the following values: */
/**        - 0 for static iCal, */
/**        - 1 for normal iCal, */
/**        - 2 for iCal & VSR (iCal w/o DFE tuning). */
/** */
/** @return  void */

void avsp_state_set_ical_mod(
    Avsp_state_t *state,    /**< [in,out] Configuration to modify */
    int newValue)           /**< [in] pCal setting to apply */
{
    /* host slices are first, mod slices follow */
    uint i;
    for( i = AVSP_1104_HOST_NUM; i < state->serdes_count; i++ )
        set_rx_ical(&state->serdes[i].rx,newValue);
}

/** @brief  Configures iCal value on all slices to newValue. */
/** @details newValue can take the following values: */
/**        - 0 for static iCal, */
/**        - 1 for normal iCal, */
/**        - 2 for iCal & VSR (iCal w/o DFE tuning). */
/** */
/** @return void */

void avsp_state_set_ical(
    Avsp_state_t *state,   /**< [in,out] Configuration to modify */
    int newValue)          /**< [in] pCal setting to apply */
{
    uint i;
    for( i = 0; i < state->serdes_count; i++ )
        set_rx_ical(&state->serdes[i].rx,newValue);
}

/** @brief   Retrieves pCal value for slice 0. */
/** */
/** @return  0 for pCal off. */
/** @return  1 for one-shot pCal. */
/** @return  2 for continuous pCal. */

int avsp_state_get_pcal(
    Avsp_state_t *state)    /**< [in,out] Configuration to modify */
{
    return get_rx_pcal(&state->serdes[0].rx);
}



/** @brief   Configures host slices pCal value to newValue. */
/** @details newValue can take the following values: */
/**        - 0 for pCal off, */
/**        - 1 for one-shot pCal, */
/**        - 2 for continuous pCal. */
/** */
/** @return  void */

void avsp_state_set_pcal_host(
    Avsp_state_t *state,    /**< [in,out] Configuration to modify */
    int newValue)           /**< [in] pCal setting to apply */
{
    /* host slices are first, mod slices follow */
    uint i;
    for( i = 0; i < AVSP_1104_HOST_NUM; i++ )
        set_rx_pcal(&state->serdes[i].rx,newValue);
}

/** @brief   Configures mod slices pCal value to newValue. */
/** @details newValue can take the following values: */
/**        - 0 for pCal off, */
/**        - 1 for one-shot pCal, */
/**        - 2 for continuous pCal. */
/** */
/** @return  void */

void avsp_state_set_pcal_mod(
    Avsp_state_t *state,    /**< [in,out] Configuration to modify */
    int newValue)           /**< [in] pCal setting to apply */
{
    /* host slices are first, mod slices follow */
    uint i;
    for( i = AVSP_1104_HOST_NUM; i < state->serdes_count; i++ )
        set_rx_pcal(&state->serdes[i].rx,newValue);
}


/** @brief   Configures pCal value on all slices to newValue. */
/** @details newValue can take the following values: */
/**        - 0 for pCal off, */
/**        - 1 for one-shot pCal, */
/**        - 2 for continuous pCal. */
/** */
/** @return  void */

void avsp_state_set_pcal(
    Avsp_state_t *state,    /**< [in,out] Configuration to modify */
    int newValue)           /**< [in] pCal setting to apply */
{
    uint i;
    for( i = 0; i < state->serdes_count; i++ )
        set_rx_pcal(&state->serdes[i].rx,newValue);
}

static void avsp_read_sbm_control_vars(Aapl_t *aapl, Avsp_state_t *state)
{
    /* SBus Master Int 0x26 38, State 1104: */
    /* DATA[15]     - 0 */
    /* DATA[14] Variable read/write select */
    /*    0 -- variable read */
    /*    1 -- variable write data in [6:0] */
    /* DATA[13] Task selection */
    /*    0 -- TASK */
    /*    1 -- Read/write variable */
    /* DATA[12:8] Variable select */
    /*    0: assp_var_0:         // A scratch variable which is unused elsewhere (location also serve */
    /*    1: assp_var_1:         // A scratch variable which is unused elsewhere */
    /*    2: assp_control_0:     // Some control bits still TBD: [0] select auto setup */
    /*    3: assp_control_1:     // Some control bits still TBD: [0] clear error counters on the assp */
    /*    4: assp_delay_0:       // Delay variable 0 (multiplied by 128 internally before use) */
    /*    5: assp_delay_1:       // Delay variable 1 (multiplied by 128 internally before use) */
    /*    6: assp_delay_cnt:     // Delay counter (multiplied by 16 internally, will count off steps */
    /*    7: assp_int_cnt_0:     // bits[6:0] of a counter which will be reconfigured into counter_st */
    /*    8: assp_int_cnt_1:     // bits[13:7] of a counter which will be reconfigured into counter_s */
    /*    9: assp_int_cnt_2:     // bits[20:14] of a counter which will be reconfigured into counter_ */
    /*    a: assp_int_cnt_3:     // bits[27:21] of a counter which will be reconfigured into counter_ */
    /*    b: assp_int_cnt_4:     // bits[34:28] of a counter which will be reconfigured into counter_ */
    /*    c: assp_int_cnt_5:     // bits[41:35] of a counter which will be reconfigured into counter_ */
    /*    d: assp_int_cnt_6:     // bits[47:42] of a counter which will be reconfigured into counter_ */
    /*    e: v2_host_clk_sel:    // User's selection for host clock source (only valid for PMA) */
    /*    f: v2_mod_clk_sel:     // User's selection for mod clock source (only valid for PMA) */
    /*   10: v2_speed_sel:       // User's speed selection */
    /*   11: v2_type_sel:        // User's type selection */
    /*   12: v2_control_0:       // Some control bits still TBD: */
    /*   13: v2_control_1:       // Some control bits still TBD: */
    /* DATA[15:8]   - task selection */
    /*       0x40   - load imem to xdmem */
    /*       0x41   - state part from xdmem */
    /*       0x42   - reset the status values */
    /*       0x43   - reset and enable the ctl logic */
    /*       0x46   - load xdmem with default values */
    /*       0x48   - run the 0x40 and 0x41 tasks, in order */
    /*       0x49   - run the 0x46 and 0x41 tasks, in order */
    /* DATA[6:0]    - sbus selection */
    uint sbm_addr = avago_make_sbus_master_addr(state->serdes[0].rx.sbus_addr);
    int v2_type_sel;

    /* General AVSP configuration values: */
    state->assp_user_var_0  = avago_spico_int(aapl,sbm_addr,0x26,0x2000) & 0x7f;
    state->assp_user_var_1  = avago_spico_int(aapl,sbm_addr,0x26,0x2100) & 0x7f;
    state->assp_control[0]  = avago_spico_int(aapl,sbm_addr,0x26,0x2200) & 0x7f;
    state->assp_control[1]  = avago_spico_int(aapl,sbm_addr,0x26,0x2300) & 0x7f;
    state->assp_delay[0]    = avago_spico_int(aapl,sbm_addr,0x26,0x2400) & 0x7f;
    state->assp_delay[1]    = avago_spico_int(aapl,sbm_addr,0x26,0x2500) & 0x7f;
    state->assp_delay_cnt   = avago_spico_int(aapl,sbm_addr,0x26,0x2600) & 0x7f;
    state->assp_int_cnt     = avago_spico_int(aapl,sbm_addr,0x26,0x2700) & 0x7f;
    state->assp_int_cnt   |= (avago_spico_int(aapl,sbm_addr,0x26,0x2800) & 0x7f) <<  7;
    state->assp_int_cnt   |= (avago_spico_int(aapl,sbm_addr,0x26,0x2900) & 0x7f) << 14;
    state->assp_int_cnt   |= (avago_spico_int(aapl,sbm_addr,0x26,0x2a00) & 0x7f) << 21;
    state->assp_int_cnt   |= (bigint)(avago_spico_int(aapl,sbm_addr,0x26,0x2b00) & 0x7f) << 28;
    state->assp_int_cnt   |= (bigint)(avago_spico_int(aapl,sbm_addr,0x26,0x2c00) & 0x7f) << 35;
    state->assp_int_cnt   |= (bigint)(avago_spico_int(aapl,sbm_addr,0x26,0x2d00) & 0x3f) << 42;    /* 6 bits */

    state->device_var1     = avago_spico_int(aapl,sbm_addr,0x26,0x2e00) & 0x7f;
    state->device_var2     = avago_spico_int(aapl,sbm_addr,0x26,0x2f00) & 0x7f;
    state->device_var3     = avago_spico_int(aapl,sbm_addr,0x26,0x3000) & 0x7f;
           v2_type_sel     = avago_spico_int(aapl,sbm_addr,0x26,0x3100) & 0x7f;
    state->assp_control[2] = avago_spico_int(aapl,sbm_addr,0x26,0x3200) & 0x7f;
    state->assp_control[3] = avago_spico_int(aapl,sbm_addr,0x26,0x3300) & 0x7f;
    state->mode = (v2_type_sel & 0x7e) == 0x02a ? AVSP_GEARBOX_10_4 :
                  (v2_type_sel & 0x7e) == 0x02e ? AVSP_GEARBOX_4_1 :
                  (v2_type_sel & 0x7e) == 0x02c ? AVSP_RS_FEC_528 :
               /*   (v2_type_sel & 0x7e) == 0x02b ? AVSP_RS_FEC_544 : */
                  (v2_type_sel & 0x7e) == 0x03e ? AVSP_RS_FEC :
                  (v2_type_sel & 0x7e) == 0x03a ? AVSP_GEARBOX_10_4_RS_FEC :    /* TODO: Update value 0x02a to correct value */
                  (v2_type_sel & 0x7e) == 0x028 ? AVSP_REPEATER_DUPLEX
                                                : AVSP_ADHOC;

#if AAPL_ENABLE_AVSP_4412
    if( state->device == 4412 ) state->mode = AVSP_REPEATER_DUPLEX;
#endif
#if AAPL_ENABLE_AVSP_8801
    if( state->device == 8801 ) state->mode = AVSP_REPEATER_SIMPLEX;
#endif

#if AAPL_ENABLE_AVSP_8812
    if( state->device == 8812 )
    {
        /* lower 4 bits of v2_type_sel contains half0 mode */
        state->u.a8812.half_mode[0]  = (v2_type_sel & 0x0f) == 0x001 ? AVSP_REPEATER_DUPLEX :
                                       (v2_type_sel & 0x0f) == 0x002 ? AVSP_GEARBOX_2_1 :
                                       (v2_type_sel & 0x0f) == 0x002 ? AVSP_GEARBOX_2_1_MOD_HOST :
                                       (v2_type_sel & 0x0f) == 0x003 ? AVSP_RS_FEC_4x4 : AVSP_ADHOC;
        /* lower 4 bits of v2_type_sel contains half1 mode */
        state->u.a8812.half_mode[1]  = (v2_type_sel & 0xf0) == 0x010 ? AVSP_REPEATER_DUPLEX :
                                       (v2_type_sel & 0xf0) == 0x020 ? AVSP_GEARBOX_2_1 :
                                       (v2_type_sel & 0xf0) == 0x020 ? AVSP_GEARBOX_2_1_MOD_HOST :
                                       (v2_type_sel & 0xf0) == 0x030 ? AVSP_RS_FEC_4x4 : AVSP_ADHOC;
    }
#endif
}


static void serdes_read_from_device(Aapl_t *aapl, void *user_ptr, Avago_serdes_tx_state_t *tx, Avago_serdes_rx_state_t *rx)
{
    uint addr = rx->sbus_addr;
    uint temp = 0;
    Avago_serdes_pll_state_t pll_state;
    (void)user_ptr;

    avago_serdes_get_tx_rx_ready(aapl, addr, &tx->enable, &rx->enable);
    avago_serdes_get_tx_rx_width(aapl, addr, &tx->width,  &rx->width);

    avago_serdes_get_tx_pll_state(aapl, addr, &pll_state);
    avago_serdes_get_tx_eq(aapl, addr, &tx->eq);
    tx->divider         = pll_state.divider;
    if( !tx->enable ) tx->divider = 0;
    tx->output_enable   = avago_serdes_get_tx_output_enable(aapl, addr);
    tx->polarity_invert = avago_serdes_get_tx_invert(aapl, addr);
    tx->data_sel        = avago_serdes_get_tx_data_sel(aapl, addr);
    tx->pll_clk_source  = avago_serdes_get_tx_pll_clk_src(aapl, addr);
/*  tx->thermal_mask    = 0;    // TBD: Where to read this? */
    tx->fw_revision     = avago_firmware_get_rev(aapl, addr);
    tx->fw_build_id     = avago_firmware_get_build_id(aapl, addr);
    temp                = avago_serdes_get_tx_line_encoding(aapl, addr);
    tx->encoding        = (temp == 1) ? AVAGO_SERDES_PAM4 : AVAGO_SERDES_PAM2;

    avago_serdes_get_rx_pll_state(aapl, addr, &pll_state);
    rx->divider              = pll_state.divider;
    if( !rx->enable ) rx->divider = 0;
    rx->polarity_invert      = avago_serdes_get_rx_invert(aapl, addr);
    rx->input_loopback       = avago_serdes_get_rx_input_loopback(aapl, addr);
    rx->pcs_fifo_clk_divider = avago_serdes_get_pcs_fifo_clk_div(aapl, addr);
    rx->term                 = avago_serdes_get_rx_term(aapl, addr);
    rx->cmp_data             = avago_serdes_get_rx_cmp_data(aapl, addr);
    rx->cmp_mode             = avago_serdes_get_rx_cmp_mode(aapl, addr);
    rx->data_qual            = avago_serdes_get_rx_data_qual(aapl, addr);
    rx->signal_ok_enable     = avago_serdes_get_signal_ok_enable(aapl, addr);
    rx->signal_ok_threshold  = avago_serdes_get_signal_ok_threshold(aapl, addr);
    rx->signal_ok            = avago_serdes_get_signal_ok(aapl, addr, FALSE);
    rx->errors = rx->enable ? avago_serdes_get_errors(aapl, addr, AVAGO_LSB, FALSE) : 0;
    temp                     = avago_serdes_get_rx_line_encoding(aapl, addr);
    rx->encoding             = (temp == 1) ? AVAGO_SERDES_PAM4 : AVAGO_SERDES_PAM2;
/*  TBD: */
/*  rx->phase_slip           = */
    avago_serdes_get_dfe_state(aapl, addr, &rx->dfe);
}
/** @brief   Retrieves the current state from the AVSP device. */
/** @return  On success, returns 0 and populates the #state structure describing the device. */
/** @return  On error, returns -1. */
int avsp_state_read_from_device(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    Avsp_state_t *state)    /**< State structure to update. */
{
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Read from device %d (AVSP-%d)\n",state->prtad, state->device);

    avsp_read_sbm_control_vars(aapl, state);
#if AAPL_ENABLE_AVSP_1104 || AAPL_ENABLE_AVSP_9104
    if( state->device == 1104 || state->device == 9104 )
    {
        Avago_addr_t addr_struct;
        avago_addr_to_struct(state->serdes[0].rx.sbus_addr,&addr_struct);
        state->mode = avsp_1104_get_mode(aapl, addr_struct.chip);
    }
#endif
#if AAPL_ENABLE_AVSP_8812
    if( state->device == 8812 )
    {
        Avago_addr_t addr_struct;
        avago_addr_to_struct(state->serdes[0].rx.sbus_addr,&addr_struct);
        state->u.a8812.half_mode[0] = avsp_8812_get_mode(aapl, addr_struct.chip, 0);
        state->u.a8812.half_mode[1] = avsp_8812_get_mode(aapl, addr_struct.chip, 1);
        {
            int i;
            char crosspoint[16];
            avsp_8812_crosspoint_get_all(aapl, state->prtad, crosspoint);
            for( i = 0; i < 16; i++ )
                state->serdes[i].tx.source_rx = crosspoint[i];
        }
    }
#endif
#if AAPL_ENABLE_AVSP_7412
    if( state->device == 7412 )
    {
        state->mode = avsp_7412_get_mode(aapl, state->prtad);
    }
#endif
#if AAPL_ENABLE_AVSP_5410
    if( state->device == 5410 )
    {
        state->mode = avsp_5410_get_mode(aapl, state->prtad);
    }
#endif
    return process_serdes_state(aapl, serdes_read_from_device, NULL, state);
}

static int int_bits_to_width(uint bits)
{
    return int_width_tab[ bits & 7 ];
}

/* Memory to/from state mapping functions: */
static void avsp_memory_to_state(
    Aapl_t *aapl,
    int *mem,
    Avago_serdes_tx_state_t *tx,
    Avago_serdes_rx_state_t *rx)
{
    int temp, t0;
    (void)aapl;
    tx->data_sel = AVAGO_SERDES_TX_DATA_SEL_PRBS7;
    rx->divider  = (mem[0x00] & 0x01) << 7;
    rx->divider |=  mem[0x01];
    rx->enable   = rx->divider != 0;
    tx->divider  = (mem[0x02] & 0x01) << 7;
    tx->divider |=  mem[0x03];
    tx->enable   = tx->divider != 0;
    temp         =  mem[0x04];
        tx->polarity_invert = (temp >> 0) & 1;
        rx->polarity_invert = (temp >> 1) & 1;
        rx->input_loopback  = (temp >> 2) & 1;
        if( temp & 0x08 ) tx->data_sel = AVAGO_SERDES_TX_DATA_SEL_LOOPBACK;
        t0 = (temp >> 4) & 3;
        if(      t0 == 3 ) rx->term = AVAGO_SERDES_RX_TERM_FLOAT;
        else if( t0 == 1 ) rx->term = AVAGO_SERDES_RX_TERM_AVDD;
        else               rx->term = AVAGO_SERDES_RX_TERM_AGND;

    tx->eq.pre   = sign_ext(mem[0x05],6);
    tx->eq.atten =          mem[0x06];
    tx->eq.post  = sign_ext(mem[0x07],6);
    temp         =          mem[0x08];
        rx->bypass_ctle  = (temp & 0x38) == 0x38;
        rx->run_ical     = (temp & 0x01) != 0;
        rx->dfe.fixed_dc = (temp & 0x08) != 0;
        rx->dfe.fixed_hf = (temp & 0x10) != 0;
        rx->dfe.fixed_lf = (temp & 0x20) != 0;
        rx->run_vsr_tune = (temp & 0x40) != 0;

    temp         =          mem[0x09];
        rx->bypass_ctle |= (temp & 0x38) == 0x38;
        rx->run_pcal     = (temp & 0x01) != 0;
        rx->run_adaptive = (temp & 0x02) != 0;
        rx->dfe.fixed_dc = (temp & 0x08) != 0;
        rx->dfe.fixed_hf = (temp & 0x10) != 0;
        rx->dfe.fixed_lf = (temp & 0x20) != 0;
        rx->run_vsr_tune = (temp & 0x40) != 0;

    rx->dfe.dc          =               (mem[0x0a] & 0x01) << 7;
    rx->dfe.dc         |=                mem[0x0b];
    rx->dfe.hf          =                mem[0x0c];
    rx->dfe.lf          =                mem[0x0d];
    rx->dfe.bw          =                mem[0x0e];
    rx->dfe.dfeGAIN     =                mem[0x0f];
    rx->dfe.dfeTAP[0]   = aapl_twos_comp(mem[0x10],4);
    rx->dfe.dfeTAP[1]   = aapl_twos_comp(mem[0x11],4);
    rx->dfe.dfeTAP[2]   = aapl_twos_comp(mem[0x12],4);
    rx->dfe.dfeTAP[3]   = aapl_twos_comp(mem[0x13],4);
    rx->dfe.dfeTAP[4]   = aapl_twos_comp(mem[0x14],4);
    rx->dfe.dfeTAP[5]   = aapl_twos_comp(mem[0x15],4);
    rx->dfe.dfeTAP[6]   = aapl_twos_comp(mem[0x16],4);
    rx->dfe.dfeTAP[7]   = aapl_twos_comp(mem[0x17],4);
    rx->dfe.dfeTAP[8]   = aapl_twos_comp(mem[0x18],4);
    rx->dfe.dfeTAP[9]   = aapl_twos_comp(mem[0x19],4);
    rx->dfe.dfeTAP[10]  = aapl_twos_comp(mem[0x1a],4);
    rx->dfe.vos[0]      = aapl_twos_comp((mem[0x1b] & 0x01) << 7,4);
    rx->dfe.vos[0]     |= aapl_twos_comp(mem[0x1c],4);
    rx->dfe.vos[1]      = aapl_twos_comp((mem[0x1d] & 0x01) << 7,4);
    rx->dfe.vos[1]     |= aapl_twos_comp(mem[0x1e],4);
    rx->dfe.vos[2]      = aapl_twos_comp((mem[0x1f] & 0x01) << 7,4);
    rx->dfe.vos[2]     |= aapl_twos_comp(mem[0x20],4);
    rx->dfe.vos[3]      = aapl_twos_comp((mem[0x21] & 0x01) << 7,4);
    rx->dfe.vos[3]     |= aapl_twos_comp(mem[0x22],4);
    rx->dfe.dfeGAIN_min =                mem[0x23];
    rx->dfe.dfeGAIN_max =                mem[0x24];
    temp                =                mem[0x25];
        if( tx->data_sel != AVAGO_SERDES_TX_DATA_SEL_LOOPBACK )
            tx->data_sel = (temp & 8) ? (Avago_serdes_tx_data_sel_t)(temp & 7) : AVAGO_SERDES_TX_DATA_SEL_CORE;

    temp                =                mem[0x26];
        rx->cmp_data = (Avago_serdes_rx_cmp_data_t)(temp & 7);
        t0 = (temp >> 3) & 3;
        if(      t0 == 1 )rx->cmp_mode = AVAGO_SERDES_RX_CMP_MODE_MAIN_PATGEN;
        else if( t0 == 2 )rx->cmp_mode = AVAGO_SERDES_RX_CMP_MODE_XOR;
        else if( t0 == 0 )rx->cmp_mode = AVAGO_SERDES_RX_CMP_MODE_OFF;

    rx->pcs_fifo_clk_divider =            (Avago_serdes_pcs_fifo_clk_t)(mem[0x27]<<8);
    tx->pll_clk_source       =            (Avago_serdes_tx_pll_clk_t)(mem[0x28]<<4);
    temp                     =            mem[0x29];
        tx->width = int_bits_to_width((temp >> 0) & 7);
        rx->width = int_bits_to_width((temp >> 4) & 7);
        tx->encoding = (((temp & 0x08) >> 3)==1) ? AVAGO_SERDES_PAM4 : AVAGO_SERDES_PAM2;
        rx->encoding = (((temp & 0x80) >> 7)==1) ? AVAGO_SERDES_PAM4 : AVAGO_SERDES_PAM2;
/*  tx->thermal_mask         =            mem[0x2a]; */
    v2_type_sel_7412         =            mem[0x2a];
    rx->phase_slip           =            mem[0x2b];
    rx->signal_ok_threshold  =            mem[0x2c];
    tx->source_rx            =            mem[0x2d];    /* Crosspoint setting */
    /* NOTE: Update last_active_index values to match last entry here! */
}

#if AAPL_ENABLE_FILE_IO

static void avago_get_tx_eq_limits(Aapl_t *aapl, uint addr, Avago_serdes_tx_eq_limits_t *limits)
{
    memset(limits, 0, sizeof(*limits));
    if( aapl->chips > 0 )
        avago_serdes_get_tx_eq_limits(aapl, addr, limits);
    else    /* If no device, fake it: */
    {
        Avago_addr_t addr_struct;
        avago_addr_to_struct(addr,&addr_struct);

        limits->total_eq  =  32;
        limits->atten_min =   0;
        limits->atten_max =  31;
        limits->pre_max   =  15;
        limits->post_max  =  31;

        if( addr_struct.sbus >= 0x11 && addr_struct.sbus <= 0x14 )
        {
            limits->pre_min   =   0; /* High speed SerDes */
            limits->post_min  =   0;
        }
        else
        {
            limits->pre_min   = - 7; /* Low speed SerDes */
            limits->post_min  = -31;
        }
    }
}

typedef struct
{
    uint sbus;
    Avago_serdes_tx_state_t *tx;
    Avago_serdes_rx_state_t *rx;
} Avsp_search_t;

static void serdes_find_sbus(Aapl_t *aapl, void *user_ptr, Avago_serdes_tx_state_t *tx, Avago_serdes_rx_state_t *rx)
{
    Avago_addr_t addr_struct;
    Avsp_search_t *find = (Avsp_search_t *)user_ptr;
    (void)aapl;

    avago_addr_to_struct(tx->sbus_addr, &addr_struct);
    if( addr_struct.sbus == find->sbus )
        find->tx = tx;
    avago_addr_to_struct(rx->sbus_addr, &addr_struct);
    if( addr_struct.sbus == find->sbus )
        find->rx = rx;
}

static void serdes_set_flag(Aapl_t *aapl, void *user_ptr, Avago_serdes_tx_state_t *tx, Avago_serdes_rx_state_t *rx)
{
    int value = *(int *)user_ptr;
    (void)aapl;
    (void)tx;
    rx->flags = value;
}

/** @brief   Reads a name and value from buf. */
/** @details Buf contains a name value pair separated by white space */
/**          and an equals sign.  Locate and nul terminate the name, and */
/**          store the value into *value. */
/**          Comments (starting with a '#') and extra fields are ignored. */
/** @return  The number of fields found: 0 for blank or comment lines, 1 for */
/**          only a name, 2 for name and value. */
static int get_name_value_pair(
    char *buf,              /**< [in] Line to parse. */
    char **name,            /**< [out] Pointer to name in buf. */
    char **value_string,    /**< [out] Pointer to value string in buf. */
    bigint *value)          /**< [out] Pointer to value. */
{
    const char *seps = " =\t\r\n";
    char *ptr;
    *value = 0;
    buf += strspn(buf,seps);        /* Skip separators */
    if( *buf == '#' || *buf == '\0' ) return 0;
    *name = buf;
    buf += strcspn(buf,seps);       /* Skip over name */
    if( *buf == '\0' ) return 1;
    *buf++ = '\0';
    buf += strspn(buf,seps);        /* Skip separators */
    if( *buf == '#' || *buf == '\0' ) return 1;
    *value_string = buf;
    *value = aapl_strtol(buf,&ptr,0);    /* Parse value */
    if( ptr == buf )
        return 1;       /* Invalid value */
    return 2;
}

static void serdes_read_from_text_file(Aapl_t *aapl, void *user_ptr, Avago_serdes_tx_state_t *tx, Avago_serdes_rx_state_t *rx)
{
    char buf[256];  /* Plenty big */
    FILE *file = (FILE *)user_ptr;
    (void)aapl;
    /*uint addr = tx->sbus_addr; */

    /* Set initial value so can tell if changed below... */
    tx->data_sel = AVAGO_SERDES_TX_DATA_SEL_PRBS7;

    while( fgets(buf,sizeof(buf),file) != NULL )
    {
        char *name, *str_val;
        bigint value;
        /*printf("BUF=%s\n",buf); */
        int count = get_name_value_pair(buf,&name,&str_val,&value);
        if( count == 0 ) continue;  /* Blank lines */
        /*printf("NAME=%s, value=0x%02x\n",name,value); */
        if( count == 1 )    /* Control lines */
        {
            if( EQS(name,"{") ) continue;
            if( EQS(name,"}") ) break;   /* Finished with this slice */
        }

        if(      EQS(name,"tx_divider"     ) ) tx->divider = value;
        else if( EQS(name,"rx_divider"     ) ) rx->divider = value;
        else if( EQS(name,"tx_source_rx"   ) ) tx->source_rx = value;
        else if( EQS(name,"tx_eq.pre"      ) ) tx->eq.pre = value;
        else if( EQS(name,"tx_eq.atten"    ) ) tx->eq.atten = value;
        else if( EQS(name,"tx_eq.post"     ) ) tx->eq.post = value;
        else if( EQS(name,"rx_dfe.DC"      ) ) rx->dfe.dc = value;
        else if( EQS(name,"rx_dfe.HF"      ) ) rx->dfe.hf = value;
        else if( EQS(name,"rx_dfe.LF"      ) ) rx->dfe.lf = value;
        else if( EQS(name,"rx_dfe.BW"      ) ) rx->dfe.bw = value;
        else if( EQS(name,"rx_dfe.GAIN"    ) ) rx->dfe.dfeGAIN = value;
        else if( EQS(name,"rx_dfe.tap2"    ) ) rx->dfe.dfeTAP[0] = value;
        else if( EQS(name,"rx_dfe.tap3"    ) ) rx->dfe.dfeTAP[1] = value;
        else if( EQS(name,"rx_dfe.tap4"    ) ) rx->dfe.dfeTAP[2] = value;
        else if( EQS(name,"rx_dfe.tap5"    ) ) rx->dfe.dfeTAP[3] = value;
        else if( EQS(name,"rx_dfe.tap6"    ) ) rx->dfe.dfeTAP[4] = value;
        else if( EQS(name,"rx_dfe.tap7"    ) ) rx->dfe.dfeTAP[5] = value;
        else if( EQS(name,"rx_dfe.tap8"    ) ) rx->dfe.dfeTAP[6] = value;
        else if( EQS(name,"rx_dfe.tap9"    ) ) rx->dfe.dfeTAP[7] = value;
        else if( EQS(name,"rx_dfe.tap10"   ) ) rx->dfe.dfeTAP[8] = value;
        else if( EQS(name,"rx_dfe.tap11"   ) ) rx->dfe.dfeTAP[9] = value;
        else if( EQS(name,"rx_dfe.tap12"   ) ) rx->dfe.dfeTAP[10] = value;
        else if( EQS(name,"rx_dfe.vos[0]"  ) ) rx->dfe.vos[0] = value;
        else if( EQS(name,"rx_dfe.vos[1]"  ) ) rx->dfe.vos[1] = value;
        else if( EQS(name,"rx_dfe.vos[2]"  ) ) rx->dfe.vos[2] = value;
        else if( EQS(name,"rx_dfe.vos[3]"  ) ) rx->dfe.vos[3] = value;
        else if( EQS(name,"rx_dfe.GAIN_min") ) rx->dfe.dfeGAIN_min = value;
        else if( EQS(name,"rx_dfe.GAIN_max") ) rx->dfe.dfeGAIN_max = value;
        else if( EQS(name,"rx_pcs_fifo_clk") ) rx->pcs_fifo_clk_divider = (Avago_serdes_pcs_fifo_clk_t)(value << 8);
        else if( EQS(name,"tx_pll_refclk"  ) ) tx->pll_clk_source = (Avago_serdes_tx_pll_clk_t)(value << 4);
/*      else if( EQS(name,"thermal_mask"   ) ) tx->thermal_mask = value; */

        /* Parse packed fields: */
        else if( EQS(name,"tx_invert"      ) ) tx->polarity_invert = value != 0;
        else if( EQS(name,"rx_invert"      ) ) rx->polarity_invert = value != 0;
        else if( EQS(name,"internal_lb"    ) ) rx->input_loopback  = value != 0;
        else if( EQS(name,"rx_termination" ) )
        {
            if(      value == 3 ) rx->term = AVAGO_SERDES_RX_TERM_FLOAT;
            else if( value == 1 ) rx->term = AVAGO_SERDES_RX_TERM_AVDD;
            else                  rx->term = AVAGO_SERDES_RX_TERM_AGND;
        }

        else if( EQS(name,"rx_dfe.bypass"  ) ) rx->bypass_ctle  = value != 0;
        else if( EQS(name,"rx_dfe.fixed_DC") ) rx->dfe.fixed_dc = value != 0;
        else if( EQS(name,"rx_dfe.fixed_LF") ) rx->dfe.fixed_lf = value != 0;
        else if( EQS(name,"rx_dfe.fixed_HF") ) rx->dfe.fixed_hf = value != 0;

        else if( EQS(name,"rx_dfe.VSR_tune") ) rx->run_vsr_tune = value != 0;
        else if( EQS(name,"rx_dfe.run_iCal") ) rx->run_ical     = value != 0;
        else if( EQS(name,"rx_dfe.run_pCal") ) rx->run_pcal     = value != 0;
        else if( EQS(name,"rx_dfe.adaptive") ) rx->run_adaptive = value != 0;

        else if( EQS(name,"rx_phase_slip"  ) ) rx->phase_slip          = value;
        else if( EQS(name,"signal_ok_thres") ) rx->signal_ok_threshold = value;

        else if( EQS(name,"parallel_lb"    ) )
        {
            if( value != 0 )
                tx->data_sel = AVAGO_SERDES_TX_DATA_SEL_LOOPBACK;
        }
        else if( EQS(name,"tx_data_sel"    ) )
        {
            if( value == 0 )
                tx->data_sel = AVAGO_SERDES_TX_DATA_SEL_CORE;
            /* else prbs value */
        }
        else if( EQS(name,"tx_prbs"        ) )
        {
            if( tx->data_sel == 0 )
                tx->data_sel = (Avago_serdes_tx_data_sel_t)(value & 0x07);
            /* else ignore as either CORE or LOOPBACK selected */
        }
        else if( EQS(name,"rx_data_sel"    ) || EQS(name,"rx_cmp_mode") )
        {
            if(      value == 1 ) rx->cmp_mode = AVAGO_SERDES_RX_CMP_MODE_MAIN_PATGEN;
            else if( value == 2 ) rx->cmp_mode = AVAGO_SERDES_RX_CMP_MODE_XOR;
            else                  rx->cmp_mode = AVAGO_SERDES_RX_CMP_MODE_OFF;
        }
        else if( EQS(name,"rx_prbs"        ) ) rx->cmp_data = (Avago_serdes_rx_cmp_data_t) (value & 0x07);

        else if( EQS(name,"tx_bit_width"   ) ) tx->width = (value < 8) ? int_bits_to_width(value) : value;
        else if( EQS(name,"rx_bit_width"   ) ) rx->width = (value < 8) ? int_bits_to_width(value) : value;
        else if( EQS(name,"tx_encoding"    ) ) tx->encoding = (value == 1) ? AVAGO_SERDES_PAM4 : AVAGO_SERDES_PAM2;
        else if( EQS(name,"rx_encoding"    ) ) rx->encoding = (value == 1) ? AVAGO_SERDES_PAM4 : AVAGO_SERDES_PAM2;
    }
    tx->enable = tx->divider != 0;
    rx->enable = rx->divider != 0;
}
/** @brief  Reads a state description text file into the #state structure. */
/** @return Returns 0 on success, -1 on failure. */
/** @see    avsp_state_write_to_text_file(). */
int avsp_state_read_from_text_file(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    const char *pathname,   /**< Pathname of state file to read. */
    Avsp_state_t *state)    /**< State structure to update. */
{
    BOOL v2_mode_set = FALSE;
    int one = 1;
    char buf[256];  /* Plenty big */
    FILE *file = fopen(pathname, "r");
    char chip_name_buf[32];
    int return_value = 0;

    if( file == 0 )
        return aapl_fail(aapl,__func__,0,"Cannot open %s: %s\n",pathname?pathname:"NULL", strerror(errno));

    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Read text file \"%s\".\n",pathname);

    while( fgets(buf,sizeof(buf),file) != NULL )
    {
        char *chip_name = 0;
        char *name, *str_val = 0;
        bigint value;
/*      printf("BUF=%s\n",buf); */
        int count = get_name_value_pair(buf,&name,&str_val,&value);

        if( count == 0 )
            chip_name = strstr(buf,"AVSP-");
        if( chip_name )
        {
            const char *chip_name_const = 0;
            uint prtad;
            const char *sep = " .";
            Avsp_mode_t mode = state->mode;
            char *tok_state;
            aapl_strtok_r(chip_name,sep,&tok_state);
            aapl_strtok_r(NULL,sep,&tok_state);
            prtad = aapl_strtol(aapl_strtok_r(NULL,sep,&tok_state),NULL,0);
            if( EQS(chip_name,"AVSP-8801") )        /* NOT AVSP-4412/8801 here */
            {
                mode = AVSP_REPEATER_SIMPLEX;
                chip_name_const = "AVSP-4412/8801";
            }
            else if( EQS(chip_name,"AVSP-4412") )   /* NOT AVSP-4412/8801 here */
            {
                mode = AVSP_REPEATER_DUPLEX;
                chip_name_const = "AVSP-4412/8801";
            }
            else if( EQS(chip_name,"AVSP-8812") )   /* NOT AVSP-4412/8801 here */
            {
                mode = AVSP_REPEATER_DUPLEX;
                /*state->u.a8812.half_mode[0] == AVSP_REPEATER_DUPLEX; */
                /*state->u.a8812.half_mode[1] == AVSP_REPEATER_DUPLEX; */
                chip_name_const = "AVSP-8812";
            }
            else if( EQS(chip_name,"AVSP-7412") )   /* NOT AVSP-4412/8801 here */
            {
                mode = AVSP_REPEATER_DUPLEX;
                chip_name_const = "AVSP-7412";
            }
            else if( EQS(chip_name,"AVSP-5410") )   /* AVSP-5410 */
            {
                mode = AVSP_REPEATER_DUPLEX;
                chip_name_const = "AVSP-5410";
            }
            else
                chip_name_const = chip_name;

            /* Configure structures for file being read: */
            AAPL_SUPPRESS_ERRORS_PUSH(aapl);
            /* Ignore expected errors attempting to read from the device, */
            /* as we assume the necessary info has been set above, or that */
            /* it will be read from the file. */
            avsp_state_init(aapl, prtad, chip_name_const, mode, state);
            AAPL_SUPPRESS_ERRORS_POP(aapl);

            /* Mark all as needing to be read: */
            process_serdes_state(aapl, serdes_set_flag, &one, state);
            strcpy(chip_name_buf,chip_name_const);
        }

        if( count == 0 ) continue;  /* Blank lines or comment lines */
/*      printf("NAME=%s, value=%s, str_val=\"%s\"\n",name,aapl_bigint_to_str(value),str_val); */

        if(      EQS(name,"assp_mode"         ) )
        {
            char *tok_state;
            aapl_strtok_r(str_val," #",&tok_state);
            v2_mode_set = TRUE;
            if( !aapl_str_to_avsp_mode(str_val,&state->mode)
                || (   state->mode != AVSP_REPEATER_DUPLEX
                    && state->mode != AVSP_GEARBOX_10_4
                    && state->mode != AVSP_GEARBOX_10_4_RS_FEC
                    && state->mode != AVSP_GEARBOX_2_1
                    && state->mode != AVSP_GEARBOX_4_1
                    && state->mode != AVSP_RS_FEC
                    && state->mode != AVSP_RS_FEC_528
                    && state->mode != AVSP_RS_FEC_544
                   ) )
            {
                aapl_log_printf(aapl,AVAGO_WARNING,__func__,__LINE__,"Invalid value for %s: %s\n",name,str_val);
            }

            avsp_state_init(aapl, state->prtad, chip_name_buf, state->mode, state);
            process_serdes_state(aapl, serdes_set_flag, &one, state);
        }
        else if( EQS(name,"gb_host_clk_sel" ) ) state->device_var1      = value;
        else if( EQS(name,"gb_mod_clk_sel"  ) ) state->device_var2      = value;
#if AAPL_ENABLE_AVSP_8812
        else if( EQS(name,"half0_mode"      ) )
        {
            char *tok_state;
            aapl_strtok_r(str_val," #",&tok_state);
            if( !aapl_str_to_avsp_mode(str_val,&state->u.a8812.half_mode[0])
                || (   state->u.a8812.half_mode[0] != AVSP_REPEATER_DUPLEX
                    && state->u.a8812.half_mode[0] != AVSP_GEARBOX_2_1
                    && state->u.a8812.half_mode[0] != AVSP_RS_FEC_4x4
                    && state->u.a8812.half_mode[0] != AVSP_GEARBOX_2_1_MOD_HOST
                   ) )
            {
                aapl_log_printf(aapl,AVAGO_WARNING,__func__,__LINE__,"Invalid value for %s: %s\n",name,str_val);
            }

        }
        else if( EQS(name,"half1_mode"      ) )
        {
            char *tok_state;
            aapl_strtok_r(str_val," #",&tok_state);
            if( !aapl_str_to_avsp_mode(str_val,&state->u.a8812.half_mode[1])
                || (   state->u.a8812.half_mode[1] != AVSP_REPEATER_DUPLEX
                    && state->u.a8812.half_mode[1] != AVSP_GEARBOX_2_1
                    && state->u.a8812.half_mode[1] != AVSP_RS_FEC_4x4
                    && state->u.a8812.half_mode[1] != AVSP_GEARBOX_2_1_MOD_HOST
                   ) )
            {
                aapl_log_printf(aapl,AVAGO_WARNING,__func__,__LINE__,"Invalid value for %s: %s\n",name,str_val);
            }
        }
#endif
        else if( EQS(name,"mdio_speed_sel"  ) ) state->device_var3      = value;
        else if( EQS(name,"assp_control[2]" ) ) state->assp_control[2]  = value;
        else if( EQS(name,"assp_control[3]" ) ) state->assp_control[3]  = value;

        else if( EQS(name,"assp_user_var[0]") ) state->assp_user_var_0  = value;
        else if( EQS(name,"assp_user_var[1]") ) state->assp_user_var_1  = value;
        else if( EQS(name,"assp_control[0]" ) ) state->assp_control[0]  = value;
        else if( EQS(name,"assp_control[1]" ) ) state->assp_control[1]  = value;
        else if( EQS(name,"assp_delay[0]"   ) ) state->assp_delay[0]    = value;
        else if( EQS(name,"assp_delay[1]"   ) ) state->assp_delay[1]    = value;
        else if( EQS(name,"assp_delay_cnt"  ) ) state->assp_delay_cnt   = value;
        else if( EQS(name,"assp_int_cnt"    ) ) state->assp_int_cnt     = value;

        if( EQS(name,"Slice") )
        {
            /* Find tx and rx corresponding to the input data: */
            Avsp_search_t find;
            Avago_addr_t addr_struct;
            uint addr;
            /* printf("str_val = %s\n",str_val); */

            find.tx = 0;
            find.rx = 0;
            find.sbus = 0;
            {
                /* Separate address token: */
                char *ptr = strchr(str_val,' ');
                if( ptr ) *ptr = '\0';
            }
            if( aapl_str_to_addr(str_val,0,&addr) )
            {
                avago_addr_to_struct(addr, &addr_struct);
                find.sbus = addr_struct.sbus;
            }
            process_serdes_state(aapl, serdes_find_sbus, &find, state);
            if( find.tx == 0 || find.rx == 0 )
            {
                return_value = aapl_fail(aapl, __func__, __LINE__, "Aborting read: SBus address 0x%x in file does not exist in part.\n", find.sbus);
                break;
            }
            if( find.rx->flags == 0 )
            {
                return_value = aapl_fail(aapl, __func__, __LINE__, "Aborting read: Duplicate entries for SBus address 0x%x.\n", find.sbus);
                break;
            }
            find.rx->flags = 0;
            serdes_read_from_text_file(aapl, file, find.tx, find.rx);
        }
    }
    if( state->device == 1104 && !v2_mode_set )
    {
        /* Magic number: Gearbox doesn't use SerDes 14-19, so a zero divider here indicates Gearbox mode. */
        state->mode = state->serdes[14].rx.divider == 0 ? AVSP_GEARBOX_10_4 : AVSP_REPEATER_DUPLEX;
    }

    return fclose(file) | return_value;
}

/* Write state for one SerDes to text file: */
static void serdes_write_to_text_file(Aapl_t *aapl, void *user_ptr, Avago_serdes_tx_state_t *tx, Avago_serdes_rx_state_t *rx)
{
    FILE *file = (FILE *)user_ptr;
    uint addr = tx->sbus_addr;
    Avago_serdes_tx_eq_limits_t limits;
    Avago_addr_t addr_struct;
    uint base_addr;
    avago_addr_to_struct(addr,&addr_struct);

    avago_get_tx_eq_limits(aapl, addr, &limits);
    base_addr = avago_make_addr3(0,0,addr_struct.sbus);

    fprintf(file,"Slice %s (", aapl_addr_to_str(base_addr));
    if( tx->sd_num >= 0 ) fprintf(file,"SD %d ", tx->sd_num);
    fprintf(file,"at 0x%04x) =\n", rx->mem_addr);
    fprintf(file,"{\n");
    fprintf(file,"    rx_divider     =  %3u\n",rx->divider);
    fprintf(file,"    tx_divider     =  %3u\n",tx->divider);
    if( tx->sd_num >= 0 )
        fprintf(file,"    tx_source_rx   =  %3u  # [0..15] SD number of source Rx\n",tx->source_rx & 0xf);

    fprintf(file,"    rx_invert      =  %3d  # 1=invert\n", rx->polarity_invert);
    fprintf(file,"    tx_invert      =  %3d  # 1=invert\n", tx->polarity_invert);
    fprintf(file,"    internal_lb    =  %3d  # 1=on\n",     rx->input_loopback);
    fprintf(file,"    parallel_lb    =  %3d  # 1=on\n",     tx->data_sel == AVAGO_SERDES_TX_DATA_SEL_LOOPBACK);
    fprintf(file,"    rx_termination =  %3d  # 0=low, 1=high, 2=invalid, 3=float\n",
                                                rx->term == AVAGO_SERDES_RX_TERM_AGND ? 0 :
                                                rx->term == AVAGO_SERDES_RX_TERM_AVDD ? 1 : 3);

    fprintf(file,"    tx_eq.pre      =  %3d  # [%d..%d]\n",tx->eq.pre,limits.pre_min,limits.pre_max);
    fprintf(file,"    tx_eq.atten    =  %3d  # [%d..%d]\n",tx->eq.atten,limits.atten_min,limits.atten_max);
    fprintf(file,"    tx_eq.post     =  %3d  # [%d..%d]\n",tx->eq.post,limits.post_min,limits.post_max);
    fprintf(file,"                           # Note: Total tx_eq must be <= %d\n",limits.total_eq);
    fprintf(file,"\n");
    fprintf(file,"    rx_dfe.bypass   = %3u  # 1==Bypass CTLE\n",       rx->bypass_ctle);
    fprintf(file,"    rx_dfe.fixed_DC = %3u  # 1==tune with fixed DC\n",rx->dfe.fixed_dc);
    fprintf(file,"    rx_dfe.VSR_tune = %3u  # 1==VSR Tune\n",          rx->run_vsr_tune);
    fprintf(file,"    rx_dfe.fixed_LF = %3u  # 1==tune with fixed LF\n",rx->dfe.fixed_lf);
    fprintf(file,"    rx_dfe.fixed_HF = %3u  # 1==tune with fixed HF\n",rx->dfe.fixed_hf);

    fprintf(file,"    rx_dfe.run_iCal = %3u  # 1==Run Coarse Tuning\n",  rx->run_ical);
    fprintf(file,"    rx_dfe.run_pCal = %3u  # 1==Run Fine Tuning\n",    rx->run_pcal);
    fprintf(file,"    rx_dfe.adaptive = %3u  # 1==Run Continuous pCal\n",rx->run_adaptive);
    fprintf(file,"                           # If fixed_XX is set, the XX setting is loaded\n");
    fprintf(file,"                           #   before dfe tuning is executed.\n");
    fprintf(file,"\n");
    fprintf(file,"    rx_dfe.DC       = %3u  # [0..255]\n",rx->dfe.dc);    /* DFE */
    fprintf(file,"    rx_dfe.HF       = %3u  # [0..15]\n",rx->dfe.hf);
    fprintf(file,"    rx_dfe.LF       = %3u  # [0..15]\n",rx->dfe.lf);
    fprintf(file,"    rx_dfe.BW       = %3u  # [0..15]\n",rx->dfe.bw);
    fprintf(file,"    rx_dfe.GAIN     = %3d  # [0..15]\n",rx->dfe.dfeGAIN);
    fprintf(file,"    rx_dfe.tap2     = %3d  # [-15..15]\n",rx->dfe.dfeTAP[0]);
    fprintf(file,"    rx_dfe.tap3     = %3d  # [-15..15]\n",rx->dfe.dfeTAP[1]);
    fprintf(file,"    rx_dfe.tap4     = %3d  # [-15..15]\n",rx->dfe.dfeTAP[2]);
    fprintf(file,"    rx_dfe.tap5     = %3d  # [-15..15]\n",rx->dfe.dfeTAP[3]);
    fprintf(file,"    rx_dfe.tap6     = %3d  # [-15..15]\n",rx->dfe.dfeTAP[4]);
    fprintf(file,"    rx_dfe.tap7     = %3d  # [-15..15]\n",rx->dfe.dfeTAP[5]);
    fprintf(file,"    rx_dfe.tap8     = %3d  # [-15..15]\n",rx->dfe.dfeTAP[6]);
    fprintf(file,"    rx_dfe.tap9     = %3d  # [-15..15]\n",rx->dfe.dfeTAP[7]);
    fprintf(file,"    rx_dfe.tap10    = %3d  # [-15..15]\n",rx->dfe.dfeTAP[8]);
    fprintf(file,"    rx_dfe.tap11    = %3d  # [-15..15]\n",rx->dfe.dfeTAP[9]);
    fprintf(file,"    rx_dfe.tap12    = %3d  # [-15..15]\n",rx->dfe.dfeTAP[10]);
    fprintf(file,"    rx_dfe.vos[0]   = %3d  # [0..255]\n",rx->dfe.vos[0]);
    fprintf(file,"    rx_dfe.vos[1]   = %3d  # [0..255]\n",rx->dfe.vos[1]);
    fprintf(file,"    rx_dfe.vos[2]   = %3d  # [0..255]\n",rx->dfe.vos[2]);
    fprintf(file,"    rx_dfe.vos[3]   = %3d  # [0..255]\n",rx->dfe.vos[3]);
    fprintf(file,"    rx_dfe.GAIN_min = %3u  # [0..15]\n",rx->dfe.dfeGAIN_min);
    fprintf(file,"    rx_dfe.GAIN_max = %3u  # [0..15]\n",rx->dfe.dfeGAIN_max);
    fprintf(file,"\n");

    fprintf(file,"    rx_cmp_mode     = %3d  # 0=off, 1=M^P, 2=M^T, 3=invalid\n",
                                    rx->cmp_mode == AVAGO_SERDES_RX_CMP_MODE_MAIN_PATGEN ? 1 :
                                    rx->cmp_mode == AVAGO_SERDES_RX_CMP_MODE_XOR         ? 2 : 0);

    fprintf(file,"    tx_data_sel     = %3d  # 0=CORE, 1=PRBS\n", tx->data_sel == AVAGO_SERDES_TX_DATA_SEL_CORE ? 0 : 1);
    fprintf(file,"\n");
    fprintf(file,"                           # Valid prbs values: (SerDes int 0x02)\n");
    fprintf(file,"    rx_prbs         = %3d  # 0=prbs7, 1=prbs9, 2=prbs11, 3=prbs15\n",rx->cmp_data & 7);
    fprintf(file,"    tx_prbs         = %3d  # 4=prbs23, 5=prbs31, 6=unused, 7=user\n", tx->data_sel > 7 ? 0 : tx->data_sel & 7);
    fprintf(file,"\n");

    fprintf(file,"    rx_bit_width    = %3d  # SerDes int 0x14 DATA[6:4]\n",rx->width);
    fprintf(file,"    tx_bit_width    = %3d  # SerDes int 0x14 DATA[2:0]\n",tx->width);
    fprintf(file,"                           # 0=10 bit, 1=20 bit, 2=20 bit, 3=40 bit\n");
    fprintf(file,"                           # 4=16 bit, 5=32 bit, 6=64 bit, 7=80 bit\n");
    fprintf(file,"                           # May input bitmask [0..7], or width [10,20,...]\n");
    fprintf(file,"\n");

    fprintf(file,"    rx_encoding     = %3d  # SerDes int 0x14 DATA[8]\n",rx->encoding);
    fprintf(file,"    tx_encoding     = %3d  # SerDes int 0x14 DATA[4]\n",tx->encoding);
    fprintf(file,"                           # 0=NRZ/PAM2, 1=PAM4\n");

    fprintf(file,"    rx_pcs_fifo_clk = %3u  # SerDes int 0x30 DATA[11:8]\n",rx->pcs_fifo_clk_divider >> 8);
    fprintf(file,"                           # 0=F66, 8=F50, 9=F60, 10=F70, 11=F80\n");
    fprintf(file,"                           # 12=F90, 13=F100, 14=F110, 15=F120\n");
    fprintf(file,"\n");

    fprintf(file,"    tx_pll_refclk   = %3u  # SerDes int 0x30 DATA[7:4]\n",tx->pll_clk_source >> 4);
    fprintf(file,"                           # 0=REFCLK, 1=RX_DIVX, 3=1'b0, 7=i_pcie_core_clk\n");
    fprintf(file,"                           # 15=i_pcie_core_clk/2\n");
    fprintf(file,"\n");

/*  fprintf(file,"    thermal_mask    = %3u\n",tx->thermal_mask); */
    fprintf(file,"    rx_phase_slip   = %3d\n",rx->phase_slip);
    fprintf(file,"    signal_ok_thres = %3d  # SerDes int 0x20 DATA[11:8]\n",rx->signal_ok_threshold);
    fprintf(file,"}\n\n");
}

/** @brief  Writes #state structure to a state description text file. */
/** @return Returns 0 on success, -1 on failure. */
/** @see    avsp_state_read_from_text_file(). */
int avsp_state_write_to_text_file(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    const char *pathname,   /**< Pathname of state file to write. */
    Avsp_state_t *state)    /**< State structure to write. */
{
    FILE *file = strcmp(pathname,"-") ? fopen(pathname, "wb") : stdout;

    if( file == 0 )
        return aapl_fail(aapl,__func__,0,"Cannot open %s: %s\n",pathname?pathname:"NULL", strerror(errno));

    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Write text file \"%s\".\n",pathname);

    fprintf(file,"# State file for the %d SerDes on AVSP-%d device %d.\n",
                        state->serdes_count,
                        state->device,
                        state->prtad);
    fprintf(file,"\n");
    fprintf(file,"sbus_master_revision = 0x%04X\n", state->sbm_fw_revision);
    fprintf(file,"sbus_master_build_id = 0x%04X\n", state->sbm_fw_build_id);
    fprintf(file,"\n");

    fprintf(file,"# Device configuration values:\n");
    if( state->device == 1104 || state->device == 9104 )
    {
        fprintf(file,"assp_mode            = %s # RPT, 10:4, 10:4_RS_FEC, 10:4_MLG\n", aapl_avsp_mode_to_str(state->mode));
        fprintf(file,"gb_host_clk_sel      = 0x%02x  # [0-9]\n", state->device_var1);
        fprintf(file,"gb_mod_clk_sel       = 0x%02x  # [0-3]\n", state->device_var2);
        fprintf(file,"mdio_speed_sel       = 0x%02x  # Must be 0x0f.\n", state->device_var3);
    }
    if( state->device == 7412 )
    {
        fprintf(file,"assp_mode            = %s # RPT, 2:1, RS_FEC_528, RS_FEC_544\n", aapl_avsp_mode_to_str(state->mode));
    }

    if( state->device == 5410 )
    {
        fprintf(file,"assp_mode            = %s # RPT, 4:1, RS_FEC\n", aapl_avsp_mode_to_str(state->mode));
    }
#if AAPL_ENABLE_AVSP_8812
    if( state->device == 8812 )
    {
        fprintf(file,"half0_mode            = %s # RPT, 2:1_GB, 1:2_GB, FEC\n", aapl_avsp_mode_to_str(state->u.a8812.half_mode[0]));
        fprintf(file,"half1_mode            = %s # RPT, 2:1_GB, 1:2_GB, FEC\n", aapl_avsp_mode_to_str(state->u.a8812.half_mode[1]));

    }
#endif

    fprintf(file,"assp_user_var[0]     = 0x%02x  # [0x0-0x7f] unused by Avago\n", state->assp_user_var_0);
    fprintf(file,"assp_user_var[1]     = 0x%02x  # [0x0-0x7f] unused by Avago\n", state->assp_user_var_1);
    fprintf(file,"assp_control[0]      = 0x%02x  # [0x0-0x7f], default = 0x01\n", state->assp_control[0]);
    fprintf(file,"                               # Self-Healing control bits: [bit] default description\n");
    fprintf(file,"                               # [0] 1 Clear to state with self-healing active.\n");
    fprintf(file,"                               # [1] 0 Set to start tuning with minimum signal.\n");
    fprintf(file,"                               #       Clear to require freq lock before tuning.\n");
    fprintf(file,"                               # [2] 0 Set to squelch TX output when RX link is down.\n");
    fprintf(file,"                               # [3] 0 RESERVED. 0 == retimers, 1 == gearboxes.\n");
    fprintf(file,"                               # [4] 0 Set to reuse initial valid DFE value when recovering future link down events.\n");
    fprintf(file,"                               # [5] 0 Set to skip DFE tuning altogether.\n");
    fprintf(file,"                               # [6] 0 Manage start/stop of adaptive tuning (pCal)\n");
    fprintf(file,"                               #       during healing, on slices that enable pCal below.\n");
    fprintf(file,"assp_control[1]      = 0x%02x  # [0x0-0x7f]\n", state->assp_control[1]);
    fprintf(file,"assp_control[2]      = 0x%02x  # [0x0-0x7f]\n", state->assp_control[2]);
    fprintf(file,"assp_control[3]      = 0x%02x  # [0x0-0x7f]\n", state->assp_control[3]);

    fprintf(file,"assp_delay[0]        = 0x%02x  # [0x0-0x7f]\n", state->assp_delay[0]);
    fprintf(file,"assp_delay[1]        = 0x%02x  # [0x0-0x7f]\n", state->assp_delay[1]);
    fprintf(file,"assp_delay_cnt       = 0x%02x  # [0x0-0x7f]\n", state->assp_delay_cnt);
    fprintf(file,"assp_int_cnt         = %5s # 48 bit value\n", aapl_bigint_to_str(state->assp_int_cnt));
    fprintf(file,"\n");

    fprintf(file,"# SerDes configuration:\n");
    fprintf(file,"\n");

    process_serdes_state(aapl, serdes_write_to_text_file, file, state);

    return (file != stdout) ? fclose(file) : 0;
}

static void serdes_read_from_sdi(Aapl_t *aapl, void *user_ptr, Avago_serdes_tx_state_t *tx, Avago_serdes_rx_state_t *rx)
{
    int **sdi_mem = (int **)user_ptr;
    avsp_memory_to_state(aapl, *sdi_mem, tx, rx);
    *sdi_mem += last_active_index_read + 1;
}
/** @return Size of memory header, 0 if none. */
static int read_sdi_header(Aapl_t *aapl, int *sdi_mem, Avsp_state_t *state, BOOL do_init)
{
    Avsp_mode_t mode = AVSP_REPEATER_DUPLEX;
    const char *chip_name = 0;
    int index = 0;
    int magic_0 = sdi_mem[index++];  /* PROD_IMEM_MAGIC_NUM0 */
    int magic_1 = sdi_mem[index++];  /* PROD_IMEM_MAGIC_NUM1 */
    int magic_a = sdi_mem[index++];  /* ASSP_IMEM_MAGIC_NUM */
    int magic_m = sdi_mem[index++];  /* MDIO_IMEM_MAGIC_NUM */
    int n = sdi_mem[index++];  /* ASSP_SLICE_CNT */
    int l = sdi_mem[index++];  /* SERDES_LAST_REG */
    int prod_var_cnt = sdi_mem[index++];  /* PROD_IMEM_VAR_CNT */
    int assp_var_cnt = sdi_mem[index++];  /* ASSP_IMEM_VAR_CNT */
    int mdio_var_cnt = sdi_mem[index++];  /* MDIO_IMEM_VAR_CNT */
    if( magic_a == ASSP_IMEM_MAGIC_NUM && magic_m == MDIO_IMEM_MAGIC_NUM )
    {
        state->magic[0] = magic_0;
        state->magic[1] = magic_1;
        state->magic[2] = magic_a;
        state->magic[3] = magic_m;
        if( magic_0 == PROD_IMEM_MAGIC_NUM0_E && magic_1 == PROD_IMEM_MAGIC_NUM1_E && n == 8 )
        {
            chip_name = "AVSP-4412/8801";
#if AAPL_ENABLE_AVSP_4412
            state->device = 4412;
#else
            state->device = 8801;
#endif
        }
        else if( magic_0 == PROD_IMEM_MAGIC_NUM0_E && magic_1 == PROD_IMEM_MAGIC_NUM1_E && n == 16 )
        {
            chip_name = "AVSP-8812";
            state->device = 8812;
        }
        else if( magic_0 == PROD_IMEM_MAGIC_NUM0_O && magic_1 == PROD_IMEM_MAGIC_NUM1_O && n == 3)
        {
            chip_name = "AVSP-7412";
            state->device = 7412;
        }
        else if( magic_0 == PROD_IMEM_MAGIC_NUM0_V && magic_1 == PROD_IMEM_MAGIC_NUM1_V && n == 20 )
        {
            chip_name = "AVSP-1104";
            state->device = 1104;
        }
        else if( magic_0 == PROD_IMEM_MAGIC_NUM0_M && magic_1 == PROD_IMEM_MAGIC_NUM1_M && n == 20 )
        {
            chip_name = "AVSP-9104";
            state->device = 9104;
        }
        else if( magic_0 == PROD_IMEM_MAGIC_NUM0_M && magic_1 == PROD_IMEM_MAGIC_NUM1_M && n == 5 )
        {
            chip_name = "AVSP-5410";
            state->device = 5410;
        }
    }
    if( chip_name == 0 )
    {
        return 0;       /* Unknown values, so assume it's an sdi file without a header. */
    }
    if( prod_var_cnt > 0 ) /* PROD_IMEM_VAR_CNT */
    {
        if( prod_var_cnt >= 6 )
        {
            int val;
            state->device_var1 = sdi_mem[index++];
            state->device_var2 = sdi_mem[index++];
            state->device_var3 = sdi_mem[index++];
            if( state->device == 8812 )
            {
                val                = sdi_mem[index++] & 0x7f;
                /* lower 4 bits of v2_type_sel contains half0 mode */
#if AAPL_ENABLE_AVSP_8812
                state->u.a8812.half_mode[0]  = (val & 0x0f) == 0x001 ? AVSP_REPEATER_DUPLEX :
                                               (val & 0x0f) == 0x002 ? AVSP_GEARBOX_2_1 :
                                               (val & 0x0f) == 0x004 ? AVSP_GEARBOX_2_1_MOD_HOST :
                                               (val & 0x0f) == 0x003 ? AVSP_RS_FEC_4x4 : AVSP_ADHOC;
                /* lower 4 bits of v2_type_sel contains half1 mode */
                state->u.a8812.half_mode[1]  = (val & 0xf0) == 0x010 ? AVSP_REPEATER_DUPLEX :
                                               (val & 0xf0) == 0x020 ? AVSP_GEARBOX_2_1 :
                                               (val & 0xf0) == 0x040 ? AVSP_GEARBOX_2_1_MOD_HOST :
                                               (val & 0xf0) == 0x030 ? AVSP_RS_FEC_4x4 : AVSP_ADHOC;
#endif
            }
            else
                val                = sdi_mem[index++] & 0x7e;

            if( val == 0x02a )
                mode = AVSP_GEARBOX_10_4;
            else if( val == 0x03a )  /* TODO: Update the 0x02a to the correct value... */
                mode = AVSP_GEARBOX_10_4_RS_FEC;
            else if( val == 0x02e )
                mode = AVSP_GEARBOX_4_1;
           else if( val == 0x03e )
                mode = AVSP_RS_FEC;
            else if( val == 0x028 )
                mode = AVSP_REPEATER_DUPLEX;
            else if( val == 0x02b )
                mode = AVSP_RS_FEC_544;
            else if( val == 0x02c )
                mode = AVSP_RS_FEC_528;
            else
                mode = AVSP_ADHOC;
            if( mode == AVSP_REPEATER_DUPLEX )
            {
                if( state->device == 8801 )
                    mode = AVSP_REPEATER_SIMPLEX;
            }
            if( state->device == 7412 )
                    mode = AVSP_REPEATER_DUPLEX; /* update state with default mode, as for 7412 actual mode is read from serdes XDMEM location */

            state->assp_control[2]   = sdi_mem[index++];
            state->assp_control[3]   = sdi_mem[index++];
            prod_var_cnt -= 6;
            state->prod_var_cnt = 6;
        }
        while( prod_var_cnt-- > 0 )
            index++;  /* Skip var */
    }
    if( assp_var_cnt > 0 )  /* ASSP_IMEM_VAR_CNT */
    {
        if( assp_var_cnt >= 14 )
        {
            state->assp_user_var_0  = sdi_mem[index++];
            state->assp_user_var_1  = sdi_mem[index++];
            state->assp_control[0]  = sdi_mem[index++];
            state->assp_control[1]  = sdi_mem[index++];
            state->assp_delay[0]    = sdi_mem[index++];
            state->assp_delay[1]    = sdi_mem[index++];
            state->assp_delay_cnt   = sdi_mem[index++];
            state->assp_int_cnt    = (sdi_mem[index++] & 0x7f) <<  0;
            state->assp_int_cnt   |= (sdi_mem[index++] & 0x7f) <<  7;
            state->assp_int_cnt   |= (sdi_mem[index++] & 0x7f) << 14;
            state->assp_int_cnt   |= (sdi_mem[index++] & 0x7f) << 21;
            state->assp_int_cnt   |= (bigint)(sdi_mem[index++] & 0x7f) << 28;
            state->assp_int_cnt   |= (bigint)(sdi_mem[index++] & 0x7f) << 35;
            state->assp_int_cnt   |= (bigint)(sdi_mem[index++] & 0x3f) << 42;
            assp_var_cnt -= 14;
            state->assp_var_cnt = 14;
        }
        while( assp_var_cnt-- > 0 )
            index++;  /* Skip var */
    }
    while( mdio_var_cnt-- > 0 )
        index++;  /* Skip var */

    last_active_index_read = l;

    if( do_init )
        avsp_state_init(aapl, state->prtad, chip_name, mode, state);

    return index;
}
static int get_sdi_header_mem(Aapl_t *aapl, short *mem, Avsp_state_t *state)
{
    int index = 0;
    (void)aapl;
    mem[index++] = state->magic[0];     /* PROD_IMEM_MAGIC_NUM0 */
    mem[index++] = state->magic[1];     /* PROD_IMEM_MAGIC_NUM1 */
    mem[index++] = state->magic[2];     /* ASSP_IMEM_MAGIC_NUM */
    mem[index++] = state->magic[3];     /* MDIO_IMEM_MAGIC_NUM */
    mem[index++] = state->serdes_count; /* ASSP_SLICE_CNT */
    mem[index++] = last_active_index_write; /* SERDES_LAST_REG */
    mem[index++] = state->prod_var_cnt; /* PROD_IMEM_VAR_CNT */
    mem[index++] = state->assp_var_cnt; /* ASSP_IMEM_VAR_CNT */
    mem[index++] = 0;                   /* MDIO_IMEM_VAR_CNT, 0 or 0x18 */

    if( state->prod_var_cnt == 6 )
    {
        int v2_type_sel = mode_to_type_sel(state->mode);
        if( state->device == 7412 )
            v2_type_sel_7412 = v2_type_sel;
        else
            v2_type_sel_7412 = 0;
#if AAPL_ENABLE_AVSP_8812
        if( state->device == 8812 )
        {
            if( state->u.a8812.half_mode[0] == AVSP_REPEATER_DUPLEX ) /* update lower 4 bits of v2_type_sel with the given mode for half0 */
                v2_type_sel = 0x001;
            else
                v2_type_sel = mode_to_type_sel(state->u.a8812.half_mode[0]);

            if( state->u.a8812.half_mode[1] == AVSP_REPEATER_DUPLEX ) /* update upper 4 bits of v2_type_sel with the given mode for half1 */
                v2_type_sel = v2_type_sel | (0x001 << 4);
            else
                v2_type_sel = v2_type_sel | (mode_to_type_sel(state->u.a8812.half_mode[1]) << 4);
        }
#endif
        mem[index++] = state->device_var1;     /* (0-9) */
        mem[index++] = state->device_var2;     /* (0-3) */
        mem[index++] = 0x0f;                   /* device_var3, must be 0x0f */
        mem[index++] = v2_type_sel;
        mem[index++] = state->assp_control[2];
        mem[index++] = state->assp_control[3];
    }
    if( state->assp_var_cnt == 0x0e )
    {
        mem[index++] = state->assp_user_var_0;
        mem[index++] = state->assp_user_var_1;
        mem[index++] = state->assp_control[0];
        mem[index++] = state->assp_control[1];
        mem[index++] = state->assp_delay[0];
        mem[index++] = state->assp_delay[1];
        mem[index++] = state->assp_delay_cnt;
        mem[index++] = state->assp_int_cnt >>  0 & 0x7f;
        mem[index++] = state->assp_int_cnt >>  7 & 0x7f;
        mem[index++] = state->assp_int_cnt >> 14 & 0x7f;
        mem[index++] = state->assp_int_cnt >> 21 & 0x7f;
        mem[index++] = state->assp_int_cnt >> 28 & 0x7f;
        mem[index++] = state->assp_int_cnt >> 35 & 0x7f;
        mem[index++] = state->assp_int_cnt >> 42 & 0x3f;
    }
    return index;
}

/** @brief   Reads state from a Serdes Device Information file. */
/** @details The SDI file is a ROM format file containing the SBus master memory tables. */
/** @return  0 on success, -1 on error. */
/** @see     avsp_state_write_to_sdi_file(). */
int avsp_state_read_from_sdi_file(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    const char *pathname,   /**< Pathname of state file to read. */
    Avsp_state_t *state)    /**< State structure to update. */
{
    int sdi_size;
    int *sdi_mem;

    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Read sdi file \"%s\".\n",pathname);
    if( avago_load_rom_from_file(aapl, pathname, &sdi_size, &sdi_mem) == 0 )
    {
        int ret = 0;
        int *sdi_mem_ptr = sdi_mem;
        /*printf("sdi_mem[sdi_size-5] = 0x%02x\n",sdi_mem[sdi_size-5]); */
        if( sdi_mem[sdi_size-5] == 0x4e &&
            (sdi_mem[2] == 0 || sdi_mem[2] == 2) &&
            (sdi_mem[3] == 4 || sdi_mem[3] == 10) )   /* Looks like it might be new format */
        {
            int len = (sdi_mem[0] & 0xff) << 8 | (sdi_mem[1] & 0xff);
            /*printf("sdi_size = %d, len = %d\n",sdi_size, len); */
            if( len == sdi_size - 5 )
            {
                int sdi_ptr_off = sdi_mem[3];
                int offset = (sdi_mem[sdi_ptr_off] & 0xff) << 8 | (sdi_mem[sdi_ptr_off+1] & 0xff);
                /*printf("sdi_offset = %d\n",offset); */
                sdi_mem_ptr += offset;
            }
            else /* perhaps this is an SBM image with the SDI appended... */
            {
                /* Plan of action: Repeat: Find next 0x4e byte, skip 4, read hi/lo length and it should */
                /* refer to 5 less than end.  If so, verify checksum, and if */
                /* ok, we've found SDI table.  Set offset and break. */
            }
        }

        /* initialize the state based on the data, then update vars: */
        read_sdi_header(aapl, sdi_mem_ptr, state, TRUE);
        sdi_mem_ptr += read_sdi_header(aapl, sdi_mem_ptr, state, FALSE);

        ret = process_serdes_state(aapl, serdes_read_from_sdi, &sdi_mem_ptr, state);
        if( state->device == 7412 )
        {
            state->mode = (v2_type_sel_7412 & 0x7f) == 0x02c ? AVSP_RS_FEC_528 :
                          (v2_type_sel_7412 & 0x7f) == 0x028 ? AVSP_REPEATER_DUPLEX :
                          (v2_type_sel_7412 & 0x7f) == 0x002 ? AVSP_GEARBOX_2_1 :
                          (v2_type_sel_7412 & 0x7f) == 0x02b ? AVSP_RS_FEC_544 :
                                                    AVSP_ADHOC;
        }

        /* Determine mode when reading from an old .sdi file: */
        if( state->device == 1104 && state->prod_var_cnt == 0 && state->serdes[14].rx.divider == 0 )
        {
            state->mode = AVSP_GEARBOX_10_4;
            state->prod_var_cnt = 6;
        }

        aapl_free(aapl, sdi_mem, "sdi_mem");
        return ret;
    }
    return -1;
}

/** @brief  Allocate and populate an SDI table containing both the swap image, */
/**         if any, and the SerDes state tables. */
/** @return On success, populates the sdi_size and sdi_rom values and returns 0. */
/** @return On error, decrements aapl->return_code and returns -1. */
static int create_sdi_in_memory(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    int swap_rom_size,      /**< [in] Size of swap, if any. */
    int *swap_rom,          /**< [in] Pointer to swap memory, or NULL. */
    Avsp_state_t *state,    /**< [in] State to output. */
    int *sdi_size,          /**< [out] Size of memory array */
    int **sdi_rom)          /**< [out] Pointer to memory array.  Call must free. */
{
    /* If we have swap, we have an existing imem-block, whose header */
    /*     grows by 2 words to point to the SDI table. */
    /* Else we need to allocate space for a new imem block of 11 bytes. */
    short memory[64];
    int table_header_len = get_sdi_header_mem(aapl, memory, state);
    int table_words = (last_active_index_write + 1) * state->serdes_count + table_header_len;
    int imem_len = swap_rom_size + table_words + (swap_rom ? 2 : 11);
    int *imem = (int *)aapl_malloc(aapl, sizeof(int) * imem_len, "imem");
    int i, icount = 0;

    *sdi_rom = imem;
    *sdi_size = 0;
    if( !imem ) return -1;

    /* Subtract 5 as imem-block length doesn't include the trailing crc: */
    imem[icount++] = (imem_len-5) >> 8 & 0xff;
    imem[icount++] = (imem_len-5) >> 0 & 0xff;

/*      printf("table_words = %d (table_header_len = %d)\n", table_words, table_header_len); */

    /* Now load swap, if present: */
    if( swap_rom )
    {
        /* Extend existing imem-block header: */
        int imem_header_len = 4 + 2 * swap_rom[2];
        int swap_len = (((swap_rom[0] & 0xff) << 8) | (swap_rom[1] & 0xff)) - imem_header_len;
        int table_offset;

        imem[icount++] = swap_rom[2];       /* swap image count */
        imem[icount++] = imem_header_len;   /* Offset to start of table ptr, 0 if none */
        for( i = 0; i < swap_rom[2]; i++ )
        {
            /* Increment each swap table offset value by 2: */
            int swap_offset = ((swap_rom[4+i*2+0] & 0xff) << 8) | (swap_rom[4+i*2+1] & 0xff);
            swap_offset += 2;   /* add 2 for table pointer */
            imem[icount++] = swap_offset >> 8 & 0xff;
            imem[icount++] = swap_offset >> 0 & 0xff;
        }
        table_offset = imem_header_len + 2 + swap_len;
        imem[icount++] = table_offset >> 8 & 0xff;
        imem[icount++] = table_offset >> 0 & 0xff;

        for( i = 0; i < swap_len; i++ )
            imem[icount++] = swap_rom[imem_header_len+i];
    }
    else
    {
        /* Create new imem-block header: */
        imem[icount++] = 0;     /* swap image count */
        imem[icount++] = 4;     /* Offset to start of table ptr, 0 if none */
        imem[icount++] = 6 >> 8 & 0xff; /* table_ptr */
        imem[icount++] = 6 >> 0 & 0xff; /* table_ptr */
    }

    /* Copy state table into imem block: */
    for( i = 0; i < table_header_len; i++ )
        imem[icount++] = memory[i];

    for( i = 0; i < (int)state->serdes_count; i++ )
    {
        int j;
        if( state->device != 7412 )
            v2_type_sel_7412 = 0;
        avsp_state_to_memory(aapl, &state->serdes[i].tx, &state->serdes[i].rx, memory);
        for( j = 0; j <= last_active_index_write; j++ )
            imem[icount++] = memory[j];
    }
    /* Update imem block CRC: */
    imem[icount++] = 0x04e;
    {
        uint crc = aapl_crc_rom(imem,icount);
        imem[icount++] = (crc >>  0) & 0xff;
        imem[icount++] = (crc >>  8) & 0xff;
        imem[icount++] = (crc >> 16) & 0xff;
        imem[icount++] = (crc >> 24) & 0xff;
    }
    *sdi_size = icount;
    return 0;
}

/* Note: This writes at most a 7 bit value, as that's all the table uses */
/*       at the present time. */
static void avago_write_rom_to_file(FILE *file, int *rom, int len)
{
    int i;
    for( i = 0; i < len; i++ )
        fprintf(file,"%03x\n", rom[i]);
}

/** @brief   Writes #state to a Serdes Device Information file. */
/** @details The SDI file is a ROM format file containing the SBus master memory tables. */
/**          If a serdes rom path is given, and it contains swap images, the */
/**          swap images are added to the SDI file. */
/** */
/**          If an SBus master rom path is given, the output will include the */
/**          SBus master image with the SDI information appended.  This format */
/**          is suitable for uploading. */
/** @return  0 on success, -1 on error. */
/** @see     avsp_state_read_from_sdi_file(). */
int avsp_state_write_to_sdi_file(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    const char *serdes_fw_path, /**< [in] Path of SerDes rom file. */
    const char *pathname,       /**< [in] Path of state file to write. */
    Avsp_state_t *state)        /**< [in] State structure to output. */
{
    int ret = 0;
    int icount, *imem = 0;
    int swap_rom_size = 0, *swap_rom = 0;
    FILE *file = fopen(pathname,"wb");

    if( file == 0 )
        return aapl_fail(aapl,__func__,0,"Cannot open %s: %s\n",pathname?pathname:"NULL", strerror(errno));

    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Write sdi file \"%s\".\n",pathname);

    if( serdes_fw_path )
    {
        /* Check if a swap image exists for this firmware revision and */
        /* build, if one exists upload the swap image to the device. */
        char *swap_name = avago_find_swap_file(aapl, serdes_fw_path);
        if( swap_name )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "Loading swap image: %s\n", swap_name);
            avago_load_rom_from_file(aapl, swap_name, &swap_rom_size, &swap_rom);
            aapl_free(aapl, swap_name, __func__);
        }
    }
    if( 0 == create_sdi_in_memory(aapl, swap_rom_size, swap_rom, state, &icount, &imem) )
    {
        avago_write_rom_to_file(file, imem, icount);
        aapl_free(aapl, imem, "imem");
    }
    else
        ret = -1;
    if( swap_rom )
        aapl_free(aapl, swap_rom, "swap_rom");
    return fclose(file) == 0 ? ret : -1;
}
#endif /* AAPL_ENABLE_FILE_IO */

#if AAPL_ENABLE_EEPROM

/** @details  The end pointers point at the byte after the last one to sum. */
/**           I.e. If start==end, nothing is summed. */
static void checksum(int *crc_ptr, unsigned char *start, unsigned char *end)
{
    while( start < end )
        aapl_crc_one_byte(crc_ptr, *start++);
}

static int verify_checksum(int crc, unsigned char *ptr)
{
    return  ptr[0] == 0x01
         && ptr[1] == ((crc >>  0) & 0xff)
         && ptr[2] == ((crc >>  8) & 0xff)
         && ptr[3] == ((crc >> 16) & 0xff)
         && ptr[4] == ((crc >> 24) & 0xff);
}

/* I2C EEPROM data format - from the customer AVSP-4412 data sheet: */
/* */
/* * At EEPROM address 0x3_0000 to 0x3_005f, there are 16 six-byte packets */
/*   of byte count/starting location data. The upper two address bits are */
/*   the lowest two device ID bits (device = 1010_0xx) */
/* */
/* * Locations 0x3_0060 to 0x3_ffff contain the standard memory area, */
/*   although it is possible to jump lower. */
/* */
/* * A single byte of 0x7x will change the I2C clock frequency.  This is */
/*   located at the beginning of the data set. */
/* */
/* * A single byte of 0x1 indicates that a 4-byte checksum follows. This */
/*   will be located at the end of the data set. */
/* */
/* * A byte with bit 7 set indicates that from 1 to 127 SBus write operations */
/*   follow. Each set of data includes a receiver address, data address, and N */
/*   sets of four bytes of data. */


static void sync_prom_ptr(unsigned char **prom_ptr)
{
    if( (*prom_ptr)[0] & 0x80 )
        *prom_ptr += ((*prom_ptr)[0] & 0x7f) * 4 + 3;
    *prom_ptr[0] = 0;
}

/* Append a single sbus command to the end of the prom */
/* */
/* Compacted sbus command format consists of a count, a register, an address */
/* and count words of data.  All words must have same address and register. */
/* Ie, this is a SIMD (single instruction, multiple data) format. */
/* */
/*   Byte number of commands */
/*      [7]   - always set */
/*      [6:0] - number of commands */
/*   Byte SBus register to write/ */
/*      [7:0] */
/*   Byte SBus address */
/*      [7:0] */
/*   Data        - 32 bit data is repeated "number of commands" times */
/*      [7:0]   - lsb byte is first */
/*      [15:8] */
/*      [23:16] */
/*      [31:24] - msb byte is last */
/* */
/* *prom_ptr points to first byte of compacted command. */
/* */
static void push_sbus(unsigned char **prom_ptr, uint sbus, int reg, int data)
{
    unsigned char *ptr = *prom_ptr;
    unsigned char *dptr;
/*  printf("ptr[0] = 0x%02x, sbus=0x%02x, reg=0x%02x\n", ptr[0], sbus, reg); */
    if( ptr[0] == 0 || ptr[1] != reg || ptr[2] != sbus || ptr[0] == 0xff )
    {
        /* Skip past current instruction, if any: */
        sync_prom_ptr(prom_ptr);
        ptr = *prom_ptr;

        /* Start a new compacted sbus command: */
        ptr[0] = 0x80;
        ptr[1] = reg;
        ptr[2] = sbus;
    }
    dptr = ptr + (*ptr & 0x7f) * 4 + 3; /* Get next data location */
    dptr[0] = (data >>  0) & 0xff;
    dptr[1] = (data >>  8) & 0xff;
    dptr[2] = (data >> 16) & 0xff;
    dptr[3] = (data >> 24) & 0xff;
    *ptr = 0x80 | ((*ptr & 0x7f) + 1);  /* Increment the data count */
    if( *ptr == 0xff )  /* If count is at max, finish up this one. */
    {
        dptr[4] = 0;
        *prom_ptr = dptr + 4;
    }
}

/* Merge a word (10 bits) into output burst instruction.  If last instruction */
/* is compatible and contains less than three 10 bit words, merge into it. */
/* Otherwise, add new instruction. */
/* If instruction group is full, start a new instruction group. */
static void push_word(unsigned char **prom_ptr, uint sbus, int reg, int word)
{
    unsigned char *ptr = *prom_ptr;
    if( ptr[0] != 0 && ptr[1] == reg && ptr[2] == sbus )
    {
        unsigned char *dptr = ptr + (*ptr & 0x7f) * 4 - 1; /* Get last data location */
        int bytes = (dptr[3] >> 6) & 3;
        if( bytes == 1 )
        {
/*          printf("Adding second value to existing word\n"); */
            dptr[1] |= (word & 0x003f) << 2;    /* Lower 6 */
            dptr[2] |= (word & 0x03c0) >> 6;    /* Upper 4 */
            dptr[3] += 1 << 6;  /* increment count */
            return;
        }
        if( bytes == 2 )
        {
/*          printf("Adding third value to existing word\n"); */
            dptr[2] |= (word & 0x000f) << 4;
            dptr[3] |= (word & 0x03f0) >> 4;
            dptr[3] += 1 << 6;  /* increment count */
            return;
        }
        /* Write directly so we can push two more words. */
        /* Otherwise, push_sbus() (on last entry) will start new command */
        /* before we've filled the last burst instruction. */
        if( bytes == 3 && *ptr <= 0xfe )
        {
            *ptr += 1;
            dptr += 4;
            dptr[0] = (word & 0x00ff) >> 0;
            dptr[1] = (word & 0x0300) >> 8;
            dptr[2] = 0x00;
            dptr[3] = 0x40;
            return;
        }
    }
/*  printf("Starting new word\n"); */
    /* else, start a new word with single value: */
    push_sbus(prom_ptr, sbus, reg, 0x40000000 | (word & 0x3ff));
}

/* Pack SerDes firmware into memory: */
static void push_rom(unsigned char **prom_ptr, uint sbus, uint reg, uint rom_size, const int *rom)
{
    uint i;
    for( i = 0; i < rom_size; i++ )
        push_word(prom_ptr, sbus, reg, rom[i]);
}


/* Add SerDes firmware to eeprom output: */
static void push_serdes(unsigned char **prom_ptr, int serdes_rom_size, int *serdes_rom, uint sbus)
{
    int end_addr = serdes_rom_size;

    /* Perform a global reset: */
    push_sbus(prom_ptr, sbus, 0x07, 0x00000011);   /* Set GLOBAL_REST & SPICO_CLK_GATE_DISABLE */
    push_sbus(prom_ptr, sbus, 0x07, 0x00000010);   /* Clear GLOBAL_RESET */
    push_sbus(prom_ptr, sbus, 0x08, 0x00000030);   /* Set DISABLE_HDW_INTERRUPT, DISABLE_CORE_INTERRUPT */
    push_sbus(prom_ptr, sbus, 0x00, 0xc0000000);   /* Set IMEM_CNTL_EN and IMEM_LOAD */

    /* Pack SerDes firmware into memory: */
    push_rom(prom_ptr, sbus, 0x0a, serdes_rom_size, serdes_rom);

    /* Zero pad output to align to 8 word boundary. */
    /* ECC memory checks 8 words at a time, and if all 8 words are not */
    /* set explicitly, errors will propagate during simulation. */
    for(      ; (end_addr % 8 ) != 0; end_addr++ )
        push_word(prom_ptr, sbus, 0x0a, 0);
    push_sbus(prom_ptr, sbus, 0x00, 0x00000000);    /* Clear IMEM_CNTL_EN */

    /* Enable ECC, turn on SPICO and enable interrupts: */
    push_sbus(prom_ptr, sbus, 0x0b, 0x000c0000);   /* Enable IMEM and DMEM ECC */
    push_sbus(prom_ptr, sbus, 0x0c, 0xc0000000);   /* Clear any prev ECC errors */
    push_sbus(prom_ptr, sbus, 0x07, 0x00000002);   /* Enable SPICO */
    push_sbus(prom_ptr, sbus, 0x08, 0x00000000);   /* Enable HDW and CORE ints */
}

static void push_sbm_start(unsigned char **prom_ptr)
{
    /* Prepare SBus Master SPICO for memory upload: */
    push_sbus(prom_ptr, 0xfd, 0x00, 0x00000003);   /* SRAM_BIST_SEL, SRAM_BIST_RST */
    push_sbus(prom_ptr, 0xfd, 0x01, 0x000000c0);   /* sbus_cntl_gate, reset spico */
    push_sbus(prom_ptr, 0xfd, 0x00, 0x00000001);   /* SRAM_BIST_SEL (clear SRAM_BIST_RST) */
    push_sbus(prom_ptr, 0xfd, 0x01, 0x00000040);   /* sbus_cntl_gate (clear reset bit) */
    push_sbus(prom_ptr, 0xfd, 0x07, 0x00000000);   /* Clear all interrupt bits */
    push_sbus(prom_ptr, 0xfd, 0x01, 0x00000240);   /* sbus_cntl_gate, imem_cntl_en */
    push_sbus(prom_ptr, 0xfd, 0x03, 0x00000000);   /* Clear imem write enable */
    push_sbus(prom_ptr, 0xfd, 0x03, 0x80000000);   /* Set imem write enable */
}

static void push_sbm_end(unsigned char **prom_ptr, int end_addr, BOOL auto_state)
{
    /* Zero pad output to align to 8 word boundary. */
    /* ECC memory checks 8 words at a time, and if all 8 words are not */
    /* set explicitly, errors will propagate during simulation. */
    while( end_addr % 8 != 0 )
    {
        push_word(prom_ptr, 0xfd, 0x14, 0);
        end_addr ++;
    }

    /* Start the processor: */
    push_sbus(prom_ptr, 0xfd, 0x01, 0x00000040);  /* Clear imem_cntl_en */
    /* Should be enabled by default, but no harm enabling here: */
    push_sbus(prom_ptr, 0xfd, 0x16, 0x000c0000);  /* Set imem_ecc_enable, dmem_ecc_enable */
    push_sbus(prom_ptr, 0xfd, 0x01, 0x00000140);  /* Enable processor */

    /* State using the imem state table: */
    if( auto_state )
    {
        /* Execute interrupt 0x26,0x4800 */
        push_sbus(prom_ptr, 0xfd, 0x02, 0x48000026);
        push_sbus(prom_ptr, 0xfd, 0x07, 0x00000001);
        push_sbus(prom_ptr, 0xfd, 0x02, 0x48000026); /* opal needs this interrupt to be fired twice due to some issue */
        push_sbus(prom_ptr, 0xfd, 0x07, 0x00000001);
    }
}

static int push_sbm_swap_image_table(Aapl_t *aapl, unsigned char **prom_ptr, int swap_rom_size, int *swap_rom, Avsp_state_t *state)
{
    int icount = 0;
    int *imem = 0;

    if( 0 == create_sdi_in_memory(aapl, swap_rom_size, swap_rom, state, &icount, &imem) )
    {
        /* Output instructions to write imem block after sbm image: */
        int i;
        for( i = 0; i < icount; i++ )
            push_word(prom_ptr, 0xfd, 0x14, imem[i]);

        aapl_free(aapl, imem, "imem");
    }
    sync_prom_ptr(prom_ptr);

    return icount;
}

/** @return 0 on success, -1 on failure. */
static int verify_args(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    int config_count,                   /**< [in] Number of config structs. */
    Avsp_state_abi_config_t *config)    /**< [in] Config struct array. */
{
    /*  Verify that all address masks are non-zero: */
    /*  Verify that each address is selected at most once. */
    int i, mask = 0;
    for( i = 0; i < config_count; i++ )
    {
        int dups = mask & config[i].address_mask;
        if( i > 0 && config[i].address_mask == 0 )
            return aapl_fail(aapl, __func__, __LINE__, "No address selected for image #%d\n",i);
        if( dups )
            return aapl_fail(aapl, __func__, __LINE__, "Address(es) used in multiple images: mask = 0x%x\n",dups);
        mask |= config[i].address_mask;
    }
    /*  Assign unspecified addresses to config of address 0, or first config. */
    config[0].address_mask |= (~mask & 0xffff);
    if( config[0].address_mask == 0 )
        return aapl_fail(aapl, __func__, __LINE__, "No address selected for image #0\n");
    if( config_count > 8 )
        return aapl_fail(aapl, __func__, __LINE__, "Too many images (%d) selected.  Max = 8.\n", config_count);
    return 0;
}

/* Set the count and offset fields in the table entries selected by address_mask. */
static void update_table(unsigned char *table, int address_mask, int count, int offset)
{
    int j;
    for( j = 0; j < 16; j++ )
    {
        if( (1 << j) & address_mask )
        {
/*          printf("Set table[%d]: count=0x%x, offset=0x%x\n",j,count,offset); */
            unsigned char *entry = table + j * 6;
            entry[0] = (count >>  0) & 0xff;
            entry[1] = (count >>  8) & 0xff;
            entry[2] = (count >> 16) & 0xff;
            entry[3] = (offset >>  0) & 0xff;
            entry[4] = (offset >>  8) & 0xff;
            entry[5] = (offset >> 16) & 0x03;
        }
    }
}

/** @return 0 on success, -1 on error. */
static int get_image(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    uint *image_length,                 /**< [out] EEPROM space required. */
    unsigned char **image_ptr,          /**< [out] Ptr to image.  Caller frees. */
    Avsp_state_abi_config_t *config)    /**< [in] Config struct array. */
{
    unsigned char *prom_ptr = 0;
    uint alloc_len = 0;
    int *d6_serdes_rom = 0, *m4_serdes_rom = 0, *p1_serdes_rom = 0, *sbm_rom = 0, *swap_rom = 0;
    int d6_serdes_rom_size = 0, m4_serdes_rom_size = 0, p1_serdes_rom_size = 0, sbm_rom_size = 0, swap_rom_size = 0;
    short memory[64];
    int table_header_len = get_sdi_header_mem(aapl, memory, config->state);
    int table_words = (last_active_index_write + 1) * config->state->serdes_count + table_header_len;
    int end_addr = 0;
    int error = 0;
    *image_ptr = 0;

    if( (!config->d6_serdes_fw_path && !config->m4_serdes_fw_path && !config->p1_serdes_fw_path) || !config->sbm_fw_path )
        return aapl_fail(aapl, __func__,__LINE__,"SerDes and SBus Master firmware images are required.\n");

    /* Load ROM files for D6 serdes: */
    if( config->d6_serdes_fw_path )
        error |= avago_load_rom_from_file(aapl, config->d6_serdes_fw_path, &d6_serdes_rom_size, &d6_serdes_rom);
    if( d6_serdes_rom )
    {
        /* Check for a swap image for this firmware revision and build. */
        /* If one exists, include the swap image in the output. */
        char *swap_name = avago_find_swap_file(aapl, config->d6_serdes_fw_path);
        if( swap_name )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG5, __func__, __LINE__, "Loading swap image: %s\n", swap_name);
            if( avago_load_rom_from_file(aapl, swap_name, &swap_rom_size, &swap_rom) != 0 )
            {
                aapl_free(aapl, d6_serdes_rom, __func__);
                d6_serdes_rom = 0;
            }
            aapl_free(aapl, swap_name, __func__);
        }
    }

    /* Load ROM files for M4 serdes: */
    if( config->m4_serdes_fw_path )
        error |= avago_load_rom_from_file(aapl, config->m4_serdes_fw_path, &m4_serdes_rom_size, &m4_serdes_rom);

    /* Load ROM files for p1 serdes: */
    if( config->p1_serdes_fw_path )
        error |= avago_load_rom_from_file(aapl, config->p1_serdes_fw_path, &p1_serdes_rom_size, &p1_serdes_rom);

    if( !error && (d6_serdes_rom || p1_serdes_rom || m4_serdes_rom) )
        avago_load_rom_from_file(aapl, config->sbm_fw_path, &sbm_rom_size, &sbm_rom);

    if( sbm_rom )
    {
        /* All ROM images are loaded successfully. */
        uint memory_words = d6_serdes_rom_size + m4_serdes_rom_size + p1_serdes_rom_size + sbm_rom_size + swap_rom_size + table_words;
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "d6_serdes_size=%d, m4_serdes_size=%d, p1_serdes_size=%d, sbm_size=%d, swap_size=%d, table_size=%d, total=%d\n",
                d6_serdes_rom_size, m4_serdes_rom_size, p1_serdes_rom_size, sbm_rom_size, swap_rom_size, table_words, memory_words);

        /* Allocate output array: */
        alloc_len = (memory_words / 381) * 512 + 1000;
        prom_ptr = (unsigned char *)aapl_malloc(aapl, alloc_len, __func__);
    }
    if( prom_ptr == 0 )
    {
        if( d6_serdes_rom ) aapl_free(aapl, d6_serdes_rom, __func__);
        if( m4_serdes_rom ) aapl_free(aapl, m4_serdes_rom, __func__);
        if( p1_serdes_rom ) aapl_free(aapl, p1_serdes_rom, __func__);
        if(       sbm_rom ) aapl_free(aapl,       sbm_rom, __func__);
        if(      swap_rom ) aapl_free(aapl,      swap_rom, __func__);
        return -1;  /* Failure message already logged */
    }

    *image_ptr = prom_ptr;

    *prom_ptr++ = 0x70 | (config->i2c_freq_control & 0x0f);
    *prom_ptr = 0;  /* Initialize for later pushes */

    /* Write SerDes firmware load instructions: */
    if( d6_serdes_rom )
    {
        uint serdes_addr = 0xff;
        push_serdes(&prom_ptr,d6_serdes_rom_size,d6_serdes_rom, serdes_addr);
        aapl_free(aapl, d6_serdes_rom, "d6_serdes_rom");
    }
    if( m4_serdes_rom )
    {
        uint serdes_addr = 0xee;
        push_serdes(&prom_ptr,m4_serdes_rom_size,m4_serdes_rom, serdes_addr);
        aapl_free(aapl, m4_serdes_rom, "m4_serdes_rom");
    }
    if( p1_serdes_rom )
    {
        uint serdes_addr = 0xed;
        push_serdes(&prom_ptr,p1_serdes_rom_size,p1_serdes_rom, serdes_addr);
        aapl_free(aapl, p1_serdes_rom, "p1_serdes_rom");
    }

    /* Write start of SBM section: */
    push_sbm_start(&prom_ptr);

    /* Load SBus Master firmware: */
    push_rom(&prom_ptr, 0xfd, 0x14, sbm_rom_size, sbm_rom);
    aapl_free(aapl, sbm_rom, "sbm_rom");

    /* Append imem-block containing swap and SDI: */
    end_addr = sbm_rom_size;
    end_addr += push_sbm_swap_image_table(aapl, &prom_ptr, swap_rom_size, swap_rom, config->state);
    if( swap_rom )
        aapl_free(aapl, swap_rom, "swap_rom");

    /* Write instructions to start SBM processor: */
    push_sbm_end(&prom_ptr, end_addr, config->auto_state);

    sync_prom_ptr(&prom_ptr);
    *prom_ptr++ = 0x01;
    prom_ptr += 4;  /* Reserve space for checksum */
    *image_length = prom_ptr - *image_ptr;
    if( alloc_len < *image_length )
    {
        aapl_free(aapl, *image_ptr, "image");
        *image_ptr = 0;
        return aapl_fail(aapl, __func__,__LINE__,"Allocated length too small: Allocated %d bytes, needed %d\n",alloc_len, *image_length);
    }
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Alloc length = %d, Actual image_length = %d\n", alloc_len, *image_length);
    return 0;
}

static unsigned char *find_end(unsigned char *ptr, int len)
{
    while( len > 0 )
    {
        if( ptr[--len] )
        {
            len++;
            break;
        }
    }
/*  len += 4; */
/*  len = (len + 7) & ~7;   // Round up to 8 boundary */
    return ptr + len;
}

static char *make_eeprom_name(Aapl_t *aapl, const char *abi_out, int num)
{
    char *namebuf = (char *)aapl_malloc(aapl, strlen(abi_out) + 10,__func__);
    if( namebuf )
    {
        char *extptr = strchr(strcpy(namebuf,abi_out),'.');
        if( !extptr )
            extptr = namebuf + strlen(namebuf);
        if( extptr[-2] == '5' && extptr[-3] == '_' )
            extptr -= 3;
        sprintf(extptr,"_%d.abi", 53 - num);
    }
    return namebuf;
}

/* Write eeprom images. */
static int write_abi_files(Aapl_t *aapl, unsigned char *prom, int prom_len, const char *abi_out)
{
    int i, ret = 0;
    int images = prom_len / (64*1024);
    for( i = 0; i < images; i++ )
    {
        char *abi_name = make_eeprom_name(aapl, abi_out, i);
        unsigned char *start_ptr = prom + prom_len - (i+1) * 64 * 1024;
        unsigned char *end_ptr = find_end(start_ptr, 64*1024);

        FILE *out = fopen(abi_name, "w");
        if( out )
        {
            unsigned char *ptr;
            for( ptr = start_ptr; ptr < end_ptr; ptr++ )
                fprintf(out, "%02x\n", *ptr);

            if( fclose(out) != 0 )
                ret = aapl_fail(aapl,__func__,__LINE__,"Cannot write '%s': %s\n",abi_name, strerror(errno));
        }
        else
            ret = aapl_fail(aapl,__func__,__LINE__,"Cannot open '%s': %s\n",abi_name, strerror(errno));

        aapl_free(aapl, abi_name, "eeprom_name");
    }
    return ret;
}

/* Copy the rom image to the prom, inserting commands to skip over the 96 byte */
/*   indirection table without modifying it. */
/* The "skip" actually writes the table to register 0xff (/dev/null), and then */
/*   resumes normal commands after the table is skipped. */
/* Checksum will be updated later. */
static uint copy_image(Aapl_t *aapl, unsigned char *prom, unsigned char *table, unsigned char *rom, uint length)
{
    unsigned char *dest = prom;
    unsigned char *end = rom + length;
    unsigned char *ptr = rom;

    while( ptr < end )
    {
        if( (*ptr & 0xF0) == 0x70 ) /* Clock control byte */
        {
            aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, 0, "0x%lx: Clock control byte\n", dest-(table-0x30000));
            *dest++ = *ptr++;
        }
        else if( *ptr == 1 )       /* Checksum follows */
        {
            aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, 0, "0x%lx: checksum\n", dest-(table-0x30000));
            *dest++ = *ptr++;
            if( ptr+4 != end )
                aapl_fail(aapl, __func__, __LINE__, "ERROR: Length doesn't match expected value\n");
            aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, 0, "incoming len = %u, outgoing = %ld\n", length, (dest+4)-prom);
            return (dest+4) - prom;
        }
        else if( *ptr & 0x80 )
        {
            int count = *ptr & 0x7f;
            int len = count * 4 + 3;
            int n = -1;
            /*printf("dest = %lx, count = %d, len = %d\n", dest-(table-0x30000), count, len); */
            if( dest + len > table - 9 ) /* Worst case: need space for checksum(5), Clock Control Byte(1) and dummy write to skip table(3) after this block write. */
            {
                /* Calculate number of data words that will fit before the header: */
                n = (table - dest - 6) / 4; /* 6 is for two SIMD instruction headers, 4 is size of data words */
                if( n > count ) n = count;
                /*printf("dest = %lx, n = %d, len = %d\n", dest-(table-0x30000), n, len); */
            }
            if( n > 0 ) /* Output partial data before header: */
            {
                aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, 0, "0x%lx: data[%d]\n", dest-(table-0x30000), n);
                *dest++ = 0x80 | n;
                *dest++ = ptr[1];
                *dest++ = ptr[2];
                memcpy(dest,ptr+3,n*4);
                dest += n*4;
            }
            if( n >= 0 ) /* Output commands to skip header: */
            {
                int skip = (table-dest + 96) / 4;
                aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, 0, "0x%lx: table[%d]\n", dest-(table-0x30000), skip);
                *dest++ = 0x80 | skip;
                *dest++ = 0xff; /* read-only register */
                *dest++ = ptr[2];
                memset(dest,0,table-dest);
                dest += skip * 4;
            }
            else /* Normal case where SIMD fits unchanged */
                n = 0;

            if( count-n > 0 ) /* Output balance of data */
            {
                aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, 0, "0x%lx: data[%d]\n", dest-(table-0x30000),count-n);
                *dest++ = 0x80 | (count - n);
                *dest++ = ptr[1];
                *dest++ = ptr[2];
                memcpy(dest, ptr+3 + n*4, (count-n) * 4);
                dest += (count-n) * 4;
            }
            ptr += count * 4 + 3;
        }
        else
        {
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "INVALID CHAR\n");
            break;
        }
    }
    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "SHOULD NEVER GET HERE\n");
    return -1;
}

typedef struct
{
    unsigned int  length;
    unsigned char *rom;
    Avsp_state_abi_config_t *config;
    int offset;
} Aapl_image_t;

/* Copy data into EEPROM image and update indirection table. */
/* If image is expanded to skip over table, update image_struct->length. */
/* Checksums will be calculated after the images are placed. */
static void place_image(Aapl_t *aapl, unsigned char *base_ptr, Aapl_image_t *image)
{
    int offset = image->offset;
    unsigned char *rom = image->rom;
    unsigned char *prom_ptr = base_ptr + offset;
    unsigned char *table_ptr = base_ptr + 3 * 64 * 1024;

    /* Copy data: */
    image->length = copy_image(aapl, prom_ptr, table_ptr, rom, image->length);

    /* Write length and offset into EEPROM redirection table: */
    update_table(table_ptr, image->config->address_mask, image->length, image->offset);
}

/** @brief   Combines the firmware files with the state and writes to an abi file. */
/** @details The ABI file is a ROM format file suitable for placing in an AVSP */
/**          eeprom(s) for auto-loading of firmware and SerDes state information. */
/** @details If the SerDes firmware has a swap image associated with it, */
/**          it is also included into the output. The swap file must have the */
/**          same path as the SerDes firmware file, except with the ".swap" */
/**          extension. */
/** @return  0 on success, -1 on error. */
int avsp_state_write_to_abi_files(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    int config_count,                   /**< [in] Number of config structs. */
    Avsp_state_abi_config_t *config,    /**< [in] Config struct array. */
    const char *abi_out)                /**< [out] Pathname of file to write. */
{
    int i, ret = 0;
    Aapl_image_t image[10];

    if( verify_args(aapl, config_count, config) != 0 )
        return -1;

    if( config_count > (int)(sizeof(image) / sizeof(image[0])) )
        return aapl_fail(aapl, __func__,__LINE__, "Too many structures passed to function.\n");

    /* Read all the images and the space each will need: */
    for( i = 0; i < config_count; i++ )
    {
        image[i].config = &config[i];
        image[i].offset = 0;
        ret |= get_image(aapl, &image[i].length, &image[i].rom, image[i].config);
    }

    /* Layout the images into the EEPROM memory: */
    if( ret == 0 )
    {
        int space_needed, roms_needed, next_offset;
        int prom_len;
        unsigned char *prom;

        space_needed = 96 + 16;  /* Table plus some overhead to skip over the table */
        for( i = 0; i < config_count; i++ )
            space_needed += image[i].length;

        roms_needed = (space_needed + (64*1024) - 1) / (64*1024);   /* Round up to 64k multiple */
        if( roms_needed > 4 )
            aapl_fail(aapl,__func__,__LINE__, "Images too big to fit in largest EEPROM.\n");

        next_offset = (4 - roms_needed) * (64*1024);
        if( next_offset == 0x30000 )
            next_offset += 96;

        /* next_offset += 13342;    // For testing, adjust this offset */

        /* Allocate output array: */
        prom_len = roms_needed * (64*1024);
        prom = (unsigned char *)aapl_malloc(aapl, prom_len, "abi_memory");
        aapl_log_printf(aapl,AVAGO_DEBUG1,__func__,__LINE__,"prom_len = %d\n",prom_len);
        if( prom )
        {
            unsigned char *base_ptr = prom + prom_len - 4*64*1024; /* Virtual base */
            memset(prom,0,prom_len);

            /* Copy images into rom memory: */
            for( i = 0; i < config_count; i++ )
            {
                image[i].offset = next_offset;
                place_image(aapl, base_ptr, &image[i]);
                next_offset += image[i].length;
                aapl_log_printf(aapl,AVAGO_DEBUG1,__func__,__LINE__,"Write image %d: offset=0x%x, length=%d\n",i,image[i].offset, image[i].length);
            }

            /* Update image checksums: */
            for( i = 0; i < 16; i++ )
            {
                unsigned char *table_ptr = base_ptr + 3 * 64 * 1024 + i * 6;
                int crc = 0;
                int length = table_ptr[0] | (table_ptr[1] << 8) | (table_ptr[2]&3) << 16;
                int offset = table_ptr[3] | (table_ptr[4] << 8) | (table_ptr[5]&3) << 16;
                unsigned char *prom_ptr = base_ptr + offset;
                checksum(&crc, table_ptr, table_ptr+6);
                checksum(&crc, prom_ptr, prom_ptr + length - 4);
                prom_ptr += length - 4;
                prom_ptr[0] = (crc >>  0) & 0xff;
                prom_ptr[1] = (crc >>  8) & 0xff;
                prom_ptr[2] = (crc >> 16) & 0xff;
                prom_ptr[3] = (crc >> 24) & 0xff;
            }

            ret = write_abi_files(aapl, prom, prom_len, abi_out);
            aapl_free(aapl, prom, "eeprom_memory");
        }
    }
    /* Free image memory: */
    for( i = 0; i < config_count; i++ )
    {
        if( image[i].rom )
        {
            aapl_free(aapl, image[i].rom, "image");
            image[i].rom = 0;
        }
    }

    return ret;
}


/** @brief   Load ABI files into memory. */
/** @details An ABI file consists of one or more ASCII encoded binary files, */
/**          where each byte is represented by two hex chars and a newline. */
/**          "_XX.abi" will replace any suffix on filename, where XX is */
/**          replaced with the i2c addresses (0x)53, 52, 51, and 50. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
static int avago_load_abi_from_files(Aapl_t *aapl, const char *filename, int *rom_size, unsigned char **rom)
{
    FILE *in_file[4];
    int i;
    for( i = 0; i < 4 ; i++ )
    {
        char *abi_name = make_eeprom_name(aapl, filename, i);
        in_file[i] = fopen(abi_name, "r");
        if( in_file[i] )
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__,__LINE__,"Load file \"%s\".\n",abi_name);
        else if( i == 0 )
            aapl_fail(aapl, __func__, __LINE__, "## ERROR opening file %s\n",abi_name);
        aapl_free(aapl, abi_name, "abi_name");
        if( !in_file[i] )
            break;
    }
    if( i == 0 )
        return -1;  /* Error logged above */

    *rom_size = i * (64 * 1024);
    *rom = (unsigned char *) aapl_malloc(aapl, sizeof(char) * *rom_size, filename);
    memset(*rom, 0, *rom_size);
    aapl_log_printf(aapl,AVAGO_DEBUG1,__func__,__LINE__,"files=%d, rom_size=0x%x\n",i,*rom_size);
    for( i = 0; i < 4 && in_file[i]; i++ )
    {
        int addr = *rom_size - (i + 1) * (64 * 1024);
        for(        ; addr < *rom_size; addr++ )
        {
            char mem_buffer[8];
            if( !fgets(mem_buffer, sizeof(mem_buffer), in_file[i]) )     /* read line from file */
                break;
            (*rom)[addr] = (unsigned char)aapl_strtoul(mem_buffer, 0, 16);  /* convert to hex */
        }
        fclose(in_file[i]);
    }
    return 0;
}


/** @brief   Write contents of ABI file to EEPROM at given i2c address. */
/** @return  0 on success, -1 on failure. */
#if AAPL_ALLOW_I2C || AAPL_ALLOW_SYSTEM_I2C
int avsp_abi_write_to_eeprom(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    const char *abi_name)   /**< [in] ABI name. */
{
    int abi_size = 0;
    unsigned char *abi = 0;

    if( 0 == avago_load_abi_from_files(aapl, abi_name, &abi_size, &abi) )
    {
        int i = abi_size / (64 * 1024);
        unsigned char *table = abi + abi_size - (64 * 1024);
        unsigned char *base = table - 3 * (64 * 1024);
        int rom_count = abi_size / (64 * 1024);


#define MAX_WRITE 128
        for( i = rom_count-1; i >= 0; i-- )
        {
            int i2c_addr = 0x53 - i;
            unsigned char *my_base = base + (3-i) * 1024 * 64;
            int offset, eeprom_len = 64 * 1024;

            /* Don't need to write trailing zero bytes: */
            while( eeprom_len > 0 && my_base[eeprom_len-1] == '\0' )
                eeprom_len --;
            eeprom_len += 4;    /* Add 4 to insure all of CRC is written (it may have zero bytes). */
            if( eeprom_len > 64 * 1024 )
                eeprom_len = 64 * 1024;

            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__,__LINE__,"Writing %d bytes to EEPROM at 0x%x.\n",eeprom_len, i2c_addr);
            for( offset = 0; offset < eeprom_len; offset += MAX_WRITE )
            {
                unsigned char data[MAX_WRITE + 2];
                int len = MAX_WRITE;            /* Most we can write */
                if( len > eeprom_len - offset )
                    len = eeprom_len - offset;  /* What's left to write */
                data[0] = (offset >> 8) & 0xff; /* EEPROM relative address to write to hi */
                data[1] = (offset >> 0) & 0xff; /* EEPROM relative address to write to lo */
                memcpy(&data[2], &my_base[offset], len);
                if( avago_i2c_write(aapl, i2c_addr, len + 2, data) != len + 2 )
                {
                    aapl_free(aapl, abi, __func__);
                    return aapl_fail(aapl, __func__, __LINE__, "Error writing data to EEPROM\n");
                }
                ms_sleep(50);   /* Space out the writes */
            }
        }
        aapl_free(aapl, abi, __func__);
        return 0;
    }
    return -1;
}
#endif /* I2C allows */

/** @brief   Writes the image for prtad from the ABI file to device. */
/** @details Writes only one image of a multiple image ABI file. */
/** @return  0 on success, -1 on failure. */
int avsp_abi_write_to_device(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint prtad,             /**< [in] Port address of the device: [0..15]. */
    const char *abi_name)   /**< [in] ABI name. */
{
    int ret = 0;
    unsigned char *abi = 0;
    int abi_size = 0;

    if( 0 != avago_load_abi_from_files(aapl, abi_name, &abi_size, &abi) )
        return -1;

    if( abi_size < 100 )
        ret = aapl_fail(aapl,__func__,__LINE__,"ERROR: %s: File too small...\n",abi_name);
    else
    {
        unsigned char *table = abi + abi_size - (64 * 1024);
        unsigned char *base = table - 3 * 64 * 1024;
        int i;
        for( i = 0; i < 16; i++ )
        {
            int crc = 0;
            int count  = table[i*6+0] | table[i*6+1] << 8 | (table[i*6+2]&3) << 16;
            int offset = table[i*6+3] | table[i*6+4] << 8 | (table[i*6+5]&3) << 16;
            int result;
            checksum(&crc, &table[i*6],   &table[i*6+6]);
            checksum(&crc, &base[offset], &base[offset+count-4]);
            result = verify_checksum(crc,&base[offset+count-5]);
            if( !result )
                ret |= aapl_fail(aapl, __func__,__LINE__,"crc failure on image for address %d.\n",i);
        }
        i = prtad;
        if( ret == 0 )
        {
            int count  = table[i*6+0] | table[i*6+1] << 8 | (table[i*6+2]&3) << 16;
            int offset = table[i*6+3] | table[i*6+4] << 8 | (table[i*6+5]&3) << 16;
            int j;

            aapl_log_printf(aapl,AVAGO_DEBUG1,__func__,__LINE__,
                "Writing ABI image from %s, start address 0x%x, to device %u:\n", abi_name, offset, prtad);

            for( j = 0; j < count; j++ )
            {
                unsigned char byte = base[offset+j];
                if( byte & 0x80 )
                {
                    int length = byte & 0x7f;
                    int reg = base[offset+j+1];
                    int addr = base[offset+j+2];
                    uint sbus_addr = avago_make_addr3(prtad, 0, addr);
                    int k;
                    j += 2;
                    for( k = 0; k < length; k++ )
                    {
                        uint data = (base[offset+j+4] << 24)
                                  | (base[offset+j+3] << 16)
                                  | (base[offset+j+2] <<  8)
                                  | (base[offset+j+1]      );
/*                      aapl_log_printf(aapl,AVAGO_DEBUG4,__func__,__LINE__,"avago_sbus_wr(aapl, 0x%04x, 0x%02x, 0x%08x);\n",sbus_addr,reg,data); */
                        avago_sbus_wr(aapl, sbus_addr, reg, data);
                        j += 4;
                    }
                }
                else if( (byte & 0x70) == 0x70 )
                {
                }
                else if( byte == 1 )
                {
                    j += 4;
                }
            }
        }
    }
    aapl_free(aapl, abi, __func__);
    return ret;
}

#if AAPL_ENABLE_MAIN
/** @brief   Parse and dump an ABI (EEPROM) file contents. */
/** @details If aapl->debug == 0, then validate file contents. */
/** @details If aapl->debug == 1, print file structure. */
/** @return  0 on success, -1 on error. */
/** @see     avsp_state_write_to_abi_files(). */
void avsp_state_dump_abi(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    const char *abi_name)       /**< [in] Name of file to parse and dump. */
{
    unsigned char *abi = 0;
    int abi_size = 0;
    aapl_log_printf(aapl,AVAGO_INFO,0,0,"Dump of ABI file(s) %s:\n", abi_name);

    if( 0 != avago_load_abi_from_files(aapl, abi_name, &abi_size, &abi) )
        return;

    if( abi_size < 100 )
        aapl_fail(aapl,__func__,__LINE__,"ERROR: %s: File too small...\n",abi_name);
    else
    {
        BOOL crc_ok = TRUE;
        unsigned char *table = abi + abi_size - (64 * 1024);
        unsigned char *base = table - 3 * 64 * 1024;
        int addr_mask = 0;
        int i;
        for( i = 0; i < 16; i++ )
        {
            int crc = 0;
            int count  = table[i*6+0] | table[i*6+1] << 8 | (table[i*6+2]&3) << 16;
            int offset = table[i*6+3] | table[i*6+4] << 8 | (table[i*6+5]&3) << 16;
            int result;
            checksum(&crc, &table[i*6],   &table[i*6+6]);
            checksum(&crc, &base[offset], &base[offset+count-4]);
            result = verify_checksum(crc,&base[offset+count-5]);
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"Section %2d: start address = 0x%x, size = %d bytes, crc is %s.\n",i,offset,count,result?"OK":"bad");
            crc_ok &= result;
        }
        for( i = 0; i < 16 && crc_ok; i++ )
        {
            int count  = table[i*6+0] | table[i*6+1] << 8 | (table[i*6+2]&3) << 16;
            int offset = table[i*6+3] | table[i*6+4] << 8 | (table[i*6+5]&3) << 16;
            int j;
            if( addr_mask & (1<<i) )
                continue;   /* Already dumped this one... */

            aapl_log_printf(aapl,AVAGO_INFO,0,0,"Dumping image at start address 0x%x (for i2c addresses:", offset);
            /* Find all references to this image: */
            for( j = i; j < 16; j++ )
            {
                int offset_next = table[j*6+3] | table[j*6+4] << 8 | (table[j*6+5]&3) << 16;
                if( offset_next == offset )
                {
                    addr_mask |= 1 << j;
                    aapl_log_printf(aapl,AVAGO_INFO,0,0," %d", j);
                }
            }
            aapl_log_printf(aapl,AVAGO_INFO,0,0,"):\n");

            for( j = 0; j < count; j++ )
            {
                unsigned char byte = base[offset+j];
                if( byte & 0x80 )
                {
                    int length = byte & 0x7f;
                    int reg = base[offset+j+1];
                    int addr = base[offset+j+2];
                    int k;
                    j += 2;
                    for( k = 0; k < length; k++ )
                    {
                        aapl_log_printf(aapl,AVAGO_INFO,0,0,"sbus %02x %02x 01 0x%02x%02x%02x%02x\n", addr, reg,
                        base[offset+j+4],
                        base[offset+j+3],
                        base[offset+j+2],
                        base[offset+j+1]);
                        j += 4;
                    }
                }
                else if( (byte & 0x70) == 0x70 )
                {
                    aapl_log_printf(aapl,AVAGO_INFO,0,0,"Clock control value = %d\n",byte & 0x0f);
                }
                else if( byte == 1 )
                {
                    aapl_log_printf(aapl,AVAGO_INFO,0,0,"crc = 0x%02x%02x%02x%02x\n",
                    base[offset+j+4],
                    base[offset+j+3],
                    base[offset+j+2],
                    base[offset+j+1]);
                    j += 4;
                }
            }
        }
    }
    aapl_free(aapl, abi, __func__);
}
#endif /* AAPL_ENABLE_MAIN */

#endif  /* AAPL_ENABLE_EEPROM */

static void serdes_read_from_memory(Aapl_t *aapl, void *user_ptr, Avago_serdes_tx_state_t *tx, Avago_serdes_rx_state_t *rx)
{
    int i;
    uint addr = rx->sbus_addr;
    uint mem_addr = rx->mem_addr;
    int memory[64];
    (void)user_ptr;

    memory[0] = avago_sbm_read_mem(aapl, addr, mem_addr);
    for( i = 1; i <= last_active_index_read; i++ )
        memory[i] = avago_sbm_read_next_mem(aapl, addr);

    avsp_memory_to_state(aapl, memory, tx, rx);
}

/** @brief  Reads state from what's in the SBus master memory. */
/** @return 0 on success, -1 on error. */
int avsp_state_read_from_memory(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    Avsp_state_t *state)    /**< State structure to update. */
{
    BOOL enabled = FALSE;
    aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "Read state from AVSP-%d memory on prtad %d.\n",state->device,state->prtad);

    /* Stop supervisor if running: */
    avsp_supervisor_status(aapl, state->prtad, &enabled);
    if( enabled )
        avsp_supervisor_enable(aapl, state->prtad, FALSE);

    avsp_read_sbm_control_vars(aapl, state);

#if AAPL_ENABLE_AVSP_7412
    /* setting default mode to enter process serdes state because at this stage fro 7412 mode will be invalid */
    /* valid mode is read in serdes_read_from_memory */
    if( state->device == 7412 )
        state->mode = AVSP_REPEATER_DUPLEX; 
#endif

    process_serdes_state(aapl, serdes_read_from_memory, NULL, state);
#if AAPL_ENABLE_AVSP_7412
    if( state->device == 7412 )
    {
        state->mode = (v2_type_sel_7412 & 0x7f) == 0x02c ? AVSP_RS_FEC_528 :
                      (v2_type_sel_7412 & 0x7f) == 0x02b ? AVSP_RS_FEC_544 :
                                                    AVSP_ADHOC;
    }
#endif

    if( enabled )   /* Restart supervisor if was running: */
        avsp_supervisor_enable(aapl, state->prtad, TRUE);

    return 0;
}

static void avsp_state_print_rx_header(
    Aapl_t *aapl)                   /**< Pointer to Aapl_t structure. */
{
    aapl_log_printf(aapl,AVAGO_INFO,0,0,"  Lnk RxAddr  en wth div lbk  term pcsClk inv cmpDta cmpMode sig  errs\n");
}
static void avsp_state_print_rx(
    Aapl_t *aapl,                   /**< Pointer to Aapl_t structure. */
    int index,                      /**< Which SerDes */
    int link_num,                   /**< Which link is this? */
    Avago_serdes_rx_state_t *st)    /**< Structure to print */
{
    char host_mod = index == link_num ? 'H' : 'M';
    aapl_log_printf(aapl,AVAGO_INFO,0,0,"  %c%2d %6s %3s  %2d %3d %3s %5s  %-4s  %3s %6.6s %7.7s %s,%x %s%3u\n",
        link_num == 0 ? host_mod : ' ',
        link_num,
        aapl_addr_to_str(st->sbus_addr),
        aapl_onoff_to_str(st->enable),
        st->width, st->divider,
        aapl_onoff_to_str(st->input_loopback),
        aapl_term_to_str(st->term),
        aapl_pcs_fifo_clk_to_str(st->pcs_fifo_clk_divider),
        aapl_onoff_to_str(st->polarity_invert),
        aapl_cmp_data_to_str(st->cmp_data),
        aapl_cmp_mode_to_str(st->cmp_mode),
        st->signal_ok ? "OK" : "--",
        st->signal_ok_threshold,
        st->errors > 999 ? ">" : " ",
        st->errors > 999 ? 999U : st->errors);
}

static void avsp_state_print_tx_header(
    Aapl_t *aapl)                   /**< Pointer to Aapl_t structure. */
{
    aapl_log_printf(aapl,AVAGO_INFO,0,0,"  Lnk TxAddr  en wth div dataSel  pllClk  inv out pre att post slew  firmware\n");
}
static void avsp_state_print_tx(
    Aapl_t *aapl,                   /**< Pointer to Aapl_t structure. */
    int index,                      /**< Which SerDes */
    int link_num,                   /**< Which link is this? */
    Avago_serdes_tx_state_t *tx)    /**< Structure to print */
{
    char host_mod = index == link_num ? 'H' : 'M';
    const char *pll_clk_str = aapl_pll_clk_to_str(tx->pll_clk_source);
    /* Shorten a few of the strings: */
    if( tx->pll_clk_source == AVAGO_SERDES_TX_PLL_PCIE_CORE_CLK )
        pll_clk_str = " CORE";
    else if( tx->pll_clk_source == AVAGO_SERDES_TX_PLL_PCIE_CORE_CLK_DIV2 )
        pll_clk_str = "CORE/2";

    aapl_log_printf(aapl,AVAGO_INFO,0,0,"  %c%2d %6s %3s  %2d %3d %-8.8s %-7.7s %3s %3s %3d %3d %4d %4d %04X_%04X\n",
        link_num == 0 ? host_mod : ' ',
        link_num,
        aapl_addr_to_str(tx->sbus_addr),
        aapl_onoff_to_str(tx->enable),
        tx->width, tx->divider,
        aapl_data_sel_to_str(tx->data_sel),
        pll_clk_str,
        aapl_onoff_to_str(tx->polarity_invert),
        aapl_onoff_to_str(tx->output_enable),
        tx->eq.pre, tx->eq.atten, tx->eq.post, tx->eq.slew,
        tx->fw_revision, tx->fw_build_id);
}
static void avsp_state_print_dfe_header(
    Aapl_t *aapl)                   /**< Pointer to Aapl_t structure. */
{
    aapl_log_printf(aapl,AVAGO_INFO,0,0,"  DFE RxAddr |DC LF HF BP VSR|run i p a|DC HF LF BW GAIN min max\n");
}
static void avsp_state_print_dfe(
    Aapl_t *aapl,                   /**< Pointer to Aapl_t structure. */
    int index,                      /**< Which SerDes */
    int link_num,                   /**< Which link is this? */
    Avago_serdes_rx_state_t *st)    /**< Structure to print */
{
    char host_mod = index == link_num ? 'H' : 'M';
    Avago_serdes_dfe_state_t *dfe = &st->dfe;
    aapl_log_printf(aapl,AVAGO_INFO,0,0,"  %c%2d %6s |%2d %2d %2d %2d %2d |    %d %d %d|%02x %02x %02x %02x%4x %3x %3x\n",
        link_num == 0 ? host_mod : ' ',
        link_num,
        aapl_addr_to_str(st->sbus_addr),
        dfe->fixed_dc, dfe->fixed_lf, dfe->fixed_hf,
        st->bypass_ctle, st->run_vsr_tune,
        st->run_ical, st->run_pcal, st->run_adaptive,
        dfe->dc, dfe->hf, dfe->lf, dfe->bw,
        dfe->dfeGAIN, dfe->dfeGAIN_min, dfe->dfeGAIN_max);
}

/** @brief Prints selected fields of the #state structure to the console. */
void avsp_state_print(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    Avsp_state_t *state,    /**< State structure to print. */
    BOOL print_dfe)       /**< Set to include DFE in output. */
{
    aapl_log_printf(aapl,AVAGO_INFO,0,0,"Avsp_state_t for AVSP-%d at port %d =\n", state->device, state->prtad);
    aapl_log_printf(aapl,AVAGO_INFO,0,0,"{\n");
    aapl_log_printf(aapl,AVAGO_INFO,0,0,"    firmware = sbus_master.0x%04X_%04X.rom\n", state->sbm_fw_revision, state->sbm_fw_build_id);
    if( state->device == 8812 )
    {
#if AAPL_ENABLE_AVSP_8812
         aapl_log_printf(aapl,AVAGO_INFO,0,0,"    half0 mode     = %s\n", aapl_avsp_mode_to_str(state->u.a8812.half_mode[0]));
         aapl_log_printf(aapl,AVAGO_INFO,0,0,"    half1 mode     = %s\n", aapl_avsp_mode_to_str(state->u.a8812.half_mode[1]));
#endif
    }
    else
         aapl_log_printf(aapl,AVAGO_INFO,0,0,"    mode     = %s\n", aapl_avsp_mode_to_str(state->mode));
    {
        uint i;
        int mod = state->serdes_count / 2;
        avsp_state_print_rx_header(aapl);
        for( i = 0; i < state->serdes_count; i++ )
        {
            avsp_state_print_rx(aapl, i, i % mod, &state->serdes[i].rx);
            if( state->serdes[i].rx.errors > 0 )
            {
                /* Clear error count after printing to show if errors */
                /* are still present. */
                avago_serdes_error_reset(aapl, state->serdes[i].rx.sbus_addr);
            }
        }
        avsp_state_print_tx_header(aapl);
        for( i = 0; i < state->serdes_count; i++ )
            avsp_state_print_tx(aapl, i, i % mod, &state->serdes[i].tx);

        if( print_dfe )
        {
            avsp_state_print_dfe_header(aapl);
            for( i = 0; i < state->serdes_count; i++ )
                avsp_state_print_dfe(aapl, i, i % mod, &state->serdes[i].rx);
        }
    }
    aapl_log_printf(aapl,AVAGO_INFO,0,0,"};\n");
}

/** @brief   Constructs a state structure for the given AVSP device. */
/** @details Allocates memory for a new state structure and calls */
/**          avsp_state_init() to initialize it. */
/**          All state is initialized to reasonable defaults, */
/**          which can then be customized before applying. */
/** @return  Allocated structure.  Call avsp_state_destruct() to free it. */
/** @return  If #avsp_name and #mode are not valid together, returns NULL. */
/** @return  See avsp_state_init() for list of valid #avsp_name and #mode values. */
/** @see     avsp_state_init(). */
Avsp_state_t *avsp_state_construct(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    uint prtad,             /**< Port address of the target device. */
    const char *avsp_name,  /**< Name of AVSP we are configuring for. */
    Avsp_mode_t mode)       /**< Device mode to configure. */
{
    size_t bytes = sizeof(Avsp_state_t);
    Avsp_state_t *state = (Avsp_state_t *) aapl_malloc(aapl, bytes, __func__);

    if( state == 0 )
        return NULL;

    if( avsp_name == 0 )
        avsp_name = aapl_get_chip_name(aapl, avago_make_addr3(prtad,0,0));

    aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "Construct state for device %d/%s, mode %s\n",
        prtad,avsp_name, aapl_avsp_mode_to_str(mode));

    if( avsp_state_init(aapl, prtad, avsp_name, mode, state) )
        return state;

    avsp_state_destruct(aapl, state);
    return NULL;
}

/** @brief   Releases the resources associated with #state. */
/** @see     avsp_state_construct(), avsp_state_get(). */
void avsp_state_destruct(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    Avsp_state_t *state)    /**< Structure with memory to free. */
{
    aapl_free(aapl, state, __func__);
}

/** @brief   Creates a state structure describing the target device state. */
/** @details Constructs and initializes a new state structure by reading */
/**          the current state of the existing device. */
/** @return  Avsp_state_t structure describing the existing device state, or NULL if any read error. */
/** @see     avsp_state_set(). */
Avsp_state_t *avsp_state_get(
    Aapl_t *aapl,       /**< Pointer to Aapl_t structure. */
    uint prtad)         /**< Port address of the existing device. */
{
    Avsp_state_t *state = avsp_state_construct(aapl, prtad, 0, AVSP_REPEATER_DUPLEX);
    if( state )
    {
        aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "Read device %d/AVSP-%d state\n", prtad,state->device);
        if( 0 == avsp_state_read_from_device(aapl,state) )
            return state;
        avsp_state_destruct(aapl, state);
    }
    return 0;
}

/** @brief   Sets the device into the specified state using the SBus master. */
/** @details Writes the SBus master memory with the desired state, then */
/**          the SBus master states the device accordingly. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avsp_state_get(). */
int avsp_state_set(
    Aapl_t *aapl,           /**< Pointer to Aapl_t structure. */
    Avsp_state_t *state)    /**< Structure describing desired device state. */
{
    aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "Set device %d/AVSP-%d into mode %s\n",
                    state->prtad,state->device,aapl_avsp_mode_to_str(state->mode));
    if( 0 == avsp_state_write_to_memory(aapl,state) )
    {
        avsp_state_device_from_memory(aapl, state->prtad);
        return 0;
    }
    return -1;
}

#endif /* AAPL_ENABLE_AVSP_STATE */

/** @} */


