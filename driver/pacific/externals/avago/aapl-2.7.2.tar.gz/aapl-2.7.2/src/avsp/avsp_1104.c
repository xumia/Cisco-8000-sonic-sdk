/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* AAPL (ASIC and ASSP Programming Layer) support for AVSP */

/** Doxygen File Header */
/** @file */
/** @brief Functions specific to the AVSP-1104 and AVSP-9104. */

#include "aapl.h"

#if AAPL_ENABLE_AVSP_1104 || AAPL_ENABLE_AVSP_9104

static uint get_control_logic_sbus(Aapl_t *aapl, uint prtad)
{
    uint addr = avago_make_addr3(prtad,0,0);
    const char *chip_name = aapl_get_chip_name(aapl, addr);
    if( 0 == strcmp(chip_name,"AVSP-1104") ) return 0x000d;
    if( 0 == strcmp(chip_name,"AVSP-9104") ) return 0x002c;
    aapl_fail(aapl, __func__,__LINE__,"Control Logic SBus address unknown.\n");
    return 0;
}

/** @brief   Directly sets the core logic into #mode. */
/** @details If #AVSP_PMA #mode is selected, all slices are reset. */
/**          If #AVSP_RPT #mode is selected, then the slices are reset only */
/**          if the corresponding bit is set in #slice_mask. */
/** @return  TRUE on success, FALSE on error. */
BOOL avsp_control_logic_reset_host_to_mod_direct(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint avsp_prtad,        /**< [in] Port address of the targeted device. */
    Avsp_mode_t mode,       /**< [in] The desired operating mode: */
                            /**<     AVSP_PMA: Set 10:4 mode */
                            /**<     AVSP_RPT: Set 10:10 mode */
    uint slice_mask)        /**< [in] Bit-wise selection mask for slices to reset. */
                            /**<      Only applies to AVSP_RPT mode. */
{
    /* Host_to_mod values: */
    uint pma_regs[]  = {41, 43, 45, 47, 49, 51, 53, 55, 57, 59}; /* List of the mod  pma  gearfifo registers */
    uint sync_regs[] = {20, 22, 24, 26, 28, 30, 32, 34, 36, 38}; /* List of the host sync gearfifo registers */
    uint addr = avago_make_addr3(avsp_prtad, 0, get_control_logic_sbus(aapl, avsp_prtad));

    /* Use the mode selection to setup the bit to write to registers. */
    uint config_pma  = 0x0000;  /* AVSP_RPT value */
    uint config_sync = 0x042c;  /* AVSP_RPT value */
    int index;

    if( mode == AVSP_PMA )
    {
        config_pma  = 0x0001;   /* AVSP_PMA value */
        config_sync = 0x003d;   /* AVSP_PMA value */
        slice_mask  = 0x3ff;    /* Select all slices always */
    }

    for( index=0; index < 10; index++ )
    {
        if( slice_mask & (1 << index) )
        {
            avago_sbus_wr(aapl, addr, pma_regs[index], config_pma);
            avago_sbus_wr(aapl, addr, sync_regs[index], config_sync);
        }
    }
    return TRUE;
}

/** @brief   Directly sets the core logic into #mode. */
/** @details If #AVSP_PMA #mode is selected, all slices are reset. */
/**          If #AVSP_RPT #mode is selected, then the slices are reset only */
/**          if the corresponding bit is set in #slice_mask. */
/** @return  TRUE on success, FALSE on error. */
BOOL avsp_control_logic_reset_mod_to_host_direct(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint avsp_prtad,        /**< [in] Port address of the targeted device. */
    Avsp_mode_t mode,       /**< [in] The desired operating mode: */
                            /**<     AVSP_PMA: Set 10:4 mode */
                            /**<     AVSP_RPT: Set 10:10 mode */
    uint slice_mask)        /**< [in] Bit-wise selection mask for slices to reset. */
                            /**<      Only applies to AVSP_RPT mode. */
{
    /* Mod_to_host values: */
    uint pma_regs[]  = {21, 23, 25, 27, 29, 31, 33, 35, 37, 39}; /* List of the host pma  gearfifo registers */
    uint sync_regs[] = {40, 42, 44, 46, 48, 50, 52, 54, 56, 58}; /* List of the mod  sync gearfifo registers */
    uint addr = avago_make_addr3(avsp_prtad, 0, get_control_logic_sbus(aapl, avsp_prtad));

    /* Use the mode selection to setup the bit to write to registers. */
    uint config_pma  = 0x0000;  /* AVSP_RPT value */
    uint config_sync = 0x042c;  /* AVSP_RPT value */
    int index;

    /* In the AVSP_PMA case, over-write the slice_mask to cover all slices */
    if( mode == AVSP_PMA )
    {
        config_pma  = 0x0001;   /* AVSP_PMA value */
        config_sync = 0x003d;   /* AVSP_PMA value */
        slice_mask  = 0x3ff;    /* Select all slices always */
    }

    for( index=0; index < 10; index++ )
    {
        if( slice_mask & (1 << index) )
        {
            avago_sbus_wr(aapl, addr, pma_regs[index], config_pma);
            avago_sbus_wr(aapl, addr, sync_regs[index], config_sync);
        }
    }
    return TRUE;
}

/** @brief   Directly sets the core logic into #mode. */
/** @return  TRUE on success, FALSE on error. */
BOOL avsp_control_logic_reset_direct(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint avsp_prtad,        /**< [in] Port address of the targeted device. */
    Avsp_mode_t mode)       /**< [in] The desired operating mode: */
                            /**<   - AVSP_PMA: Set 10:4 mode */
                            /**<   - AVSP_RPT: Set 10:10 mode */
{
    return avsp_control_logic_reset_host_to_mod_direct(aapl, avsp_prtad, mode, 0x3ff) &&
           avsp_control_logic_reset_mod_to_host_direct(aapl, avsp_prtad, mode, 0x3ff);
}

/** @brief   Resets the host_to_mod core logic paths in the device. */
/** @details Uses the SBus Master to reset the core logic for the current */
/**          operating mode. */
/**          The operating mode is set when the SBus Master states the device. */
/**          Individual paths can be selected for reset by setting the */
/**          corresponding bit in #slice_mask. */
/** @return  TRUE on success, FALSE on error. */
BOOL avsp_control_logic_reset_host_to_mod(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint prtad,             /**< [in] Port address of the targeted device. */
    uint slice_mask)        /**< [in] Bit-wise selection mask for slices to reset. */
{
    uint addr = avago_make_addr3(prtad,0,0);
    const char *chip_name = aapl_get_chip_name(aapl, addr);

    if( 0 == strcmp(chip_name, "AVSP-1104") )
    {
        uint sbm_addr = avago_make_sbus_master_addr(addr);

        if( (slice_mask & 0x3ff) == 0x3ff )
            avago_spico_int(aapl, sbm_addr, 0x26, 0x0e2a);  /* Reset all host slices */
        else
        {
            uint serdes_addrs[] = { AVSP_1104_HOST_LIST };
            int index;
            for( index=0; index < 10; index++ )
            {
                if( slice_mask & (1 << index) )
                {
                    int int_data = 0x0e00 | serdes_addrs[index];
                    avago_spico_int(aapl, sbm_addr, 0x26, int_data);
                }
            }
        }
    }
    else if( 0 == strcmp(chip_name, "AVSP-9104") )
    {
        uint sbm_addr = avago_make_sbus_master_addr(addr);

        if( (slice_mask & 0x3ff) == 0x3ff )
            avago_spico_int(aapl, sbm_addr, 0x26, 0x0e2a);  /* Reset all host slices */
        else
        {
            uint serdes_addrs[] = { AVSP_9104_HOST_LIST };
            int index;
            for( index=0; index < 10; index++ )
            {
                if( slice_mask & (1 << index) )
                {
                    int int_data = 0x0e00 | serdes_addrs[index];
                    avago_spico_int(aapl, sbm_addr, 0x26, int_data);
                }
            }
        }
    }
    return TRUE;
}

/** @brief   Resets the mod_to_host core logic paths in the device. */
/** @details Uses the SBus Master to reset the core logic for the current */
/**          operating mode. */
/**          The operating mode is set when the SBus Master states the device. */
/**          Individual paths can be selected for reset by setting the */
/**          corresponding bit in #slice_mask. */
/** @return  TRUE on success, FALSE on error. */
BOOL avsp_control_logic_reset_mod_to_host(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint prtad,             /**< [in] Port address of the targeted device. */
    uint slice_mask)        /**< [in] Bit-wise selection mask for slices to reset. */
{
    uint addr = avago_make_addr3(prtad,0,0);
    const char *chip_name = aapl_get_chip_name(aapl, addr);

    if( 0 == strcmp(chip_name, "AVSP-1104") )
    {
        uint sbm_addr = avago_make_sbus_master_addr(addr);

        if( (slice_mask & 0x3ff) == 0x3ff )
            avago_spico_int(aapl, sbm_addr, 0x26, 0x0e2d);  /* Reset all mod slices */
        else
        {
            uint serdes_addrs[] = { AVSP_1104_MOD_LIST };
            int index;
            for( index=0; index < 10; index++ )
            {
                if( slice_mask & (1 << index) )
                {
                    int int_data = 0x0e00 | serdes_addrs[index];
                    avago_spico_int(aapl, sbm_addr, 0x26, int_data);
                }
            }
        }
    }
    else if( 0 == strcmp(chip_name, "AVSP-9104") )
    {
        uint sbm_addr = avago_make_sbus_master_addr(addr);

        if( (slice_mask & 0x3ff) == 0x3ff )
            avago_spico_int(aapl, sbm_addr, 0x26, 0x0e2d);  /* Reset all mod slices */
        else
        {
            uint serdes_addrs[] = { AVSP_9104_MOD_LIST };
            int index;
            for( index=0; index < 10; index++ )
            {
                if( slice_mask & (1 << index) )
                {
                    int int_data = 0x0e00 | serdes_addrs[index];
                    avago_spico_int(aapl, sbm_addr, 0x26, int_data);
                }
            }
        }
    }
    return TRUE;
}

/** @brief   Resets the core logic paths in the device. */
/** @details Uses the SBus Master to reset the core logic for the current */
/**          operating mode. */
/**          The operating mode is set when the SBus Master states the device. */
/** @return  TRUE on success, FALSE on error. */
BOOL avsp_control_logic_reset(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint prtad)             /**< [in] Port address of the targeted device. */
{
    uint addr = avago_make_addr3(prtad,0,0);
    const char *chip_name = aapl_get_chip_name(aapl, addr);
    if( 0 == strcmp(chip_name, "AVSP-1104") || 0 == strcmp(chip_name,"AVSP-9104") )
    {
        uint sbm_addr = avago_make_sbus_master_addr(addr);
        avago_spico_int(aapl, sbm_addr, 0x26, 0x0e2f);  /* Reset all slices */
    }
    return TRUE;
}




/*============================================================================= */
/* A V S P   1 1 0 4   L O O P B A C K */
/* */
/** @brief This is a DEBUGGING function. */
/** @details  NOTE: This function is provided for purposes of testing, but */
/**           not for production code. */
/**           This signature is likely to change in a future release. */
/** @details           Sets up various host/module side loopback modes. */
/**                    The NEAR loopback modes re-configure the SerDes on */
/**                    the selected #lb_side. All other loopback modes assume */
/**                    that the chip has already been stated by the user into */
/**                    a desired configuration.  All modes can be recovered */
/**                    by issuing the AVSP_LB_OFF case. Keep in mind that there is */
/**                    no checking done on the current state. It is up to the */
/**                    user to ensure that only one LB mode is selected at any */
/**                    time as these can interfere with each other. */
/** @param div_ratio   This sets the divider ratio in the SerDes. Bitrate is */
/**                    equal to div_ratio * refclk, this is only used in the */
/**                    NEAR #lb_mode and is ignored in other cases. */
/** @param lb_mode     Selects one of the loopback options */
/**                    - AVSP_LB_NEAR: The near side data is sent along in parallel */
/**                               loopback, and the clock used on the TX is recovered */
/**                               from the FAR side being in ILB. */
/**                    - AVSP_LB_FAR:  Sets the SerDes on the opposing lb_side into */
/**                               internal loopback (ILB) mode sending TX data */
/**                               back into the RX. This setup makes no changes */
/**                               to the current SerDes states so the device must */
/**                               be properly configured beforehand. */
/**                    - AVSP_LB_OFF:  This option turns off all loopback on all SerDes. */
/**                               This will recover from all modes besides AVSP_LB_NEAR. */
/**                               All the loopback modes issue a rest to the control */
/**                               logic when transitioning between modes so while */
/**                               the device will still pass all traffic, the user */
/**                               should expect to see that lane markers are not */
/**                               maintained in the same channels as they were */
/**                               prior to the issue of loopback change. */
/**                    - AVSP_LB_STATE:This option makes no change to the current state */
/**                               and simply reads the current value of the */
/**                               loopback bits in each bank of SerDes. Each indicator */
/**                               bit is only set if all SerDes in a given bank are */
/**                               in the same mode, this is a pretty gross check of */
/**                               the current state. */
/**                               return[0] - indicates all Host slices are in ILB */
/**                               return[1] - indicates all Host slices are in PLB */
/**                               return[2] - indicates all MOD25G# slices are in ILB */
/**                               return[3] - indicates all MOD25G# slices are in PLB */
/**                               return[4] - indicates all MOD slices are in ILB */
/**                               return[5] - indicates all MOD slices are in PLB */
/** @param lb_side     Selects one side of the chip for configuration */
/**                    - AVSP_LB_HOST: Directs the #lb_mode selection to the host side */
/**                    - AVSP_LB_MOD:  Directs the #lb_mode selection to the mod side. */
/**                               The MOD selection also uses the pma_v_rpt choice */
/**                               to determine if 4 or 10 devices are targetted. */
/** @return   The return value is 0 for most states, and in the AVSP_LB_STATE mode */
/**           selection the return value indicates the current state of */
/**           loopback bits in the chip. */

uint avsp_1104_loopback(
    Aapl_t *aapl,               /**< Pointer to Aapl_t structure. */
    uint div_ratio,             /**< */
    uint avsp_prtad,            /**< The port address of the targeted device */
    Avsp_mode_t pma_v_rpt,      /**< AVSP_PMA or AVSP_RPT */
    Avsp_lb_mode_t lb_mode,     /**< */
    Avsp_lb_side_t lb_side)     /**< */
{
    uint *addr_ptr;
    int return_val = 0x0; /* default return value */
    uint *host_sbus_list;
    uint *mod_pma_sbus_list;
    uint *mod_rpt_sbus_list;

    uint host_sbus_list_1104[]    = {AVSP_1104_HOST_LIST, ~0U}; /* Create the 1104 host list with a flag at the end */
    uint mod_pma_sbus_list_1104[] = {AVSP_1104_MOD4_LIST, ~0U}; /* Create the 1104 AVSP_PMA mode mod list with a flag at the end */
    uint mod_rpt_sbus_list_1104[] = {AVSP_1104_MOD_LIST, ~0U};  /* Create the 1104 AVSP_RPT mode mod list with a flag at the end */
    uint host_sbus_list_9104[]    = {AVSP_9104_HOST_LIST, ~0U}; /* Create the 9104 host list with a flag at the end */
    uint mod_pma_sbus_list_9104[] = {AVSP_9104_MOD4_LIST, ~0U}; /* Create the 9104 AVSP_PMA mode mod list with a flag at the end */
    uint mod_rpt_sbus_list_9104[] = {AVSP_9104_MOD_LIST, ~0U};  /* Create the 9104 AVSP_RPT mode mod list with a flag at the end */

    uint addr = avago_make_addr3(avsp_prtad,0,0);
    const char *chip_name = aapl_get_chip_name(aapl, addr);
    (void)div_ratio;
    if( 0 == strcmp(chip_name,"AVSP-1104") )
    {
        host_sbus_list    = host_sbus_list_1104;
        mod_pma_sbus_list = mod_pma_sbus_list_1104;
        mod_rpt_sbus_list = mod_rpt_sbus_list_1104;
    }
    else if( 0 == strcmp(chip_name,"AVSP-9104") )
    {
        host_sbus_list    = host_sbus_list_9104;
        mod_pma_sbus_list = mod_pma_sbus_list_9104;
        mod_rpt_sbus_list = mod_rpt_sbus_list_9104;
    }
    else
    {
        aapl_fail(aapl, __func__,__LINE__, "Function supports 1104 and 9104 chips, only.\n");
        return return_val;
    }

    /* Far Loopback Modes next */
    /* Host Far loopback, AVSP_PMA */
    if ((lb_side == AVSP_LB_HOST) && (lb_mode == AVSP_LB_FAR) && (pma_v_rpt == AVSP_PMA))
    {
        addr_ptr = &mod_pma_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            avago_serdes_set_rx_input_loopback(aapl, addr, TRUE);
        }
    }
    /* Host Far loopback, AVSP_RPT */
    else if ((lb_side == AVSP_LB_HOST) && (lb_mode == AVSP_LB_FAR) && (pma_v_rpt == AVSP_RPT))
    {
        addr_ptr = &mod_rpt_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            avago_serdes_set_rx_input_loopback(aapl, addr, TRUE);
        }
    }
    /* Mod Far loopback */
    else if ((lb_side == AVSP_LB_MOD) && (lb_mode == AVSP_LB_FAR))
    {
        addr_ptr = &host_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            avago_serdes_set_rx_input_loopback(aapl, addr, TRUE);
        }
    }


    /* Near Loopback with clock */
    /* Host Near loopback with Far loopback clock, AVSP_PMA */
    else if ((lb_side == AVSP_LB_HOST) && (lb_mode == AVSP_LB_NEAR) && (pma_v_rpt == AVSP_PMA))
    {
        addr_ptr = &mod_pma_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            avago_serdes_set_rx_input_loopback(aapl, addr, TRUE);
        }
        addr_ptr = &host_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            avago_serdes_set_tx_data_sel(   aapl, addr, AVAGO_SERDES_TX_DATA_SEL_LOOPBACK);
            avago_serdes_set_tx_pll_clk_src(aapl, addr, AVAGO_SERDES_TX_PLL_REFCLK);
        }
    }
    /* Host Near loopback with Far loopback clock, AVSP_RPT */
    else if ((lb_side == AVSP_LB_HOST) && (lb_mode == AVSP_LB_NEAR) && (pma_v_rpt == AVSP_RPT))
    {
        addr_ptr = &mod_rpt_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            avago_serdes_set_rx_input_loopback(aapl, addr, TRUE);
        }
        addr_ptr = &host_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            avago_serdes_set_tx_data_sel(   aapl, addr, AVAGO_SERDES_TX_DATA_SEL_LOOPBACK);
            avago_serdes_set_tx_pll_clk_src(aapl, addr, AVAGO_SERDES_TX_PLL_REFCLK);
        }
    }
    /* Mod Near loopback with Far loopback clock, AVSP_PMA */
    else if ((lb_side == AVSP_LB_MOD) && (lb_mode == AVSP_LB_NEAR) && (pma_v_rpt == AVSP_PMA))
    {
        addr_ptr = &host_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            avago_serdes_set_rx_input_loopback(aapl, addr, TRUE);
        }
        addr_ptr = &mod_pma_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            avago_serdes_set_tx_data_sel(   aapl, addr, AVAGO_SERDES_TX_DATA_SEL_LOOPBACK);
            avago_serdes_set_tx_pll_clk_src(aapl, addr, AVAGO_SERDES_TX_PLL_REFCLK);
        }
    }
    /* Mod Near loopback with Far loopback clock, AVSP_RPT */
    else if ((lb_side == AVSP_LB_MOD) && (lb_mode == AVSP_LB_NEAR) && (pma_v_rpt == AVSP_RPT))
    {
        addr_ptr = &host_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            avago_serdes_set_rx_input_loopback(aapl, addr, TRUE);
        }
        addr_ptr = &mod_rpt_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            avago_serdes_set_tx_data_sel(   aapl, addr, AVAGO_SERDES_TX_DATA_SEL_LOOPBACK);
            avago_serdes_set_tx_pll_clk_src(aapl, addr, AVAGO_SERDES_TX_PLL_REFCLK);
        }
    }

    /* Turn loopback off (no checking is done for the current state, just open */
    /* up the PLB and ILB selections on the selected lb_side) */
    /* Loopback OFF, AVSP_PMA */
    else if ((lb_mode == AVSP_LB_OFF) && (pma_v_rpt == AVSP_PMA))
    {
        addr_ptr = &host_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            avago_serdes_set_rx_input_loopback(aapl, addr, FALSE);
            avago_serdes_set_tx_data_sel(      aapl, addr, AVAGO_SERDES_TX_DATA_SEL_CORE);
        }
        addr_ptr = &mod_pma_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            avago_serdes_set_rx_input_loopback(aapl, addr, FALSE);
            avago_serdes_set_tx_data_sel(      aapl, addr, AVAGO_SERDES_TX_DATA_SEL_CORE);
        }
    }
    /* Loopback OFF, AVSP_RPT */
    else if ((lb_mode == AVSP_LB_OFF) && (pma_v_rpt == AVSP_RPT))
    {
        addr_ptr = &host_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            avago_serdes_set_rx_input_loopback(aapl, addr, FALSE);
            avago_serdes_set_tx_data_sel(      aapl, addr, AVAGO_SERDES_TX_DATA_SEL_CORE);
        }
        addr_ptr = &mod_rpt_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            avago_serdes_set_rx_input_loopback(aapl, addr, FALSE);
            avago_serdes_set_tx_data_sel(      aapl, addr, AVAGO_SERDES_TX_DATA_SEL_CORE);
        }
    }


    /* Check the current state. This is a pretty gross check. It loops */
    /* through all the slices in a given bank and does a logical and of */
    /* the return code bits for PLB or ILB. The result will only have */
    /* the bits still set for a case where all of a given type are set */
    /* to the same value. */
    /* Loopback state return */
    else if (lb_mode == AVSP_LB_STATE)
    {
        return_val = 0x3f; /* Set all the possible bits (AND things together later to clear them). */
        addr_ptr = &host_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            /* For each host slice, check for PLB or ILB */
            if( AVAGO_SERDES_TX_DATA_SEL_LOOPBACK == avago_serdes_get_tx_data_sel(aapl, addr) )
                return_val &= 0x3c | 2;
            else if( avago_serdes_get_rx_input_loopback(aapl, addr) )
                return_val &= 0x3c | 1;
        }
        addr_ptr = &mod_pma_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            /* For each mod4 slice, check for PLB or ILB */
            if( AVAGO_SERDES_TX_DATA_SEL_LOOPBACK == avago_serdes_get_tx_data_sel(aapl, addr) )
                return_val &= 0x33 | (2 << 2);
            else if( avago_serdes_get_rx_input_loopback(aapl, addr) )
                return_val &= 0x33 | (1 << 2);
        }
        addr_ptr = &mod_rpt_sbus_list[0];
        AVSP_ADDR_LOOP(addr_ptr)
        {
            addr = avago_make_addr3(avsp_prtad, 0, *addr_ptr);
            /* For each mod slice, check for PLB or ILB */
            if( AVAGO_SERDES_TX_DATA_SEL_LOOPBACK == avago_serdes_get_tx_data_sel(aapl, addr) )
                return_val &= 0x0f | (2 << 4);
            else if( avago_serdes_get_rx_input_loopback(aapl, addr) )
                return_val &= 0x0f | (1 << 4);
        }
    }


    /* Any unsupported selection */
    else
    {
        aapl_fail(aapl, __func__,__LINE__, "An invalid loopback method was selected\n");
        return return_val;
    }

    avsp_control_logic_reset_direct(aapl, avsp_prtad, pma_v_rpt); /* Perform a control logic reset for all cases */
    return return_val;
}


/*============================================================================= */
/* A V S P   1 1 0 4   S L I P */
/* */
/** @brief   Function to achieve alignment in DEMO modes. */
/** @brief    This is a DEBUGGING function. */
/** @details  NOTE: This function is provided for purposes of testing, but */
/**           not for production code. */
/**           This signature is likely to change in a future release. */
/** */
/** This function sets a host slice to output parallel PRBS data into */
/** the core and then performs bit-slips on the associated module slice */
/** until the same PRBS pattern is detected back at the parallel input to */
/** the slice. After this is accomplished, there is some cleanup activity */
/** to put the slice back into a known good state. The end result is that */
/** data coming into the host_sbus_addr RX will be aligned so that it */
/** returns to the host_sbus_rx TX */
/** */
/** @return  Returns TRUE on success, FALSE on failure. */

uint avsp_1104_slip(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint avsp_prtad,        /**< [in] MDIO address of the device */
    uint host_sbus_addr,    /**< [in] SBus slice address for host slice sending data */
    uint mod_sbus_addr)     /**< [in] SBus slice address for mod slice looping data back */
{
    uint loop_count, lock_flag;
    uint host_addr = avago_make_addr3(avsp_prtad, 0, host_sbus_addr);
    uint mod_addr  = avago_make_addr3(avsp_prtad, 0, mod_sbus_addr);

    /*avago_serdes_set_tx_data_sel(aapl, host_addr, AVAGO_SERDES_TX_DATA_SEL_PRBS9); */
    avago_spico_int(aapl, host_addr, 0x0002, 0x0121);    /* Set TX PRBS generator to PRBS9 */
    /*avago_serdes_set_rx_cmp_data(aapl, host_addr, AVAGO_SERDES_RX_CMP_DATA_PRBS9); */
    avago_spico_int(aapl, host_addr, 0x0002, 0x0221);    /* Set RX PRBS checker to PRBS9 */
    /*avago_serdes_set_rx_cmp_mode(aapl, host_addr, (Avago_serdes_rx_cmp_mode_t)0x340); */
    avago_spico_int(aapl, host_addr, 0x0003, 0x0343);    /* Set compare control */

    avago_spico_int(aapl, host_addr, 0x0018, 0x8024);    /* Set RX_DATA DMA bits */
    avago_spico_int(aapl, host_addr, 0x0019, 0x10c2);    /* REG35_7_6 is operative here... */
    avago_spico_int(aapl, host_addr, 0x0018, 0x8018);    /* Set COMPARE_CLK_SEL bits */
    avago_spico_int(aapl, host_addr, 0x0019, 0xf001);    /* */
    avago_spico_int(aapl, host_addr, 0x0018, 0x8029);    /* Set TX_PRBS_CTL bits */
    avago_spico_int(aapl, host_addr, 0x0019, 0x8031);    /* */
    avago_spico_int(aapl, host_addr, 0x0018, 0x8021);    /* Set TX_DATA bits */
    avago_spico_int(aapl, host_addr, 0x0019, 0x0c00);    /* */

    /* Loop until lock is achieved or we've tried all slip combinations to no avail */
    lock_flag = 0;
    for( loop_count = 0; !lock_flag && loop_count < AVSP_1104_SLIP_LIM; loop_count++ )
    {
        uint low_byte, high_byte;
        avago_spico_int(aapl, mod_addr,  0x000c, 0x0001);       /* Bit slip on the mod slice */
        avago_spico_int(aapl, host_addr, 0x0018, 0x800d);       /* Reset the host's error counter */
        avago_spico_int(aapl, host_addr, 0x0019, 0x0011);       /*   with a series of big_reg writes */
        avago_spico_int(aapl, host_addr, 0x0018, 0x800d);       /* */
        avago_spico_int(aapl, host_addr, 0x0019, 0x0018);       /* */
        avago_spico_int(aapl, host_addr, 0x0018, 0x0002);       /* */
        avago_spico_int(aapl, host_addr, 0x0019, 0x0000);       /* Error counter low byte */
        avago_spico_int(aapl, host_addr, 0x0019, 0x0000);       /* Error counter high byte */
        avago_spico_int(aapl, host_addr, 0x0018, 0x0003);       /* Read the error counter result */
        low_byte = avago_spico_int(aapl, host_addr, 0x001a, 0x0003);    /*   low byte */
        high_byte = avago_spico_int(aapl, host_addr, 0x001a, 0x0003);    /*   high byte */
        lock_flag = ((low_byte == 0) && (high_byte == 0));        /* If error count is zero then we have lock */
    }

    /* Clean up the slices and put them back in a good state. */
    /*avago_serdes_set_rx_input_loopback(aapl, host_addr, FALSE); // Set ELB */
    avago_spico_int(aapl, host_addr, 0x0008, 0x0100);    /* Set ELB */
    /*avago_serdes_set_rx_cmp_mode(aapl, host_addr, AVAGO_SERDES_RX_CMP_MODE_MAIN_PATGEN); */
    avago_spico_int(aapl, host_addr, 0x0003, 0x0203);    /* Set error compare back to M^P */
    /*avago_serdes_set_rx_cmp_data(aapl, host_addr, AVAGO_SERDES_RX_CMP_DATA_PRBS7); */
    avago_spico_int(aapl, host_addr, 0x0002, 0x0230);    /* Set RX data to PRBS7 for now */

    avago_spico_int(aapl, host_addr, 0x0018, 0x8024);    /* Set RX_DATA DMA bits */
    avago_spico_int(aapl, host_addr, 0x0019, 0x1440);    /* */
    avago_spico_int(aapl, host_addr, 0x0018, 0x4020);    /* Set AVAGO_ESB DMA bits */
    avago_spico_int(aapl, host_addr, 0x0019, 0x008c);    /* */
    avago_spico_int(aapl, host_addr, 0x0018, 0x8018);    /* Set COMPARE_CLK_SEL bits */
    avago_spico_int(aapl, host_addr, 0x0019, 0xf048);    /* */
    avago_spico_int(aapl, host_addr, 0x0018, 0x8029);    /* Set TX_PRBS_CTL bits */
    avago_spico_int(aapl, host_addr, 0x0019, 0x8021);    /* */
    avago_spico_int(aapl, host_addr, 0x0018, 0x8021);    /* Set TX_DATA bits */
    avago_spico_int(aapl, host_addr, 0x0019, 0x0c00);    /* */

    if (lock_flag == 0)
    {
        aapl_fail(aapl, __func__,__LINE__, "Failed to achieve a locked case for the path from 0x%04x to 0x%04x\n", host_sbus_addr, mod_sbus_addr);
        return 0;
    }
    else
    {
        return 1;
    }
}

/** @brief  Retrieves the mode into which the core logic is configured. */
/** @return Returns the core logic configuration mode. */
Avsp_mode_t avsp_1104_get_mode(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint avsp_prtad)        /**< [in] Port address of the targeted device. */
{
    /* Make 1104 control logic address: */
    uint ctl_addr = avago_make_addr3(avsp_prtad, 0, get_control_logic_sbus(aapl, avsp_prtad));

    uint setting = avago_sbus_rd(aapl, ctl_addr, 0x14);
    uint mode    = avago_sbus_rd(aapl, ctl_addr, 0x96) & 0x0f;
    if( mode == 0 && setting == 0x0019 ) /* MLG data & sync_gf_rx_out & pcs_fifo_clk_for_mlg */
    {
        /*printf("1104 or 9104 in GearBox mode\n"); */
        return AVSP_GEARBOX_10_4;
    }
    else if( mode == 0 && setting == 0x408 ) /* repeater_tx_clk & sync_gf_rx_out */
    {
        /*printf("1104 or 9104 in 10:10 mode\n"); */
        return AVSP_REPEATER_DUPLEX;
    }
    else if( mode == 0 && setting == 0x0119 )
    {
        /*printf("9104 in GearBox mode\n"); */
        return AVSP_GEARBOX_10_4;
    }
#if AAPL_ENABLE_AVSP_9104
    else if( mode == 1 && setting == 0x0a )  /* sync_gf_rx_out */
    {
        /*printf("9104 in 10:4 RS FEC mode\n"); */
        return AVSP_GEARBOX_10_4_RS_FEC;
    }
    else if( mode >= 2 && mode <= 5 )
    {
        /*printf("9104 in 10:4 MLG mode\n"); */
        return AVSP_GEARBOX_10_4_MLG;
    }
#endif
    else
    {
        /*printf("1104 or 9104 in ad-hoc mode (setting = 0x04%x)\n", setting); */
        return AVSP_ADHOC;
    }
}

#endif /* AAPL_ENABLE_AVSP_1104 || AAPL_ENABLE_AVSP_9104 */

