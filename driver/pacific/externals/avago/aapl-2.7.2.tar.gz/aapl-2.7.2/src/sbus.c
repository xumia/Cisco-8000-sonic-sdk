/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* AAPL (ASIC and ASSP Programming Layer) SBus-related functions.  "SBus" is a */
/* frequently used command to a server (in contact with an ASIC, usually on a */
/* characterization board) to do I/O with an SBus master or individual slices */
/* (such as, but not necessarily, AVAGO_SERDES). */

/** Doxygen File Header */
/** @file */
/** @brief SBus functions. */

#define AAPL_CORE_FILE
#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#define AAPL_LOG_PRINT8 if(aapl->debug >= AVAGO_DEBUG8) aapl_log_printf
#define AAPL_LOG_PRINT9 if(aapl->debug >= AVAGO_DEBUG9) aapl_log_printf

#if AAPL_ALLOW_OFFLINE_SBUS

/** @cond INTERNAL */

uint avago_offline_sbus_fn(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,         /**< [in] SBus slice address. */
    unsigned char reg_addr, /**< [in] SBus register to read/write */
    unsigned char command,  /**< [in] 0=reset, 1=write, 2=read */
    uint *sbus_data)        /**< [in] Data to write */
{
    uint data = 0;
    uint index;
    Avago_addr_t addr_struct;
    avago_addr_to_struct(sbus_addr,&addr_struct);

    if( !aapl->offline_sbus_reg )
    {
        uint chip, reg_addr;
        int size = AAPL_MAX_CHIPS*AAPL_MAX_RINGS*256*256*sizeof(int);
        aapl->offline_sbus_reg = (int *)AAPL_MALLOC(size);
        if( aapl->offline_sbus_reg )
        {
            memset(aapl->offline_sbus_reg,0,size);
        }
        for (chip = 0; chip < AAPL_MAX_CHIPS; chip++)
        {
            uint ring;
            for (ring = 0; ring < AAPL_MAX_RINGS; ring++)
            {
                /* Set to the highest SBus address, other than 0xfd and 0xfe. */
                uint max_ip_address = 5;
                uint sbus = AVAGO_SBUS_CONTROLLER_ADDRESS;

                reg_addr = 0x2;
                index = ((chip * AAPL_MAX_RINGS + ring) * 256 + sbus) * 256 + reg_addr;
                if (chip == 0) aapl->offline_sbus_reg[index] = max_ip_address + 1;
                else           aapl->offline_sbus_reg[index] = 0x2 + 1;

                for (sbus = 1; sbus <= max_ip_address; sbus ++)
                {
                    reg_addr = 0xff;
                    index = ((chip * AAPL_MAX_RINGS + ring) * 256 + sbus) * 256 + reg_addr;
                    aapl->offline_sbus_reg[index] = AVAGO_SERDES;
                }

                sbus = AVAGO_SBUS_CONTROLLER_ADDRESS;
                reg_addr = 0xff;
                index = ((chip * AAPL_MAX_RINGS + ring) * 256 + sbus) * 256 + reg_addr;
                aapl->offline_sbus_reg[index] = AVAGO_SBUS_CONTROLLER;

                /* Set up SBus controller rev, which is used to determine process type: */
                sbus = AVAGO_SBUS_CONTROLLER_ADDRESS;
                reg_addr = 0xfe;
                index = ((chip * AAPL_MAX_RINGS + ring) * 256 + sbus) * 256 + reg_addr;
                aapl->offline_sbus_reg[index] = 0xbe; /* 28nm */

                sbus = AVAGO_SBUS_MASTER_ADDRESS; /* SBus master SPICO (0xfd) */
                reg_addr = 0xff;
                index = ((chip * AAPL_MAX_RINGS + ring) * 256 + sbus) * 256 + reg_addr;
                aapl->offline_sbus_reg[index] = AVAGO_SPICO;
            }
        }
    }

    /*emulate int aapl->offline_sbus_reg[AAPL_MAX_CHIPS][AAPL_MAX_RINGS][256][256]; */
    index = ((addr_struct.chip * AAPL_MAX_RINGS + addr_struct.ring) * 256 + addr_struct.sbus) * 256 + reg_addr;

    aapl_log_printf(aapl, AVAGO_DEBUG9, 0,0,"OFFLINE: index=%x, %s, %x, %x, %x\n", index, aapl_addr_to_str(sbus_addr), reg_addr, command, *sbus_data);

    /*if( reg_addr == 0x3 && command == 0x01 ) aapl->offline_sbus_reg[index+1] = sbus_data >> 16; */

    if      (command == 0x01) data = aapl->offline_sbus_reg[index] = *sbus_data;
    else if (command == 0x02) data = aapl->offline_sbus_reg[index];

    /* Example of hardcoding a value: */
    /* if( addr_struct.sbus == AVAGO_SBUS_CONTROLLER_ADDRESS && reg_addr == 0xfe && command == 0x02 ) data = 0xbe; // 28nm */

    *sbus_data = data;
    return TRUE;
}

/** @brief Opens communcation for the offline sbus communication method. */
int avago_offline_open_fn(
    Aapl_t *aapl) /**< [in] Pointer to Aapl_t structure. */
{
    aapl->socket = 1;
    return 0;
}
/** @brief Closes communcation for the offline sbus communication method. */
int avago_offline_close_fn(
    Aapl_t *aapl) /**< [in] Pointer to Aapl_t structure. */
{
    aapl->socket = -1;
    return 0;
}

/** @endcond */

#endif /* AAPL_ALLOW_OFFLINE_SBUS */


/*============================================================================= */
/* S B U S */
/* */
/** @brief   Execute an sbus command. */
/** @details Lowest level SBus function.  Allows the user to fully specify */
/**          all fields in the sbus command.  Generally, one should use */
/**          sbus_rd, sbus_wr and sbus_rmw instead of sbus. */
/** @return  For reads, returns read data. */
/**          For writes and reset, returns 0. */
uint avago_sbus(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,         /**< [in] SBus slice address. */
    unsigned char reg_addr, /**< [in] SBus register to read/write */
    unsigned char command,  /**< [in] 0=reset, 1=write, 2=read */
    uint sbus_data,         /**< [in] Data to write */
    int recv_data_back)     /**< [in] Allows AACS protocol optimization. */
{
    Avago_addr_t addr_struct;

    if (aapl_reconnect(aapl, __func__) < 0) return -1;

    sbus_addr &= 0xffff; /* make sure no lane information gets passed on */
    avago_addr_to_struct(sbus_addr,&addr_struct);
    sbus_data &= 0xffffffff; /* mask out anything more than 32 bits */

    if( addr_struct.chip == AVAGO_BROADCAST ) /* is chip broadcast set? */
    {
        uint data = 0;
        Avago_addr_t a_struct = addr_struct;
        for( a_struct.chip = 0; a_struct.chip < aapl->chips; a_struct.chip++ ) /* send this command to every chip we're connected to. */
            data = avago_sbus(aapl, avago_struct_to_addr(&a_struct), reg_addr, command, sbus_data, recv_data_back);
        return data; /* return data from last command */
    }
    if( addr_struct.ring == AVAGO_BROADCAST ) /* is ring broadcast set? */
    {
        uint data = 0;
        Avago_addr_t a_struct = addr_struct;
        for( a_struct.ring = 0; a_struct.ring < AAPL_MAX_RINGS; a_struct.ring++ )
        {
            if( aapl->max_sbus_addr[a_struct.chip][a_struct.ring] != 0 )  /* send this command to every SBus ring that exists */
                data = avago_sbus(aapl, avago_struct_to_addr(&a_struct), reg_addr, command, sbus_data, recv_data_back);
        }
        return data; /* return data from last command */
    }

    { /* local context for sbus_cmd and mutex locking below */
    char sbus_cmd[AAPL_SBUS_CMD_LOG_BUF_SIZE+1];
    AAPL_SBUS_LOCK;

    /* Form an ASCII representation of the SBus command: */
    snprintf(sbus_cmd, AAPL_SBUS_CMD_LOG_BUF_SIZE, "sbus %x%x%02x %02x %02x 0x%08x",
        addr_struct.chip, addr_struct.ring, addr_struct.sbus & 0xff, reg_addr, command, sbus_data);

    if( !aapl->max_sbus_addr[addr_struct.chip][addr_struct.ring] )
    {
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__,
            "SBus command (%s) destined for SBus address %s sent to ring %d which may not exist.\n",
            sbus_cmd, aapl_addr_to_str(sbus_addr), addr_struct.ring);
    }

    /* if we're in interrupt only mode, only allow SBus commands that are interrupts. */
    if (aapl->spico_int_only && ((command == 1 && reg_addr != 3) || (command == 2 && reg_addr != 4)))
    {
        if (aapl->aacs) snprintf(aapl->data_char, 16, "ERROR"); /* if we're in AACS mode, then make sure the calling function sees an error as SBus reads will be attempted twice in that case */
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "SPICO interrupt only mode is enabled and an SBus command that is not an interrupt is attempting to be sent: %s -> 0x%08x\n", sbus_cmd, sbus_data);
        AAPL_SBUS_UNLOCK;
        return 0;
    }

    /* if the command is the "special" CISM start command, set recv_data_back to 1 to prevent batching, and threading -- ie make it a blocking command */
    if (sbus_addr == 0xfe && reg_addr == 0x00 && (command & 0x3) == 1 && sbus_data == 0x81) recv_data_back = 1;
#if AAPL_ALLOW_THREADED_SBUS
    if (!aapl->debug) /* only execute this when debugging is off, as the aapl_log_printf is not thread safe */
    {
        if (!aapl->sbus_thread) pthread_create(&aapl->sbus_thread, NULL, &aapl_sbus_thread_worker, (void *)aapl);
        while (aapl->sbus_execute) {} /* wait for any pending commands to complete */
        aapl->sbus_sa = sbus_addr;
        aapl->sbus_da = reg_addr;
        aapl->sbus_cmd = command;
        aapl->sbus_data = sbus_data;
        aapl->sbus_recv_data_back = recv_data_back;
        __sync_synchronize();
        /*pthread_mutex_lock(&aapl->sbus_execute_mutex); */
        aapl->sbus_execute = 1;
        /*pthread_mutex_unlock(&aapl->sbus_execute_mutex); */
        /*pthread_cond_signal(&aapl->sbus_execute_cv); */

        if (recv_data_back) /* if we need data back, wait for thread to complete */
        {
            /*pthread_mutex_lock(&aapl->sbus_done_mutex); */
            /*pthread_cond_wait(&aapl->sbus_done_cv, &aapl->sbus_done_mutex); */
            /*pthread_mutex_unlock(&aapl->sbus_done_mutex); */
            while (aapl->sbus_execute) { }
            sbus_data = aapl->sbus_data;
        }
    }
    else
#endif /* AAPL_ALLOW_THREADED_SBUS */
    {
        uint rc = 0;
        if (aapl->sbus_fn)        rc = aapl->sbus_fn(aapl, sbus_addr, reg_addr, command, &sbus_data);
        else if (aapl->sbus_fn_2) rc = aapl->sbus_fn_2(aapl, sbus_addr, reg_addr, command, &sbus_data, recv_data_back); /* aapl_aacs_sbus_fn? */
        else aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "SBus function function not registered.\n");

        if (!rc) aapl_fail(aapl, __func__, __LINE__, "SBus function %s failed. Registered SBus function: 0x%1x.\n", sbus_cmd, (fn_cast_t)aapl->sbus_fn);
    }

    if( recv_data_back <= 1 )
        AAPL_LOG_PRINT8(aapl, AVAGO_DEBUG8, __func__, __LINE__, "%s -> 0x%08x\n", sbus_cmd, sbus_data);
    aapl->sbus_commands++;
    AAPL_SBUS_UNLOCK;
    return sbus_data;
    }
}

#if AAPL_ALLOW_THREADED_SBUS
void *aapl_sbus_thread_worker(void *aapl_in)
{
    Aapl_t *aapl = (Aapl_t *) aapl_in;
    uint data;
    while (1)
    {
        /*pthread_mutex_lock(&aapl->sbus_execute_mutex); */
        /*while (aapl->sbus_execute != 1) pthread_cond_wait(&aapl->sbus_execute_cv, &aapl->sbus_execute_mutex); */
        if (aapl->sbus_execute)
        {
            uint rc = 0;
            aapl->sbus_execute ++; /* increase this count to inform AACS send command that an SBus command is in process */
            data = aapl->sbus_data;
            if (aapl->sbus_fn)        rc = aapl->sbus_fn(aapl, aapl->sbus_sa, aapl->sbus_da, aapl->sbus_cmd, &data);
            else if (aapl->sbus_fn_2) rc = aapl->sbus_fn_2(aapl, aapl->sbus_sa, aapl->sbus_da, aapl->sbus_cmd, &data, aapl->sbus_recv_data_back);
            else aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "SBus function function not registered.\n");

            AAPL_LOG_PRINT8(aapl, AVAGO_DEBUG8, __func__, __LINE__, "%s -> 0x%08x\n", aapl->sbus_cmd, data);
            aapl->sbus_commands++;

            /*printf("t## ex: %x %x %x %x\n", aapl->sbus_sa, aapl->sbus_da, aapl->sbus_cmd, data); */
            aapl->sbus_data = data;
            if (!rc) aapl_fail(aapl, __func__, __LINE__, "SBus function (0x%lx) failed.\n", (fn_cast_t)aapl->sbus_fn);
            aapl->sbus_execute = 0;
        }
        /*pthread_mutex_unlock(&aapl->sbus_execute_mutex); */
        else if (aapl->destroy_thread) break; /* aapl_destruct set this to force the thread to quit */
        else if (aapl->debug) {aapl->sbus_thread = 0; break;} /* this thread will only ever be used if debugging is off, however the thread gets created before we know if debugging is on */
    }
    return NULL;
}
#endif /* AAPL_ALLOW_THREADED_SBUS */


/*============================================================================= */
/*  SBUS RD */
/* */
/** @brief  SBus read operation */
/** @return Returns the result of the read operation. */
/** */
uint avago_sbus_rd(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,         /**< [in] SBus slice address. */
    unsigned char reg_addr) /**< [in] Register to read */
{
    if (aapl->aacs == 1)
    {
        uint data;
        AAPL_SUPPRESS_ERRORS_PUSH(aapl);
        data = avago_sbus(aapl, sbus_addr, reg_addr, 0x02, 0x00000000, /* recv_data_back */ 1);
        AAPL_SUPPRESS_ERRORS_POP(aapl);
        if ((strstr(aapl->data_char, "WARNING") || strstr(aapl->data_char, "ERROR")))
        {
            aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "SBus read failure reading from SBus: %s addr: 0x%02x (%s). Attempting a second sbus read...\n", aapl_addr_to_str(sbus_addr), reg_addr, aapl->data_char);
            data = avago_sbus(aapl, sbus_addr, reg_addr, 0x02, 0x00000000, /* recv_data_back */ 1);
        }
        return data;
    }
    else
        return avago_sbus(aapl, sbus_addr, reg_addr, 0x02, 0x00000000, /* recv_data_back */ 1);
}

/** @brief  Reads multiple registers from a single SBus device. */
/** @return Returns 0 and places the results of the read operations in sbus_data[]. */
uint avago_sbus_rd_array(
    Aapl_t *aapl,                   /**< [in] Pointer to Aapl_t structure. */
    uint addr,                      /**< [in] SBus slice address. */
    uint count,                     /**< [in] Number of registers to read. */
    const unsigned char *reg_addr,  /**< [in] Register addresses to read. */
    uint sbus_data[])               /**< [out] Array into which to place register values. */
{
    uint i;
    if( (uint)aapl->max_cmds_buffered < count+aapl->cmds_buffered )
    {
        /* If buffering is too limited, read one-at-a-time. */
        for( i = 0; i < count; i++ )
            sbus_data[i] = avago_sbus_rd(aapl, addr, reg_addr[i]);
        return 0;
    }

    /* Do array read: */
    for( i = 0; i < count-1; i++ )
        sbus_data[i] = avago_sbus(aapl, addr, reg_addr[i], 0x02, 0x00000000, /* recv_data_back */ 2);
    sbus_data[i] = avago_sbus(aapl, addr, reg_addr[i], 0x02, 0x00000000, /* recv_data_back */ 3);

#if AAPL_ALLOW_AACS
    if( aapl->sbus_fn_2 == &aapl_aacs_sbus_fn )
    {
        /* The results are in the aapl->data_char string. */
        char *ptr = aapl->data_char;
        /*printf("aapl->data_char = \"%s\"\n", ptr); */
        while( *ptr == ';' )
            ptr++;          /* Skip output of any preceding buffered writes */
        for( i = 0; i < count; i++ )
        {
            sbus_data[i] = aapl_strtol(ptr, &ptr, 2);
            ptr++;
            AAPL_LOG_PRINT8(aapl, AVAGO_DEBUG8, __func__, __LINE__, "sbus %04x %2x 02 0x00000000 -> 0x%08x\n", addr, reg_addr[i], sbus_data[i]);
        }
    }
#endif
    return 0;
}

/*============================================================================= */
/*  SBUS WR */
/* */
/** @brief  SBus write operation */
/** @return Returns the result of the avago_sbus() write function, which should generally be ignored. */
/** */
uint avago_sbus_wr(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,         /**< [in] SBus slice address. */
    unsigned char reg_addr, /**< [in] Register to update */
    uint sbus_data)         /**< [in] Data to write */
{
    return avago_sbus(aapl, sbus_addr, reg_addr, 0x01, sbus_data, 0);
}

/*============================================================================= */
/*  SBUS WR FLUSH */
/* */
/** @brief  SBus write operation with flush */
/** @return Returns the result of the avago_sbus() write function, which should generally be ignored. */
/** */
uint avago_sbus_wr_flush(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,         /**< [in] SBus slice address. */
    unsigned char reg_addr, /**< [in] Register to update */
    uint sbus_data)         /**< [in] Data to write */
{
    return avago_sbus(aapl, sbus_addr, reg_addr, 0x01, sbus_data, 1);
}

/*============================================================================= */
/*  SBUS RMW */
/* */
/** @brief  Modify some bits in an existing SBus register */
/** @return Returns the initial value of the SBus register before it was modified. */
uint avago_sbus_rmw(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,         /**< [in] SBus slice address. */
    unsigned char reg_addr, /**< [in] Register to update */
    uint sbus_data,         /**< [in] Data to write */
    uint mask)              /**< [in] Bits in existing data to modify */
{
    /* TBD write code for broadcast RMWs (or at least generate a warning) */

    /* TBD: Convert this to optionally use HS1 read modify write. */
    /* Needs to be conditional so it will still function when compiled */
    /*   into a system not communicating with an HS1 */

    uint initial_value = avago_sbus_rd(aapl, sbus_addr, reg_addr);  /* Read existing value */
    avago_sbus_wr(aapl, sbus_addr, reg_addr, (sbus_data & mask) | (initial_value & ~mask)); /* modify & write */
    return initial_value;
}

#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
/** @cond INTERNAL */
static uint get_sbus_reset_bit(int tap_gen)
{
    if      (tap_gen == 1) return 46;
    else if (tap_gen == 2) return 46;
    else if (tap_gen == 3) return 47;
    else /*if (tap_gen == 4)*/ return 46;
}

static uint get_sbus_core_sbus_override(int tap_gen)
{
    if      (tap_gen == 1) return 47;
    else if (tap_gen == 2) return 48;
    else if (tap_gen == 3) return 49;
    else /*if (tap_gen == 4)*/ return 48;
}

static void send_read_to_all_rings(
    Aapl_t *aapl,
    uint sbus_addr_in      /**< [in] SBus slice address. */
)
{
    uint ring;
    for (ring = 0; ring < aapl->sbus_rings; ring++)
    {
        Avago_addr_t addr_struct;
        avago_addr_to_struct(avago_make_sbus_master_addr(sbus_addr_in), &addr_struct);
        addr_struct.ring = ring;
        avago_sbus_rd(aapl, avago_struct_to_addr(&addr_struct), 0x2); /* send SBus command to make sure reset gets set to each ring */
    }
}

/** @brief Internal function to set SBus reset override signals */
void aapl_set_sbus_tap_reset_sel(Aapl_t *aapl, uint chip, uint override)
{
    if(!aapl->aacs && !aapl_is_jtag_communication_method(aapl)) return; /* only works when communicating with HS1s or PS1s, or if we're in a JTAG communication method */

    aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "HS1 reset override set to: %d.\n", override);

    AAPL_SUPPRESS_ERRORS_PUSH(aapl);
    if (aapl_is_jtag_communication_method(aapl))
    {
        aapl->sbus_reg[126-48-1] = '1';
        avago_sbus_rd(aapl, avago_make_addr3(chip, 0, 0xfe), 0x2);  /* send SBus read command, which forces the above set_sbus to be scanned in */
    }
    else /* aapl->aacs mode is true */
    {
        uint tap_gen = avago_get_tap_gen(aapl);
        char hs1_mode[64];
        char set_sbus[32];
        uint sbus_bit = 49;
        Aapl_comm_method_t comm_method;

        snprintf (hs1_mode, 64, "sbus_mode %s", avago_aacs_send_command(aapl, "sbus_mode"));
        {
            /* sbus_mode can return "slow I2C", but the extra I2C at end is illegal when restoring... */
            char *ptr = strstr(hs1_mode," I2C");
            if( ptr ) *ptr = '\0';
        }
        comm_method = aapl->communication_method;                   /* save previous comm method */
        aapl->communication_method = AVAGO_SBUS;                    /* set to AACS_SBUS so that SBus commands will be sent from AAPL */
        avago_aacs_send_command(aapl, "sbus_mode jtag");            /* set HS1 to JTAG mode so that SBus commands will be sent via JTAG (a JTAG base SBus command will force the HS1 to update these bits) */

        sbus_bit = get_sbus_core_sbus_override(tap_gen);            /* Set jtag override of core sbus reset signal if we're using an HS1 */
        snprintf(set_sbus, 32, "set_sbus %u %d", sbus_bit, override);
        avago_aacs_send_command(aapl, set_sbus);

        sbus_bit = get_sbus_reset_bit(tap_gen);                     /* remove SBus reset (in case it was set for some reason) */
        snprintf(set_sbus, 32, "set_sbus %u %d", sbus_bit, 0);
        avago_aacs_send_command(aapl, set_sbus);

        avago_sbus_rd(aapl, avago_make_addr3(chip, 0, 0xfe), 0x2);  /* send SBus read command, which forces the above set_sbus to be scanned in */

        avago_aacs_send_command(aapl, hs1_mode);                    /* restore HS1 mode */
        aapl->communication_method = comm_method;                   /* restore AAPL mode */
    }
    AAPL_SUPPRESS_ERRORS_POP(aapl);
}
/** @endcond */
#endif /* AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS */


/*============================================================================= */
/* S B U S   R E S E T */
/* */
/** @brief   Performs an sbus reset action. */
/** @details NOTE: When 0xff is used as the input address, all IP types are reset (not just SerDes) */
/** */
/** @return  void */
void avago_sbus_reset(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr_in,      /**< [in] SBus slice address. */
    int hard)
{
    BOOL st;
    Avago_addr_t addr_struct, start, stop, next;

    if (aapl->spico_int_only)
    {
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "SPICO interrupt only mode is enabled and an SBus reset is attempting to be sent to address %s\n", aapl_addr_to_str(sbus_addr_in));
        return;
    }

    if( hard )
    {
        sbus_addr_in = avago_make_serdes_broadcast_addr(sbus_addr_in); /* For a hard reset, all SerDes need the setup/reset below. */
        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Hard SBus reset called to address 0x%x\n", sbus_addr_in);
        if (aapl->hard_sbus_reset_fn) hard = aapl->hard_sbus_reset_fn(aapl, sbus_addr_in);
        else hard = 0; /* not registered, use soft reset */
    }

    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "SBus %s, Soft SBus reset called\n", aapl_addr_to_str(sbus_addr_in));

    /* To prevent power supply glitching, disallow broadcast resets: */
    avago_addr_to_struct(sbus_addr_in, &addr_struct);
    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, AAPL_BROADCAST_IGNORE_LANE);
         st;
         st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_IGNORE_LANE) )
    {
        uint sbus_addr = avago_struct_to_addr(&next);

        if( aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, AVAGO_UNKNOWN_IP) )
            continue; /* Skip entries that don't exist or are unknown */

        if (!hard)
        {
            if (aapl_check_process(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, AVAGO_TSMC_16) && aapl_get_ip_type(aapl, sbus_addr) == AVAGO_SERDES)
                avago_sbus_wr(aapl, sbus_addr, 0xff, 0x0); /* A hardware bug exists that when a reset occurs values on the data bus can corrupt memory. Found on Maxwell, but can effect all 16nm chips, until the SBusRX is fixed. */
            avago_sbus(aapl, sbus_addr, 0x00, 0x00, 0x00, 1); /* soft SBus reset */
        }

        if( aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, FALSE, 1, AVAGO_SERDES) &&
            aapl_check_process(aapl, sbus_addr, __func__, __LINE__, FALSE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28) )
        {
            /* Ensure AVAGO_DMEM_EN_CNTL2 is high so we can do DMA writes (avago_serdes_dma_* needs this) */
            avago_sbus_wr(aapl, sbus_addr, 0x01, 0x20000000);
        }
    }
    if (sbus_addr_in == AVAGO_BROADCAST && !hard) /* if broadcast was input, reset the two items that are not actually broadcast addresses: */
    {
        avago_sbus(aapl, avago_make_sbus_master_addr(sbus_addr_in), 0x00, 0x00, 0x00, 1); /* soft SBus reset for SBus master SPICO */
        avago_sbus(aapl, avago_make_sbus_controller_addr(sbus_addr_in), 0x00, 0x00, 0x00, 1); /* soft SBus reset for SBus controller */
    }
}

/** @cond INTERNAL */

/** @brief   Performs an sbus reset action. */
/** @details sbus_addr_in is used to select which chip and ring to reset. */
/** */
/** @return  TRUE if successful. FALSE if not, or not implemented */
int avago_hard_sbus_reset_fn(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr_in)      /**< [in] SBus slice address. */
{
    int hard = 1;
    (void) sbus_addr_in;
#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
    if (aapl_is_jtag_communication_method(aapl))
    {
        uint tap_gen = avago_get_tap_gen(aapl);
        uint sbus_bit = get_sbus_reset_bit(tap_gen);
        AAPL_SUPPRESS_ERRORS_PUSH(aapl);
        aapl->sbus_reg[126-sbus_bit-1] = '1';
        send_read_to_all_rings(aapl, sbus_addr_in);
        aapl->sbus_reg[126-sbus_bit-1] = '0';
        send_read_to_all_rings(aapl, sbus_addr_in);
        AAPL_SUPPRESS_ERRORS_POP(aapl);
    }
#endif

#if AAPL_ALLOW_AACS
    if (aapl->capabilities & AACS_SERVER_SBUS_RESET) /* can the server support the sbus_reset command? */
    {
        char cmd[64];
        snprintf(cmd, 63, "sbus_reset 0x%x", sbus_addr_in);
        avago_aacs_send_command(aapl, cmd);
    }
    else if(aapl_is_aacs_communication_method(aapl)) /* then we are most likely using an HS1 */
    {
        AAPL_SUPPRESS_ERRORS_PUSH(aapl);
        Aapl_comm_method_t comm_method;
        char hs1_mode[64];
        char set_sbus[32];
        uint tap_gen = avago_get_tap_gen(aapl);
        uint sbus_bit = get_sbus_reset_bit(tap_gen);

        snprintf (hs1_mode, 64, "sbus_mode %s", avago_aacs_send_command(aapl, "sbus_mode"));
        {
            /* sbus_mode can return "slow I2C", but the extra I2C at end */
            /* is illegal when restoring... */
            char *ptr = strstr(hs1_mode," I2C");
            if( ptr )
                *ptr = '\0';
        }
        comm_method = aapl->communication_method;                   /* save previous comm method */
        aapl->communication_method = AVAGO_SBUS;                    /* set to AACS_SBUS so that SBus commands will be sent from AAPL */
        avago_aacs_send_command(aapl, "sbus_mode jtag");            /* set HS1 to JTAG mode so that SBus commands will be sent via JTAG */

        snprintf(set_sbus, 32, "set_sbus %u %d", sbus_bit, 1);
        avago_aacs_send_command(aapl, set_sbus);
        send_read_to_all_rings(aapl, sbus_addr_in);

        snprintf(set_sbus, 32, "set_sbus %u %d", sbus_bit, 0);
        avago_aacs_send_command(aapl, set_sbus);
        send_read_to_all_rings(aapl, sbus_addr_in);

        avago_aacs_send_command(aapl, hs1_mode);                    /* restore HS1 mode */
        aapl->communication_method = comm_method;                   /* restore AAPL mode */
        AAPL_SUPPRESS_ERRORS_POP(aapl);
    }
#endif /* AAPL_ALLOW_AACS */

#if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO
    /* no else if here, attempt other methods as well */
    if(aapl_is_mdio_communication_method(aapl))
    {
        Avago_addr_t addr_struct;
        int prev_timeout;
        uint reset_val;

        avago_addr_to_struct(sbus_addr_in, &addr_struct);

        reset_val = avago_mdio_rd(aapl, addr_struct.chip, AVSP_DEVAD, AVAGO_MDIO_REG_RESET); /* save current reset register */

        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Initial MDIO reset reg: 0x%0x\n", reset_val);

        reset_val &= 0x1; /* just get bit 0 */
        reset_val |= (reset_val << 1); /* make bit 1 a copy of bit 0 */

        reset_val ^= 3; /* assume we we not in reset, so invert the bits */

        prev_timeout = aapl->sbus_mdio_timeout;
        avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, AVAGO_MDIO_REG_RESET, 0x0100 | reset_val);
        avago_mdio_wr(aapl, addr_struct.chip, AVSP_DEVAD, AVAGO_MDIO_REG_RESET, 0x0100 | (reset_val ^ 3));
        aapl->sbus_mdio_timeout = 10000;        /* artificially bump  up the allotted time for completion of this sbus-over-mdio */

        AAPL_SUPPRESS_ERRORS_PUSH(aapl);
        avago_sbus_rd(aapl, avago_make_sbus_controller_addr(sbus_addr_in), 0xfe);        /* Do an sbus-over-mdio read of a known register, this will poll until the sbus reset is clear */
        AAPL_SUPPRESS_ERRORS_POP(aapl);
        aapl->sbus_mdio_timeout = prev_timeout; /* Set the sbus_mdio_timeout back to the previous value */

        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Final MDIO reset reg: 0x%0x\n", 0x0100 | (reset_val ^ 3));
    }
    else
#endif /* AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO */
#if AAPL_ALLOW_I2C || AAPL_ALLOW_SYSTEM_I2C
    if(aapl_is_i2c_communication_method(aapl))
    {
        aapl->sbus_fn(aapl, sbus_addr_in, 0, 3, 0); /* command 3 is hard reset for I2C */
    }
    else
#endif /* AAPL_ALLOW_I2C || AAPL_ALLOW_SYSTEM_I2C */
    if (!aapl_is_aacs_communication_method(aapl) && !aapl_is_jtag_communication_method(aapl)) /* that case was handled separately above */
    {
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Hard reset not implemented, using soft SBus reset instead.\n");
        hard = 0;  /* use soft reset below */
    }
    return hard;
}
/** @endcond */

/** @brief   Performs a read-write test to the SBus Controller or SerDes */
/** @details If sbus_addr is 0 or points to an SBus controller the test will */
/**          Communicate with the SBus Controller (sbus address 0xfd), */
/**          otherwise it will run on any specified SerDes SBus address. */
/** @return  TRUE if the test passes, FALSE if any errors. */
BOOL avago_diag_sbus_rw_test(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,     /**< [in] SBus slice address. */
    int cycles)         /**< [in] Number of write-read cycles to do. */
{
    Avago_addr_t addr_struct;
    int result = TRUE, addr, data_addr, mask, rev = 0, data2 = 0, x;
    uint ran, data = 0, prev = 0;

    if (aapl->spico_int_only) return TRUE;

    avago_addr_to_struct(sbus_addr, &addr_struct);
    if( addr_struct.chip == AVAGO_BROADCAST ) addr_struct.chip = 0;
    if( addr_struct.ring == AVAGO_BROADCAST ) addr_struct.ring = 0;

    if (addr_struct.sbus != AVAGO_SBUS_CONTROLLER_ADDRESS &&  /* check for SBus controller (don't call aapl_get_ip_type as the cache may not yet be set (and this may be running during get_ip_info) */
        (!aapl->ip_type[AAPL_3D_ARRAY_ADDR(addr_struct)] ||  /* check if cache has been set. If not, revert to controller */
         (aapl_get_ip_type(aapl, sbus_addr) != AVAGO_SERDES &&  aapl_get_ip_type(aapl, sbus_addr) != AVAGO_M4 )))  /* if cache is set, check to see if it is a SerDes */
    {
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "%s requested on SBus address %s, which doesn't support the r/w test. Testing using SBus address %s instead.\n",
            __func__, aapl_addr_to_str(sbus_addr), aapl_addr_to_str(avago_make_sbus_controller_addr(sbus_addr)));
        sbus_addr = avago_make_sbus_controller_addr(sbus_addr);
    }

    avago_addr_to_struct(sbus_addr, &addr_struct);

    if (addr_struct.sbus == 0 || addr_struct.sbus == AVAGO_SBUS_CONTROLLER_ADDRESS)
    {
        addr = avago_make_sbus_controller_addr(sbus_addr); /* if no address past in, use SBus controller */
        mask = 0xffffffff;
        data_addr = 0x13;
    }
    else /* SerDes */
    {
        addr = sbus_addr;
        mask = 0xffff;
        data_addr = 0x26; /* Lower 16 bits is PC override, which is rarely used */
    }

    AAPL_SUPPRESS_ERRORS_PUSH(aapl);
    {
        int orig_val = avago_sbus_rd(aapl, addr, data_addr); /* store original value so we can restore it later */

        ran = 0x1678ab4a;     /* seed for pseudo random number generator below */
        ran ^= (size_t) &ran; /* XOR in address of the variable, which should vary some */
        for( x=1; x <= cycles; x++ )
        {
            ran = (ran << 1) | (((ran >> 0) ^ (ran >> 6)) & 0x1); /* generate a pseudo random number */
            ran &= mask;
            avago_sbus_wr(aapl, addr, data_addr, ran);   /* write random value */
            data = avago_sbus_rd(aapl, addr, data_addr) & mask; /* read value written */
            if (data != ran)
            {
                rev = avago_sbus_rd(aapl, addr, 0xff); /* read known static value */
                data2 = avago_sbus_rd(aapl, addr, data_addr) & mask; /* read value written */
                result = FALSE;
                if (!(aapl->debug & AAPL_DEBUG_SBUS_RW_TEST)) break;

                aapl->suppress_errors -= 1; /* Allow this error to be printed -- the debug mode indicates that we want to see all errors that occur */
                aapl_fail(aapl, __func__, __LINE__, "SBus read/write test failed on address %s in test loop %d. Expected 0x%08x, but got 0x%08x, re-read: 0x%08x. Previous data written was: 0x%08x. Reg 0xff: 0x%08x\n", aapl_addr_to_str(addr), x, ran, data, data2, prev, rev);
                aapl->suppress_errors += 1;
            }
            if (x % 1000 == 0) aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "SBus R/W %d cycles complete on address %s.\n", x, aapl_addr_to_str(addr));
            prev = ran;
        }
        /* Need to flush the sbus commands here, because if there is a read/write failure */
        /* this command will fail and the HS1 will fail to execute any other buffered sbus commands. */
        avago_sbus_wr_flush(aapl, addr, data_addr, orig_val); /* restore original value. */
    }
    AAPL_SUPPRESS_ERRORS_POP(aapl);

    if (result) aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "SBus R/W test passed on address %s after %d cycles.\n", aapl_addr_to_str(addr), cycles);
    else if (!(aapl->debug & AAPL_DEBUG_SBUS_RW_TEST)) aapl_fail(aapl, __func__, __LINE__, "SBus read/write test failed on address %s in test loop %d. Expected 0x%08x, but got 0x%08x, re-read: 0x%08x. Previous data written was: 0x%08x. Reg 0xff: 0x%08x\n", aapl_addr_to_str(addr), x, ran, data, data2, prev, rev);
    return result;
}


#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
/** @cond INTERNAL */

/** @brief   Implements an SBus command with JTAG instructions */
/** @return  SBus result */
uint avago_jtag_sbus_fn(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint sbus_address,  /**< [in] SBus slice address. */
    unsigned char data_address,
    unsigned char command,
    uint *data)
{
    #define AVAGO_JTAG_SCAN_DATA_OUT (32+12)
    #define AVAGO_BITS_TO_SCAN 126 - AVAGO_JTAG_SCAN_DATA_OUT
    #define AVAGO_MAX_LOOPS 1000

    /*static unsigned char prev_command = 0; // only used by dummy write code */
    uint cism = 0; /* special CISM command */
    uint tap_gen = avago_get_tap_gen(aapl);
    char tdi[256];
    char *tdo = 0;
    char bin_data[33];

    int max_read_loops = AVAGO_MAX_LOOPS;
    int max_dummy_write_loops = AVAGO_MAX_LOOPS;
    int offset;
    Avago_addr_t addr_struct;
    avago_addr_to_struct(sbus_address, &addr_struct);

    if (tap_gen == 3) offset = 1;
    else              offset = 0;

    if (tap_gen != 3 && tap_gen != 4)
    {
        aapl_fail(aapl, __func__, __LINE__, "%s only supports TAP gen 3 and 4.\n", __func__);
        return FALSE;
    }

    aapl_set_chip_by_addr(aapl, sbus_address);

    /* if (offset) sprintf(tdi, "%s%s%s%s%s%s%s", "00000000000000000", "0000", da, sa, cmd, dat, "010010"); */
    /* else        sprintf(tdi, "%s%s%s%s%s%s%s", "00000000000000000", "0000", da, sa, cmd, dat, "01001"); */
    memset(tdi, 0, 255);
    memcpy(tdi,    aapl->sbus_reg, 128);
    memcpy(tdi+21, aapl_hex_2_bin(bin_data, data_address, 0, 8), 8);
    memcpy(tdi+29, aapl_hex_2_bin(bin_data, sbus_address, 0, 8), 8);
    memcpy(tdi+37, aapl_hex_2_bin(bin_data, command, 0, 8),      8);
    memcpy(tdi+45, aapl_hex_2_bin(bin_data, *data, 0, 32),      32);

    tdi[78] = '1'; /* SBUS_RCV_DATA_VALID_SEL */
    tdi[81] = '1'; /* SBUS_EXECUTE */

    /*tdi[126-49] = 0x31; // reset override */

    if (sbus_address == 0xfe && data_address == 0x00 && (command & 0x3) == 1 && *data == 0x81) cism = 1;

    if ((command & 0x3) != 2 && cism != 1) /* if it's not a read and it's not a CISM command, then do a single scan in now */
        avago_jtag_options(aapl, aapl->sbus_tdr_opcode_base + addr_struct.ring, AVAGO_BITS_TO_SCAN + offset, tdi, 0); /* sbus_execute set high -- and we don't need to scan in the result data */
    else
    {
        /*Dummy write code: */
        /*if ((prev_command & 0x3) == 2) // was the last command also a read? */
        /*{ */
        /*    char dummy_tdi[256]; */
        /*    sprintf(dummy_tdi, "%s%s%s%s%s%s%s%s%s%s", "00000000000000000", "0000", "11111111", "11111110", "00000001", "00000000000000000000000000000000", "00001", "0000000", "00000", "00000000000000000000000000000000"); */
        /*    do */
        /*    { */
        /*        tdo = avago_jtag(aapl, aapl->sbus_tdr_opcode_base + addr_struct.ring, AVAGO_BITS_TO_SCAN+offset, dummy_tdi); // scan result out -- extra bit for tap gen 4 */
        /*        max_dummy_write_loops --; */
        /*        //printf("## %d %x%x%x\n", max_dummy_write_loops, tdo[AVAGO_BITS_TO_SCAN-34-1]-0x30, tdo[AVAGO_BITS_TO_SCAN-33-1]-0x30, tdo[AVAGO_BITS_TO_SCAN-32-1]-0x30); */
        /*    } while (!(tdo[AVAGO_BITS_TO_SCAN-34-1] == 0x30 && tdo[AVAGO_BITS_TO_SCAN-32-1] == 0x31) && max_dummy_write_loops); */
        /*} */

        if (!aapl->recv_data_valid[addr_struct.chip][addr_struct.ring]) /* if we don't have a previous recv data valid, we need to retrieve it the first time so we know what to look for below */
        {
            tdo = avago_jtag_options(aapl, aapl->sbus_tdr_opcode_base + addr_struct.ring, AVAGO_BITS_TO_SCAN + offset, tdi, 1); /* sbus_execute set high -- and we don't need to scan in the result data */
            aapl->recv_data_valid[addr_struct.chip][addr_struct.ring] = tdo[AVAGO_BITS_TO_SCAN-35-1];
            /*printf("### %x\n", aapl->recv_data_valid[addr_struct.chip][addr_struct.ring]); */
        }
        else
            avago_jtag_options(aapl, aapl->sbus_tdr_opcode_base + addr_struct.ring, AVAGO_BITS_TO_SCAN + offset, tdi, 0); /* sbus_execute set high -- and we don't need to scan in the result data */

        tdi[126-45] = 0x30; /* set execute low */

        while (1)
        {
            tdo = avago_jtag(aapl, aapl->sbus_tdr_opcode_base + addr_struct.ring, AVAGO_BITS_TO_SCAN+offset, tdi); /* scan result out -- extra bit for tap gen 4 */
            /*if (tap_gen >= 4 && tdo[AVAGO_BITS_TO_SCAN-44-1] == '1') // check for SBus execute still being set high */
            /*    aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "SBus executed remained high when executing %02x %02x %02x %08x. Read loops: %d Dummy write loops: %d. Bits scanned in: %s Bits scanned out: %s\n", */
            /*        sbus_address, data_address, command, *data, AVAGO_MAX_LOOPS-max_read_loops, AVAGO_MAX_LOOPS-max_dummy_write_loops, tdi, tdo?tdo:""); */
            if (!cism && --max_read_loops == 0) break; /* stop if timed out */
            if (tdo[AVAGO_BITS_TO_SCAN-34-1] == 0x31 && tdo[AVAGO_BITS_TO_SCAN-32-1] == 0x30 && tdo[AVAGO_BITS_TO_SCAN-35-1] != aapl->recv_data_valid[addr_struct.chip][addr_struct.ring] && !cism) break;
            else if (cism && tdo[AVAGO_BITS_TO_SCAN-34-1] == 0x31 && tdo[AVAGO_BITS_TO_SCAN-33-1] == 0x31 && tdo[AVAGO_BITS_TO_SCAN-32-1] == 0x31) break;
        }

        /*printf("### %x %x\n", aapl->recv_data_valid[addr_struct.chip][addr_struct.ring], tdo[AVAGO_BITS_TO_SCAN-35-1]); */
        /*printf("#! %d %x%x%x\n", max_read_loops, tdo[AVAGO_BITS_TO_SCAN-34-1]-0x30, tdo[AVAGO_BITS_TO_SCAN-33-1]-0x30, tdo[AVAGO_BITS_TO_SCAN-32-1]-0x30); */
        if (offset) tdo[AVAGO_BITS_TO_SCAN] = 0; /* delete extra bit from end of scan chain */

        if (!max_read_loops || !max_dummy_write_loops)
        {
            aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Read and/or dummy write loops reached max for command: %02x %02x %02x %08x: read dummy: %d write dummy: %d %x%x%x\n", sbus_address, data_address, command, *data, AVAGO_MAX_LOOPS-max_read_loops, AVAGO_MAX_LOOPS-max_dummy_write_loops, tdo[AVAGO_BITS_TO_SCAN-34-1]-0x30, tdo[AVAGO_BITS_TO_SCAN-33-1]-0x30, tdo[AVAGO_BITS_TO_SCAN-32-1]-0x30);
            aapl->recv_data_valid[addr_struct.chip][addr_struct.ring] = 0; /* something went wrong, detect aapl->recv_data_valid next time */
            aapl->prev_opcode = 0; /* force opcode to get updated */
        }

        *data = (uint) aapl_strtoul(tdo+AVAGO_BITS_TO_SCAN-32, NULL, 2);
    }
    if (aapl->recv_data_valid[addr_struct.chip][addr_struct.ring] == 0x30) aapl->recv_data_valid[addr_struct.chip][addr_struct.ring] = 0x31; /* invert XOR selection for next command */
    else aapl->recv_data_valid[addr_struct.chip][addr_struct.ring] = 0x30;

    if (cism) aapl->recv_data_valid[addr_struct.chip][addr_struct.ring] = 0;
    /*prev_command = command; */

    if (aapl->debug >= 9)
    {
        AAPL_LOG_PRINT9(aapl, AVAGO_DEBUG9, __func__, __LINE__, "Bits scanned in:  %s\n", tdi);
        if ((command & 0x3) == 2) AAPL_LOG_PRINT9(aapl, AVAGO_DEBUG9, __func__, __LINE__, "Read loops: %d Dummy write loops: %d. Bits scanned out: %s\n", AVAGO_MAX_LOOPS-max_read_loops, AVAGO_MAX_LOOPS-max_dummy_write_loops, tdo?tdo:""); /* (int) strlen(tdo+126-40-offset), tdo+126-40-offset); */
    }
    return TRUE;
}

/** @endcond */
#endif
