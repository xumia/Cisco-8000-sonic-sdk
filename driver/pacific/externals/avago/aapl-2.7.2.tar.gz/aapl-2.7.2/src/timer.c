/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* timer.c */
/* */
/* ONELINER microtimer implementation */
/* */

/** @file */
/** @brief Microtimer functions for e.g. profiling performance */

#include "aapl.h"

/** @cond INTERNAL */

#ifdef WIN32
static __int64 m_frequency = 0;
#endif

#include "timer.h"


/* Accumulate time and/or start timer */
/* */
static void aapl_timer_accumulate(Aapl_microtimer_t *timer, int bstart)
{
#ifdef WIN32
    LARGE_INTEGER now;
    if( (timer->m_start != 0 || bstart) && QueryPerformanceCounter(&now) )
    {
        if( timer->m_start != 0 )
            timer->m_timer += (now.QuadPart - timer->m_start);        /* Accumulate time */
        timer->m_start = now.QuadPart;
    }
#else
    struct timeval now;
    if( (timer->m_start.tv_sec != 0 || bstart) && (0 == gettimeofday(&now,0)) )
    {
        if( timer->m_start.tv_sec != 0 )        /* Accumulate time */
            timer->m_timer += ((bigint)(now.tv_sec - timer->m_start.tv_sec)) * 1000000 +
                                   now.tv_usec - timer->m_start.tv_usec;
        timer->m_start = now;                /* struct assignment */
    }
#endif
}

/** @brief Initializes timer. */
/** @details Call before first use. */
void aapl_timer_reset(Aapl_microtimer_t *timer)
{
#ifdef WIN32
    if( m_frequency == 0 )
    {
        LARGE_INTEGER frequency;
        if( QueryPerformanceFrequency(&frequency) )
            m_frequency = frequency.QuadPart;
        else
            m_frequency = 1;    /* gettimeofday returns microseconds */
    }
    timer->m_start = AAPL_CONST_INT64(0);
    timer->m_timer = AAPL_CONST_INT64(0);
#else
    timer->m_start.tv_sec = 0;
    timer->m_timer = 0;
#endif
}

/** @brief Starts or continues counting from current elapsed time. */
void aapl_timer_start(Aapl_microtimer_t *timer)
{
    aapl_timer_accumulate(timer,1);
}

/** @brief Restarts counting from zero. */
void aapl_timer_reset_start(Aapl_microtimer_t *timer)
{
    aapl_timer_reset(timer);
    aapl_timer_start(timer);
}

/** @brief Stops timer and optionally synchronously switches to new timer without loss of time. */
void aapl_timer_switchto(Aapl_microtimer_t *oldtimer, Aapl_microtimer_t *newtimer)
{
    aapl_timer_accumulate(oldtimer, 0!=newtimer); /* Accumulate to oldtimer */
    if( newtimer )
        newtimer->m_start = oldtimer->m_start;  /* start other timer */
#ifdef WIN32
    oldtimer->m_start = 0;                  /* Turn off this timer */
#else
    oldtimer->m_start.tv_sec = 0;           /* Turn off this timer */
#endif
}

/** @brief Stops accumulating time. */
void aapl_timer_stop(Aapl_microtimer_t *timer)
{
    aapl_timer_switchto(timer, 0);
}

/** @brief Accumulates time and returns microseconds of accumulated time. */
bigint aapl_timer_get(Aapl_microtimer_t *timer)
{
    /* accumulate time, don't start if not already running */
    aapl_timer_accumulate(timer,0);
#ifdef WIN32
    return (bigint)(timer->m_timer * 1000000 / m_frequency);
#else
    return timer->m_timer;
#endif
}

/** @brief Accumulates time and returns a string representation of the accumulated time in seconds. */
const char *aapl_timer_gets(Aapl_microtimer_t *timer)
{
    static char buf[2][20];
    static int which = 0;
    long t = aapl_timer_get(timer) / 100;
    sprintf(buf[1 & ++which],"%ld.%04ld",t/10000,t % 10000);
    return buf[1 & which];
}

/** @brief Saves timer state into state string. */
/** @details The state string should be a buffer at least 32 bytes long. */
void aapl_timer_save(Aapl_microtimer_t *timer, char *state)
{
    int sec;
    uint usec;
#ifdef WIN32
    sec  = timer->m_start >> 32;
    usec = timer->m_start & 0xffffffff;
#else
    sec = timer->m_start.tv_sec;
    usec = timer->m_start.tv_usec;
#endif
    sprintf(state,"%d,%u", sec, usec);
}

/** @brief Initializes timer from state string. */
void aapl_timer_init(Aapl_microtimer_t *timer, const char *state)
{
    int sec;
    uint usec;
    sscanf(state,"%10d,%10u", &sec, &usec);
    aapl_timer_reset(timer);
#ifdef WIN32
    timer->m_start = sec;
    timer->m_start <<= 32;
    timer->m_start |= usec;
#else
    timer->m_start.tv_sec = (time_t)sec;
    timer->m_start.tv_usec = (suseconds_t)usec;
#endif
}

/** @endcond */
