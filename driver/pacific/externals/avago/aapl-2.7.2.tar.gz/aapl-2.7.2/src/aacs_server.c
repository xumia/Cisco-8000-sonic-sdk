/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* AAPL (ASIC and ASSP Programming Layer), AACS (Avago ASIC Communication */
/* Service), LAN (command) server process/thread.  This allows a customer */
/* application to start a server and send it commands over TCP/IP that are */
/* processed locally using AAPL. */

/** Doxygen File Header */
/** @file */
/** @brief Implementation of AACS Server functionality. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"


#if AAPL_ENABLE_AACS_SERVER
/* Global variables used by aacs_server and it's functions */
struct sockaddr_in client_IPaddr, client_IPaddr_ts;
struct sockaddr_in client_IPaddr_lock[2];

#if !defined __MINGW32__ && !defined _MSC_VER
#include <arpa/inet.h> /* needed by the server, but not the main functions */
#endif
#endif /* AAPL_ENABLE_AACS_SERVER */

#if AAPL_ENABLE_MAIN || AAPL_ENABLE_AACS_SERVER

#define EQCN(str1,str2,len) (! aapl_strncasecmp(str1, str2, len))
#define EOS               '\0'
#define ISNUL(cp)         (*(cp) == EOS)
#define ISEOL(cp)         ((*(cp) == '#') || ISNUL(cp))  /* comment or end. */
#define ISTERM(cp)        (isspace(*(cp)) || ISEOL(cp))  /* end of token. */
#define SKIPSPACE(cp)     while (isspace(*(cp))) ++(cp)
#define ISCMD(cp,cmd,len) (EQCN(cp, cmd, len) && ISTERM((cp) + len))

/* Special result strings for special commands, used both as flags and for */
/* logging: */

#define RES_CLOSE "(close)"
#define RES_EXIT  "(exit)"

/* Keep this string consistent with avago_aacs_process_cmd(): */

const char *RES_HELP = "Valid commands are: sbus, jtag, i2c"
#if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO
    ", mdio"
#endif
    ", set_debug, chips, chipnum, version, status, send, help, close, exit, spico_int, commands, sleep, tck_delay"
#if AAPL_ENABLE_ATE_VEC
    ", ate_vec"
#endif
#if AAPL_ENABLE_DIAG
    ", diag"
#endif
    ", sbus_reset, cli, lock, unlock, allow, log_dump. Command batching supported.";


/*============================================================================= */
/* N U M   F R O M   H E X */
/* */
/** @details     Parse a hex number and return the equivalent binary number, */
/**              with *endp modified to the first char after the token. */
/** @param cp    String that should be all hex digits. */
/** @param endp  Pointer to string to return. */
/** @param min   Minimum token length in chars (must be >= 1). */
/** @param max   Maximum token length in chars. */
/** @return uint Binary equivalent, or 0 for any error, with *endp set to the */
/**              original cp (as a failure flag). */

static uint aapl_num_from_hex(const char *cp, const char **endp, int min, int max)
{
    uint result = 0;
    const char * start = *endp = cp;

    while (isxdigit(*cp))
    {
        if (cp - start >= max) return(0);
        result = (result << 4) | (uint)(isdigit(*cp) ? (*cp - '0') : (10 + tolower(*cp) - 'a'));
        ++cp;
    }
    if ((cp - start < min) || (! ISTERM(cp))) return(0);
    *endp = cp;
    return(result);
}

/*============================================================================= */
/* N U M   F R O M   B I N */
/* */
/** @details     Parse an ASCII binary number possibly containing 'x'/'X' */
/**              digits, and return the equivalent binary number, with *endp */
/**              modified to the first char after the token. */
/** @param cp    String that should be all '0'/'1'/'x'/'X' digits. */
/** @param endp  Pointer to string to return. */
/** @param min   Minimum token length in chars (must be >= 1). */
/** @param max   Maximum token length in chars. */
/** @param maskp Pointer to a 32-bit mask value to set, default = all 1s, but */
/**              returns 0s for 'x'/'X' meaning bits not to be changed */
/**              (read/modify/write). */
/** @return uint Binary equivalent, or 0 for any error, with *endp set to the */
/**              original cp (as a failure flag); and with *maskp (always) */
/**              modified to reflect the data value.  In case of an empty */
/**              string (following a data value consisting of just "z"), */
/**              assuming min >= 1, returns 0 with an apparent error, but with */
/**              mask = 0, and the caller can proceed from there. */

static uint aapl_num_from_bin(const char *cp, const char **endp, int min, int max, uint *maskp)
{
    uint result = 0;
    uint mask   = 0;  /* default = no bits to modify. */
    const char * start = *endp = cp;

    while ((*cp == '0') || (*cp == '1') || (*cp == 'x') || (*cp == 'X'))
    {
        if (cp - start >= max) return(0);

        if ((*cp == '0') || (*cp == '1'))
        {
            result = (result << 1) | (uint)(*cp - '0');
            mask = (mask << 1) | 1;
        }
        else
        {
            result <<= 1;
            mask <<= 1;  /* 0-bit, masked out. */
        }
        ++cp;
    }
    *maskp = mask;

    if ((cp - start < min) || (! ISTERM(cp))) return(0);
    *endp = cp;
    return(result);
}


/* A common abbreviation that optionally closes 0-2 files: */

#define FAILRET(rc,fd1,fd2) {if ((fd1) >= 0) close(fd1); if ((fd2) >= 0) close(fd2); return rc;}

/* Note:  Would like to declare char arrays/pointers "properly", but then every */
/* call to a library like strlen() requires a cast to the explicit, wrong type */
/* "char *": */
/* */
/* typedef unsigned char uc_t, * str_t;  // for brevity here. */


/*============================================================================= */
/* C M D   E R R O R */
/* */
/* Given a buffer of size AACS_SERVER_BUFFERS, plus a printf() format string and any */
/* varargs, print a client command error into the buffer with "ERROR:" */
/* inserted. */

static void cmd_error(Aapl_t *aapl, char *result, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsprintf(result, fmt, ap);

    /* Print to the aapl log */
    aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "%s\n", result);

    memmove(result+19, result, strlen(result)+1); /* move the string to the right by 19 */
    memcpy(result, "AACS server ERROR: ", 19);
    va_end(ap);
}

/*============================================================================= */
/* All command handling functions below receive: */
/* */
/* - full command line string for error messages (possibly including leading */
/*   whitespace), but with any trailing CR/NL removed */
/* */
/* - place in the string immediately after the command (known to be ISTERM()) */
/* */
/* - a result buffer to write */
/* */
/* All return non-null text (result or error message) in result[], without a */
/* trailing newline. */


/*============================================================================= */
/* S B U S   P A R S E   D A   C M D */
/* */
/* Parse an SBus command <da> or <cmd> field.  Given: */
/* */
/* - command string read from a socket (any trailing CR/NL already removed) */
/* - pointer to start of SBus <da> or <cmd> token to parse */
/* - pointer to uint value to return */
/* - argument number on command line, for error message */
/* - description of the value, for error message */
/* - result buffer */
/* */
/* Parse the token as a 2-char hex number.  If successful, sets *valp, advances */
/* *cpp to the next token, and returns TRUE; otherwise, writes an error message */
/* into result, and returns FALSE. */

static BOOL sbus_parse_da_cmd(Aapl_t *aapl, const char * cmd, const char ** cpp, uint * valp, const int argnum, const char * valname, char * result)
{
    const char * cp2;
    uint val = aapl_num_from_hex(*cpp, &cp2, 2, 2);

    if (cp2 == *cpp)
    {
        cmd_error(aapl, result, "Invalid \"sbus\" command ignored: Arg %d = <%s> must be 2 hex digits. Got: \"%s\".", argnum, valname, cmd);
        return(FALSE);
    }
    SKIPSPACE(cp2);
    *cpp  = cp2;
    *valp = val;
    return(TRUE);
}

/*============================================================================================ */
/* S B U S   P A R S E   D A T A */
/* */
/* Parse an SBus command <data> field; given: */
/* */
/* - command string read from a socket (any trailing CR/NL already removed) */
/* - pointer to start of SBus <data> token to parse */
/* - pointer to uint value to return */
/* - pointer to uint mask to return */
/* - result buffer */
/* - pointer to read/modify/write flag to set */
/* */
/* Parse various formats (see the HW ServerUISpec, or summary below).  If */
/* successful, sets *datap and *maskp (latter with 1s for bits to set), */
/* advances *cpp to the next token, and returns the number of bits to send the */
/* client in the reply (8 or 32); otherwise, writes an error message into */
/* result, and returns 0. */

static int sbus_parse_data(Aapl_t *aapl, const char * cmd, const char ** cpp, uint * datap, uint * maskp, char * result)
{
    const char * cp = *cpp;
    const char * cp2;
    int  reslen;  /* number of bits to send client, based on input. */
    uint data = 0;

/* ----------- excerpt from HW ServerUISpec 110224 ------------ */
/*  Address formats for <data>: */
/* */
/*  C:  2 chars:  8-bit ASCII-encoded hex, such as "a5" */
/*  D:  8 chars:  8-bit ASCII-encoded binary, such as "10100101" */
/*  E: 10 chars:  32-bit ASCII-encoded hex, such as "0x012345a5" */
/*                (the leading "0x" or "0X" is required) */
/*  F: 32 chars:  32-bit ASCII-encoded binary, such as */
/*                "00000001001000110100010110100101" */
/*  G:  N <= 31 chars (variable length) beginning with 'z'/'Z', such as "z01011": */
/*                same as previous except the 'z'/'Z' is replaced with an */
/*                appropriate number of 'x's to make a 32-char <data> value (see */
/*                below) */
/* */
/*  For short formats (C and D), leading bits are prefilled as 0s. */
/* */
/*  For all ASCII-encoded binary formats (D, F, G), any character except */
/*  the 'z'/'Z' prefix for case G can be specified as 'x'/'X' instead of */
/*  '0'/'1'.  Special case:  D or F can start with "0x"|"0X". */


/* Check for 'z' prefix (case G) followed by 0-31 ASCII binary bits: */

    if ((*cp == 'z') || (*cp == 'Z'))
    {
        data = aapl_num_from_bin(++cp, &cp2, 1, 31, maskp);

        if (cp == cp2)  /* empty or invalid binary string found: */
        {
            if (! ISTERM(cp + 1))  /* naked "z" only is OK; data == *maskp == 0. */
            {
                cmd_error(aapl, result, "Invalid \"sbus\" command ignored. Arg 4 = <data> 'z' prefix must be followed by 0-31 '0'/'1'/'x'/'X' chars, but got: \"%s\".", cmd);
                return(0);
            }
        }
        /* else leaves cp2 set after token. */

        reslen = 32;
    }

/* Check for cases C,D,E,F starting with token length (2,8,10,32): */

    else
    {
        int len;
        *maskp = 0xffffffff;  /* default = no read/modify/write. */

        for (cp2 = cp; isxdigit(*cp2) || (*cp2 == 'x') || (*cp2 == 'X'); ++cp2)
        /* null */;

        len = cp2 - cp;

        if      ( len ==  2) data = aapl_num_from_hex(cp, &cp2,  2,  2);         /* case C. */
        else if ( len ==  8) data = aapl_num_from_bin(cp, &cp2,  8,  8, maskp);  /* case D. */
        else if ((len == 10) && EQCN(cp, "0x", 2))
                   {cp += 2; data = aapl_num_from_hex(cp, &cp2,  8,  8);}        /* case E. */
        else if ( len == 32) data = aapl_num_from_bin(cp, &cp2, 32, 32, maskp);  /* case F. */
        else cp2 = cp;  /* marks an error. */

        if (cp == cp2)
        {
            cmd_error(aapl, result, "Invalid \"sbus\" command ignored. Arg 4 = <data> must be 2-hex, 8-bin, 0x-8-hex, 32-bin, or \"z\" prefix variable-length, but got: \"%s\".", cmd);
            return(0);
        }
        reslen = ((len <= 8) ? 8 : 32);
    }
    *cpp   = cp2;
    *datap = data;
    return(reslen);

} /* sbus_parse_data() */


/*============================================================================= */
/* C H E C K   T E R M */
/* */
/* Given: */
/* */
/* - command line string for error messages */
/* */
/* - location of trailing part of command, after last token, but can start */
/*   with whitespace */
/* */
/* - result buffer to write */
/* */
/* Check if the command terminates properly:  if not a white space, */
/* at end of line or a comment mark, write an error message to result and */
/* return FALSE, otherwise just return TRUE. */

static BOOL check_term(Aapl_t *aapl, const char * cmd, const char * cp, char * result)
{
    if (!cp || ISTERM(cp)) return(TRUE);

    cmd_error(aapl, result, "Unexpected extra word(s) on command line, ignored. Got: \"%s\".", cmd);
    return(FALSE);
}

/*============================================================================= */
/* S B U S   C O M M A N D */
/* */
/* Handles an "sbus" command and writes into result an error message or the */
/* SBus command response.  See command handling summary above. */
/* */
/* This code versus the HW server and sbus*() backends: */
/* */
/* - This server parses the SBus parameters:  All values are allowed the same */
/*   as in the HW server, except no ASCII binary for <sa>, <da>, or <cmd> args. */
/*   Comments are allowed but presently ignored, not forwarded to sbus*() */
/*   back-ends.  Unlike the HW server, parses strings to binary values, not to */
/*   strings.  Any "z" or "x" in <data> sets corresponding mask bits to 0, */
/*   otherwise it's all-1s. */
/* */
/* - For <sa>, parses/saves optional chip_num (4th char) and ring_num (3rd */
/*   char) values, and applies them to all following SBus commands until */
/*   changed.  Note that "chip_num" can independently alter chip_num between */
/*   SBus commands. */
/* */
/* - This server does not range-check chip_num or ring_num values at all.  This */
/*   allows passing 0xf (for broadcast) to AAPL sbus*() (unlike no special */
/*   meaning of 0xf for HW the server), and lets it do any other range checking */
/*   at a lower level. */
/* */
/* - This server does not handle broadcast (<sa> & 0xff = special values like */
/*   0xff) and/or RMW (zero'd mask bits).  It just passes parameters (as ints, */
/*   plus mask) to sbus*() for it to handle. */
/* */
/* - Lower-level sbus*() handles both broadcast and/or RMW, versus what's */
/*   passed to the HW server if that's the backend.  Might be slower but more */
/*   portable to not forward broadcast and/or RMW to the HW server. */
/* */
/* sbus <sa> <da> <cmd> <data> [# <comment>]  # in these formats: */
/* */
/*   <sa>:    SBus (slice) address, optionally including chip + ring numbers */
/*   <da>:    data (register) address */
/*   <cmd>:   command, usually 01 = write or 02 = read */
/*   <data>:  data to send */
/* */
/* <sa>,<da>,<cmd> = 2-char hex only, such as "00" or "a5" (except <sa>, see */
/*   below); unlike Perl/HW servers, does not support ASCII binary for these */
/*   values. */
/* */
/*   For <sa> only:  Optional 4/3-char format to set *chip_nump (0..f) (such as */
/*   "2" in "2081") and *ring_nump (0..f) (such as "3" in "37a").  Previous */
/*   chip and ring numbers are remembered and applied to new "sbus" commands */
/*   where they are not respecified, plus "chip_num" can revise chip_num */
/*   between SBus commands. */
/* */
/* <data> = 2-char hex, 8-char binary, 8-char hex (preceded by "0x"), or */
/*   32-char binary; with "z" and "x" allowed in binary values for leading */
/*   zeroes and read/modify/write, respectively. */
/* */
/* Examples: */
/*   sbus fe 0a 02 00          # read SBus master clock divider value. */
/*   sbus fe 0a 01 0x00000003  # write divider using 32-bit/char value. */
/*   sbus fe 0a 01 00000000000000000000000000000011  # write using binary. */
/*   sbus fe 0a 01 z1x0        # RMW setting bits [2,0] to '1x0'. */
/* */
/* Note:  This AAPL AACS server's "sbus" command code is similar to that in the */
/* HW server (HS1, PS1, PC1), but far from identical. */

static void sbus_command(Aapl_t * aapl, const char * cmd, const char * cp, char * result, int * chip_nump, int * ring_nump)
{
    const char * cp2;
    uint new_chip = 0x10;
    uint new_ring = 0x10;
    uint sa;
    uint data_out;
    uint da, scmd, data, mask = 0xffffffff;

    int reslen;

    SKIPSPACE(cp);

    if (ISEOL(cp))
    {
        cmd_error(aapl, result, "Invalid \"sbus\" command ignored. Must be: \"sbus <sa> <da> <cmd> <data> [# <comment>]\".");
        return;
    }

/* Parse <sa> with special case handling of 4/3-char hex <sa> starting with */
/* [chip number and] SBus ring address: */
/* */
/* Note:  Does not range-check these values, leaves that for sbus*() calls. */

    sa = aapl_num_from_hex(cp, &cp2, 2, 4);

    if (cp2 == cp)
    {
        cmd_error(aapl, result, "Invalid \"sbus\" command ignored: Arg 1 = <sa> must be 2-4 hex digits. Got: \"%s\".", cmd);
        return;
    }
    if (cp2 - cp == 4) new_chip = (sa & 0xf000) >> 12;
    if (cp2 - cp >= 3) new_ring = (sa & 0x0f00) >>  8;
    cp = cp2; SKIPSPACE(cp);

/* Parse <da>, <cmd>, <data> fields: */

    if (! (sbus_parse_da_cmd(aapl, cmd, &cp, &da,   2, "da",  result)
        && sbus_parse_da_cmd(aapl, cmd, &cp, &scmd, 3, "cmd", result)
        && ((reslen = sbus_parse_data(aapl, cmd, &cp, &data, &mask, result)))))
    {return;}

/* Check end of command line: */

    if (! check_term(aapl, cmd, cp, result)) return;
    if (new_chip < 0x10) *chip_nump = new_chip;
    if (new_ring < 0x10) *ring_nump = new_ring;

/* Forward the command for execution: */

    sa |= (*chip_nump << 12) | (*ring_nump << 8);  /* a no-op if just got new values. */

    data_out = ((scmd == 1 && mask != 0xffffffff) ? avago_sbus_rmw(aapl, sa, da, data, mask) :
                (scmd == 1)                       ? avago_sbus_wr( aapl, sa, da, data) :
                                                    avago_sbus(    aapl, sa, da, scmd, data, /* recv_data_back = */ 1));

    aapl_hex_2_bin(result, data_out, /* underscore_en = */ 0, /* bits */ 32);
    if (reslen == 8) strcpy(result, result + 24);  /* last "byte" only. */

} /* sbus_command() */


/* Input (cmd) is one of: */
/*      i2c r <addr> <num_bytes> [# <comment>] */
/*      i2c w <addr> <byte> [<byte>...] [# <comment>] */
/*      i2c wr <addr> <num_bytes> <byte> [<byte>...] [# <comment>] */
/*  Where <addr> and <byte> are 2 digit hex values, and */
/*        <num_bytes> is a decimal value. */
#if AAPL_ALLOW_I2C || AAPL_ALLOW_SYSTEM_I2C
static void i2c_command(Aapl_t *aapl, const char *cmd, const char *cp, char *result)
{
    typedef enum { cmd_read = 0, cmd_write, cmd_writeread} i2c_cmd_t;
    unsigned int i2c_address;  /* [in] Address of the sbus device */
    const char *cp2;
    unsigned char buffer[256];
    i2c_cmd_t command;
    int num_bytes_r = 0, num_bytes = 0;

    SKIPSPACE(cp);
    if( *cp == '\0' )
    {
BadI2cCommand:
        sprintf(result, "ERROR: Invalid \"i2c\" command ignored. Must be: "
        "\"i2c r <addr> <num_bytes> [# <comments>]\", "
        "\"i2c w <addr> <byte>[ <byte>...] [# <comments>]\", or "
        "\"i2c wr <addr> <num_bytes> <byte>[ <byte>...] [# <comments>]\". "
        "Got: \"%s\".", cmd);
        return;
    }

    /* Determine command type: */
    if(      (cp[0] == 'r' || cp[0] == 'R') && isspace(cp[1]) )
        command = cmd_read;
    else if( (cp[1] == 'r' || cp[1] == 'R') &&
             (cp[0] == 'w' || cp[0] == 'W') && isspace(cp[2]) )
    {
        cp++;
        command = cmd_writeread;
    }
    else if( (cp[0] == 'w' || cp[0] == 'W') && (isspace(cp[1]) || cp[1]=='\0') )
        command = cmd_write;
    else
    {
        sprintf(result, "ERROR: Invalid \"i2c\" command ignored. Arg 1 must be \"r\", \"w\", or \"wr\".  Got \"%s\".", cmd);
        return;
    }
    cp++; SKIPSPACE(cp);

    /* Parse address: */
    i2c_address = aapl_num_from_hex(cp, &cp2, 1, 2);
    if( cp2 == cp || i2c_address > 0x7f )
    {
        sprintf(result, "ERROR: Invalid \"i2c\" command ignored. Arg 2 must be a hex I2C address in the range 00..7f. Got: \"%s\".", cmd);
        return;
    }
    cp = cp2; SKIPSPACE(cp);

    if( *cp == '\0' )
        goto BadI2cCommand;

    if( command == cmd_read || command == cmd_writeread )
    {
        num_bytes_r = (int) aapl_strtol(cp, (char **)&cp2, 10);
        if( cp2 == cp || !(isspace(*cp2) || *cp2 == '\0') || num_bytes_r < 0 || num_bytes_r > (int)sizeof(buffer) )
        {
            sprintf(result, "ERROR: Invalid \"i2c %s\" command ignored. Arg 3 must be a number of bytes in the range 1..%d. Got: \"%s\".",
                            command==cmd_read ? "r" : "wr", (int)sizeof(buffer), cmd);
            return;
        }
        cp = cp2; SKIPSPACE(cp);
    }

    if( command == cmd_write || command == cmd_writeread )
    {
        while( *cp )
        {
            int value;
            if( num_bytes >= (int)sizeof(buffer) )
            {
                sprintf(result, "ERROR: Invalid \"i2c %s\" command ignored, too many bytes specified, limit is %d. Got: \"%s\".",
                                command==cmd_write ? "w" : "wr", (int)sizeof(buffer), cmd);
                return;
            }
            value = aapl_num_from_hex(cp, &cp2, 1, 2);
            if( cp2 == cp || value > 0xff )
            {
                sprintf(result, "ERROR: Invalid \"i2c %s\" command ignored. Arg %d must be a hex byte value in the range 00..ff. Got: \"%s\".",
                                command==cmd_write ? "w" : "wr", 3 + num_bytes, cmd);
                return;
            }
            cp = cp2; SKIPSPACE(cp);
            buffer[num_bytes++] = value;
        }
        if( num_bytes == 0 )
        {
            sprintf(result, "ERROR: Invalid \"i2c %s\" command ignored. "
                            "Must specify one or more bytes to send. "
                            "Invoke with no arguments for a usage summary.",
                                command==cmd_write ? "w" : "wr");
            return;
        }
    }

    if( command == cmd_write || command == cmd_writeread )
    {
        if( avago_i2c_write(aapl, i2c_address, num_bytes, buffer) < 0 )
        {
            sprintf(result, "ERROR: i2c command \"%s\" failed.", cmd);
            return;
        }
        if( command == cmd_write )
            sprintf(result, "Address 0x%02x, bytes written: %d.", i2c_address, num_bytes);
    }
    if( command == cmd_read || command == cmd_writeread )
    {
        int i;
        char *ptr = result;
        if( avago_i2c_read(aapl, i2c_address, num_bytes_r, buffer) < 0 )
        {
            sprintf(result, "ERROR: i2c command \"%s\" failed.", cmd);
            return;
        }
        for( i = 0; i < num_bytes_r; i++ )
            ptr += sprintf(ptr, "%02x ", buffer[i]);
        ptr[-1] = '\0';
    }
}
#endif /* AAPL_ALLOW_I2C || AAPL_ALLOW_SYSTEM_I2C */

#if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO
/* Commands: */
/*     mdio a port dev address  # Set read/write address */
/*     mdio w port dev data     # Write data to address */
/*     mdio r port dev          # Read data from address */
/*     mdio wait port dev       # Not sure what this does */
static void mdio_command(Aapl_t *aapl, const char *cmd, const char *cp, char *result)
{
    Avago_mdio_cmd_t mdio_cmd;
    uint port_addr, dev_addr, reg_addr = 0, data = 0;
    const char *cp2;
    char cmd_name[5] = "wait";

    if( !aapl->mdio_fn )
    {
        sprintf(result, "ERROR: no mdio implementation is available.");
        return;
    }

    SKIPSPACE(cp);
    if( *cp == '\0' )
    {
        sprintf(result, "ERROR: Invalid \"mdio\" command ignored. Must be: "
        "\"mdio a <port_addr> <dev_addr> <reg_addr> [# <comments>]\", "
        "\"mdio w <port_addr> <dev_addr> <reg_data> [# <comments>]\", "
        "\"mdio r <port_addr> <dev_addr> [# <comments>]\", "
        "\"mdio wait <port_addr> <dev_addr> [# <comments>]\", "
        "Got: \"%s\".", cmd);
        return;
    }

    /* Determine command type: */
    strncpy(cmd_name,cp,4);
    cmd_name[4] = '\0';
    if(      (cp[0] == 'a' || cp[0] == 'A') && isspace(cp[1]) ) mdio_cmd = AVAGO_MDIO_ADDR;
    else if( (cp[0] == 'w' || cp[0] == 'W') && isspace(cp[1]) ) mdio_cmd = AVAGO_MDIO_WRITE;
    else if( (cp[0] == 'r' || cp[0] == 'R') && isspace(cp[1]) ) mdio_cmd = AVAGO_MDIO_READ;
    else if( aapl_strncasecmp(cp,"wait ",5) == 0 ) { cp += 4;   mdio_cmd = AVAGO_MDIO_WAIT; }
    else
    {
        sprintf(result, "ERROR: Invalid \"mdio\" command ignored. Arg 1 must be \"a\", \"w\", \"r\" or \"wait\".  Got \"%s\".", cmd);
        return;
    }
    cp++; SKIPSPACE(cp);
    if( mdio_cmd != AVAGO_MDIO_WAIT )
        cmd_name[1] = '\0';

    /* Parse port: */
    port_addr = aapl_strtoul(cp, (char **)&cp2, 0);
    if( cp2 == cp || port_addr >= 256 )
    {
        sprintf(result, "ERROR: Invalid \"mdio %s\" command ignored. Arg 2 must be a numerical port value < 256. Got: \"%s\".", cmd_name, cmd);
        return;
    }
    cp = cp2; SKIPSPACE(cp);
    /* Parse device: */
    dev_addr = aapl_strtoul(cp, (char **)&cp2, 0);
    if( cp2 == cp || dev_addr >= 256 )
    {
        sprintf(result, "ERROR: Invalid \"mdio %s\" command ignored. Arg 3 must be a numerical device value < 256. Got: \"%s\".", cmd_name, cmd);
        return;
    }
    cp = cp2; SKIPSPACE(cp);
    if( mdio_cmd == AVAGO_MDIO_ADDR )
    {
        /* Parse address: */
        reg_addr = aapl_strtoul(cp, (char **)&cp2, 0);
        if( cp2 == cp )
        {
            sprintf(result, "ERROR: Invalid \"mdio a\" command ignored. Arg 4 must be a numerical address value. Got: \"%s\".", cmd);
            return;
        }
    }
    else if( mdio_cmd == AVAGO_MDIO_WRITE )
    {
        /* Parse data: */
        data = aapl_strtoul(cp, (char **)&cp2, 0);
        if( cp2 == cp || data > 0xffff )
        {
            sprintf(result, "ERROR: Invalid \"mdio w\" command ignored. Arg 4 must be a numerical data value < 0xffff. Got: \"%s\".", cmd);
            return;
        }
    }

    /* Execute command and return results: */
    sprintf(result, "%x", aapl->mdio_fn(aapl, mdio_cmd, port_addr, dev_addr, reg_addr, data));    /* avago_mdio_sbus_fn, avago_gpio_mdio_fn(). */
}
#endif /* AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO */

/*============================================================================= */
/* J T A G   C O M M A N D */
/* */
/* See command handling summary above. */
/* */
/*   jtag 32 02b6 0...  [#<comments>]  # one or more 0s. */
/* */
/* Forwards a JTAG command to the avago_jtag function for processing. */
/* Handles a "jtag 32 02b6 00" command (chip TAP ID).  This is a necessary */
/* special case, so a client can identify the ASIC.  Writes into result one of: */
/* */
/* - AAPL_CHIP_ID_OVERRIDE, if defined */
/* - else if AAPL_ALLOW_AACS, result of sending the command to the backend server */
/* - else an error message */

static void jtag_command(Aapl_t * aapl, const char * cmd, const char * cp, char * result, int * chip_nump)
{
    char *tdo = 0, *cp2 = 0;
    int opcode, bits;

    SKIPSPACE(cp);

    bits = aapl_strtol(cp, &cp2, 10);
    if (!bits || ISNUL(cp2)) goto BadJtagCmd;
    opcode = aapl_strtol(cp2, &cp2, 16);
    if (ISNUL(cp2)) goto BadJtagCmd;

    if (bits == 32 && opcode == 0x2b6)
        aapl_hex_2_bin(result, aapl->jtag_idcode[*chip_nump], 0, 32);
    else
    {
        char *buf;
        int length;
        SKIPSPACE(cp2);
        length = strlen(cp2);
        buf = (char *) aapl_malloc(aapl, bits+1, __func__);
        if( buf )
        {
#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
            if (strstr(cp2, "read"))
            {
                memset(buf, '0', bits+1); /* prefill with '0' (0x30) */
                tdo = avago_jtag_rd(aapl, opcode, bits);
            }
            else
#endif /* AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS */
            {
                memset(buf+length, '0', bits+1-length); /* prefill with '0' (0x30) */
                memcpy(buf, cp2, length);  /* copy the buffer over in case the user didn't specify all the bits */
                tdo = avago_jtag(aapl, opcode, bits, buf);
            }
            if (tdo) snprintf(result, AACS_SERVER_BUFFERS, "%s", tdo);
            else result[0] = 0;
            aapl_free(aapl, buf, __func__);
        }
    }
    return;

    BadJtagCmd:
    cmd_error(aapl, result, "Unsupported \"jtag\" command ignored. Format should be \"jtag <bits> <opcode> <ascii binary data>\". Got: \"%s\".", cmd);
}


#if AAPL_ENABLE_MAIN
static void cli_command(Aapl_t * aapl, const char * cmd, const char * cp, char * result)
{
    char *argv[100];
    char argv_buf[100][100];
    int argc = 0, length = 0;
    (void) cmd; /* cp used instead */

    SKIPSPACE(cp);

    strcpy(argv_buf[argc], "aapl"); /* set argv[0] to "aapl" -- ie the "program" being called */
    argv[argc] = argv_buf[argc];
    argc++;

    while (1)
    {
        if (!cp[0]) length = 0;
        else if (strchr(cp, ' ')) length = strchr(cp, ' ') - cp;
        else length = strlen(cp);

        if (length < 0) length = strlen(cp);
        if (!length) break;

        strncpy(argv_buf[argc], cp, length); /* copy argument */
        argv_buf[argc][length] = 0; /* terminate the string */
        argv[argc] = argv_buf[argc]; /* set argv pointer to the string we found */
        argc++;
        cp += length;
        SKIPSPACE(cp);
    }

    /*for (int x = 0; x<argc; x++) printf("## argv[%d]: %s\n", x, argv[x]); */
    aapl->enable_debug_logging = 1;
    aapl_log_clear(aapl);
    aapl_close_connection(aapl);
    aapl_main(argc, argv, aapl);
    snprintf(result, AACS_SERVER_BUFFERS, "%s\n", aapl->log);
    return;
}
#endif /* AAPL_ENABLE_MAIN */

#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
/** Private function used by avago_jtag_scan and avago_jtag_rd */
/** Copied from aapl_core.c. aapl_core.c wants this function to be static for performance. */
static AAPL_INLINE char avago_bit_banged_jtag(Aapl_t *aapl, uint cycles, BOOL tms, BOOL tdi, BOOL trst_l, BOOL get_tdo)
{
    if (aapl->aacs) /* check for AACS communication mode */
    {
        char buf[64];

        snprintf(buf, 63, "jtag_cycle %u %d %d %d", cycles, tms, tdi, trst_l); /* cycles tms tdi trst */
        avago_aacs_send_command(aapl, buf);
        return aapl->data_char[0];
    }
    else
    {
        if (!aapl->bit_banged_jtag_fn)
        {
            aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Bit banged JTAG function function not registered.\n");
            return 0x30; /* return '0' */
        }
        while (cycles > 1) /* note: when doing multiple cycles, we only return the last tdo bit (avago_jtag_scan never looks at TDO when cycles > 1) */
        {
            aapl->bit_banged_jtag_fn(aapl, tms, tdi, trst_l, 0);
            cycles--;
        }
        return aapl->bit_banged_jtag_fn(aapl, tms, tdi, trst_l, get_tdo) + 0x30; /* get last bit */
    }
}
#endif /* AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS */

#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
/*============================================================================= */
/* JTAG CYCLE */
/* */
/* jtag_cycle <cycles> <tms> <tdi> <trst_l> */
/* */
static void jtag_cycle_command(Aapl_t * aapl, const char * cmd, const char * cp, char * result)
{
    char *cp2;
    uint cycles, tms, tdi, trst_l;

    cycles = aapl_strtol(cp, &cp2, 10);
    if (ISNUL(cp2)) goto jtag_cycle_error;
    tms = aapl_strtol(cp2, &cp2, 10);
    if (ISNUL(cp2)) goto jtag_cycle_error;
    tdi = aapl_strtol(cp2, &cp2, 10);
    if (ISNUL(cp2)) goto jtag_cycle_error;
    trst_l = aapl_strtol(cp2, &cp2, 10);

    result[0] = 0;
    result[1] = 0;
    if (!check_term(aapl, cmd, cp2, result))
    {
        jtag_cycle_error:
        cmd_error(aapl, result, "Invalid command ignored. Command must be of format: jtag_cycle <cycles> <tms> <tdi> <trst_l>. Got: \"%s\".", cmd);
    }
    else
    {
        aapl->prev_opcode = 0; /* clear previous opcode */
        result[0] = avago_bit_banged_jtag(aapl, cycles, tms, tdi, trst_l, 1);
    }
}
#endif /* AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS */

/*============================================================================= */
/* C H I P S   C O M M A N D */
/* */
/* See command handling summary above. */
/* */
/*   chips [#<comments>] */
/* */
/* Writes into result an error message or the number of ASICs in the TAP loop */
/* (aapl->chips). */

static void chips_command(Aapl_t * aapl, const char * cmd, const char * cp, char * result)
{
    if (check_term(aapl, cmd, cp, result))
        sprintf(result, "%d", aapl->chips);
}

/*============================================================================= */
/* C H I P N U M   C O M M A N D */
/* */
/* See command handling summary above. */
/* */
/*   chipnum [#<comments>] */
/* */
/* Writes into result an error message, the present chip number 0..f (see */
/* "sbus" above), or with an argument, sets and returns the number, but only */
/* within the valid range 0 .. (aapl->chips - 1). */

static void chipnum_command(Aapl_t * aapl, const char * cmd, const char * cp, char * result, int * chip_nump)
{
    const char *cp2;
    uint num;

    SKIPSPACE(cp);
    if (ISEOL(cp)) {sprintf(result, "%d", *chip_nump); return;}

    cp2 = cp;
    num = aapl_num_from_hex(cp, &cp2, 1, 1);

    if (cp2 == cp)
        cmd_error(aapl, result, "Invalid \"chipnum\" command ignored: Parameter must be a single hex digit. Got: \"%s\".", cmd);
    else if (num >= aapl->chips)
        cmd_error(aapl, result, "Invalid \"chipnum\" command ignored: Max chip number is 0x%x. Got: \"%s\".", aapl->chips - 1, cmd);
    else {*chip_nump = num; result[0] = *cp; result[1] = '\0';}
    aapl_set_chip(aapl, *chip_nump); /* to make sure we set chip and clear opcode */
}

/*============================================================================= */
/* SET PTR */
/* */
/* Allows user to set integer pointer passed in */
/* */
/*   <cmd_name> [val] [#<comments>] */
/* */
/*   If val is not present, return the current value of the pointer, otherwise */
/*   set the pointer to <val> */
/* */
static void set_uint(Aapl_t * aapl, const char * cmd, const char * cp, uint * ptr, char * result)
{
    char *cp2;
    uint num;

    SKIPSPACE(cp);
    if (ISEOL(cp)) {snprintf(result, AACS_SERVER_BUFFERS, "%d", *ptr); return;}

    num = aapl_strtol(cp, &cp2, 0);

    if (!cp2)
        cmd_error(aapl, result, "Invalid command ignored: Parameter must be a single integer. Got: \"%s\".", cmd);
    else
    {
        *ptr = num;
        snprintf(result, AACS_SERVER_BUFFERS, "%d", *ptr);
    }
}

/*============================================================================= */
/* SBUS RESET COMMAND */
/* */
/* Perform a hard SBus reset */
/* */
/*   sbus_reset <addr> */
/* */
static void sbus_reset_command(Aapl_t * aapl, const char * cmd, const char * cp, char * result)
{
    /*const char *cp2; */
    uint addr;

    SKIPSPACE(cp);
    if (ISEOL(cp)) goto sbus_reset_error;

    if (!aapl_str_to_addr(cp, 0, &addr)) goto sbus_reset_error; /* convert first parameter from a string to an SBus address */
    cp = strchr(cp, ' '); /* move cp pointer past address */

    if (!check_term(aapl, cmd, cp, result))     /* Flag an error if there's more */
    {
        sbus_reset_error:
        cmd_error(aapl, result, "Invalid \"sbus_reset\" command ignored: Parameter must be a valid address. Got: \"%s\".", cmd);
    }
    else
    {
        avago_sbus_reset(aapl, addr, 1);
        snprintf(result, AACS_SERVER_BUFFERS, "Hard SBus reset executed to address %s.", aapl_addr_to_str(addr));
    }
}

#if AAPL_ENABLE_ATE_VEC
/* Usage: ate_vec ate_test_vector_string */
static void ate_vec_command(Aapl_t *aapl, const char *cmd, const char *cp, char *result)
{
    if( !aapl->ate_vec_fn )
        cmd_error(aapl, result, "An ate_vec function is not registered.");
    else
    {
        SKIPSPACE(cp);
        if( ISEOL(cp) )
            cmd_error(aapl, result, "Invalid \"ate_vec\" command ignored: Parameter required. Got: \"%s\".", cmd);
        else
        {
            int ret = aapl->ate_vec_fn(aapl, cp);
            snprintf(result, AACS_SERVER_BUFFERS, ret == 0 ? "PASS" : "FAIL");
        }
    }
}
#endif
/*============================================================================= */
/* SLEEP COMMAND */
/* */
/* Sleeps for specified number of seconds */
/* */
/*   sleep <seconds>[.<fraction>] */
/* */
static void sleep_command(Aapl_t * aapl, const char * cmd, const char * cp, char * result)
{
    char *cp2 = 0;
    int num;

    SKIPSPACE(cp);

    /* cp points to an ascii floating point seconds value to convert to ms: */
    num = aapl_strtol(cp, &cp2, 10); /* Convert seconds portion. */
    num *= 1000;                /* Convert that to milliseconds. */
    if( *cp2 == '.' )           /* Add any fractional part. */
    {
        char *cp3 = ++cp2;
        int num2 = aapl_strtol(cp3, &cp2, 10);
        int len = cp2-cp3;
        for( ; len > 3; len-- ) num2 = (num2 + 5) / 10; /* Truncate to milliseconds, with rounding */
        for( ; len < 3; len++ ) num2 *= 10;             /* Expand to milliseconds. */
        num += num2;
    }
    if( *cp2 != '\0' || num < 0 || *cp == '-' )
        cmd_error(aapl, result, "Invalid \"sleep\" command ignored: Parameter must be a (non-negative) number of seconds (int or decimal). Got: \"%s\".", cmd);
    else
    {
#if AAPL_ALLOW_AACS
        avago_aacs_flush(aapl);
#endif /* AAPL_ALLOW_AACS */
        ms_sleep(num);
        snprintf(result, AACS_SERVER_BUFFERS, "Slept %d.%03d seconds.",num/1000,num%1000);
    }
}

/*============================================================================= */
/* SBUS MODE COMMAND */
/* */
/* Allows user to check and set aapl->communication_method */
/* */
static void sbus_mode_command(Aapl_t * aapl, const char * cmd, const char * cp, char * result)
{
    const char *cp2;
    Aapl_comm_method_t comm_method;
    (void)cmd;

    SKIPSPACE(cp);
    if (ISEOL(cp)) {snprintf(result, AACS_SERVER_BUFFERS, "%s", aapl_comm_method_to_str(aapl->communication_method)); return;}

    cp2 = cp;

    if( aapl_str_to_comm_method(cp2,&comm_method) )
    {
        aapl->communication_method = comm_method;
        snprintf(result, AACS_SERVER_BUFFERS, "sbus_mode set to %s.", cp2);
    }
    else snprintf(result, AACS_SERVER_BUFFERS, "sbus_mode option must be {AACS}_{I2C|MDIO|SBUS|JTAG|BB_JTAG}|SYSTEM_{I2C|MDIO}|GPIO_MDIO|OFFLINE\n");
}

#if AAPL_ENABLE_DIAG
/*============================================================================= */
/* DIAG COMMAND */
/* */
/* Allows remote user to run local diagnostics */
/* */
static void diag_command(Aapl_t * aapl, const char * cmd, const char * cp, char * result)
{
    char *cp2;
    uint addr;

    SKIPSPACE(cp);
    if (ISEOL(cp)) goto diag_cmd_error;

    if (EQCN(cp, "size", 4))
    {
        cp += 4;
        if (!check_term(aapl, cmd, cp, result)) goto diag_cmd_error;    /* Flag an error if there's more */
        snprintf(result, AACS_SERVER_BUFFERS, "%u", (uint)sizeof(Avago_diag_config_t));
        return;
    }

    aapl_str_to_addr(cp, 0, &addr); /* convert first parameter from a string to an SBus address */
    cp = strchr(cp, ' '); /* move cp pointer past address */

    if (!check_term(aapl, cmd, cp, result))     /* Flag an error if there's more */
    {
        diag_cmd_error:
        cmd_error(aapl, result, "Invalid \"diag\" command ignored. Should be: diag [size | <addr>]. Got: \"%s\".", cmd);
        return;
    }

    aapl_log_clear(aapl); /* clear the AAPL log, then run commands, then send the gathered log */

    /* local context */
    {
        Avago_diag_config_t *config  = avago_diag_config_construct(aapl);
        if( config )
        {
            size_t index;
            for (index = 0; index < (sizeof(Avago_diag_config_t) - 2*sizeof(int))/sizeof(BOOL); index++)
            {
                int num;
                if (!cp) break;
                num = aapl_strtoul(cp, &cp2, 0); /* get next parameter */
                if (cp != cp2) *((char *)config + index) = num; /* if there was a parameter, set it in the struct */
                cp = cp2;
                /*printf("%d %x\n", index, *((char *)config + index)); */
            }

            avago_diag(aapl, addr, config);
            avago_diag_config_destruct(aapl, config);
        }
    }

    aapl_str_rep(aapl->log, 0xa, 0x2);
    aapl->aacs_server_buffer = (char *) aapl_realloc(aapl, aapl->aacs_server_buffer, strlen(aapl->log) + AACS_SERVER_BUFFERS, __func__);
    if( aapl->aacs_server_buffer )
        snprintf(aapl->aacs_server_buffer, strlen(aapl->log) + AACS_SERVER_BUFFERS, "%c%c%s", 0x1, 0x1, aapl->log);
}
#endif /* AAPL_ENABLE_DIAG */

/*============================================================================= */
/* SPICO INT COMMAND */
/* */
/* Call the avago_spico_int subroutine */
/* */
/*   spico_int <addr> <int> <param> */
/* */
/*   <addr> is the SBus address (include chip, ring, lane) */
/*   <int> and <param> are the SPICO interrupt and value (user must provide base prefix, if desired) */
/* */
static void spico_int_command(Aapl_t * aapl, const char * cmd, const char * cp, char * result)
{
    char *cp2;
    uint interrupt, param, addr;

    SKIPSPACE(cp);
    if (ISEOL(cp)) goto spico_int_error;

    aapl_str_to_addr(cp, 0, &addr); /* convert first parameter from a string to an SBus address */
    cp = strchr(cp, ' '); /* move cp pointer past address */

    if (!cp) goto spico_int_error;
    SKIPSPACE(cp);
    if (ISEOL(cp)) goto spico_int_error;
    interrupt = aapl_strtoul(cp, &cp2, 0);

    cp = cp2;
    SKIPSPACE(cp);
    if (ISEOL(cp)) goto spico_int_error;
    param  = aapl_strtoul(cp, &cp2, 0);

    cp = cp2;
    if (!check_term(aapl, cmd, cp, result))     /* Flag an error if there's more */
    {
        spico_int_error:
        cmd_error(aapl, result, "Invalid \"spico_int\" command ignored. Should be: spico_int <addr> <int> <param>. Got: \"%s\".", cmd);
        return;
    }
    snprintf(result, AACS_SERVER_BUFFERS, "%x", avago_spico_int(aapl, addr, interrupt, param));
}

/*============================================================================= */
/* V E R S I O N   C O M M A N D */
/* */
/* See command handling summary above. */
/* */
/*   version [#<comments>] */

static void version_command(Aapl_t *aapl, const char * cmd, const char * cp, char * result)
{
    if (check_term(aapl, cmd, cp, result))
        snprintf(result, AACS_SERVER_BUFFERS, "AAPL AACS server %s", AAPL_VERSION);
}

/*============================================================================= */
/* S T A T U S   C O M M A N D */
/* */
/* See command handling summary above. */
/* */
/*   status [#<comments>] */

#if AAPL_ENABLE_HS2 && AAPL_ENABLE_FILE_IO
static void run_system_cmd(const char *cmd, char *data)
{
        FILE *fp;
        char * data_ptr = data; /* point to the char * passed in */
        fp = popen(cmd, "r");
        if (fp != NULL) 
        {
            while (fgets(data_ptr, sizeof(data), fp) != NULL)  /* put some characters into data_ptr (which is pointing at the end of char * data) */
                data_ptr = data + strlen(data); /* move pointer to end of characters just added */
            data[strlen(data)-1] = 0; /* remove newline */
        }
        pclose(fp);
}
#endif /* AAPL_ENABLE_HS2 && AAPL_ENABLE_FILE_IO */


static void status_command(Aapl_t *aapl, const char * cmd, const char * cp, char ** result)
{
    if (check_term(aapl, cmd, cp, *result))
    {
        char *result_end = *result;
        int size = AACS_SERVER_BUFFERS;

#if AAPL_ENABLE_HS2 && AAPL_ENABLE_FILE_IO
        char data[1024];
        data[0] = 0; /* make data a valid string */
        run_system_cmd("/bin/cat /home/pi/hs2-*.txt", data);
        aapl_str_rep(data, 0xa, ';');
        aapl_buf_add(aapl, result, &result_end, &size, "%s;", data);

        run_system_cmd("/bin/date", data);
        aapl_buf_add(aapl, result, &result_end, &size, "Updated:              %s;", data);
        run_system_cmd("/usr/bin/uptime", data);
        aapl_buf_add(aapl, result, &result_end, &size, "Uptime:               %s;", data);
#endif /* AAPL_ENABLE_HS2 && AAPL_ENABLE_FILE_IO */

#if AAPL_ENABLE_AACS_SERVER
        aapl_buf_add(aapl, result, &result_end, &size, "Locked by client:     %s;", inet_ntoa(client_IPaddr_lock[0].sin_addr));
        aapl_buf_add(aapl, result, &result_end, &size, "Locked by client:     %s;", inet_ntoa(client_IPaddr_lock[1].sin_addr));
        aapl_buf_add(aapl, result, &result_end, &size, "Cmd client IP addr:   %s;", inet_ntoa(client_IPaddr.sin_addr));
#endif /* AAPL_ENABLE_AACS_SERVER */

        aapl_buf_add(aapl, result, &result_end, &size, "Version:              AAPL %s;", AAPL_VERSION);
#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
        aapl_buf_add(aapl, result, &result_end, &size, "Current chip:         %d (of 0..%d);", aapl->curr_chip, aapl->chips-1);
#endif /* AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS */
        if (aapl->chips)
        {
            uint chip = 0;
            for (chip = 0; chip <= aapl->chips - 1; chip++)
            {
                aapl_buf_add(aapl, result, &result_end, &size, "Chip %d:               0x%08x ", chip, aapl->chip_name[chip]);
                if (aapl->chip_name[chip]) aapl_buf_add(aapl, result, &result_end, &size, "(%s);", aapl->chip_name[chip]);
                else                       aapl_buf_add(aapl, result, &result_end, &size, ";");
            }
        }
        aapl_buf_add(aapl, result, &result_end, &size, "SBus rings:           %d;", aapl->sbus_rings);
        aapl_buf_add(aapl, result, &result_end, &size, "TAP generation:       %d;", avago_get_tap_gen(aapl));
        aapl_buf_add(aapl, result, &result_end, &size, "Communication method: %s;", aapl_comm_method_to_str(aapl->communication_method));
        aapl_buf_add(aapl, result, &result_end, &size, "Debug level:          %d;", aapl->debug);
        aapl_buf_add(aapl, result, &result_end, &size, "Verbose level:        %d;", aapl->verbose);
        aapl_buf_add(aapl, result, &result_end, &size, "Suppress errors:      %d;", aapl->suppress_errors);
        aapl_buf_add(aapl, result, &result_end, &size, "Upgrade warnings:     %d;", aapl->upgrade_warnings);
        aapl_buf_add(aapl, result, &result_end, &size, "Serdes int timeout    %d;", aapl->serdes_int_timeout);
        aapl_buf_add(aapl, result, &result_end, &size, "TCK delay:            %d;", aapl->tck_delay);
        aapl_buf_add(aapl, result, &result_end, &size, "Error count:          %d;", aapl->errors);
        aapl_buf_add(aapl, result, &result_end, &size, "Warning count:        %d;", aapl->warnings);
        aapl_buf_add(aapl, result, &result_end, &size, "Max commands buffered:%d;", aapl->max_cmds_buffered);
        aapl_buf_add(aapl, result, &result_end, &size, "Capabilities:         %d;", aapl->capabilities);
        aapl_buf_add(aapl, result, &result_end, &size, "Client cmds received: %d (sbus %d);", aapl->commands, aapl->sbus_commands);
        aapl_buf_add(aapl, result, &result_end, &size, "AACS Server buf size: %d;", AACS_SERVER_BUFFERS);
        aapl_buf_add(aapl, result, &result_end, &size, "Data_char size:       %d;", aapl->data_char_size);
        aapl_buf_add(aapl, result, &result_end, &size, "Log size:             %d;", aapl->log_size);
        if (aapl->aacs_server) aapl_buf_add(aapl, result, &result_end, &size, 
                                                        "Remote AACS server:   %s:%d;", aapl->aacs_server, aapl->tcp_port);
    }
}

/*============================================================================= */
/* NULL COMMAND */
/* */
/* Do nothing. This is used for commands that we want to accept, but not error on */
/* */
static void null_command(Aapl_t *aapl, const char * cmd, const char * cp, char * result)
{
    (void)aapl;
    (void)cmd;
    (void)cp;
    if (cp[0] == '#') result[0] = 0; /* send nothing back */
    else              snprintf(result, AACS_SERVER_BUFFERS, "Unimplemented command.");
}


#if AAPL_ALLOW_AACS
/*============================================================================= */
/* M Y   S E N D   C O M M A N D */
/* */
/* See command handling summary above. */
/* */
/*   send <anything> [#<comments>] */
/* */
/* Sends anything on the command line after "send" to the back-end server, and */
/* writes into result the command response (truncated at AACS_SERVER_BUFFERS). */

static void my_send_command(Aapl_t * aapl, const char * cmd, const char * cp, char * result)
{
      (void)cmd;
      SKIPSPACE(cp);

/* TBD:  This special case is only needed until avago_aacs_send_command() can handle an */
/* empty command: */

      if (ISNUL(cp)) {result[0] = '\0'; return;}

      strncpy(result, avago_aacs_send_command(aapl, cp), AACS_SERVER_BUFFERS);
      result[AACS_SERVER_BUFFERS - 1] = '\0';
}
#endif /* AAPL_ALLOW_AACS */

/*============================================================================= */
/* H E L P   C O M M A N D */
/* */
/* See command handling summary above. */
/* */
/*   help [#<comments>] */
/* */
/* Writes into result an error string or RES_HELP. */

static void help_command(Aapl_t *aapl, const char * cmd, const char * cp, char * result)
{
    if (check_term(aapl, cmd, cp, result)) strcpy(result, RES_HELP);
}

static void commands_command(Aapl_t *aapl, const char * cmd, const char * cp, char * result)
{
    if (check_term(aapl, cmd, cp, result))
        snprintf(result, AACS_SERVER_BUFFERS, "%d (sbus %d)", aapl->commands, aapl->sbus_commands);
}

/*============================================================================= */
/* C L O S E   C O M M A N D */
/* */
/* See command handling summary above. */
/* */
/*   close [#<comments>] */
/* */
/* Writes into result an error string or RES_CLOSE. */

static void close_command(Aapl_t *aapl, const char * cmd, const char * cp, char * result)
{
    if (check_term(aapl, cmd, cp, result)) strcpy(result, RES_CLOSE);
}

/*============================================================================= */
/* E X I T   C O M M A N D */
/* */
/* See command handling summary above. */
/* */
/*   exit [#<comments>] */
/* */
/* Writes into result an error string or RES_EXIT. */

static void exit_command(Aapl_t *aapl, const char * cmd, const char * cp, char * result)
{
    if (check_term(aapl, cmd, cp, result))
        strcpy(result, RES_EXIT);
}

#if AAPL_ENABLE_FILE_IO
static void log_dump_command(Aapl_t *aapl, const char * cmd, const char * cp, char * result)
{
    FILE *file;
    (void) aapl;
    (void) cmd;

    SKIPSPACE(cp);
    file = fopen(cp, "w+");
    if (file)
    {
        snprintf(result, AACS_SERVER_BUFFERS, "%d bytes AAPL log written to %s and then cleared.", (int) strlen(aapl->log), cp);
        fprintf(file, "%s\n", aapl_log_get(aapl));
        fclose(file);
        aapl_log_clear(aapl);
    }
    else
        cmd_error(aapl, aapl->aacs_server_buffer, "Not able to open file %s to dump log to.", cp);
}
#endif /* AAPL_ENABLE_FILE_IO */

#if AAPL_ALLOW_AACS && AAPL_ENABLE_AACS_SERVER
static void lock_command(Aapl_t *aapl, const char * cmd, const char * cp, char * result)
{
    (void) aapl;
    (void) cmd;
    (void) cp;
    client_IPaddr_lock[1].sin_addr.s_addr = client_IPaddr_lock[0].sin_addr.s_addr;
    client_IPaddr_lock[0].sin_addr.s_addr = client_IPaddr.sin_addr.s_addr;
    snprintf(result, AACS_SERVER_BUFFERS, "Locked to %s.", inet_ntoa(client_IPaddr_lock[0].sin_addr));
}

static void allow_command(Aapl_t *aapl, const char * cmd, const char * cp, char * result)
{
    struct hostent *server = NULL;
    (void) aapl;
    (void) cmd;
    (void) cp;

    SKIPSPACE(cp);
    server = gethostbyname(cp);
    if( server == NULL )
    {
        snprintf(result, AACS_SERVER_BUFFERS, "Unable to determine IP address to lock to.");
        return;
    }

    client_IPaddr_lock[1].sin_addr.s_addr = client_IPaddr_lock[0].sin_addr.s_addr;
    client_IPaddr_lock[0].sin_addr.s_addr = client_IPaddr.sin_addr.s_addr;
    memmove((char *)&client_IPaddr_lock[0].sin_addr.s_addr, (char *)server->h_addr_list[0], server->h_length);
    snprintf(result, AACS_SERVER_BUFFERS, "Locked to %s.", inet_ntoa(client_IPaddr_lock[0].sin_addr));
}

static void unlock_command(Aapl_t *aapl, const char * cmd, const char * cp, char * result)
{
    (void) aapl;
    (void) cmd;
    (void) cp;
    client_IPaddr_lock[0].sin_addr.s_addr = 0;
    client_IPaddr_lock[1].sin_addr.s_addr = 0;
    snprintf(result, AACS_SERVER_BUFFERS, "Unlocked.");
}
#endif /* AAPL_ALLOW_AACS && AAPL_ENABLE_AACS_SERVER */


/*============================================================================= */
/* P R O C E S S   C M D */
/* */
/* Given: */
/* */
/* - aapl info pointer */
/* - command string read from a socket (any trailing CR/NL already removed) */
/* - pointers to chip_num and ring_num values to use/modify */
/* */
/* Process the string as an AACS server command, one of a limited subset of */
/* commands understood by the old Perl server and the newer HW server (HS1, */
/* PS1, PC1); see RES_HELP for a list, and *_command() for syntax summaries. */
/* */
/* Returns a newline-terminated response string in all cases, including error */
/* messages, including empty string for empty, RES_CLOSE for "close", or */
/* RES_EXIT for "exit" commands.  The result lives in static memory overwritten */
/* by the next call. */

char *avago_aacs_process_cmd(
    Aapl_t *aapl,       /**< [in] */
    const char *cmd,    /**< [in] */
    int *chip_nump,     /**< [in/out] */
    int *ring_nump)     /**< [in/out] */
{
    int errors, warnings, rc;
    const char *cp = cmd;
    int x = 0;
    int y = 0;
    if (!chip_nump) chip_nump = &x;
    if (!ring_nump) ring_nump = &y;

    /* aapl->aacs_server_buffer is used to store the results */
    /* aapl->data_char holds the incoming commands */
    if (!aapl->aacs_server_buffer ) aapl->aacs_server_buffer = (char *) aapl_malloc(aapl, AACS_SERVER_BUFFERS, __func__);
    if( !aapl->aacs_server_buffer ) return NULL;
    SKIPSPACE(cp);

    if (strchr(cmd, ';')) /* ";" is the command seperator */
    {
        char next_cmd[AACS_SERVER_BUFFERS];
        int result_index = 0;
        char result_buf[AACS_SERVER_BUFFERS];

        const char * index;
        const char * remaining_cmd;
        int first_cmd = 0;

        remaining_cmd = cmd;
        do
        {
            const char *result;
            index = strchr(remaining_cmd, ';');
            if (index) strncpy(next_cmd, remaining_cmd, index - remaining_cmd); /* isolate the first command */
            else       strncpy(next_cmd, remaining_cmd, strlen(remaining_cmd)+1); /* isolate the first command */
            if (index) next_cmd[index-remaining_cmd] = 0; /* terminate string */
            remaining_cmd = index + 1; /* move past ";" */

            result = avago_aacs_process_cmd(aapl, next_cmd, chip_nump, ring_nump); /* send one command */
            if( !result ) continue;

            if (!first_cmd++) result_index += snprintf(result_buf + result_index, AACS_SERVER_BUFFERS, "%s", result);  /* print first command's results into result_buf */
            else              result_index += snprintf(result_buf + result_index, AACS_SERVER_BUFFERS, ";%s", result); /* add ";" and then add result */
        } while (index);

        strncpy(aapl->aacs_server_buffer, result_buf, AACS_SERVER_BUFFERS); /* result needs to be moved to aacs_server_buffer */
        return aapl->aacs_server_buffer;
    }

    aapl->commands++;
    rc = aapl->return_code;
    errors = aapl->errors;
    warnings = aapl->warnings;

    if (cp[0] == '@') cp++;

#if AAPL_ALLOW_AACS && AAPL_ENABLE_AACS_SERVER /* locking not allowed when not a server */
    if ((client_IPaddr_lock[0].sin_addr.s_addr || client_IPaddr_lock[1].sin_addr.s_addr)  /* are one of the locks active? */
        && !(   (client_IPaddr_lock[0].sin_addr.s_addr && client_IPaddr_lock[0].sin_addr.s_addr == client_IPaddr.sin_addr.s_addr)  /* does the current IP address match either lock address? */
             || (client_IPaddr_lock[1].sin_addr.s_addr && client_IPaddr_lock[1].sin_addr.s_addr == client_IPaddr.sin_addr.s_addr))
        && (   strstr(cmd, "version") == 0
            && strstr(cmd, "unlock") == 0
            && strstr(cmd, "lock") == 0
            && strstr(cmd, "close") == 0
            && strstr(cmd, "status") == 0
            && strstr(cmd, "allow") == 0))  /* and is the command not any allowed commands? */
    {
        char lock0[64], lock1[64];
        lock0[0] = 0;
        lock1[0] = 0; /* terminate strings */

        if ((client_IPaddr_lock[0].sin_addr.s_addr)) snprintf(lock0, 64, "%s", inet_ntoa(client_IPaddr_lock[0].sin_addr));
        if ((client_IPaddr_lock[1].sin_addr.s_addr)) snprintf(lock1, 64, "%s", inet_ntoa(client_IPaddr_lock[1].sin_addr));

        cmd_error(aapl, aapl->aacs_server_buffer, "AACS server is currently locked by %s%s%s. Command(s) ignored.", lock0, lock1[0] ? " and " : "", lock1);
        goto end; /* prevents need for else for all the commands below */
    }
#endif /* AAPL_ALLOW_AACS && AAPL_ENABLE_AACS_SERVER */

    if      (ISCMD(cp, "sbus",        4)) sbus_command(       aapl, cmd, cp + 4, aapl->aacs_server_buffer, chip_nump, ring_nump);
    else if (cp[0] == '#'               ) null_command(       aapl, cmd, cp    , aapl->aacs_server_buffer);
#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
    else if (ISCMD(cp, "jtag_cycle", 10)) jtag_cycle_command( aapl, cmd, cp +10, aapl->aacs_server_buffer);
#endif /* AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS */
    else if (ISCMD(cp, "jtag",        4)) jtag_command(       aapl, cmd, cp + 4, aapl->aacs_server_buffer, chip_nump);
    else if (ISCMD(cp, "chip",        4)) jtag_command(       aapl, cmd, "32 02b6 0", aapl->aacs_server_buffer, chip_nump);
    else if (ISCMD(cp, "chips",       5)) chips_command(      aapl, cmd, cp + 5, aapl->aacs_server_buffer);
    else if (ISCMD(cp, "chipnum",     7)) chipnum_command(    aapl, cmd, cp + 7, aapl->aacs_server_buffer, chip_nump);
    else if (ISCMD(cp, "version",     7)) version_command(    aapl, cmd, cp + 7, aapl->aacs_server_buffer);
    else if (ISCMD(cp, "status",      6)) status_command (    aapl, cmd, cp + 6, &aapl->aacs_server_buffer);
#if AAPL_ALLOW_I2C || AAPL_ALLOW_SYSTEM_I2C
    else if (ISCMD(cp, "i2c",         3)) i2c_command(        aapl, cmd, cp + 3, aapl->aacs_server_buffer);
#endif /* AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS */
#if AAPL_ALLOW_MDIO || AAPL_ALLOW_GPIO_MDIO
    else if (ISCMD(cp, "mdio",        4)) mdio_command(       aapl, cmd, cp + 4, aapl->aacs_server_buffer);
#endif
    else if (ISCMD(cp, "sbus_mode",   9)) sbus_mode_command(  aapl, cmd, cp + 9, aapl->aacs_server_buffer);
    else if (ISCMD(cp, "spico_int",   9)) spico_int_command(  aapl, cmd, cp + 9, aapl->aacs_server_buffer);
    else if (ISCMD(cp, "sleep",       5)) sleep_command(      aapl, cmd, cp + 5, aapl->aacs_server_buffer);
    else if (ISCMD(cp, "sbus_reset", 10)) sbus_reset_command( aapl, cmd, cp +10, aapl->aacs_server_buffer);
#if AAPL_ENABLE_ATE_VEC
    else if (ISCMD(cp, "ate_vec",     7)) ate_vec_command(    aapl, cmd, cp + 7, aapl->aacs_server_buffer);
#endif
#if AAPL_ENABLE_DIAG
    else if (ISCMD(cp, "diag",        4)) diag_command(       aapl, cmd, cp + 4, aapl->aacs_server_buffer);
#endif
#if AAPL_ALLOW_AACS
    else if (ISCMD(cp, "send",        4)) my_send_command(    aapl, cmd, cp + 4, aapl->aacs_server_buffer); /* strip off "send" and send the rest of the command along */
    else if (ISCMD(cp, "reset",       5)) my_send_command(    aapl, cmd, cp    , aapl->aacs_server_buffer); /* send along unchanged */
    else if (ISCMD(cp, "set_sbus",    8)) my_send_command(    aapl, cmd, cp    , aapl->aacs_server_buffer); /* send along unchanged */
#endif
#if AAPL_ALLOW_AACS && AAPL_ENABLE_AACS_SERVER
    else if (ISCMD(cp, "allow",       5)) allow_command(      aapl, cmd, cp + 5, aapl->aacs_server_buffer);
    else if (ISCMD(cp, "lock",        4)) lock_command(       aapl, cmd, cp + 4, aapl->aacs_server_buffer);
    else if (ISCMD(cp, "unlock",      6)) unlock_command(     aapl, cmd, cp + 6, aapl->aacs_server_buffer);
#else
    else if (ISCMD(cp, "send",        4)) null_command(       aapl, cmd, cp + 4, aapl->aacs_server_buffer); /* ignore */
    else if (ISCMD(cp, "reset",       5)) null_command(       aapl, cmd, cp    , aapl->aacs_server_buffer); /* ignore */
    else if (ISCMD(cp, "set_sbus",    8)) null_command(       aapl, cmd, cp    , aapl->aacs_server_buffer); /* ignore */
#endif /* AAPL_ALLOW_AACS && AAPL_ENABLE_AACS_SERVER */
    else if (ISCMD(cp, "null",        4)) null_command(       aapl, cmd, cp + 4, aapl->aacs_server_buffer);
    else if (ISCMD(cp, "help",        4)) help_command(       aapl, cmd, cp + 4, aapl->aacs_server_buffer);
    else if (ISCMD(cp, "set_debug",   9)) set_uint(           aapl, cmd, cp + 9, &aapl->debug,      aapl->aacs_server_buffer);
    else if (ISCMD(cp, "tck_delay",   9)) set_uint(           aapl, cmd, cp + 9, &aapl->tck_delay,  aapl->aacs_server_buffer);
    else if (ISCMD(cp, "close",       5)) close_command(      aapl, cmd, cp + 5, aapl->aacs_server_buffer);
    else if (ISCMD(cp, "exit",        4)) exit_command(       aapl, cmd, cp + 4, aapl->aacs_server_buffer);
#if AAPL_ENABLE_FILE_IO
    else if (ISCMD(cp, "log_dump",    8)) log_dump_command(   aapl, cmd, cp + 8, aapl->aacs_server_buffer);
#endif /* AAPL_ENABLE_FILE_IO */
    else if (ISCMD(cp, "commands",    8)) commands_command(   aapl, cmd, cp + 8, aapl->aacs_server_buffer);
#if AAPL_ENABLE_MAIN
    else if (ISCMD(cp, "cli",         3)) cli_command(        aapl, cmd, cp + 3, aapl->aacs_server_buffer);
#endif /* AAPL_ENABLE_MAIN */
    else if (ISNUL(cp)) aapl->aacs_server_buffer[0] = '\0';
    else if ((cp[0] >= '0' && cp[0] <= '9') || (cp[0] >= 'a' && cp[0] <= 'f') || (cp[0] >= 'A' && cp[0] <= 'F')) /* if the line starts with [0-9a-fA-F] then assume it is an SBus command */
    {
        const char *cp2;
        aapl_num_from_hex(cp, &cp2, 2, 4); /* is it a "real" hex input? */
        if (cp2 != cp)                    sbus_command(       aapl, cmd, cp + 0, aapl->aacs_server_buffer, chip_nump, ring_nump);
        else cmd_error(aapl, aapl->aacs_server_buffer, "Unrecognized command ignored: \"%s\".", cmd);
    }
    else cmd_error(aapl, aapl->aacs_server_buffer, "Unrecognized command ignored: \"%s\".", cmd);

#if AAPL_ALLOW_AACS && AAPL_ENABLE_AACS_SERVER /* locking not allowed when not a server */
    end:
#endif /* AAPL_ALLOW_AACS && AAPL_ENABLE_AACS_SERVER */
#if AAPL_ALLOW_JTAG || AAPL_ALLOW_AACS
    aapl->curr_chip = *chip_nump; /* so low level AAPL functions know what chip we're communicating with */
#endif

    if (cmd[0] == '@') aapl->aacs_server_buffer[0] = 0; /* don't send result if @ present */

/* Check for anomaly: */

    if (rc != aapl->return_code || errors != aapl->errors || warnings != aapl->warnings)
    {
        char result_buf[256]; /* need a seperate buffer here since result is the source and the destination for cmd_error() */
        strncpy(result_buf, aapl->aacs_server_buffer, 255);
        /* Send the command failed message along with the result which is prepended with ASCII 0x1 0x1 0x1, so that the client can identify where in the string the answer lies. */
        cmd_error(aapl, aapl->aacs_server_buffer, "Command failed: \"%s\". Error: \"%s\". Result => %s %s", cmd, aapl->last_err, "\x1\x1\x1", result_buf);
    }

    return aapl->aacs_server_buffer;
}
#endif /* AAPL_ENABLE_MAIN || AAPL_ENABLE_AACS_SERVER */


#if AAPL_ENABLE_AACS_SERVER
static void update_server_status(Aapl_t *aapl, int *chip_num, int *ring_num)
{
    #if AAPL_ENABLE_HS2
    FILE *file = fopen("/var/www/html/server_status.htm", "w+");
    if (file)
    {
        char *result = avago_aacs_process_cmd(aapl, "status", chip_num, ring_num);
        if( result )
        {
            aapl_str_rep(result, ';', 0xa);
            fprintf(file, "<pre>\n%s\n", result);
        }
        fclose(file);
    }
    #else
    (void) aapl;
    (void) chip_num;
    (void) ring_num;
    #endif /* AAPL_ENABLE_HS2 */
}


/** @brief   Starts an AACS Server and listens for requests. */
/** @details Starts (and restarts after closure) an AACS server that accepts one TCP/IP */
/** connection on tcp_port, receives zero or more AACS commands, forwards them */
/** to avago_sbus_wr(), etc, and returns response text to the command client. */
/** */
/** The caller must first: */
/** */
/** - Open a lower-level (back end) connection or whatever else is required for */
/**   avago_sbus_wr(), etc to function, such as by using aapl_connect() (but not */
/**   necessarily this function in the end user context). */
/** */
/** - Start a process or thread that's taken over by this function, which only */
/**   returns upon "exit" or internal error. */
/** */
/** Note:  Unlike the HW server (HS1, etc), this process does not support */
/** command batching.  It expects just one command => response at a time. */
/** */
/** @return Returns FALSE for internal error logged, or TRUE for client "exit" command. */
/** Does not return for client command anomalies or "close" commands. */
/** */

int avago_aacs_server_options(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    int tcp_port,       /**< [in] Port of remote to connect to. */
    const char *ats_server_host,
    uint ats_server_host_port,
    BOOL close_connection) /**< [in] If true aapl_close_connection will be called when the client connection is closed */
{
    int chip_num = 0;  /* selected for SBus; 0 .. (aapl->chips - 1). */
    int ring_num = 0;  /* which SBus ring within the current chip. */
    int error_or_exit = 0;
    int return_status = 0;
    int rc = 1, rc_ts = 1;
    int fd_socket, fd_socket_ts = -1;
    int return_code = 0;
    Aapl_t * aapl_ats_server_host = NULL;
    struct sockaddr_in sai, sai_ts;  /* INET socket info. */
    Aapl_t *aapl_server = aapl_construct();
    socklen_t addr_len = sizeof(client_IPaddr);
    socklen_t addr_len_ts = sizeof(client_IPaddr_ts);

    if( !aapl_server ) return 0;

    #if AAPL_ALLOW_THREAD_SUPPORT && AAPL_ENABLE_HS2
    {
        Aapl_server_cntl_t server_cntl;
        server_cntl.aapl_upstream = aapl_server;
        server_cntl.aapl_downstream = aapl;
        if (!aapl->telnet_thread) pthread_create(&aapl->telnet_thread, NULL, &aapl_telnet_thread, (void *)&server_cntl);
    }
    #endif /* AAPL_ALLOW_THREAD_SUPPORT && AAPL_ENABLE_HS2 */

    client_IPaddr_lock[0].sin_addr.s_addr = 0;
    client_IPaddr_lock[1].sin_addr.s_addr = 0; /* clear locks */

    # ifdef WIN32
    {
        WSADATA wsaData;
        WORD vers_req = MAKEWORD(2,2);
        WSAStartup(vers_req,&wsaData);
    }
    # endif

    /* INITIALIZE:  Open TCP socket to command client: */

    fd_socket = socket(PF_INET, SOCK_STREAM, 0);
    fd_socket_ts = socket(PF_INET, SOCK_STREAM, 0);
    if( fd_socket < 0 || fd_socket_ts < 0 )
    {
        aapl_fail(aapl, __func__, __LINE__, "Cannot create PF_INET socket: %s.\n", aapl_tcp_strerr());
        goto cleanup_and_exit;
    }

    /* Set socket option to allow immediate reuse; otherwise it usually remains */
    /* unavailable (bind() fails) in TCP/IP TIME_WAIT status for a long time. */
    rc = setsockopt(fd_socket, SOL_SOCKET, SO_REUSEADDR, (char *) &rc, sizeof(rc));
    rc_ts = setsockopt(fd_socket_ts, SOL_SOCKET, SO_REUSEADDR, (char *) &rc_ts, sizeof(rc_ts));

    /* SO_KEEPALIVE triggers eventual cleanup of a dead connection which */
    /* otherwise would hang indefinitely. */
    rc = rc_ts = 1;
    rc = setsockopt(fd_socket, SOL_SOCKET, SO_KEEPALIVE, (char *) &rc, sizeof(rc));
    rc_ts = setsockopt(fd_socket_ts, SOL_SOCKET, SO_KEEPALIVE, (char *) &rc_ts, sizeof(rc_ts));

    if( rc < 0 || rc_ts < 0 )
    {
        aapl_fail(aapl, __func__, __LINE__, "Cannot setsockopt(SO_REUSEADDR) on socket %d: %s.\n", fd_socket, aapl_tcp_strerr());
        goto cleanup_and_exit;
    }

    if (ats_server_host) /* connecting to a remote ATS server. Setup an Aapl_t for it -- we'll connect later */
    {
        aapl_log_printf(aapl, AVAGO_INFO, __func__, 0, "Attempting to connect to remote AACS ATS server: %s:%d.\n", ats_server_host, ats_server_host_port);
        aapl_ats_server_host = aapl_construct();
        aapl_ats_server_host->debug = aapl->debug;
        aapl_ats_server_host->disable_reconnect = 1; /* don't allow AAPL to auto-reconnect, as we must handle the connection here */
    }
    else /* bind and listen for AACS server (and ATS server if applicable) */
    {
        sai.sin_family      = AF_INET;
        sai.sin_addr.s_addr = INADDR_ANY;
        sai.sin_port        = htons(tcp_port);

        if ((rc = bind(fd_socket, (struct sockaddr *) &sai, sizeof (sai))) < 0)
        {
            aapl_fail(aapl, __func__, __LINE__, "Cannot bind() AF_INET socket for clients on port %d: %s.\n", tcp_port, aapl_tcp_strerr());
            goto cleanup_and_exit;
        }

        if ((rc = listen(fd_socket, /* backlog = */ 1)) < 0)
        {
            aapl_fail(aapl, __func__, __LINE__, "Cannot listen() for command client on port %d: %s.\n", tcp_port, aapl_tcp_strerr());
            goto cleanup_and_exit;
        }

        if (!ats_server_host && ats_server_host_port) /* start an ATS server */
        {
            int queries;
            char buffer[128];
            sai_ts.sin_family      = AF_INET;
            sai_ts.sin_addr.s_addr = INADDR_ANY;
            sai_ts.sin_port        = htons(ats_server_host_port);

            if ((rc = bind(fd_socket_ts, (struct sockaddr *) &sai_ts, sizeof (sai_ts))) < 0)
            {
                aapl_fail(aapl, __func__, __LINE__, "Cannot bind() AF_INET socket for clients on port %d: %s.\n", ats_server_host_port, aapl_tcp_strerr());
                goto cleanup_and_exit;
            }

            if ((rc = listen(fd_socket_ts, /* backlog = */ 1)) < 0)
            {
                aapl_fail(aapl, __func__, __LINE__, "Cannot listen() for command client on port %d: %s.\n", ats_server_host_port, aapl_tcp_strerr());
                goto cleanup_and_exit;
            }
            aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "AAPL ATS server version %s is now listening for TCP connections on port %d...\n", AAPL_VERSION, ats_server_host_port);

            /* set aapl->socket to the incoming connection. */
            /* We will first act like a server, and they'll send some queries to discover information about us. */
            /* When that is complete, we'll then start acting like a client. */
            aapl->socket = accept(fd_socket_ts, (struct sockaddr *) &client_IPaddr_ts, &addr_len_ts);
            aapl->disable_reconnect = 1; /* don't allow AAPL to auto-reconnect, as we must handle the connection here */

            aapl->aacs_server = (char *) aapl_realloc(aapl, aapl->aacs_server, 32, __func__);
            if( aapl->aacs_server )
                strncpy(aapl->aacs_server, "(remote AAPL ATS server)", 32);
            aapl->tcp_port = 0; /* this is an incoming connection */
            strncpy(aapl->data_char, "", 3);

            aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "AAPL ATS server is now connected on port %d.\n", ats_server_host_port);

            /* the remote side will send these commands when they start as part of their capability check. Since they are really the server, */
            /* we must act like a server for these two commands and respond appropriately. See aapl_check_capabilities() for more info. */
            snprintf(buffer, 128, "AAPL AACS server %s in ATS mode", AAPL_VERSION);
            avago_aacs_send_command(aapl, buffer);              /* response for version command */
            avago_aacs_send_command_options(aapl, "ok", 1, 10); /* response for number of queries to expect */
            queries = aapl->data;
            strncpy(buffer, RES_HELP, 128);
            if (queries >= 2) avago_aacs_send_command(aapl, buffer); /* response for help command */
            if (queries >= 3) avago_aacs_send_command(aapl, "0");    /* response for diag size command */

            /* now we officially treat the client as a server. All future commands will be sent to the remote server (which is in client mode), */
            /* as if it were a "standard" AACS server in. */
            aapl_check_capabilities(aapl);
            aapl_get_ip_info(aapl, 0);
            aapl_close_connection(aapl);
        }
        aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "AAPL AACS server version %s is now listening for TCP connections on port %d...\n", AAPL_VERSION, tcp_port);
    }

    /* OUTER LOOP:  Await connections from command clients: */
    /* */
    /* The accept() function blocks until a command client requests a connection, */
    /* then returns a new socket fd for communicating with the client. */
    while( !error_or_exit )
    {
        update_server_status(aapl, &chip_num, &ring_num);

        if (ats_server_host) /* connect to a remote translation server */
        {
            aapl_connect(aapl_ats_server_host, ats_server_host, ats_server_host_port);
            aapl_server->socket = aapl_ats_server_host->socket; /* the "incoming" socket will be what we just connected to */
            if( aapl_server->socket < 0 ) aapl_fail(aapl, __func__, __LINE__, "Cannot connect to remote ATS server %s:%d.\n", ats_server_host, ats_server_host_port, aapl_tcp_strerr());
        }
        else /* wait for a remote connection */
        {
            aapl_server->socket = accept(fd_socket, (struct sockaddr *) &client_IPaddr, &addr_len);
            if( aapl_server->socket < 0 ) aapl_fail(aapl, __func__, __LINE__, "Cannot accept() for command client on port %d: %s.\n", tcp_port, aapl_tcp_strerr());
        }

        if( aapl_server->socket < 0 )
        {
            error_or_exit = 1;  /* Cleanup and exit */
            break;
        }

        if (ats_server_host) aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Connection to remote AACS ATS server %s:%d (socket %d) successful.\n", ats_server_host, ats_server_host_port, aapl_server->socket);
        else                 aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Connection accepted from %s:%d (socket %d).\n", inet_ntoa(client_IPaddr.sin_addr), tcp_port, aapl_server->socket);

        if (!(ats_server_host || ats_server_host_port)) /* if we're not a ATS server connect to device now */
        {
            return_code = aapl->return_code;
            aapl_connect(aapl, 0, 0);
            if( return_code != aapl->return_code )
            {
                aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "aapl_connect failed.\n");
                break;
            }
        }

#       if 0
        /* This clause updates info on every connection. */
        /* Disable to get info only once at startup: */
        return_code = aapl->return_code;
        aapl_get_ip_info(aapl, /* chip_reset */ 0);
        if( return_code != aapl_get_return_code(aapl) )
        {
            aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "aapl_get_ip_info returned a negative value.\n");
            break;
        }
#       endif

        update_server_status(aapl, &chip_num, &ring_num);

        /* INNER LOOP:  Read commands until internal error, EOF, "close", or "exit": */
        /* */
        /* Note:  Assume no command over AACS_SERVER_BUFFERS - 1 bytes, otherwise it gets fragmented and misparsed. */
        for(;;)  /* until break or return: */
        {
            char *cmd;
            int read_len = 0;
            int send_len = 0;
            char *result;
            size_t res_len;

            read_len = aapl_recv(aapl_server);
            cmd = aapl_server->data_char;

            if (read_len < 0)
            {
                #ifdef WIN32
                if( WSAGetLastError() == WSAECONNRESET)
                #else
                if( errno == ECONNRESET )
                #endif
                     aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "could not read from socket %d on port %d (%d: %s)\n", aapl->socket, tcp_port, read_len, aapl_tcp_strerr());
                else
                {
                    aapl_fail(aapl, __func__, __LINE__, "could not read from socket %d on port %d (%d: %s).\n", aapl->socket, tcp_port, read_len, aapl_tcp_strerr());
                    error_or_exit = 1;  /* Cleanup and exit */
                }
                break;
            }

            /* EOF:  Normal socket closure by the client (rather than through "close" */
            /* command) results in read_len == 0, otherwise there's normally at least a newline: */
            if( 0 == read_len )
            {
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Server got EOF on port %d.\n", tcp_port);
                break;  /* inner loop only. */
            }

            /* Terminate command string; remove CR/NL if any (at least a newline is usually */
            /* present); then process the command: */
            if ((read_len >= 1) && (cmd[read_len - 1] == '\n')) --read_len;
            if ((read_len >= 1) && (cmd[read_len - 1] == '\r')) --read_len;
            cmd[read_len] = '\0';

            if (!ats_server_host && ats_server_host_port && aapl->socket < 0) /* we're an ATS host that has lost the connection, wait for a reconnection */
            {
                aapl_close_connection(aapl);
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "AAPL ATS server lost connection with client. Waiting for new connection on port %d...\n", ats_server_host_port); aapl->socket = accept(fd_socket_ts, (struct sockaddr *) &client_IPaddr_ts, &addr_len_ts); if (aapl_connection_status(aapl) < 0)
                {
                    aapl_close_connection(aapl);
                    aapl->socket = accept(fd_socket_ts, (struct sockaddr *) &client_IPaddr_ts, &addr_len_ts);
                }
                aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "AAPL ATS server is now connected on port %d (socket %d).\n", ats_server_host_port, aapl->socket);
                aapl_get_ip_info(aapl, 0);
            }

            result = avago_aacs_process_cmd(aapl, cmd, &chip_num, &ring_num);
            if( !result ) continue;

            aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "%s => %s\n", cmd, result);

            res_len = strlen(result);
            result[res_len++] = '\n';  /* append a newline. */

            send_len = aapl_send(aapl_server, result, res_len, tcp_port);
            if (send_len < 0) {error_or_exit = 1; break;}

            /* Handle special cases: */
            if( 0 == strncmp(result, RES_CLOSE, 5) )
                break;  /* inner loop only. */
            if( 0 == strncmp(result, RES_EXIT, 4) )
            {
                error_or_exit = 1;
                return_status = 1;
                break;
            }
        } /* inner loop:  client commands. */

        if (close_connection) aapl_close_connection(aapl);
        if (ats_server_host) aapl_close_connection(aapl_ats_server_host);
        else closesocket(aapl_server->socket);
    } /* outer loop:  new connections. */

cleanup_and_exit:
    closesocket(fd_socket);
    aapl_destruct(aapl_server);
    return return_status;

} /* avago_aacs_server_options() */

/** @brief   Starts an AACS Server and listens for requests. */
/** @details Starts (and restarts after closure) an AACS server that accepts one TCP/IP */
/** connection on tcp_port, receives zero or more AACS commands, forwards them */
/** to avago_sbus_wr(), etc, and returns response text to the command client. */
/** */
/** The caller must first: */
/** */
/** - Open a lower-level (back end) connection or whatever else is required for */
/**   avago_sbus_wr(), etc to function, such as by using aapl_connect() (but not */
/**   necessarily this function in the end user context). */
/** */
/** - Start a process or thread that's taken over by this function, which only */
/**   returns upon "exit" or internal error. */
/** */
/** Note:  Unlike the HW server (HS1, etc), this process does not support */
/** command batching.  It expects just one command => response at a time. */
/** */
/** @return Returns FALSE for internal error logged, or TRUE for client "exit" command. */
/** Does not return for client command anomalies or "close" commands. */
/** */
int avago_aacs_server(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    int tcp_port)       /**< [in] Port of remote to connect to. */
{
    return avago_aacs_server_options(aapl, tcp_port, NULL, 0, TRUE);
}

#if AAPL_ALLOW_THREAD_SUPPORT && AAPL_ENABLE_HS2
void *aapl_telnet_thread(void *server_cntl_in)
{
    int error_or_exit = 0;
    int rc = 1;
    int fd_socket;
    struct sockaddr_in sai;  /* INET socket info. */
    int tcp_port = 23;

    Aapl_server_cntl_t *server_cntl = (Aapl_server_cntl_t *) server_cntl_in;
    /*Aapl_t *aapl = server_cntl->aapl_downstream; */
    Aapl_t *aapl_telnet_server = aapl_construct();
    Aapl_t *aapl = aapl_telnet_server;
    /* aapl_telnet_server is the incoming telnet connection */
    /* aapl is the downstream connection to the part (and what is normally used for logging) */
    /* server_cntl->aapl_downstream is the same as aapl */
    /* server_cntl->aapl_upstream is the client AACS connection (if any) */

    struct sockaddr_in telnet_IPaddr;
    socklen_t addr_len = sizeof(telnet_IPaddr);

    # ifdef WIN32
    {
        WSADATA wsaData;
        WORD vers_req = MAKEWORD(2,2);
        WSAStartup(vers_req,&wsaData);
    }
    # endif

    /* INITIALIZE:  Open TCP socket to command client: */
    fd_socket = socket(PF_INET, SOCK_STREAM, 0);
    if( fd_socket < 0 )
    {
        aapl_fail(aapl, __func__, __LINE__, "Cannot create PF_INET socket: %s.\n", aapl_tcp_strerr());
        return 0;
    }

    /* Set socket option to allow immediate reuse; otherwise it usually remains */
    /* unavailable (bind() fails) in TCP/IP TIME_WAIT status for a long time. */
    rc = setsockopt(fd_socket, SOL_SOCKET, SO_REUSEADDR, (char *) &rc, sizeof(rc));

    /* SO_KEEPALIVE triggers eventual cleanup of a dead connection which */
    /* otherwise would hang indefinitely. */
    rc = setsockopt(fd_socket, SOL_SOCKET, SO_KEEPALIVE, (char *) &rc, sizeof(rc));

    if( rc < 0 )
    {
        aapl_fail(aapl, __func__, __LINE__, "Cannot setsockopt(SO_REUSEADDR) on socket %d: %s.\n", fd_socket, aapl_tcp_strerr());
        goto cleanup_and_exit;
    }

    /* bind and listen for AACS server (and ATS server if applicable) */
    sai.sin_family      = AF_INET;
    sai.sin_addr.s_addr = INADDR_ANY;
    sai.sin_port        = htons(tcp_port);

    if ((rc = bind(fd_socket, (struct sockaddr *) &sai, sizeof (sai))) < 0)
    {
        aapl_fail(aapl, __func__, __LINE__, "Cannot bind() AF_INET socket for clients on port %d: %s.\n", tcp_port, aapl_tcp_strerr());
        goto cleanup_and_exit;
    }

    if ((rc = listen(fd_socket, /* backlog = */ 1)) < 0)
    {
        aapl_fail(aapl, __func__, __LINE__, "Cannot listen() for command client on port %d: %s.\n", tcp_port, aapl_tcp_strerr());
        goto cleanup_and_exit;
    }
    aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "AAPL telnet server version %s is now listening for TCP connections on port %d...\n", AAPL_VERSION, tcp_port);

    /* OUTER LOOP:  Await connections from command clients: */
    /* */
    /* The accept() function blocks until a command client requests a connection, */
    /* then returns a new socket fd for communicating with the client. */
    while( !error_or_exit )
    {
        int send_len;
        int size = 1024;
        char *data = (char *) aapl_malloc(aapl, size, __func__);
        char *data_end = data;

        /* wait for a remote connection */
        aapl_telnet_server->socket = accept(fd_socket, (struct sockaddr *) &telnet_IPaddr, &addr_len);
        if( aapl_telnet_server->socket < 0 )
        {
            aapl_fail(aapl, __func__, __LINE__, "Cannot accept() for command client on port %d: %s.\n", tcp_port, aapl_tcp_strerr());
            error_or_exit = 1;  /* Cleanup and exit */
            break;
        }
        aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "Connection accepted from %s:%d (socket %d).\n", inet_ntoa(telnet_IPaddr.sin_addr), tcp_port, aapl_telnet_server->socket);

        aapl_buf_add(aapl, &data, &data_end, &size, "===============================================================================\n");
        aapl_buf_add(aapl, &data, &data_end, &size, "AAPL Telnet Server. AAPL version %s\n\n", AAPL_VERSION);
        aapl_buf_add(aapl, &data, &data_end, &size, "close, c, q            close this telnet connection\n");
        aapl_buf_add(aapl, &data, &data_end, &size, "k                      Kill any current AACS server connections\n");
        aapl_buf_add(aapl, &data, &data_end, &size, "lock, y                Kill any connections, then lock.\n");
        aapl_buf_add(aapl, &data, &data_end, &size, "unlock, u, t           Unlock HS2\n");
        aapl_buf_add(aapl, &data, &data_end, &size, "reboot, r              Reboot HS2\n");
        aapl_buf_add(aapl, &data, &data_end, &size, "exit                   Terminate AACS server (will normally restart)\n");
        aapl_buf_add(aapl, &data, &data_end, &size, "===============================================================================\n");
        send_len = aapl_send(aapl_telnet_server, data, strlen(data), tcp_port);
        if (send_len < 0) {error_or_exit = 1; break;}

        /* INNER LOOP:  Read commands until internal error, EOF, "close", or "exit": */
        /* Note:  Assume no command over AACS_SERVER_BUFFERS - 1 bytes, otherwise it gets fragmented and misparsed. */
        for(;;)  /* until break or return: */
        {
            char *cmd;
            int read_len;

            data_end = data;
            aapl_buf_add(aapl, &data, &data_end, &size, "\nHS2] ");
            send_len = aapl_send(aapl_telnet_server, data, strlen(data), tcp_port);
            if (send_len < 0) {error_or_exit = 1; break;}

            read_len = aapl_recv(aapl_telnet_server);
            cmd = aapl_telnet_server->data_char;

            if (read_len < 0)
            {
                #ifdef WIN32
                if( WSAGetLastError() == WSAECONNRESET)
                #else
                if( errno == ECONNRESET )
                #endif
                     aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "could not read from socket %d on port %d (%d: %s)\n", aapl->socket, tcp_port, read_len, aapl_tcp_strerr());
                else
                {
                    aapl_fail(aapl, __func__, __LINE__, "could not read from socket %d on port %d (%d: %s).\n", aapl->socket, tcp_port, read_len, aapl_tcp_strerr());
                    error_or_exit = 1;  /* Cleanup and exit */
                }
                break;
            }

            /* EOF:  Normal socket closure by the client (rather than through "close" */
            /* command) results in read_len == 0, otherwise there's normally at least a newline: */
            if( 0 == read_len )
            {
                aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Server got EOF on port %d.\n", tcp_port);
                break;  /* inner loop only. */
            }

            /* Terminate command string; remove CR/NL if any (at least a newline is usually */
            /* present); then process the command: */
            if ((read_len >= 1) && (cmd[read_len - 1] == '\n')) --read_len;
            if ((read_len >= 1) && (cmd[read_len - 1] == '\r')) --read_len;
            cmd[read_len] = '\0';

            if (cmd[0] == (char)0xff && strstr(cmd, "#")) cmd = strstr(cmd, "#") + 1;
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, " %d on port %d (%d: %s)\n", aapl->socket, tcp_port, read_len, aapl_tcp_strerr());

            data[0] = 0;
            if      (strstr(cmd, "close") || 
                    (strlen(cmd) == 1 && cmd[0] == 'c') || 
                    (strlen(cmd) == 1 && cmd[0] == 'q') ) break;
            /*else if (strstr(cmd, "status")  || (strlen(cmd) == 1 && cmd[0] == 's')) */
            /*{ */
            /*    status_command(aapl_telnet_server, "status", "status", &data); */
            /*} */
            else if (strstr(cmd, "unlock") || 
                    (strlen(cmd) == 1 && cmd[0] == 'u') || 
                    (strlen(cmd) == 1 && cmd[0] == 't') ) 
            {
                client_IPaddr_lock[0].sin_addr.s_addr = 0;
                client_IPaddr_lock[1].sin_addr.s_addr = 0;
                snprintf(data, 128, "Unlocked.\n");
            }
            else if (strstr(cmd, "lock") || 
                    (cmd[0] == 'y')) 
            {
                shutdown(server_cntl->aapl_upstream->socket, SHUT_RDWR);
                server_cntl->aapl_upstream->socket = 0;
                snprintf(data, 128, "Closing AAPL AACS server socket %d.\n", server_cntl->aapl_upstream->socket);
                send_len = aapl_send(aapl_telnet_server, data, strlen(data), tcp_port);
                if (send_len < 0) {error_or_exit = 1; break;}

                client_IPaddr_lock[0].sin_addr.s_addr = 0; /* clear second lock */
                client_IPaddr_lock[1].sin_addr.s_addr = 0; /* clear second lock */
                if (strlen(cmd) == 1) 
                    client_IPaddr_lock[0].sin_addr.s_addr = telnet_IPaddr.sin_addr.s_addr; /* no ip address specified, use the client's IP address */
                else 
                {
                    struct hostent *server = NULL;
                    server = gethostbyname(strstr(cmd, " ")+1);
                    if (server) memmove((char *)&client_IPaddr_lock[0].sin_addr.s_addr, (char *)server->h_addr_list[0], server->h_length);
                    else
                    {
                        snprintf(data, 128, "Not able to determine IP address from %s.\n", strstr(cmd, " ")+1);
                        send_len = aapl_send(aapl_telnet_server, data, strlen(data), tcp_port);
                        if (send_len < 0) {error_or_exit = 1; break;}
                    }
                }
                snprintf(data, 128, "Locked to %s.\n", inet_ntoa(client_IPaddr_lock[0].sin_addr));
            }
            else if (strstr(cmd, "reboot") || 
                    (strlen(cmd) == 1 && cmd[0] == 'r')) 
            {
                snprintf(data, 128, "Rebooting now.\n");
                send_len = aapl_send(aapl_telnet_server, data, strlen(data), tcp_port);
                if (send_len < 0) {error_or_exit = 1; break;}

                aapl->destroy_thread = 1;
                aapl_destruct(server_cntl->aapl_upstream);
                aapl_destruct(server_cntl->aapl_downstream);
                aapl_destruct(aapl_telnet_server);
                system("sudo shutdown -r now");
                exit(0);
            }
            else if (strlen(cmd) == 1 && cmd[0] == 'k')
            {
                shutdown(server_cntl->aapl_upstream->socket, SHUT_RDWR);
                server_cntl->aapl_upstream->socket = 0;
                snprintf(data, 128, "Closing AAPL AACS server socket %d.\n", server_cntl->aapl_upstream->socket);
            }
            else if (strstr(cmd, "exit")) 
            {
                snprintf(data, 128, "Exiting.\n");
                send_len = aapl_send(aapl_telnet_server, data, strlen(data), tcp_port);
                if (send_len < 0) {error_or_exit = 1; break;}

                aapl->destroy_thread = 1;
                aapl_destruct(server_cntl->aapl_upstream);
                aapl_destruct(server_cntl->aapl_downstream);
                aapl_destruct(aapl_telnet_server);
                exit(0);
            }
            else snprintf(data, 128, "Unknown command received: %s (%d)\n", cmd, (int)strlen(cmd));

            send_len = aapl_send(aapl_telnet_server, data, strlen(data), tcp_port);
            if (send_len < 0) {error_or_exit = 1; break;}
        } /* inner loop:  client commands. */
        closesocket(aapl_telnet_server->socket);
    }
cleanup_and_exit:
    closesocket(fd_socket);
    aapl_destruct(aapl_telnet_server);
    return NULL;
}
#endif /* AAPL_ALLOW_THREAD_SUPPORT && AAPL_ENABLE_HS2 */

#endif /* AAPL_ENABLE_AACS_SERVER */
