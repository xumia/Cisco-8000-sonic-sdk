/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/** Doxygen File Header */
/** @file */
/** @brief Functions for logging SAS/SATA link training. */

/* BACKGROUND: This file was cloned from kr_logger.c, which looks like it was cloned */
/* from dfe_logger.c.  Thus there are a number of code sections that might not apply */
/* to sas. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

void internal_serdes_dfe_tune_logger(Aapl_t *aapl, unsigned int sbus_addr, const char *tablefile);

/* TODO: refactor check pikes dynamically? */
#define PIKES
#ifdef PIKES
/* PIKES needs to use error_2 instead of tc_cntr_val per Jeff S. */
#define TC_CNTR    "error_hi_2"
#define TC_CNTR_HI "error_hi_2"
#define TC_CNTR_LO "error_lo_2"
#else
#define TC_CNTR    "tc_cntr_val"
#define TC_CNTR_HI "tc_cntr_val_hi"
#define TC_CNTR_LO "tc_cntr_val_lo"
#endif

#if AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO
static const char *sas_logger_dmem_labels[] =
{
  "pmd_state",          /* 00 */
  "pmd_rx_eq_state",    /* 01 */
  "dfe_state",          /* 02 */
  "dme_encode_2",       /* 03 */
  "dme_encode_1",       /* 04 */
  "dme_decode_1",       /* 05 */
  "dme_decode_0",       /* 06 */
  "pmd_km1",            /* 07 */
  "pmd_k0",             /* 08 */
  "pmd_kp1",            /* 09 */
  "pmd_rx_eq_tap_done", /* 10 */
  "pmd_control",        /* 11 */
  "dme_control",        /* 12 */
  "pmd_config",         /* 13 */
  "pmd_status",         /* 14 */
  "pmd_16g_cntl",       /* 15 */
  "pmd_16g_status",     /* 16 */
  "pmd_adj_req2",       /* 17 */
  "error_hi",           /* 18 */
  "error_lo",           /* 19 */
  "err_cnt_p0_hi",      /* 20 */
  "err_cnt_p0_lo",      /* 21 */
  "err_cnt_p1_hi",      /* 22 */
  "err_cnt_p1_lo",      /* 23 */
#if 0 /* carry over from kr_logger/dfe_logger */
  "corr_errs_hi",       /* 24 */
  "corr_errs_lo",       /* 25 */
  "gainC",              /* 26 */
/*  "gainD",            // 20 */
  "dvos_d0e_hi",        /* 26 */
  "dvos_d0e_lo",        /* 27 */
  "dvos_d0o_hi",        /* 28 */
  "dvos_d0o_lo",        /* 29 */
  "dvos_d1e_hi",        /* 30 */
  "dvos_d1e_lo",        /* 31 */
  "dvos_d1o_hi",        /* 32 */
  "dvos_d1o_lo",        /* 33 */
  "dvos_t1e_0_hi",      /* 34 */
  "dvos_t1e_0_lo",      /* 35 */
  "dvos_t1o_0_hi",      /* 36 */
  "dvos_t1o_0_lo",      /* 37 */
  "dvos_t1e_1_hi",      /* 38 */
  "dvos_t1e_1_lo",      /* 39 */
  "dvos_t1o_1_hi",      /* 40 */
  "dvos_t1o_1_lo",      /* 41 */
  "d6_tap_loops",       /* 42 */
  "d6_pCal_loop_count", /* 43 */
  "cal_timer_hi",       /* 44 */
  "PFD",                /* 45 */
  "min_errors_hi",      /* 46 */
  "min_errors_lo",      /* 47 */
  "error_hi",           /* 48 */
  "error_lo",           /* 49 */
  TC_CNTR_HI,           /* 50 */
  TC_CNTR_LO,           /* 51 */
  "compare_clk_sel",    /* 52 */
  "compare_mask",       /* 53 */
  "compare",            /* 54 */
  "compare_enable",     /* 55 */
  "bestDC",             /* 56 */
  "bestLF",             /* 57 */
  "bestHF",             /* 58 */
  "bestT1P0",           /* 59 */
  "bestT1P1",           /* 60 */
  "bestEyeP0",          /* 61 */
  "bestEyeP1",          /* 62 */
  "startDC",            /* 63 */
  "stopDC",             /* 64 */
  "stepDC",             /* 65 */
  "startLF",            /* 66 */
  "stopLF",             /* 67 */
  "stepLF",             /* 68 */
  "startHF",            /* 69 */
  "stopHF",             /* 70 */
  "stepHF",             /* 71 */
# endif
  "pmd_tx_init_km1_value",           /* 24 */
  "pmd_tx_ref2_km1_value",           /* 25 */
  "pmd_tx_noeq_km1_value",           /* 26 */
  "pmd_tx_init_k0_value",            /* 27 */
  "pmd_tx_ref2_k0_value",            /* 28 */
  "pmd_tx_noeq_k0_value",            /* 28 */
  "pmd_tx_init_kp1_value",           /* 30 */
  "pmd_tx_ref2_kp1_value",           /* 31 */
  "pmd_tx_noeq_kp1_value"            /* 32 */
};
static const int sas_dmem_entries = sizeof(sas_logger_dmem_labels)/sizeof(sas_logger_dmem_labels[0]);

#define MAX_STEPS        1000

#define PMD_INIT         0
#define PMD_SEND_TRAIN   1
#define PMD_TRAIN_LOCAL  2
#define PMD_TRAIN_REMOTE 3
#define PMD_LINK_RDY     4
#define PMD_SEND_DATA    5
#define PMD_FAILURE      6
static int sas_logger_pmd_state;

#define PMD_RX_INIT        0
#define PMD_RX_PRESET_DONE 1
#define PMD_RX_PREC_INIT   2
#define PMD_RX_POST_INIT   3
#define PMD_RX_ICAL        4
#define PMD_RX_EVAL        5
#define PMD_RX_DONE        6
#define PMD_RX_FINISHED    7
static int sas_logger_pmd_rx_state;

static char *hexfile;

static uint serdes_sas_logger_parse_table_file(Aapl_t *aapl, const char *tablefile, int *dmem, int *done_label, int *rx_eq_request, int *tx_eq_request);
static void serdes_sas_logger_print_header();
static void serdes_sas_logger_print_state(Aapl_t *aapl, unsigned int sbus_addr, int *dmem, int num, int prev_state, int * data_saved);

/*============================================================================= */
/* S E R D E S   S A S   A D D R S */
/* */
/* Parses given table file for sas specific labels to be used for testing sas logger */
/* */
void avago_serdes_sas_addrs(Aapl_t *aapl,
                                const char *tablefile,
                                int *ref1_km1,
                                int *ref2_km1,
                                int *noeq_km1,
                                int *ref1_k0,
                                int *ref2_k0,
                                int *noeq_k0,
                                int *ref1_kp1,
                                int *ref2_kp1,
                                int *noeq_kp1,
                                int *pmd_km1,
                                int *pmd_k0,
                                int *pmd_kp1)
{
      int n;
      int sas_tune_done=0;        /* AVAGO_IMEM address of sas tune done */
      int tx_eq_request=0;        /* AVAGO_IMEM address of rx_eq_request point */
      int rx_eq_request=0;        /* AVAGO_IMEM address of tx_eq_request point */
      int dmem[AAPL_ARRAY_LENGTH(sas_logger_dmem_labels)]; /* data variable addresses */

      /* Default AVAGO_DMEM to unknown value */
      for(n=0; n<sas_dmem_entries; n++) {dmem[n] = -1;}

      /* Parse the Table file to get label addresses, If unable to open then return */
      if (serdes_sas_logger_parse_table_file(aapl,&tablefile[0],dmem,&sas_tune_done,&rx_eq_request,&tx_eq_request) ) {
        return; /* Failed to read table file, exit */
      }

      *ref1_km1 = dmem[24];
      *ref2_km1 = dmem[25];
      *noeq_km1 = dmem[26];
      *ref1_k0  = dmem[27];
      *ref2_k0  = dmem[28];
      *noeq_k0  = dmem[29];
      *ref1_kp1 = dmem[30];
      *ref2_kp1 = dmem[31];
      *noeq_kp1 = dmem[32];
      *pmd_km1  = dmem[7];
      *pmd_k0   = dmem[8];
      *pmd_kp1  = dmem[9];
}

/*============================================================================= */
/* S E R D E S   S A S   L O G G E R */
/*  */
/* Launches SAS tuning on the provided SerDes */
/* int_dfe_data is the data field used to launch SAS tuning */
/* The Logger stops the sas tuning process after every DME encode/decode change */
/* and gathers data from the SerDes */
/* */
void avago_serdes_sas_logger(Aapl_t *aapl, unsigned int sbus_addr, unsigned int int_sas_data, const char *tablefile, int sas_iterations, int log_type, int log_iter, int log_steps)
{
  int sas_tune_done=0;        /* AVAGO_IMEM address of sas tune done */
  int tx_eq_request=0;        /* AVAGO_IMEM address of rx_eq_request point */
  int rx_eq_request=0;        /* AVAGO_IMEM address of tx_eq_request point */
  int dmem[AAPL_ARRAY_LENGTH(sas_logger_dmem_labels)]; /* data variable addresses */
  int data_saved[AAPL_ARRAY_LENGTH(sas_logger_dmem_labels)];
  int n;
  int pc;
  int prev_state = 0;
  int cycle;
  int cycles;
  int initial_state;
  char str[1024];

  hexfile = 0;
#if AAPL_ENABLE_FILE_IO
/* DEBUG, invoke stepping */
  hexfile = read_spico_file(aapl, sbus_addr, ".hex");
#endif

  /* Validate the sbus address is a SerDes and it's 28nm */
  if (!aapl_check_ip_type(aapl,sbus_addr, __func__, __LINE__, TRUE, 1, AVAGO_SERDES)) return;
  if (!aapl_check_process(aapl,sbus_addr, __func__, __LINE__, TRUE, 2, AVAGO_TSMC_16, AVAGO_TSMC_28)) return;

  /* Default AVAGO_DMEM to unknown value */
  for(n=0; n<sas_dmem_entries; n++) {dmem[n] = -1;}

  /* Parse the Table file to get label addresses, If unable to open then return */
  if (serdes_sas_logger_parse_table_file(aapl,&tablefile[0],dmem,&sas_tune_done,&rx_eq_request,&tx_eq_request) ) {
#if AAPL_ENABLE_FILE_IO
  aapl_free(aapl, hexfile, __func__);
#endif
    return; /* Failed to read table file, exit */
  }

  printf("sas_tune_done: 0x%04x\n", sas_tune_done);
  printf("rx_eq_request: 0x%04x\n", rx_eq_request);
  printf("tx_eq_request: 0x%04x\n", tx_eq_request);

  /* Verify all labels found */
  if (sas_tune_done == 0) { printf("WARNING: no address for sas_tune_done\n"); /*return;*/}
  if (rx_eq_request == 0)       { printf("WARNING: no address for rx_eq_request\n");       /*return;*/}
  if (tx_eq_request == 0)       { printf("WARNING: no address for tx_eq_request\n");       /*return;*/}

  avago_spico_int_check(aapl, __func__, __LINE__, sbus_addr, 0x04, 0x0000); /* Issue a PMD restart just in case */
  /* NOTE: signal ok does not assert for SAS until training done, so can't wait for it here */
  /*while(!(avago_serdes_mem_rd(aapl,sbus_addr,AVAGO_LSB,AVSD_LSB_CORE_STATUS) & 0x0010)); // Wait for sig_ok to assert */
  /* Load the Start BreakPoint addresses, BP2 = 31:16, BP1 = 15:0 */
  printf("NOTE: setting BPs to rx_eq_request/tx_eq_request\n");
  avago_sbus_wr(aapl,sbus_addr,0x21,(rx_eq_request<<16)+tx_eq_request);
  /* Enable Breakpoints */
  avago_sbus_wr(aapl,sbus_addr,0x20,0x0000000c);
  /* Launch DFE tuning */
  avago_spico_int_check(aapl, __func__, __LINE__, sbus_addr, 0x04, int_sas_data | 0x0010); /* Issue SAS training w/timeout disabled */
#if 0 /* carry over from kr_logger/dfe_logger */
  do { /* Wait for PC to reach start BP */
    pc = avago_sbus_rd(aapl,sbus_addr,0x25) & 0xFFFF;
  } while ( (pc != ical_start) && (pc != pcal_start) );

  /* Load the Tuning BreakPoint addresses, BP2 = 31:16, BP1 = 15:0 */
  avago_sbus_wr(aapl,sbus_addr,0x21,(dfe_tune_done<<16)+error_timer_done);
#endif
  /* Disable logging while looping through status */
  n = 0;
  do {
    int j = 0;
    do { /* Wait for PC to reach a BP */
      pc = avago_sbus_rd(aapl,sbus_addr,0x25) & 0xFFFF;
      j++;
      if (j > 10) printf("WARNING: too many steps (j, pc): %d 0x%04x\n", j, pc);
      if (j > 10) break;
    } while ( (pc != tx_eq_request) && (pc != rx_eq_request) && (pc != sas_tune_done) );
    /* Assert SS_EN along with BP_ENs */
    avago_sbus_wr(aapl,sbus_addr,0x20,0x0000000d);
    serdes_sas_logger_print_state(aapl,sbus_addr,dmem,n,prev_state,data_saved);
    prev_state = sas_logger_pmd_state;

    /* DEBUG, invoke dfe logger */
    /*if (log_type == 1 && sas_logger_pmd_rx_state == PMD_RX_ICAL) { */
    if (log_type == 1 && n == log_iter) {
      log_type = 0;
      printf("NOTE: changing to DFE LOGGER\n");
      internal_serdes_dfe_tune_logger(aapl, sbus_addr, tablefile);
      printf("NOTE: setting BPs to rx_eq_request/tx_eq_request\n");
      avago_sbus_wr(aapl,sbus_addr,0x21,(rx_eq_request<<16)+tx_eq_request);
      printf("NOTE: changing to SAS LOGGER\n");
    }

    /* DEBUG, invoke stepping */
    /*if (log_type == 2 && sas_logger_pmd_rx_state == PMD_RX_POST_INIT) { */
    if (log_type == 2 && n == log_iter) {
      printf("NOTE: changing to SINGLE STEPPING\n");
      cycles = log_steps;
      initial_state = avago_spico_halt(aapl, sbus_addr);
      for (cycle = 0; cycle < cycles; cycle++)
      {
        avago_spico_diag_line(aapl, sbus_addr, hexfile, str, cycle);
        avago_spico_single_step(aapl, sbus_addr, initial_state); /* single step */
      }
      avago_sbus_wr(aapl,sbus_addr,0x01,0x20000000); /* Clear AVAGO_DMEM overrides */
      avago_sbus_wr(aapl,sbus_addr,0x20,0x00000000); /* Clear BP_ENs and SS_EN */
     return; /* for now, don't try to re-enter logger after single step */
    }

    if (sas_logger_pmd_rx_state == PMD_RX_DONE) {
      printf("NOTE: setting BPs to sas_tune_done/tx_eq_request\n");
      avago_sbus_wr(aapl,sbus_addr,0x21,(sas_tune_done<<16)+tx_eq_request);
    }
    /* Assert single step */
    avago_sbus_wr(aapl,sbus_addr,0x20,0x0000000f);
    /* Clear SS_EN, leave BP_EN high */
    avago_sbus_wr(aapl,sbus_addr,0x20,0x0000000c);
    n++;
  /*} while (pc != sas_tune_done); */
  } while (pc != sas_tune_done && n < sas_iterations);
  /* End of loop, set logging back to previous setting. */

  /* Clear AVAGO_DMEM overrides */
  avago_sbus_wr(aapl,sbus_addr,0x01,0x20000000);
  /* Clear BP_ENs and SS_EN */
  avago_sbus_wr(aapl,sbus_addr,0x20,0x00000000);
#if AAPL_ENABLE_FILE_IO
  aapl_free(aapl, hexfile, __func__);
#endif
}


/*============================================================================= */
/* S E R D E S   D F E   L O G G E R   P R I N T   S T A T E */
/*  */
/* Takes the tablefile pointer and reads it to find the addresses */
/* of all the required AVAGO_DMEM locations and two AVAGO_IMEM labels */
/* */
static void serdes_sas_logger_print_state(Aapl_t *aapl, unsigned int sbus_addr, int *dmem, int num, int prev_state, int *data_saved)
{

  int i;
  int data;
  int prev_data=0;
  int cur_state=0;
  /*int data_signed; */
  /*int prev_data_signed=0; */
  int process16 = (aapl_get_process_id(aapl,sbus_addr) == AVAGO_TSMC_16);

  if ((num % 100) == 0) serdes_sas_logger_print_header();

  printf("%-6d",num);
  for(i=0;i<sas_dmem_entries; i++)
  {
    int skip = 0;
    int pipe = 0;
    int no_space = 0;
    int char_count = 4;
    int signed_var=0;
    int skip_read=0;
#if 0 /* carry over from kr_logger/dfe_logger */
    if ( (i==11) || (i==12) ) { /* EDGE VOS */
      skip_read = 1;
    }
    if (cur_state == 6) { /* In DFE state, skip CTLE, VOS, DVOS, LOOP_COUNTS */
      if ( (i >=  1) && (i <= 12) ) { skip_read = 1; }  /* CTLE,VOS */
      if ( (i >= 26) && (i <= 43) ) { skip_read = 1; }  /* DVOS,LOOP */
    } else {              /* NOT DFE, skip DFE taps and gainDFE */
      if (i==13) { skip_read = 1;}
      if ( (i >= 15) && (i <= 25) ) { skip_read = 1; }
    }
    if (cur_state == 9) { /* In lev_fine, skip CTLE */
      if ( (i >=  1) && (i <= 4) ) { skip_read = 1; }   /* CTLE */
    } else {              /* NOT lev_fine, skip DVOS, LOOP */
      if ( (i >= 26) && (i <= 43) ) { skip_read = 1; }  /* DVOS,LOOP */
    }
#endif
    /* Always update on state transitions and dfe_state */
    if ( (prev_state !=0 ) && (prev_state == cur_state) && (i>0) && skip_read ) {
      data = *(data_saved+i);
      no_space = signed_var = 0;    /* Force use to avoid warnings because of ifdefs. */
    } else {
      if ( dmem[i] < 0 ) {   /* AVAGO_ESB address, only one atm is PFD */
        if (process16)
        {
            /* TODO-16NM - sas logger needs to be tested on 16NM */
              avago_sbus_wr(aapl,sbus_addr,0x01,0x40000030); /* 0x30 AVAGO_ESB ADDR */
              avago_sbus_wr(aapl,sbus_addr,0x01,0x80000030); /* 0x30 AVAGO_ESB ADDR */
              avago_sbus_wr(aapl,sbus_addr,0x01,0x00000032); /* 0x32 AVAGO_ESB READ_DATA */
              avago_sbus_wr(aapl,sbus_addr,0x01,0x80000032); /* 0x32 AVAGO_ESB READ_DATA */
              data = ( avago_sbus_rd(aapl,sbus_addr,0x01) & 0x00000400 ) >> 10; /* PFD is [10] of AVAGO_ESB 0x00 */
        } else {
            avago_sbus_wr(aapl,sbus_addr,0x02,0x00300000); /* 0x30 AVAGO_ESB ADDR */
            avago_sbus_wr(aapl,sbus_addr,0x02,0x80300000); /* 0x30 AVAGO_ESB ADDR */
            avago_sbus_wr(aapl,sbus_addr,0x02,0x00320000); /* 0x32 AVAGO_ESB READ_DATA */
            avago_sbus_wr(aapl,sbus_addr,0x02,0x80320000); /* 0x32 AVAGO_ESB READ_DATA */
            data = ( avago_sbus_rd(aapl,sbus_addr,0x40) & 0x00000400 ) >> 10; /* PFD is [10] of AVAGO_ESB 0x00 */
        }
      } else {
        if (dmem[i] < 512) {  /* Test for DMA v. AVAGO_DMEM */
          if (process16)
              avago_sbus_wr(aapl,sbus_addr,0x01,(dmem[i]) & 0x000000FF);
          else
              avago_sbus_wr(aapl,sbus_addr,0x02,(dmem[i] << 16) & 0x00FF0000);
          data = avago_sbus_rd(aapl,sbus_addr,0x40) & 0x0000FFFF;
        } else {
          avago_sbus_wr(aapl,sbus_addr,0x01,0x60000000|(dmem[i] & 0x000003FF)); 
          data = ( avago_sbus_rd(aapl,sbus_addr,0x01) >> 12 ) & 0x0000FFFF;
        }
      }
    }
    *(data_saved+i) = data;
#if 0 /* carry over from kr_logger/dfe_logger */
    if (data & 0x8000) {
      data_signed = -1 * ((data ^ 0xFFFF) + 1);
    } else {
      data_signed = data;
    }
#endif
    switch(i) {
      case 0 : { const char *state;
                 switch(data) {
                   case PMD_INIT :         state = "init"; break;
                   case PMD_SEND_TRAIN :   state = "send_train"; break;
                   case PMD_TRAIN_LOCAL :  state = "train_local"; break;
                   case PMD_TRAIN_REMOTE : state = "train_remote"; break;
                   case PMD_LINK_RDY :     state = "link_rdy"; break;
                   case PMD_SEND_DATA :    state = "send_data"; break;
                   case PMD_FAILURE :      state = "failure"; break;
                   default:                state = "unknown"; break;
                 }
                 printf("%-14s",state);
                 skip = 1;
                 cur_state = data;
                 sas_logger_pmd_state = data;
                 break;
               }
      case 1 : { const char *state;
                 switch(data) {
                   case PMD_RX_INIT : state = "init"; break;
                   case PMD_RX_PRESET_DONE : state = "preset"; break;
                   case PMD_RX_PREC_INIT :   state = "pre_loop"; break;
                   case PMD_RX_POST_INIT :   state = "post_loop"; break;
                   case PMD_RX_ICAL : state = "iCal"; break;
                   case PMD_RX_EVAL : state = "eval"; break;
                   case PMD_RX_DONE : state = "done"; break;
                   case PMD_RX_FINISHED : state = "finished"; break;
                   default: state = "unknown"; break;
                 }
                 printf("%-14s",state);
                 skip = 1;
                 sas_logger_pmd_rx_state = data;
                 break;
               }
      case 2 : { const char *state;
                 switch(data) {
                   case 0 : state = "idle"; break;
                   case 3 : state = "dlev_coarse"; break;
                   case 4 : state = "tlev_coarse"; break;
                   case 5 : state = "tlev_fine"; break;
                   case 6 : state = "dfe"; break;
                   case 7 : state = "dcgain"; break;
                   case 9 : state = "dlev_fine"; break;
                   case 11: state = "update_lev"; break;
                   case 13: state = "vos_cross"; break;
                   case 15: state = "ical_done"; break;
                   default: state = "unknown"; break;
                 }
                 printf("%-14s",state);
                 skip = 1;
                 break;
               }
               /* DME CONTROL */
      case 5 : printf("| ");
      case 3 : { char state[15];
                 memset(state, '\0', sizeof( state ));
                 if (data & 0x1000)
                   strncat(state,"INITIALIZE",sizeof(state)-1);
                 else
                   if (data & 0x2000)
                     strncat(state,"PRESET",sizeof(state)-1);
                   else {
                     int ddd;
                     for(ddd=0; ddd<3; ddd++) {
                       switch( (data >> (ddd*2)) & 0x3) {
                         case 0 : {strncat(state,"HOLD",4); break;}
                         case 1 : {strncat(state," INC",4); break;}
                         case 2 : {strncat(state," DEC",4); break;}
                         default: {strncat(state,"????",4); break;}
                       }
                       if (ddd < 2)
                         strncat(state,",",1);
                     }
                   }
                 printf("%-14s(%04x) ",state, data);
                 skip = 1;
                 break;
               }
               /* DME STATUS */
      case 6 :
      case 4 : { char state[12];
                 int ddd;
                 memset(state, '\0', sizeof( state ));
                 for(ddd=0; ddd<3; ddd++) {
                   switch( (data >> (ddd*2)) & 0x3) {
                     case 0 : {strncat(state,"NUP",3); break;}
                     case 1 : {strncat(state," UP",3); break;}
                     case 2 : {strncat(state,"MIN",3); break;}
                     default: {strncat(state,"MAX",3); break;}
                   }
                   if (ddd < 2)
                     strncat(state,",",1);
                 }
                 printf("%-11s(%04x) ",state, data);
                 skip = 1;
                 break;
               }
      case 7 : { pipe = 1; break;} /* Before TX_EQ */
      case 10: { pipe = 1; break;} /* Before MIN/MAX RESPONSE RECEIVED */
      case 11: { pipe = 1; break;} /* Before PMD_CONTROL */
      case 13: { pipe = 1; break;} /* Before PMD_CONFIG */
      case 15: { pipe = 1; break;} /* Before 16G_CNTL */
      case 17: { pipe = 1; break;} /* Before PMD_2nd_REQ */
      case 18: { pipe = 1; skip = 1; break;}                            /* Before err_cnt_p0 */
      case 19: { char_count = 8; data = data + (prev_data << 16); break;} /* err_cnt_p0 */
      case 20: { skip = 1; break;}
      case 21: { char_count = 8; data = data + (prev_data << 16); break;} /* err_cnt_p1 */
      case 22: { skip = 1; break;}
      case 23: { char_count = 8; data = data + (prev_data << 16); break;} /* corr_err */
#if 0 /* carry over from kr_logger/dfe_logger */
      case 24: { skip = 1; break;}
      case 25: { char_count = 8; data = data + (prev_data << 16); break;} /* min_err` */
      case 25: {signed_var = 1; break;}
      case 26: { pipe = 1; skip = 1; break;}      /* Before data height */
      case 27: { data = abs(prev_data_signed - data_signed); break;} /* Calculate d0e height */
      case 28: { skip = 1;  break;}               /* skip d0o_lo */
      case 29: { data = abs(prev_data_signed - data_signed); break;} /* Calculate d0o height */
      case 30: { skip = 1;  break;}               /* skip d1e_lo */
      case 31: { data = abs(prev_data_signed - data_signed); break;} /* Calculate d1e height */
      case 32: { skip = 1;  break;}               /* skip d1o_lo */
      case 33: { data = abs(prev_data_signed - data_signed); break;} /* Calculate d1o height */
      case 34: { pipe = 1; skip = 1; break;}      /* Before test height */
      case 35: { data = abs(prev_data_signed - data_signed); break;} /* Calculate t_d0e height */
      case 36: { skip = 1;  break;}               /* skip t_d0o_lo */
      case 37: { data = abs(prev_data_signed - data_signed); break;} /* Calculate t_d0o height */
      case 38: { skip = 1;  break;}               /* skip t_d1e_lo */
      case 39: { data = abs(prev_data_signed - data_signed); break;} /* Calculate t_d1e height */
      case 40: { skip = 1;  break;}               /* skip t_d1o_lo */
      case 41: { data = abs(prev_data_signed - data_signed); break;} /* Calculate t_d1o height */
      case 42: { pipe = 1; break;} /* Before tap_loops */
      case 44: { pipe = 1; char_count = 1; data = (data >> 14) & 0x0003; printf(" "); no_space=1;break;} /* FLOCK,DISABLE_FLOCK_CHECKS */
      case 45: { char_count = 1; break;}          /* PFD */
      case 46: { pipe = 1; skip=1;break;} /* Before min_errors */
      case 47: { data = data + (prev_data << 16); char_count = 8; no_space=1; break;} /* min_error_count */
      case 48: { skip=1;break;}          
      case 49: { data = data + (prev_data << 16); char_count = 8; break;} /* error_count */
      case 50: { skip=1;break;}          
      case 51: { data = data + (prev_data << 16); char_count = 8; break;} /* error_chk_count */
      case 52: { pipe = 1; skip = 1; break;} /* Before mask */
      case 53: { data = data | ((prev_data & 0xF000) << 4); char_count = 5; no_space=1; break;} /* Mask */
      case 54: { char_count = 4; break;} /* Compare mode */
      case 55: { char_count = 4; break;} /* qual */
      case 56: { pipe=1; no_space=1; char_count = 2; break;}  /* bestDC */
      case 57:                                                /* bestLF */
      case 58: { char_count = 2; break; }                     /* bestHF */
      case 59:                              
      case 60: { char_count = 4; break; }                     /* bestT1P1 */
      case 61:                                                /* bestEyeP0 */
      case 62: { char_count = 2; break;}                      /* bestEyeP1 */
      case 63: { pipe=1; }
      case 64:
      case 65: { char_count = 2; break;} /* DC loop range */
      case 66: { pipe=1; }
      case 67:
      case 68: { char_count = 1; break;} /* LF loop range */
      case 69: { pipe=1; }
      case 70:
      case 71: { char_count = 1; break;} /* HF loop range */
#endif
      case 24: { skip = 1; break;}
      case 25: { skip = 1; break;}
      case 26: { skip = 1; break;}
      case 27: { skip = 1; break;}
      case 28: { skip = 1; break;}
      case 29: { skip = 1; break;}
      case 30: { skip = 1; break;}
      case 31: { skip = 1; break;}
      case 32: { skip = 1; break;}
      default: break;
    }
    if (pipe) {
      printf("|");
    }
    if (!skip) {
      if (!no_space) {
        printf(" ");
      }
      switch(char_count) {
        case 1 : {printf("%x",data); break;}
        case 4 : {printf("%04x",data); break;}
        case 5 : {printf("%05x",data); break;}
        case 8 : {
                   if (data == 0) {
                     printf("0x........");  /* Substitute 0's with ......... for easier parsing */
                   } else {
                     printf("0x%08x",data); 
                   }
                   break;
                 }
        default: {
                   if (signed_var) {
                     if (data > 128) {
                       printf("-%x", (data ^ 0xFFFF) + 1);
                     } else {
                       printf("%02x",data); 
                     }
                   } else {
                     printf("%02x",data); 
                   }
                   break;
                 }
      }
    }
    prev_data = data;
    /*prev_data_signed = data_signed; */
  }
  printf("\n");
  avago_sbus_wr(aapl,sbus_addr,0x01,0x20000000); /* clear dmem override */
  /*printf("state-> %d\n",cur_state); */
}
/*============================================================================= */
/* S E R D E S   D F E   L O G G E R   P R I N T   H E A D E R */
/*  */
/* Print the header for the columns of data comping out */
/* */
static void serdes_sas_logger_print_header()
{

  int i;
  char header[20];

  printf("%-6s","count");
  for(i=0;i<sas_dmem_entries; i++) {
    int skip = 0;
    int pipe = 0;
    int no_space = 0;
    const char *entry = sas_logger_dmem_labels[i];
    if ( strstr(entry,"pmd_state") )       { printf("%-14s","state"); skip =1;}
    if ( strstr(entry,"pmd_rx_eq_state") ) { printf("%-14s","rx_eq_state"); skip =1;}
    if ( strstr(entry,"dfe_state") )       { printf("%-14s","dfe_state"); skip =1;}
    if ( strstr(entry,"dme_encode_2") )    { printf("%-14s","SEND CONTROL"); skip =1;}
    if ( strstr(entry,"dme_encode_1") )    { printf("%-11s","         STATUS          "); skip =1;}
    if ( strstr(entry,"dme_decode_1") )    { printf("%-14s","| RECEIVE CONTROL"); skip =1;}
    if ( strstr(entry,"dme_decode_0") )    { printf("%-11s","         STATUS         "); skip =1;}
    if ( strstr(entry,"pmd_k") )           { skip = 1;}
    if ( strstr(entry,"pmd_k0") )          { printf("%-16s","| TX EQ"); skip =1;}

    if (!strcmp(entry,"pmd_tx_init_km1_value") )   { skip=1;}
    if (!strcmp(entry,"pmd_tx_ref2_km1_value") )    { skip=1;}
    if (!strcmp(entry,"pmd_tx_noeq_km1_value") )   { skip=1;}
    if (!strcmp(entry,"pmd_tx_init_k0_value") )    { skip=1;}
    if (!strcmp(entry,"pmd_tx_ref2_k0_value") )    { skip=1;}
    if (!strcmp(entry,"pmd_tx_noeq_k0_value") )    { skip=1;}
    if (!strcmp(entry,"pmd_tx_init_kp1_value") )    { skip=1;}
    if (!strcmp(entry,"pmd_tx_ref2_kp1_value") )   { skip=1;}
    if (!strcmp(entry,"pmd_tx_noeq_kp1_value") )   { skip=1;}

    if ( strstr(entry,"pmd_") )   { if (!skip) strcpy(header,entry+4);}
    if ( strstr(entry,"pmd_config") )      { strcpy(header,"cfg"); pipe=1;}
    if ( strstr(entry,"pmd_status") )      { no_space=1;}
    if ( strstr(entry,"pmd_rx_eq_tap_done") )  {strcpy(header,"loop"); pipe=1;}
    if ( strstr(entry,"pmd_control") )     {strcpy(header," hdw cntl"); pipe=1;}
    if ( strstr(entry,"dme_control") )     {skip=1;}
    if ( strstr(entry,"16g") )             {skip=1;}
    if ( strstr(entry,"pmd_16g_cntl") )    {strcpy(header," FC mask "); pipe=1; skip=0;}
    if ( strstr(entry,"pmd_adj_req2") )    {printf("| req2"); skip=1;}
    if ( strstr(entry,"_lo") )             {skip=1;}
    if ( strstr(entry,"error_hi") )        {printf("| %-10s","corr");     skip=1;}
    if ( strstr(entry,"err_cnt_p0_hi") )   {printf(" %-10s","corr_prev");  skip=1;}
    if ( strstr(entry,"err_cnt_p1_hi") )   {printf(" %-10s","corr_prev2"); skip=1;}
#if 0 /* carry over from kr_logger/dfe_logger */
    if ( strstr(entry,"stop") ) { strcpy(header,entry+4); pipe=1;}
    if ( strstr(entry,"gain") ) { strcpy(header,entry+4); }
    if ( strstr(entry,"vos_") ) { strcpy(header,entry+5); }
    if ( strstr(entry,"d6_alpha") ) { strcpy(header," 1"); }
    if ( strstr(entry,"dvos") ) { 
      skip = 1;
      if ( strstr(entry,"dvos_d0e_hi") ) { 
        strcpy(header," data height"); 
        skip = 0;
        pipe = 1;
        no_space = 1;
      }
      if ( strstr(entry,"dvos_t1e_0_hi") ) { 
        strcpy(header," test height"); 
        skip = 0;
        pipe = 1;
        no_space = 1;
      }
    }
    if ( strstr(entry,"d6_tap") )     { strcpy(header,"tap"); pipe=1; skip = 0;no_space=1;}
    if ( strstr(entry,"d6_pCal") )    { strcpy(header,"pCal"); skip = 0;no_space=1;}
    if ( strstr(entry,"cal_timer") )  { strcpy(header,"PLL"); pipe=1;no_space=1;}
    if ( strstr(entry,"error") )      { strcpy(header,"  errors"); }
    if ( strstr(entry,"min_errors") ) { strcpy(header,"min_errors"); pipe=1;}
    if ( strstr(entry,TC_CNTR_HI) )   { strcpy(header,"  error_chks"); no_space=1;}
    if ( strstr(entry,"compare") )    { strcpy(header,"cmp "); }
    if ( strstr(entry,"mask") )       { strcpy(header,entry+8); printf("| ");}
    if ( strstr(entry,"enable") )     { strcpy(header,"qual"); no_space=1;}
    if ( strstr(entry,"save") )       { strcpy(header,"debug"); }
    if (!strcmp(entry,"gainBW") )     { no_space=1;}
    if (!strcmp(entry,"vos_d0e") )    { printf("|d");}
    if (!strcmp(entry,"vos_t1e") )    { printf("|t");}
    if (!strcmp(entry,"vos_d1o") )    { no_space=1;}
    if (!strcmp(entry,"vos_t0o") )    { no_space=1;}
    if (!strcmp(entry,"gainDFE") )    { pipe=1;}
    if (!strcmp(entry,"gainC") )      { no_space=1;}
    if (!strcmp(entry,"save_vos_e") ) { pipe=1;}
    if (!strcmp(entry,"save_vos_o") ) { skip=1;}
    if (!strcmp(entry,"temp_p") )     { skip=1;}
    if (!strcmp(entry,"min_i") )      { skip=1;}
    if (!strcmp(entry,"debug_") )     { skip=1;}
    if (!strcmp(entry,"eye_") )       { skip=1;}
    if (!strcmp(entry,"gainDC_step") ){ skip=1;}
    if (!strcmp(entry,"bestDC") )     { pipe=1;}
    if (!strcmp(entry,"bestEyeP0") )  { strcpy(header,"EyeP*"); no_space=1;}
    if (!strcmp(entry,"bestEyeP1") )  { skip=1;}
    if (!strcmp(entry,"stopDC") )     { strcpy(header,"LOOPS: DC"); no_space=1;}
    if (!strcmp(entry,"stepDC") )     { skip=1;}
    /*if (strlen(header) < 2) {printf(" ");} // Insert space for gain taps */
#endif
    if (!skip) {
      if (pipe) {
        printf("|");
      }
      printf("%s",header);
      if (!no_space) {
        printf(" ");
      }
    }
  }
  printf("\n");
}

/*============================================================================= */
/* S E R D E S   D F E   L O G G E R   T A B L E   P A R S E R */
/*  */
/* Takes the tablefile pointer and reads it to find the addresses */
/* of all the required AVAGO_DMEM locations and two AVAGO_IMEM labels */
/* */
static uint serdes_sas_logger_parse_table_file(Aapl_t *aapl, const char *tablefile, int *dmem, int *done_label, int *rx_eq_request, int *tx_eq_request)
{
#if !AAPL_ENABLE_FILE_IO
(void)aapl;
(void)tablefile;
(void)dmem;
(void)done_label;
(void)rx_eq_request;
(void)tx_eq_request;
#else
  FILE * file;
  char line[200];

  printf("File to read %s\n",tablefile);
  file = fopen(tablefile, "r"); /* open file as read only */
  if (!file) {
    aapl_fail(aapl, __func__, __LINE__, "Couldn't open file %s.\n", tablefile);
    return 1;
  }

  while (fgets (line, sizeof line, file) != NULL) {
    char label[100] = "";
    char addr[5] = "";
    char hex[7] = "";
    char type[11] = "";
    uint  num = 0;
    sscanf(line,"%99s %4s %10s",label,addr,type);
    /* Create an int of the address */
    strcpy(hex,"0x");
    strcat(hex,addr);
    sscanf(hex,"%6x",&num);
    /* Check if we've already have set labels, and go onto AVAGO_DMEM_LABEL check if so */
    if ( (!*done_label || !*rx_eq_request || !*tx_eq_request) 
        && !strcmp(type,"IMEM_LABEL") ) {
      /*if (!strcmp(label,"main_loop_pmd_rtn") ) */
      if (!strcmp(label,"pmd_training_end_transmission") )
        *done_label = num;
      /*if (!strcmp(label,"pmd_rx_eq_set_output__if4_end") ) */
      if (!strcmp(label,"pmd_rx_eq_loop__if13_end") ) /* this is pmd_rx_eq_loop just before interrupts re-enabled */
        *rx_eq_request = num;
      if (!strcmp(label,"pmd_tx_eq_check_done") )
        *tx_eq_request = num;
    }  else {
      if (!strcmp(type,"DMEM_LABEL") ) {
        /* Check if we save this label */
        int i = 0;
        do {
          if (!strcmp(label,sas_logger_dmem_labels[i]) ) {
            *(dmem+i) = num;
            i = sas_dmem_entries;
          } /* Match label X */
          else {
            /* esb and lsb symbols were changed to add a prefix "reg_esb_" or "reg_lsb_" */
            char *p = label + strlen("reg_esb_");
            if (!strcmp(p,sas_logger_dmem_labels[i]) ) {
              *(dmem+i) = num;
              i = sas_dmem_entries;
            } /* Match label X */
          }
          i++;
        } while (i<sas_dmem_entries);
      } /* AVAGO_DMEM_LABEL */
    } /* AVAGO_IMEM_LABEL */
  } /* File reading */
  fclose(file);
#endif  /* AAPL_ENABLE_FILE_IO */
  return 0;
}
#endif /* AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO */
