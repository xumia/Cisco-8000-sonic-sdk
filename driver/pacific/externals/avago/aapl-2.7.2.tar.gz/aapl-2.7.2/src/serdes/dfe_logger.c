/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/** Doxygen File Header */
/** @file */
/** @brief Functions for logging DFE tuning. */

#define HAL_BASED_LOGGER
#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

/* TODO: refactor check pikes dynamically? */
/*#define PIKES */
#ifdef PIKES
/* PIKES needs to use error_2 instead of tc_cntr_val per Jeff S. */
#define TC_CNTR    "error_hi_2"
#define TC_CNTR_HI "error_hi_2"
#define TC_CNTR_LO "error_lo_2"
#else
#define TC_CNTR    "tc_cntr_val"
#define TC_CNTR_HI "tc_cntr_val_hi"
#define TC_CNTR_LO "tc_cntr_val_lo"
#endif

#if AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO

/* HAL BASED Logger */
#ifdef HAL_BASED_LOGGER
static const char *dfe_logger_dmem_labels[] =
{
  "dfe_state",          /* 00 */
  "ctle_inputs__plus2", /* gainDC",             // 01 */
  "ctle_inputs__plus1", /* gainLF",             // 02 */
  "ctle_inputs",        /* gainHF",             // 03 */
  "ctle_inputs__plus3", /* gainBW",             // 04 */
  "vos_d0e",            /* 05 */
  "vos_d0o",            /* 06 */
  "vos_d1e",            /* 07 */
  "vos_d1o",            /* 08 */
  "vos_t1e",            /* 09 */
  "vos_t1o",            /* 10 */
  "vos_t0e",            /* 11 */
  "vos_t0o",            /* 12 */
  "dfe_inputs",         /* gainDFE",            // 13 */
  "d6_alpha",           /* 14 */
  "dfe_inputs__plus1",  /* gain2",              // 15 */
  "dfe_inputs__plus2",  /* gain3",              // 16 */
  "dfe_inputs__plus3",  /* gain4",              // 17 */
  "dfe_inputs__plus4",  /* gain5",              // 18 */
  "dfe_inputs__plus5",  /* gain6",              // 19 */
  "dfe_inputs__plus6",  /* gain7",              // 20 */
  "dfe_inputs__plus7",  /* gain8",              // 21 */
  "dfe_inputs__plus8",  /* gain9",              // 22 */
  "dfe_inputs__plus9",  /* gainA",              // 23 */
  "dfe_inputs__plus10",  /* gainB",              // 24 */
  "dfe_inputs__plus11",  /* gainC",              // 25 */
  "dfe_inputs__plus12",  /* gainD",              // 26 */
  "dvos_d0e_hi",        /* 27 */
  "dvos_d0e_lo",        /* 28 */
  "dvos_d0o_hi",        /* 29 */
  "dvos_d0o_lo",        /* 30 */
  "dvos_d1e_hi",        /* 31 */
  "dvos_d1e_lo",        /* 32 */
  "dvos_d1o_hi",        /* 33 */
  "dvos_d1o_lo",        /* 34 */
  "dvos_t1e_0_hi",      /* 35 */
  "dvos_t1e_0_lo",      /* 36 */
  "dvos_t1o_0_hi",      /* 37 */
  "dvos_t1o_0_lo",      /* 38 */
  "dvos_t1e_1_hi",      /* 39 */
  "dvos_t1e_1_lo",      /* 40 */
  "dvos_t1o_1_hi",      /* 41 */
  "dvos_t1o_1_lo",      /* 42 */
  "d6_tap_loops",       /* 43 */
  "d6_pCal_loop_count", /* 44 */
  "cal_timer_hi",       /* 45 */
  "error_count",        /* 46  this was PFD but HAl based uses any ole label to keep continuity of table entries */
  "min_errors_hi",      /* 47 */
  "min_errors_lo",      /* 48 */
  "error_hi",           /* 49 */
  "error_lo",           /* 50 */
  "error_hi_2",         /* 51 */
  "error_lo_2",         /* 52 */
  "compare_clk_sel",    /* 53 */
  "compare_mask_4",     /* 54 */
  "compare_mask_3",     /* 55 */
  "compare_mask_2",     /* 56 */
  "compare_mask_1",     /* 57 */
  "compare_mask",       /* 58 */
  "compare",            /* 59 */
  "compare_enable",     /* 60 */
  "compare_data_compare_en_3", /* 61 */
  "compare_data_compare_en_2", /* 62 */
  "compare_data_compare_en_1", /* 63 */
  "compare_data_compare_en_0", /* 64 */
  "bestDC",             /* 65 */
  "bestLF",             /* 66 */
  "bestHF",             /* 67 */
  "bestT1P0",           /* 68 */
  "bestT1P1",           /* 69 */
  "bestEyeP0",          /* 70 */
  "bestEyeP1",          /* 71 */
  "startDC",            /* 72 */
  "stopDC",             /* 73 */
  "stepDC",             /* 74 */
  "startLF",            /* 75 */
  "stopLF",             /* 76 */
  "stepLF",             /* 77 */
  "startHF",            /* 78 */
  "stopHF",             /* 79 */
  "stepHF",             /* 80 */
  "dfe_status",         /* 81 */
  "error_reg_hi",           /* 82 */
  "error_reg_lo"            /* 83 */
};
#else
static const char *dfe_logger_dmem_labels[] =
{
  "dfe_state",          /* 00 */
  "gainDC",             /* 01 */
  "gainLF",             /* 02 */
  "gainHF",             /* 03 */
  "gainBW",             /* 04 */
  "vos_d0e",            /* 05 */
  "vos_d0o",            /* 06 */
  "vos_d1e",            /* 07 */
  "vos_d1o",            /* 08 */
  "vos_t1e",            /* 09 */
  "vos_t1o",            /* 10 */
  "vos_t0e",            /* 11 */
  "vos_t0o",            /* 12 */
  "gainDFE",            /* 13 */
  "d6_alpha",           /* 14 */
  "gain2",              /* 15 */
  "gain3",              /* 16 */
  "gain4",              /* 17 */
  "gain5",              /* 18 */
  "gain6",              /* 19 */
  "gain7",              /* 20 */
  "gain8",              /* 21 */
  "gain9",              /* 22 */
  "gainA",              /* 23 */
  "gainB",              /* 24 */
  "gainC",              /* 25 */
  "gainD",              /* 26 */
  "dvos_d0e_hi",        /* 27 */
  "dvos_d0e_lo",        /* 28 */
  "dvos_d0o_hi",        /* 29 */
  "dvos_d0o_lo",        /* 30 */
  "dvos_d1e_hi",        /* 31 */
  "dvos_d1e_lo",        /* 32 */
  "dvos_d1o_hi",        /* 33 */
  "dvos_d1o_lo",        /* 34 */
  "dvos_t1e_0_hi",      /* 35 */
  "dvos_t1e_0_lo",      /* 36 */
  "dvos_t1o_0_hi",      /* 37 */
  "dvos_t1o_0_lo",      /* 38 */
  "dvos_t1e_1_hi",      /* 39 */
  "dvos_t1e_1_lo",      /* 40 */
  "dvos_t1o_1_hi",      /* 41 */
  "dvos_t1o_1_lo",      /* 42 */
  "d6_tap_loops",       /* 43 */
  "d6_pCal_loop_count", /* 44 */
  "cal_timer_hi",       /* 45 */
  "PFD",                /* 46 */
  "min_errors_hi",      /* 47 */
  "min_errors_lo",      /* 48 */
  "error_hi",           /* 49 */
  "error_lo",           /* 50 */
  "error_hi_2",         /* 51 */
  "error_lo_2",         /* 52 */
  "compare_clk_sel",    /* 53 */
  "compare_mask_4",     /* 54 */
  "compare_mask_3",     /* 55 */
  "compare_mask_2",     /* 56 */
  "compare_mask_1",     /* 57 */
  "compare_mask",       /* 58 */
  "compare",            /* 59 */
  "compare_enable",     /* 60 */
  "compare_data_compare_en_3", /* 61 */
  "compare_data_compare_en_2", /* 62 */
  "compare_data_compare_en_1", /* 63 */
  "compare_data_compare_en_0", /* 64 */
  "bestDC",             /* 65 */
  "bestLF",             /* 66 */
  "bestHF",             /* 67 */
  "bestT1P0",           /* 68 */
  "bestT1P1",           /* 69 */
  "bestEyeP0",          /* 70 */
  "bestEyeP1",          /* 71 */
  "startDC",            /* 72 */
  "stopDC",             /* 73 */
  "stepDC",             /* 74 */
  "startLF",            /* 75 */
  "stopLF",             /* 76 */
  "stepLF",             /* 77 */
  "startHF",            /* 78 */
  "stopHF",             /* 79 */
  "stepHF",             /* 80 */
  "dfe_status",         /* 81 */
  /* FOR_HERTZ */
  "error_reg_hi",           /* 82 */
  "error_reg_lo"            /* 83 */
};
#endif

/* VARIABLES */
static int dfe_dmem_entries = sizeof(dfe_logger_dmem_labels)/sizeof(dfe_logger_dmem_labels[0]);
static char *hexfile;
static int dfe_status = 0x11;

/* PROTOTYPES */
static void serdes_dfe_tune_logger(Aapl_t *aapl, unsigned int sbus_addr, unsigned int int_code, 
                                   unsigned int int_dfe_data, const char *tablefile);
static uint serdes_dfe_logger_parse_table_file(Aapl_t *aapl, const char *tablefile, int *dmem, 
                                               int *error_label, int *done_label, int *tune_start, int *vos_start);
static void serdes_dfe_logger_print_header();
static int  serdes_dfe_logger_print_state(Aapl_t *aapl, unsigned int sbus_addr, int *dmem, int num, int prev_state, int * data_saved);

/** @brief   Launches DFE tuning on the provided SerDes. */
/** @details The Logger stops the dfe tuning process after every error accumulation */
/**          and gathers data from the SerDes. */
/** @return  void. */
/** @see     serdes_dfe_tune_logger(). */
void avago_serdes_dfe_logger(
    Aapl_t *aapl,                /**< [in] Pointer to Aapl_t structure. */
    unsigned int sbus_addr,      /**< [in] Device address number. */
    unsigned int int_dfe_data,   /**< [in] Data to launch DFE tuning. */
    const char *tablefile)       /**< [in] Path to the tablefile. */
{
  serdes_dfe_tune_logger(aapl, sbus_addr, 0x0A, int_dfe_data, tablefile);
}

/** @brief   Launches DFE tuning on the provided PCIe SerDes. */
/** @details The Logger stops the dfe tuning process after every error accumulation */
/**          and gathers data from the SerDes. */
/** @return  void. */
/** @see     serdes_dfe_tune_logger(). */
void avago_serdes_pcie_logger(
    Aapl_t *aapl,                /**< [in] Pointer to Aapl_t structure. */
    unsigned int sbus_addr,      /**< [in] Device address number. */
    unsigned int int_dfe_data,   /**< [in] Data to launch DFE tuning. */
    const char *tablefile)       /**< [in] Path to the tablefile. */
{
  avago_spico_int(aapl, sbus_addr, 0x26, 0x5201); /* Ensure that iCal will execute when called */
  serdes_dfe_tune_logger(aapl, sbus_addr, 0x24, int_dfe_data, tablefile);
}

#ifdef AAPL_ENABLE_INTERNAL_FUNCTIONS
void internal_serdes_dfe_tune_logger(Aapl_t *aapl, unsigned int sbus_addr, const char *tablefile)
{
  serdes_dfe_tune_logger(aapl, sbus_addr, 0xffff, 0, tablefile);
}
#endif
/* serdes_dfe_tune_logger() */
/*  */
/* Launches DFE tuning on the provided SerDes */
/* int_dfe_data is the data field used to launch DFE tuning */
/* The Logger stops the dfe tuning process after every error accumulation */
/* and gathers data from the SerDes */
static void serdes_dfe_tune_logger(Aapl_t *aapl, 
                                   unsigned int sbus_addr, 
                                   unsigned int int_code, 
                                   unsigned int int_dfe_data, 
                                   const char *tablefile)
{
  int error_timer_done=0;     /* AVAGO_IMEM address of error count complete */
  int dfe_tune_done=0;        /* AVAGO_IMEM address of dfe tune complete */
  int vos_start=0;            /* AVAGO_IMEM address of iCal start */
  int tune_start=0;           /* AVAGO_IMEM address of pCal start */
  int dmem[AAPL_ARRAY_LENGTH(dfe_logger_dmem_labels)]; /* data variable addresses */
  int data_saved[AAPL_ARRAY_LENGTH(dfe_logger_dmem_labels)];
  int n;
  int pc;
  int prev_state = 0;
  int dmem_entries_adjust = 0;
/* DEBUG, invoke stepping */
/*  int cycle; */
/*  int cycles; */
/*  int initial_state; */
/*  char str[1024]; */

  hexfile = 0;
/* DEBUG, invoke stepping */
/*  hexfile = read_spico_file(aapl, sbus_addr, ".hex"); */

  /* Validate the sbus address is a SerDes and it's 28nm */
  if (!aapl_check_ip_type(aapl,sbus_addr, __func__, __LINE__, TRUE, 2, AVAGO_SERDES, AVAGO_M4)) return;
  if (!aapl_check_process(aapl,sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28)) return;

  /* Init AVAGO_DMEM to unknown value */
  for(n=0; n<dfe_dmem_entries; n++) {
    dmem[n] = -1;
  }

  /* Parse the Table file to get label addresses, If unable to open then return */
  if (serdes_dfe_logger_parse_table_file(aapl,
                                         &tablefile[0],
                                         dmem,
                                         &error_timer_done,
                                         &dfe_tune_done,
                                         &tune_start,
                                         &vos_start) ) {
    return; 
  }

  printf("error_timer_done: 0x%04x\n", error_timer_done);
  printf("dfe_tune_done:    0x%04x\n", dfe_tune_done);
  printf("vos_start:        0x%04x\n", vos_start);
  printf("tune_start:       0x%04x\n", tune_start);

  /* Verify all labels found */
  if (error_timer_done == 0) { printf("WARNING: no address for error_timer_done\n"); }
  if (dfe_tune_done == 0)    { printf("WARNING: no address for dfe_tune_done\n");    }
  if (vos_start == 0)        { printf("WARNING: no address for ical_start\n");       }
  if (tune_start == 0)       { printf("WARNING: no address for pcal_start\n");       }
  for(n=0; n<dfe_dmem_entries; n++) {
      if (dmem[n] == -1) {
          /* FOR_HERTZ */
          if ( strstr(dfe_logger_dmem_labels[n],"error_reg") ) dmem_entries_adjust--;
          else printf("WARNING: no address for %s\n", dfe_logger_dmem_labels[n]);
          /*return;*/
      }
      /* Uncomment to see parsed labels by this exe */
      /* printf("0x%04x : %s\n", dmem[n], dfe_logger_dmem_labels[n]); */
  }
  /* FOR_HERTZ */
  dfe_dmem_entries += dmem_entries_adjust;

  /* Load the Start BreakPoint addresses, BP2 = 31:16, BP1 = 15:0 */
  avago_sbus_wr(aapl,sbus_addr,0x21,(tune_start<<16)+vos_start);
  /* Enable Breakpoints */
  avago_sbus_wr(aapl,sbus_addr,0x20,0x0000000c);
  /* Launch DFE tuning */
  if (int_code != 0xffff)
    avago_spico_int(aapl, sbus_addr, int_code, int_dfe_data);
  do { /* Wait for PC to reach start BP */
    pc = avago_sbus_rd(aapl,sbus_addr,0x25) & 0xFFFF;
  } while ( (pc != tune_start) && (pc != vos_start) );

  /* Load the Tuning BreakPoint addresses, BP2 = 31:16, BP1 = 15:0 */
  avago_sbus_wr(aapl,sbus_addr,0x21,(dfe_tune_done<<16)+error_timer_done);

  /* Disable logging while looping through status */
  n = 0;
  do {
    do { /* Wait for PC to reach a BP */
      pc = avago_sbus_rd(aapl,sbus_addr,0x25)& 0xFFFF;
      /*printf("pc: 0x%04x\n", pc); */
      /*avago_spico_diag_line(aapl, sbus_addr, hexfile, str, j); */
    } while ( (pc != dfe_tune_done) && (pc != error_timer_done) );
    /* Assert SS_EN along with BP_ENs */
    avago_sbus_wr(aapl,sbus_addr,0x20,0x0000000d);
    prev_state = serdes_dfe_logger_print_state(aapl,sbus_addr,dmem,n,prev_state,data_saved);

    /*printf("status: 0x%04x\n", dfe_status); */
    if (pc != dfe_tune_done && (dfe_status & 0x33) == 0) {
      printf("NOTE: dfe status indicates done, force pc to dfe_tune_done\n");
      pc = dfe_tune_done;  /* force done */
    }

/* DEBUG, invoke stepping */
/*    if (n == 3966) { */
/*      printf("NOTE: changing to SINGLE STEPPING\n"); */
/*      cycles = 10000; */
/*      initial_state = avago_spico_halt(aapl, sbus_addr); */
/*      for (cycle = 0; cycle < cycles; cycle++) */
/*      { */
/*        avago_spico_diag_line(aapl, sbus_addr, hexfile, str, cycle); */
/*        avago_spico_single_step(aapl, sbus_addr, initial_state); // single step */
/*      } */
/*      avago_sbus_wr(aapl,sbus_addr,0x01,0x20000000); // Clear AVAGO_DMEM overrides */
/*      avago_sbus_wr(aapl,sbus_addr,0x20,0x00000000); // Clear BP_ENs and SS_EN */
/*      return; */
/*    } */

    /* Assert single step */
    avago_sbus_wr(aapl,sbus_addr,0x20,0x0000000f);
    /* Clear SS_EN, leave BP_EN high */
    avago_sbus_wr(aapl,sbus_addr,0x20,0x0000000c);
    n++;
  } while (pc != dfe_tune_done);
  /* End of loop, set logging back to previous setting. */

  if (int_code != 0xffff) {
    /* Clear AVAGO_DMEM overrides */
    avago_sbus_wr(aapl,sbus_addr,0x01,0x20000000);
    /* Clear BP_ENs and SS_EN */
    avago_sbus_wr(aapl,sbus_addr,0x20,0x00000000);
  }
}


/* serdes_dfe_logger_print_state() */
/* */
/* Takes the tablefile pointer and reads it to find the addresses */
/* of all the required AVAGO_DMEM locations and two AVAGO_IMEM labels */
/* */
static int serdes_dfe_logger_print_state(Aapl_t *aapl, unsigned int sbus_addr, int *dmem, int num, int prev_state, int *data_saved)
{
  int i;
  int data;
  int temp;
  int prev_data=0;
  int cur_state=0;
  int data_signed;
  int prev_data_signed=0;
  Avago_process_id_t process = aapl_get_process_id(aapl,sbus_addr);

  int gen2_lsb = 0;
  int m4_lsb   = 0;
  if( process == AVAGO_TSMC_16 || process == AVAGO_TSMC_07 || aapl_get_lsb_rev(aapl, sbus_addr) > 4 )
    gen2_lsb = 1;
  if( aapl_get_ip_type(aapl, sbus_addr) == AVAGO_M4 )
    m4_lsb = 1;

  if ((num % 100) == 0) serdes_dfe_logger_print_header();

  printf("%-6d",num);
  for(i=0;i<dfe_dmem_entries; i++)
  {
    int skip = 0;
    int pipe = 0;
    int no_space = 0;
    int char_count = 2;
    int signed_var=0;
    int skip_read=0;
    if ( (i==11) || (i==12) ) { /* EDGE VOS */
      skip_read = 1;
    }
    if (cur_state == 6) { /* In DFE state, skip CTLE, VOS, DVOS, LOOP_COUNTS */
      if ( (i >=  1) && (i <= 12) ) { skip_read = 1; }  /* CTLE,VOS */
      if ( (i >= 27) && (i <= 42) ) { skip_read = 1; }  /* DVOS,LOOP */
    } else {              /* NOT DFE, skip DFE taps and gainDFE */
      if (i==13) { skip_read = 1;}
      if ( (i >= 15) && (i <= 26) ) { skip_read = 1; }
    }
    if (cur_state == 9) { /* In lev_fine, skip CTLE */
      if ( (i >=  1) && (i <= 4) ) { skip_read = 1; }   /* CTLE */
    } else {              /* NOT lev_fine, skip DVOS, LOOP */
      if ( (i >= 27) && (i <= 42) ) { skip_read = 1; }  /* DVOS,LOOP */
    }
    /* Always update on state transitions and dfe_state */
    if ( (prev_state !=0 ) && (prev_state == cur_state) && (i>0) && skip_read ) {
      data = *(data_saved+i);
    } else {
      if ( dmem[i] < 0 ) {   /* AVAGO_ESB address, only one atm is PFD */
        if(process == AVAGO_TSMC_16) {
            avago_serdes_mem_wr(aapl,sbus_addr,AVAGO_LSB_DIRECT,0x30,0x80); /* AVAGO_ESB_ADDR 0x80 */
            data  = (avago_serdes_mem_rd(aapl,sbus_addr,AVAGO_LSB_DIRECT,0x32) >> 1) & 0x01;/* AVAGO_ESB_ADDR 0x80 */
            avago_serdes_mem_wr(aapl,sbus_addr,AVAGO_LSB_DIRECT,0x30,0x93); /* AVAGO_ESB_ADDR 0x93 */
            temp = (avago_serdes_mem_rd(aapl,sbus_addr,AVAGO_LSB_DIRECT,0x32) >> 8) & 0x0f;
            /* Hertz */
            if (temp == 4) data += 0x10;
            if (temp == 8) data += 0x30;
            /* Maxwell */
            /*if (temp == 8) data += 0x10; */
            /*if (temp == 4) data += 0x30; */
        } else {
          avago_serdes_mem_wr(aapl,sbus_addr,AVAGO_LSB_DIRECT,0x30,0x00); /* AVAGO_ESB_ADDR 0x0 */
          data  = (avago_serdes_mem_rd(aapl,sbus_addr,AVAGO_LSB_DIRECT,0x32) >> 10) & 0x01;/* AVAGO_ESB_ADDR 0x00 */
          avago_serdes_mem_wr(aapl,sbus_addr,AVAGO_LSB_DIRECT,0x30,0x30); /* AVAGO_ESB_ADDR 0x30 */
          data += avago_serdes_mem_rd(aapl,sbus_addr,AVAGO_LSB_DIRECT,0x32) & 0x30;  /* AVAGO_ESB_ADDR 0x30 */
        }
        /*sbus_wr(aapl,sbus_addr,0x02,0x00300000); // 0x30 AVAGO_ESB ADDR */
        /*sbus_wr(aapl,sbus_addr,0x02,0x80300000); // 0x30 AVAGO_ESB ADDR */
        /*sbus_wr(aapl,sbus_addr,0x02,0x00320000); // 0x32 AVAGO_ESB READ_DATA */
        /*sbus_wr(aapl,sbus_addr,0x02,0x80320000); // 0x32 AVAGO_ESB READ_DATA */
        /*data = ( avago_sbus_rd(aapl,sbus_addr,0x40) & 0x00000400 ) >> 10; // PFD is [10] of AVAGO_ESB 0x00 */
        /*sbus_wr(aapl,sbus_addr,0x02,0x00300030); // 0x30 AVAGO_ESB ADDR */
        /*sbus_wr(aapl,sbus_addr,0x02,0x80300030); // 0x30 AVAGO_ESB ADDR */
        /*sbus_wr(aapl,sbus_addr,0x02,0x00320000); // 0x32 AVAGO_ESB READ_DATA */
        /*sbus_wr(aapl,sbus_addr,0x02,0x80320000); // 0x32 AVAGO_ESB READ_DATA */
        /*data = ( avago_sbus_rd(aapl,sbus_addr,0x40) & 0x00000400 ) >> 10; // PFD is [10] of AVAGO_ESB 0x00 */
      } else {
        if (dmem[i] < 512) {  /* Test for DMA v. AVAGO_DMEM */
            if(process == AVAGO_TSMC_16) {
                avago_sbus_wr(aapl,sbus_addr,0x01,0x60000000|(dmem[i] & 0x000003FF));
                data = ( avago_sbus_rd(aapl,sbus_addr,0x01) >> 12 ) & 0x0000FFFF;
            } else {
                avago_sbus_wr(aapl,sbus_addr,0x02,(dmem[i] << 16) & 0x00FF0000);
                data = avago_sbus_rd(aapl,sbus_addr,0x40) & 0x0000FFFF;
            }
        } else {
          avago_sbus_wr(aapl,sbus_addr,0x01,0x60000000|(dmem[i] & 0x000003FF)); 
          data = ( avago_sbus_rd(aapl,sbus_addr,0x01) >> 12 ) & 0x0000FFFF;
        }
      }
    }
    *(data_saved+i) = data;
    if (data & 0x8000) {
      data_signed = -1 * ((data ^ 0xFFFF) + 1);
    } else {
      data_signed = data;
    }
    switch(i) {
      case 0 : { const char *state;
                 switch(data) {
                   case 0 : state = "idle"; break;
                   case 1 : state = "dfe_vos"; break;
                   case 3 : state = "dlev_coars"; break;
                   case 4 : state = "tlev_coars"; break;
                   case 5 : state = "tlev_fine"; break;
                   case 6 : state = "dfe"; break;
                   case 7 : state = "dcgain"; break;
                   case 9 : state = "dlev_fine"; break;
                   case 10: state = "dfe_broke"; break;
                   case 11: state = "update_lev"; break;
                   case 13: state = "vos_cross"; break;
                   case 14: state = "pcal_done"; break;
                   case 15: state = "ical_done"; break;
                   default: state = "unknown"; break;
                 }
                 printf("%-12s",state);
                 skip = 1;
                 cur_state = data;
                 break;
               }
      case 5 : { pipe = 1; break;} /* Before vos_d0e */
      case 9 : { pipe = 1; break;} /* Before vos_t1e */
      case 13: { pipe = 1; break;} /* Before gainDFE */
      case 14:
      case 15:
      case 16:
      case 17:
      case 18:
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
      case 24:
      case 25:
      case 26: {signed_var = 1; break;}
      case 27: { pipe = 1; skip = 1; break;}      /* Before data height */
      case 28: { data = abs(prev_data_signed - data_signed); break;} /* Calculate d0e height */
      case 29: { skip = 1;  break;}               /* skip d0o_lo */
      case 30: { data = abs(prev_data_signed - data_signed); break;} /* Calculate d0o height */
      case 31: { skip = 1;  break;}               /* skip d1e_lo */
      case 32: { data = abs(prev_data_signed - data_signed); break;} /* Calculate d1e height */
      case 33: { skip = 1;  break;}               /* skip d1o_lo */
      case 34: { data = abs(prev_data_signed - data_signed); break;} /* Calculate d1o height */
      case 35: { pipe = 1; skip = 1; break;}      /* Before test height */
      case 36: { data = abs(prev_data_signed - data_signed); break;} /* Calculate t_d0e height */
      case 37: { skip = 1;  break;}               /* skip t_d0o_lo */
      case 38: { data = abs(prev_data_signed - data_signed); break;} /* Calculate t_d0o height */
      case 39: { skip = 1;  break;}               /* skip t_d1e_lo */
      case 40: { data = abs(prev_data_signed - data_signed); break;} /* Calculate t_d1e height */
      case 41: { skip = 1;  break;}               /* skip t_d1o_lo */
      case 42: { data = abs(prev_data_signed - data_signed); break;} /* Calculate t_d1o height */
      case 43: { pipe = 1; break;} /* Before tap_loops */
      case 45: { pipe = 1; char_count = 1; data = (data >> 14) & 0x0003; printf(" "); no_space=1;break;} /* FLOCK,DISABLE_FLOCK_CHECKS */
      case 46: { char_count = 2; break;}          /* PFD */
      case 47: { pipe = 1; skip=1;break;} /* Before min_errors */
      case 48: { data = data + (prev_data << 16); char_count = 8; no_space=1; break;} /* min_error_count */
      case 49: { skip=1;break;}          
      case 50: { data = data + (prev_data << 16); char_count = 8; break;} /* error_count */
      case 51: { skip=1;break;}          
      case 52: { data = data + (prev_data << 16); char_count = 8; break;} /* error_chk_count */
      case 53: { pipe = 1; skip = 1; break;} /* Before mask */
      /*case 53: { skip = 1; break;} // Before mask */
      case 54: { if (m4_lsb  ) {char_count = 4; no_space=1;} else {skip=1;}  break;} /* Mask 79:64 */
      case 55: { if (m4_lsb  ) {char_count = 4; no_space=1;} else {skip=1;}  break;} /* Mask 64:48 */
      case 56: { if (gen2_lsb) {char_count = 4; no_space=1;} else {skip=1;}  break;} /* Mask 47:32 */
      case 57: { if (gen2_lsb) {char_count = 4; no_space=1;} else {skip=1;}  break;} /* Mask 31:16 */
      case 58: { if (gen2_lsb) {char_count = 4; no_space=1; break; } else            /* Mask 15:0 */
                 {data = data | ((prev_data & 0xF000) << 4); char_count = 5; no_space=1; break;}
               } /* Mask */
      case 59: { char_count = 4; break;} /* Compare mode */
      case 60: { char_count = 4; break;} /* qual */
      case 61: { if (m4_lsb  ) {char_count = 4;                        } else skip = 1; break;} /* qual 63:48 */
      case 62: { if (m4_lsb  ) {char_count = 4;             no_space=1;} else skip = 1; break;} /* qual 47:32 */
      case 63: { if (m4_lsb  ) {char_count = 4;             no_space=1;} else skip = 1; break;} /* qual 31:16 */
      case 64: { if (gen2_lsb) {char_count = 4; if (m4_lsb) no_space=1;} else skip = 1; break;} /* qual 15:0 */
      case 65: { pipe=1; no_space=1; char_count = 2; break;}  /* bestDC */
      case 66:                                                /* bestLF */
      case 67: { char_count = 2; break; }                     /* bestHF */
      case 68:                                                /* bestT1P0 */
      case 69: { char_count = 4; break; }                     /* bestT1P1 */
      case 70:                                                /* bestEyeP0 */
      case 71: { char_count = 2; break;}                      /* bestEyeP1 */
      case 72: { pipe=1; }
      case 73:
      case 74: { char_count = 2; break;} /* DC loop range */
      case 75: { pipe=1; }
      case 76:
      case 77: { char_count = 1; break;} /* LF loop range */
      case 78: { pipe=1; }
      case 79:
      case 80: { char_count = 1; break;} /* HF loop range */
      case 81: { skip=1; dfe_status=data;break;}
      /* FOR_HERTZ */
      case 82: { pipe=1;skip=1;break;}
      case 83: { data = data + (prev_data << 16); char_count = 8; break;} /* error_reg */
      default: break;
    }
    if (pipe) {
      printf("|");
    }
    if (!skip) {
      if (!no_space) {
        printf(" ");
      }
      switch(char_count) {
        case 1 : {printf("%x",data); break;}
        case 4 : {printf("%04x",data); break;}
        case 5 : {printf("%05x",data); break;}
        case 8 : {
                   if (data == 0) {
                     printf("........");  /* Substitute 0's with ......... for easier parsing */
                   } else {
                     printf("%08x",data);
                   }
                   break;
                 }
        default: {
                   if (signed_var) {
                     if (data > 128) {
                       printf("-%x", (data ^ 0xFFFF) + 1);
                     } else {
                       printf("%02x",data); 
                     }
                   } else {
                     printf("%02x",data); 
                   }
                   break;
                 }
      }
    }
    prev_data = data;
    prev_data_signed = data_signed;
  }
  printf("\n");
  avago_sbus_wr(aapl,sbus_addr,0x01,0x20000000); /* clear dmem override */
  return cur_state;
}
/* S E R D E S   D F E   L O G G E R   P R I N T   H E A D E R */
/*  */
/* Print the header for the columns of data comping out */
/* */
static void serdes_dfe_logger_print_header()
{

  int i;
  char header[144];

#ifdef HAL_BASED_LOGGER
  printf("\n%-6s","cnt   state        DC LF HF BW|d0e 0o 1e 1o|t1e 1o 0e 0o| DG T1  2  3  4  5  6  7  8  9  a  b  c  d| data height| test height|tap pCl|cFerr|min_errs   error1   error2| mask        cmp  cmpE qual|DC LF HF T1P0 T1P1 EyeP0|Loop: DC |LF    |HF \n");
  return;
#endif

  printf("\n%-6s","cnt");
  for(i=0;i<dfe_dmem_entries; i++)
  {
    int skip = 0;
    int pipe = 0;
    int no_space = 0;
    const char *entry = dfe_logger_dmem_labels[i];
    if ( strstr(entry,"PFD") )        { skip = 1;}
    if ( strstr(entry,"clk_sel") )    { skip = 1;}
    if ( strstr(entry,"_lo") )        { skip = 1;}
    if ( strstr(entry,"start") )      { skip = 1;}
    if ( strstr(entry,"step") )       { strcpy(header,"  ");}
    if ( strstr(entry,"dfe_state") ) { printf("%-12s","state"); skip =1;}
    if ( strstr(entry,"best") ) { strcpy(header,entry+4); }
    if ( strstr(entry,"stop") ) { strcpy(header,entry+4); pipe=1;}
    if ( strstr(entry,"gain") ) { strcpy(header,entry+4); }
    if ( strstr(entry,"vos_") ) { strcpy(header,entry+5); }
    if ( strstr(entry,"d6_alpha") ) { strcpy(header," 1"); }
    if ( strstr(entry,"dvos") ) { 
      skip = 1;
      if ( strstr(entry,"dvos_d0e_hi") ) { 
        strcpy(header," data height"); 
        skip = 0;
        pipe = 1;
        no_space = 1;
      }
      if ( strstr(entry,"dvos_t1e_0_hi") ) { 
        strcpy(header," test height"); 
        skip = 0;
        pipe = 1;
        no_space = 1;
      }
    }
    if ( strstr(entry,"d6_tap") )     { strcpy(header,"tp"); pipe=1; skip = 0;no_space=1;}
    if ( strstr(entry,"d6_pCal") )    { strcpy(header," pC"); skip = 0;no_space=1;}
    if ( strstr(entry,"cal_timer") )  { strcpy(header,"PLL"); pipe=1;no_space=0;}
    if ( strstr(entry,"error") )      { strcpy(header,"errors"); }
    if ( strstr(entry,"min_errors") ) { strcpy(header,"min_errs"); pipe=1;}
    if ( strstr(entry,TC_CNTR) )      { strcpy(header,"  err_chks"); no_space=1;}
    if ( strstr(entry,"compare") )    { strcpy(header,"cmp "); }
    if ( strstr(entry,"mask") )       { strcpy(header,entry+8); printf("| ");}
    if (!strncmp(entry,"compare_mask_",13)){skip=1;}
    if ( strstr(entry,"enable") )     { strcpy(header,"qual"); no_space=1;}
    if ( strstr(entry,"save") )       { strcpy(header,"debug"); }
    if (!strcmp(entry,"gainBW") )     { no_space=1;}
    if (!strcmp(entry,"vos_d0e") )    { printf("   |d");}
    if (!strcmp(entry,"vos_t1e") )    { printf("|t");}
    if (!strcmp(entry,"vos_d1o") )    { no_space=1;}
    if (!strcmp(entry,"vos_t0o") )    { no_space=1;}
    if (!strcmp(entry,"gainDFE") )    { strcpy(header,"gD "); pipe=1;}
    if (!strcmp(entry,"gainD") )      { no_space=1;}
    if (!strcmp(entry,"save_vos_e") ) { pipe=1;}
    if (!strcmp(entry,"save_vos_o") ) { skip=1;}
    if (!strcmp(entry,"temp_p") )     { skip=1;}
    if (!strcmp(entry,"min_i") )      { skip=1;}
    if (!strcmp(entry,"debug_") )     { skip=1;}
    if (!strcmp(entry,"eye_") )       { skip=1;}
    if (!strcmp(entry,"gainDC_step") ){ skip=1;}
    if (!strcmp(entry,"bestDC") )     { pipe=1;}
    if (!strcmp(entry,"bestEyeP0") )  { strcpy(header,"EyeP0"); no_space=1;}
    if (!strcmp(entry,"bestEyeP1") )  { skip=1;}
    if (!strcmp(entry,"stopDC") )     { strcpy(header,"LOOPS: DC"); no_space=1;}
    if (!strcmp(entry,"stepDC") )     { skip=1;}
    /* FOR_HERTZ */
    if ( strstr(entry,"error_reg") )      { strcpy(header,"  err_reg");; pipe=1; }
    if (strlen(header) < 2) {printf(" ");} /* Insert space for gain taps */
    if (!skip) {
      if (pipe) {
        printf("|");
      }
      printf("%s",header);
      if (!no_space) {
        printf(" ");
      }
    }
  }
  printf("\n");
}

/* serdes_dfe_logger_parse_table_file() */
/*  */
/* Takes the tablefile pointer and reads it to find the addresses */
/* of all the required AVAGO_DMEM locations and two AVAGO_IMEM labels */
static uint serdes_dfe_logger_parse_table_file(Aapl_t *aapl, 
                                               const char *tablefile,     
                                               int *dmem, 
                                               int *error_label, 
                                               int *done_label, 
                                               int *tune_start, 
                                               int *vos_start)
{
#if !AAPL_ENABLE_FILE_IO
(void)aapl;
(void)tablefile;
(void)dmem;
(void)error_label;
(void)done_label;
(void)tune_start;
(void)vos_start;
#else
  FILE * file;
  char line[200];

  printf("File to read %s\n",tablefile);
  file = fopen(tablefile, "r"); /* open file as read only */
  if (!file) {
    aapl_fail(aapl, __func__, __LINE__, "Couldn't open file %s.\n", tablefile);
    return 1;
  }

  while (fgets (line, sizeof line, file) != NULL) {
    char label[100] = "";
    char addr[5] = "";
    char hex[7] = "";
    char type[11] = "";
    uint  num = 0;
    sscanf(line,"%99s %4s %10s",label,addr,type);
    /* Create an int of the address */
    strcpy(hex,"0x");
    strcat(hex,addr);
    sscanf(hex,"%6x",&num);
    /* Check if we've already have set labels, and go onto AVAGO_DMEM_LABEL check if so */
    if ( (!*error_label || !*done_label || !*tune_start || !*vos_start) 
        && !strcmp(type,"IMEM_LABEL") ) {
      if (!strcmp(label,"get_errors_rtn") ) 
        *error_label = num;
      if (!strcmp(label,"get_errors_wait") )
        *error_label = num+6;
      if (!strcmp(label,"d6_dfe_jmp_to_main") )
        *done_label = num;
      if (!strcmp(label,"d6_find_vos") )
        *vos_start = num;
      if (!strcmp(label,"d6_run_tuning") )
        *tune_start = num;
      if (!strcmp(label,"run_tuning") )
        *tune_start = num;
    }  else {
      if (!strcmp(type,"DMEM_LABEL") ) {
        int i = 0;
        if ( (!strncmp(label,"reg_esb_",8)) || (!strncmp(label,"reg_lsb_",8)) )
            strncpy(label,label+8,92);
        /* Check if we save this label */
        do {
          if (!strcmp(label,dfe_logger_dmem_labels[i]) ) {
            *(dmem+i) = num;
            i = dfe_dmem_entries;
          } /* Match label X */
          else {
            /* esb and lsb symbols were changed to add a prefix "reg_esb_" or "reg_lsb_" */
            char *p = label + strlen("reg_esb_");
            if (!strcmp(p,dfe_logger_dmem_labels[i]) ) {
              *(dmem+i) = num;
              i = dfe_dmem_entries;
            } /* Match label X */
          }
          i++;
        } while (i<dfe_dmem_entries);
      } /* AVAGO_DMEM_LABEL */
    } /* AVAGO_IMEM_LABEL */
  } /* File reading */
  fclose(file);
#endif /* AAPL_ENABLE_FILE_IO */
  return 0;
}
#endif /* AAPL_ENABLE_DIAG && AAPL_ENABLE_FILE_IO */
