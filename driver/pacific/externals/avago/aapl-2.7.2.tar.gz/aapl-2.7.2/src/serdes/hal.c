/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */

/** Doxygen File Header */
/** @file hal.c */
/** @brief AAPL (ASIC and ASSP Programming Layer) support for HAL structure reading and writing. */


#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

/** @cond INTERNAL */

#define FIELD_INDEX(st,field) (&st->field - (short *)st)
#define HAL_READ( aapl, addr, hal, st, field) st->field = (short) avago_serdes_hal_get(aapl, addr, hal, FIELD_INDEX(st,field))
#define HAL_WRITE(aapl, addr, mask, hal, st, field) if( mask & (1 << FIELD_INDEX(st, field)) ) avago_serdes_hal_set(aapl, addr, hal, FIELD_INDEX(st,field), st->field)
#define HAL_PRINT(aapl, buf, buf_end, size, mask, st, field, str) if( mask & (1 << FIELD_INDEX(st, field)) ) aapl_buf_add(aapl, &buf, &buf_end, &size, "%s: %3d", str, st->field)

#define HAL_HPRINT(aapl, buf, buf_end, size, mask, st, field) if( mask & ((bigint)1 << FIELD_INDEX(st, field)) ) aapl_buf_add(aapl, &buf, &buf_end, &size, "\n    %-25s : 0x%04x", #field, st->field & 0xffff)
#define HAL_DPRINT(aapl, buf, buf_end, size, mask, st, field) if( mask & ((bigint)1 << FIELD_INDEX(st, field)) ) aapl_buf_add(aapl, &buf, &buf_end, &size, "\n    %-25s : %6d", #field, st->field)

/** @brief Read hal table into params, from index begin up to, but not including, end. */
static void hal_read_table(
    Aapl_t *aapl,                /**< [in] Pointer to Aapl_t structure. */
    uint addr,                   /**< [in] Device address number. */
    Avago_serdes_hal_type_t hal, /**< [in] Which table to read. */
    uint begin,                  /**< [in] First hal index to read. */
    uint len,                    /**< [in] Number of entries to read. */
    void *params)                /**< [out] Results array/structure. */
{
    uint index;
    short *array = (short *)params;
    for( index = 0; index < len; index++ )
        array[index] = (short) avago_serdes_hal_get(aapl, addr, hal, begin + index);
}

/** @brief Write hal indices from begin up to but not including end into params. */
/** @brief Write params into hal table, from index begin up to, but not including, end. */
static void hal_write_table(
    Aapl_t *aapl,                /**< [in] Pointer to Aapl_t structure. */
    uint addr,                   /**< [in] Device address number. */
    uint mask,                   /**< [in] Select fields to write. */
    Avago_serdes_hal_type_t hal, /**< [in] Which table to write. */
    uint begin,                  /**< [in] First index to write. */
    uint len,                    /**< [in] Number of entries to write. */
    void *params)                /**< [in] Data to write. */
{
    uint index;
    short *array = (short *)params;
    for( index = 0; index < len; index++ )
        if( mask & (1 << index) )
            avago_serdes_hal_set(aapl, addr, hal, begin + index, array[index]);
}

static int avago_serdes_ctle_table_size(Aapl_t *aapl, uint addr)
{
    int table_size = sizeof(Avago_serdes_ctle_t) / sizeof(short);
    int sdrev = aapl_get_sdrev(aapl, addr);
    if( sdrev == AAPL_SDREV_D6_07 )
        table_size = 4; /* gainshape only on CM4 */
    else if( sdrev != AAPL_SDREV_CM4_16 )
        table_size = 6; /* short_channel_en is valid only for CM4 */
    else if( !aapl_check_firmware_rev(aapl, addr, __func__, __LINE__, FALSE, 1, 0x1075) )
        table_size = 7;
    return table_size;
}

/** @brief   Populates a structure with the CTLE settings limits. */
/** @details Returns values based on the specific SerDes specified. */
/** @return  On success, returns 0. */
/** @return  On failure, returns -1. */
/** @see     avago_serdes_ctle_write(), avago_serdes_ctle_validate(). */
int avago_serdes_ctle_get_limits(
    Aapl_t *aapl,                       /**< [in]  Pointer to Aapl_t structure. */
    uint addr,                          /**< [in]  Device address number. */
    Avago_serdes_ctle_limits_t *limits) /**< [out] Address of structure to populate. */
{
    int sdrev = aapl_get_sdrev(aapl, addr);

    memset(limits, 0, sizeof(*limits));
    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 4, AAPL_SDREV_CM4_16, AAPL_SDREV_D6_07, AAPL_SDREV_OM4, AAPL_SDREV_CM4) )
        return -1;

    /* OM4 SerDes */
    if( sdrev == AAPL_SDREV_OM4 )
    {
        limits->hf_max = 8; limits->lf_max = 2;
        limits->dc_max = 1; limits->bw_max = 8;
        limits->gainshape1_max = 3; limits->gainshape2_max = 3;
    }
    else if( sdrev == AAPL_SDREV_D6_07 )
    {
        limits->hf_max = 15; limits->lf_max = 31;
    }
    /* 28nm and 16nm CM4 SerDes */
    else
    {
        limits->hf_max = 15; limits->lf_max = 15;
        limits->dc_max = 255; limits->bw_max = 15;
        limits->gainshape1_max = 3; limits->gainshape2_max = 3;
        limits->short_channel_en_max = 1;
        if( sdrev == AAPL_SDREV_CM4_16 )
            limits->dc_max = 85;
    }
    return 0;
}

/** @brief Writes CTLE inputs structure to firmware. */
/** @details Retrieves limit of all values and validates that parameters are within that range. */
/** @return On success, returns 0. */
/** @return On failure, decrements aapl->return_code and returns -1. */
/** @see avago_serdes_ctle_write(), avago_serdes_ctle_get_limits(). */
int avago_serdes_ctle_validate(
    Aapl_t *aapl,              /**< [in] Pointer to Aapl_t structure. */
    uint addr,                 /**< [in] Device address number. */
    uint mask,                 /**< [in] Mask that defines which parameters to validate. */
    Avago_serdes_ctle_t *ctle) /**< [in] New set of values. */
{
    Avago_serdes_ctle_limits_t limits;
    BOOL rc = FALSE;
    int table_size = avago_serdes_ctle_table_size(aapl, addr);

    /* Get valid range of CTLE parameters */
    if( avago_serdes_ctle_get_limits(aapl, addr, &limits) != 0 )
        return -1;

    if( mask & 0x001 ) rc =       (ctle->hf < 0) || (ctle->hf > limits.hf_max);
    if( mask & 0x002 ) rc = rc || (ctle->lf < 0) || (ctle->lf > limits.lf_max);
    if( mask & 0x004 ) rc = rc || (ctle->dc < limits.dc_min) || (ctle->dc > limits.dc_max);
    if( mask & 0x008 ) rc = rc || (ctle->bw < 0) || (ctle->bw > limits.bw_max);
    if( table_size >= 5 )
        if( mask & 0x010 ) rc = rc || (ctle->gainshape1 < 0) || (ctle->gainshape1 > limits.gainshape1_max);
    if( table_size >= 6 )
        if( mask & 0x020 ) rc = rc || (ctle->gainshape2 < 0) || (ctle->gainshape2 > limits.gainshape2_max);
    if( table_size >= 7 )
        if( mask & 0x40 ) rc = (rc || (ctle->short_channel_en < 0) || (ctle->short_channel_en > limits.short_channel_en_max));
    if( table_size >= 11 )
    {
        if( mask & 0x080 ) rc = rc || (ctle->hf_min < 0) || (ctle->hf_min > limits.hf_max);
        if( mask & 0x100 ) rc = rc || (ctle->hf_max < 0) || (ctle->hf_max > limits.hf_max);
        if( mask & 0x200 ) rc = rc || (ctle->lf_min < 0) || (ctle->lf_min > limits.lf_max);
        if( mask & 0x400 ) rc = rc || (ctle->lf_max < 0) || (ctle->lf_max > limits.lf_max);
    }

    if( rc )    /* Log any failure */
    {
        char *buf = 0, *buf_end = 0;
        int size = 0;

        aapl_buf_add(aapl, &buf, &buf_end, &size, "SBus %s Invalid range of CTLE parameters.\n", aapl_addr_to_str(addr));
        aapl_buf_add(aapl, &buf, &buf_end, &size, "Valid range: hf: [0 - %d], lf: [0 - %d], dc: [%d - %d], bw: [0 - %d]", limits.hf_max, limits.lf_max, limits.dc_min, limits.dc_max, limits.bw_max);
        if( table_size >= 6 ) aapl_buf_add(aapl, &buf, &buf_end, &size, ", gainshape1: [0 - %d], gainshape2: [0 - %d]", limits.gainshape1_max, limits.gainshape2_max);
        if( table_size >= 7 ) aapl_buf_add(aapl, &buf, &buf_end, &size, ", short_channel: [0 - %d]", limits.short_channel_en_max);
        aapl_buf_add(aapl, &buf, &buf_end, &size, ".\n");

        aapl_buf_add(aapl, &buf, &buf_end, &size, "Requested  : hf: %8d, lf: %8d, dc: %8d, bw: %8d", ctle->hf, ctle->lf, ctle->dc, ctle->bw);
        if( table_size >= 6 ) aapl_buf_add(aapl, &buf, &buf_end, &size, ", gainshape1: %7d, gainshape2: %7d", ctle->gainshape1, ctle->gainshape2);
        if( table_size >= 7 ) aapl_buf_add(aapl, &buf, &buf_end, &size, ", short_channel: %7d", ctle->short_channel_en);
        aapl_buf_add(aapl, &buf, &buf_end, &size, ".\n");

        aapl_fail(aapl, __func__, __LINE__, buf);
        aapl_free(aapl, buf, __func__);
        return -1;
    }
    return 0;
}
/** @endcond */

static char *one_line(char *buf)
{
    register char *to = buf;
    register char *from = buf;
    for( from = buf; *from; from++ )
    {
        if( *from == '\n' )
        {
            if( from != buf )
                *to++ = ',';
        }
        else if( *from != ' ' )
            *to++ = *from;
        else
        {
            *to++ = ' ';
            while( from[1] == ' ' )
                from++;
        }
    }
    *to = '\0';
    return buf;
}

/** @brief  Prints selected fields of the CTLE structure to a buffer. */
/** @return On success, returns a pointer to a string which should be freed using aapl_free(). */
/** @return On failure, returns NULL. */
/** @see    avago_serdes_ctle_read(). */
char *avago_serdes_ctle_print(
    Aapl_t *aapl,                /**< [in] Pointer to Aapl_t structure. */
    uint addr,                   /**< [in] Device address number. */
    uint mask,                   /**< [in] Mask that defines which fields to print. */
    Avago_serdes_ctle_t *params) /**< [in] Values to print. */
{
    int table_size = avago_serdes_ctle_table_size(aapl, addr);
    char *buf = 0, *buf_end = 0;
    int size = 0;

    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, hf);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, lf);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, dc);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, bw);
    if( table_size >= 5 ) HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gainshape1);
    if( table_size >= 6 ) HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gainshape2);
    if( table_size >= 7 ) HAL_DPRINT(aapl, buf, buf_end, size, mask, params, short_channel_en);
    if( table_size >= 11 )
    {
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, hf_min);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, hf_max);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, lf_min);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, lf_max);
    }

    return buf;
}

/** @brief  Writes selected fields of CTLE structure to firmware, then applies settings to hardware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_ctle_read(), avago_serdes_ctle_write(), avago_serdes_ctle_validate(). */
int avago_serdes_ctle_apply(
    Aapl_t *aapl,                /**< [in] Pointer to Aapl_t structure. */
    uint addr,                   /**< [in] Device address number. */
    uint mask,                   /**< [in] Mask that defines which parameters to update. */
    Avago_serdes_ctle_t *params) /**< [in] New set of values. */
{
    int table_size = avago_serdes_ctle_table_size(aapl, addr);
    int return_code = aapl->return_code;

    if( avago_serdes_ctle_validate(aapl, addr, mask, params) != 0 )
        return -1;

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_ctle_print(aapl, addr, mask, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Write CTLE structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }

    {
        hal_write_table(aapl, addr, mask, AVAGO_HAL_RXEQ_CTLE, 0, table_size, params); /* Write to firmware. */
        avago_serdes_hal_func(aapl, addr, AVAGO_HAL_RXEQ_CTLE_APPLY);           /* Apply to hardware. */
    }

    return (aapl->return_code == return_code) ? 0 : -1;
}

/** @brief  Writes CTLE structure to firmware, then applies settings to hardware. */
/** @details Verifies that parameters are within range. */
/** @return  On success, returns 0. */
/** @return  On failure, returns -1. */
/** @see     avago_serdes_ctle_read(). */
int avago_serdes_ctle_write(
    Aapl_t *aapl,                /**< [in] Pointer to Aapl_t structure. */
    uint addr,                   /**< [in] Device address number. */
    Avago_serdes_ctle_t *params) /**< [in] New set of values. */
{
    return avago_serdes_ctle_apply(aapl, addr, ~0, params);
}

/** @brief  Reads CTLE fields from firmware and updates members of structure. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_ctle_apply(), avago_serdes_ctle_get_limits(), avago_serdes_ctle_print(), avago_serdes_ctle_validate(), avago_serdes_ctle_write(). */
int avago_serdes_ctle_read(
    Aapl_t *aapl,                /**< [in]  Pointer to Aapl_t structure. */
    uint addr,                   /**< [in]  Device address number. */
    Avago_serdes_ctle_t *params) /**< [out] Results structure. */
{
    int table_size = avago_serdes_ctle_table_size(aapl, addr);
    int return_code = aapl->return_code;

    memset(params, 0, sizeof(*params));
    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 4, AAPL_SDREV_CM4_16, AAPL_SDREV_D6_07, AAPL_SDREV_OM4, AAPL_SDREV_CM4) )
        return -1;

    hal_read_table(aapl, addr, AVAGO_HAL_RXEQ_CTLE, 0, table_size, params);

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_ctle_print(aapl, addr, ~0, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Read CTLE structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }
    return (aapl->return_code == return_code) ? 0 : -1;
}

/** @brief Populates a structure with the limits for the RxFFE settings. */
/** @details Returns values based on the specific SerDes specified. */
/** @return On success, returns 0. */
/** @return On failure, decrements aapl->return_code and returns -1. */
/** @see avago_serdes_rxffe_write(), avago_serdes_rxffe_validate(). */
int avago_serdes_rxffe_get_limits(
    Aapl_t *aapl,                        /**< [in]  Pointer to Aapl_t structure. */
    uint addr,                           /**< [in]  Device address number. */
    Avago_serdes_rxffe_limits_t *limits) /**< [out] Address of structure to populate. */
{
    int sdrev;
    int fw_build;

    memset(limits, 0, sizeof(*limits));
    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 1, AVAGO_M4) )
        return -1;

    sdrev = aapl_get_sdrev(aapl, addr);
    fw_build = aapl_get_firmware_build(aapl, addr);

    limits->bflf_max = 5; limits->bfhf_max = 8;
    limits->post1_min = -15; limits->post1_max = 15;
    limits->pre1_max = 15; limits->datarate_max = 7;
    limits->short_channel_en_max = 1;

    if( sdrev == AAPL_SDREV_OM4 )
    {
        limits->pre2_min = -7;
        limits->pre2_max = 7;
        limits->short_channel_en_max = 0;
    }

    else if( sdrev == AAPL_SDREV_CM4 )
    {
        limits->pre2_min = -3; limits->pre2_max = 3;
        limits->post1_min = -10; limits->post1_max = 10;
    }
    else if( sdrev == AAPL_SDREV_CM4_16 )
    {
        if( fw_build == 0xA085 )  /* Tesla */
        {
            limits->pre2_min = -9;
            limits->pre2_max = 9;
        }
        else /* Fermi */
        {
            limits->pre2_min = -10;
            limits->pre2_max = 10;
        }
    }

    return 0;
}

/** @cond INTERNAL */

/** @brief   Validates the RxFFE parameter values. */
/** @details Retrieves limit of all values and validate parameters within that range. */
/** @return  On success, returns 0. */
/** @return  On failure, decrements aapl->return_code and returns -1. */
/** @see     avago_serdes_rxffe_get_limits(), avago_serdes_rxffe_write(). */
int avago_serdes_rxffe_validate(
    Aapl_t *aapl,                /**< [in] Pointer to Aapl_t structure. */
    uint addr,                   /**< [in] Device address number. */
    uint mask,                   /**< [in] Mask that defines which parameters to validate. */
    Avago_serdes_rxffe_t *rxffe) /**< [in] New set of values. */
{
    BOOL rc = FALSE;
    Avago_serdes_rxffe_limits_t limits;

    if( avago_serdes_rxffe_get_limits(aapl, addr, &limits) != 0 )
        return -1;

    if( mask & 0x01 ) rc =       (rxffe->pre2 < limits.pre2_min)   || (rxffe->pre2 > limits.pre2_max);
    if( mask & 0x02 ) rc = rc || (rxffe->pre1 < 0)                 || (rxffe->pre1 > limits.pre1_max);
    if( mask & 0x04 ) rc = rc || (rxffe->post1 < limits.post1_min) || (rxffe->post1 > limits.post1_max);
    if( mask & 0x08 ) rc = rc || (rxffe->bflf < 0)                 || (rxffe->bflf > limits.bflf_max);
    if( mask & 0x10 ) rc = rc || (rxffe->bfhf < 0)                 || (rxffe->bfhf > limits.bfhf_max);
    if( mask & 0x20 ) rc = rc || (rxffe->datarate < 0)             || (rxffe->datarate > limits.datarate_max);
    if( mask & 0x080 ) rc = rc || (rxffe->pre1_min < 0)            || (rxffe->pre1_min > limits.pre1_max);
    if( mask & 0x100 ) rc = rc || (rxffe->pre1_max < 0)            || (rxffe->pre1_max > limits.pre1_max);
    if( mask & 0x200 ) rc = rc || (rxffe->pre2_min<limits.pre2_min)|| (rxffe->pre2_min > limits.pre2_max);
    if( mask & 0x400 ) rc = rc || (rxffe->pre2_max<limits.pre2_min)|| (rxffe->pre2_max > limits.pre2_max);
    if( aapl_get_sdrev(aapl, addr) == AAPL_SDREV_CM4_16 ) /* short_channel_en is valid only for CM4 */
    {
        if( mask & 0x40 ) rc = ( rc || (rxffe->short_channel_en < 0) || (rxffe->short_channel_en > limits.short_channel_en_max) );
        if( rc )
            return aapl_fail(aapl, __func__, __LINE__, "SBus %s Invalid range of RxFFE parameters.\n"
                                   "Valid range: pre2: [%d - %d], pre1: [0 - %d], post1: [%d - %d], bflf: [0 - %d], "
                                   "bfhf: [0 - %d], datarate: [0 - %d], short_channel_en: [0 - %d].\n"
                                   "Requested:   pre2: %10d, pre1: %8d, post1: %10d, bflf: %7d, bfhf: %7d, datarate: %7d, short_channel_en: %7d.\n",
                                   aapl_addr_to_str(addr),
                                   limits.pre2_min, limits.pre2_max, limits.pre1_max, limits.post1_min, limits.post1_max,
                                   limits.bflf_max, limits.bfhf_max, limits.datarate_max,limits.short_channel_en_max,
                                   rxffe->pre2, rxffe->pre1, rxffe->post1, rxffe->bflf,
                                   rxffe->bfhf, rxffe->datarate, rxffe->short_channel_en);

    }
    if( rc )
        return aapl_fail(aapl, __func__, __LINE__, "SBus %s Invalid range of RxFFE parameters.\n"
                              "Valid range: pre2: [%d - %d], pre1: [0 - %d], post1: [%d - %d], bflf: [0 - %d], "
                              "bfhf: [0 - %d], datarate: [0 - %d].\n"
                              "Requested:   pre2: %8d, pre1: %8d, post1: %10d, bflf: %7d, bfhf: %7d, datarate: %7d.\n",
                              aapl_addr_to_str(addr),
                              limits.pre2_min, limits.pre2_max, limits.pre1_max, limits.post1_min, limits.post1_max,
                              limits.bflf_max, limits.bfhf_max, limits.datarate_max,
                              rxffe->pre2, rxffe->pre1, rxffe->post1, rxffe->bflf,
                              rxffe->bfhf, rxffe->datarate);

    return 0;
}
/** @endcond */

static int avago_serdes_rxffe_table_size(Aapl_t *aapl, uint addr)
{
    int table_size = sizeof(Avago_serdes_rxffe_t) / sizeof(short);
    if( aapl_get_sdrev(aapl, addr) != AAPL_SDREV_CM4_16 )  /* short_channel_en is valid only for CM4 */
        table_size = 6;
    else if( !aapl_check_firmware_rev(aapl, addr, __func__, __LINE__, FALSE, 1, 0x1086) )
    {
        if( !aapl_check_firmware_rev(aapl, addr, __func__, __LINE__, FALSE, 1, 0x1071) )
            table_size = 7;
        else if( !aapl_check_firmware_rev(aapl, addr, __func__, __LINE__, FALSE, 1, 0x1075) )
            table_size = 9;
        else
            table_size = 12;
    }
    return table_size;
}

/** @brief  Prints selected fields of the RxFFE structure to a buffer. */
/** @return On success, returns a pointer to a string which should be freed using aapl_free(). */
/** @return On failure, returns NULL. */
/** @see    avago_serdes_rxffe_read(); */
char *avago_serdes_rxffe_print(
    Aapl_t *aapl,                 /**< [in] Pointer to Aapl_t structure. */
    uint addr,                    /**< [in] Device address number. */
    uint mask,                    /**< [in] Mask that defines which fields to print. */
    Avago_serdes_rxffe_t *params) /**< [in] Values to print. */
{
    int table_size = avago_serdes_rxffe_table_size(aapl, addr);
    char *buf = 0, *buf_end = 0;
    int size = 0;

    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pre2);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pre1);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, post1);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, bflf);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, bfhf);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, datarate);
    if( table_size >= 7 )
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, short_channel_en);
    if( table_size >= 9 )
    {
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pre1_min);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pre1_max);
    }
    if( table_size >= 12 )
    {
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pre2_min);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pre2_max);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, bflf_ical);
    }
    if( table_size >= 14 )
    {
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, post1_min);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, post1_max);
    }

    return buf;
}

/** @brief  Writes selected fields of rxffe structure to firmware, then applies settings to hardware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_rxffe_read(), avago_serdes_rxffe_validate(), avago_serdes_rxffe_write(). */
int avago_serdes_rxffe_apply(
    Aapl_t *aapl,                 /**< [in] Pointer to Aapl_t structure. */
    uint addr,                    /**< [in] Device address number. */
    uint mask,                    /**< [in] Mask that defines which parameters to update. */
    Avago_serdes_rxffe_t *params) /**< [in] New set of values. */
{
    int table_size = avago_serdes_rxffe_table_size(aapl, addr);
    int return_code = aapl->return_code;

    if( avago_serdes_rxffe_validate(aapl, addr, mask, params) != 0 )
        return -1;

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_rxffe_print(aapl, addr, mask, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Write RxFFE structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }

    hal_write_table(aapl, addr, mask, AVAGO_HAL_RXEQ_FFE, 0, table_size, params); /* Write to firmware. */
    avago_serdes_hal_func(aapl, addr, AVAGO_HAL_RXEQ_FFE_APPLY);           /* Apply to hardware. */

    return (aapl->return_code == return_code) ? 0 : -1;
}

/** @brief  Writes rxffe structure to firmware, then applies settings to hardware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_rxffe_apply(), avago_serdes_rxffe_get_limits(), avago_serdes_rxffe_read(), avago_serdes_rxffe_validate(). */
int avago_serdes_rxffe_write(
    Aapl_t *aapl,                 /**< [in] Pointer to Aapl_t structure. */
    uint addr,                    /**< [in] Device address number. */
    Avago_serdes_rxffe_t *params) /**< [in] New set of values. */
{
    return avago_serdes_rxffe_apply(aapl, addr, ~0, params);
}

/** @brief Reads RxFFE fields from HAL register and update members of structure. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_rxffe_apply(), avago_serdes_rxffe_print(), avago_serdes_rxffe_read(), avago_serdes_rxffe_validate(). */
int avago_serdes_rxffe_read(
    Aapl_t *aapl,                 /**< [in]  Pointer to Aapl_t structure. */
    uint addr,                    /**< [in]  Device address number. */
    Avago_serdes_rxffe_t *params) /**< [out] Address of structure to update. */
{
    int return_code = aapl->return_code;
    int table_size = avago_serdes_rxffe_table_size(aapl, addr);

    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 1, AVAGO_M4) )
        return -1;

    hal_read_table(aapl, addr, AVAGO_HAL_RXEQ_FFE, 0, table_size, params);

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_rxffe_print(aapl, addr, ~0, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Read RxFFE structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }
    return (aapl->return_code == return_code) ? 0 : -1;
}

static int avago_serdes_dfe_table_size(Aapl_t *aapl, uint addr)
{
    int sdrev = aapl_get_sdrev(aapl, addr);
    int table_size = 14; /* sizeof(Avago_serdes_dfe_t) / sizeof(short); */
    if( sdrev == AAPL_SDREV_D6_07 )
        table_size = 28;
    return table_size;
}

/** @brief Populates a structure with the limits for the DFE settings. */
/** @details Returns values based on the specific SerDes specified. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_dfe_write(), avago_serdes_dfe_validate(). */
int avago_serdes_dfe_get_limits(
    Aapl_t *aapl,                      /**< [in]  Pointer to Aapl_t structure. */
    uint addr,                         /**< [in]  Device address number. */
    Avago_serdes_dfe_limits_t *limits) /**< [out] Address of structure to populate. */
{
    int sdrev = aapl_get_sdrev(aapl, addr);

    memset(limits, 0, sizeof(*limits));
    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 4, AAPL_SDREV_D6_07, AAPL_SDREV_CM4_16, AAPL_SDREV_OM4, AAPL_SDREV_CM4) )
        return -1;

    limits->gaintap_min  =  40; limits->gaintap_max  = 255;
    limits->gaintap2_min =  40; limits->gaintap2_max = 255;
    limits->gainx_min    = -31; limits->gainx_max    =  31;
    limits->gainy_min    = -15; limits->gainy_max    =  15;

    if( sdrev == AAPL_SDREV_OM4 )
    {
        limits->gaintap_min = 20; limits->gaintap2_min = 20;
    }
    else if( sdrev == AAPL_SDREV_D6_07 )
    {
        limits->gaintap_min  =  4; limits->gaintap_max  = 15;
        limits->gaintap2_min =  4; limits->gaintap2_max = 15;
    }
    return 0;
}

/** @cond INTERNAL */

/** @brief   Validates the DFE parameter values. */
/** @details Retrieves limit of all values and validate parameters within that range. */
/** @return  On success, returns 0. */
/** @return  On failure, decrements aapl->return_code and returns -1. */
/** @see     avago_serdes_dfe_get_limits(), avago_serdes_dfe_read(). */
int avago_serdes_dfe_validate(
    Aapl_t *aapl,            /**< [in] Pointer to Aapl_t structure. */
    uint addr,               /**< [in] Device address number. */
    bigint mask,             /**< [in] Mask that defines which parameters to validate. */
    Avago_serdes_dfe_t *dfe) /**< [in] New set of values. */
{
    Avago_serdes_dfe_limits_t limits;
    BOOL rc = FALSE;
    int sdrev = aapl_get_sdrev(aapl, addr);

    if( avago_serdes_dfe_get_limits(aapl, addr, &limits) != 0 )
        return -1;

    {
        /* CM4 or 7nm D6: */
        if( mask & 0x0001 ) rc =       (dfe->gaintap  < limits.gaintap_min )  || (dfe->gaintap  > limits.gaintap_max );
        if( mask & 0x0002 ) rc = rc || (dfe->gaintap2 < limits.gaintap2_min)  || (dfe->gaintap2 > limits.gaintap2_max);
        if( mask & 0x0010 ) rc = rc || (dfe->gain4    < limits.gainy_min)     || (dfe->gain4    > limits.gainy_max);
    }

    /* All: */
    if( mask & 0x0004 ) rc = rc || (dfe->gain2  < limits.gainx_min)       || (dfe->gain2  > limits.gainx_max);
    if( mask & 0x0008 ) rc = rc || (dfe->gain3  < limits.gainx_min)       || (dfe->gain3  > limits.gainx_max);
    if( mask & 0x0020 ) rc = rc || (dfe->gain5  < limits.gainy_min)       || (dfe->gain5  > limits.gainy_max);
    if( mask & 0x0040 ) rc = rc || (dfe->gain6  < limits.gainy_min)       || (dfe->gain6  > limits.gainy_max);
    if( mask & 0x0080 ) rc = rc || (dfe->gain7  < limits.gainy_min)       || (dfe->gain7  > limits.gainy_max);
    if( mask & 0x0100 ) rc = rc || (dfe->gain8  < limits.gainy_min)       || (dfe->gain8  > limits.gainy_max);
    if( mask & 0x0200 ) rc = rc || (dfe->gain9  < limits.gainy_min)       || (dfe->gain9  > limits.gainy_max);
    if( mask & 0x0400 ) rc = rc || (dfe->gain10 < limits.gainy_min)       || (dfe->gain10 > limits.gainy_max);
    if( mask & 0x0800 ) rc = rc || (dfe->gain11 < limits.gainy_min)       || (dfe->gain11 > limits.gainy_max);
    if( mask & 0x1000 ) rc = rc || (dfe->gain12 < limits.gainy_min)       || (dfe->gain12 > limits.gainy_max);
    if( mask & 0x2000 ) rc = rc || (dfe->gain13 < limits.gainy_min)       || (dfe->gain13 > limits.gainy_max);

    if( sdrev == AAPL_SDREV_D6_07 )
    {
        if( mask & 0x00010000 ) rc = rc || (dfe->o_gain2  < limits.gainx_min)     || (dfe->o_gain2  > limits.gainx_max);
        if( mask & 0x00020000 ) rc = rc || (dfe->o_gain3  < limits.gainx_min)     || (dfe->o_gain3  > limits.gainx_max);
        if( mask & 0x00040000 ) rc = rc || (dfe->o_gain4  < limits.gainy_min)     || (dfe->o_gain4  > limits.gainy_max);
        if( mask & 0x00080000 ) rc = rc || (dfe->o_gain5  < limits.gainy_min)     || (dfe->o_gain5  > limits.gainy_max);
        if( mask & 0x00100000 ) rc = rc || (dfe->o_gain6  < limits.gainy_min)     || (dfe->o_gain6  > limits.gainy_max);
        if( mask & 0x00200000 ) rc = rc || (dfe->o_gain7  < limits.gainy_min)     || (dfe->o_gain7  > limits.gainy_max);
        if( mask & 0x00400000 ) rc = rc || (dfe->o_gain8  < limits.gainy_min)     || (dfe->o_gain8  > limits.gainy_max);
        if( mask & 0x00800000 ) rc = rc || (dfe->o_gain9  < limits.gainy_min)     || (dfe->o_gain9  > limits.gainy_max);
        if( mask & 0x01000000 ) rc = rc || (dfe->o_gain10 < limits.gainy_min)     || (dfe->o_gain10 > limits.gainy_max);
        if( mask & 0x02000000 ) rc = rc || (dfe->o_gain11 < limits.gainy_min)     || (dfe->o_gain11 > limits.gainy_max);
        if( mask & 0x04000000 ) rc = rc || (dfe->o_gain12 < limits.gainy_min)     || (dfe->o_gain12 > limits.gainy_max);
        if( mask & 0x08000000 ) rc = rc || (dfe->o_gain13 < limits.gainy_min)     || (dfe->o_gain13 > limits.gainy_max);
    }

    if( rc )
    {
        return aapl_fail(aapl, __func__, __LINE__, "SBus %s Invalid range of DFE parameters.\n"
                              "Valid range: gaintap: [%d - %d], gaintap2: [%d - %d], gain2-3: [%d - %d], gain4-12: [%d - %d].\n",
                              aapl_addr_to_str(addr),
                              limits.gaintap_min, limits.gaintap_max, limits.gaintap2_min, limits.gaintap2_max,
                              limits.gainx_min, limits.gainx_max, limits.gainy_min, limits.gainy_max);
    }
    return 0;
}
/** @endcond */

/** @brief  Prints selected fields of the DFE structure to a buffer. */
/** @return On success, returns a pointer to a string which should be freed using aapl_free(). */
/** @return On failure, returns NULL. */
/** @see    avago_serdes_dfe_read(). */
char *avago_serdes_dfe_print(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                  /**< [in] Device address number. */
    bigint mask,                /**< [in] Mask that defines which fields to print. */
    Avago_serdes_dfe_t *params) /**< [in] Values to print. */
{
    char *buf = 0, *buf_end = 0;
    int size = 0;
    int table_size = avago_serdes_dfe_table_size(aapl, addr);

    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gaintap);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gaintap2);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gain2);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gain3);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gain4);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gain5);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gain6);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gain7);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gain8);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gain9);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gain10);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gain11);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gain12);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gain13);

    if( table_size >= 28 )
    {
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, o_gain2);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, o_gain3);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, o_gain4);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, o_gain5);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, o_gain6);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, o_gain7);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, o_gain8);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, o_gain9);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, o_gain10);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, o_gain11);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, o_gain12);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, o_gain13);
    }
    return buf;
}

/** @brief  Writes selected fields of DFE structure to firmware, then applies settings to hardware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see avago_serdes_dfe_write(). */
/** @see    avago_serdes_dfe_read(), avago_serdes_dfe_write(), avago_serdes_dfe_validate(). */
int avago_serdes_dfe_apply(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                  /**< [in] Device address number. */
    bigint mask,                /**< [in] Mask that defines which parameters to update. */
    Avago_serdes_dfe_t *params) /**< [in] New set of values. */
{
    int return_code = aapl->return_code;
    int table_size = avago_serdes_dfe_table_size(aapl, addr);

    if( avago_serdes_dfe_validate(aapl, addr, mask, params) != 0 )
        return -1;

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_dfe_print(aapl, addr, mask, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Write DFE structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }

    hal_write_table(aapl, addr, mask, AVAGO_HAL_RXEQ_DFE, 0, table_size, params); /* Write to firmware. */
    avago_serdes_hal_func(aapl, addr, AVAGO_HAL_RXEQ_DFE_APPLY);                  /* Apply to hardware. */

    return (aapl->return_code == return_code) ? 0 : -1;
}

/** @brief  Writes DFE structure to firmware, then applies settings to hardware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_dfe_read(). */
int avago_serdes_dfe_write(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                  /**< [in] Device address number. */
    Avago_serdes_dfe_t *params) /**< [in] New set of values. */
{
    return avago_serdes_dfe_apply(aapl, addr, ~0, params);
}


/** @brief  Reads DFE fields from firmware and updates members of structure. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_dfe_apply(), avago_serdes_dfe_get_limits(), avago_serdes_dfe_print(), avago_serdes_dfe_validate(), avago_serdes_dfe_write(). */
int avago_serdes_dfe_read(
    Aapl_t *aapl,               /**< [in]  Pointer to Aapl_t structure. */
    uint addr,                  /**< [in]  Device address number. */
    Avago_serdes_dfe_t *params) /**< [out] Address of structure to update. */
{
    int return_code = aapl->return_code;
    int table_size = avago_serdes_dfe_table_size(aapl, addr);

    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 4, AAPL_SDREV_D6_07, AAPL_SDREV_CM4_16, AAPL_SDREV_OM4, AAPL_SDREV_CM4) )
        return -1;

    hal_read_table(aapl, addr, AVAGO_HAL_RXEQ_DFE, 0, table_size, params);

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_dfe_print(aapl, addr, ~0, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Read DFE structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }
    return (aapl->return_code == return_code) ? 0 : -1;
}

static int avago_serdes_vernier_delay_table_size(Aapl_t *aapl, uint addr)
{
    Avago_ip_type_t ip_type = aapl_get_ip_type(aapl, addr);
    if( ip_type == AVAGO_SERDES )
        return 12;    /* 7nm D6 */
    return 11;    /* 16nm CM4 */
}

/** @brief  Prints selected fields of the vernier delay structure to a buffer. */
/** @return On success, returns a pointer to a string which should be freed using aapl_free(). */
/** @return On failure, returns NULL. */
/** @see    avago_serdes_vernier_delay_read(). */
char *avago_serdes_vernier_delay_print(
    Aapl_t *aapl,                         /**< [in] Pointer to Aapl_t structure. */
    uint addr,                            /**< [in] Device address number. */
    uint mask,                            /**< [in] Mask that defines which fields to print. */
    Avago_serdes_vernier_delay_t *params) /**< [in] Values to print. */
{
    char *buf = 0, *buf_end = 0;
    int size = 0;
    int table_size = avago_serdes_vernier_delay_table_size(aapl, addr);

    if( table_size == 12 )    /* 7nm D6 */
    {
        Avago_serdes_vernier_delay_d6_t *d6_params = (Avago_serdes_vernier_delay_d6_t *)params;
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, prev0_even);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, prev1_even);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, test_even);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, tap_even);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, edge_even);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, cdc_even);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, prev0_odd);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, prev1_odd);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, test_odd);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, tap_odd);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, edge_odd);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, cdc_odd);
    }
    else            /* CM4 */
    {
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, upper_even_dly);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, upper_odd_dly);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, middle_even_dly);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, middle_odd_dly);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, lower_even_dly);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, lower_odd_dly);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, test_even_dly);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, test_odd_dly);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, edge_even_dly);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, edge_odd_dly);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, tap_dly);
    }

    return buf;
}

/** @brief  Writes selected fields of vernier delay structure to firmware, then applies settings to hardware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_vernier_delay_read(), avago_serdes_vernier_delay_write(). */
int avago_serdes_vernier_delay_apply(
    Aapl_t *aapl,                         /**< [in] Pointer to Aapl_t structure. */
    uint addr,                            /**< [in] Device address number. */
    uint mask,                            /**< [in] Mask that defines which parameters to update. */
    Avago_serdes_vernier_delay_t *params) /**< [in] New set of values */
{
    int return_code = aapl->return_code;
    int max_vernier_delay = 19;
    int table_size = avago_serdes_vernier_delay_table_size(aapl, addr);

    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 2, AAPL_SDREV_CM4_16, AAPL_SDREV_D6_07) )
        return -1;

    if( ((mask & 0x001) && (params->upper_odd_dly   < -max_vernier_delay || params->upper_odd_dly   > max_vernier_delay)) ||
        ((mask & 0x002) && (params->upper_even_dly  < -max_vernier_delay || params->upper_even_dly  > max_vernier_delay)) ||
        ((mask & 0x004) && (params->middle_odd_dly  < -max_vernier_delay || params->middle_odd_dly  > max_vernier_delay)) ||
        ((mask & 0x008) && (params->middle_even_dly < -max_vernier_delay || params->middle_even_dly > max_vernier_delay)) ||
        ((mask & 0x010) && (params->lower_odd_dly   < -max_vernier_delay || params->lower_odd_dly   > max_vernier_delay)) ||
        ((mask & 0x020) && (params->lower_even_dly  < -max_vernier_delay || params->lower_even_dly  > max_vernier_delay)) ||
        ((mask & 0x040) && (params->test_odd_dly    < -max_vernier_delay || params->test_odd_dly    > max_vernier_delay)) ||
        ((mask & 0x080) && (params->test_even_dly   < -max_vernier_delay || params->test_even_dly   > max_vernier_delay)) ||
        ((mask & 0x100) && (params->edge_odd_dly    < -max_vernier_delay || params->edge_odd_dly    > max_vernier_delay)) ||
        ((mask & 0x200) && (params->edge_even_dly   < -max_vernier_delay || params->edge_even_dly   > max_vernier_delay)) ||
        ((mask & 0x400) && (params->tap_dly         < -max_vernier_delay || params->tap_dly         > max_vernier_delay)) )
        return aapl_fail(aapl, __func__, __LINE__, "%s Invalid request to set vernier delay."
                               " Valid range: [-%d..%d]\n", aapl_addr_to_str(addr), max_vernier_delay, max_vernier_delay);

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_vernier_delay_print(aapl, addr, ~0, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Write vernier delays structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }

    hal_write_table(aapl, addr, mask, AVAGO_HAL_RXCLK_SELECT, 5, table_size, params); /* Write to firmware. */
    avago_serdes_hal_func(aapl, addr, AVAGO_HAL_RXCLK_VERNIER_APPLY);                                      /* Apply to hardware. */

    return (aapl->return_code == return_code) ? 0 : -1;
}

/** @brief  Writes vernier delay structure to firmware, then applies settings to hardware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_vernier_delay_read(), avago_serdes_vernier_delay_apply(). */
int avago_serdes_vernier_delay_write(
    Aapl_t *aapl,                         /**< [in] Pointer to Aapl_t structure. */
    uint addr,                            /**< [in] Device address number. */
    Avago_serdes_vernier_delay_t *params) /**< [in] New set of values. */
{
    return avago_serdes_vernier_delay_apply(aapl, addr, ~0, params);
}

/** @brief  Reads vernier delay fields from HAL register and update the structure. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_vernier_delay_apply(), avago_serdes_vernier_delay_print(), avago_serdes_vernier_delay_write(). */
int avago_serdes_vernier_delay_read(
    Aapl_t *aapl,                         /**< [in] Pointer to Aapl_t structure. */
    uint addr,                            /**< [in] Device address number. */
    Avago_serdes_vernier_delay_t *params) /**< [in] Address of structure to update. */
{
    int return_code = aapl->return_code;
    int table_size = avago_serdes_vernier_delay_table_size(aapl, addr);

    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 2, AAPL_SDREV_CM4_16, AAPL_SDREV_D6_07) )
        return -1;

    hal_read_table(aapl, addr, AVAGO_HAL_RXCLK_SELECT, 5, table_size, params); /* Read from firmware. */

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_vernier_delay_print(aapl, addr, ~0, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Read vernier delay structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }
    return (aapl->return_code == return_code) ? 0 : -1;
}

/** @brief  Prints selected fields of the vernier cal structure to a buffer. */
/** @return On success, returns a pointer to a string which should be freed using aapl_free(). */
/** @return On failure, returns NULL. */
/** @see    avago_serdes_vernier_cal_read(). */
char *avago_serdes_vernier_cal_print(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    uint addr,                          /**< [in] Device address number. */
    uint mask,                          /**< [in] Mask that defines which fields to print. */
    Avago_serdes_vernier_cal_t *params) /**< [in] Values to print. */
{
    char *buf = 0, *buf_end = 0;
    int size = 0;
    (void)addr;

    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, upper_even_cal);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, upper_odd_cal);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, middle_even_cal);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, middle_odd_cal);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, lower_even_cal);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, lower_odd_cal);

    return buf;
}

/** @brief  Writes selected fields of vernier cal structure to firmware, then applies settings to hardware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_vernier_cal_read(), avago_serdes_vernier_cal_write(). */
int avago_serdes_vernier_cal_apply(
    Aapl_t *aapl,                         /**< [in] Pointer to Aapl_t structure. */
    uint addr,                            /**< [in] Device address number. */
    uint mask,                            /**< [in] Mask that defines which parameters to update. */
    Avago_serdes_vernier_cal_t *params) /**< [in] New set of values */
{
    int return_code = aapl->return_code;

    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 1, AVAGO_M4) )
        return -1;

    if( ((mask & 0x001) && (params->upper_odd_cal   < -9 || params->upper_odd_cal   > 10)) ||
        ((mask & 0x002) && (params->upper_even_cal  < -9 || params->upper_even_cal  > 10)) ||
        ((mask & 0x004) && (params->middle_odd_cal  < -9 || params->middle_odd_cal  > 10)) ||
        ((mask & 0x008) && (params->middle_even_cal < -9 || params->middle_even_cal > 10)) ||
        ((mask & 0x010) && (params->lower_odd_cal   < -9 || params->lower_odd_cal   > 10)) ||
        ((mask & 0x020) && (params->lower_even_cal  < -9 || params->lower_even_cal  > 10)) )
        return aapl_fail(aapl, __func__, __LINE__, "%s Invalid request to set vernier cal."
                               " Valid range: [-9..10]\n", aapl_addr_to_str(addr));

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_vernier_cal_print(aapl, addr, ~0, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Write vernier cals structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }

    hal_write_table(aapl, addr, mask, AVAGO_HAL_CLK_VERNIER_CAL, 0, sizeof(*params) / sizeof(short), params); /* Write to firmware. */
    avago_serdes_hal_func(aapl, addr, AVAGO_HAL_RXCLK_VERNIER_APPLY);                                         /* Apply to hardware. */

    return (aapl->return_code == return_code) ? 0 : -1;
}

/** @brief  Writes vernier cal structure to firmware, then applies settings to hardware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_vernier_cal_read(), avago_serdes_vernier_cal_apply(). */
int avago_serdes_vernier_cal_write(
    Aapl_t *aapl,                         /**< [in] Pointer to Aapl_t structure. */
    uint addr,                            /**< [in] Device address number. */
    Avago_serdes_vernier_cal_t *params) /**< [in] New set of values. */
{
    return avago_serdes_vernier_cal_apply(aapl, addr, ~0, params);
}

/** @brief  Reads vernier cal fields from HAL register and update the structure. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_vernier_cal_apply(), avago_serdes_vernier_cal_print(), avago_serdes_vernier_cal_write(). */
int avago_serdes_vernier_cal_read(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    uint addr,                          /**< [in] Device address number. */
    Avago_serdes_vernier_cal_t *params) /**< [in] Address of structure to update. */
{
    int return_code = aapl->return_code;

    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 1, AVAGO_M4) )
        return -1;

    hal_read_table(aapl, addr, AVAGO_HAL_CLK_VERNIER_CAL, 0, sizeof(*params) / sizeof(short), params); /* Read from firmware. */

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_vernier_cal_print(aapl, addr, ~0, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Read vernier cal structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }
    return (aapl->return_code == return_code) ? 0 : -1;
}

static int avago_serdes_global_tune_params_table_size(Aapl_t *aapl, uint addr)
{
    int table_size = sizeof(Avago_serdes_global_tune_params_t) / sizeof(short);
    if( !aapl_check_firmware_rev(aapl, addr, __func__, __LINE__, FALSE, 1, 0x1071) )
        table_size = 25;   /* ical_effort is last entry on older firmware */
    else if( !aapl_check_firmware_rev(aapl, addr, __func__, __LINE__, FALSE, 1, 0x1075) )
        table_size = 26;
    return table_size;
}

/** @brief  Prints selected fields of the global tune params structure to a buffer. */
/** @return On success, returns a pointer to a string which should be freed using aapl_free(). */
/** @return On failure, returns NULL. */
/** @see    avago_serdes_global_tune_params_read(). */
char *avago_serdes_global_tune_params_print(
    Aapl_t *aapl,                              /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                 /**< [in] Device address number. */
    uint mask,                                 /**< [in] Mask that defines which fields to print. */
    Avago_serdes_global_tune_params_t *params) /**< [in] Values to print. */
{
    int table_size = avago_serdes_global_tune_params_table_size(aapl, addr);
    char *buf = 0, *buf_end = 0;
    int size = 0;

    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, error_threshold);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, nrz_ctle_dwell_1ex);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, nrz_ctle_lf_dwell_shift);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, eye_oversample);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pam4_ctle_dwell_1ex);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pam4_dvos_dwell_1ex);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pam4_dvos_pcal_dwell_1ex);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, lms_dwell_1ex);
    HAL_HPRINT(aapl, buf, buf_end, size, mask, params, ctle_fixed);
    HAL_HPRINT(aapl, buf, buf_end, size, mask, params, rxffe_fixed);
    HAL_HPRINT(aapl, buf, buf_end, size, mask, params, dfe_fixed);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gaintap_max_min);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gaintap2_max_min);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pCal_loops);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, disable_one_shot_pcal);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, lms_pcal_dwell_1ex);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, dcr_pcal_dwell_1ex);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pCal_delay);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, iq_cal_interleave_disable);
    HAL_HPRINT(aapl, buf, buf_end, size, mask, params, ctle_lfhf_max_min);
    HAL_HPRINT(aapl, buf, buf_end, size, mask, params, ctle_dc_max_min);
    HAL_HPRINT(aapl, buf, buf_end, size, mask, params, vernier_fixed);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, prbs_tune_mode);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, gradient_options);
    HAL_HPRINT(aapl, buf, buf_end, size, mask, params, ical_effort);
    if( table_size >= 26 )
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, use_rx_clock_cal_values);
    if( table_size >= 28 )
    {
        HAL_HPRINT(aapl, buf, buf_end, size, mask, params, latch_fail);
        HAL_HPRINT(aapl, buf, buf_end, size, mask, params, delta_cal_fail);
    }

    return buf;
}

/** @brief  Writes selected fields of global tune params structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_global_tune_params_read(), avago_serdes_global_tune_params_write(). */
int avago_serdes_global_tune_params_apply(
    Aapl_t *aapl,                              /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                 /**< [in] Device address number. */
    uint mask,                                 /**< [in] Mask that defines which parameters to update. */
    Avago_serdes_global_tune_params_t *params) /**< [in] New set of values. */
{
    int table_size = avago_serdes_global_tune_params_table_size(aapl, addr);
    int return_code = aapl->return_code;

    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 1, AVAGO_M4) )
        return -1;

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_global_tune_params_print(aapl, addr, mask, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Write global tune params structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }

    hal_write_table(aapl, addr, mask, AVAGO_HAL_GLOBAL_TUNE_PARAMS, 0, table_size, params); /* Write to firmware. */

    return (aapl->return_code == return_code) ? 0 : -1;
}

/** @brief Writes global tune parameters fields if fields are valid. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_global_tune_params_apply(). */
int avago_serdes_global_tune_params_write(
    Aapl_t *aapl,                              /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                 /**< [in] Device address number. */
    Avago_serdes_global_tune_params_t *params) /**< [in] New set of values. */
{
    return avago_serdes_global_tune_params_apply(aapl, addr, ~0, params);
}

/** @brief Reads global tune parameters fields from HAL register and update members of structure. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_global_tune_params_apply(), avago_serdes_global_tune_params_print(), avago_serdes_global_tune_params_write(). */
int avago_serdes_global_tune_params_read(
    Aapl_t *aapl,                              /**< [in]  Pointer to Aapl_t structure. */
    uint addr,                                 /**< [in]  Device address number. */
    Avago_serdes_global_tune_params_t *params) /**< [out] Results structure. */
{
    int table_size = avago_serdes_global_tune_params_table_size(aapl, addr);
    int return_code = aapl->return_code;

    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 1, AVAGO_M4) )
        return -1;

    hal_read_table(aapl, addr, AVAGO_HAL_GLOBAL_TUNE_PARAMS, 0, table_size, params);

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_global_tune_params_print(aapl, addr, ~0, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Read global tune params structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }
    return (aapl->return_code == return_code) ? 0 : -1;
}

static int avago_serdes_gradient_inputs_table_size(Aapl_t *aapl, uint addr)
{
    int table_size = sizeof(Avago_serdes_global_tune_params_t) / sizeof(short);
    if( !aapl_check_firmware_rev(aapl, addr, __func__, __LINE__, FALSE, 1, 0x1075) )
        table_size = 9;
    return table_size;
}

/** @brief  Prints selected fields of the gradient inputs structure to a buffer. */
/** @return On success, returns a pointer to a string which should be freed using aapl_free(). */
/** @return On failure, returns NULL. */
/** @see    avago_serdes_gradient_inputs_read(). */
char *avago_serdes_gradient_inputs_print(
    Aapl_t *aapl,                           /**< [in] Pointer to Aapl_t structure. */
    uint addr,                              /**< [in] Device address number. */
    uint mask,                              /**< [in] Mask that defines which fields to print. */
    Avago_serdes_gradient_inputs_t *params) /**< [in] Values to print. */
{
    int table_size = avago_serdes_gradient_inputs_table_size(aapl, addr);
    char *buf = 0, *buf_end = 0;
    int size = 0;

    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, dwell_shift_ical);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, agc_target_low);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, agc_target_high);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, tune_level);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, dwell_shift_pcal);
    if( table_size >= 16 )   /* 1075 and newer */
    {
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pcal_hysteresis_pre1_pos);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pcal_hysteresis_pre1_neg);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pcal_hysteresis_post1_pos);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pcal_hysteresis_post1_neg);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pcal_hysteresis_67_pre1);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pcal_hysteresis_78_post1);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pcal_level3_threshold);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pcal_threshold_offset_post1_pos);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pcal_threshold_offset_post1_neg);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pcal_hysteresis_pre2_pos);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, pcal_hysteresis_pre2_neg);
    }

    return buf;
}

/** @brief  Writes selected fields of gradient inputs structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_gradient_inputs_read(), avago_serdes_gradient_inputs_write(). */
int avago_serdes_gradient_inputs_apply(
    Aapl_t *aapl,                           /**< [in] Pointer to Aapl_t structure. */
    uint addr,                              /**< [in] Device address number. */
    uint mask,                              /**< [in] Mask that defines which fields to write. */
    Avago_serdes_gradient_inputs_t *params) /**< [in] New set of values. */
{
    int table_size = avago_serdes_gradient_inputs_table_size(aapl, addr);
    int return_code = aapl->return_code;

    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 1, AVAGO_M4) )
        return -1;

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_gradient_inputs_print(aapl, addr, mask, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Write gradient inputs structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }

    hal_write_table(aapl, addr, mask, AVAGO_HAL_GRADIENT_INPUTS, 0, table_size, params); /* Write to firmware. */
/*  avago_serdes_hal_func(aapl, addr, AVAGO_HAL_GRADIENT_INPUTS_APPLY); // Firmware fields, no apply */

    return (aapl->return_code == return_code) ? 0 : -1;
}

/** @brief Writes gradient inputs structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_gradient_inputs_apply(), avago_serdes_gradient_inputs_read(). */
int avago_serdes_gradient_inputs_write(
    Aapl_t *aapl,                           /**< [in] Pointer to Aapl_t structure. */
    uint addr,                              /**< [in] Device address number. */
    Avago_serdes_gradient_inputs_t *params) /**< [in] New set of values. */
{
    return avago_serdes_gradient_inputs_apply(aapl, addr, ~0, params);
}

/** @brief  Reads gradient inputs fields from firmware and updates members of structure. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_gradient_inputs_apply(), avago_serdes_gradient_inputs_print(), avago_serdes_gradient_inputs_write(). */
int avago_serdes_gradient_inputs_read(
    Aapl_t *aapl,                           /**< [in] Pointer to Aapl_t structure. */
    uint addr,                              /**< [in] Device address number. */
    Avago_serdes_gradient_inputs_t *params) /**< [out] Results structure. */
{
    int table_size = avago_serdes_gradient_inputs_table_size(aapl, addr);
    int return_code = aapl->return_code;

    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 1, AVAGO_M4) )
        return -1;

    hal_read_table(aapl, addr, AVAGO_HAL_GRADIENT_INPUTS, 0, table_size, params);

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_gradient_inputs_print(aapl, addr, ~0, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Read gradient inputs structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }
    return (aapl->return_code == return_code) ? 0 : -1;
}


/** @brief  Prints selected fields of the test channel inputs structure to a buffer. */
/** @return On success, returns a pointer to a string which should be freed using aapl_free(). */
/** @return On failure, returns NULL. */
/** @see    avago_serdes_test_channel_inputs_read(), avago_serdes_test_channel_cal_read(). */
char *avago_serdes_test_channel_inputs_print(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    uint mask,                                  /**< [in] Mask that defines which fields to print. */
    Avago_serdes_test_channel_inputs_t *params) /**< [in] Values to print. */
{
    char *buf = 0, *buf_end = 0;
    int size = 0;
    (void)addr;

    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, test_e);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, test_o);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, edge_e);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, edge_o);

    return buf;
}

/** @brief  Writes selected fields of test_channel_inputs structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_test_channel_inputs_read(), */
/*avago_serdes_test_channel_inputs_write(). */
int avago_serdes_test_channel_inputs_apply(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    uint mask,                                  /**< [in] Mask that defines which fields to write. */
    Avago_serdes_test_channel_inputs_t *params) /**< [in] New set of values. */
{
    int return_code = aapl->return_code;

    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 4, AAPL_SDREV_CM4_16, AAPL_SDREV_D6_07, AAPL_SDREV_OM4, AAPL_SDREV_CM4) )
        return -1;

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_test_channel_inputs_print(aapl, addr, mask, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Write test_channel_inputs structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }

    hal_write_table(aapl, addr, mask, AVAGO_HAL_TEST_CHANNEL_INPUTS, 0, sizeof(*params) / sizeof(short), params); /* Write to firmware. */
    avago_serdes_hal_func(aapl, addr, AVAGO_HAL_TEST_CHANNEL_APPLY);                                              /* Apply to hardware. */

    return (aapl->return_code == return_code) ? 0 : -1;
}

/** @brief Writes test_channel_inputs structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_test_channel_inputs_apply(), */
/*avago_serdes_test_channel_inputs_read(). */
int avago_serdes_test_channel_inputs_write(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    Avago_serdes_test_channel_inputs_t *params) /**< [in] New set of values. */
{
    return avago_serdes_test_channel_inputs_apply(aapl, addr, ~0, params);
}

/** @brief  Reads test_channel_inputs fields from firmware and updates members of structure. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_test_channel_inputs_apply(), avago_serdes_test_channel_inputs_print(), avago_serdes_test_channel_inputs_write(). */
int avago_serdes_test_channel_inputs_read(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    Avago_serdes_test_channel_inputs_t *params) /**< [out] Results structure. */
{
    int return_code = aapl->return_code;

    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 4, AAPL_SDREV_CM4_16, AAPL_SDREV_D6_07, AAPL_SDREV_OM4, AAPL_SDREV_CM4) )
        return -1;

    hal_read_table(aapl, addr, AVAGO_HAL_TEST_CHANNEL_INPUTS, 0, sizeof(*params) / sizeof(short), params);

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_test_channel_inputs_print(aapl, addr, ~0, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Read test_channel_inputs structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }
    return (aapl->return_code == return_code) ? 0 : -1;
}

/** @brief  Writes selected fields of test_channel_cal structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_test_channel_cal_read(), */
/*avago_serdes_test_channel_cal_write(). */
int avago_serdes_test_channel_cal_apply(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    uint mask,                                  /**< [in] Mask that defines which fields to write. */
    Avago_serdes_test_channel_inputs_t *params) /**< [in] New set of values. */
{
    int return_code = aapl->return_code;

    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 4, AAPL_SDREV_CM4_16, AAPL_SDREV_D6_07, AAPL_SDREV_OM4, AAPL_SDREV_CM4) )
        return -1;

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_test_channel_inputs_print(aapl, addr, mask, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Write test_channel_cal structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }

    hal_write_table(aapl, addr, mask, AVAGO_HAL_TEST_CHANNEL_CAL, 0, sizeof(*params) / sizeof(short), params); /* Write to firmware. */
    avago_serdes_hal_func(aapl, addr, AVAGO_HAL_TEST_CHANNEL_APPLY);                                           /* Apply to hardware. */

    return (aapl->return_code == return_code) ? 0 : -1;
}

/** @brief Writes test_channel_cal structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_test_channel_cal_apply(), avago_serdes_test_channel_cal_read(). */
int avago_serdes_test_channel_cal_write(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    Avago_serdes_test_channel_inputs_t *params) /**< [in] New set of values. */
{
    return avago_serdes_test_channel_cal_apply(aapl, addr, ~0, params);
}

/** @brief  Reads test_channel_cal fields from firmware and updates members of structure. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_test_channel_cal_apply(), avago_serdes_test_channel_inputs_print(), avago_serdes_test_channel_cal_write(). */
int avago_serdes_test_channel_cal_read(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    Avago_serdes_test_channel_inputs_t *params) /**< [out] Results structure. */
{
    int return_code = aapl->return_code;

    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 4, AAPL_SDREV_CM4_16, AAPL_SDREV_D6_07, AAPL_SDREV_OM4, AAPL_SDREV_CM4) )
        return -1;

    hal_read_table(aapl, addr, AVAGO_HAL_TEST_CHANNEL_CAL, 0, sizeof(*params) / sizeof(short), params);

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_test_channel_inputs_print(aapl, addr, ~0, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Read test_channel_cal structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }
    return (aapl->return_code == return_code) ? 0 : -1;
}

static int avago_serdes_data_channel_inputs_table_size(Aapl_t *aapl, uint addr)
{
    int table_size = sizeof(Avago_serdes_data_channel_inputs_t) / sizeof(short);
    if( aapl_get_ip_type(aapl, addr) == AVAGO_SERDES )
        table_size = 4;
    return table_size;
}

/** @brief  Prints selected fields of the data channel inputs structure to a buffer. */
/** @return On success, returns a pointer to a string which should be freed using aapl_free(). */
/** @return On failure, returns NULL. */
/** @see    avago_serdes_data_channel_inputs_read(), avago_serdes_data_channel_cal_read(), avago_serdes_data_channel_cal_delta_read(). */
char *avago_serdes_data_channel_inputs_print(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    uint mask,                                  /**< [in] Mask that defines which fields to print. */
    Avago_serdes_data_channel_inputs_t *params) /**< [in] Values to print. */
{
    char *buf = 0, *buf_end = 0;
    int size = 0;
    int table_size = avago_serdes_data_channel_inputs_table_size(aapl, addr);
    (void)addr;

    if( table_size == 4 )
    {
        Avago_serdes_data_channel_inputs_d6_t *d6_params = (Avago_serdes_data_channel_inputs_d6_t *)params;
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, vos_d0e);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, vos_d0o);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, vos_d1e);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, d6_params, vos_d1o);
    }
    else
    {
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, upper_e);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, upper_o);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, mid_e);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, mid_o);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, lower_e);
        HAL_DPRINT(aapl, buf, buf_end, size, mask, params, lower_o);
    }

    return buf;
}

static const char *get_data_channel_inputs_label(Avago_serdes_hal_type_t hal)
{
    switch( hal )
    {
    default:
    case AVAGO_HAL_DATA_CHANNEL_INPUTS:    return "inputs";
    case AVAGO_HAL_DATA_CHANNEL_CAL:       return "cal";
    case AVAGO_HAL_DATA_CHANNEL_CAL_DELTA: return "cal delta";
    }
}

static int avago_serdes_data_channel_read(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    Avago_serdes_hal_type_t hal,                /**< [in] Table to read. */
    Avago_serdes_data_channel_inputs_t *params) /**< [out] Results structure. */
{
    int table_size = avago_serdes_data_channel_inputs_table_size(aapl, addr);
    int return_code = aapl->return_code;

    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 4, AAPL_SDREV_CM4_16, AAPL_SDREV_D6_07, AAPL_SDREV_OM4, AAPL_SDREV_CM4) )
        return -1;

    hal_read_table(aapl, addr, hal, 0, table_size, params);

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_data_channel_inputs_print(aapl, addr, ~0, params);
        if( buf )
        {
            const char *label = get_data_channel_inputs_label(hal);
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Read data channel %s structure: {%s }\n", aapl_addr_to_str(addr), label, one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }
    return (aapl->return_code == return_code) ? 0 : -1;
}

/** @brief  Writes selected fields of data channel inputs structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
static int avago_serdes_data_channel_apply(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    Avago_serdes_hal_type_t hal,                /**< [in] Table to which to write values. */
    uint mask,                                  /**< [in] Mask that defines which fields to write. */
    Avago_serdes_data_channel_inputs_t *params) /**< [in] New set of values. */
{
    int table_size = avago_serdes_data_channel_inputs_table_size(aapl, addr);
    int return_code = aapl->return_code;

    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 4, AAPL_SDREV_CM4_16, AAPL_SDREV_D6_07, AAPL_SDREV_OM4, AAPL_SDREV_CM4) )
        return -1;

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_data_channel_inputs_print(aapl, addr, mask, params);
        if( buf )
        {
            const char *label = get_data_channel_inputs_label(hal);
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Write data channel %s structure: {%s }\n", aapl_addr_to_str(addr), label, one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }

    hal_write_table(aapl, addr, mask, hal, 0, table_size, params);   /* Write to firmware. */
    avago_serdes_hal_func(aapl, addr, AVAGO_HAL_DATA_CHANNEL_APPLY); /* Apply to hardware. */

    return (aapl->return_code == return_code) ? 0 : -1;
}

/** @brief  Writes selected fields of data channel inputs structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_data_channel_inputs_read(), avago_serdes_data_channel_inputs_write(). */
int avago_serdes_data_channel_inputs_apply(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    uint mask,                                  /**< [in] Mask that defines which fields to write. */
    Avago_serdes_data_channel_inputs_t *params) /**< [in] New set of values. */
{
    return avago_serdes_data_channel_apply(aapl, addr, AVAGO_HAL_DATA_CHANNEL_INPUTS, mask, params);
}

/** @brief  Writes data channel inputs structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_data_channel_inputs_read(), avago_serdes_data_channel_inputs_apply(). */
int avago_serdes_data_channel_inputs_write(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    Avago_serdes_data_channel_inputs_t *params) /**< [in] New set of values. */
{
    return avago_serdes_data_channel_inputs_apply(aapl, addr, ~0, params);
}

/** @brief Reads data channel inputs fields from firmware and updates members of structure. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_data_channel_inputs_apply(), avago_serdes_data_channel_inputs_print(), avago_serdes_data_channel_inputs_write(). */
int avago_serdes_data_channel_inputs_read(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    Avago_serdes_data_channel_inputs_t *params) /**< [out] Results structure. */
{
    return avago_serdes_data_channel_read(aapl, addr, AVAGO_HAL_DATA_CHANNEL_INPUTS, params);
}

/** @brief  Writes selected fields of data channel inputs structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_data_channel_cal_read(), avago_serdes_data_channel_cal_write(). */
int avago_serdes_data_channel_cal_apply(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    uint mask,                                  /**< [in] Mask that defines which fields to write. */
    Avago_serdes_data_channel_inputs_t *params) /**< [in] New set of values. */
{
    return avago_serdes_data_channel_apply(aapl, addr, AVAGO_HAL_DATA_CHANNEL_CAL, mask, params);
}

/** @brief  Writes data channel inputs structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_data_channel_cal_read(), avago_serdes_data_channel_cal_apply(). */
int avago_serdes_data_channel_cal_write(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    Avago_serdes_data_channel_inputs_t *params) /**< [in] New set of values. */
{
    return avago_serdes_data_channel_cal_apply(aapl, addr, ~0, params);
}

/** @brief Reads data channel cal fields from firmware and updates members of structure. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_data_channel_cal_apply(), avago_serdes_data_channel_inputs_print(), avago_serdes_data_channel_cal_write(). */
int avago_serdes_data_channel_cal_read(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    Avago_serdes_data_channel_inputs_t *params) /**< [out] Results structure. */
{
    return avago_serdes_data_channel_read(aapl, addr, AVAGO_HAL_DATA_CHANNEL_CAL, params);
}

/** @brief  Writes selected fields of data channel inputs structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_data_channel_cal_delta_read(), avago_serdes_data_channel_cal_delta_write(). */
int avago_serdes_data_channel_cal_delta_apply(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    uint mask,                                  /**< [in] Mask that defines which fields to write. */
    Avago_serdes_data_channel_inputs_t *params) /**< [in] New set of values. */
{
    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 1, AVAGO_M4) )
        return -1;

    return avago_serdes_data_channel_apply(aapl, addr, AVAGO_HAL_DATA_CHANNEL_CAL_DELTA, mask, params);
}

/** @brief  Writes data channel inputs structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_data_channel_cal_delta_read(), avago_serdes_data_channel_cal_delta_apply(). */
int avago_serdes_data_channel_cal_delta_write(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    Avago_serdes_data_channel_inputs_t *params) /**< [in] New set of values. */
{
    return avago_serdes_data_channel_cal_delta_apply(aapl, addr, ~0, params);
}

/** @brief Reads data channel cal delta fields from firmware and updates members of structure. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_data_channel_cal_delta_apply(), avago_serdes_data_channel_inputs_print(), avago_serdes_data_channel_cal_delta_write(). */
int avago_serdes_data_channel_cal_delta_read(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    Avago_serdes_data_channel_inputs_t *params) /**< [out] Results structure. */
{
    if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, TRUE, 1, AVAGO_M4) )
        return -1;

    return avago_serdes_data_channel_read(aapl, addr, AVAGO_HAL_DATA_CHANNEL_CAL_DELTA, params);
}

/** @brief  Prints selected fields of the PAM4 levels structure to a buffer. */
/** @return On success, returns a pointer to a string which should be freed using aapl_free(). */
/** @return On failure, returns NULL. */
/** @see    avago_serdes_pam4_levels_read(). */
char *avago_serdes_pam4_levels_print(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    uint addr,                          /**< [in] Device address number. */
    uint mask,                          /**< [in] Mask that defines which fields to print. */
    Avago_serdes_pam4_levels_t *params) /**< [in] Values to print. */
{
    char *buf = 0, *buf_end = 0;
    int size = 0;
    (void)addr;

    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, level_x3x_e);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, level_x3x_o);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, level_x2x_e);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, level_x2x_o);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, level_x1x_e);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, level_x1x_o);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, level_x0x_e);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, level_x0x_o);

    return buf;
}

/** @brief  Writes selected fields of data channel inputs structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_pam4_levels_read(), avago_serdes_pam4_levels_write(). */
int avago_serdes_pam4_levels_apply(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    uint addr,                          /**< [in] Device address number. */
    uint mask,                          /**< [in] Mask that defines which fields to write. */
    Avago_serdes_pam4_levels_t *params) /**< [in] New set of values. */
{
    int return_code = aapl->return_code;

    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 1, AAPL_SDREV_CM4_16) )
        return -1;

    hal_write_table(aapl, addr, mask, AVAGO_HAL_PAM4_LEVELS, 0, sizeof(*params) / sizeof(short), params); /* Write to firmware. */
/*  avago_serdes_hal_func(aapl, addr, AVAGO_HAL_PAM4_LEVELS_APPLY); // Firmware fields, no apply */

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_pam4_levels_print(aapl, addr, mask, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Write PAM4 levels structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }

    return (aapl->return_code == return_code) ? 0 : -1;

}
/** @brief  Writes data channel inputs structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_pam4_levels_apply(), avago_serdes_pam4_levels_read(). */
int avago_serdes_pam4_levels_write(
    Aapl_t *aapl,                               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                                  /**< [in] Device address number. */
    Avago_serdes_pam4_levels_t *params) /**< [in] New set of values. */
{
    return avago_serdes_pam4_levels_apply(aapl, addr, ~0, params);
}

/** @brief Reads PAM4 levels fields from firmware and updates members of structure. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_pam4_levels_apply(), avago_serdes_pam4_levels_print(), avago_serdes_pam4_levels_write(). */
int avago_serdes_pam4_levels_read(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    uint addr,                          /**< [in] Device address number. */
    Avago_serdes_pam4_levels_t *params) /**< [out] Results structure. */
{
    int return_code = aapl->return_code;

    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 1, AAPL_SDREV_CM4_16) )
        return -1;

    hal_read_table(aapl, addr, AVAGO_HAL_PAM4_LEVELS, 0, sizeof(*params) / sizeof(short), params);

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_pam4_levels_print(aapl, addr, ~0, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Read PAM4 levels structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }
    return (aapl->return_code == return_code) ? 0 : -1;
}


/** @brief  Prints selected fields of the PAM4 eye structure to a buffer. */
/** @return On success, returns a pointer to a string which should be freed using aapl_free(). */
/** @return On failure, returns NULL. */
/** @see    avago_serdes_pam4_eye_read(). */
char *avago_serdes_pam4_eye_print(
    Aapl_t *aapl,                    /**< [in] Pointer to Aapl_t structure. */
    uint addr,                       /**< [in] Device address number. */
    uint mask,                       /**< [in] Mask that defines which fields to print. */
    Avago_serdes_pam4_eye_t *params) /**< [in] Values to print. */
{
    char *buf = 0, *buf_end = 0;
    int size = 0;
    (void)addr;

    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, height_even_l);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, height_even_m);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, height_even_u);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, height_odd_l);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, height_odd_m);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, height_odd_u);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, start_even_l);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, start_even_m);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, start_even_u);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, start_odd_l);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, start_odd_m);
    HAL_DPRINT(aapl, buf, buf_end, size, mask, params, start_odd_u);

    return buf;
}

/** @brief  Writes selected fields of PAM4 eye structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_pam4_eye_read(), avago_serdes_pam4_eye_write(). */
int avago_serdes_pam4_eye_apply(
    Aapl_t *aapl,                    /**< [in] Pointer to Aapl_t structure. */
    uint addr,                       /**< [in] Device address number. */
    uint mask,                       /**< [in] Mask that defines which fields to write. */
    Avago_serdes_pam4_eye_t *params) /**< [in] New set of values. */
{
    int return_code = aapl->return_code;

    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 1, AAPL_SDREV_CM4_16) )
        return -1;

    hal_write_table(aapl, addr, mask, AVAGO_HAL_PAM4_EYE, 0, sizeof(*params) / sizeof(short), params); /* Write to firmware. */
/*  avago_serdes_hal_func(aapl, addr, AVAGO_HAL_PAM4_EYE_APPLY); // Firmware fields, no apply */

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_pam4_eye_print(aapl, addr, mask, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Write PAM4 eye structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }

    return (aapl->return_code == return_code) ? 0 : -1;
}

/** @brief  Writes PAM4 eye structure to firmware. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_pam4_eye_apply(), avago_serdes_pam4_eye_read(). */
int avago_serdes_pam4_eye_write(
    Aapl_t *aapl,                    /**< [in] Pointer to Aapl_t structure. */
    uint addr,                       /**< [in] Device address number. */
    Avago_serdes_pam4_eye_t *params) /**< [in] New set of values. */
{
    return avago_serdes_pam4_eye_apply(aapl, addr, ~0, params);
}

/** @brief Reads PAM4 eye fields from firmware and updates members of structure. */
/** @return On success, returns 0. */
/** @return On failure, returns -1. */
/** @see    avago_serdes_pam4_eye_apply(), avago_serdes_pam4_eye_print(), avago_serdes_pam4_eye_write(). */
int avago_serdes_pam4_eye_read(
    Aapl_t *aapl,                    /**< [in] Pointer to Aapl_t structure. */
    uint addr,                       /**< [in] Device address number. */
    Avago_serdes_pam4_eye_t *params) /**< [out] Results structure. */
{
    int return_code = aapl->return_code;

    if( !aapl_check_sdrev(aapl, addr, __func__, __LINE__, TRUE, 1, AAPL_SDREV_CM4_16) )
        return -1;

    hal_read_table(aapl, addr, AVAGO_HAL_PAM4_EYE, 0, sizeof(*params) / sizeof(short), params);

    if( aapl->debug > 0 )
    {
        char *buf = avago_serdes_pam4_eye_print(aapl, addr, ~0, params);
        if( buf )
        {
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, Read PAM4 eye structure: {%s }\n", aapl_addr_to_str(addr), one_line(buf));
            aapl_free(aapl, buf, __func__);
        }
    }
    return (aapl->return_code == return_code) ? 0 : -1;
}

