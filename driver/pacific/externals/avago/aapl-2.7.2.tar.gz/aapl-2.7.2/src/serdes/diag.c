/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* AAPL (ASIC and ASSP Programming Layer) SerDes diagnostics */

/** Doxygen File Header */
/** @file diag.c */
/** @brief Functions for SerDes diagnostics. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

extern int aapl_sigint_detected;

/** @brief   Prints detailed information for a SerDes. */
/** @details Prints a table of TX, RX, DFE, and other information for the given SerDes. This function is broadcast safe. */
void avago_serdes_print_state_table(Aapl_t *aapl, Avago_addr_t *addr_struct)
{
    avago_serdes_print_state_table_options(aapl, addr_struct, 0);
}

#if AAPL_ENABLE_DIAG

/** @brief   Enables and configures the BSB to the specified mode for a source_addr/dest_addr pair. */
/** @details */
void avago_serdes_set_bsb(Aapl_t *aapl, uint source_addr, uint dest_addr, Avago_serdes_bsb_mode_t bsb_mode, Avago_serdes_bsb_clk_sel_t bsb_clk_sel, int mem_addr, int mem_bit)
{
    if(source_addr)
    {
        if( !aapl_check_ip_type(aapl, source_addr, __func__, __LINE__, TRUE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) ||
            !aapl_check_process(aapl, source_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28) )
            return;
    }
    if( !aapl_check_ip_type(aapl, dest_addr, __func__, __LINE__, TRUE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) ||
        !aapl_check_process(aapl, dest_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28) )
        return;

    if(source_addr==dest_addr || source_addr == 0)
        avago_serdes_bsb_setup(aapl, dest_addr, bsb_mode, bsb_clk_sel, 1, mem_addr, mem_bit);
    else if (bsb_mode == AVAGO_SERDES_BSB_DISABLE)
    {
        avago_serdes_bsb_setup(aapl, source_addr, bsb_mode, bsb_clk_sel, 0, mem_addr, mem_bit);
        avago_serdes_bsb_setup(aapl, dest_addr, bsb_mode, bsb_clk_sel, 0, mem_addr, mem_bit );
    }
    else
    {
        /* 0xfe, 0x21 == ({sbus_bist_mux_sel[2:0],sbus_bist_test_cntl}), */
        /* 0xfe[3] = sbus_bist_stat_in; */
        /* 3'b000: sbus_bist_stat_out = 1'b0; */
        /* 3'b001: sbus_bist_stat_out = sbus_bist_test_cntl; */
        /* 3'b010: sbus_bist_stat_out = sbus_bist_stat_in; */
        /* 3'b011: sbus_bist_stat_out = TEST__SBUS_DATA_OUT >> data_out_bit_select; */
        /* 3'b100: sbus_bist_stat_out = spare_sbus_data_out >> data_out_bit_select; */
        avago_sbus_wr(aapl, avago_make_sbus_controller_addr(source_addr), 0x21, 0x4); /* turn BSB into ring via the SBus controller */
        avago_serdes_bsb_setup(aapl, source_addr, bsb_mode, bsb_clk_sel, 0, mem_addr, mem_bit);
        avago_serdes_bsb_setup(aapl, dest_addr, AVAGO_SERDES_BSB_PASSTHRU, (Avago_serdes_bsb_clk_sel_t)0, 1, 0, 0);
    }
}


/** @brief   Enables and configures the BSB to the specified mode for a single SerDes */
/** @details */
void avago_serdes_bsb_setup(Aapl_t *aapl, uint sbus_addr, Avago_serdes_bsb_mode_t bsb_mode, Avago_serdes_bsb_clk_sel_t bsb_clk_sel, int tx_en, int mem_addr, int mem_bit)
{
    /* NOTE:  This code could be cleaned up to use common code with a */
    /* differing register values based on chip.  For now, it has three */
    /* implementations, of which only the D6 is known to work. */

    int sdrev = aapl_get_sdrev(aapl,sbus_addr);
    int tx_en_cmd = 0;
    int tx_en_msk = 0;
    int addr_eb = 0;

    if( !aapl_check_ip_type(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) ||
        !aapl_check_process(aapl, sbus_addr, __func__, __LINE__, TRUE, 3, AVAGO_TSMC_07, AVAGO_TSMC_16, AVAGO_TSMC_28) )
        return;

    if (bsb_mode == AVAGO_SERDES_BSB_DISABLE)
    {
        tx_en = 0;
        bsb_mode = AVAGO_SERDES_BSB_PASSTHRU;
    }

    if (tx_en)
    {
        tx_en_cmd = 0x0c;
        tx_en_msk = 0x1c;
        addr_eb = 0x2;
    }
    else
    {
        tx_en_cmd = 0x04;
        tx_en_msk = 0x1c;
        addr_eb = 0x0;
    }

    if( sdrev == AAPL_SDREV_D6 || sdrev == AAPL_SDREV_HVD6 )
    {
        if (bsb_mode == AVAGO_SERDES_BSB_CLK)
        {
            avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_LSB, 0x48, 0x21);                  /* BSB_CONTROL, select clock,enable */
            avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_LSB, 0x23, tx_en_cmd, tx_en_msk); /* BSB_AND_TX_OVERRIDE */
            if (sdrev == AAPL_SDREV_HVD6)
                avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_ESB, 0x300, bsb_clk_sel << 8, 0xff00);   /* CLK_MISC_OUT0.LC_BSB_CNTL */
            else
                avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_ESB, 0x300, bsb_clk_sel, 0x1f);   /* CLK_MISC_OUT0.LC_BSB_CNTL */
        }
        else if (bsb_mode == AVAGO_SERDES_BSB_PASSTHRU)
        {
            avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_LSB, 0x48, 0x01);                  /* BSB_CONTROL, select bist_stat_in,enable */
            if (aapl_get_process_id(aapl,sbus_addr) == AVAGO_TSMC_16)
                avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_ESB, 0xeb, addr_eb, 0x2);     /* ? */
            avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_LSB, 0x23, tx_en_cmd, tx_en_msk); /* BSB_AND_TX_OVERRIDE */
        }
        else if (bsb_mode == AVAGO_SERDES_BSB_DISABLE)
        {
            avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_LSB, 0x48, 0x00);                  /* BSB_CONTROL, disable */
            if (aapl_get_process_id(aapl,sbus_addr) == AVAGO_TSMC_16)
                avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_ESB, 0xeb, addr_eb, 0x2);     /* ? */
        }
        else if(bsb_mode == AVAGO_SERDES_BSB_DMA || bsb_mode == AVAGO_SERDES_BSB_SBUS)
        {
            if     (bsb_mode == AVAGO_SERDES_BSB_DMA)  avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_LSB, 0x48, 0x11); /* BSB_CONTROL, select DMA obs, enable */
            else if(bsb_mode == AVAGO_SERDES_BSB_SBUS) avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_LSB, 0x48, 0x51); /* BSB_CONTROL, select SBUS obs, enable */
            if (aapl_get_process_id(aapl,sbus_addr) == AVAGO_TSMC_16)
                avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_ESB, 0xeb, addr_eb, 0x2);                               /* ? */
            avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_LSB, 0x23, tx_en_cmd, tx_en_msk);                           /* BSB_AND_TX_OVERRIDE */
            avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_LSB, 0x49, (mem_bit << 8), 0x1f00);                         /* BSB_ADDR_SELECT.BSB_BIT_SEL */
            avago_sbus_wr(aapl, sbus_addr, 0x01, (1<<29)); /* make sure DMEM_CNTL2_EN is set                        // */
            avago_sbus_wr(aapl, sbus_addr, 0x02, (mem_addr & 0xff) << 16);                                          /* */
        }
        else aapl_fail(aapl, __func__, __LINE__, "SBus 0x%02x, Invalid BSB Mode (%d).\n", sbus_addr, bsb_mode);
    }
    else if( sdrev == AAPL_SDREV_P1 )
    {
        if (bsb_mode == AVAGO_SERDES_BSB_CLK)
        {
            avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_LSB, 0xfb, 0x21);                    /* BSB_CONTROL, select clock,enable */
            avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_LSB, 0xeb, tx_en_cmd, tx_en_msk);   /* BSB_AND_TX_OVERRIDE */
            avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_ESB, 0x12c, bsb_clk_sel<<8, 0xff00);
        }
        else if (bsb_mode == AVAGO_SERDES_BSB_PASSTHRU)
        {
            avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_LSB, 0xfb, 0x01);                    /* BSB_CONTROL, select bist_stat_in,enable */
            avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_LSB, 0xeb, tx_en_cmd, tx_en_msk);   /* BSB_AND_TX_OVERRIDE */
        }
        else if (bsb_mode == AVAGO_SERDES_BSB_DISABLE)
        {
            avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_LSB, 0xfb, 0x00);                    /* BSB_CONTROL, disable */
        }
        else if(bsb_mode == AVAGO_SERDES_BSB_DMA || bsb_mode == AVAGO_SERDES_BSB_SBUS)
        {
            if     (bsb_mode == AVAGO_SERDES_BSB_DMA)  avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_LSB, 0xfb, 0x11); /* BSB_CONTROL, select DMA obs, enable */
            else if(bsb_mode == AVAGO_SERDES_BSB_SBUS) avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_LSB, 0xfb, 0x51); /* BSB_CONTROL, select SBUS obs, enable */
            avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_LSB, 0xeb, tx_en_cmd, tx_en_msk);                           /* BSB_AND_TX_OVERRIDE */
            avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_LSB, 0x49, (mem_bit << 8), 0x1f00);                         /* BSB_ADDR_SELECT.BSB_BIT_SEL */
            avago_sbus_wr(aapl, sbus_addr, 0x01, (1<<29)); /* make sure DMEM_CNTL2_EN is set */
            avago_sbus_wr(aapl, sbus_addr, 0x02, (mem_addr & 0xff) << 16);
        }
        else aapl_fail(aapl, __func__, __LINE__, "SBus 0x%02x, Invalid BSB Mode (%d).\n", sbus_addr, bsb_mode);
    }
    else
    {
        if (bsb_mode == AVAGO_SERDES_BSB_CLK)
        {
            avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_LSB, 0x48, 0x21);
            avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_ESB, 0xeb, addr_eb, 0x2);   /* 16nm & M4 */
            avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_LSB, 0x23, tx_en_cmd, tx_en_msk);
            avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_ESB, 0xf0, bsb_clk_sel<<8, 0xff00);  /* 16nm & M4 */
        }
        else if (bsb_mode == AVAGO_SERDES_BSB_PASSTHRU)
        {
            avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_LSB, 0x48, 0x01);
            if (aapl_get_process_id(aapl,sbus_addr) == AVAGO_TSMC_16)
                avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_ESB, 0xeb, addr_eb, 0x2);
            avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_LSB, 0x23, tx_en_cmd, tx_en_msk);
        }
        else if (bsb_mode == AVAGO_SERDES_BSB_DISABLE)
        {
            avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_LSB, 0x48, 0x00);
            if (aapl_get_process_id(aapl,sbus_addr) == AVAGO_TSMC_16)
                avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_ESB, 0xeb, addr_eb, 0x2);
        }
        else if(bsb_mode == AVAGO_SERDES_BSB_DMA || bsb_mode == AVAGO_SERDES_BSB_SBUS)
        {
            if     (bsb_mode == AVAGO_SERDES_BSB_DMA)  avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_LSB, 0x48, 0x11);
            else if(bsb_mode == AVAGO_SERDES_BSB_SBUS) avago_serdes_mem_wr(aapl, sbus_addr, AVAGO_LSB, 0x48, 0x51);
            if (aapl_get_process_id(aapl,sbus_addr) == AVAGO_TSMC_16)
                avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_ESB, 0xeb, addr_eb, 0x2);
            avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_LSB, 0x23, tx_en_cmd, tx_en_msk);
            avago_serdes_mem_rmw(aapl, sbus_addr, AVAGO_LSB, 0x49, (mem_bit << 8), 0x1f00);
            avago_sbus_wr(aapl, sbus_addr, 0x01, (1<<29)); /* make sure DMEM_CNTL2_EN is set */
            avago_sbus_wr(aapl, sbus_addr, 0x02, (mem_addr & 0xff) << 16);
        }
        else aapl_fail(aapl, __func__, __LINE__, "SBus 0x%02x, Invalid BSB Mode (%d).\n", sbus_addr, bsb_mode);
    }
}


/** @brief   Retrieves the current BSB configuration information */
/** @details */
int avago_serdes_get_bsb(Aapl_t *aapl, uint sbus_addr, Avago_serdes_bsb_mode_t *bsb_mode, Avago_serdes_bsb_clk_sel_t *bsb_clk_sel, int *mem_addr, int *mem_bit)
{
    int sdrev = aapl_get_sdrev(aapl,sbus_addr);
    int rd_out = 0;
    int return_code = aapl->return_code;
    int bsb_cntl_reg, lc_bsb_cntl_reg, cntl_shift;

    switch( sdrev )
    {
    case AAPL_SDREV_P1:   bsb_cntl_reg = 0xfb; lc_bsb_cntl_reg = 0x12c; cntl_shift = 8; break;
    case AAPL_SDREV_HVD6: bsb_cntl_reg = 0x48; lc_bsb_cntl_reg = 0x300; cntl_shift = 8; break;
    case AAPL_SDREV_D6:   bsb_cntl_reg = 0x48; lc_bsb_cntl_reg = 0x300; cntl_shift = 0; break;
    default:              bsb_cntl_reg = 0x48; lc_bsb_cntl_reg = 0x0f0; cntl_shift = 8; break;
    }

    rd_out = avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_LSB, bsb_cntl_reg) & 0x71;

    switch(rd_out)
    {
        case 0x00: *bsb_mode = AVAGO_SERDES_BSB_PASSTHRU;   break;
        case 0x01: *bsb_mode = AVAGO_SERDES_BSB_PASSTHRU;   break;
        case 0x11: *bsb_mode = AVAGO_SERDES_BSB_DMA;        break;
        case 0x21: *bsb_mode = AVAGO_SERDES_BSB_CLK;        break;
        case 0x31: *bsb_mode = AVAGO_SERDES_BSB_CORE;       break;
        case 0x51: *bsb_mode = AVAGO_SERDES_BSB_SBUS;       break;
    }

    rd_out = (avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_ESB, lc_bsb_cntl_reg) >> cntl_shift) & 0x1f;
    switch(rd_out)
    {
        case 0x00: *bsb_clk_sel = AVAGO_SERDES_BSB_GND;              break;
        case 0x01: *bsb_clk_sel = AVAGO_SERDES_BSB_RX_F10;           break;
        case 0x02: *bsb_clk_sel = AVAGO_SERDES_BSB_RX_F20;           break;
        case 0x03: *bsb_clk_sel = AVAGO_SERDES_BSB_RX_F40_FIFO_CLK;  break;
        case 0x04: *bsb_clk_sel = AVAGO_SERDES_BSB_RX_CLK;           break;
        case 0x05: *bsb_clk_sel = AVAGO_SERDES_BSB_RX_FIFO_CLK;      break;
        case 0x06: *bsb_clk_sel = AVAGO_SERDES_BSB_RX_F66_CLK;       break;
        case 0x07: *bsb_clk_sel = AVAGO_SERDES_BSB_PCS6466_FIFO_CLK; break;
        case 0x08: *bsb_clk_sel = AVAGO_SERDES_BSB_TX_F10;           break;
        case 0x09: *bsb_clk_sel = AVAGO_SERDES_BSB_TX_F20;           break;
        case 0x0a: *bsb_clk_sel = AVAGO_SERDES_BSB_TX_F40;           break;
        case 0x0b: *bsb_clk_sel = AVAGO_SERDES_BSB_TX_FIFO_CLK;      break;
        case 0x0c: *bsb_clk_sel = AVAGO_SERDES_BSB_SBUS_CLK;         break;
        case 0x0d: *bsb_clk_sel = AVAGO_SERDES_BSB_SBUS_CLK_TEST;    break;
        case 0x0f: *bsb_clk_sel = AVAGO_SERDES_BSB_TX_TEST_CLK;      break;
        case 0x11: *bsb_clk_sel = AVAGO_SERDES_BSB_REFCLK;           break;
        case 0x12: *bsb_clk_sel = AVAGO_SERDES_BSB_REFCLK_TEST;      break;
        case 0x14: *bsb_clk_sel = AVAGO_SERDES_BSB_TX_DIVX_CLK;      break;
        case 0x15: *bsb_clk_sel = AVAGO_SERDES_BSB_RX_DIVX_CLK;      break;
        case 0x16: *bsb_clk_sel = AVAGO_SERDES_BSB_DIVX_CLK_TEST;    break;
        case 0x17: *bsb_clk_sel = AVAGO_SERDES_BSB_TX_F10_CLK_VAR;   break;
        case 0x18: *bsb_clk_sel = AVAGO_SERDES_BSB_TX_F20_CLK_VAR;   break;
        case 0x19: *bsb_clk_sel = AVAGO_SERDES_BSB_TX_CLK_TEST;      break;
        case 0x1b: *bsb_clk_sel = AVAGO_SERDES_BSB_LSSEL;            break;
        case 0x1c: *bsb_clk_sel = AVAGO_SERDES_BSB_RESET_COMPLETE;   break;
        case 0x1e: *bsb_clk_sel = AVAGO_SERDES_BSB_RX_PI_CLK;        break;
        case 0x1f: *bsb_clk_sel = AVAGO_SERDES_BSB_AVDD;             break;
    }

    *mem_addr = avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_LSB, 0x49) & 0x00ff;
    *mem_bit = avago_serdes_mem_rd(aapl, sbus_addr, AVAGO_LSB, 0x49) & 0x1f00;
    return return_code == aapl->return_code ? 0 : -1;
}


/** @brief   Allocates and initializes a Avago_serdes_health_check_config_t struct. */
/** @details The return value should be released using */
/**          avago_serdes_health_check_config_destruct() after use. */
/** @return  On success, returns a pointer to the initialized structure. */
/** @return  On failure, returns NULL. */
/** @see     avago_serdes_health_check_config_destruct(), avago_serdes_health_check(). */
Avago_serdes_health_check_config_t *avago_serdes_health_check_config_construct(
    Aapl_t *aapl)       /**< [in] Pointer to Aapl_t structure. */
{
    size_t bytes = sizeof(Avago_serdes_health_check_config_t);
    Avago_serdes_health_check_config_t *config;

    if( ! (config = (Avago_serdes_health_check_config_t *) aapl_malloc(aapl, bytes, "Avago_serdes_health_check_config_t struct")) )
        return NULL;
    memset(config, 0, sizeof(*config));         /* set all bytes to zero */
    return config;
}

/** @brief   Releases a Avago_serdes_init_config_t struct. */
/** */
/** @return  None. */
/** @see     avago_serdes_health_check_config_construct(), avago_serdes_health_check(). */
void avago_serdes_health_check_config_destruct(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    Avago_serdes_health_check_config_t *config) /**< [in] Pointer to struct to release. */
{
    aapl_free(aapl, config, "Avago_serdes_health_check_config_t struct");
}

/* Private function for avago_serdes_health_check() */
void health_check_test_int_int(Aapl_t *aapl, Avago_serdes_health_check_config_t *config, const char * str, int check, int value)
{
    if (check != value)
    {
        if (config->verbose) aapl_log_printf(aapl, AVAGO_INFO, __func__, 0, "Serdes '%s' health check failed. Expected: %d Actual: %d.\n", str, check, value);
        config->failed = TRUE;
    }
}

/** @brief   Runs a health check on the SerDes specified. */
/** @details Based on the config input, various tests are run on the specified address. */
/** @return  Returns TRUE for passing, and FALSE for failure. */
/** @see     avago_serdes_health_check_config_destruct(), avago_serdes_health_check(). */
BOOL avago_serdes_health_check(Aapl_t *aapl, uint addr, Avago_serdes_health_check_config_t *config)
{
    BOOL tx_rdy, rx_rdy;

    config->failed = FALSE;

    avago_serdes_get_tx_rx_ready(aapl, addr, &tx_rdy, &rx_rdy);
    if (config->crc)                health_check_test_int_int(aapl, config, "crc",        TRUE,              avago_spico_crc(aapl, addr));
    if (config->spico_running)      health_check_test_int_int(aapl, config, "spico_running",TRUE,            avago_spico_running(aapl, addr));

    if (config->ready)              health_check_test_int_int(aapl, config, "ready",      config->ready,     tx_rdy & rx_rdy);
    if (config->tx_invert_check)    health_check_test_int_int(aapl, config, "tx_invert",  config->tx_invert, avago_serdes_get_tx_invert(aapl, addr));
    if (config->tx_out)             health_check_test_int_int(aapl, config, "tx_out",     config->tx_out,    avago_serdes_get_tx_output_enable(aapl, addr));

    if (config->rx_invert_check)    health_check_test_int_int(aapl, config, "rx_invert",  config->rx_invert, avago_serdes_get_rx_invert(aapl, addr));
    if (config->loopback_check)     health_check_test_int_int(aapl, config, "loopback",   config->loopback,  avago_serdes_get_rx_input_loopback(aapl, addr));
    if (config->elec_idle_check)    health_check_test_int_int(aapl, config, "elec_idle",  0,                 avago_serdes_get_electrical_idle(aapl, addr));
    if (config->signal_ok_check)    health_check_test_int_int(aapl, config, "signal_ok",  1,                 avago_serdes_get_signal_ok(aapl, addr, FALSE));

    if (config->errors_check)       health_check_test_int_int(aapl, config, "errors",     0,                 avago_serdes_get_errors(aapl, addr, AVAGO_LSB, FALSE));

    if (config->failed) return FALSE;
    return TRUE;
}

#if AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT
unsigned char avago_serdes_set_delay_vernier(Aapl_t *aapl, uint addr, int x)
{
    if (aapl_get_process_id(aapl, addr) == AVAGO_TSMC_28)
    {
        if (x<=14)
        {
            int y = 15 - x;
            avago_serdes_mem_rmw(aapl, addr, AVAGO_ESB, 0x2d, y | (y<<4), 0xffff);
            avago_serdes_mem_rmw(aapl, addr, AVAGO_ESB, 0x2e, 0, 0xffff);
        }
        else
        {
            int y = x - 15;
            avago_serdes_mem_rmw(aapl, addr, AVAGO_ESB, 0x2d, 0, 0xffff);
            avago_serdes_mem_rmw(aapl, addr, AVAGO_ESB, 0x2e, (y | (y<<4)) << 8 | y | (y<<4), 0xffff);
        }
        return x;
    }
    else if (aapl_get_process_id(aapl, addr) == AVAGO_TSMC_16)
    {
        int array[] = {
        0xd6, 0xce, 0xd0, 0xb5, 0x95, 0x90, 0xa5, 0xa1, 0x88, 0x84, 0x56, 0x4e, 0x46, 0x50, 0x45, 0x44, 0x06, 0x10, 0x22, 0x03,
        0x01, 0x03, 0x22, 0x10, 0x06, 0x44, 0x45, 0x50, 0x46, 0x4e, 0x56, 0x84, 0x88, 0xa1, 0xa5, 0x90, 0x95, 0xb5, 0xd0, 0xce, 0xd6, -1};

        if (x<=19)
        {
            avago_serdes_mem_rmw(aapl, addr, AVAGO_ESB, 0xb3, array[x], 0xff); /* main */
            avago_serdes_mem_rmw(aapl, addr, AVAGO_ESB, 0xb4, 0, 0xffff); /* edge */
        }
        else
        {
            avago_serdes_mem_rmw(aapl, addr, AVAGO_ESB, 0xb3, 0, 0xff); /* main */
            avago_serdes_mem_rmw(aapl, addr, AVAGO_ESB, 0xb4, array[x] | (array[x] << 8), 0xffff); /* edge */
        }

        return array[x];
    }
    return 0;
}

static uint step_phase_xor(Aapl_t *aapl, uint addr, int target_phase, int *current_phase, int vap[], BOOL x_or)
{
    int errors = 0;

    if (x_or)
    {
        avago_serdes_set_rx_data_qual(aapl, addr, AVAGO_SERDES_RX_DATA_QUAL_PREV1);
        avago_serdes_set_dac(aapl, addr, 0x80+vap[1], 0);
        /*avago_spico_int(aapl, addr, 0x26, 0x1400 | (0x80+vap[1])); */
        /*avago_spico_int(aapl, addr, 0x26, 0x1500 | (0x80+vap[1])); */
    }

    errors = avago_serdes_step_phase(aapl, addr, target_phase, current_phase, 1);

    if (x_or)
    {
        /*Addr DC LF HF BW |d0e 0o 1e 1o|t1e 1o 0e 0o|DFE     1  2  3  4  5  6  7  8  9  A  B  C  D| data height| test height|BER     |Status */
        /*2:17 56 01 0f 07 | 8d 92 6c 72| 83 82 78 80|  9  16.0 -4 -3 -2  0  0  0  0  0  0  0  0  0| 22 22 23 23| 22 22 23 23|2.21e-05|0f 80 */
        /*2:24 62 01 0f 07 | 93 92 75 6f| 8b 80 84 7f|  8  17.0 -4 -3 -2 -1  0  1 -1  0  0  0  0  0| 1f 20 20 20| 1f 20 20 20|2.21e-05|0f 80 */

        avago_serdes_set_rx_data_qual(aapl, addr, AVAGO_SERDES_RX_DATA_QUAL_PREV0);
        avago_serdes_set_dac(aapl, addr, 0x80+vap[0], 0);
        /*avago_spico_int(aapl, addr, 0x26, 0x1400 | (0x80+vap[0]+9)); */
        /*avago_spico_int(aapl, addr, 0x26, 0x1500 | (0x80+vap[0]+9)); */
        errors += avago_serdes_step_phase(aapl, addr, target_phase, current_phase, 1);
    }
    return errors;
}


/** @brief   Configures delay calibration specified in mode. */
/** @details If mode == 4, set tap=I, test=R, edge=Q, data=I (typical non-delay mode) */
/** @details If mode == 3, set tap=I, test=I, edge=Q, data=R (delay data) */
/** @details If mode == 2, disable delay calibration and reset to defaults. */
/** @details If mode == 1, set tap=I, test=I, edge=Q, data=I (typical non-delay mode) */
/** @details If mode == 0, set tap=I, test=I, edge=R, data=I (delay edge) */
/** @details If mode == ~0, return R clock phase value. */
int avago_serdes_delay_cal(Aapl_t *aapl, uint addr, uint mode, bigint dwell, int *start_p, int *stop_p)
{
    int x = 0, start = 0, stop = 0;
    int best_point = 0;
    int errors;
    int min_errors = 1000000000;
    int x_or = 0;
    int vap[6] = {0,0,0,0,0,0};
    int prev_phase = 0;
    int clk_mode = 0;

    /* mode: 0xssSSuumm  s=start, S=stop, u=use this value, m = mode */
    int loop_stop = aapl_get_process_id(aapl, addr) == AVAGO_TSMC_16 ? 40 : 30;
    int stop_val = (mode >> 8) & 0xff;
    int loop_start = (mode >> 24) & 0xff;
    if ((mode >> 16) & 0xff) loop_stop = (mode >> 16) & 0xff;

    if (mode == 0xffffffff) return avago_serdes_get_phase(aapl, addr);

    mode &= 0xff;
    if (aapl_get_process_id(aapl, addr) == AVAGO_TSMC_16)
    {
        avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, 0x93, 0x8888);
        avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, 0xb7, 0x1111);
        if (mode == 2) return 0;

        /*DDR 147/0x93 async DFE_MISC_CTL2               //  8  4  2              1 */
        /*REG  15:12      8   RW TAP_SEL    //        [3:0]: I, Q, dly from 0xb7, dly inv from 0xb7 */
        /*REG   11:8      8   RW T2CLK1_SEL // test   [3:0]: I, R, dly from 0xb7, dly inv from 0xb7 */
        /*REG    7:4      8   RW T2CLK0_SEL // edge   [3:0]: Q, I, dly from 0xb7, dly inv from 0xb7 */
        /*REG    3:0      8   RW D2CLK0_SEL           [3:0]: I, Q, dly from 0xb7, dly inv from 0xb7 */
        if (mode == 0) clk_mode = 0x8828;
        if (mode == 1) clk_mode = 0x8822;
        if (mode == 3) clk_mode = 0x8882;
        if (mode == 4) clk_mode = 0x8448;
        avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, 0x93, clk_mode);

        /*ADDR 183/0xb7 async DFE_CK_OBS        //        8      4      2      1 */
        /*REG  15:12      1   RW TAP_DEL_SEL    // [3:0]: sel R, sel Q, Sel I, sel dlypd */
        /*REG   11:8      1   RW T2CLK1_DEL_SEL // [3:0]: sel R, sel Q, Sel I, sel dlypd */
        /*REG    7:4      1   RW T2CLK0_DEL_SEL // [3:0]: sel R, sel Q, Sel I, sel dlypd */
        /*REG    3:0      1   RW D2CLK0_DEL_SEL // [3:0]: sel R, sel Q, Sel I, sel dlypd */
        if (mode == 0) avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, 0xb7, 0x1181);
        if (mode == 1) avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, 0xb7, 0x1142);
        if (mode == 3) avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, 0xb7, 0x1118);

        /*ADDR 179/0xb3 async DFE_D2CLK0_DEL */
        /*REG   15:8      0   RW TAP_CTL */
        /*REG    7:0      0   RW D2CLK0_CTL */

        /*ADDR 180/0xb4 async DFE_T2CLK_DEL */
        /*REG   15:8      0   RW T2CLK1_CTL // test */
        /*REG    7:0      0   RW T2CLK0_CTL // edge */
    }

    if (avago_serdes_get_rx_cmp_mode(aapl, addr) == AVAGO_SERDES_RX_CMP_MODE_XOR) /* get vert alphas if in XOR mode */
    {
        Avago_serdes_dfe_state_t *dfe_state = avago_serdes_dfe_state_construct(aapl);
        /*int *vos = (int *) dfe_state->vos; */
        /*int *mid = (int *) dfe_state->vosMID; */
        x_or = 1;

        avago_serdes_get_dfe_state(aapl, addr, dfe_state);

        /*vap[0] = aapl_iround((vos[0] - mid[0]           // d0e */
        /*                    + vos[1] - mid[1]) / 2.0);  // d0o */
        /*vap[1] = aapl_iround((vos[2] - mid[2]           // d1e */
        /*                    + vos[3] - mid[3]) / 2.0);  // d1o */
        /*vap[2] = vos[0] - mid[0];   // prev0e */
        /*vap[3] = vos[1] - mid[1];   // prev0o */
        /*vap[4] = vos[2] - mid[2];   // prev1e */
        /*vap[5] = vos[3] - mid[3];   // prev1o */

        vap[0] = (dfe_state->testLEV[5] + dfe_state->testLEV[4]) / 2;
        vap[1] = (dfe_state->testLEV[1] + dfe_state->testLEV[0]) / 2;

        avago_serdes_dfe_state_destruct(aapl, dfe_state);

        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Delay cal in XOR mode. vert_alphas: %d %d %d %d %d %d\n", vap[0], vap[1], vap[2], vap[3], vap[4], vap[5]);
    }

    #define AVAGO_DFE_ADAPTIVE_ENABLED 0x40
    #define DFE_ROW_COL(row,col) ((row << 8) | (col << 12))
    if(avago_spico_int(aapl, addr, 0x126, DFE_ROW_COL(11, 0)) & AVAGO_DFE_ADAPTIVE_ENABLED ) return 0;

    avago_serdes_set_rx_test_clock(aapl, addr, AVAGO_SERDES_RX_CLOCK_R); /* power on the PI -- switches the PI input to R clock */
    avago_serdes_set_rx_data_qual(aapl, addr, AVAGO_SERDES_RX_DATA_QUAL_UNLOCK);
    avago_serdes_set_rx_data_qual(aapl, addr, AVAGO_SERDES_RX_DATA_QUAL_UNQUAL);
    avago_serdes_set_error_timer(aapl, addr, dwell); /* set dwell time */
    avago_serdes_step_phase(aapl, addr, x, &prev_phase, 1); /* clear previous errors */

    if (mode != 1) /* pi mode */
    {
        BOOL signal_ok;
        int signal_ok_count = 0;
        int min_opening = 10;
        int mult = avago_serdes_get_phase_multiplier(aapl, addr);
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "#### SBus address %s Phase mult: %d\n", aapl_addr_to_str(addr), mult);

        if (aapl_get_process_id(aapl, addr) == AVAGO_TSMC_16)
            avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, 0x93, clk_mode); /* set the test channel clock back */

        while (signal_ok_count < 5) /* wait for 5 bad signal OKs in a row */
        {
            errors = -1;
            avago_serdes_step_phase(aapl, addr, ++x, &prev_phase, 0); /* set phase, but don't check errors */
            signal_ok = avago_serdes_get_signal_ok(aapl, addr, TRUE);
            if (aapl->debug > 1) errors = step_phase_xor(aapl, addr, x, &prev_phase, vap, x_or);

            if (!signal_ok) signal_ok_count++; /* count bad signal OKs */
            else signal_ok_count = 0; /* if we get a good one, reset the counter */

            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "## %3d %s %-13d %7.3f\n", x, signal_ok ? "OK" : "--", errors, (float) errors/dwell);
            if (x > 127 * mult) {x = 0; break;} /* prevent infinite loops (max 2UI) */
        }

        signal_ok_count = 0;
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "#### Starting sweep at phase of %d (from %d)\n", x, prev_phase);
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "## %3s %2s %2s (%3s %3s) %3s %3s %s\n", "Val", "OK", "  ", "Sta", "Stp", "Mid", "Siz", "Errors");
        for (; x <= 64 * 4 * mult; x++) /* max 4 UI */
        {
            errors = -1;
            avago_serdes_step_phase(aapl, addr, x, &prev_phase, 0); /* set phase, but don't check errors */

            signal_ok = avago_serdes_get_signal_ok(aapl, addr, TRUE);
            if (signal_ok || start || aapl->debug > 1) errors = step_phase_xor(aapl, addr, x, &prev_phase, vap, x_or);

            if (signal_ok) signal_ok_count ++;
            else if (signal_ok_count < 10) /* latch once we see 10 in a row, otherwise reset count */
            {
                signal_ok_count = 0; /* reset */
                start = 0;
                stop = 0;
            }

            if (signal_ok)
            {
                if (errors < 20 && !start) {start = x; stop = x;} /* initial start point */
                else if (errors < 20) stop = x; /* set stop point to last point with low errors */

                if (!start && (errors < min_errors)) /* if no start point, and we have a new min error count, save it */
                {
                    min_errors = errors;
                    best_point = x;
                }
            }
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "## %3d (%3d) %s %2d (%3d %3d) %3d %3d %-12d %7.3f\n", x, x % 128, signal_ok ? "OK": "--", signal_ok_count, start, stop, (stop-start)/2+start, stop-start, errors, (float) errors/dwell);
            if (signal_ok_count && (errors > 20) && start) min_opening--;
            if (signal_ok_count && (errors > 20) && start && !min_opening) break;
        }
        if (start) x = (stop-start)/2+start;
        else x = best_point;

        if (stop_val)  x = stop_val;
        errors = avago_serdes_step_phase(aapl, addr, x, &prev_phase, 1); /* step phase nicely back to middle */

        if (aapl_get_process_id(aapl, addr) == AVAGO_TSMC_16)
            avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, 0x93, clk_mode); /* switch test back to I clock so DFE tuning will work */
    }
    else /* vernier mode */
    {
        start = 0;
        stop = 41;
        avago_serdes_set_rx_test_clock(aapl, addr, AVAGO_SERDES_RX_CLOCK_I); /* switch test to I clock */

        for (x = loop_start; x<=loop_stop; x++)
        {
            unsigned char value;
            value = avago_serdes_set_delay_vernier(aapl, addr, x);
            errors = step_phase_xor(aapl, addr, x, &prev_phase, vap, x_or);

            if (errors < 20 && !start) start = x;
            else if (errors < 20) stop = x;

            if (!start && (errors < min_errors))
            {
                min_errors = errors;
                best_point = x;
            }
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "## %2d %2d %2d %2d %02x %u\n", x, start, stop, (stop-start)/2+start, value, errors);
        }
        if (start) x = (stop-start)/2+start;
        else x = best_point;

        avago_serdes_set_delay_vernier(aapl, addr, x);
        ms_sleep(100);
        errors = step_phase_xor(aapl, addr, x, &prev_phase, vap, x_or);
    }
    avago_serdes_set_rx_data_qual(aapl, addr, AVAGO_SERDES_RX_DATA_QUAL_UNLOCK);
    avago_serdes_set_rx_data_qual(aapl, addr, AVAGO_SERDES_RX_DATA_QUAL_UNQUAL);

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "#### Setting delay to: %d (% 128: %d). Errors: %d\n", x, x % 128, errors);
    if (start_p) *start_p = start;
    if (stop_p) *stop_p = stop;

    return x;
}
#endif /* AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT */

#if AAPL_ENABLE_FLOAT_USAGE
#include "timer.h"

#if AAPL_ENABLE_MAIN
/** @return Returns TRUE if specific eye is selected. */
static BOOL select_eye(Aapl_t *aapl, uint addr, int loop)
{
    Avago_serdes_data_qual_t dq;
    Avago_serdes_datapath_t dp;
    char *dq_buf = 0, *dq_buf_end = 0;
    int dq_size = 0;

    avago_serdes_get_rx_datapath(aapl, addr, &dp);
    if( dp.precode_enable ) return FALSE;
    /* Note: Gray does not affect the selection patterns: */
    /* */
    if( loop == 6 )             aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "xxx");
    else
    {
        if(      !dp.swizzle_enable && !dp.polarity_invert )    /* Straight */
        {
            if      (loop % 3 == 2) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "x[23]x,lsb");
            else if (loop % 3 == 1) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "msb");
            else                    aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "x[01]x,lsb");
        }
        else if( !dp.swizzle_enable && dp.polarity_invert )     /* Polarity Invert */
        {
            if      (loop % 3 == 2) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "x[01]x,lsb");
            else if (loop % 3 == 1) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "msb");
            else                    aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "x[23]x,lsb");
        }
        else if( dp.swizzle_enable && !dp.polarity_invert )     /* Swizzle */
        {
            if      (loop % 3 == 2) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "x[13]x,msb");
            else if (loop % 3 == 1) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "lsb");
            else                    aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "x[02]x,msb");
        }
        else if( dp.swizzle_enable && dp.polarity_invert)       /* Swizzle + Polarity Invert */
        {
            if      (loop % 3 == 2) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "x[02]x,msb");
            else if (loop % 3 == 1) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "lsb");
            else                    aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "x[13]x,msb");
        }

        if( loop <= 2 ) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, ",even");
        else            aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, ",odd");
    }

    dq = aapl_data_qual_from_str(dq_buf, "data_qual");
    avago_serdes_set_data_qual(aapl, addr, dq);
    aapl_free(aapl, dq_buf, __func__);

    avago_aacs_flush(aapl);
    ms_sleep(5); /* wait for data-qual to take effect before checking errors below (seems to help one customer, but should not be necessary) */
    return loop != 6;
}
#endif /* AAPL_ENABLE_MAIN */

/** @brief   Measures the BER of the Rx at each address in the list. */
/** @details All measurements are performed in parallel. */
/**          If console is true, each BER is displayed.  Otherwise, a single address should be specified. */
/**          The BER is calculated over the given number of seconds using an estimate of the data rate. */
/** @return  If a single address is given, its estimated BER is returned. */
float avago_serdes_get_ber_eye(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    Avago_addr_t *addr_struct,  /**< [in] Addresses to perform BER measurement on. If console is false, this should only be one address. */
    uint dwell,                 /**< [in] Dwell time, in seconds. */
    int eye_select,             /**< [in] Which eye to measure [-1..6]. */
    uint refclk,                /**< [in] Reference clock frequency in Hertz.  If zero, use an estimated frequency. */
    BOOL console,               /**< [in] If true, use aapl_log_printf to send data to console, otherwise only the return value is made. */
    BOOL reset,                 /**< [in] Reset the error counter prior to making BER measurement. */
    BOOL use_aux_errors)        /**< [in] Use the aux error counter instead of the standard error counter. The user should either already have the counter enabled, or have the reset input set to TRUE */
{
    const char *eye_descrip[] =
    {
        "Lower even",
        "Middle even",
        "Upper even",
        "Lower odd",
        "Middle odd",
        "Upper odd",
        "Overall"
    };
    Avago_addr_t start, stop, next; BOOL st;
    char *buf = 0, *buf_end = 0;
    int size = 0, eye;
    float ber = 0;

    struct ber_data_t { uint errors; uint addr; Aapl_microtimer_t timer; } *ber_data = 0;
    int serdes_count;

    if (console)
    {
        const char *sep = "---------------";
        aapl_buf_add(aapl, &buf, &buf_end, &size, "%7s  %7s %10s %10s %10s %10s %10s\n", "Addr", "Rate", "Dwell (s)", "Errors", "Error Diff", "Errors/sec", "Approx BER");
        aapl_buf_add(aapl, &buf, &buf_end, &size, "%.7s  %.7s %.10s %.10s %.10s %.10s %.10s\n", sep, sep, sep, sep, sep, sep, sep);
    }

    /* Count the number of SerDes we are measuring: */
    serdes_count = 0;
    for( st = aapl_broadcast_first(aapl, addr_struct, &start, &stop, &next, 0); st; st = aapl_broadcast_next(aapl, &next, &start, &stop, 0) )
    {
        uint addr = avago_struct_to_addr(&next);
        if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, FALSE, 4, AVAGO_M4, AVAGO_SERDES, AVAGO_BLACKHAWK, AVAGO_P1) )
            continue; /* don't call lower level functions unless they are known types */
        serdes_count++;
    }
    if( serdes_count <= 0 )
        return 0;

    /* Allocate arrays for the data: */
    ber_data = (struct ber_data_t *)aapl_malloc(aapl, serdes_count * sizeof(struct ber_data_t), __func__);

    /* Initialize array addresses: */
    serdes_count = 0;
    for( st = aapl_broadcast_first(aapl, addr_struct, &start, &stop, &next, 0); st; st = aapl_broadcast_next(aapl, &next, &start, &stop, 0) )
    {
        uint addr = avago_struct_to_addr(&next);
        if( !aapl_check_ip_type(aapl, addr, __func__, __LINE__, FALSE, 4, AVAGO_M4, AVAGO_SERDES, AVAGO_BLACKHAWK, AVAGO_P1) )
            continue; /* don't call lower level functions unless they are known types */
        ber_data[serdes_count++].addr = addr;
    }

    /* Gather data for each eye: */
    for( eye = 0; eye <= 6; eye++ )
    {
        static int sigint = 0;
        int ber_data_index = 0;

        if (eye_select != -1) eye = eye_select; /* Only one eye selected */

        /* Initialize state information and start error count for each SerDes: */
        for( ber_data_index = 0; ber_data_index < serdes_count; ber_data_index++ )
        {
            uint addr = ber_data[ber_data_index].addr;

#if AAPL_ENABLE_MAIN
            Avago_serdes_line_encoding_t tx, rx;
            if ((eye_select != -1 || console) && (eye_select != -1 || aapl->verbose) && ((aapl_get_ip_type(aapl, addr) == AVAGO_M4) && (avago_serdes_get_tx_rx_line_encoding(aapl, addr, &tx, &rx) == 0 && rx == AVAGO_SERDES_PAM4))) /* measure all 6 eyes */
            {
                if( !select_eye(aapl, addr, eye) && eye_select == -1 )
                    eye = 6;   /* Unknown qualification */
            }
            else
#endif /* AAPL_ENABLE_MAIN */
            eye = 6;   /* Default */

            if (reset)
            {
                if (use_aux_errors) avago_serdes_aux_counter_start(aapl, addr);
                else                avago_serdes_error_reset(aapl, addr);
                ber_data[ber_data_index].errors = 0;
            }
            else
            {
                if (use_aux_errors) ber_data[ber_data_index].errors = avago_serdes_aux_counter_read(aapl, addr);
                else                ber_data[ber_data_index].errors = avago_serdes_get_errors(aapl, addr, AVAGO_LSB, 0);
            }
            aapl_timer_reset_start(&ber_data[ber_data_index].timer);
        }

        /* Sleep for requested period of time: */
        avago_aacs_flush(aapl);
        if (dwell) ms_sleep(dwell * 1000);
        if (aapl_sigint_detected > 0) sigint++; /* increment local sigint counter */
        if (sigint == 1 && aapl_sigint_detected > 0) aapl_sigint_detected -= 1; /* if on the FIRST sigint, ignore it */

        /* Measure errors and calculate BER results: */
        for( ber_data_index = 0; ber_data_index < serdes_count; ber_data_index++ )
        {
            uint addr = ber_data[ber_data_index].addr;
            float errors_per_second = 0, wait_time;
            Avago_serdes_pll_state_t pll_state;
            uint error_diff, curr_errors;
            Avago_serdes_line_encoding_t pam_tx, pam_rx;
            BOOL no_ber;
            Avago_serdes_rx_cmp_mode_t  rx_cmp_mode  = avago_serdes_get_rx_cmp_mode(aapl, addr);
            Avago_serdes_data_qual_t    data_qual  = avago_serdes_get_data_qual(aapl,addr);
            if (aapl->debug || (
            strstr("unqual", aapl_data_qual_to_str(data_qual)) &&
            rx_cmp_mode != AVAGO_SERDES_RX_CMP_MODE_OFF && rx_cmp_mode != AVAGO_SERDES_RX_CMP_MODE_XOR))
                no_ber = FALSE;
            else no_ber = TRUE;

            if (use_aux_errors) curr_errors = avago_serdes_aux_counter_read(aapl, addr);
            else                curr_errors = avago_serdes_get_errors(aapl, addr, AVAGO_LSB, 0);

            wait_time = aapl_timer_get(&ber_data[ber_data_index].timer) / 1000000.0;
            error_diff = curr_errors - ber_data[ber_data_index].errors;
            errors_per_second = error_diff / wait_time;
            if (errors_per_second >= 999999999) errors_per_second = 999999999;
            avago_serdes_get_tx_pll_state(aapl, addr, &pll_state);     /* Get PLL state, which contains the divider and estimated bitrate */

            if( refclk )
                pll_state.est_rate = (bigint)refclk * pll_state.divider;    /* Use actual rate if refclk is set. */

            avago_serdes_get_tx_rx_line_encoding(aapl, addr, &pam_tx, &pam_rx);

            pll_state.est_rate *= (int) (pam_rx) + 1;

            if (!error_diff) ber = (error_diff+1) / ((float) pll_state.est_rate * wait_time);
            else             ber = error_diff     / ((float) pll_state.est_rate * wait_time);

            if (console)
            {
                aapl_buf_add(aapl, &buf, &buf_end, &size, "%7s @%7.3f ", aapl_addr_to_str(addr), (float) pll_state.est_rate / 1000000000);
                if (curr_errors >= 0xffffffffU) /* || no_ber) */
                     aapl_buf_add(aapl, &buf, &buf_end, &size, "%10.3f %10u %10s %10s %10s",         wait_time, 0xffffffffU,  "Unknown",  "Unknown",         "N/A");
                else aapl_buf_add(aapl, &buf, &buf_end, &size, "%10.3f %10u %10u %10.0f %s%.3e",     wait_time, curr_errors, error_diff, errors_per_second, error_diff ? " " : "<", ber);
                if (curr_errors >= 0xffffffffU) aapl_buf_add(aapl, &buf, &buf_end, &size, "  No BER reported due to max error count.\n");
                else if (no_ber && !aapl->verbose && !use_aux_errors) aapl_buf_add(aapl, &buf, &buf_end, &size, "  WARNING: BER reported may be inaccurate due to data qualification or compare issue. Fix with \"aapl serdes -rx-mode prbs31\".\n");
                else if (aapl->verbose) aapl_buf_add(aapl, &buf, &buf_end, &size, "  %s eye, dq = %s\n", eye_descrip[eye], aapl_data_qual_to_str(data_qual));
                else aapl_buf_add(aapl, &buf, &buf_end, &size, "\n");
            }
            if (!error_diff) ber = 0; /* if there were no errors, return 0 for the BER to the caller */
            if (buf)
            {
                if (console) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%s", buf);
                aapl_free(aapl, buf, __func__);
                buf = 0;
            }
        }
        if (eye_select != -1) break;    /* Break if only one eye selected */
    }
    aapl_free(aapl, ber_data, __func__);
    return ber;
}

/** @brief   Measures the BER of the Rx at each address in the list. */
/** @details All measurements are performed in parallel. */
/**          If console is true, each BER is displayed.  Otherwise, a single address should be specified. */
/**          The BER is calculated over the given number of seconds using an estimate of the data rate. */
/** @return  If a single address is given, its estimated BER is returned. */
float avago_serdes_get_ber(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    Avago_addr_t *addr_struct,  /**< [in] Addresses to perform BER measurement on. If console is false, this should only be one address. */
    uint dwell,                 /**< [in] Dwell time, in seconds. */
    uint refclk,                /**< [in] Reference clock frequency in Hertz.  If zero, use an estimated frequency. */
    BOOL console,               /**< [in] If true, use aapl_log_printf to send data to console, otherwise only the return value is made. */
    BOOL reset,                 /**< [in] Reset the error counter prior to making BER measurement. */
    BOOL use_aux_errors)        /**< [in] Use the aux error counter instead of the standard error counter. The user should either already have the counter enabled, or have the reset input set to TRUE */
{
    return avago_serdes_get_ber_eye(aapl, addr_struct, dwell, -1, refclk, console, reset, use_aux_errors);
}

static void tune_vernier_eye(Aapl_t *aapl, uint addr, int loop, Avago_serdes_vernier_delay_t *vernier, short *ptr)
{
    int x;
    char *buf = 0, *buf_end = 0;
    int size = 0;
    int start = 99, stop = 99;
    int best_vernier;
    float best_ber = 1;
    int initial_value;
    Avago_addr_t addr_struct;
    avago_addr_to_struct(addr,&addr_struct);

    best_vernier = *ptr; /* go back to starting point if nothing better is ever found */
    initial_value = *ptr;
    if (aapl->verbose) aapl_buf_add(aapl, &buf, &buf_end, &size,"### %2d %3d ", loop, *ptr);
    {
        Avago_serdes_data_qual_t    data_qual  = avago_serdes_get_data_qual(aapl,addr);
        if (aapl->verbose) aapl_buf_add(aapl, &buf, &buf_end, &size, "  %s", aapl_data_qual_to_str(data_qual));
    }

    if (buf) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "%s\n", buf);
    for (x = -10; x<=10; x++)
    {
        float ber;
        *ptr = initial_value + x;
        avago_serdes_vernier_delay_write(aapl, addr, vernier);
        avago_serdes_vernier_delay_apply(aapl, addr, -1, vernier);
        ber = avago_serdes_get_ber_eye(aapl, &addr_struct, 0, loop, 0, 0, 1, 0);

        if (!ber && start == 99) start = *ptr;
        if (start != 99 && ber && stop == 99) stop = *ptr;

        if (ber < best_ber)
        {
            best_ber = ber;
            best_vernier = *ptr;
        }
        if (aapl->verbose) aapl_log_printf(aapl, AVAGO_INFO, 0, 0,"### %4d %3d %6.3e %3d || %2d %2d \n", loop, *ptr, ber, best_vernier, start, stop);
    }
    if (start !=99 && stop == 99) stop = *ptr;
    if (aapl->verbose) aapl_log_printf(aapl, AVAGO_INFO, 0, 0,"###                  %3d || %2d %2d \n", best_vernier, start, stop);

    if (buf) aapl_free(aapl, buf, __func__); /* reset buffer to use again */
    buf = 0;
    buf_end = 0;
    size = 0;
    {
        Avago_serdes_data_qual_t    data_qual  = avago_serdes_get_data_qual(aapl,addr);
        aapl_buf_add(aapl, &buf, &buf_end, &size, "%s", aapl_data_qual_to_str(data_qual));
    }

    if (start != 99) best_vernier = (stop - start)/2+start;

    aapl_log_printf(aapl, AVAGO_INFO, 0,0, "Vernier tuning for loop %d (%20s) complete. Initial: %2d. Best: %2d\n", loop, buf, initial_value, best_vernier);
    *ptr = best_vernier;
    avago_serdes_vernier_delay_write(aapl, addr, vernier);
    avago_serdes_vernier_delay_apply(aapl, addr, -1, vernier);

    if (aapl->verbose) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n");
}

void avago_serdes_tune_vernier(Aapl_t *aapl, uint addr)
{
    int loop = 0;
    Avago_serdes_vernier_delay_t vernier;

    avago_serdes_vernier_delay_read(aapl, addr, &vernier);

    tune_vernier_eye(aapl, addr, loop++, &vernier, &vernier.lower_even_dly);
    tune_vernier_eye(aapl, addr, loop++, &vernier, &vernier.middle_even_dly);
    tune_vernier_eye(aapl, addr, loop++, &vernier, &vernier.upper_even_dly);
    tune_vernier_eye(aapl, addr, loop++, &vernier, &vernier.lower_odd_dly);
    tune_vernier_eye(aapl, addr, loop++, &vernier, &vernier.middle_odd_dly);
    tune_vernier_eye(aapl, addr, loop++, &vernier, &vernier.upper_odd_dly);
}

void avago_serdes_param_sweep(Aapl_t *aapl, uint addr, Avago_serdes_param_sweep_t *options)
{
    int mem_addr[] = {0xef, 0xf7, 0x9a, 0x95, 0x96, 0x99, 0};
    int *mem_addr_ptr = mem_addr;
    int error_ratio_fail = 0, loop;
    if (!options->step_size) options->step_size = 1;

    aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "## SBus addr: %s mem_addr: 0x%04x, latch_mask: 0x%04x, range to be tested:: %x - %x\n", aapl_addr_to_str(addr), options->mem_addr, options->latch_mask, options->min_range, options->max_range);

    if (options->mem_addr)
    {
        mem_addr[0] = options->mem_addr;
        mem_addr[1] = 0;
    }
    for (loop = 0; loop <= 5; loop++)
    {
        int initial = avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, *mem_addr_ptr) & ~(options->latch_mask);
        int start = 0, stop = 0, x;
        int error_ratio_fail_local = 0;
        int phase = 0;
        uint min_errors = 0xffffffff, min_errors_loc = 0;

        if (mem_addr[1] != 0 && options->enable_qual)
        {
            Avago_serdes_data_qual_t dq;
            Avago_serdes_datapath_t dp;
            char *dq_buf = 0, *dq_buf_end = 0;
            int dq_size = 0;

            avago_serdes_get_rx_datapath(aapl, addr, &dp);
            if (!dp.gray_enable && !dp.swizzle_enable && !dp.polarity_invert)
            {
                if      ((loop % 3) == 0) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "x[01]x,lsb");
                else if ((loop % 3) == 1) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "msb");
                else if ((loop % 3) == 2) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "x[23]x,lsb");
            }
            else if (dp.gray_enable && dp.swizzle_enable && !dp.polarity_invert)
            {
                if      ((loop % 3) == 0) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "x[13]x,msb");
                else if ((loop % 3) == 1) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "lsb");
                else if ((loop % 3) == 2) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, "x[02]x,msb");
            }

            if (loop <= 2) aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, ",even");
            else           aapl_buf_add(aapl, &dq_buf, &dq_buf_end, &dq_size, ",odd");

            aapl_str_to_data_qual(dq_buf, &dq);
            avago_serdes_set_data_qual(aapl, addr, dq);
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "## %20s  ", dq_buf);

            avago_aacs_flush(aapl);
            ms_sleep(5); /* wait for data-qual to take effect before checking errors below (seems to help one customer, but should not be necessary) */
        }

        if (options->pi) phase = avago_serdes_get_phase(aapl, addr);
        for (x = options->min_range; x< options->max_range; x+=options->step_size)
        {
            uint errors, errors2 = 0;
            float error_ratio = 0;
            int bits = 1e6;

            if (options->pi)
            {
                avago_serdes_step_phase(aapl, addr, x, &phase, 0);
                phase = x;
            }
            else avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, *mem_addr_ptr, x);

            if (options->no_timer)
            {
                avago_serdes_error_reset(aapl, addr);
                errors = avago_serdes_get_errors(aapl, addr, AVAGO_LSB, 1);
            }
            else errors = avago_serdes_count_errors(aapl, addr, bits);

            if (options->latch_test)
            {
                avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, *mem_addr_ptr, options->latch_mask | x);
                if (options->no_timer)
                {
                    avago_serdes_error_reset(aapl, addr);
                    errors2 = avago_serdes_get_errors(aapl, addr, AVAGO_LSB, 1);
                }
                else errors2 = avago_serdes_count_errors(aapl, addr, bits);

                error_ratio = fabs((float) (errors2-errors)/bits * 100);
                if (error_ratio > 200) error_ratio_fail_local++;
            }
            if (errors < min_errors)
            {
                min_errors = errors;
                min_errors_loc = x;
            }

            if (!errors && !start) start = x;
            if (start && errors && !stop) stop = x;

            if (aapl->verbose && options->latch_test) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "## %2x %3x -> %3x %3x %3x %3x %10d %10d  %10.3f  %3d\n", *mem_addr_ptr, x, options->latch_mask | x, start, stop, stop ? (stop-start)/2+start : 0, errors, errors2, error_ratio, error_ratio_fail_local);
            else if (aapl->verbose)                   aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "## %2x %3x %3x %3x %3x %10d\n", *mem_addr_ptr, x, start, stop, stop ? (stop-start)/2+start : 0, errors);
       }
       if (options->latch_test) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "## Addr: 0x%2x window: %3x to %3x size: %3x (%3d) initial: 0x%03x center: 0x%03x ratio_failures: %3d min_errors: %9d @ %x\n", *mem_addr_ptr, start, stop, stop-start, stop-start, initial, (stop-start)/2+start, error_ratio_fail_local, min_errors, min_errors_loc);
       else                     aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "## Addr: 0x%2x window: %3x to %3x size: %3x (%3d) initial: 0x%03x center: 0x%03x min_errors: %9d @ %x\n", *mem_addr_ptr, start, stop, stop-start, stop-start, initial, (stop-start)/2+start, min_errors, min_errors_loc);

       if (options->center)
       {
           avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, *mem_addr_ptr, (stop-start)/2+start);
           avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, *mem_addr_ptr, ((stop-start)/2+start)| options->latch_mask); /* raise latch hold bit */
       }
       else
       {
           avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, *mem_addr_ptr, initial);
           avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, *mem_addr_ptr, initial | options->latch_mask); /* raise latch hold bit */
       }
       error_ratio_fail += error_ratio_fail_local;
       mem_addr_ptr++;
       if (!*mem_addr_ptr || options->pi) break;
    }
    if (options->latch_test) aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "## Total number of error ratio failures for %s: %d\n", aapl_addr_to_str(addr), error_ratio_fail);
}

#endif /* AAPL_ENABLE_FLOAT_USAGE */
#endif /* AAPL_ENABLE_DIAG */
