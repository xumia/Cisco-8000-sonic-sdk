/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/** Doxygen File Header */
/** @file */
/** @brief Functions for string conversion. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

/* Utility functions for doing both name to type and type to name conversions. */

/** @defgroup Conversions Type to String and String to Type Conversion Functions */
/** @{ */

#if AAPL_ENABLE_MAIN && AAPL_ENABLE_DIAG
/*// */
static Aapl_conv_table_t bsb_mode_table[] =
{
    { "BSB_DISABLE",    AVAGO_SERDES_BSB_DISABLE  },
    { "BSB_CLK",        AVAGO_SERDES_BSB_CLK      },
    { "BSB_PASSTHRU",   AVAGO_SERDES_BSB_PASSTHRU },
    { "BSB_DMA",        AVAGO_SERDES_BSB_DMA      },
    { "BSB_SBUS",       AVAGO_SERDES_BSB_SBUS     },
    { "BSB_CORE",       AVAGO_SERDES_BSB_CORE     },
    { 0,                0 }
};

/** @brief  Converts an Avago_serdes_bsb_mode_t value into a string. */
/** @return Returns a string representing the bsb mode. */
/** @see    aapl_str_to_bsb_mode(). */
const char *aapl_bsb_mode_to_str(
    Avago_serdes_bsb_mode_t value)  /**< [in] bsb mode. */
{
    Aapl_conv_table_t *table = bsb_mode_table;
    int index = value_to_index(table,value);
    return index >= 0 ? table[index].name : "unknown";
}

/** @brief  Converts a string into an Avago_serdes_bsb_mode_t value. */
/** @return Returns TRUE and updates *out if a recognized mode string. */
/** @return Returns FALSE if an unrecognized mode. */
/** @see    aapl_bsb_mode_to_str(). */
BOOL aapl_str_to_bsb_mode(
    const char *name,              /**< [in]  String to be parsed. */
    Avago_serdes_bsb_mode_t *out)  /**< [out] Recognized bsb mode. */
{
    Aapl_conv_table_t *table = bsb_mode_table;
    int index = name_to_index(table,name,4);
    if( index >= 0 )
        *out = (Avago_serdes_bsb_mode_t)table[index].value;
    return index >= 0;
}

static Aapl_conv_table_t bsb_table[] =
{
    {"GND",              AVAGO_SERDES_BSB_GND               },
    {"RX_F10",           AVAGO_SERDES_BSB_RX_F10            },
    {"RX_F20",           AVAGO_SERDES_BSB_RX_F20            },
    {"RX_F40_FIFO_CLK",  AVAGO_SERDES_BSB_RX_F40_FIFO_CLK   },
    {"RX_CLK",           AVAGO_SERDES_BSB_RX_CLK            },
    {"RX_FIFO_CLK",      AVAGO_SERDES_BSB_RX_FIFO_CLK       },
    {"RX_F66_CLK",       AVAGO_SERDES_BSB_RX_F66_CLK        },
    {"PCS6466_FIFO_CLK", AVAGO_SERDES_BSB_PCS6466_FIFO_CLK  },
    {"TX_F10",           AVAGO_SERDES_BSB_TX_F10            },
    {"TX_F20",           AVAGO_SERDES_BSB_TX_F20            },
    {"TX_F40",           AVAGO_SERDES_BSB_TX_F40            },
    {"TX_FIFO_CLK",      AVAGO_SERDES_BSB_TX_FIFO_CLK       },
    {"SBUS_CLK",         AVAGO_SERDES_BSB_SBUS_CLK          },
    {"SBUS_CLK_TEST",    AVAGO_SERDES_BSB_SBUS_CLK_TEST     },
    {"TX_TEST_CLK",      AVAGO_SERDES_BSB_TX_TEST_CLK       },
    {"REFCLK",           AVAGO_SERDES_BSB_REFCLK            },
    {"REFCLK_TEST",      AVAGO_SERDES_BSB_REFCLK_TEST       },
    {"TX_DIVX_CLK",      AVAGO_SERDES_BSB_TX_DIVX_CLK       },
    {"RX_DIVX_CLK",      AVAGO_SERDES_BSB_RX_DIVX_CLK       },
    {"DIVX_CLK_TEST",    AVAGO_SERDES_BSB_DIVX_CLK_TEST     },
    {"TX_F10_CLK_VAR",   AVAGO_SERDES_BSB_TX_F10_CLK_VAR    },
    {"TX_F20_CLK_VAR",   AVAGO_SERDES_BSB_TX_F20_CLK_VAR    },
    {"TX_CLK_TEST",      AVAGO_SERDES_BSB_TX_CLK_TEST       },
    {"LSSEL",            AVAGO_SERDES_BSB_LSSEL             },
    {"RESET_COMPLETE",   AVAGO_SERDES_BSB_RESET_COMPLETE    },
    {"RX_PI_CLK",        AVAGO_SERDES_BSB_RX_PI_CLK         },
    {"AVDD",             AVAGO_SERDES_BSB_AVDD              },
    { 0,                 0 }
};

/** @brief  Converts an Avago_serdes_bsb_clk_sel_t value into a string. */
/** @return Returns a string representing the bsb clock. */
/** @see    aapl_str_to_bsb_clk(). */
const char *aapl_bsb_clk_to_str(
    Avago_serdes_bsb_clk_sel_t value)  /**< [in] bsb clock select value. */
{
    Aapl_conv_table_t *table = bsb_table;
    int index = value_to_index(table,value);
    return index >= 0 ? table[index].name : "unknown";
}

/** @brief  Converts a string into an Avago_serdes_bsb_clk_sel_t value. */
/** @return Returns TRUE and updates *out if a recognized clock string. */
/** @return Returns FALSE if an unrecognized clock. */
/** @see    aapl_bsb_clk_to_str(). */
BOOL aapl_str_to_bsb_clk(
    const char *name,                 /**< [in] String to be parsed. */
    Avago_serdes_bsb_clk_sel_t *out)  /**< [out] Recognised bsb clock. */
{
    Aapl_conv_table_t *table = bsb_table;
    int index = name_to_index(table,name,0);
    if( index >= 0 )
        *out = (Avago_serdes_bsb_clk_sel_t)table[index].value;
    return index >= 0;
}
#endif /* AAPL_ENABLE_MAIN && AAPL_ENABLE_DIAG */

/*////// */


static Aapl_conv_table_t data_qual_table[] =
{
    { "PREV0",      AVAGO_SERDES_RX_DATA_QUAL_PREV0 },
    { "PREV1",      AVAGO_SERDES_RX_DATA_QUAL_PREV1 },
    { "PREV0E",     AVAGO_SERDES_RX_DATA_QUAL_PREV0E },
    { "PREV0O",     AVAGO_SERDES_RX_DATA_QUAL_PREV0O },
    { "PREV1E",     AVAGO_SERDES_RX_DATA_QUAL_PREV1E },
    { "PREV1O",     AVAGO_SERDES_RX_DATA_QUAL_PREV1O },
    { "UNQUAL",     AVAGO_SERDES_RX_DATA_QUAL_UNQUAL },
    { "DEFAULT",    AVAGO_SERDES_RX_DATA_QUAL_DEFAULT },
    { "ODD",        AVAGO_SERDES_RX_DATA_QUAL_ODD },
    { "EVEN",       AVAGO_SERDES_RX_DATA_QUAL_EVEN },
    { "UNLOCK",     AVAGO_SERDES_RX_DATA_QUAL_UNLOCK },
    { 0,            0 }
};

/** @brief  Converts an Avago_serdes_rx_data_qual_t value into a string. */
/** @return Returns a string representing the rx data qual. */
const char *aapl_rx_data_qual_to_str(Avago_serdes_rx_data_qual_t dq)
{
    Aapl_conv_table_t *table = data_qual_table;
    int index = value_to_index(table, dq);
    if( index >= 0 )
        return table[index].name;
    else
    {
        static char buf[32];
        sprintf(buf,"RX_DATA_QUAL_0x%x",(int)dq);
        return buf;
    }
}

static int merge_patterns(int *patterns, int from_len)
{
    int from, to_len = 0;

    for( from = 0; from < from_len; from++ )
    {
        BOOL merged = FALSE;
        int to;
        for( to = 0; to < to_len; to++ )
        {
            if( ((patterns[from] & 0xff0) == (patterns[to] & 0xff0)) ||
                ((patterns[from] & 0xf0f) == (patterns[to] & 0xf0f)) ||
                ((patterns[from] & 0x0ff) == (patterns[to] & 0x0ff)) )
            {
                patterns[to] |= patterns[from];
                merged = TRUE;
                break;
            }
        }
        if( !merged )
            patterns[to_len++] = patterns[from];
    }
    if( to_len < from_len )
        to_len = merge_patterns(patterns, to_len);
    return to_len;
}

static int m4_data_qual_to_str(char *buf, int len, short unsigned int *cmp)
{
    const char *tbl[] = { "-", "0", "1", "[01]", "2", "[02]", "[12]", "[012]", "3", "[03]", "[13]", "[013]", "[23]", "[023]", "[123]", "x" };
    char *end = buf + len;
    char *ptr = buf;

    /* Need to design an algorithm as there are billions of possibilities. */
    int pattern_list[64];
    int list_len = 0;
    int i;
    for( i = 0; i < 64; i++)
    {
        if( cmp[i>>4] & (1 << (i&0xf)) )    /* If that bit is set */
        {
            /* set a bit in each quad indicating the bit of that pattern: */
            pattern_list[list_len]  = 0x001 << ((i >> 0) & 0x03)
                                   |  0x010 << ((i >> 2) & 0x03)
                                   |  0x100 << ((i >> 4) & 0x03);
            list_len++;
        }
    }
    /* Merge the quads together: */
    list_len = merge_patterns(pattern_list, list_len);
    *buf = '\0';

    /* Convert the quads to a string: */
    for( i = 0; i < list_len; i++ )
    {
        int p = pattern_list[i];
        if( i > 0 && ptr <= end ) ptr += snprintf(ptr,end-ptr,",");
        if( ptr <= end )
            ptr += snprintf(ptr, end-ptr, "%s%s%s", tbl[(p>>8) & 0xf],tbl[(p>>4) & 0xf],tbl[(p>>0) & 0xf]);
    }
    if( ptr > end )
    {
        ptr = end;
        /* printf("WARNING: OUTPUT IS TRUNCATED\n"); */
    }
    return ptr-buf;
}

/** @brief  Converts an Avago_serdes_data_qual_t value into a string. */
/** @return Returns a string representing the type. */
/** @see    aapl_data_qual_from_str(). */
const char *aapl_data_qual_to_str(
    Avago_serdes_data_qual_t dq)  /**< [in] Data qual type. */
{
    static char buf[64];
    char *ptr = buf;
    char temp[12];
    temp[0] = '\0';

    if( dq.cmp_valid_pre & 8 )
        ptr += snprintf(ptr,sizeof(buf)+buf-ptr,"%d",dq.cmp_valid_pre & 7);
    else if( dq.cmp_valid_post & 8 )
        ptr += snprintf(ptr,sizeof(buf)+buf-ptr,"x");

    if( dq.d6_data_qual == AVAGO_SERDES_RX_DATA_QUAL_DEFAULT )
        strcpy(temp,"DEFAULT");
    else if( !dq.pam )
    {
        int d6_dq = dq.d6_data_qual;
        if( d6_dq & 0xff )
        {
            switch( d6_dq & 0xff )
            {
            case 0x01: strcpy(temp,"000"); break;
            case 0x02: strcpy(temp,"001"); break;
            case 0x03: strcpy(temp,"00x"); break;
            case 0x04: strcpy(temp,"010"); break;
            case 0x05: strcpy(temp,"0x0"); break;
            case 0x08: strcpy(temp,"011"); break;
            case 0x0a: strcpy(temp,"0x1"); break;
            case 0x0c: strcpy(temp,"01x"); break;
            case 0x0f: strcpy(temp,"0xx"); break;
            case 0x10: strcpy(temp,"100"); break;
            case 0x11: strcpy(temp,"x00"); break;
            case 0x20: strcpy(temp,"101"); break;
            case 0x22: strcpy(temp,"x01"); break;
            case 0x30: strcpy(temp,"10x"); break;
            case 0x33: strcpy(temp,"x0x"); break;
            case 0x40: strcpy(temp,"110"); break;
            case 0x44: strcpy(temp,"x10"); break;
            case 0x50: strcpy(temp,"1x0"); break;
            case 0x55: strcpy(temp,"xx0"); break;
            case 0x80: strcpy(temp,"111"); break;
            case 0x88: strcpy(temp,"x11"); break;
            case 0xa0: strcpy(temp,"1x1"); break;
            case 0xaa: strcpy(temp,"xx1"); break;
            case 0xc0: strcpy(temp,"11x"); break;
            case 0xcc: strcpy(temp,"x1x"); break;
            case 0xf0: strcpy(temp,"1xx"); break;
            case 0xff: strcpy(temp,"xxx"); break;

            case 0x18: strcpy(temp,"011,100"); break;
            case 0x81: strcpy(temp,"000,111"); break;
            case 0x99: strcpy(temp,"x00,x11"); break;
            case 0xa5: strcpy(temp,"0x0,1x1"); break;
            case 0xc3: strcpy(temp,"00x,11x"); break;
            default: snprintf(temp,sizeof(temp),"_%02x",d6_dq); break;
            }
        }
        else if( (d6_dq & 0x2800) == AVAGO_SERDES_RX_DATA_QUAL_PREV0 )
            strcpy(temp, "0xx");
        else if( (d6_dq & 0x2800) == AVAGO_SERDES_RX_DATA_QUAL_PREV1 )
            strcpy(temp, "1xx");
        else
            strcpy(temp,"xxx");
        /* Preserve even/odd: */
        dq.select &= ~3;
        if( d6_dq & 0x4000 ) dq.select |= 1;
        if( d6_dq & 0x8000 ) dq.select |= 2;
    }
    else if( dq.cmp_data_compare_en[0] == 0xffff &&
             dq.cmp_data_compare_en[1] == 0xffff &&
             dq.cmp_data_compare_en[2] == 0xffff &&
             dq.cmp_data_compare_en[3] == 0xffff )
    {
        strcpy(temp,"xxx");
    }
    else
    {
        BOOL five_syms = ptr != buf;
        if( five_syms ) *ptr++ = '.';
        ptr += m4_data_qual_to_str(ptr, buf+sizeof(buf)-ptr-2, dq.cmp_data_compare_en);
        if( five_syms ) *ptr++ = '.';
    }

    /* Map "xxx" to unqual, or remove it if any even/odd/msb/lsb to add */
    if( 0 == strcmp(temp,"xxx") )
    {
        if( !(dq.cmp_valid_post & 8) && !(dq.cmp_valid_pre & 8) && !(dq.select & 0xf) )
            strcpy(temp,"unqual");
        else
            *temp = '\0';
    }

    strncpy(ptr,temp,sizeof(buf)+buf-ptr); ptr += strlen(ptr);

    if( dq.cmp_valid_post & 8 )
        ptr += snprintf(ptr,sizeof(buf)+buf-ptr,"%d",dq.cmp_valid_post & 7);
    else if( dq.cmp_valid_pre & 8 )
        ptr += snprintf(ptr,sizeof(buf)+buf-ptr,"x");

    if(      (dq.select & 0x03) == 1 ) ptr += snprintf(ptr,sizeof(buf)+buf-ptr,",odd");
    else if( (dq.select & 0x03) == 2 ) ptr += snprintf(ptr,sizeof(buf)+buf-ptr,",even");
    if(      (dq.select & 0x0c) == 4 ) ptr += snprintf(ptr,sizeof(buf)+buf-ptr,",lsb");
    else if( (dq.select & 0x0c) == 8 ) ptr += snprintf(ptr,sizeof(buf)+buf-ptr,",msb");
    if( buf[0] == ',' ) memmove(buf,buf+1,ptr-buf);
    return buf;
}

/* Symbol is one of '0', '1', '2', '3', 'x', 'X', '*', or a range of values */
/* using the syntax '[values]', where 'values' is one or more of the */
/* individual symbols.  Note: 'x', 'X' and '*' are shortcuts for '[0123]'. */
/* Examples of 3 symbol patterns:  0x0, 1xx, [23]x[01] */
/* Return value sets bit 0 if 0 is selected, bit 1 if 1 is selected, etc. */
static char get_symbol(const char **pattern)
{
    const char *ptr = *pattern;
    char selection = 0;
    /* printf("Parsing: %s\n",ptr); */
    switch( *ptr++ )
    {
    case '0': selection = 1; break;
    case '1': selection = 2; break;
    case '2': selection = 4; break;
    case '3': selection = 8; break;
    case 'x':
    case 'X':
    case '*': selection = 15; break;
    case '[':
            {
                int sel;
                while( (sel = get_symbol(&ptr)) )
                    selection |= sel;
                break;
            }
    case ']': break;
    default:  return 0; /* ERROR return */
    }
    *pattern = ptr;
    /* printf("Remaining: %s, returning %x\n",ptr,selection); */
    return selection;
}
/* Load the 3 to 5 bit pattern symbols and return count. */
static int get_pattern(const char **ptr, char *symbol)
{
    int symbol_count = 1;
    if(      0==aapl_strncasecmp(*ptr,"even",4) ) { symbol[0] = 'E'; (*ptr) += 4; }
    else if( 0==aapl_strncasecmp(*ptr,"odd" ,3) ) { symbol[0] = 'O'; (*ptr) += 3; }
    else if( 0==aapl_strncasecmp(*ptr,"msb" ,3) ) { symbol[0] = 'M'; (*ptr) += 3; }
    else if( 0==aapl_strncasecmp(*ptr,"lsb" ,3) ) { symbol[0] = 'L'; (*ptr) += 3; }
    else if( 0==aapl_strncasecmp(*ptr,"e" ,1) ) { symbol[0] = 'E'; (*ptr) += 1; }
    else if( 0==aapl_strncasecmp(*ptr,"o" ,1) ) { symbol[0] = 'O'; (*ptr) += 1; }
    else if( 0==aapl_strncasecmp(*ptr,"m" ,1) ) { symbol[0] = 'M'; (*ptr) += 1; }
    else if( 0==aapl_strncasecmp(*ptr,"l" ,1) ) { symbol[0] = 'L'; (*ptr) += 1; }
    else for( symbol_count = 0; symbol_count < 5; symbol_count++ )
        if( 0 == (symbol[symbol_count] = get_symbol(ptr)) )
            break;
    if( **ptr != '\0' && **ptr != ',' && 1 != strspn(*ptr,"eEoO") && (*ptr)[1] != '\0' )
        return 0;                   /* Unexpected symbol */
    if( **ptr == ',' ) (*ptr)++;    /* Move to next symbol and return success */
    return symbol_count;
}
/** @brief   Parse string into both NRZ and PAM4 data qualifications. */
/** @details Input name can be a shorthand for several common patterns, or */
/**          a comma separated list of patterns of form XXX or XXXXX. */
/**          Each X can be replaced with a 0, 1, x, X or * character. */
/**          For devices supporting PAM4 encoding, values of 2 and 3 are */
/**          also supported, as well as a set of patterns using the '[xx]' */
/**          syntax. For devices supporting only 3 bit patterns, only the */
/**          middle 3 values of a 5 bit pattern will be used.  A pattern list */
/**          also can end with an 'E' or 'O' character to select only */
/**          even or odd bits. */
/** */
/**          PAM4 patterns also allow selection of a MSB or LSB compare, */
/**          which is specified by including a "msb" or "lsb" directive. */
/** */
/**          PAM4 and NRZ patterns allow selecting even or odd data compares, */
/**          which is specified using "even" or "odd" directives. Default is */
/**          to compare all data. */
/** */
/**          Examples:  101,010 (selects pulses); 0x1; 0xx (prev0 selection); */
/**                     1xx,odd (prev1 odd selection); */
/**                     x2x,msb; x1x,lsb,even; x3x,odd; */
/**                     00300,33033,even (pulse selections); */
/**                     [03]x[03] (equivalent to 0x0,0x3,3x0,3x3). */
/** */
/** @details BNF form: */
/** @details sym = '0' | '1' | '2' | '3' | 'x' | 'X' | '*' */
/** @details set = '[' sym+ ']'     # 1 or more syms */
/** @details tok = sym | set */
/** @details pat = (tok tok tok | tok tok tok tok tok | 'lsb' | 'msb' | 'even' | 'odd' )  # 3 or 5 toks or directive */
/** @details sep = [',' | '.'] */
/** @details pat_list = pat [sep pat]* */
/** @return  Updates *dq and returns TRUE on success. */
/** @return  Returns FALSE if syntax error. */

BOOL aapl_str_to_data_qual(
    const char *name,
    Avago_serdes_data_qual_t *dq)
{
    const char *name_ptr = name;
    char symbol[5];
    int symbol_count = 0;
    Aapl_conv_table_t *table = data_qual_table;
    int index = name_to_index(table,name,0);

    avago_serdes_data_qual_init(dq);
    /* Any of these letters and we assume pam4 pattern: */
    dq->pam = strlen(name) != strcspn(name,"23msbMSB");
    if( index >= 0 )
    {
        switch( table[index].value )
        {
        case AVAGO_SERDES_RX_DATA_QUAL_PREV0: name_ptr = "0xx"; break;
        case AVAGO_SERDES_RX_DATA_QUAL_PREV1: name_ptr = "1xx"; break;
        case AVAGO_SERDES_RX_DATA_QUAL_PREV0O: name_ptr = "0xx,odd"; break;
        case AVAGO_SERDES_RX_DATA_QUAL_PREV0E: name_ptr = "0xx,even"; break;
        case AVAGO_SERDES_RX_DATA_QUAL_PREV1O: name_ptr = "1xx,odd"; break;
        case AVAGO_SERDES_RX_DATA_QUAL_PREV1E: name_ptr = "1xx,even"; break;
        case AVAGO_SERDES_RX_DATA_QUAL_UNQUAL: name_ptr = "xxx"; break;
        case AVAGO_SERDES_RX_DATA_QUAL_DEFAULT:
            dq->d6_data_qual = (Avago_serdes_rx_data_qual_t)table[index].value;
            return TRUE;
        }
        /* Fall through to parse name_ptr for both NRZ and PAM4 qualification. */
    }
  /*printf("%s:%d: Parse string '%s'\n",__func__,__LINE__,name); */

    memset(dq->cmp_data_compare_en,0,sizeof(dq->cmp_data_compare_en));  /* Clear bits */
    while( (symbol_count = get_pattern(&name_ptr, symbol)) > 0 )
    {
      /*int i; printf("symbols ="); for( i = 0; i < symbol_count; i++ ) printf(" %d(%c)", symbol[i],symbol[i]); printf("\n"); */
        if( symbol_count == 1 )
        {
            /* Record directives: */
            switch( symbol[0] )
            {
            case 'O': AAPL_BITS_SET(dq->select, 2, 0, 1); break; /* odd */
            case 'E': AAPL_BITS_SET(dq->select, 2, 0, 2); break; /* even */
            case 'L': AAPL_BITS_SET(dq->select, 2, 2, 1); break; /* lsb */
            case 'M': AAPL_BITS_SET(dq->select, 2, 2, 2); break; /* msb */
            }
            continue;
        }
        if( symbol_count == 5 )
        {
            /* Extract the pre and post patterns: */
            /* Note, these are PAM4 pattern values. */
            /* For NRZ use, convert value 9 to 11 (0xb). */
            if(      symbol[0] == 1 ) dq->cmp_valid_pre = 0x8;
            else if( symbol[0] == 2 ) dq->cmp_valid_pre = 0x9;
            else if( symbol[0] == 4 ) dq->cmp_valid_pre = 0xa;
            else if( symbol[0] == 8 ) dq->cmp_valid_pre = 0xb;
            if(      symbol[4] == 1 ) dq->cmp_valid_post = 0x8;
            else if( symbol[4] == 2 ) dq->cmp_valid_post = 0x9;
            else if( symbol[4] == 4 ) dq->cmp_valid_post = 0xa;
            else if( symbol[4] == 8 ) dq->cmp_valid_post = 0xb;

            /* Shift and fall through for middle bit parsing: */
            symbol[0] = symbol[1];
            symbol[1] = symbol[2];
            symbol[2] = symbol[3];
            symbol_count = 3;
        }
        if( symbol_count == 3 )
        {
            int max_syms = 64;
            int i;
            for( i = 0; i < max_syms; i++ )    /* For each possible pattern */
            {
                BOOL match_pam = TRUE;
                int sym;
                /* See if the 3 symbols are selected by the symbol array. */
                for( sym = 0; sym < 3 && match_pam; sym++ )
                {
                    int sym_mask = 1 << ((i >> (2-sym)*2) & 3);
                  /*printf("PAM: [%d,%d]: %d & %d\n",i,sym,symbol[sym],sym_mask); */
                    if( !(symbol[sym] & sym_mask) )
                        match_pam = FALSE;
                }
                if( match_pam ) /* If match on all syms: */
                {
                    dq->cmp_data_compare_en[i/16] |= 1 << i%16;
                  /*printf("match_pam: cmp_data_compare_en[i=%d] = 0x%x\n",i, dq->cmp_data_compare_en[i/16]); */
                }
            }
            continue;
        }
        return FALSE;   /* Invalid number of symbols */
    }
    /* Handle trailing even/odd bit selection, for compatibility with older syntax */
    if( 1 == strspn(name_ptr,"EeOo") )
    {
        if( *name_ptr == 'O' || *name_ptr == 'o' ) AAPL_BITS_SET(dq->select, 2, 0, 1);
        if( *name_ptr == 'E' || *name_ptr == 'e' ) AAPL_BITS_SET(dq->select, 2, 0, 2);
        name_ptr++; /* skip even/odd token */
    }
    /* If nothing selected, select everything: */
    if( dq->cmp_data_compare_en[0] == 0 && dq->cmp_data_compare_en[1] == 0 && dq->cmp_data_compare_en[2] == 0 && dq->cmp_data_compare_en[3] == 0 )
        dq->cmp_data_compare_en[0] = dq->cmp_data_compare_en[1] = dq->cmp_data_compare_en[2] = dq->cmp_data_compare_en[3] = 0xffff;

    aapl_construct_d6_data_qual(dq);
#if 0   /* Debug logging */
    printf("parse '%s' -> mask = ", name);
    if( dq->cmp_valid_pre & 8 ) printf("%d.",dq->cmp_valid_pre & 7);
    else                        printf("*.");

    printf("%04x",dq->cmp_data_compare_en[3]);
    printf("%04x",dq->cmp_data_compare_en[2]);
    printf("%04x",dq->cmp_data_compare_en[1]);
    printf("%04x",dq->cmp_data_compare_en[0]);
    printf("(0x%x)", dq->d6_data_qual);
    if( dq->cmp_valid_post & 8 ) printf(".%d",dq->cmp_valid_post & 7);
    else                         printf(".*");
    if( AAPL_BITS_GET(dq->select, 2, 0) == 1 )    printf(",odd");
    if( AAPL_BITS_GET(dq->select, 2, 0) == 2 )    printf(",even");
    if( AAPL_BITS_GET(dq->select, 2, 2) == 1 )    printf(",lsb");
    if( AAPL_BITS_GET(dq->select, 2, 2) == 2 )    printf(",msb");
    printf("\n");
#endif
    return *name_ptr == '\0';
}

/** @brief  Converts an DFE status value into a string. */
/** @return Returns a string representing the DFE status. */
const char *aapl_dfe_status_to_str(
    uint status)  /**< [in] DFE status value. */
{
    static char buf[100];
    char *ptr = buf;
    char *end = buf + AAPL_ARRAY_LENGTH(buf);
    if( status & 0x200 ) ptr += snprintf(ptr, end-ptr, "Rx_not_ready,");
    if( status & 0x100 ) ptr += snprintf(ptr, end-ptr, "LOS,");
    if( status & 0x080 ) ptr += snprintf(ptr, end-ptr, "VOS_done,");
    if( status & 0x040 ) ptr += snprintf(ptr, end-ptr, "run_adaptive,");
    if( status & 0x020 ) ptr += snprintf(ptr, end-ptr, "run_pcal,");
    if( status & 0x010 ) ptr += snprintf(ptr, end-ptr, "run_ical,");
    if( status & 0x004 ) ptr += snprintf(ptr, end-ptr, "vos_in_prog,");
    if( status & 0x002 ) ptr += snprintf(ptr, end-ptr, "pCal_in_prog,");
    if( status & 0x001 ) ptr += snprintf(ptr, end-ptr, "iCal_in_prog,");
    if( ptr > buf ) *--ptr = '\0';
    return buf;
}

static Aapl_conv_table_t pcs_fifo_clk_table[] =
{
    { "F66",  AVAGO_SERDES_PCS_FIFO_F66     },
    { "F50",  AVAGO_SERDES_PCS_FIFO_F50     },
    { "F60",  AVAGO_SERDES_PCS_FIFO_F60     },
    { "F70",  AVAGO_SERDES_PCS_FIFO_F70     },
    { "F80",  AVAGO_SERDES_PCS_FIFO_F80     },
    { "F90",  AVAGO_SERDES_PCS_FIFO_F90     },
    { "F100", AVAGO_SERDES_PCS_FIFO_F100    },
    { "F110", AVAGO_SERDES_PCS_FIFO_F110    },
    { "F120", AVAGO_SERDES_PCS_FIFO_F120    },
    { "DIVX", AVAGO_SERDES_PCS_FIFO_RX_DIVX },
    { "F68",  AVAGO_SERDES_PCS_FIFO_F68     },
    { "F33",  AVAGO_SERDES_PCS_FIFO_F33     },
    { "GND",  AVAGO_SERDES_PCS_FIFO_GND     },
    { 0,      0 }
};

/** @brief  Converts an Avago_serdes_pcs_fifo_clk_t value into a string. */
/** @return Returns a string representing the pcs fifo clock. */
/** @see    aapl_str_to_pcs_fifo_clk(). */
const char *aapl_pcs_fifo_clk_to_str(
    Avago_serdes_pcs_fifo_clk_t value)  /**< [in] pcs fifo clock value. */
{
    Aapl_conv_table_t *table = pcs_fifo_clk_table;
    int index = value_to_index(table,value);
    return index >= 0 ? table[index].name : "unknown";
}

/** @brief  Converts a string to an Avago_serdes_pcs_fifo_clk_t value. */
/** @return Returns TRUE and updates *out if a recognized clock string. */
/** @return Returns FALSE if an unrecognized clock. */
/** @see    aapl_pcs_fifo_clk_to_str(). */
BOOL aapl_str_to_pcs_fifo_clk(
    const char *name,                  /**< [in] String to be parsed. */
    Avago_serdes_pcs_fifo_clk_t *out)  /**< [out] Recognised pcs fifo clock. */
{
    Aapl_conv_table_t *table = pcs_fifo_clk_table;
    int index = name_to_index(table,name,0);
    if( index >= 0 )
        *out = (Avago_serdes_pcs_fifo_clk_t)table[index].value;
    return index >= 0;
}

/** @brief  Converts a string to a boolean value. */
/** @return Returns TRUE and updates *out if a recognized boolean string. */
/** @return Returns FALSE if an unrecognized value. */
BOOL aapl_str_to_bool(
    const char *name,  /**< [in] String to be parsed. */
    BOOL *out)         /**< [out] Recognised boolean value. */
{
    if( 0 == aapl_strcasecmp(name,"true") || 0 == aapl_strcasecmp(name,"t") || 0 == strcmp(name,"1") )
        return (*out = TRUE), TRUE;
    if( 0 == aapl_strcasecmp(name,"false") || 0 == aapl_strcasecmp(name,"f") || 0 == strcmp(name,"0") )
        return (*out = FALSE), TRUE;
    return (*out = FALSE), FALSE;
}

#if AAPL_ENABLE_FEC
static Aapl_conv_table_t fec_mode_table[] =
{
    { "FEC_528",    AVAGO_FEC_RS528  },
    { "FEC_544",    AVAGO_FEC_RS544  },
    { 0        ,    0}
};

/** @brief  Converts a string into an Avago_fec_mode_t value. */
/** @return Returns TRUE and updates *out if a recognized mode string. */
/** @return Returns FALSE if an unrecognized mode. */
/** @see    aapl_fec_mode_to_str(). */
BOOL aapl_str_to_fec_mode(
    const char *name,      /**< [in]  String to be parsed. */
    Avago_fec_mode_t *out) /**< [out] recognized FEC mode. */
{
    Aapl_conv_table_t *table = fec_mode_table;
    int index = name_to_index(table,name,9);
    if( index < 0 )
        index = name_to_index(table,name,8);
    if( index >= 0 )
        *out = (Avago_fec_mode_t) table[index].value;
    return index >= 0;
}

/** @brief  Converts an Avago_fec_mode_t value into a string. */
/** @return Returns a string representing the FEC mode. */
/** @see    aapl_str_to_fec_mode(). */
const char *aapl_fec_mode_to_str(
    Avago_fec_mode_t value)    /**< [in] FEC mode. */
{
    Aapl_conv_table_t *table = fec_mode_table;
    int index = value_to_index(table, value);
    return index >= 0 ? table[index].name : "AVAGO_FEC_RS528";
}

#endif /* AAPL_ENABLE_FEC */

#if AAPL_ENABLE_AVSP
static Aapl_conv_table_t avsp_mode_table[] =
{
    { "REPEATER_SIMPLEX",       AVSP_REPEATER_SIMPLEX      },
    { "REPEATER_DUPLEX",        AVSP_REPEATER_DUPLEX       },
    { "GEARBOX_10:4_RS_FEC",    AVSP_GEARBOX_10_4_RS_FEC   },
    { "GEARBOX_10:4_MLG",       AVSP_GEARBOX_10_4_MLG      },
    { "GEARBOX_10:4",           AVSP_GEARBOX_10_4          },
    { "GEARBOX_4:1",            AVSP_GEARBOX_4_1           },
    { "GEARBOX_2:1",            AVSP_GEARBOX_2_1           },
    { "GEARBOX_2:1_MOD_HOST",   AVSP_GEARBOX_2_1_MOD_HOST  },
    { "RS_FEC_RPT",             AVSP_RS_FEC_4x4            },
    { "RS_FEC_528",             AVSP_RS_FEC_528            },
    { "RS_FEC_544",             AVSP_RS_FEC_544            },
    { "FEC",                    AVSP_RS_FEC                },
    { "ADHOC",                  AVSP_ADHOC                 },
    /* Shortcut aliases: */
    { "RPT",                    AVSP_REPEATER_DUPLEX       },
    { "PMA",                    AVSP_GEARBOX_10_4          },
    { "RS_FEC",                 AVSP_GEARBOX_10_4_RS_FEC   },
    { "MLG",                    AVSP_GEARBOX_10_4_MLG      },
    { "GEARBOX_10_4",           AVSP_GEARBOX_10_4          },
    { "GEARBOX_4_1",            AVSP_GEARBOX_4_1           },
    { "GEARBOX_2_1",            AVSP_GEARBOX_2_1           },
    { "GEARBOX_2_1_MOD_HOST",   AVSP_GEARBOX_2_1_MOD_HOST  },
    { 0,                        0 }
};

/** @brief  Converts an Avsp_mode_t value into a string. */
/** @return Returns a string representing the AVSP mode. */
/** @see    aapl_str_to_avsp_mode(). */
const char *aapl_avsp_mode_to_str(
    Avsp_mode_t value)   /**< [in] AVSP mode value. */
{
    Aapl_conv_table_t *table = avsp_mode_table;
    int index = value_to_index(table,value);
    return index >= 0 ? table[index].name : "AVSP_ADHOC";
}

/** @brief  Converts a string to an Avago_mode_t value. */
/** @return Returns TRUE and updates *out if a recognized AVSP mode. */
/** @return Returns FALSE if an unrecognized AVSP mode. */
/** @see    aapl_avsp_mode_to_str(). */
BOOL aapl_str_to_avsp_mode(
    const char *name,  /**< [in] String to be parsed. */
    Avsp_mode_t *out)  /**< [out] Recognised AVSP mode. */
{
    Aapl_conv_table_t *table = avsp_mode_table;
    int index = name_to_index(table,name,9);
    if( index < 0 )
        index = name_to_index(table,name,8);
    if( index >= 0 )
        *out = (Avsp_mode_t)table[index].value;
    return index >= 0;
}

static Aapl_conv_table_t supervisor_mode_table[] =
{
    { "TUNE_IF_SIGNAL",        AVSP_SUPERVISOR_MODE_TUNE_IF_SIGNAL        },
    { "TUNE_IF_LOCKED_SIGNAL", AVSP_SUPERVISOR_MODE_TUNE_IF_LOCKED_SIGNAL },
    { "NO_TUNE",               AVSP_SUPERVISOR_MODE_NO_TUNE               },
    { 0,                       0 }
};

/** @brief  Converts an Avsp_supervisor_mode_t value into a string. */
/** @return Returns a string representing the AVSP supervisor mode. */
/** @see    aapl_str_to_supervisor_mode(). */
const char *aapl_supervisor_mode_to_str(
    Avsp_supervisor_mode_t value)   /**< [in] AVSP supervisor mode value. */
{
    Aapl_conv_table_t *table = supervisor_mode_table;
    int index = value_to_index(table,value);
    return index >= 0 ? table[index].name : "UNKNOWN_SUPERVISOR_MODE";
}

/** @brief  Converts a string to an Avsp_supervisor_mode_t value. */
/** @return Returns TRUE and updates *out if a recognized AVSP supervisor mode. */
/** @return Returns FALSE if an unrecognized AVSP supervisor mode. */
/** @see    aapl_supervisor_mode_to_str(). */
BOOL aapl_str_to_supervisor_mode(
    const char *name,             /**< [in] String to be parsed. */
    Avsp_supervisor_mode_t *out)  /**< [out] Recognised AVSP supervisor mode. */
{
    Aapl_conv_table_t *table = supervisor_mode_table;
    int index = name_to_index(table,name,0);
    if( index >= 0 )
        *out = (Avsp_supervisor_mode_t)table[index].value;
    return index >= 0;
}
#endif /* AAPL_ENABLE_AVSP */


#if AAPL_ENABLE_MAIN

/** @brief  Converts a string to an address value. */
/** @return Returns address converted from string and in case of invalid address, gives error message. */
/** @see    aapl_str_to_addr(). */
uint aapl_addr_from_str(
    const char *str,      /**< [in] The string to parse. */
    const char *optname)  /**< [in] The option name being parsed. */
{
    uint addr;
    if( aapl_str_to_addr(str,0,&addr) )
        return addr;

    aapl_main_error("The -%s option requires an address [[chip]:[ring]:]sbus[.lane]; got: \"%s\".", optname, str);
    return 0;
}

/** @brief  Converts a string to an communication method value. */
/** @return Returns communication method recognized from string and in case of unrecognized method, gives error message. */
/** @see    aapl_str_to_comm_method(). */
Aapl_comm_method_t aapl_comm_method_from_str(
    const char *str,      /**< [in] The string to parse. */
    const char *optname)  /**< [in] The option name being parsed. */
{
    Aapl_comm_method_t comm_method;
    if( aapl_str_to_comm_method(str,&comm_method) )
        return comm_method;
    aapl_main_error("-%s option must be {AACS}_{I2C|MDIO|SBUS|JTAG|BB_JTAG}|SYSTEM_{I2C|MDIO}|GPIO_MDIO|OFFLINE\n", optname);
    return AVAGO_OFFLINE;
}

#if AAPL_ENABLE_DIAG
/** @brief  Converts a string into an Avago_serdes_bsb_mode_t value. */
/** @return Returns bsb mode and in case of unrecognized mode, gives error message. */
/** @see    aapl_str_to_bsb_mode(). */
Avago_serdes_bsb_mode_t aapl_bsb_mode_from_str(
    const char *str,       /**< [in] The string to parse. */
    const char *optname)   /**< [in] The option name being parsed. */
{
    Avago_serdes_bsb_mode_t comm_method;
    if( aapl_str_to_bsb_mode(str,&comm_method) )
        return comm_method;
    aapl_main_error("-%s option must be BSB_{DISABLE|CLK|PASSTHRU|DMA|SBUS|CORE}\n", optname);
    return AVAGO_SERDES_BSB_PASSTHRU;
}

/** @brief  Converts a string into an Avago_serdes_bsb_clk_sel_t value. */
/** @return Returns selected bsb clock and in case of unrecognized clock, gives error message. */
/** @see    aapl_str_to_bsb_clk(). */
Avago_serdes_bsb_clk_sel_t aapl_bsb_clk_from_str(
    const char *str,      /**< [in] The string to parse. */
    const char *optname)  /**< [in] The option name being parsed. */
{
    Avago_serdes_bsb_clk_sel_t comm_method;
    if( aapl_str_to_bsb_clk(str,&comm_method) )
        return comm_method;
    aapl_main_error("-%s option must be {BSB}_{GND|PCS6466_FIFO_CLK|LSSEL|RESET_COMPLETE|AVDD}|{RX_{F10|F20|F40_FIFO_CLK|CLK|FIFO_CLK}}|{TX_{F10|F20|F40|FIFO_CLK|TEST_CLK|DIVX_CLK|F10_CLK_VAR|F20_CLK_VAR|CLK_TEST}}|{SBUS_{CLK|CLK_TEST}}\n", optname);
    return AVAGO_SERDES_BSB_GND;
}
#endif /* AAPL_ENABLE_DIAG */


/** @details       Parses and returns a decimal number from an option string */
/**                (optarg) that can include scientific notation */
/**                (positive exponents only). */
/** @return bigint The binary equivalent, but errors out in case of error. */
/* */
/* Note:  Can't find a way to do this in the Linux library, even with scanf(). */

bigint aapl_nume_from_str(
    const char *str,        /**< The optarg string to parse. */
    const char *optname)    /**< The option letter/name for error reporting. */
{
    char * str2;
    bigint val = aapl_strtol(str, &str2, 10);
    int scale = 0;

    if( *str2 == '.' )
    {
        for( str2++; *str2 >= '0' && *str2 <= '9'; str2++ )
        {
            val = 10 * val + (*str2 - '0');
            scale++;
        }
    }

    if ((str >= str2) || !(*str2=='\0' || *str2=='e' || *str2=='E')) aapl_main_error("-%s option requires a decimal or exponential (like \"1.1e6\") number; got: \"%s\".", optname, str);

    if (*str2=='e' || *str2=='E')
    {
        int exp_val;
        str = str2 + 1;
        exp_val = aapl_strtol(str, &str2, 10);

        if ((str >= str2) || *str2 || (exp_val <= 0)) aapl_main_error("-%s option with exponential number (like \"1.1e6\") must end with positive exponent; got: \"%s\".", optname, str);

        exp_val -= scale;
        while( exp_val < 0 )
        {
            val /= 10;
            exp_val++;
        }

        while (exp_val > 0 )
        {
            val *= 10;
            exp_val --;
        }
    }
    return val;
}

/** @cond INTERNAL */

/** @brief   Convert a bit field ie [7:4] to the number of bits and shift amount (4 and 4 for this example) */
/** @return  *bit_field_bits (number of bits) and *bit_field_shift (how many bits to left shift) */
void aapl_bit_field_from_str(
    const char *str,        /**< String to parse. */
    const char *optname,    /**< Option letter for error reporting. */
    uint *bit_field_bits,    /**< Number of bits in the mask provided in *str */
    uint *bit_field_shift,   /**< Number of bits to left shift to match the mask in *str */
    uint base)               /**< Base for conversion.  See strtoul(). */
{
    char *str2;
    uint val;

    if (str[0] && str[0] != '[') return;
    str++;
    val = aapl_strtoul(str, &str2, base);
    /* printf("### %s ### %s ###\n", str, str2); */
    if ( (str < str2)  && (str2[0] == ']') ) /* single bit specified (ie [4]) */
    {
        *bit_field_shift = val;
        *bit_field_bits = 1;
    }
    else if ((str < str2) && (str2[0] == ':')) /* make sure there is another number and a : present */
    {
        str=str2; /* move to last char found by strtoul */
        str++; /* move past the : */
        *bit_field_shift = aapl_strtoul(str, &str2, base);
        *bit_field_bits = val - *bit_field_shift + 1;
    }
    /*printf("## bitfield: %04x %04x ## %s ## %s\n", *bit_field_bits, *bit_field_shift, str, str2); */

    if( (str >= str2) || (str2[0] != ']'))
    {
        if( *optname == '<' )
            aapl_main_error("%s parameter has unrecognized characters: \"%s\".", optname, str);
        else if( base > 1 )
            aapl_main_error("-%s option requires a number of base %d; got: \"%s\".", optname, base, str);
        else
            aapl_main_error("-%s option requires a number; got: \"%s\".", optname, str);
    }
    return;
}

/** @endcond */

/** @brief   Gets a number from an option string (optarg). */
/** @details Prints message and calls aapl_main_error() on error. */
/** @return  The unsigned value. */
uint aapl_num_from_str(
    const char *str,        /**< String to parse. */
    const char *optname,    /**< Option letter for error reporting. */
    int base)               /**< Base for conversion.  See strtoul(). */
{
    char *str2;
    uint val;

    if( str[0] == '0' && str[1] == 'b' && (base == 0 || base == 2) )
        /* If given prefix of "0b" read as a binary number. */
        val = aapl_strtoul(str+2, &str2, 2);
    else
        val = aapl_strtoul(str, &str2, base);

    if( (str >= str2) || *str2 )
    {
        if( *optname == '<' )
            aapl_main_error("%s parameter has unrecognized characters: \"%s\".", optname, str);
        else if( base > 1 )
            aapl_main_error("-%s option requires a number of base %d; got: \"%s\".", optname, base, str);
        else
            aapl_main_error("-%s option requires a number; got: \"%s\".", optname, str);
    }
    return val;
}

/** @details Get and return a boolean flag value from an option string. */
/**          Input string may be 0, 1, true, false, t, or f. */
/** @return TRUE or FALSE.  Calls aapl_main_error() on parsing error. */
BOOL aapl_bool_from_str(
    const char *str,        /**< [in] The string to parse. */
    const char *optname)    /**< [in] The option name being parsed. */
{
    BOOL val;
    if( !aapl_str_to_bool(str, &val) )
        aapl_main_error("-%s option requires a 0|1|true|false|t|f; got: \"%s\".", optname, str);
    return val;
}

/** @brief  Converts a string into an Avago_serdes_data_qual_t value. */
/** @return Returns data qual type and in case of unrecognized type, gives error message. */
/** @see    aapl_data_qual_to_str(). */
Avago_serdes_data_qual_t aapl_data_qual_from_str(
    const char *str,      /**< [in] The string to parse. */
    const char *optname)  /**< [in] The option name being parsed. */
{
    Avago_serdes_data_qual_t dq;
    if( !aapl_str_to_data_qual(str, &dq) )
        aapl_main_error("-%s option requires a qualification name, or a valid 3 or 5 symbol pattern; got: \"%s\".", optname, str);
    return dq;
}

/** @brief  Converts a string into an Avago_serdes_rx_clock_t value. */
/** @return Returns rx clock type and in case of unrecognized type, gives error message. */
Avago_serdes_rx_clock_t aapl_rx_clock_from_str(
    const char *str,     /**< [in] The string to parse. */
    const char *optname) /**< [in] The option name being parsed. */
{
    Avago_serdes_rx_clock_t clock;
    if( !aapl_str_to_rx_clock(str, &clock) )
        aapl_main_error("-%s option requires iclk, qclk, rclk or PD; got: \"%s\".", optname, str);
    return clock;
}

/** @brief  Converts a string into an Avago_serdes_rx_clock_cdc_t value. */
/** @return Returns CDC clock type and in case of unrecognized type, gives error message. */
Avago_serdes_rx_clock_cdc_t aapl_rx_clock_cdc_from_str(
    const char *str,      /**< [in] The string to parse. */
    const char *optname)  /**< [in] The option name being parsed. */
{
    Avago_serdes_rx_clock_cdc_t cdc;
    if( !aapl_str_to_rx_clock_cdc(str, &cdc) )
        aapl_main_error("-%s option requires DATA, CDC, ~DATA or ~CDC; got: \"%s\".", optname, str);
    return cdc;
}

/** @brief  Converts a string into an Avago_serdes_rx_cmp_mode_t value. */
/** @return Returns comparator mode and in case of unrecognized mode, gives error message. */
Avago_serdes_rx_cmp_mode_t aapl_cmp_mode_from_str(
    const char *str,     /**< [in] The string to parse. */
    const char *optname) /**< [in] The option name being parsed. */
{
    Avago_serdes_rx_cmp_mode_t cmp_mode = AVAGO_SERDES_RX_CMP_MODE_XOR;
    if( !aapl_str_to_cmp_mode(str, &cmp_mode) )
        aapl_main_error("-%s option requires an AVAGO_SERDES_RX_CMP_MODE_* type; got: \"%s\".", optname, str);
    return cmp_mode;
}

/** @brief  Converts a string into an Avago_serdes_mem_type_t value. */
/** @return Returns memory type and in case of unrecognized type, gives error message. */
Avago_serdes_mem_type_t aapl_mem_type_from_str(
    const char *str,     /**< [in] The string to parse. */
    const char *optname) /**< [in] The option name being parsed. */
{
    Avago_serdes_mem_type_t type = AVAGO_ESB;
    if( !aapl_str_to_mem_type(str,&type) )
        aapl_main_error("%s option requires LSB, ESB, DMEM, IMEM, LSB_DIRECT or ESB_DIRECT, got: \"%s\".", optname, str);
    return type;
}

#if AAPL_ENABLE_FEC
/** @brief  Converts a string into an Avago_fec_mode_t value. */
/** @return Returns FEC mode and in case of unrecognized mode, gives error message. */
/** @see    aapl_fec_mode_to_str(). */
Avago_fec_mode_t aapl_fec_mode_from_str(
    const char *str,     /**< [in] The string to parse. */
    const char *optname) /**< [in] The option name being parsed. */
{
    Avago_fec_mode_t type = AVAGO_FEC_RS528;
    if( !aapl_str_to_fec_mode(str, &type) )
        aapl_main_error("%s option requires FEC_528, FEC_544 got: \"%s\".", optname, str);
    return type;
}
#endif /* AAPL_ENABLE_FEC */

#if AAPL_ENABLE_AVSP
/** @brief  Converts a string into an Avsp_mode_t value. */
/** @return Returns AVSP mode and in case of unrecognized mode, gives error message. */
/** @see    aapl_str_to_avsp_mode(). */
Avsp_mode_t aapl_avsp_mode_from_str(
    const char *str,       /**< [in] The string to parse. */
    const char *optname)   /**< [in] The option name being parsed. */
{
    Avsp_mode_t type = AVSP_REPEATER_DUPLEX;
    if( !aapl_str_to_avsp_mode(str,&type) )
        aapl_main_error("%s option requires REPEATER_DUPLEX, REPEATER_SIMPLEX, GEARBOX_10:4, GEARBOX_10:4_MLG or GEARBOX_10:4_RS_FEC, GEARBOX_2:1, GEARBOX_2:1_MOD_HOST, GEARBOX_4:1, RS_FEC, RS_FEC_RPT, RS_FEC_528, RS_FEC_544 got: \"%s\".", optname, str);
    return type;
}
#endif

/** @brief  Converts a string into an Avsp_mode_t value. */
/** @return Returns AVSP mode and in case of unrecognized mode, gives error message. */
/** @see    aapl_str_to_avsp_mode(). */
Avago_serdes_dfe_tune_mode_t aapl_dfe_tune_mode_from_str(
    const char *str,     /**< [in] The string to parse. */
    const char *optname) /**< [in] The option name being parsed. */
{
    Avago_serdes_dfe_tune_mode_t mode = AVAGO_DFE_ICAL;
    if( !aapl_str_to_dfe_tune_mode(str,&mode) )
        aapl_main_error("%s option requires ICAL, PCAL, START_ADAPTIVE, STOP_ADAPTIVE, ENABLE_RR or DISABLE_RR, got: \"%s\".", optname, str);
    return mode;
}

/** @} */

#endif /* AAPL_ENABLE_MAIN */

