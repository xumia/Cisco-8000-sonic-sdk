/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* MAIN program for the "an" auto-negotiate command. */

/** Doxygen File Header */
/** @file */
/** @brief Launch wrapper for AN function. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_MAIN && AAPL_ENABLE_SERDES_AUTO_NEG

static int show_serdes_an_help()
{
    aapl_common_main_help(TRUE);
    printf(
"-an-start         Use this command to configure and start AN.\n"
"Options for use with -an-start:\n"
);
    printf(
"  -an-clk <0|1>     Defines what speed AN will occur at:\n"
"                    0=1.25GB/s, 1=3.125 (Default: 1.25GB/s)\n"
"  -disable-link-inhibit-timer <0|1>   1=disable, 0=enable (def=0)\n"
"  -ignore-nonce-match <0|1>           0=perform nonce match, 1=ignore match (def=0)\n"
"  -nonce-pattern-sel  <0|1|3>         0=PRBS7, 1=PRBS9, 3=user-defined pattern (def=0)\n"
"  -nonce-user-pattern <pattern>       5-bit user-defined nonce pattern(def=0)\n\n"
);
    printf(
"  -np-continuous-load <0|1>     1 = auto reload next pages with null (def=0)\n"
"  -pause       <0|1>            Disable/Enable symmetric PAUSE ability (def=0).\n"
"  -asm-dir     <0|1>            Disable/Enable asymmetric PAUSE ability (def=0).\n"
"  -np-enable   <0|1>            Enable next page data transmission/reception. (def=0)\n"
);

    printf(
    /* Note: See 802.3 Table 73-4 for these definitions: */
"  -user-cap <cap>\n"
"  -cap <cap>  Sets technology ability list as follows:\n"
"              0x0001=1000Bkx,  0x0002=10GBkx4,     0x0004=10GBkr,       0x0008=40GBkr4\n"
"              0x0010=40GBcr4,  0x0020=100GBcr10,   0x0040=100GBkp4,     0x0080=100GBkr4\n"
"              0x0100=100GBcr4, 0x0200=25GBkr/cr-s, 0x0400=25GBkr/cr,    0x0800=2.5GB-kx\n"
"              0x1000=5GB-kr,   0x2000=50GB-kr/cr,  0x4000=100GBkr2/cr2, 0x8000=200GBkr4/cr4\n"
);

    printf(
"  -auto-kr     <0|1>            Enable auto rate change and KR launch for selected HCD rate (def=0)\n"
"  -pmd-config  <val>            Interrupt 0x4 data if -auto-kr = 1 (def=0x02)\n"
);
    printf(
"  -fec-ability <0|1>            Enable FEC (def=0)\n"
"  -fec-request <req>            Sets FEC capability (def=0=none)\n"
"                                0x01=F1 10gb/s FEC request.\n"
"                                0x02=F2 25gb/s RS-FEC request (with user-cap kr/cr selections).\n"
"                                0x04=F3 25gb/s FEC request (with user-cap kr/cr selections).\n"
"\n"
);

    printf(
"-next-page-transmit <data>    Load 48bit of next page data\n"
"                              -np-enable must be used with this command\n"
"                              data contains bit[48:0] where 15bits are separated by '_' or ','\n"
"                              Ex: -next-page-tx 1234_5678_9abc \n"
);
    printf(
"-next-page-receive <data>     Compares the 48-bit data received from LP with this data buffer\n"
"                              data contains bit[48:0] where 15bits are separated by '_' or ','\n"
"                              Ex: -next-page-rx 1234_5678_9abc \n"
);
    printf(
"-read-status      Display the HCD status\n"
"-wait-for-an      Wait for AN to complete\n"
"-assert-link      Use this command after AN completes to configure SerDes per the AN HCD.\n"
"\n"
"Link configuration options for use with -assert-link (if -auto-kr = 0):\n"
"  -width-mode    <10|16|20|32|40|64|80>  Set the width modes. [def=40 for D6, 80 for M4]\n"
"  -tx-width-mode <10|16|20|32|40|64|80>  Set the TX width mode.\n"
"  -rx-width-mode <10|16|20|32|40|64|80>  Set the RX width mode.\n"
);
    printf(
"\n"
"PMD Options for use with -assert-link:\n"
"  -train-mode        <data>     PMD link training mode. <data>: PMD_RESTART, PMD_TRAIN OR PMD_BYPASS. Default: PMD_TRAIN.\n"
"  -initial-pre       <data>     Initial pre-cursor value. Maximum 15 (def=0).\n"
"  -initial-post      <data>     Initial pre-cursor value. Maximum 15 (def=0).\n"
"  -disable-txeq-adj  <0|1>      Enable/disable requesting TxEq adjustments (def=0).\n"
"  -invert-requests   <0|1>      Disable/enable invert requests made to remote Tx (def=0).\n"
);

    printf(
"  -asym-mode         <0|1>      Disable/enable asymmetric mode (def=0).\n"
"  -asym-tx           <data>     SBus Rx Address of SerDes that is the Tx portion of the duplex link, ignored if -asym-mode = FALSE.\n"
"  -reset-params      <0|1>      Disable/enable reset of any previously configured parameters (def=0).\n"
"  -disable-timeout   <0|1>      Enable/Disable the timeout timer. (def=0)\n"
"  -prbs-seed         <data>     PRBS seed value (def=0).\n"
);
    printf(
"  -TT-FECreq         <0|1>      Disable/enable FEC request in TT training frames (def=0).\n"
"  -TT-FECcap         <0|1>      Disable/enable FEC capability in TT training frames (def=0).\n"
"  -TT-TF             <0|1>      Disable/enable Fixed TxEq in TT training frames (def=0).\n"
"  -wait-for-pmd                 Wait for PMD to complete\n"
);
    return 1;
}

/* Main program for configuring serdes AN using Interrupt 0x07 */
/* pre-existing process/thread.  Exits with 0 for success or 1 for error. */

int aapl_serdes_an_main(int argc, char ** argv, Aapl_t *aapl)
{
/* Prepare AAPL API: */
    Avago_serdes_an_config_t *config = 0;
    Avago_serdes_pmd_config_t *pmd_config, new_pmd_config;

/* Parse options: */
    Avago_addr_t addr_struct;
    int    rc, index = 0;
    int ret;
    uint   addr;
    int    tx_width = 0, rx_width = 0;
    int    an_hcd = 31;
    const char *np_data_tx   = 0;
    const char *np_data_rx   = 0;
    BOOL   assert_link = 0;
    BOOL   an_start    = 0;
    BOOL   read_status = FALSE;
    BOOL   wait_for_an = FALSE;
    BOOL   wait_for_pmd = FALSE;
    BOOL next_page_tx  = 0;
    BOOL next_page_rx  = 0;
    uint configure_pmd = 0;
    int err = 0;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"an-clk",                      1, NULL, 'c'},  /* AN clock source */
        {"disable-link-inhibit-timer",  1, NULL, 'l'},  /* link inhibit timer */
        {"ignore-nonce-match",          1, NULL, 'i'},  /* perform nonce match or not */
        {"nonce-pattern-sel",           1, NULL, 'n'},  /* nonce pattern selection */
        {"nonce-user-pattern",          1, NULL, 'u'},  /* user defined none pattern */
        {"an-cap",                      1, NULL, 'x'},  /* AN technology capabilities */
        {"user-cap",                    1, NULL, 'x'},
        {"auto-kr",                     1, NULL, 'k'},  /* Auto configuring serdes and KR launch */
        {"pmd-config",                  1, NULL, 'p'},  /* Config data for auto KR */
        {"np-enable",                   1, NULL, 'N'},  /* Next page enable */
        {"fec-ability",                 1, NULL, 'f'},  /* Fec ability */
        {"fec-request",                 1, NULL, 'r'},  /* FEC request */
        {"pause",                       1, NULL, 's'},  /* Symmetric PAUSE ability */
        {"asm-dir",                     1, NULL, 'A'},  /* Asymmetric PAUSE ability */
        {"np-continuous-load",          1, NULL, 'o'},  /* continuously load next pages with NULL */
        {"assert-link",                 0, NULL, 'L'},  /* configure and assert advertised capability */
        {"an-start",                    0, NULL, 'a'},  /* start AN */
        {"train-mode",                  1, NULL,  1 },  /* PMD link training mode */
        {"asym-tx",                     1, NULL,  2 },  /* SBus Rx Address of SerDes that is the Tx portion of the duplex link */
        {"initial-pre",                 1, NULL,  3 },  /* Initial pre-cursor value */
        {"initial-post",                1, NULL,  4 },  /* Initial post-cursor value */
        {"asym-mode",                   1, NULL,  5 },  /* Channels to another SerDes that is the partner to form the duplex link */
        {"disable-txeq-adj",            1, NULL,  6 },  /* Disables requesting TxEq adjustments */
        {"invert-requests",             1, NULL,  7 },  /* Invert requests made to remote Tx */
        {"reset-params",                1, NULL,  8 },  /* Reset any previously configured parameters */
        {"disable-timeout",             1, NULL,  9 },  /* Disables the timeout timer */
        {"next-page-transmit",          1, NULL, 10 },  /* Load next pages to transmit */
        {"next-page-receive",           1, NULL, 11 },  /* Receive next pages */
        {"prbs-seed",                   1, NULL, 12 },  /* When non-zero overrides the default PRBS seed value */
        {"TT-FECreq",                   1, NULL, 13 },  /* Transmit FEC request in TT training frames */
        {"TT-FECcap",                   1, NULL, 14 },  /* Transmit FEC capability in TT training frames */
        {"TT-TF",                       1, NULL, 15 },  /* Transmit Fixed TxEq in TT training frames */
        {"tx-width-mode",               1, NULL, 16 },  /* Set Tx width mode */
        {"rx-width-mode",               1, NULL, 17 },  /* Set Rx width mode */
        {"width-mode",                  1, NULL, 18 },  /* Set Tx and Rx width mode */
        {"read-status",                 0, NULL, 25 },  /* */
        {"wait-for-an",                 0, NULL, 26 },  /* */
        {"wait-for-pmd",                0, NULL, 27 },  /* */
    };

    avago_addr_to_struct(aapl_default_device_addr, &addr_struct);
    if( aapl_common_main_options(aapl, argc, argv, &addr_struct) < 0 )
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_serdes_an_help();
    }
    addr = avago_struct_to_addr(&addr_struct);

    if( aapl->return_code < 0 ) return 1;  /* EXIT, assume anomalies already reported. */

    config = avago_serdes_an_config_construct(aapl);
    pmd_config = avago_serdes_pmd_config_construct(aapl);
    memset(&new_pmd_config, 0, sizeof(new_pmd_config));

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        switch (rc)
        {
        /* AN Fields: */
        case 'a': an_start                             = 1; break;
        case 's': config->pause                        = aapl_bool_from_str(optarg, name);    break;
        case 'A': config->asm_dir                      = aapl_bool_from_str(optarg, name);    break;
        case 'c': config->an_clk                       = aapl_num_from_str( optarg, name, 0); break;
        case 'l': config->disable_link_inhibit_timer   = aapl_bool_from_str(optarg, name);    break;
        case 'i': config->ignore_nonce_match           = aapl_bool_from_str(optarg, name);    break;
        case 'n': config->nonce_pattern_sel            = aapl_num_from_str( optarg, name, 0); break;
        case 'u': config->nonce_user_pattern           = aapl_num_from_str( optarg, name, 0); break;
        case 'x': config->user_cap                     = aapl_num_from_str( optarg, name, 0); break;
        case 'k': config->auto_kr                      = aapl_bool_from_str(optarg, name);    break;
        case 'p': config->pmd_config                   = aapl_num_from_str( optarg, name, 0); break;
        case 'N': config->np_enable                    = aapl_bool_from_str(optarg, name);    break;
        case 'f': config->fec_ability                  = aapl_bool_from_str(optarg, name);    break;
        case 'r': config->fec_request                  = aapl_num_from_str( optarg, name, 0); break;
        case 'o': config->np_continuous_load           = aapl_bool_from_str(optarg, name);    break;

        case 10 : next_page_tx                         = 1; np_data_tx = optarg; break;
        case 11 : next_page_rx                         = 1; np_data_rx = optarg; break;

        case 'L': assert_link                          = 1; break;

        /* PMD Fields: */
        case  1 : aapl_str_to_pmd_train_mode(optarg, &new_pmd_config.train_mode);             configure_pmd |= 0x0001; break;
        case  2 : new_pmd_config.asym_tx               = aapl_num_from_str( optarg, name, 0); configure_pmd |= 0x0002; break;
        case  3 : new_pmd_config.initial_pre           = aapl_num_from_str( optarg, name, 0); configure_pmd |= 0x0004; break;
        case  4 : new_pmd_config.initial_post          = aapl_num_from_str( optarg, name, 0); configure_pmd |= 0x0008; break;
        case  5 : new_pmd_config.asymmetric_mode       = aapl_bool_from_str(optarg, name);    configure_pmd |= 0x0010; break;
        case  6 : new_pmd_config.disable_txeq_adj      = aapl_bool_from_str(optarg, name);    configure_pmd |= 0x0020; break;
        case  7 : new_pmd_config.invert_requests       = aapl_bool_from_str(optarg, name);    configure_pmd |= 0x0040; break;
        case  8 : new_pmd_config.reset_parameters      = aapl_bool_from_str(optarg, name);    configure_pmd |= 0x0080; break;
        case  9 : new_pmd_config.disable_timeout       = aapl_bool_from_str(optarg, name);    configure_pmd |= 0x0100; break;
        case 12 : new_pmd_config.prbs_seed             = aapl_num_from_str( optarg, name, 0); configure_pmd |= 0x0200; break;
        case 13 : new_pmd_config.TT_FECreq             = aapl_bool_from_str(optarg, name);    configure_pmd |= 0x0400; break;
        case 14 : new_pmd_config.TT_FECcap             = aapl_bool_from_str(optarg, name);    configure_pmd |= 0x0800; break;
        case 15 : new_pmd_config.TT_TF                 = aapl_bool_from_str(optarg, name);    configure_pmd |= 0x1000; break;

        /* Serdes-init fields: */
        case 16 : tx_width                             = aapl_num_from_str( optarg, name, 0); break;
        case 17 : rx_width                             = aapl_num_from_str( optarg, name, 0); break;
        case 18 : rx_width = tx_width                  = aapl_num_from_str( optarg, name, 0); break;

        case 25 : read_status = TRUE; break;
        case 26 : wait_for_an = TRUE; break;
        case 27 : wait_for_pmd = TRUE; break;
        default : if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

/* No args are allowed beyond options: */

    if( optind < argc )
        aapl_exit_on_unexpected_arg(argv[optind]);

    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) return 1; /* EXIT */
    aapl_get_ip_info(aapl,0);

    if( addr_struct.next == 0 && !aapl_check_ip_type(aapl, avago_struct_to_addr(&addr_struct), __func__, __LINE__, TRUE, 3,
                                       AVAGO_SERDES, AVAGO_M4, AVAGO_P1) )
        goto cleanup_and_exit; /* prevents invalid addresses from silently doing nothing */

    if (configure_pmd)
    {
        if( configure_pmd & 0x0001 ) pmd_config->train_mode  = new_pmd_config.train_mode;
        if( configure_pmd & 0x0002 ) pmd_config->asym_tx  = new_pmd_config.asym_tx;
        if( configure_pmd & 0x0004 ) pmd_config->initial_pre  = new_pmd_config.initial_pre;
        if( configure_pmd & 0x0008 ) pmd_config->initial_post = new_pmd_config.initial_post;
        if( configure_pmd & 0x0010 ) pmd_config->asymmetric_mode = new_pmd_config.asymmetric_mode;
        if( configure_pmd & 0x0020 ) pmd_config->disable_txeq_adj = new_pmd_config.disable_txeq_adj;
        if( configure_pmd & 0x0040 ) pmd_config->invert_requests = new_pmd_config.invert_requests;
        if( configure_pmd & 0x0080 ) pmd_config->reset_parameters = new_pmd_config.reset_parameters;
        if( configure_pmd & 0x0100 ) pmd_config->disable_timeout = new_pmd_config.disable_timeout;
        if( configure_pmd & 0x0200 ) pmd_config->prbs_seed = new_pmd_config.prbs_seed;
        if( configure_pmd & 0x0400 ) pmd_config->TT_FECreq = new_pmd_config.TT_FECreq;
        if( configure_pmd & 0x0800 ) pmd_config->TT_FECcap = new_pmd_config.TT_FECcap;
        if( configure_pmd & 0x1000 ) pmd_config->TT_TF = new_pmd_config.TT_TF;
    }
    if (an_start)
       avago_serdes_an_start(aapl, addr, config);
    if (next_page_tx)
       avago_serdes_an_next_page_transmit(aapl, addr, np_data_tx);
    if (next_page_rx)
       avago_serdes_an_next_page_receive(aapl, addr, np_data_rx);
    if( wait_for_an )
        avago_serdes_an_wait_hcd(aapl, addr, 10, 0);

    if( read_status )
    {
        if( avago_serdes_an_read_status(aapl, addr, AVAGO_SERDES_AN_GOOD) )
        {
            an_hcd = avago_serdes_an_read_status(aapl, addr, AVAGO_SERDES_AN_READ_HCD);
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "HCD = %d = \"%s\"\n", an_hcd, aapl_an_hcd_to_str(an_hcd));
        }
        else if( avago_serdes_an_read_status(aapl, addr, AVAGO_SERDES_AN_COMPLETE) )
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "AN_COMPLETE\n");
        else
            err = aapl_fail(aapl, 0, 0, "AN not complete.\n");
    }
    if( !err && assert_link )
    {
        if( 0 != avago_serdes_an_wait_hcd(aapl, addr, 10, 0) )
            aapl_fail(aapl, __func__, __LINE__, "AN HCD not negotiated on %s.\n", aapl_addr_to_str(addr));

        an_hcd = avago_serdes_an_read_status(aapl, addr, AVAGO_SERDES_AN_READ_HCD);

        /* Assert the link status to AN: */
        if( !err && avago_serdes_an_assert_link_status(aapl, addr, an_hcd) == -1 )
            err = aapl_fail(aapl, __func__, __LINE__, "SBus %s, Failed to assert link status.\n", aapl_addr_to_str(addr));

        /* Configure the device per negotiated HCD and then start PMD: */
        if( tx_width == 0 ) tx_width = avago_serdes_get_default_width(aapl, addr);
        if( rx_width == 0 ) rx_width = avago_serdes_get_default_width(aapl, addr);
        an_hcd = avago_serdes_an_configure_to_hcd(aapl, &addr_struct, config, pmd_config, tx_width, rx_width);
        if( an_hcd < 0 )
            goto cleanup_and_exit;

        /* avago_serdes_an_complete(aapl, avago_struct_to_addr(&addr_struct), an_hcd, config); */
    }
    if( !err && wait_for_pmd && pmd_config->clause != AVAGO_PMD_NONE )
    {
        int pmd_status = avago_serdes_pmd_wait(aapl, &addr_struct, 50, 80000);
        if( pmd_status == 0 )
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "PMD Completed on all channels\n");
        else
        {
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "PMD failed to complete on one or more channels\n");
            aapl->return_code--;
        }
    }
    if( assert_link && an_hcd != 31 )
    {
        if( !err && !avago_serdes_an_wait_complete(aapl, addr, 10, 1000) )
            return aapl_fail(aapl, __func__, __LINE__, "Fail to achieve AN Complete on %s\n", aapl_addr_to_str(addr));

        if( !err )  /* Disable AN: */
            avago_spico_int(aapl, addr, 0x0007, 0); /* Disable AN */
    }


cleanup_and_exit:
    ret = aapl->return_code < 0 ? 1 : 0;
    avago_serdes_an_config_destruct(aapl, config);
    avago_serdes_pmd_config_destruct(aapl, pmd_config);
    avago_addr_delete(aapl, &addr_struct);
    return ret;
}

#endif /* AAPL_ENABLE_MAIN && AAPL_ENABLE_SERDES_AUTO_NEG */
