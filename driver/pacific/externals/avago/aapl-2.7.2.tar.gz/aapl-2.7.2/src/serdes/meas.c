/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* AAPL (ASIC and ASSP Programming Layer) support for */
/* measuring the data signal from a SerDes slice (28nm only). */

/** Doxygen File Header */
/** @file */
/** @brief Helper functions for eye measurements. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#define AAPL_LOG_PRINT5 if(aapl->debug >= 5) aapl_log_printf
#define AAPL_LOG_PRINT6 if(aapl->debug >= 6) aapl_log_printf

/** @cond INTERNAL */

int avago_serdes_get_dac_range(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint addr)              /**< [in] Device address number. */
{
    int sdrev = aapl_get_sdrev(aapl,addr);
    return sdrev == AAPL_SDREV_CM4 || sdrev == AAPL_SDREV_CM4_16 || sdrev == AAPL_SDREV_D6_07 ? 512 : 256;
}

/** @endcond */

#if AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT || AAPL_ENABLE_DIAG

#define INT_CMP_CONTROL 0x0003
#define INT_DFE_EYE     0x0025

#if AAPL_ENABLE_ESCOPE_MEASUREMENT
#if AAPL_ALLOW_THREAD_SUPPORT
static AAPL_THREAD_STORAGE int mem_lock_count = 0; /* file scoped global that allows AAPL_SERDES_MEM_LOCK to be recursive */
#endif
#endif /* AAPL_ENABLE_ESCOPE_MEASUREMENT */

/** @cond INTERNAL */

/** @brief   Reads the SerDes phase multiplier value. */
/** @details The phase multiplier is the ratio between real (ASIC setting */
/**          level) PI steps per UI and the steps per UI in full rate */
/**          mode (which is 64). */
/** @details In reduced data rate mode, the hardware supports 2, 4 or */
/**          more times the PI steps per UI than in full rate mode. */
/** */
/** @details For example, if running in 1/4 rate mode, */
/**          avago_serdes_get_phase_multiplier returns 4 to indicate that the */
/**          hardware has 4 * 64 = 256 PI steps per UI. */
/** */
/** @return  On success, returns the phase multiplier (>= 1). */
/** @return  On error, decrements aapl->return_code and returns 0. */
/** @see     avago_serdes_get_phase(), avago_serdes_step_phase(). */
uint avago_serdes_get_phase_multiplier(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint addr)              /**< [in] Device address number. */
{
    int return_code = aapl->return_code;
    int reg;
    uint rc = 0;
    switch( aapl_get_sdrev(aapl,addr) )
    {
    case AAPL_SDREV_P1: rc = 1; break; /* P1 FW provides 64 phase steps per UI at all data rates. */
                        /* reg = 0x11c; mul_map = {2,1,4,1,8,1,6,1}; break; // PLL_F2_DIV_CTL[F2GEN_DIV1] */
    default:
    case AAPL_SDREV_CM4:
    case AAPL_SDREV_CM4_16:
    case AAPL_SDREV_OM4:
    case AAPL_SDREV_16: reg = 0x086; break; /* RX_PLL_F2_DIV_CTL[RX_F2DIV] */
    case AAPL_SDREV_D6_07: reg = 0x406; break; /* RX_PLL_F2_DIV_CTL[RX_F2DIV] */
    case AAPL_SDREV_HVD6:
    case AAPL_SDREV_D6: reg = 0x004; break; /* RX_PLL_F2_DIV_CTL[RX_F2DIV_IN] */
    case AAPL_SDREV_PON: {
        unsigned int mul_map[4] = {4,1,8,2};
        reg = 0x146; /* CDR_CNTL_3[DMA_RATE_SEL] */
        rc = mul_map[avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, reg) & 3] * 2;
        }
        break;
    }
    if( rc == 0 )
    {
        unsigned int mul_map[8] = {1,2,4,8,16,32,64,128};
        int bits = avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, reg) & 7;
        rc   = (return_code != aapl->return_code) ? 0 : mul_map[bits];
    }

    AAPL_LOG_PRINT5(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, multiplier %d.\n", aapl_addr_to_str(addr), rc);
    return rc;
}

/** @brief   Reads the current phase interpolator value. */
/** @details While the PI can be stepped to any value, positive or negative, */
/**          and those values are meaningful, the returned value is always */
/**          positive.  The PI wraps in a modulo arithmetic fashion. */
/**          That means the application must keep track of the actual location. */
/** @return  On success, returns the current phase interpolator setting */
/**          in range [0..127] on some devices, and [0..4095] on others. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_serdes_get_phase_multiplier(). */
int avago_serdes_get_phase(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint addr)              /**< [in] Device address number. */
{
    int return_code = aapl->return_code;
    int phase, rc;
    if( aapl_get_interrupt_rev(aapl,addr,INT_DFE_EYE) == 2 )
    {
        phase = ((short)((avago_spico_int(aapl, addr, INT_DFE_EYE, 0x2000) & 0x0fff) << 4)) >> 4;
    }
    else
    {
        phase = (short)avago_spico_int(aapl, addr, INT_DFE_EYE, 0x0200);
    }
    rc = return_code == aapl->return_code ? (int) phase : -1;
    AAPL_LOG_PRINT5(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, phase = %d.\n", aapl_addr_to_str(addr), rc);
    return rc;
}
/** @brief   Sets the PI (phase interpolator) value, and optionally does an */
/**          immediate gather (without another interrupt required). */
/** @return  On success, if <b>get_errors</b> is true, returns errors gathered, else 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** */
/** @details <b>Note</b>: Performs the indicated operation blindly, which is generally */
/**          unsafe unless it's the current value from avago_serdes_get_phase() or */
/**          the call comes through avago_serdes_step_phase(), which knows how to */
/**          step in increments supported by the PI hardware. */
/** */
/** <b>Note important side-effect</b>:  The SerDes SPICO DFE FW does automatic */
/** re-gathering unless PI or DAC is set.  If the caller changes the error */
/** compare/counter mode (via avago_serdes_set_rx_cmp_mode()) or the timer (via */
/** avago_serdes_set_error_timer()), they must not call avago_serdes_get_errors() directly, but go */
/** through avago_serdes_set_phase() or avago_serdes_set_dac() to ignore the invalid */
/** gather; also see comments in avago_serdes_get_errors(). */
/** */
static int avago_serdes_set_phase(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr,          /**< [in] Device address number. */
    int  phase,         /**< [in] New phase interpolator setting. */
    BOOL get_errors)    /**< [in] If true, accumulate errors before returning. */
{
    /* NOTE: HW and FW bit resolutions differ:  D6: 7 HW, 8 FW; P1: 8 HW, 8 FW.  M4: 7 HW, 12 FW. */
    int return_code = aapl->return_code;
    int rc;
    uint errors;
    if( aapl_get_interrupt_rev(aapl,addr,INT_DFE_EYE) == 2 )
    {
        int full_precision = FALSE;
        /* Interrupt 0x25 v2: */
        if( full_precision )
        {
            /* Read full precision error count: */
            int int_data = 0x4000 | (phase & 0x0fff);
            errors = avago_spico_int(aapl, addr, INT_DFE_EYE, (get_errors ? 0x8000 : 0) | int_data); /* low 15 bits */
            if( get_errors && (errors & 0x8000) )   /* Is high part non-zero? */
            {
                errors &= 0x7fff;
                errors |= avago_spico_int(aapl, addr, INT_DFE_EYE, 0x1000 | int_data) << 15;  /* high part */
            }
        }
        else
        {
            /* Read floating point error count: */
            int int_data = 0x7000 | (phase & 0x0fff);
            errors = avago_spico_int(aapl, addr, INT_DFE_EYE, (get_errors ? 0x8000 : 0) | int_data);
            if( errors & 0xe000 )
                errors = (0x1000 | (errors & 0x0fff)) << (((errors >> 12) & 0x0f) - 1);
        }
    }
#if 0
    else if( get_errors )
    {
        /* Interrupt 0x25 v1 batch operation: */
        Avago_spico_int_t ints[] =
        {
            {INT_DFE_EYE, 0x0000, 0, AVAGO_SPICO_INT_FIRST},     /* setphase + read low */
            {INT_DFE_EYE, 0x0000, 0, AVAGO_SPICO_INT_NOT_FIRST}, /* read low */
            {INT_DFE_EYE, 0x0100, 0, AVAGO_SPICO_INT_ALL}        /* read hi */
        };
        ints[0].param = 0x8000 | 0x2000 | (phase & 0x7f);

        avago_spico_int_array(aapl, addr, 3, ints);
        errors = ints[0].ret | ints[1].ret | (ints[2].ret << 16);
    }
#endif
    else
    {
        /* Interrupt 0x25 v1: */
        errors = avago_spico_int(aapl, addr, INT_DFE_EYE, (get_errors ? 0x8000 : 0) | 0x2000 | (phase & 0xff)); /* low 16 bits */
        if( get_errors )
            errors |= avago_spico_int(aapl, addr, INT_DFE_EYE, 0x0100) << 16; /* high 16 bits */
    }
    if( return_code != aapl->return_code )
        return aapl_fail(aapl,__func__,__LINE__,"SBus %s, phase=%d, get_errors=%d, errors %u.\n", aapl_addr_to_str(addr), phase, get_errors, errors);
    rc = get_errors ? (int) errors : 0;
    AAPL_LOG_PRINT6(aapl, AVAGO_DEBUG6, __func__, __LINE__, "SBus %s, phase %d, get_errors %d, errors %u.\n", aapl_addr_to_str(addr), phase, get_errors, rc);
    return rc;
}
/** @brief Moves the PI (phase interpolator) value, and optionally does a 28nm */
/**        immediate gather (without another interrupt required). */
/** */
/** @details The PI value cannot be set absolutely, but must be moved in a */
/**          controlled manner.  This is why avago_serdes_set_phase is not directly */
/**          accessible to the user. */
/** */
/** Steps the phase from the present to a new hardware setting, always */
/** decrementing/incrementing by 1 at the real (SerDes) setting level, and */
/** always doing at least one PI set even if already at the goal.  Optionally */
/** does a 28nm immediate gather (without another interrupt required). */
/** */
/* Note:  Why step the real (SerDes) PI always by 1?  Any other steps can */
/* cause short-term glitches or runt pulses, and even permanent failure to */
/* synchronize downstream, if the F10 clock (used to fill words with bits) */
/* gets out of sync, requiring cal/init to fix. */
/* */
/* The code COULD be smarter about 28nm Gray scale stepping, but it's not */
/* trivial.  The "OK to step by 3 or 5" idea is an oversimplification.  It */
/* doesn't work at all points, and it's not always OK to just change the Gray */
/* coded value by one bit either. */
/* */
/** @return  Returns the errors gathered (when get_errors is true), else */
/**          0 on success. */
/** @return  On failure, decrements aapl->return_code and returns -1. */
/**          In addition, *current_phase is updated for any phase changes. */
/** @see     avago_serdes_get_phase(), avago_serdes_get_phase_multiplier(), avago_serdes_get_errors(). */
int avago_serdes_step_phase(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr,          /**< [in] Device address number. */
    int  target_phase,  /**< [in] New phase interpolator setting. */
    int *current_phase, /**< [in,out] Current PI, is updated with any changes. */
    BOOL get_errors)    /**< [in] If true, accumulate errors before returning. */
{
    int return_code = aapl->return_code;
    int new_phase = *current_phase;
    int old_phase = new_phase;
    int step = (new_phase < target_phase) ? +1 :
               (new_phase > target_phase) ? -1 : 0;
    int errors, rc;

    while( (new_phase += step) != target_phase )  /* stop before reaching goal. */
    {
        if( avago_serdes_set_phase(aapl, addr, new_phase, FALSE) < 0 )
            break;
        *current_phase += step;  /* immediately after each successful step. */
    }

    /* Always do at least a single avago_serdes_set_phase(), even if already */
    /* at the new PI setting: */
    errors = avago_serdes_set_phase(aapl, addr, new_phase, get_errors);
    if( errors >= 0 )
        *current_phase += step;  /* immediately after each successful step. */
    rc = return_code == aapl->return_code ? errors : -1;

    AAPL_LOG_PRINT5(aapl, AVAGO_DEBUG5, __func__, __LINE__,
        "SBus %s, old/target/got/step = %d,%d,%d,%d; get_errors %d, errors = %d.\n",
        aapl_addr_to_str(addr), old_phase, target_phase, *current_phase, step, get_errors, rc);

    return rc;
}



/** @brief   Sets the DAC and optionally does an immediate gather. */
/** @details If full_precision is TRUE, a 31 bit error count is returned. */
/**          If full_precision is FALSE, a value with 13 bit precision is returned. */
/**          The lower precision value is faster to read, and generally sufficient */
/**          for displaying pictures.  For BTC calculations, the full_precision */
/**          value is recommended. */
/** @return  On success, if get_errors is TRUE, returns errors gathered, else 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_serdes_get_errors(), avago_serdes_step_phase(). */
int avago_serdes_set_dac2(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint addr,              /**< [in] Device address number. */
    uint udac,              /**< [in] New DAC setting for test channel. */
    BOOL full_precision,    /**< [in] Request full precision return. */
    BOOL get_errors)        /**< [in] If true, accumulate and return error count. */
{
    int return_code = aapl->return_code;
    uint errors;
    int dac = udac;
    /* D6 firmware inverts DAC sense from HW reality, so invert again */
    int sdrev = aapl_get_sdrev(aapl,addr);
    int dac_range = avago_serdes_get_dac_range(aapl,addr);

    /* NOTE: Also see get_vert_alpha function which should have the same list: */
    /* */
    if( sdrev == AAPL_SDREV_D6 || sdrev == AAPL_SDREV_HVD6 || sdrev == AAPL_SDREV_16 || sdrev == AAPL_SDREV_P1 )
    {
        /* FW_DAC(AAPL_DAC) = 255 - AAPL_DAC */
        /* D6_HW_DAC(FW_DAC) = 255 - (FW_DAC - 127 + VOS) */
        /* D6_HW_DAC(AAPL_DAC) = 255 - (255 - AAPL_DAC - 127 + VOS) = AAPL_DAC - (VOS-127) */

        /* AAPL DAC  ->  D6_FW_DAC  -> D6_HW_DAC */
        /*    255    ->        0    -> 255  # NOTE: Register writes are forced to range [0..255]. */
        /*    128    ->      127    -> 128 */
        /*    127    ->      128    -> 127 */
        /*      0    ->      255    ->   0 */
     /* dac--;  // Pushes both level means up */
        dac++;  /* Pushes both level means down */
        dac = dac_range-1-dac;
        if( !aapl_check_firmware_rev(aapl,addr, __func__, __LINE__, FALSE, 1, 0x1065) )
        {
            dac += 2;
            if( dac > 255 ) dac = 255;
        }
    }

    if( aapl_get_interrupt_rev(aapl,addr,INT_DFE_EYE) == 2 )
    {
        dac -= (dac_range - 1) / 2; /* To get to nominal mid */

        /* Interrupt 0x25 v2: */
        if( full_precision )
        {
            /* Read full precision error count: */
            int int_data = 0x0000 | (dac & 0x0fff);
            errors = avago_spico_int(aapl, addr, INT_DFE_EYE, (get_errors ? 0x8000 : 0) | int_data); /* low 15 bits */
            if( get_errors && (errors & 0x8000) )   /* Is high part non-zero? */
            {
                errors &= 0x7fff;
                errors |= avago_spico_int(aapl, addr, INT_DFE_EYE, 0x1000 | int_data) << 15;  /* high part */
            }
        }
        else
        {
            /* Read floating point error count: */
            int int_data = 0x3000 | (dac & 0x0fff);
            errors = avago_spico_int(aapl, addr, INT_DFE_EYE, (get_errors ? 0x8000 : 0) | int_data);
            if( errors & 0xe000 )
                errors = (0x1000 | (errors & 0x0fff)) << (((errors >> 12) & 0x0f) - 1);
        }
        if( !get_errors )
            errors = 0;
    }
#if 0
    else if( get_errors )
    {
        /* Interrupt 0x25 v1 batch operation: */
        Avago_spico_int_t ints[] =
        {
            {INT_DFE_EYE, 0x0000,  0, AVAGO_SPICO_INT_FIRST},     /* setdac + read low */
            {INT_DFE_EYE, 0x0000,  0, AVAGO_SPICO_INT_NOT_FIRST}, /* read low */
            {INT_DFE_EYE, 0x0100,  0, AVAGO_SPICO_INT_ALL}        /* read hi */
        };
        ints[0].param = 0x8000 | 0x4000 | (dac & 0xff);

        avago_spico_int_array(aapl, addr, 3, ints);
        errors = ints[0].ret | ints[1].ret | (ints[2].ret << 16);
    }
#endif
    else
    {
        /* Interrupt 0x25 v1: */
        errors = avago_spico_int(aapl, addr, INT_DFE_EYE, (get_errors ? 0x8000 : 0) | 0x4000 | (dac & 0xff)); /* low 16 bits */
        if( get_errors )
            errors |= avago_spico_int(aapl, addr, INT_DFE_EYE, 0x0100) << 16; /* high 16 bits */
        else
            errors = 0;
    }
    if( return_code != aapl->return_code )
        return aapl_fail(aapl, __func__, __LINE__, "SBus %s, dac=%d, get_errors=%d, errors %u.\n", aapl_addr_to_str(addr), dac, get_errors, errors);
    AAPL_LOG_PRINT5(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, dac %d, get_errors %d, errors %u.\n", aapl_addr_to_str(addr), dac, get_errors, errors);
    return (int)errors;
}

#endif /* AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT || AAPL_ENABLE_DIAG */

#if AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT

/** @brief   Sets the DAC and optionally does an immediate gather. */
/** @return  On success, if get_errors is TRUE, returns errors gathered, else 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/** @see     avago_serdes_get_errors(), avago_serdes_step_phase(). */
int avago_serdes_set_dac(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint addr,              /**< [in] Device address number. */
    uint dac,               /**< [in] New DAC setting for test channel. */
    BOOL get_errors)        /**< [in] If true, accumulate and return error count. */
{
    return avago_serdes_set_dac2(aapl,addr,dac,TRUE,get_errors);
}

/** @brief   Gets the SerDes error timer value. */
/** @return  Error timer value, in bits. */
bigint avago_serdes_get_error_timer(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr)          /**< [in] Device address number. */
{
    /* Read ERROR_TIMER_VAL_LO and ERROR_TIMER_VAL_HI: */
    bigint dwell_bits = 0;
    int reg_error_timer_val_lo, reg_error_timer_val_hi;
    switch( aapl_get_sdrev(aapl,addr) )
    {
    case AAPL_SDREV_P1: reg_error_timer_val_lo = 0xdd; reg_error_timer_val_hi = 0xde; break;
    default:
    case AAPL_SDREV_16: reg_error_timer_val_lo = 0x13; reg_error_timer_val_hi = 0x14; break;
    }

    dwell_bits  = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, reg_error_timer_val_lo);
    dwell_bits |= avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, reg_error_timer_val_hi) << 16;
    dwell_bits *= avago_serdes_get_rx_register_clock(aapl,addr);
    if( avago_serdes_get_rx_line_encoding(aapl, addr) )
        dwell_bits *= 2;

    AAPL_LOG_PRINT5(aapl, AVAGO_DEBUG5, __func__, __LINE__, "SBus %s, dwell_bits = %s.\n", aapl_addr_to_str(addr), aapl_bigint_to_str(dwell_bits));

    return dwell_bits;
}

/** @brief   Gets the clock source for data capture. */
/** */
/** @return  Returns TRUE if the RX test channel is using the rotated clock, */
/**          FALSE otherwise. */
BOOL avago_serdes_get_rx_test_chan_rclk(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr)          /**< [in] Device address number. */
{
    BOOL test_is_rclk = FALSE;
    Avago_serdes_rx_clocks_t rx_clock;
    if( 0 == avago_serdes_rx_clock_read(aapl, addr, &rx_clock) )
        test_is_rclk = (rx_clock.test == AVAGO_SERDES_RX_CLOCK_R);

    aapl_log_printf(aapl, AVAGO_DEBUG5, __func__,__LINE__,"SBus %s, return %s\n",aapl_addr_to_str(addr), aapl_bool_to_str(test_is_rclk));

    return test_is_rclk;
}


/** @brief   Sets the clock source for data capture. */
/** @details Switches the test channel between iclk (mission data) and */
/*           rclk (rotated, using phase interpolator). */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
/* NOTE: Does NOT support Denali-A. */
/* Other Notes: */
/* iclk = mission data, qclk = quadrature, and rclk = rotated (test */
/* channel using phase interpolator). */
int avago_serdes_set_rx_test_chan_rclk(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr,          /**< [in] Device address number. */
    BOOL select_rclk)   /**< [in] TRUE == rclk, FALSE == iclk. */
{
    Avago_serdes_rx_clock_t clock = select_rclk ? AVAGO_SERDES_RX_CLOCK_R : AVAGO_SERDES_RX_CLOCK_I;
    aapl_log_printf(aapl,AVAGO_DEBUG5,__func__,__LINE__,"SBus %s, set rclk %s\n", aapl_addr_to_str(addr), aapl_bool_to_str(select_rclk));

#if 0
    /* TODO: Switch to the interrupt once it is implemented: */
    if( build_id == 0x8025 || build_id == 0x0025 ) /* Opal 1 & 2 */
        /*  0x0 = i_clock (data) */
        /*  0x1 = q_clock (edge) */
        /*  0x2 = r_clock (rotated/phase)                                irqi     iiqi */
        avago_serdes_mem_wr(aapl, addr, AVAGO_ESB, 0x93, select_rclk ? 0x0210 : 0x0010);
#endif

    if( avago_serdes_set_rx_test_clock(aapl, addr, clock) )
        return 0;
    return -1;
}

#define DOUBLE_EDGE_PHASE_CENTERING 1

#if ! DOUBLE_EDGE_PHASE_CENTERING
/*============================================================================== */
/* U N S P I K E   M A X   E R R O R S */
/* */
/* Given: */
/* */
/* - aapl struct */
/* - phase settings:  min, key (where max_errors was found), and max */
/* - pointer to array of error counts across this range; must access using */
/*   ERRORS_GET/SET() */
/* */
/* Check and correct for a misleading spike in the error counts, and return a */
/* better (lower) max_errors value if any, else the present value. */
/* */
/* Discussion:  Some SerDes (such as 40nm Aswan) have the odd property that */
/* they produce a spike in error counts above the true max value, say 1 in */
/* every 10 UI (on 40nm), which is bad if the search range happens to cross */
/* this point, which happens to be likely on Aswan (the spike is 1 UI to the */
/* right of the good XOR eye). */
/* */
/* This function starts with the highest max_errors found, which could be at */
/* the top of a spike, and walks away from it in the longer available direction */
/* looking for a "level sequence" of error counts that are "stable" within a */
/* "window" whose constant size was determined experimentally.  The height of */
/* the window is how much variation (absolute value of fractional difference */
/* between successive counts) is too much, and the length of the window is the */
/* number of stable sequential counts that must be seen. */

static int unspike_max_errors(Aapl_t *aapl, int phase_min, int phase_key, int phase_max, const int *errorsp)
{
    int max_errors = errorsp[phase_key];

    int window_height = 100;  /* relative change fraction denominator; see function header comments. */
    int window_width  = 4;    /* sequential counts; see function header comments. */

/* Walk away from phase_key in whichever direction has more data points */
/* available: */

    int dir, phase_lim;  /* step direction and limit. */

    if( (phase_max - phase_key) > (phase_key - phase_min) ) {dir = +1; phase_lim = phase_max;}
    else                                                    {dir = -1; phase_lim = phase_min;}

    int phase_new;  /* best max_errors point. */
    int delta;      /* pairwise change (ratio). */
    int errors;     /* shorthand at one PI setting. */
    int count = 0;  /* of sequential good points. */

/* Look for relative stability of high error counts; see above: */

    for( phase_new = phase_key; phase_new != phase_lim; phase_new += dir )
    {
        errors = errorsp[phase_new + dir];  /* next neighbor. */
        int e = abs(errorsp[phase_new] - errors);
        delta =  e > 0 ? errors / e : window_height;
        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "%3d, %8d / %5d = %d\n", phase_new, errorsp[phase_new], e, delta);

        if( delta < window_height ) {count = 0; continue;}  /* reset at any bad point. */
        if( ++count < window_width ) continue;  /* count good points. */

/* Don't do anything if no evidence of a spike, meaning the initial point was */
/* good enough; moving to a new max_errors shouldn't hurt, but there's no need */
/* to report it either: */

        if( phase_new == (phase_key + (dir * (window_width - 1))) ) break;

        phase_new -= (dir * ((int) (window_width / 2)));  /* approx middle of window. */
        errors = errorsp[phase_new];
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "found better max at phase %d: %d => %d.\n", phase_new, max_errors, errors);
        max_errors = errors;
        break;
    }
    return max_errors;
}
#endif

/* Insure that the current phase is stepped into the 7 bit range that */
/* avago_serdes_get_phase() can return.  This allows another caller */
/*  to retrieve and use this value consistently with any other function */
/*  that modifies the phase. */

static int set_phase_to_standard_range(Aapl_t *aapl, uint addr, int current_phase)
{
    if( current_phase > 127 )
        avago_serdes_step_phase(aapl, addr, 127, &current_phase, FALSE);
    if( current_phase < 0 )
        avago_serdes_step_phase(aapl, addr, 0, &current_phase, FALSE);
    return aapl->return_code;
}

/** @brief  Find the SerDes test channel phase interpolator (PI) eye center. */
/** */
/** @return The PI center value (>= 0), or aapl->return_code (< 0) on error. */
/* */
/* Method:  Find eye edges, which have similar BER spaced one UI apart. */
/*          The center is then 1/2 UI before the edge which is rising (or */
/*          one UI later to avoid returning negative phases). */
/* Advantages over old method: */
/*          Inherently ignores error spikes. */
/*          Typical speed is faster, worst case is same. */
/*          Simpler algorithm. */
/* */
/* Old Method: Looks for a 50% BER transition crossing relative to max errors */
/* (RX bits per dwell time), which works even with closed eyes that descend far */
/* enough; otherwise returns the center based on the lowest error count seen. */
/* */
/* Note: */
/* */
/* - Always sets the error (dwell) timer to a short value. */
/* */
/* - Always sets the DAC to the Y center, then X-centers using XOR */
/*   (Mission^Test) mode.  Why center with XOR mode even if plotting the eye */
/*   with Pattern = Test^PatGen or (unlikely) some other mode?  The nature of */
/*   comparing against PatGen is that "false eyes" are generated, for obscure */
/*   reasons, one UI off from the good eyes.  XOR mode doesn't have this */
/*   problem, and produces (nearly) identical centering results. */
/* */
/* - Leaves error compare/counter control modified, unless it's in XOR to start */
/*   with. */
/* */
/* - Leaves test channel clock source set to the test clock (rclk). */

int avago_serdes_find_phase_center(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr,          /**< [in] Device address number. */
    char **log_message) /**< [out] Info used to determine the phase center. */
{
    int dac_center = (avago_serdes_get_dac_range(aapl,addr) - 1) / 2;

    bigint dwell_bits = AVAGO_EYE_DEF_DWELL_BITS;

/* Unlock here first just in case the error counter resource was left locked: */
/* */
/* TBD:  This is a poor workaround for proper parallel resource access */
/* handling.  The error counter lock doesn't even start until gathering time, */
/* which is too late (already set timer, mode, etc).  Anyway in ebert.pl the */
/* abort/exit path is fairly solid for doing the unlock, but since in AAPL a */
/* general abort (SIGINT/SIGPIPE at least) path doesn't exist yet, force-unlock */
/* early here as a workaround.  Too bad if DFE tuning or some other resource */
/* user is running...  No sufficient locking is available yet. */

    Avago_serdes_data_qual_t dq;

    int sdrev = aapl_get_sdrev(aapl,addr);
    if( sdrev == AAPL_SDREV_P1 )
        return 32;   /* 32 is always the center */
    if( sdrev == AAPL_SDREV_PON )
        return 0;   /* 0 is always the center */

    aapl_str_to_data_qual("xxx,msb", &dq);

/* Set required SerDes test channel state: */
    if( avago_serdes_set_rx_cmp_mode(aapl, addr, AVAGO_SERDES_RX_CMP_MODE_XOR) < 0
     || avago_serdes_set_data_qual(aapl, addr, dq) < 0
     || avago_serdes_set_dac(aapl, addr, dac_center, /* get_errors = */ FALSE) < 0
     || avago_serdes_set_error_timer(aapl, addr, dwell_bits) < 0
     || avago_serdes_set_rx_test_chan_rclk(aapl, addr, TRUE) < 0 )
    {
        return -1;
    }

    /* Set Error Count force active: */
    if( AAPL_SDREV_P1 == aapl_get_sdrev(aapl,addr) )
        avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, 0xd7, 0, 8);
    else
        avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, 0x0d, 0, 8);

#if 0
    if( sdrev == AAPL_SDREV_D6_07 )
    {
        int pi = 0x849;
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Absolute Center:  %3d\n", (short)avago_spico_int(aapl, addr, 0x125, 0x2000));
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Virtual Center:   %3d\n", (short)avago_spico_int(aapl, addr, 0x025, 0x2000));
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi (0x%3x)      = %3d\n", pi,(short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+0));
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_temp         = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+1));
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_center       = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+2));
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_total        = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+3));
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_two_ui_range = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+4));
        avago_spico_int(aapl, addr, 0x25, 0x4000);  /* Set phase to center of eye */
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Absolute Center:  %3d\n", (short)avago_spico_int(aapl, addr, 0x125, 0x2000));
        aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Virtual Center:   %3d\n", (short)avago_spico_int(aapl, addr, 0x25, 0x2000));
        return 0;   /* Virtual center */
    }
    /* Code for 16nm PCIe gen4 SerDes with Lane Margining hardware and associated firmware support: */
    {
        int fw_rev   = aapl_get_firmware_rev(aapl, addr);
        int fw_eng   = avago_firmware_get_engineering_id(aapl, addr);
        int fw_build = aapl_get_firmware_build(aapl, addr);
        if( fw_build == 0x2347 && ((fw_rev&0xff) > 0x83 || ((fw_rev&0xff) == 0x83 && fw_eng >= 2) || ((fw_rev&0xff) == 0x80 && fw_eng >= 0x50)) )
        {
            int pi = 0x1e3;
            avago_spico_int(aapl, addr, 0x25, 0x2000);  /* Set phase to center of eye */
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Absolute Center:  %3d\n", (short)avago_spico_int(aapl, addr, 0x125, 0x0200));
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Virtual Center:   %3d\n", (short)avago_spico_int(aapl, addr, 0x025, 0x0200));
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi (0x%3x)      = %3d\n", pi, (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+0));
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_temp         = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+1));
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_center       = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+2));
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_total        = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+3));
            aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "pi_two_ui_range = %3d\n", (short)avago_serdes_mem_rd(aapl, addr, AVAGO_DMEM, pi+4));
            return 0;   /* Virtual center */
        }
    }
#endif

    {
    int x_resolution = avago_serdes_get_phase_multiplier(aapl,addr) * 64;
    int current_phase = avago_serdes_get_phase(aapl, addr);

#define INVALID_PHASE  (-x_resolution)
    int phase_center = INVALID_PHASE;           /* value found. */

#if DOUBLE_EDGE_PHASE_CENTERING
    int phase_start = -2;
    int phase_end = 2 * x_resolution + phase_start + 7; /* 7 allow for skew. */
    int *errors_all = (int *)aapl_malloc(aapl, sizeof(int) * (phase_end-phase_start), __func__);
    int *errors = &errors_all[-phase_start];    /* ptr allows negative indices */
    int phase;                                  /* present index. */
    int phase_min_errs = 0;                     /* where minimum was seen. */
    int phase_max_errs = 0;                     /* where minimum was seen. */
    int min_errs = dwell_bits+1;  /* keep track of minimum errors. */
    int max_errs = 0;             /* keep track of maximum errors */
    const char *dir = "unknown";            /* "rising & falling" or vice versa. */
    int phase_prev_ui = 0;

    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "SBus %s, Count errors over phase range %d..%d, dac=%d, x_res=%d.\n", aapl_addr_to_str(addr),phase_start,phase_end,dac_center,x_resolution);

    for( phase = phase_start; phase < phase_end; phase++ )
    {
        /* NOTE: step_phase seems to return differing error info from set_dac, */
        /* resulting in a one phase step difference in centering.  Since all */
        /* other gathers are done using set_dac, we also use set_dac here. */
        int errs;
        avago_serdes_step_phase(aapl, addr, phase, &current_phase, /* get_errors = */ FALSE);
        errs = avago_serdes_set_dac2(aapl,addr,dac_center,FALSE,TRUE);
        if( errs < 0 )
        {
            aapl_free(aapl, errors_all, __func__);
            return -1;
        }

        errors[phase] = errs;
        /*if( errs > 300000 ) printf("get_error_timer = %s\n",aapl_bigint_to_str(avago_serdes_get_error_timer(aapl,addr))); */

        if (min_errs > errs) {min_errs = errs; phase_min_errs = phase;}
        if (max_errs < errs) {max_errs = errs; phase_max_errs = phase;}

        if( errs != 0 ) aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, phase/errors/min: %3d: %8d, %8d.\n", aapl_addr_to_str(addr), phase, errs, min_errs);

        if( phase < x_resolution+phase_start )  /* Need one UI to start comparing */
            continue;

/* We look back one step less than a full UI so we have a perfect center */
/* and avoid rounding issues. */

        phase_prev_ui = phase - (x_resolution - 1);

/* Compare error counts with those of previous UI. */
/* When count values are equivalent, we've found the edges and can calculate */
/* the center from the rising edge. */

        if( errors[phase_prev_ui-1] >  errors[phase-1] &&   /* negative slope */
            errors[phase_prev_ui]   <= errors[phase] &&     /* positive slope */
            errors[phase] != 0 )
        {
            dir = "falling & rising";
            phase_center = phase - x_resolution / 2;
            {
                /* This block validates that we've settled on a good edge. */
                /* If not, we keep searching, using this "center" only if */
                /*   another or better one isn't found. */
                BOOL found_good_match = TRUE;
                int i;
                for( i = 1; i < 7 && found_good_match; i++ )
                {
                    if( errors[phase-i-1] > errors[phase-i] )
                        found_good_match = FALSE;
                    if( errors[phase_prev_ui+i-1] < errors[phase_prev_ui+i] )
                        found_good_match = FALSE;
                }
                if( found_good_match )
                    break;
            }
        }

        if( errors[phase_prev_ui-1] <  errors[phase-1] &&    /* positive slope */
            errors[phase_prev_ui]   >= errors[phase] &&      /* negative slope */
            errors[phase_prev_ui] != 0 )
        {
            dir = "rising & falling";
            phase_center = phase + x_resolution / 2;
            phase_center %= 2 * x_resolution;   /* To keep the value in range */
            {
                /* This block validates that we've settled on a good edge. */
                /* If not, we keep searching, using this "center" only if */
                /*   another or better one isn't found. */
                BOOL found_good_match = TRUE;
                int i;
                for( i = 1; i < 7 && found_good_match; i++ )
                {
                    if( errors[phase-i-1] < errors[phase-i] )
                        found_good_match = FALSE;
                    if( errors[phase_prev_ui+i-1] > errors[phase_prev_ui+i] )
                        found_good_match = FALSE;
                }
                if( found_good_match )
                    break;
            }
        }
    }
    /* In this case, we need to try another algorithm: */
    if( phase_center == INVALID_PHASE && max_errs > 0 )
    {
        int i, mod = x_resolution * 2;
        int left = phase_max_errs, right = phase_max_errs;
        for( i = 0; i < x_resolution/2; i++ )
        {
            int phase = phase_max_errs + i;
            if( errors[phase % mod] != 0 ) right = phase;
            phase = phase_max_errs - i;
            if( errors[(phase + mod) % mod] != 0 ) left = phase;
        }
        phase_center = ((left + right) / 2 + x_resolution) % mod;
    }

    if( log_message )   /* Log centering info */
    {
        int buf_size = (phase - phase_start) * 10 + 70;
        char *buf = (char *)aapl_realloc(aapl, *log_message, buf_size, __func__);
        char *ptr = buf;
        char *end = buf + buf_size;
        int p = phase_start;
        ptr += snprintf(ptr,end-ptr,"min %d at %d center %d start %d counts:",
             min_errs, phase_min_errs, phase_center, phase_start);

        if( phase == phase_end ) phase--;   /* Avoid accessing beyond end */
        while( ptr < end && p <= phase )
            ptr += snprintf(ptr,end-ptr," %d", errors[p++]);
        *log_message = buf;
    }

/* Handle failure to find edges: */

    if( phase_center == INVALID_PHASE )
    {
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "SBus %s; Cannot find eye edges (error counts rising and falling separated by 1 UI) over PI range %d..%d. Using point of minimum errors (%d at phase %d).\n", aapl_addr_to_str(addr), phase_start, phase_end, min_errs, phase_min_errs);

        aapl_free(aapl, errors_all, __func__);
        return phase_min_errs; /* The best we can do... */
    }

/* Found an edge: */

    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "SBus %s, Phase centering found %s edges at %d&%d (%d,%d..%d,%d); errors min = %d at %d; center = %d.\n", aapl_addr_to_str(addr),
        dir, phase_prev_ui-1, phase,
        errors[phase_prev_ui-1], errors[phase_prev_ui],
        errors[phase-1], errors[phase],
        min_errs, phase_min_errs, phase_center);

    aapl_free(aapl, errors_all, __func__);

#else   /* ! DOUBLE_EDGE_PHASE_CENTERING (== SINGLE_EDGE_PHASE_CENTERING) */

/* Below, phase_range is far enough to cover at least two UI, to find a good */
/* max_errors value.  (A smaller range is faster, but not enough in the worst */
/* case, if starting at just the wrong phase setting with a wide eye.) */
/* */
/* And phase_range is far enough to cover enough UI to ensure finding at least */
/* one eye edge.  In <= 40nm that takes 10 UI, but in >= 28nm only 2 UI (plus a */
/* little margin). */

    int phase_range = 2 * x_resolution;
    int phase_stop2 = phase_range + 7;
    int errors_all[phase_stop2+1];      /* error count at each phase visited. */

    int    phase;                       /* present index. */
    int    phase_min_errors = 0;        /* where minimum was seen. */
    int    phase_max_errors = 0;        /* where maximum was seen. */
    int    errors;                      /* present value (negative for anomaly). */
    bigint min_errors = AAPL_CONST_INT64(1e12); /* keep track of minimum point. */
    bigint max_errors = 0;              /* auto-scale to actual max value. */

/* Discover and "autoscale" to the maximum possible error count: */
/* */
/* Scan upward from the initial phase setting through phase_range to ensure */
/* gathering enough points to definitely see a valid max_errors value.  This */
/* avoids any complications about timer settings (theoretical max errors) */
/* versus gathering modes and actual errors seen, error transition density, */
/* etc.  Save error counts seen along the way. */

    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Count errors over phase range 0..%d.\n", phase_range);

    for( phase = 0; phase <= phase_range; phase++ )
    {
        errors = avago_serdes_step_phase(aapl, addr, phase, &current_phase, /* get_errors = */ TRUE);
        if( errors < 0 )
            return -1;

        errors_all[phase] = errors;

        if (min_errors > errors) {min_errors = errors; phase_min_errors = phase;}
        if (max_errors < errors) {max_errors = errors; phase_max_errors = phase;}

        aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "phase/errors/min/max: %3d: %8d, %8ld, %8ld.\n", phase, errors, min_errors, max_errors);
    }

/* Correct max_errors if necessary: */
/* */
/* Note:  Why not just watch for a "good" max_errors value while running the */
/* loop above, and quit sooner?  The problem is that, even starting with a */
/* theoretical (ultimate limit) max_errors based on RX bits from the caller, */
/* doesn't tell you the actual (empirical) best value for the true data.  That */
/* depends on both the theoretical limit and the transition density (0101...  = */
/* 50%, longer runs of 0s/1s => lower) or DC balance.  A shallow (closed) eye */
/* with both max_errors outside the eye, and a high error count inside the eye, */
/* would be mishandled. */

    max_errors = unspike_max_errors(aapl, 0, phase_max_errors, phase_range, errors_all);

/* Check that a high enough error count was seen, where "high enough" is */
/* somewhat arbitrary, but err on the low side: */

    int min_max_errors = dwell_bits / 100;

    if( max_errors < min_max_errors )
    {
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Insufficiently high max error count (%ld, need %d) seen over 2 UI (phase settings %d..%d) to horizontally center eye data. Using point of minimum errors (%ld at phase %d).\n", max_errors, min_max_errors, 0, phase_range, min_errors, phase_min_errors);

        return phase_min_errors;
    }

/* Check for a rising or falling eye edge in the data already gathered, or if */
/* none, keep scanning and looking: */
/* */
/* A rising or falling edge means a pair of successive error counts straddling */
/* one half of max_errors.  This is similar in concept to how the mission data */
/* channel recovers the quadrature clock, and by definition should occur */
/* exactly 1/2 UI from the center of the eye (mission data clock). */
/* Second-order effects, including integer rounding, fuzz this out a little */
/* bit, but shouldn't be big enough to matter.  So finding either edge (rising */
/* or falling) is sufficient. */
/* */
/* Note:  This loop restarts at phase_start, but "knows" the phase setting is */
/* phase_range.  Through that point it uses saved error counts, then starts */
/* gathering more. */
/* */
/* TBD:  Doesn't know how to use three-point moving averages to smooth out */
/* noise in the error counts a little, but it should. */

    bigint thresh       = max_errors / 2;  /* see above */
    int    prev         = -1;              /* successive error counts: */
    int    now          = errors_all[0];
    const char *dir     = "";              /* "rising" or "falling". */

    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Check/count errors over phase range %d..%d, thresh = %d.\n", 0, phase_stop2, thresh);

    for( phase = 0 + 1; phase <= phase_stop2; phase++ )
    {
        prev = now;

        if( phase <= phase_range )  /* use existing: */
        {
            now = errors_all[phase];
        }
        else  /* gather new data point: */
        {
            now = errors = avago_serdes_step_phase(aapl, addr, phase, &current_phase, /* get_errors = */ TRUE);
            if( now < 0 )
                return set_phase_to_standard_range(aapl, addr, current_phase); /* Error */

            errors_all[phase] = errors;

/* Should be no need to update max_errors, but do track min_errors in case a */
/* better "backup" center materializes: */

            if( min_errors > errors ) {min_errors = errors; phase_min_errors = phase;}

            aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "phase/errors/min/max: %3d: %8d, %8ld, %8ld.\n", phase, errors, min_errors, max_errors);
        }

/* Check for threshold crossing in either direction, in which case move 1/2 UI */
/* in the appropriate direction from the threshold crossing point: */
/* */
/* Note:  In odd cases this extrapolation results in phase < 0 or > phase_stop2, */
/* but that's OK. */

        int    halfUI = x_resolution / 2;     /* +/- x_resolution */
        if     ( (prev <= thresh) && (now >= thresh) ) {dir = "rising";  halfUI = -halfUI;}
        else if( (prev >= thresh) && (now <= thresh) ) {dir = "falling"; halfUI = +halfUI;}
        else continue;

        phase_center = phase + halfUI;
        /* Interpolate which step is closer to the edge and adjust accordingly: */
        if( abs(now - thresh) > abs(thresh - prev) )
            phase_center--;
        break;

    } /* each phase */

/* Handle failure to find an edge: */

    if( phase_center == INVALID_PHASE )
    {
        aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "Cannot find an eye edge (error counts rising or falling through threshold = %d = half of max errors) over PI range %d..%d. Using point of minimum errors (%ld at phase %d).\n", thresh, 0, phase_stop2, min_errors, phase_min_errors);

        return phase_min_errors; /* The best we can do... */
    }

/* Found an edge: */

    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "Phase centering complete; found %s edge at %d; max/dwell = %s/%s; prev,now = %d,%d; center = %d.\n", dir, phase, aapl_bigint_to_str(max_errors), aapl_bigint_to_str(dwell_bits), prev, now, phase_center);

#endif  /* DOUBLE_EDGE_PHASE_CENTERING */

    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "SBus %s, PHASE CENTER = %d\n", aapl_addr_to_str(addr), phase_center);

    /* Call to coordinate with serdes_get_phase: */
    set_phase_to_standard_range(aapl, addr, current_phase);

    return phase_center;
    }
}

/** @brief   Gets the power status of the phase interpolator circuitry. */
/** @return  On success, returns 0 if phase interpolator circuitry is */
/**          powered down and 1 if it is powered up. */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_serdes_get_phase_interpolator_power_state(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr)          /**< [in] Device address number. */
{
    int return_code = aapl->return_code;
    int reg_pd, reg_pd_mask;
    int rc = 1;  /* If old firmware, assume it is powered up. */

    switch( aapl_get_sdrev(aapl,addr) )
    {
    case AAPL_SDREV_D6:   reg_pd = 0x11; reg_pd_mask = 1<<2; break; /* F2R_PD */
    case AAPL_SDREV_HVD6: reg_pd = 0xc2; reg_pd_mask = 1<<2; break; /* F2R_PD */
    case AAPL_SDREV_CM4:
    case AAPL_SDREV_CM4_16:
    case AAPL_SDREV_OM4:  reg_pd = 0x8b; reg_pd_mask = 1<<0; break; /* PI_PDR_BOGUS_0 */
    default:
    case AAPL_SDREV_16:   reg_pd = 0x8b; reg_pd_mask = 1<<5; break; /* PI_F2R_PD_1 */
    case AAPL_SDREV_D6_07:reg_pd =0x5fa; reg_pd_mask = 1<<5; break; /* PI_F2R_PD_1 */
    case AAPL_SDREV_P1:   return 1;   /* TODO: Is this correct? */
    }

    if( aapl_check_firmware_rev(aapl,addr, __func__, __LINE__, FALSE, 1, 0x1045) )
    {
        int bits = avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, reg_pd);
        rc  = (bits & reg_pd_mask) ? 0 : 1; /* down : up; */
        aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "SBus %s, ESB reg 0x%x = 0x%x, return = %d.\n", aapl_addr_to_str(addr), reg_pd, bits, rc);
    }
    else
        aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "SBus %s, OLD FIRMWARE, return = %d.\n", aapl_addr_to_str(addr), rc);
    return (return_code == aapl->return_code) ? rc : -1;
}

/** @brief   Sets phase interpolator (PI) hardware to low/no power mode. */
/** @details The PI powers up automatically whenever interrupt 0x0f is invoked. */
/**          However, since the firmware does not know when the user is finished */
/**          with the PI, the PI user must explicitly */
/**          power it down when it is no longer needed. */
/** @return  On success, returns 0. */
/** @return  On error, decrements aapl->return_code and returns -1. */
int avago_serdes_power_down_phase_interpolator(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr)          /**< [in] Device address number. */
{
    if( aapl_check_firmware_rev(aapl,addr, __func__, __LINE__, FALSE, 1, 0x1045) )
    {
        if( !avago_spico_int_check(aapl, __func__, __LINE__, addr, 0x0f, 0x100) )   /* Power down request */
            return -1;
        aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "SBus %s, phase interpolator powered down.\n", aapl_addr_to_str(addr));
    }
    else /* Can't do operation on older firmware */
        aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "SBus %s, OLD FIRMWARE, phase interpolator not powered down.\n", aapl_addr_to_str(addr));
    return 0;
}

/** @brief  Gets hardware info into string buffer. */
/** @return On success, an allocated buffer with hardware info is returned. */
/**         The caller is responsible for calling aapl_free() on the returned value. */
/** @return On error, NULL is returned. */
char *avago_hardware_info_format(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr)          /**< [in] Device address number. */
{
    const int buf_length = 250;
    char *buf = (char *)aapl_malloc(aapl, buf_length, __func__);
    char *ptr = buf;
    uint sbm_addr = avago_make_sbus_master_addr(addr);
    uint eng_release = avago_firmware_get_engineering_id(aapl, addr);
    char eng_buffer[10];
    sprintf(eng_buffer, "_%03X", eng_release);
    if( !buf ) return 0;
    buf[0] = '\0';
    ptr += snprintf(ptr,buf_length-(ptr-buf),
            "SBus_address:   %s\n"
            "JTAG_ID:        %s rev %s (0x%08x)\n"
            "Process_ID:     %s (%d)\n"
            "SBus_master:    FW sbus_master.0x%04X_%04X.rom\n"
            "SerDes:         ",
        aapl_addr_to_str(addr),
        aapl_get_chip_name(aapl, addr),
            aapl_get_chip_rev_str(aapl, addr),
            aapl_get_jtag_idcode(aapl, addr),
        aapl_get_process_id_str(aapl, addr),
            aapl_get_process_id(aapl, addr),
        aapl_get_firmware_rev(aapl,sbm_addr),
            aapl_get_firmware_build(aapl,sbm_addr));
    ptr += snprintf(ptr,buf_length-(ptr-buf), "%s ",
            avago_get_ip_info(aapl, addr)->rev_id_name);
    ptr += snprintf(ptr,buf_length-(ptr-buf), "(0x%02x); LSB 0x%02x; ",
                aapl_get_ip_rev(aapl,addr),
                aapl_get_lsb_rev(aapl,addr));
    ptr += snprintf(ptr,buf_length-(ptr-buf), "CF %d MHz; ",
                avago_get_ip_info(aapl, addr)->center_freq);
    ptr += snprintf(ptr,buf_length-(ptr-buf), "FW serdes.0x%04X_%04X%s.rom\n",
                aapl_get_firmware_rev(aapl,addr),
                aapl_get_firmware_build(aapl,addr),
                eng_release?eng_buffer:"");
    return buf;
}
#endif /* AAPL_ENABLE_EYE_MEASUREMENT || AAPL_ENABLE_ESCOPE_MEASUREMENT */

/* DFE status bit meanings (as of 0x1048): */
/* dfe_status[0] iCal in_prog */
/* dfe_status[1] pCal in_prog */
/* dfe_status[2] vos  in_prog */
/* dfe_status[3] No REFCLK tuning flag */
/* dfe_status[4] run_ical */
/* dfe_status[5] run_pcal */
/* dfe_status[6] adaptive pcal */
/* dfe_status[7] VOS done */
/* dfe_status[9] EI detected (loss of signal) */
#define AVAGO_DFE_ACTIVE           0x37
#define AVAGO_DFE_ADAPTIVE_ENABLED 0x40

/** @endcond */

/** @brief   Checks if signal is loss during dfe tuning. */
/** @return  Returns TRUE if dfe is LOS detected, FALSE otherwise. */
/** @see     avago_serdes_get_dfe_status(). */
BOOL avago_serdes_dfe_los(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr)          /**< [in] Device address number. */
{
    int dfe_status = avago_serdes_get_dfe_status(aapl, addr);
    return (dfe_status & 0x200) != 0;
}

/** @brief   Checks if DFE is running. */
/** @return  Returns TRUE if dfe is running, FALSE otherwise. */
/** @see     avago_serdes_get_dfe_status(). */
BOOL avago_serdes_dfe_running(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr)          /**< [in] Device address number. */
{
    int dfe_status = avago_serdes_get_dfe_status(aapl, addr);
    return (dfe_status & AVAGO_DFE_ACTIVE) != 0;
}

/** @brief   Waits until any running DFE completes. */
/** @details May return without any wait if DFE is paused because of loss of signal. */
/**          Call avago_serdes_dfe_pause() rather than this function. */
/** @return  Returns 1 if dfe has stopped. */
/** @return  Returns 0 if dfe is still running (timeout). */
/** @return  Returns -1 and decrements aapl->return_code if dfe won't run because of no signal. */
/** @see     avago_serdes_dfe_tune(), avago_serdes_dfe_wait(). */
int avago_serdes_dfe_wait_timeout(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr,          /**< [in] Device address number. */
    int ms_timeout)     /**< [in] Maximum milliseconds to wait for dfe to complete. */
{
    /* Wait for tuning to stop: */
    int dfe_status;
    /* dfe_status > 0 == running, 0 == complete, -1 = Loss of Signal */
    int ret_status;
    int loop_delay = 40; /* milliseconds */
    int loop_time = 0;
    Aapl_log_type_t log_level = AVAGO_DEBUG3;
    dfe_status = avago_serdes_interpret_dfe_status(aapl, addr);
    aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "SBus %s, dfe_status 0x%x, Waiting for tuning to stop.\n", aapl_addr_to_str(addr), dfe_status);
    while( dfe_status > 0 && loop_time < ms_timeout )
    {
        /* Work around for firmware <= 1043, which can leave a run bit set */
        /*  without actually starting DFE tuning. */
        /* So we start the pending DFE tuning directly. */
        if( !(dfe_status & AVAGO_DFE_ADAPTIVE_ENABLED)
            && !aapl_check_firmware_rev(aapl, addr, __func__,__LINE__,FALSE,1, 0x1044)
            /* If a run bit is set,  but the in_prog bit is not set: */
            && ((dfe_status & 0x30) && !(dfe_status & 0x03)) )
        {
            avago_serdes_mem_rmw(aapl, addr, AVAGO_DMEM, 0x200, 0x40, 0x40);
            aapl_log_printf(aapl, AVAGO_WARNING, __func__, __LINE__, "SBus %s, Running DFE Workaround\n",aapl_addr_to_str(addr));
        }

        loop_time += loop_delay;
        ms_sleep(loop_delay);
        if( aapl->debug >= 4 && ((loop_time / loop_delay) % 100) == 0 )
        {
            char buf[60], *ptr = buf;
            int i;
            for( i = 0; ptr-buf < (int)(sizeof(buf))-10; i++ )
            {
                uint pc = avago_sbus_rd(aapl, addr, 0x25);
                ptr += sprintf(ptr, "%x, ", pc);
            }
            aapl_log_printf(aapl, AVAGO_DEBUG4, __func__, __LINE__, "SBus %s, dfe_status 0x%x, pc samples=%s\n", aapl_addr_to_str(addr), dfe_status, buf);
        }
        dfe_status = avago_serdes_interpret_dfe_status(aapl, addr);
    }
    ret_status = dfe_status == 0 ? 1 : dfe_status > 0 ? 0 : -1; /* Convert to return value */
    if( ret_status < 0 ) aapl->return_code--;   /* Decrement return_code on LOS return. */
    if( ret_status != 1 ) log_level = AVAGO_WARNING;
    aapl_log_printf(aapl, log_level, __func__, __LINE__, "SBus %s, dfe_status 0x%x, DFE tuning %s, loop_time=%d ms.\n",
                    aapl_addr_to_str(addr), avago_serdes_get_dfe_status(aapl, addr), ret_status == 0 ? "stop timed out" : ret_status == 1 ? "stopped" : "no signal", loop_time);
    return ret_status;
}

/** @brief   Wait until any running DFE completes. */
/** @details May return without any wait if DFE is paused because of loss of signal. */
/** @details Calls avago_serdes_dfe_pause() rather than this function. */
/** @return  Returns 1 if dfe has stopped. */
/** @return  Returns 0 if dfe is still running (timeout). */
/** @return  Returns -1 and decrements aapl->return_code if dfe won't run because of no signal. */
/** @see     avago_serdes_dfe_tune(), avago_serdes_dfe_wait_timeout(). */
int avago_serdes_dfe_wait(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr)          /**< [in] Device address number. */
{
    int ms_timeout = 20000;
    if( aapl_check_firmware_rev(aapl, addr, __func__, __LINE__, FALSE, 1, 0x1054) )
        ms_timeout = 50000;
    if( aapl_get_ip_type(aapl, addr) == AVAGO_M4 )
        ms_timeout *= 4;
    return avago_serdes_dfe_wait_timeout(aapl, addr, ms_timeout);
}

/** @brief   Block new DFE actions from starting, and */
/**          then wait on any in progress. */
/** @details Each SerDes may participate in round-robin (rr) pCal or continuous */
/**          adaptive pCal, both of which can start DFE at any time. Since a */
/**          running DFE interferes with eye and escope measurement, */
/**          avago_serdes_dfe_pause() is provided to block any new pCal from */
/**          starting and then wait for any in-progress tuning to finish. */
/**          <br> */
/**          Note on firmware support: */
/**          0x1049 and newer: Pause and resume are fully supported, pause and */
/**            resume are idempotent, and rr_enabled is unused and may be NULL. */
/**          In pre-0x1049 releases, adaptive pCal is stopped and the user must */
/**              restart it themselves. */
/**          In release 0x1048, the rr_enabled field must be used to properly */
/**              resume the rr state.  In pre-0x1048, rr is not supported. */
/** @return  On success, returns 0. */
/**          On error, decrements aapl->return_code and returns -1. */
/**          If the wait on in-progress DFE times out, a -1 is returned without */
/**          aapl->return_code being decremented.  In this case, call */
/**          avago_serdes_dfe_pause() again to wait an additional period of time */
/**          for DFE to complete. */
/**          If dfe_pause returns because of loss of signal, -1 is returned */
/**          and aapl->return_code is decremented. */
/** @see     avago_serdes_dfe_resume(), avago_serdes_dfe_tune(), avago_serdes_tune(). */
int avago_serdes_dfe_pause(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr,          /**< [in] Device address number. */
    uint *rr_enabled)   /**< [out] Return if RR was enabled (0x1048 only). */
{
    if( rr_enabled )
        *rr_enabled = FALSE;

    if( aapl_get_ip_type(aapl, addr) == AVAGO_M4 )
    {
        /* M4 firmware does not implement the pause and resume interrupt options. */
        /* Since it does not support round-robin participation, and doesn't */
        /* pause anything in progress, we need only resume adaptive pCal. */
        /* rr_eanbled is used to pass adaptive pCal status to resume. */

        if( avago_serdes_get_dfe_status(aapl, addr) & AVAGO_DFE_ADAPTIVE_ENABLED )
        {
            /* Switch from adaptive pCal to one shot pCal. */
            if( rr_enabled ) *rr_enabled = TRUE;
            avago_spico_int_check(aapl, __func__, __LINE__, addr, 0x0a, 0x02);
        }
        /* Wait for any in-progress tuning to stop: */
        return avago_serdes_dfe_wait(aapl, addr) == 1 ? 0 : -1;
    }

    if( aapl_check_firmware_rev(aapl,addr, __func__, __LINE__, FALSE, 1, 0x1049) )
    {
        if (!avago_spico_int_check(aapl, __func__, __LINE__, addr, 0x0a, 0x00)) return -1;

        /* Wait for any in-progress tuning to stop: */
        /*return avago_serdes_dfe_wait(aapl, addr) == 1 ? 0 : -1; */
        return avago_serdes_dfe_wait(aapl, addr) == 1 ? 0 : -1;
    }

    /* Handle older firmware revisions here: */

    /* 0x1048 supports RR, but we have to track the state ourselves. */
    if( aapl_check_firmware_rev(aapl,addr, __func__, __LINE__, FALSE, 1, 0x1048) )
    {
        if( rr_enabled )
            *rr_enabled = avago_spico_int(aapl, addr, 0x126, 0x5400);
        if( !rr_enabled || *rr_enabled )
            if (!avago_spico_int_check(aapl, __func__, __LINE__, addr, 0x0a, 0x08)) return -1;   /* Remove from RR */
    }

    /* Pre-1049 revs can't restart adaptive, so simply stop it if running. */
    /* User must restart it if desired. */
    if( avago_serdes_get_dfe_status(aapl, addr) & AVAGO_DFE_ADAPTIVE_ENABLED )
    {
        Avago_serdes_dfe_tune_t control;
        avago_serdes_tune_init(aapl, &control);
        control.tune_mode = AVAGO_DFE_STOP_ADAPTIVE;
        avago_serdes_tune(aapl, addr, &control);
    }

    /* Wait for any in-progress tuning to stop: */
    return avago_serdes_dfe_wait(aapl, addr) == 1 ? 0 : -1;
}

/** @brief   Resumes the previously paused DFE run state. */
/** @details Resumes the DFE execution state most recently saved by the */
/**          avago_serdes_dfe_pause operation. In particular, */
/**          if DFE adaptive tuning was running, it resumes running. And if */
/**          round robin pCal participation was enabled, it is re-enabled. */
/**          Note that repeating a resume operation has no additional effect, */
/**          but repeating a pause operation will clear the resume state. */
/**          Note for 0x1048 firmware, RR participation is restored. */
/**          For pre-0x1049 firmware, adaptive pCal must be restarted */
/**          by the caller, if desired. */
/** @return  On success, returns 0. */
/**          On error, decrements aapl->return_code and returns -1. */
/** @see     avago_serdes_dfe_pause(), avago_serdes_dfe_tune(), avago_serdes_tune(). */
int avago_serdes_dfe_resume(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure. */
    uint addr,          /**< [in] Device address number. */
    uint rr_enable)     /**< [in] Enable RR if TRUE (0x1048 release only). */
{
    if( aapl_get_ip_type(aapl, addr) == AVAGO_M4 )
    {
        /* M4 firmware does not implement the pause and resume interrupt options. */
        /* Since it does not support round-robin participation, and doesn't */
        /* pause anything in progress, we need only resume adaptive pCal. */
        /* Note that rr_enable is used to pass original adaptive pCal state. */

        /* Restart adaptive pCal: */
        if( rr_enable && !avago_spico_int_check(aapl, __func__, __LINE__, addr, 0x0a, 0x06) )
            return -1;
        return 0;
    }

    if( aapl_check_firmware_rev(aapl,addr, __func__, __LINE__, FALSE, 1, 0x1049) )
    if( aapl_check_firmware_rev(aapl,addr, __func__, __LINE__, FALSE, 1, 0x1049) )
    {
        return avago_spico_int_check(aapl, __func__, __LINE__, addr, 0x0a, 0x0f) ? 0 : -1;
    }

    /* Handle older firmware revisions here: */

    /* 0x1048 supports RR, but we have to track the state ourselves. */
    if( rr_enable && aapl_check_firmware_rev(aapl,addr, __func__, __LINE__, FALSE, 1, 0x1048) )
        if( !avago_spico_int_check(aapl, __func__, __LINE__, addr, 0x0a, 0x0a) ) /* Re-add to RR */
            return -1;

    /* Pre-1049 revs can't restart adaptive. */
    /* User must restart it if desired. */
    return 0;
}

/** @cond INTERNAL */

#if AAPL_ENABLE_FILE_IO

void scan_array(const char *str, int *array, int len)
{
    int i;
    const char *ptr = str;
    for( i = 0; i < len; i++ )
    {
        char *end;
        array[i] = aapl_strtol(ptr,&end,0);
        ptr = end;
        if( *ptr == ',' ) ptr++;
    }
}
#define SCAN_A(str,array) scan_array(str,(int *)array,AAPL_ARRAY_LENGTH(array))

#define EQS(str1,str2) (0==strcmp(str1,str2))

/** @brief Reads dfe fields from measurement function data file into dfe structure: */
void avago_update_dfe_field(Avago_serdes_dfe_state_t *dfe, const char *name, int value, const char *str_val)
{
    if(      EQS(name,"dfe.fixed_dc"           ) ) dfe->fixed_dc = value;
    else if( EQS(name,"dfe.fixed_lf"           ) ) dfe->fixed_lf = value;
    else if( EQS(name,"dfe.fixed_hf"           ) ) dfe->fixed_hf = value;
    else if( EQS(name,"dfe.fixed_bw"           ) ) dfe->fixed_bw = value;
    else if( EQS(name,"dfe.seeded_dc"          ) ) dfe->seeded_dc = value;
    else if( EQS(name,"dfe.seeded_lf"          ) ) dfe->seeded_lf = value;
    else if( EQS(name,"dfe.seeded_hf"          ) ) dfe->seeded_hf = value;
    else if( EQS(name,"dfe.seedDC"             ) ) dfe->seedDC = value;
    else if( EQS(name,"dfe.seedLF"             ) ) dfe->seedLF = value;
    else if( EQS(name,"dfe.seedHF"             ) ) dfe->seedHF = value;
    else if( EQS(name,"dfe.dfe_disable"        ) ) dfe->dfe_disable = value;
    else if( EQS(name,"dfe.tune_mode"          ) ) aapl_str_to_dfe_tune_mode(str_val, &dfe->tune_mode);
    else if( EQS(name,"dfe.dc"                 ) ) dfe->dc = value;
    else if( EQS(name,"dfe.lf"                 ) ) dfe->lf = value;
    else if( EQS(name,"dfe.hf"                 ) ) dfe->hf = value;
    else if( EQS(name,"dfe.bw"                 ) ) dfe->bw = value;
    else if( EQS(name,"dfe.gainshape1"         ) ) dfe->gainshape1 = value;
    else if( EQS(name,"dfe.gainshape2"         ) ) dfe->gainshape2 = value;

    else if( EQS(name,"dfe.dwell_bits"         ) ) dfe->dwell_bits = value;
    else if( EQS(name,"dfe.error_threshold"    ) ) dfe->error_threshold = value;
    else if( EQS(name,"dfe.dfeGAIN"            ) ) dfe->dfeGAIN = value;
    else if( EQS(name,"dfe.dfeGAIN2"           ) ) dfe->dfeGAIN2 = value;
    else if( EQS(name,"dfe.dfeGAIN_min"        ) ) dfe->dfeGAIN_min = value;
    else if( EQS(name,"dfe.dfeGAIN_max"        ) ) dfe->dfeGAIN_max = value;
    else if( EQS(name,"dfe.state"              ) ) dfe->state = value;
    else if( EQS(name,"dfe.status"             ) ) dfe->status = value;
    else if( EQS(name,"dfe.rxFFE"              ) ) SCAN_A(str_val,dfe->rxFFE);
    else if( EQS(name,"dfe.vos"                ) ) SCAN_A(str_val, dfe->vos);
    else if( EQS(name,"dfe.vosMID"             ) ) SCAN_A(str_val, dfe->vosMID);
    else if( EQS(name,"dfe.dataLEV"            ) ) SCAN_A(str_val, dfe->dataLEV);
    else if( EQS(name,"dfe.testLEV"            ) ) SCAN_A(str_val, dfe->testLEV);
    else if( EQS(name,"dfe.eyeHeights"         ) ) SCAN_A(str_val, dfe->eyeHeights);
    else if( EQS(name,"dfe.vernierDelay"       ) ) SCAN_A(str_val, dfe->vernierDelay);
    else if( EQS(name,"dfe.dfeTAP_offset"      ) ) SCAN_A(str_val, dfe->dfeTAP_offset);
    else if( EQS(name,"dfe.taps"               ) )
    {
        /* Move ptr past first value: */
        const char *ptr = strchr(str_val,',');
        if( ptr ) ptr++; else ptr = "";

        /* Scan the first value: */
#if AAPL_ENABLE_FLOAT_USAGE
        sscanf(str_val, "%20f", &dfe->dfeTAP1);
#else
        sscanf(str_val, "%9d", &dfe->dfeTAP1);
#endif
        /* Scan remaining items into array of taps: */
        SCAN_A(ptr, dfe->dfeTAP);
    }
    /* For compatibility reading old files: */
    else if( EQS(name,"dfe.DC"                 ) ) dfe->dc = value;
    else if( EQS(name,"dfe.LF"                 ) ) dfe->lf = value;
    else if( EQS(name,"dfe.HF"                 ) ) dfe->hf = value;
    else if( EQS(name,"dfe.BW"                 ) ) dfe->bw = value;
    else if( EQS(name,"dfe.disable"            ) ) dfe->dfe_disable = value;
    else if( EQS(name,"dfe.GAIN"               ) ) dfe->dfeGAIN = value;
    else if( EQS(name,"dfe.GAIN2"              ) ) dfe->dfeGAIN2 = value;
    else if( EQS(name,"dfe.GAIN_min"           ) ) dfe->dfeGAIN_min = value;
    else if( EQS(name,"dfe.GAIN_max"           ) ) dfe->dfeGAIN_max = value;
    else return;   /* No op statement to satisfy checkers. */
}

/* Print the list if any element is non-zero: */
static BOOL print_list(FILE *file, const char *label, const char *format, const int *array, int len)
{
    int i;
    BOOL have_data = FALSE;
    for( i = 0; i < len; i++ )
        if( array[i] )
        {
            have_data = TRUE;
            break;
        }
    if( have_data )
    {
        fprintf(file, label, array[0]);
        for( i = 1; i < len; i++ )
            fprintf(file, format, array[i]);
        fprintf(file,"\n");
    }
    return have_data;
}

/** @endcond */

/** @brief  Writes the DFE structure values to file. */
/** @return void. */
void avago_write_dfe_state(
    FILE *file,                           /**< [in] File Pointer. */
    const Avago_serdes_dfe_state_t *dfe)  /**< [in] DFE state structure to be dump in file. */
{
#define WRITE_FIELD(member) if( dfe->member != 0 ) fprintf(file,"%-20s%3u\n","dfe." #member ":", dfe->member)
#define PRINT_A(file,label,format,array) print_list(file,label,format,(int *)array,AAPL_ARRAY_LENGTH(array))
    WRITE_FIELD(fixed_dc);
    WRITE_FIELD(fixed_lf);
    WRITE_FIELD(fixed_hf);
    WRITE_FIELD(fixed_bw);
    WRITE_FIELD(seeded_dc);
    WRITE_FIELD(seeded_lf);
    WRITE_FIELD(seeded_hf);
    WRITE_FIELD(seedDC);
    WRITE_FIELD(seedLF);
    WRITE_FIELD(seedHF);
    WRITE_FIELD(dfe_disable);
  /*WRITE_FIELD(seeded_tuning); */
    fprintf(file,"tune_mode:      %3s\n", aapl_dfe_tune_mode_to_str(dfe->tune_mode));
    WRITE_FIELD(dc);
    WRITE_FIELD(lf);
    WRITE_FIELD(hf);
    WRITE_FIELD(bw);
    WRITE_FIELD(gainshape1);
    WRITE_FIELD(gainshape2);
    PRINT_A(file,"dfe.vos:            %3d",",%d",dfe->vos);
    PRINT_A(file,"dfe.vosMID:         %3u",",%u",dfe->vosMID);
#if AAPL_ENABLE_FLOAT_USAGE
    fprintf(file,"dfe.taps:          %5.1f",dfe->dfeTAP1);
#else
    fprintf(file,"dfe.taps:          %d",dfe->dfeTAP1);
#endif
    if( !PRINT_A(file,",%d",",%d",dfe->dfeTAP) )
        fprintf(file,"\n");
    PRINT_A(file,"dfe.dataLEV:       %4d",",%d",dfe->dataLEV);
    PRINT_A(file,"dfe.testLEV:       %4d",",%d",dfe->testLEV);
    PRINT_A(file,"dfe.eyeHeights:    %4d",",%d",dfe->eyeHeights);
    PRINT_A(file,"dfe.vernierDelay:  %4d",",%d",dfe->vernierDelay);
    WRITE_FIELD(dwell_bits);
    WRITE_FIELD(error_threshold);
    WRITE_FIELD(dfeGAIN);
    WRITE_FIELD(dfeGAIN2);
    WRITE_FIELD(dfeGAIN_min);
    WRITE_FIELD(dfeGAIN_max);
    PRINT_A(file,"dfe.rxFFE:          %3d",",%d",dfe->rxFFE);
    WRITE_FIELD(state);
    fprintf(file,"dfe.status:        0x%02x = %s\n", dfe->status, aapl_dfe_status_to_str(dfe->status));
    PRINT_A(file,"dfe.dfeTAP_offset:  %3d",",%d",dfe->dfeTAP_offset);
}
#endif /* AAPL_ENABLE_FILE_IO */

/** @cond INTERNAL */

#if AAPL_ENABLE_ESCOPE_MEASUREMENT

/** @brief  Finds the greatest common divisor of two integers. */
/** @return Returns the GCD of two integers. */
static uint gcd(uint a, uint b)
{
    while( a )
    {
        int temp = a;
        a = b % a;
        b = temp;
    }
    return b;
}

/** @brief  Finds the least common multiple of two integers. */
/** @return Returns the least common multiple of the inputs. */
uint avago_least_common_multiple(
    uint a,  /**< Any positive integer */
    uint b)  /**< Any positive integer */
{
    uint temp = gcd(a,b);
    return temp ? (a / temp * b) : 0;
}

/** @brief Calculates the register clocks needed to setup the heartbeat */
/**        for the given pattern_length and register clock divider. */
/** @return Heartbeat in register clocks. */
int avago_meas_calculate_heartbeat(int pattern_length, int rx_register_clock)
{
    /* Calculate the minimum period to consistently align pattern_length */
    /*   in the capture registers. */
    uint lcm = avago_least_common_multiple(pattern_length, rx_register_clock) / rx_register_clock;
    int period = lcm;
    /* Increase period until it's at least some minimum. */
    /* Minimum working value may depend on lots of factors. */
    /* 9 seems to work, but longer doesn't hurt. */
    while( period < 50 )
        period += lcm;  /* Increase by multiples of lcm value. */
    return period;
}


/** @brief      Set up the heartbeat for consistent (aligned) data capture. */
/** @details    The heartbeat must repeat every LCM(pattern_length,20) bits */
/**             since the data is captured 20 bits at a time.  This way */
/**             the data will be consistently aligned within the register */
/**             every time we read it. */
/** */
/**             Since the timer counts down using the register clock */
/**             (which is bits / 20), our period is */
/**             avago_least_common_multiple(pattern_length,20)/20 clocks. */
/** */
/**             Finally, since the heartbeat takes three cycles to reseed, */
/**             and we need 4 clocks to capture 80 bits, we insure a minimum */
/**             heartbeat period of 6, accounting for overlap. */
/** */
/** @return aapl->return_code, which is 0 on success, <0 on failure. */
/* */
/* Detailed timing analysis: */
/* */
/* Heartbeat counts a period of N as follows: */
/* */
/*    2,   1,   0,   0, N-3, N-3, N-4, N-5, N-6, ... */
/* */
/* Example for period of 6 (the minimum): */
/* */
/*    2,   1,   0,   0,   3,   3,   2,   1,  0,  0,  3,  3,  2, ... */
/* */
/* Example for period of 9: */
/* */
/*    2,   1,   0,   0,   6,   6,   5,   4,  3,  ... */
/* */
/* Capture occurs when heartbeat counter < TIMER1_ALMOST_DONE_CNT, */
/*       so a value of 0 will not capture.  Also, since the count starts */
/*       at N-3, values > N-3 will never stop capture. */
/* */
/* Therefore, the TIMER1_ALMOST_DONE_CNT value must be in range [1..N-3]. */
/* Note however that a value of N-3 captures for only two clock cycles, */
/*   which is insufficient to load all 80 bits. */
/* Combining all these constraints results in a minimum value for N of 6. */

int avago_meas_setup_heartbeat(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint addr,              /**< [in] Device address number. */
    int pattern_length,     /**< [in] Length of repeating pattern. */
    BOOL test_channel)      /**< [in] If TRUE, gather data from the test channel, otherwise gather from the main data channel */
{
    int return_code = aapl->return_code;

    /* Calculate the register clocks needed for the given pattern length: */
    int rx_clock_divider = avago_serdes_get_rx_register_clock(aapl,addr);
    int period = avago_meas_calculate_heartbeat(pattern_length,rx_clock_divider);

    int timer_cnt = period - 3; /* 3 is a fixed value, based on the hardware response. */

    int rx_prbs_control_reg, clock_enables_reg, timer1_cntl_reg, timer_val_lo_reg, timer_val_hi_reg, cmp_clk_sel_reg;
    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "patlen = %d, period = %d\n", pattern_length, period);
    switch( aapl_get_sdrev(aapl,addr) )
    {
    case AAPL_SDREV_P1: /* Only for Buck Hill and newer. */
        clock_enables_reg   = 0x00d6;   /* TIMER1_CLK_EN */
        rx_prbs_control_reg = 0x00f2;   /* RX_SEED_SEL, RX_RESEED_ON_ERROR */
        timer_val_lo_reg    = 0x010a;   /* TIMER_START_CNT_15_0_ */
        timer_val_hi_reg    = 0x010b;   /* TIMER_START_CNT_29_16_ */
        timer1_cntl_reg     = 0x010c;   /* TIMER1_ENABLE_HEARTBEAT, TIMER1_CLK_SEL = CMP_CLK (Hard coded), TIMER1_LOAD, TIMER1_EN */
        cmp_clk_sel_reg     = 0x00e2;   /* CMP_CLK_SEL */
        break;
    default: /* M4, 16nm, D6 firmware: */
    case AAPL_SDREV_16:
        clock_enables_reg   = 0x000c;   /* TIMER1_CLK_EN */
        rx_prbs_control_reg = 0x002a;   /* RX_SEED_SEL, RX_RESEED_ON_ERROR */
        timer_val_lo_reg    = 0x0038;   /* TIMER_START_CNT_15_0_ */
        timer_val_hi_reg    = 0x0039;   /* TIMER_START_CNT_29_16_ */
        timer1_cntl_reg     = 0x003a;   /* TIMER1_ENABLE_HEARTBEAT, TIMER1_CLK_SEL = RX, TIMER1_LOAD, TIMER1_EN */
        cmp_clk_sel_reg     = 0x0018;   /* CMP_CLK_SEL */
        break;
    }

    /* Set RX PRBS CONTROL, RX_SEED_SEL to test channel: */
    avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, rx_prbs_control_reg, ((test_channel ? 1 : 0) << 12), (3 << 12));

    /* Select rx_clk into the comparator: (needed on P1 since P1 uses cmp_clk for heartbeat) */
    avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, cmp_clk_sel_reg, 0, 3);

    /* Enable RX_CLK, TIMER1 heartbeat clock, CMP_CLK: */
    avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, clock_enables_reg, (1<<15)|(1<<6)|(1<<1), (1<<15)|(1<<6)|(1<<1));

    /* PRBS control, Disable RX PRBSGEN: */
    avago_serdes_set_rx_cmp_data(aapl, addr, AVAGO_SERDES_RX_CMP_DATA_OFF);

    /* Set RX PRBS CONTROL, RX_RESEED_ON_ERROR = 0: */
    avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, rx_prbs_control_reg, (0 << 4), (1 << 4));

    /* Set TIMER1_ENABLE_HEARTBEAT, TIMER1_CLK_SEL = RX */
    avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, timer1_cntl_reg, (1 << 7 |
                        /*P1 Note: TIMER1_CLK_SEL is hard coded to cmp_clk... */
                                                  2 << 8),
                                                 (7 << 7));

    /* Load the new timer value: */

    /* TIMER_VAL_LO, TIMER_START_CNT_15_0_: */
    avago_serdes_mem_wr(aapl, addr, AVAGO_LSB, timer_val_lo_reg, timer_cnt & 0xffff);
    /* TIMER_VAL_HI, TIMER_START_CNT_29_16: */
    avago_serdes_mem_wr(aapl, addr, AVAGO_LSB, timer_val_hi_reg, (timer_cnt >> 16) & 0x3fff);

    /* Clock the timer value into the timer register: */

    /* TIMER1_CNTL, TIMER1_LOAD = 1 */
    avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, timer1_cntl_reg, (1 << 1), (1 << 1));

    /* TIMER1_CNTL, TIMER1_LOAD = 0 */
    avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, timer1_cntl_reg, (0 << 1), (1 << 1));

    /* Start the timer: */

    /* TIMER1_CNTL, TIMER1_EN = 1 */
    avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, timer1_cntl_reg, (1 << 0), (1 << 0));

    if( return_code != aapl->return_code )
        return aapl_fail(aapl,__func__,__LINE__,"SBus %s, pattern len %d + divider %d => %d clocks\n",aapl_addr_to_str(addr), pattern_length, rx_clock_divider, period);

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "SBus %s, pattern len %d + divider %d => %d clocks\n",aapl_addr_to_str(addr), pattern_length, rx_clock_divider, period);
    return 0;
}


int avago_meas_setup_data_capture(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint addr,              /**< [in] Device address number. */
    uint pattern_length,    /**< [in] Length, in bits, of repeating pattern. */
    uint ui,                /**< [in] Number of ui to capture. */
    uint window)            /**< [in] Which offset to start capture. */
{
    /* The 5 here consists of */
    /*    3 for non-existent upper values due to hardware reseed timing */
    /*   +2 to insure that we have a 4 clock (80 bit) capture window. */
    /*    capture_offset must have a minimum value of 1, and max of */
    /*    pattern_length - 3 (which would only capture for 2 clocks (40 bits)). */

    uint rx_clock_divider = avago_serdes_get_rx_register_clock(aapl,addr);
    uint min_capture_offset = 1;
    uint capture_clocks = (ui+79) / rx_clock_divider;
    uint capture_offset, start_capture;
    if (avago_serdes_get_rx_line_encoding(aapl,addr)) rx_clock_divider *= 2;

    /* Position capture window(s) in middle of range to minimize */
    /*   the time in which the CMP_USE_TIMER_FOR_RESEED must be high, */
    /*   which is what limits the pattern length where we can avoid */
    /*   inserting delays. */
    /*uint start_capture = (max_capture_offset + min_capture_offset + capture_clocks) / 2; */
    start_capture = (min_capture_offset + capture_clocks);
    if( start_capture > pattern_length - 5 )
        start_capture = pattern_length - 5;
    capture_offset = start_capture - window/rx_clock_divider;

    /* Must set capture value one greater than actual capture location: */
    capture_offset += 1;

    aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "SBus %s, Offset %u, capture %u UI starting at %u (of %u), bits/clock = %u\n",
                aapl_addr_to_str(addr), capture_offset, ui, window, pattern_length, rx_clock_divider);
    return avago_meas_setup_capture_offset(aapl, addr, capture_offset);
}

/* The heartbeat uses a count down timer, and we are loading into */
/*   almost_done_counter the value at which to stop the capture. */
/* Each count represents rx_clock_divider bits, and the max count is the */
/*   heart_beat value - 5, while the minimum is 1. */

int avago_meas_setup_capture_offset(
    Aapl_t *aapl,
    uint addr,
    int capture_offset) /* Register offset to trigger capture */
{
    int return_code = aapl->return_code;
    int timer1_almost_done_lo, timer1_almost_done_hi;
    aapl_log_printf(aapl, AVAGO_DEBUG2, __func__, __LINE__, "SBus %s, capture_offset %d\n",aapl_addr_to_str(addr),capture_offset);
    switch( aapl_get_sdrev(aapl,addr) )
    {
    case AAPL_SDREV_P1:
        timer1_almost_done_lo = 0x010d; /* TIMER1_ALMOST_DONE_LO */
        timer1_almost_done_hi = 0x010e; /* TIMER1_ALMOST_DONE_HI */
        break;
    default: /* M4, 16nm, D6 firmware: */
    case AAPL_SDREV_16:
        timer1_almost_done_lo = 0x003b; /* TIMER1_ALMOST_DONE_LO */
        timer1_almost_done_hi = 0x003c; /* TIMER1_ALMOST_DONE_HI */
        break;
    }

    /* TIMER1 ALMOST DONE LO, TIMER1_ALMOST_DONE_CNT_15_0_: */
    avago_serdes_mem_wr(aapl, addr, AVAGO_LSB, timer1_almost_done_lo, capture_offset & 0xffff);

    /* TIMER1 ALMOST DONE HI, TIMER1_ALMOST_DONE_CNT_29_16_: */
    avago_serdes_mem_wr(aapl, addr, AVAGO_LSB, timer1_almost_done_hi, (capture_offset >> 16) & 0x3fff);

    if( return_code != aapl->return_code )
        return aapl_fail(aapl,__func__,__LINE__,"SBus %s, capture_offset %d\n",aapl_addr_to_str(addr), capture_offset);
    return 0;
}

/* How does the capture work? */
/* */
/* Hardware Signals: */
/*   Heartbeat counter - See discussion at avago_meas_setup_heartbeat function. */
/* */
/*   timer = heartbeat counter */
/*   timer1_almost_done */
/*        Tracks value of (timer < almost_done_count). */

/*   cmp_use_timer1_for_reseed [CMP_USE_TIMER1_FOR_RESEED] */
/*        We toggle this high, then low via spico_int calls. */
/*   cmp_use_timer1_for_reseed_sync */
/*        Updated on next clock after cmp_use_timer1_for_reseed is changed. */

/*   rx_hearbeat_reseed_sticky */
/*        When cmp_use_timer1_for_reseed_sync */
/*              - is high, set to !timer1_almost_done */
/*              - is low, set to !timer1_almost_done & rx_hearbeat_reseed_sticky */
/*         So, when cmp_use_timer1_for_reseed_sync is low, */
/*          rx_hearbeat_reseed_sticky will stick low, and goes low with */
/*          timer1_almost_done going high. When it goes low, the data register */
/*          contains the data we want, and we disable further loads. */
/* */
/*         From model,v: */
/*           rx_hearbeat_reseed_sticky <= `C2Q global_reset_rx ? 1'b0 : */
/*                (cmp_use_timer1_for_reseed_sync */
/*                    ? ~timer1_almost_done */
/*                    : (~timer1_almost_done & rx_hearbeat_reseed_sticky)); */
/* */
/* To insure we capture valid, stable data, we must: */
/* */
/*  N = period */
/*  C = capture_offset = N - 5 - window * 4. */
/* */
/* Set 0x017[3] CMP_USE_TIMER1_FOR_RESEED high for at least N-1-window*4 clocks. */
/* Then set it low for at least window*4+1 clocks */
/* */
/* For maximum asynchronous performance, the min-time high and min-time low */
/*   should be roughly equal, which means sampling in the middle of the cycle. */

int avago_meas_capture_and_read(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                  /**< [in] Device address number. */
    int base_compare_register,  /**< [in] Cached values to avoid reading here */
    int bits_to_read,           /**< [in] Number of bits to read */
    short data[8])              /**< [out] 8 x 10 bits */
{
    int return_code = aapl->return_code;
    int i;
    int reads = (bits_to_read + 9) / 10;
    int compare_reg = (aapl_get_sdrev(aapl,addr) == AAPL_SDREV_P1) ? 0x00e1 : 0x0017;
#if 1
    /* Optimize calls for HS1; makes it 50% faster: */
    /* */
    const int enable  = base_compare_register |  (1<<3);
    const int disable = base_compare_register & ~(1<<3);

    Avago_spico_int_t ints[] =
    {
        {0x8017, 0x0000,  0, AVAGO_SPICO_INT_ALL},    /* enable */
        {0x8017, 0x0000,  0, AVAGO_SPICO_INT_ALL},    /* disable */
        {0x0018, 0x0004,  0, AVAGO_SPICO_INT_ALL},    /* select big reg */
        {0x001A, 0x0000,  0, AVAGO_SPICO_INT_ALL},    /* read */
        {0x001A, 0x0000,  0, AVAGO_SPICO_INT_ALL},    /* read */
        {0x001A, 0x0000,  0, AVAGO_SPICO_INT_ALL},    /* read */
        {0x001A, 0x0000,  0, AVAGO_SPICO_INT_ALL},    /* read */
        {0x001A, 0x0000,  0, AVAGO_SPICO_INT_ALL},    /* read */
        {0x001A, 0x0000,  0, AVAGO_SPICO_INT_ALL},    /* read */
        {0x001A, 0x0000,  0, AVAGO_SPICO_INT_ALL},    /* read */
        {0x001A, 0x0000,  0, AVAGO_SPICO_INT_ALL}     /* read */
    };

    int cmds = 3 + reads;
    ints[0].param = enable;
    ints[1].param = disable;
    ints[0].interrupt =
    ints[1].interrupt = 0x8000 | compare_reg;

    AAPL_SERDES_MEM_LOCK;
    if( avago_spico_int_array(aapl, addr, cmds, ints) < 0 )
        return -1;

    for( i = 0; i < reads; i++ )
        data[i] = ints[i+3].ret & 0x03ff;
#else
    AAPL_SERDES_MEM_LOCK;
    /* Straight-forward approach: */
    /* */

    /* Toggle high, then low: COMPARE CMP_USE_TIMER1_FOR_RESEED: */
    /*avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, compare_reg, (1 << 3), (1 << 3)); */
    /*avago_serdes_mem_rmw(aapl, addr, AVAGO_LSB, compare_reg, (0 << 3), (1 << 3)); */
    avago_serdes_mem_wr(aapl, addr, AVAGO_LSB, compare_reg, base_compare_register | (1 << 3));
    avago_serdes_mem_wr(aapl, addr, AVAGO_LSB, compare_reg, base_compare_register & ~(1 << 3));

    avago_spico_int(aapl, addr, 0x0018, 0x0004); /* Select data capture register */

    /* Read the register, 10 bits at a time: */
    for( i = 0; i < reads; i++ )
        data[i] = avago_spico_int(aapl, addr, 0x001A, 0x0000) & 0x3ff;
#endif
    AAPL_SERDES_MEM_UNLOCK;
    if( return_code != aapl->return_code )
        return aapl_fail(aapl, __func__, __LINE__, "SBus %s, bits %d, ret = %d\n",aapl_addr_to_str(addr),bits_to_read,aapl->return_code);

    aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "SBus %s, bits %d, ret = %d\n",aapl_addr_to_str(addr),bits_to_read,aapl->return_code);
    return 0;
}


/** @endcond */


/** @brief   Captures a repeating pattern from the SerDes RX */
/** @details Uses pattern capture and trigger hardware in the serdes */
/**          to capture a repeating pattern. The pattern length must */
/**          be known, and must be continously transmitted to the RX */
/**          while the function is running. */
/** @return  Returns a pointer to a binary string of the pattern. */
/**          This memory must be freed. */
char *avago_serdes_pattern_capture(
    Aapl_t *aapl,               /**< [in] Pointer to Aapl_t structure. */
    uint addr,                  /**< [in] Device address number. */
    int pattern_length)         /**< [in] Pattern length to capture */
{
    char str[40];       /* for 32 bit intermediate result */
    short *data;        /* 10 bit data from serdes */
    int *data_aligned;  /* 10 bit data realigned to 32 bit so it can be converted to binary */
    char *result = 0;   /* output returned (must be freed) */
    int result_len = 0;
    int bits;
    /* we put data into 32 bit bytes. The wasted amount is the number of bits over the pattern length, that must */
    /* be allocated into 32 bit bytes. We'll remove that at the end. */
    int wasted = 32 * (pattern_length/32 + ((pattern_length % 32) ? 1 : 0)) - pattern_length;

    Avago_serdes_rx_cmp_mode_t orig_cmp_mode;
    Avago_serdes_rx_cmp_data_t orig_cmp_data;
    Avago_serdes_rx_data_qual_t orig_data_qual;
    uint dfe_resume_status = 0;

    if (pattern_length == 0) /* search for pattern length, up to max length, shown below */
    {
        int max_length = 10000;
        int length;
        for (length = 10; length < max_length; length ++)
        {
            char *str = avago_serdes_pattern_capture(aapl, addr, length * 2);
            char *str_offset = str + length;
            int x = strncmp(str, str_offset, length);
            aapl_free(aapl, str, __func__);
            if (!x) aapl_log_printf(aapl, AVAGO_DEBUG1, __func__, __LINE__, "Found match at %d bits.\n", length);
            if (!x) break;
        }
        return avago_serdes_pattern_capture(aapl, addr, length);
    }

    /* Save DFE state and pause DFE tuning, then wait on any in progress tune: */
    if( avago_serdes_dfe_pause(aapl, addr, &dfe_resume_status) < 0 &&
        avago_serdes_dfe_wait(aapl, addr) == 0 )
    {
        aapl_fail(aapl,__func__,__LINE__,"Pattern capture coordination with running DFE failed.\n");
        return result;
    }

    orig_cmp_mode = avago_serdes_get_rx_cmp_mode(aapl, addr);
    orig_cmp_data = avago_serdes_get_rx_cmp_data(aapl, addr);
    orig_data_qual = avago_serdes_get_rx_data_qual(aapl, addr);
    avago_serdes_set_rx_test_chan_rclk(aapl, addr, FALSE);   /* Setup mission clock */

    result = (char *) aapl_malloc(aapl, pattern_length * sizeof(char) + 33, __func__);
    data = (short *) aapl_malloc(aapl, (pattern_length/10 + 8) * sizeof(short), __func__);
    data_aligned = (int *) aapl_malloc(aapl, (pattern_length/32 + 1) * sizeof(int), __func__);

    avago_meas_setup_heartbeat(aapl, addr, pattern_length, FALSE);

    memset(data, 0, (pattern_length/10 + 8) * sizeof(short));
    memset(data_aligned, 0, (pattern_length/32 + 1) * sizeof(int));

    for (bits = 0; bits<pattern_length; bits+=80) /* read 80 bits at a time */
    {
        avago_meas_setup_data_capture(aapl, addr, pattern_length, pattern_length, bits); /* which portion to capture */
        avago_meas_capture_and_read(aapl, addr, 0, 80, &data[bits/10]); /* &data is loaded 8 words at a time */

        if (aapl->debug > 2)
        {
            int bits2;
            int number_len = ceil(log(pattern_length)/log(10));

            for (bits2 = 0; bits2<80; bits2+=1) /* move it to 32 bit words */
                data_aligned[bits2/32] = data_aligned[bits2/32] | (((data[bits2/10+bits/10] >> bits2%10) & 1) << bits2%32);

            for (bits2 = 80-1; bits2>=0; bits2-=32)
                result_len += sprintf(result + result_len, "%s", aapl_hex_2_bin(str, data_aligned[bits2/32],0,32));

            aapl_log_printf(aapl, AVAGO_DEBUG3, __func__, __LINE__, "%*d - %*d %s\n", number_len, bits, number_len, bits+79, result+16);

            memset(data_aligned, 0, (pattern_length/32 + 1) * sizeof(int)); /* clear data aligned for down below */
            result_len = 0; /* clear for whole conversion down below */
        }
    }

    for (bits = 0; bits<pattern_length; bits+=1) /* move it to 32 bit words */
        data_aligned[bits/32] = data_aligned[bits/32] | (((data[bits/10] >> bits%10) & 1) << bits%32);

    for (bits = pattern_length-1; bits>=0; bits-=32)
        result_len += sprintf(result + result_len, "%s", aapl_hex_2_bin(str, data_aligned[bits/32],0,32));

    aapl_free(aapl, data, __func__);
    aapl_free(aapl, data_aligned, __func__);

    memmove(result, result + wasted, pattern_length); /* move string by wasted amount */
    result[pattern_length] = 0; /* terminate string */

    /* restore state */
    avago_serdes_set_rx_data_qual(aapl, addr, AVAGO_SERDES_RX_DATA_QUAL_UNLOCK);
    avago_serdes_set_rx_cmp_mode(aapl, addr, orig_cmp_mode);
    avago_serdes_set_rx_cmp_data(aapl, addr, orig_cmp_data);
    avago_serdes_set_rx_data_qual(aapl, addr, orig_data_qual);

    /* Restore DFE tuning to previous state: */
    avago_serdes_dfe_resume(aapl, addr, dfe_resume_status);

    return result; /* needs to be freed externally */
}

#endif /* AAPL_ENABLE_ESCOPE_MEASUREMENT */
