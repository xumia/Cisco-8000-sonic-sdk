/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* MAIN program for the hal sub-commands. */

/** Doxygen File Header */
/** @file */
/** @brief Launch wrappers for hal sub-commands. */

#define AAPL_ENABLE_INTERNAL_FUNCTIONS

#include "aapl.h"

#if AAPL_ENABLE_MAIN && AAPL_ENABLE_SERDES_HAL


static int show_hal_help()
{
    aapl_common_main_help(TRUE);

    printf(
"-ctle-limits                   Display field limits.\n"
"-rxffe-limits\n"
"-dfe-limits\n"
"\n"
"-suppress-default-print        Suppress the default printing after setting a value."
"\n"
);
    printf(
"-get-ctle                      Display firmware tables.\n"
"-get-data-channel-cal-delta\n"
"-get-data-channel-cal\n"
"-get-data-channel-inputs\n"
"-get-dfe\n"
"-get-global-tune-params\n"
"-get-gradient-inputs\n"
"-get-pam4-eye\n"
"-get-pam4-levels\n"
"-get-rxffe\n"
"-get-test-channel-cal\n"
"-get-test-channel-inputs\n"
"-get-vernier-cal\n"
"-get-vernier-delay\n"
"\n"
);
    printf(
"-get-all-tables            Display all the tables.\n"
"-get-channel-tables        Display consolidated data & test channel tables.\n"
"-get-vernier-tables        Display consolidated vernier tables.\n"
"\n"
);
    printf(
"-get-rx-clocks\n"
"-rx-clocks.data [PD|iclk|qclk|rclk]     Set clock source.\n"
"-rx-clocks.edge [PD|iclk|qclk|rclk]\n"
"-rx-clocks.test [PD|iclk|qclk|rclk]\n"
"-rx-clocks.dfe  [PD|iclk|qclk|rclk]\n"
"-rx-clocks.cdc  [DATA|EDGE|~DATA|~EDGE]\n"
"\n"
);


    printf(
"-ctle.<field>                   <num>  Set <field> to <num>.\n"
"-data-channel-cal-delta.<field> <num>\n"
"-data-channel-cal.<field>       <num>  For a list of <field> names for a table,\n"
"-data-channel-inputs.<field>    <num>  display the table.  To see all fields,\n"
"-dfe.<field>                    <num>  run with -get-all-tables.\n"
"-global-tune-params.<field>     <num>\n"
"-gradient-inputs.<field>        <num>\n"
);
    printf(
"-pam4-eye.<field>               <num>\n"
"-pam4-levels.<field>            <num>\n"
"-rxffe.<field>                  <num>\n"
"-test-channel-cal.<field>       <num>\n"
"-test-channel-inputs.<field>    <num>\n"
"-vernier-cal.<field>            <num>\n"
"-vernier-delay.<field>          <num>\n"
);

    return 1;
}

static void print_values(const char *str, int min, int max)
{
    printf("  %s: [%d-%d]", str, min, max);
}

#define FIELD_INDEX(st,field) (&st->field - (short *)(st))
#define AAPL_CONCAT(a,b) a ## b
#define AAPL_CONCAT3(a,b,c) a ## b ## c
#define SET_VALUE_MASK(st, field) st.field = aapl_num_from_str(optarg,name,0); AAPL_CONCAT(st,_mask) |= (1 << FIELD_INDEX((&st),field))
#define SET_VALUE_MASK_PLUS(st, field, delta) st.field = aapl_num_from_str(optarg,name,0) + delta; AAPL_CONCAT(st,_mask) |= (1 << FIELD_INDEX((&st),field))
#define DECLARE(name) AAPL_CONCAT3(Avago_serdes_,name,_t) name; uint AAPL_CONCAT(name,_mask) = 0; BOOL AAPL_CONCAT(get_,name) = FALSE
#define ZERO(var) memset(&var,0,sizeof(var))

static int vernier_decode(int reg)
{
    /* bit 0 has weight 1 */
    /* bit 1 has weight 2 */
    /* bit 2 has weight 4 */
    /* bit 3 has weight 4 */
    /* bit 4 has weight 4 */
    /* bit 5 has weight 4 */
    return (reg&7) + ((reg>>1)&4) + ((reg>>2)&4) + ((reg>>3)&4);
}

/* Main program for read/write HAL parameters using Interrupt 0x2C. */
/* pre-existing process/thread.  Exits with 0 for success or 1 for error. */
int aapl_hal_main(int argc, char ** argv, Aapl_t *aapl)
{
/* Parse options: */
    int rc, index = 0;
    Avago_addr_t addr_struct;
    Avago_addr_t start, stop, next;
    BOOL st;

/* These typedefs are so that the DECLARE macro will work: */
typedef Avago_serdes_data_channel_inputs_t Avago_serdes_data_channel_cal_t;
typedef Avago_serdes_data_channel_inputs_t Avago_serdes_data_channel_cal_delta_t;
typedef Avago_serdes_test_channel_inputs_t Avago_serdes_test_channel_cal_t;

    DECLARE(ctle);
    DECLARE(rxffe);
    DECLARE(dfe);
    DECLARE(vernier_cal);
    DECLARE(vernier_delay);
    DECLARE(rx_clocks);
    DECLARE(global_tune_params);
    DECLARE(gradient_inputs);
    DECLARE(data_channel_inputs);
    DECLARE(data_channel_cal);
    DECLARE(data_channel_cal_delta);
    DECLARE(pam4_levels);
    DECLARE(pam4_eye);
    DECLARE(test_channel_inputs);
    DECLARE(test_channel_cal);

    BOOL get_ctle_limits = FALSE;
    BOOL get_rxffe_limits = FALSE;
    BOOL get_dfe_limits = FALSE;
    BOOL get_all_tables = FALSE;
    BOOL get_vernier_tables = FALSE;
    BOOL get_channel_tables = FALSE;
    BOOL have_user_option = FALSE;

    BOOL enable_default_print = TRUE;

    struct option options[] =
    {
        AAPL_COMMON_MAIN_OPTIONS,
        {"ctle-limits",  0, NULL, 1 },
        {"rxffe-limits", 0, NULL, 2 },
        {"dfe-limits",   0, NULL, 3 },

        {"suppress-default-print", 0, NULL,  50 },

        {"get-ctle"             , 0, NULL,  80 },
        {"ctle.hf"              , 1, NULL,  81 },
        {"ctle.lf"              , 1, NULL,  82 },
        {"ctle.dc"              , 1, NULL,  83 },
        {"ctle.bw"              , 1, NULL,  84 },
        {"ctle.gainshape1"      , 1, NULL,  85 },
        {"ctle.gainshape2"      , 1, NULL,  86 },
        {"ctle.short_channel_en", 1, NULL,  87 },
        {"ctle.hf_min"          , 1, NULL,  88 },
        {"ctle.hf_max"          , 1, NULL,  89 },
        {"ctle.lf_min"          , 1, NULL,  90 },
        {"ctle.lf_max"          , 1, NULL,  91 },

        {"get-rxffe"             , 0, NULL, 100 },
        {"rxffe.pre2"            , 1, NULL, 101 },
        {"rxffe.pre1"            , 1, NULL, 102 },
        {"rxffe.post1"           , 1, NULL, 103 },
        {"rxffe.bflf"            , 1, NULL, 104 },
        {"rxffe.bfhf"            , 1, NULL, 105 },
        {"rxffe.datarate"        , 1, NULL, 106 },
        {"rxffe.short_channel_en", 1, NULL, 107 },
        {"rxffe.pre1_min"        , 1, NULL, 108 },
        {"rxffe.pre1_max"        , 1, NULL, 109 },
        {"rxffe.pre2_min"        , 1, NULL, 110 },
        {"rxffe.pre2_max"        , 1, NULL, 111 },
        {"rxffe.bflf_ical"       , 1, NULL, 112 },
        {"rxffe.post1_min"       , 1, NULL, 113 },
        {"rxffe.post1_max"       , 1, NULL, 114 },

        {"get-dfe"     , 0, NULL, 120 },
        {"dfe.gaintap" , 1, NULL, 121 },
        {"dfe.gaintap2", 1, NULL, 122 },
        {"dfe.gain2"   , 1, NULL, 123 },
        {"dfe.gain3"   , 1, NULL, 124 },
        {"dfe.gain4"   , 1, NULL, 125 },
        {"dfe.gain5"   , 1, NULL, 126 },
        {"dfe.gain6"   , 1, NULL, 127 },
        {"dfe.gain7"   , 1, NULL, 128 },
        {"dfe.gain8"   , 1, NULL, 129 },
        {"dfe.gain9"   , 1, NULL, 130 },
        {"dfe.gain10"  , 1, NULL, 131 },
        {"dfe.gain11"  , 1, NULL, 132 },
        {"dfe.gain12"  , 1, NULL, 133 },
        {"dfe.gain13"  , 1, NULL, 134 },

        {"dfe.o_gain2" , 1, NULL, 423 },
        {"dfe.o_gain3" , 1, NULL, 424 },
        {"dfe.o_gain4" , 1, NULL, 425 },
        {"dfe.o_gain5" , 1, NULL, 426 },
        {"dfe.o_gain6" , 1, NULL, 427 },
        {"dfe.o_gain7" , 1, NULL, 428 },
        {"dfe.o_gain8" , 1, NULL, 429 },
        {"dfe.o_gain9" , 1, NULL, 430 },
        {"dfe.o_gain10", 1, NULL, 431 },
        {"dfe.o_gain11", 1, NULL, 432 },
        {"dfe.o_gain12", 1, NULL, 433 },
        {"dfe.o_gain13", 1, NULL, 434 },

        {"get-vernier-delay"            , 0, NULL, 140 },
        {"vernier-delay.upper_odd_dly"  , 1, NULL, 141 },
        {"vernier-delay.upper_even_dly" , 1, NULL, 142 },
        {"vernier-delay.middle_odd_dly" , 1, NULL, 143 },
        {"vernier-delay.middle_even_dly", 1, NULL, 144 },
        {"vernier-delay.lower_odd_dly"  , 1, NULL, 145 },
        {"vernier-delay.lower_even_dly" , 1, NULL, 146 },
        {"vernier-delay.test_odd_dly"   , 1, NULL, 147 },
        {"vernier-delay.test_even_dly"  , 1, NULL, 148 },
        {"vernier-delay.edge_odd_dly"   , 1, NULL, 149 },
        {"vernier-delay.edge_even_dly"  , 1, NULL, 150 },
        {"vernier-delay.tap_dly"        , 1, NULL, 151 },

        {"vernier-delay.prev0_even"     , 1, NULL, 141 },
        {"vernier-delay.prev1_even"     , 1, NULL, 142 },
        {"vernier-delay.test_even"      , 1, NULL, 143 },
        {"vernier-delay.tap_even"       , 1, NULL, 144 },
        {"vernier-delay.edge_even"      , 1, NULL, 145 },
        {"vernier-delay.cdc_even"       , 1, NULL, 146 },
        {"vernier-delay.prev0_odd"      , 1, NULL, 147 },
        {"vernier-delay.prev1_odd"      , 1, NULL, 148 },
        {"vernier-delay.test_odd"       , 1, NULL, 149 },
        {"vernier-delay.tap_odd"        , 1, NULL, 150 },
        {"vernier-delay.edge_odd"       , 1, NULL, 151 },
        {"vernier-delay.cdc_odd"        , 1, NULL, 152 },

        {"get-rx-clocks",  0, NULL, 160 },
        {"rx-clocks.data", 1, NULL, 161 },
        {"rx-clocks.edge", 1, NULL, 162 },
        {"rx-clocks.test", 1, NULL, 163 },
        {"rx-clocks.dfe",  1, NULL, 164 },
        {"rx-clocks.cdc",  1, NULL, 165 },

        {"get-global-tune-params"                      , 0, NULL, 180 },
        {"global-tune-params.error_threshold"          , 1, NULL, 181 },
        {"global-tune-params.nrz_ctle_dwell_1ex"       , 1, NULL, 182 },
        {"global-tune-params.nrz_ctle_lf_dwell_shift"  , 1, NULL, 183 },
        {"global-tune-params.eye_oversample"           , 1, NULL, 184 },
        {"global-tune-params.pam4_ctle_dwell_1ex"      , 1, NULL, 185 },
        {"global-tune-params.pam4_dvos_dwell_1ex"      , 1, NULL, 186 },
        {"global-tune-params.pam4_dvos_pcal_dwell_1ex" , 1, NULL, 187 },
        {"global-tune-params.lms_dwell_1ex"            , 1, NULL, 188 },
        {"global-tune-params.ctle_fixed"               , 1, NULL, 189 },
        {"global-tune-params.rxffe_fixed"              , 1, NULL, 190 },
        {"global-tune-params.dfe_fixed"                , 1, NULL, 191 },
        {"global-tune-params.gaintap_max_min"          , 1, NULL, 192 },
        {"global-tune-params.gaintap2_max_min"         , 1, NULL, 193 },
        {"global-tune-params.pCal_loops"               , 1, NULL, 194 },
        {"global-tune-params.disable_one_shot_pcal"    , 1, NULL, 195 },
        {"global-tune-params.lms_pcal_dwell_1ex"       , 1, NULL, 196 },
        {"global-tune-params.dcr_pcal_dwell_1ex"       , 1, NULL, 197 },
        {"global-tune-params.pCal_delay"               , 1, NULL, 198 },
        {"global-tune-params.iq_cal_interleave_disable", 1, NULL, 199 },
        {"global-tune-params.ctle_lfhf_max_min"        , 1, NULL, 200 },
        {"global-tune-params.ctle_dc_max_min"          , 1, NULL, 201 },
        {"global-tune-params.vernier_fixed"            , 1, NULL, 202 },
        {"global-tune-params.prbs_tune_mode"           , 1, NULL, 203 },
        {"global-tune-params.gradient_options"         , 1, NULL, 204 },
        {"global-tune-params.ical_effort"              , 1, NULL, 205 },
        {"global-tune-params.use_rx_clock_cal_values"  , 1, NULL, 206 },
        {"global-tune-params.latch_fail"               , 1, NULL, 207 },
        {"global-tune-params.delta_cal_fail"           , 1, NULL, 208 },

        {"get-gradient-inputs"                            , 0, NULL, 210 },
        {"gradient-inputs.dwell_shift_ical"               , 1, NULL, 211 },
        {"gradient-inputs.agc_target_low"                 , 1, NULL, 212 },
        {"gradient-inputs.agc_target_high"                , 1, NULL, 213 },
        {"gradient-inputs.tune_level"                     , 1, NULL, 214 },
        {"gradient-inputs.dwell_shift_pcal"               , 1, NULL, 215 },
        {"gradient-inputs.pcal_hysteresis_pre1_pos"       , 1, NULL, 216 },
        {"gradient-inputs.pcal_hysteresis_pre1_neg"       , 1, NULL, 217 },
        {"gradient-inputs.pcal_hysteresis_post1_pos"      , 1, NULL, 218 },
        {"gradient-inputs.pcal_hysteresis_post1_neg"      , 1, NULL, 219 },
        {"gradient-inputs.pcal_hysteresis_67_pre1"        , 1, NULL, 220 },
        {"gradient-inputs.pcal_hysteresis_78_post1"       , 1, NULL, 221 },
        {"gradient-inputs.pcal_level3_threshold"          , 1, NULL, 222 },
        {"gradient-inputs.pcal_threshold_offset_post1_pos", 1, NULL, 223 },
        {"gradient-inputs.pcal_threshold_offset_post1_neg", 1, NULL, 224 },
        {"gradient-inputs.pcal_hysteresis_pre2_pos"       , 1, NULL, 225 },
        {"gradient-inputs.pcal_hysteresis_pre2_neg"       , 1, NULL, 226 },

        {"get-vernier-tables"         , 0, NULL, 227 },
        {"get-all-tables"             , 0, NULL, 228 },
        {"get-channel-tables"         , 0, NULL, 229 },
        {"get-data-channel-tables"    , 0, NULL, 229 }, /* Deprecated */
        {"get-data-channel-inputs"    , 0, NULL, 230 },
        {"data-channel-inputs.vos_d0e", 1, NULL, 231 },
        {"data-channel-inputs.vos_d0o", 1, NULL, 232 },
        {"data-channel-inputs.vos_d1e", 1, NULL, 233 },
        {"data-channel-inputs.vos_d1o", 1, NULL, 234 },
        {"data-channel-inputs.lower_e", 1, NULL, 235 },
        {"data-channel-inputs.lower_o", 1, NULL, 236 },
        {"data-channel-inputs.mid_e"  , 1, NULL, 237 },
        {"data-channel-inputs.mid_o"  , 1, NULL, 238 },
        {"data-channel-inputs.upper_e", 1, NULL, 239 },
        {"data-channel-inputs.upper_o", 1, NULL, 240 },

        {"get-data-channel-cal",     0, NULL, 245 },
        {"data-channel-cal.vos_d0e", 1, NULL, 246 },
        {"data-channel-cal.vos_d0o", 1, NULL, 247 },
        {"data-channel-cal.vos_d1e", 1, NULL, 248 },
        {"data-channel-cal.vos_d1o", 1, NULL, 249 },
        {"data-channel-cal.lower_e", 1, NULL, 250 },
        {"data-channel-cal.lower_o", 1, NULL, 251 },
        {"data-channel-cal.mid_e"  , 1, NULL, 252 },
        {"data-channel-cal.mid_o"  , 1, NULL, 253 },
        {"data-channel-cal.upper_e", 1, NULL, 254 },
        {"data-channel-cal.upper_o", 1, NULL, 255 },

        {"get-data-channel-cal-delta",     0, NULL, 260 },
        {"data-channel-cal-delta.lower_e", 1, NULL, 261 },
        {"data-channel-cal-delta.lower_o", 1, NULL, 262 },
        {"data-channel-cal-delta.mid_e"  , 1, NULL, 263 },
        {"data-channel-cal-delta.mid_o"  , 1, NULL, 264 },
        {"data-channel-cal-delta.upper_e", 1, NULL, 265 },
        {"data-channel-cal-delta.upper_o", 1, NULL, 266 },

        {"get-pam4-levels",         0, NULL, 280 },
        {"pam4-levels.level_x0x_e", 1, NULL, 281 },
        {"pam4-levels.level_x0x_o", 1, NULL, 282 },
        {"pam4-levels.level_x1x_e", 1, NULL, 283 },
        {"pam4-levels.level_x1x_o", 1, NULL, 284 },
        {"pam4-levels.level_x2x_e", 1, NULL, 285 },
        {"pam4-levels.level_x2x_o", 1, NULL, 286 },
        {"pam4-levels.level_x3x_e", 1, NULL, 287 },
        {"pam4-levels.level_x3x_o", 1, NULL, 288 },

        {"get-pam4-eye",           0, NULL, 300 },
        {"pam4-eye.height_even_l", 1, NULL, 301 },
        {"pam4-eye.height_even_m", 1, NULL, 302 },
        {"pam4-eye.height_even_u", 1, NULL, 303 },
        {"pam4-eye.height_odd_l" , 1, NULL, 304 },
        {"pam4-eye.height_odd_m" , 1, NULL, 305 },
        {"pam4-eye.height_odd_u" , 1, NULL, 306 },
        {"pam4-eye.start_even_l" , 1, NULL, 307 },
        {"pam4-eye.start_even_m" , 1, NULL, 308 },
        {"pam4-eye.start_even_u" , 1, NULL, 309 },
        {"pam4-eye.start_odd_l"  , 1, NULL, 310 },
        {"pam4-eye.start_odd_m"  , 1, NULL, 311 },
        {"pam4-eye.start_odd_u"  , 1, NULL, 312 },

        {"get-vernier-cal"            , 0, NULL, 320 },
        {"vernier-cal.upper_odd_cal"  , 1, NULL, 321 },
        {"vernier-cal.upper_even_cal" , 1, NULL, 322 },
        {"vernier-cal.middle_odd_cal" , 1, NULL, 323 },
        {"vernier-cal.middle_even_cal", 1, NULL, 324 },
        {"vernier-cal.lower_odd_cal"  , 1, NULL, 325 },
        {"vernier-cal.lower_even_cal" , 1, NULL, 326 },

        {"get-test-channel-cal"    , 0, NULL, 330 },
        {"test-channel-cal.test_e" , 1, NULL, 331 },
        {"test-channel-cal.test_o" , 1, NULL, 332 },
        {"test-channel-cal.edge_e" , 1, NULL, 333 },
        {"test-channel-cal.edge_o" , 1, NULL, 334 },

        {"get-test-channel-inputs"    , 0, NULL, 340 },
        {"test-channel-inputs.test_e" , 1, NULL, 341 },
        {"test-channel-inputs.test_o" , 1, NULL, 342 },
        {"test-channel-inputs.edge_e" , 1, NULL, 343 },
        {"test-channel-inputs.edge_o" , 1, NULL, 344 },

        {0,                                 0, NULL, 0 }
    };

    avago_addr_to_struct(aapl_default_device_addr, &addr_struct);
    if( aapl_common_main_options(aapl, argc, argv, &addr_struct) < 0 )
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_hal_help();
    }

    if( aapl->return_code < 0 ) return 1;  /* EXIT, assume anomalies already reported. */

    ZERO(ctle);
    ZERO(rxffe);
    ZERO(dfe);
    ZERO(vernier_cal);
    ZERO(vernier_delay);
    ZERO(rx_clocks);
    ZERO(global_tune_params);
    ZERO(gradient_inputs);
    ZERO(data_channel_inputs);
    ZERO(data_channel_cal);
    ZERO(data_channel_cal_delta);
    ZERO(pam4_levels);
    ZERO(pam4_eye);
    ZERO(test_channel_inputs);
    ZERO(test_channel_cal);

    while( (rc = getopt_long_only(argc, argv, "", options, &index)) >= 0 )
    {
        const char *name = options[index].name;
        have_user_option = TRUE;
        switch (rc)
        {
        case 1: get_ctle_limits       = TRUE; break;
        case 2: get_rxffe_limits      = TRUE; break;
        case 3: get_dfe_limits        = TRUE; break;

        case 50: enable_default_print = FALSE; break;

        case  80: get_ctle = TRUE; break;
        case  81: SET_VALUE_MASK(ctle, hf              ); break;
        case  82: SET_VALUE_MASK(ctle, lf              ); break;
        case  83: SET_VALUE_MASK(ctle, dc              ); break;
        case  84: SET_VALUE_MASK(ctle, bw              ); break;
        case  85: SET_VALUE_MASK(ctle, gainshape1      ); break;
        case  86: SET_VALUE_MASK(ctle, gainshape2      ); break;
        case  87: SET_VALUE_MASK(ctle, short_channel_en); break;
        case  88: SET_VALUE_MASK(ctle, hf_min          ); break;
        case  89: SET_VALUE_MASK(ctle, hf_max          ); break;
        case  90: SET_VALUE_MASK(ctle, lf_min          ); break;
        case  91: SET_VALUE_MASK(ctle, lf_max          ); break;

        case 100: get_rxffe = TRUE; break;
        case 101: SET_VALUE_MASK(rxffe, pre2            ); break;
        case 102: SET_VALUE_MASK(rxffe, pre1            ); break;
        case 103: SET_VALUE_MASK(rxffe, post1           ); break;
        case 104: SET_VALUE_MASK(rxffe, bflf            ); break;
        case 105: SET_VALUE_MASK(rxffe, bfhf            ); break;
        case 106: SET_VALUE_MASK(rxffe, datarate        ); break;
        case 107: SET_VALUE_MASK(rxffe, short_channel_en); break;
        case 108: SET_VALUE_MASK(rxffe, pre1_min        ); break;
        case 109: SET_VALUE_MASK(rxffe, pre1_max        ); break;
        case 110: SET_VALUE_MASK(rxffe, pre2_min        ); break;
        case 111: SET_VALUE_MASK(rxffe, pre2_max        ); break;
        case 112: SET_VALUE_MASK(rxffe, bflf_ical       ); break;
        case 113: SET_VALUE_MASK(rxffe, post1_min       ); break;
        case 114: SET_VALUE_MASK(rxffe, post1_max       ); break;

        case 120: get_dfe = TRUE; break;
        case 121: SET_VALUE_MASK(dfe, gaintap ); break;
        case 122: SET_VALUE_MASK(dfe, gaintap2); break;
        case 123: SET_VALUE_MASK(dfe, gain2   ); break;
        case 124: SET_VALUE_MASK(dfe, gain3   ); break;
        case 125: SET_VALUE_MASK(dfe, gain4   ); break;
        case 126: SET_VALUE_MASK(dfe, gain5   ); break;
        case 127: SET_VALUE_MASK(dfe, gain6   ); break;
        case 128: SET_VALUE_MASK(dfe, gain7   ); break;
        case 129: SET_VALUE_MASK(dfe, gain8   ); break;
        case 130: SET_VALUE_MASK(dfe, gain9   ); break;
        case 131: SET_VALUE_MASK(dfe, gain10  ); break;
        case 132: SET_VALUE_MASK(dfe, gain11  ); break;
        case 133: SET_VALUE_MASK(dfe, gain12  ); break;
        case 134: SET_VALUE_MASK(dfe, gain13  ); break;
        case 423: SET_VALUE_MASK(dfe, o_gain2 ); break;
        case 424: SET_VALUE_MASK(dfe, o_gain3 ); break;
        case 425: SET_VALUE_MASK(dfe, o_gain4 ); break;
        case 426: SET_VALUE_MASK(dfe, o_gain5 ); break;
        case 427: SET_VALUE_MASK(dfe, o_gain6 ); break;
        case 428: SET_VALUE_MASK(dfe, o_gain7 ); break;
        case 429: SET_VALUE_MASK(dfe, o_gain8 ); break;
        case 430: SET_VALUE_MASK(dfe, o_gain9 ); break;
        case 431: SET_VALUE_MASK(dfe, o_gain10); break;
        case 432: SET_VALUE_MASK(dfe, o_gain11); break;
        case 433: SET_VALUE_MASK(dfe, o_gain12); break;
        case 434: SET_VALUE_MASK(dfe, o_gain13); break;

        case 140: get_vernier_delay = TRUE; break;
        case 141: SET_VALUE_MASK(vernier_delay, upper_odd_dly  ); break;
        case 142: SET_VALUE_MASK(vernier_delay, upper_even_dly ); break;
        case 143: SET_VALUE_MASK(vernier_delay, middle_odd_dly ); break;
        case 144: SET_VALUE_MASK(vernier_delay, middle_even_dly); break;
        case 145: SET_VALUE_MASK(vernier_delay, lower_odd_dly  ); break;
        case 146: SET_VALUE_MASK(vernier_delay, lower_even_dly ); break;
        case 147: SET_VALUE_MASK(vernier_delay, test_odd_dly   ); break;
        case 148: SET_VALUE_MASK(vernier_delay, test_even_dly  ); break;
        case 149: SET_VALUE_MASK(vernier_delay, edge_odd_dly   ); break;
        case 150: SET_VALUE_MASK(vernier_delay, edge_even_dly  ); break;
        case 151: SET_VALUE_MASK(vernier_delay, tap_dly        ); break;
        case 152: SET_VALUE_MASK(vernier_delay, padding        ); break;

        case 160: get_rx_clocks = TRUE; break;
        case 161: rx_clocks.data = aapl_rx_clock_from_str(optarg, name); rx_clocks_mask |= 0x01; get_rx_clocks = TRUE; break;
        case 162: rx_clocks.edge = aapl_rx_clock_from_str(optarg, name); rx_clocks_mask |= 0x02; get_rx_clocks = TRUE; break;
        case 163: rx_clocks.test = aapl_rx_clock_from_str(optarg, name); rx_clocks_mask |= 0x04; get_rx_clocks = TRUE; break;
        case 164: rx_clocks.dfe  = aapl_rx_clock_from_str(optarg, name); rx_clocks_mask |= 0x08; get_rx_clocks = TRUE; break;
        case 165: rx_clocks.cdc  = aapl_rx_clock_cdc_from_str(optarg,name); rx_clocks_mask |= 0x10; get_rx_clocks = TRUE; break;

        case 180: get_global_tune_params = TRUE; break;
        case 181: SET_VALUE_MASK(global_tune_params, error_threshold          ); break;
        case 182: SET_VALUE_MASK(global_tune_params, nrz_ctle_dwell_1ex       ); break;
        case 183: SET_VALUE_MASK(global_tune_params, nrz_ctle_lf_dwell_shift  ); break;
        case 184: SET_VALUE_MASK(global_tune_params, eye_oversample           ); break;
        case 185: SET_VALUE_MASK(global_tune_params, pam4_ctle_dwell_1ex      ); break;
        case 186: SET_VALUE_MASK(global_tune_params, pam4_dvos_dwell_1ex      ); break;
        case 187: SET_VALUE_MASK(global_tune_params, pam4_dvos_pcal_dwell_1ex ); break;
        case 188: SET_VALUE_MASK(global_tune_params, lms_dwell_1ex            ); break;
        case 189: SET_VALUE_MASK(global_tune_params, ctle_fixed               ); break;
        case 190: SET_VALUE_MASK(global_tune_params, rxffe_fixed              ); break;
        case 191: SET_VALUE_MASK(global_tune_params, dfe_fixed                ); break;
        case 192: SET_VALUE_MASK(global_tune_params, gaintap_max_min          ); break;
        case 193: SET_VALUE_MASK(global_tune_params, gaintap2_max_min         ); break;
        case 194: SET_VALUE_MASK(global_tune_params, pCal_loops               ); break;
        case 195: SET_VALUE_MASK(global_tune_params, disable_one_shot_pcal    ); break;
        case 196: SET_VALUE_MASK(global_tune_params, lms_pcal_dwell_1ex       ); break;
        case 197: SET_VALUE_MASK(global_tune_params, dcr_pcal_dwell_1ex       ); break;
        case 198: SET_VALUE_MASK(global_tune_params, pCal_delay               ); break;
        case 199: SET_VALUE_MASK(global_tune_params, iq_cal_interleave_disable); break;
        case 200: SET_VALUE_MASK(global_tune_params, ctle_lfhf_max_min        ); break;
        case 201: SET_VALUE_MASK(global_tune_params, ctle_dc_max_min          ); break;
        case 202: SET_VALUE_MASK(global_tune_params, vernier_fixed            ); break;
        case 203: SET_VALUE_MASK(global_tune_params, prbs_tune_mode           ); break;
        case 204: SET_VALUE_MASK(global_tune_params, gradient_options         ); break;
        case 205: SET_VALUE_MASK(global_tune_params, ical_effort              ); break;
        case 206: SET_VALUE_MASK(global_tune_params, use_rx_clock_cal_values  ); break;
        case 207: SET_VALUE_MASK(global_tune_params, latch_fail               ); break;
        case 208: SET_VALUE_MASK(global_tune_params, delta_cal_fail           ); break;

        case 210: get_gradient_inputs = TRUE; break;
        case 211: SET_VALUE_MASK(gradient_inputs, dwell_shift_ical        ); break;
        case 212: SET_VALUE_MASK(gradient_inputs, agc_target_low          ); break;
        case 213: SET_VALUE_MASK(gradient_inputs, agc_target_high         ); break;
        case 214: SET_VALUE_MASK(gradient_inputs, tune_level              ); break;
        case 215: SET_VALUE_MASK(gradient_inputs, dwell_shift_pcal        ); break;
        case 216: SET_VALUE_MASK(gradient_inputs, pcal_hysteresis_pre1_pos       ); break;
        case 217: SET_VALUE_MASK(gradient_inputs, pcal_hysteresis_pre1_neg       ); break;
        case 218: SET_VALUE_MASK(gradient_inputs, pcal_hysteresis_post1_pos      ); break;
        case 219: SET_VALUE_MASK(gradient_inputs, pcal_hysteresis_post1_neg      ); break;
        case 220: SET_VALUE_MASK(gradient_inputs, pcal_hysteresis_67_pre1        ); break;
        case 221: SET_VALUE_MASK(gradient_inputs, pcal_hysteresis_78_post1       ); break;
        case 222: SET_VALUE_MASK(gradient_inputs, pcal_level3_threshold          ); break;
        case 223: SET_VALUE_MASK(gradient_inputs, pcal_threshold_offset_post1_pos); break;
        case 224: SET_VALUE_MASK(gradient_inputs, pcal_threshold_offset_post1_neg); break;
        case 225: SET_VALUE_MASK(gradient_inputs, pcal_hysteresis_pre2_pos       ); break;
        case 226: SET_VALUE_MASK(gradient_inputs, pcal_hysteresis_pre2_neg       ); break;

        case 227: get_vernier_tables         = TRUE; break;
        case 228: get_all_tables             = TRUE; break;
        case 229: get_channel_tables         = TRUE; break;
        case 230: get_data_channel_inputs    = TRUE; break;
        case 231: SET_VALUE_MASK_PLUS(data_channel_inputs, lower_e, 256); break; /* NOTE: these 4 are aliases for vos_d0e, vos_d0o, etc. */
        case 232: SET_VALUE_MASK_PLUS(data_channel_inputs, lower_o, 256); break;
        case 233: SET_VALUE_MASK_PLUS(data_channel_inputs, mid_e  , 256); break;
        case 234: SET_VALUE_MASK_PLUS(data_channel_inputs, mid_o  , 256); break;
        case 235: SET_VALUE_MASK(data_channel_inputs, lower_e); break;
        case 236: SET_VALUE_MASK(data_channel_inputs, lower_o); break;
        case 237: SET_VALUE_MASK(data_channel_inputs, mid_e  ); break;
        case 238: SET_VALUE_MASK(data_channel_inputs, mid_o  ); break;
        case 239: SET_VALUE_MASK(data_channel_inputs, upper_e); break;
        case 240: SET_VALUE_MASK(data_channel_inputs, upper_o); break;

        case 245: get_data_channel_cal       = TRUE; break;
        case 246: SET_VALUE_MASK_PLUS(data_channel_cal, lower_e, 256); break; /* NOTE: these 4 are aliases for vos_d0e, vos_d0o, etc. */
        case 247: SET_VALUE_MASK_PLUS(data_channel_cal, lower_o, 256); break;
        case 248: SET_VALUE_MASK_PLUS(data_channel_cal, mid_e  , 256); break;
        case 249: SET_VALUE_MASK_PLUS(data_channel_cal, mid_o  , 256); break;
        case 250: SET_VALUE_MASK(data_channel_cal, lower_e); break;
        case 251: SET_VALUE_MASK(data_channel_cal, lower_o); break;
        case 252: SET_VALUE_MASK(data_channel_cal, mid_e  ); break;
        case 253: SET_VALUE_MASK(data_channel_cal, mid_o  ); break;
        case 254: SET_VALUE_MASK(data_channel_cal, upper_e); break;
        case 255: SET_VALUE_MASK(data_channel_cal, upper_o); break;

        case 260: get_data_channel_cal_delta = TRUE; break;
        case 261: SET_VALUE_MASK(data_channel_cal_delta, lower_e); break;
        case 262: SET_VALUE_MASK(data_channel_cal_delta, lower_o); break;
        case 263: SET_VALUE_MASK(data_channel_cal_delta, mid_e  ); break;
        case 264: SET_VALUE_MASK(data_channel_cal_delta, mid_o  ); break;
        case 265: SET_VALUE_MASK(data_channel_cal_delta, upper_e); break;
        case 266: SET_VALUE_MASK(data_channel_cal_delta, upper_o); break;

        case 280: get_pam4_levels = TRUE; break;
        case 281: SET_VALUE_MASK(pam4_levels, level_x0x_e); break;
        case 282: SET_VALUE_MASK(pam4_levels, level_x0x_o); break;
        case 283: SET_VALUE_MASK(pam4_levels, level_x1x_e); break;
        case 284: SET_VALUE_MASK(pam4_levels, level_x1x_o); break;
        case 285: SET_VALUE_MASK(pam4_levels, level_x2x_e); break;
        case 286: SET_VALUE_MASK(pam4_levels, level_x2x_o); break;
        case 287: SET_VALUE_MASK(pam4_levels, level_x3x_e); break;
        case 288: SET_VALUE_MASK(pam4_levels, level_x3x_o); break;

        case 300: get_pam4_eye = TRUE; break;
        case 301: SET_VALUE_MASK(pam4_eye, height_even_l ); break;
        case 302: SET_VALUE_MASK(pam4_eye, height_even_m ); break;
        case 303: SET_VALUE_MASK(pam4_eye, height_even_u ); break;
        case 304: SET_VALUE_MASK(pam4_eye, height_odd_l  ); break;
        case 305: SET_VALUE_MASK(pam4_eye, height_odd_m  ); break;
        case 306: SET_VALUE_MASK(pam4_eye, height_odd_u  ); break;
        case 307: SET_VALUE_MASK(pam4_eye, start_even_l  ); break;
        case 308: SET_VALUE_MASK(pam4_eye, start_even_m  ); break;
        case 309: SET_VALUE_MASK(pam4_eye, start_even_u  ); break;
        case 310: SET_VALUE_MASK(pam4_eye, start_odd_l   ); break;
        case 311: SET_VALUE_MASK(pam4_eye, start_odd_m   ); break;
        case 312: SET_VALUE_MASK(pam4_eye, start_odd_u   ); break;

        case 320: get_vernier_cal = TRUE; break;
        case 321: SET_VALUE_MASK(vernier_cal, upper_odd_cal  ); break;
        case 322: SET_VALUE_MASK(vernier_cal, upper_even_cal ); break;
        case 323: SET_VALUE_MASK(vernier_cal, middle_odd_cal ); break;
        case 324: SET_VALUE_MASK(vernier_cal, middle_even_cal); break;
        case 325: SET_VALUE_MASK(vernier_cal, lower_odd_cal  ); break;
        case 326: SET_VALUE_MASK(vernier_cal, lower_even_cal ); break;

        case 330: get_test_channel_cal = TRUE; break;
        case 331: SET_VALUE_MASK(test_channel_cal, test_e  ); break;
        case 332: SET_VALUE_MASK(test_channel_cal, test_o ); break;
        case 333: SET_VALUE_MASK(test_channel_cal, edge_e ); break;
        case 334: SET_VALUE_MASK(test_channel_cal, edge_o); break;

        case 340: get_test_channel_inputs = TRUE; break;
        case 341: SET_VALUE_MASK(test_channel_inputs, test_e  ); break;
        case 342: SET_VALUE_MASK(test_channel_inputs, test_o ); break;
        case 343: SET_VALUE_MASK(test_channel_inputs, edge_e ); break;
        case 344: SET_VALUE_MASK(test_channel_inputs, edge_o); break;

        default : if( (rc & 0xf000) != 0xf000 )
                     aapl_main_error("Run with -h for a usage summary.");
                 break;
        }
    }

    /* No args are allowed beyond options: */
    if( optind < argc )
    {
        aapl_exit_on_unexpected_arg(argv[optind]);
        avago_addr_delete(aapl, &addr_struct);
        return show_hal_help();
    }

    if( !have_user_option )
    {
        avago_addr_delete(aapl, &addr_struct);
        return show_hal_help();
    }

    aapl_connect(aapl, 0, 0); if( aapl->return_code < 0 ) return 1; /* EXIT */
    aapl_get_ip_info(aapl,0);

    /* If given a single, invalid address that isn't a useful type, complain: */
    if( addr_struct.next == 0
        && !aapl_check_ip_type(aapl, avago_struct_to_addr(&addr_struct), __func__, __LINE__, TRUE, 7,
                               AVAGO_SERDES, AVAGO_SERDES_D6_BROADCAST,
                               AVAGO_M4,     AVAGO_SERDES_M4_BROADCAST,
                               AVAGO_P1,     AVAGO_SERDES_P1_BROADCAST) )
        goto cleanup_and_exit; /* prevents invalid addresses from silently doing nothing */

    for( st = aapl_broadcast_first(aapl, &addr_struct, &start, &stop, &next, AAPL_BROADCAST_NO_ITER_LANE);
         st;
         st = aapl_broadcast_next(aapl, &next, &start, &stop, AAPL_BROADCAST_NO_ITER_LANE) )
    {
        uint addr = avago_struct_to_addr(&next);
        BOOL d6_hal = aapl_get_process_id(aapl, addr) == AVAGO_TSMC_07 && aapl_get_ip_type(aapl, addr) == AVAGO_SERDES;

        /* don't call (most) lower level functions unless they are serdes */
        if( !aapl_check_ip_type(aapl, addr, __func__,__LINE__,FALSE, 3, AVAGO_SERDES, AVAGO_M4, AVAGO_P1) )
            continue;

        if( !d6_hal && aapl_get_ip_type(aapl,addr) == AVAGO_SERDES )    /* Ignore on 16 and 28nm D6 */
            continue;

        /* Each of these returns error if called on an inappropriate device: */
        if( ctle_mask                   ) avago_serdes_ctle_apply(aapl, addr, ctle_mask, &ctle);
        if( rxffe_mask                  ) avago_serdes_rxffe_apply(aapl, addr, rxffe_mask, &rxffe);
        if( dfe_mask                    ) avago_serdes_dfe_apply(aapl, addr, dfe_mask, &dfe);
        if( vernier_cal_mask            ) avago_serdes_vernier_cal_apply(aapl, addr, vernier_cal_mask, &vernier_cal);
        if( vernier_delay_mask          ) avago_serdes_vernier_delay_apply(aapl, addr, vernier_delay_mask, &vernier_delay);
        if( rx_clocks_mask              ) avago_serdes_rx_clock_apply(aapl, addr, rx_clocks_mask, &rx_clocks);
        if( global_tune_params_mask     ) avago_serdes_global_tune_params_apply(aapl, addr, global_tune_params_mask, &global_tune_params);
        if( gradient_inputs_mask        ) avago_serdes_gradient_inputs_apply(aapl, addr, gradient_inputs_mask, &gradient_inputs);
        if( data_channel_inputs_mask    ) avago_serdes_data_channel_inputs_apply(aapl, addr, data_channel_inputs_mask, &data_channel_inputs);
        if( data_channel_cal_mask       ) avago_serdes_data_channel_cal_apply(aapl, addr, data_channel_cal_mask, &data_channel_cal);
        if( data_channel_cal_delta_mask ) avago_serdes_data_channel_cal_delta_apply(aapl, addr, data_channel_cal_delta_mask, &data_channel_cal_delta);
        if( test_channel_inputs_mask    ) avago_serdes_test_channel_inputs_apply(aapl, addr, test_channel_inputs_mask, &test_channel_inputs);
        if( test_channel_cal_mask       ) avago_serdes_test_channel_cal_apply(aapl, addr, test_channel_cal_mask, &test_channel_cal);
        if( pam4_levels_mask            ) avago_serdes_pam4_levels_apply(aapl, addr, pam4_levels_mask, &pam4_levels);
        if( pam4_eye_mask               ) avago_serdes_pam4_eye_apply(aapl, addr, pam4_eye_mask, &pam4_eye);

        if( get_all_tables )
        {
            get_ctle = get_dfe = get_rx_clocks = TRUE;
            {
                get_data_channel_inputs = get_data_channel_cal =
                get_test_channel_inputs = get_test_channel_cal = get_channel_tables = get_vernier_delay = TRUE;
                if( !d6_hal )
                    get_rxffe = get_vernier_cal = get_global_tune_params = get_data_channel_cal_delta =
                    get_gradient_inputs = get_vernier_tables = get_pam4_levels = get_pam4_eye = TRUE;
            }
        }

#define PRINT_REQUESTED(st) (AAPL_CONCAT(get_,st) || (AAPL_CONCAT(st,_mask) && enable_default_print))

        if( PRINT_REQUESTED(ctle) )
        {
            char *buf;
            Avago_serdes_ctle_t params;

            avago_serdes_ctle_read(aapl, addr, &params);
            buf = avago_serdes_ctle_print(aapl, addr, ~0, &params);
            printf("SBus %s, CTLE structure:\n{%s\n}\n", aapl_addr_to_str(addr), buf);
            aapl_free(aapl, buf, __func__);
        }
        if( PRINT_REQUESTED(rxffe) )
        {
            char *buf;
            Avago_serdes_rxffe_t params;

            avago_serdes_rxffe_read(aapl, addr, &params);
            buf = avago_serdes_rxffe_print(aapl, addr, ~0, &params);
            printf("SBus %s, RxFFE structure:\n{%s\n}\n", aapl_addr_to_str(addr), buf);
            aapl_free(aapl, buf, __func__);
        }

        if( PRINT_REQUESTED(dfe) )
        {
            char *buf;
            Avago_serdes_dfe_t params;

            avago_serdes_dfe_read(aapl, addr, &params);
            buf = avago_serdes_dfe_print(aapl, addr, ~0, &params);
            printf("SBus %s, DFE structure:\n{%s\n}\n", aapl_addr_to_str(addr), buf);
            aapl_free(aapl, buf, __func__);
        }

        if( get_vernier_tables )
        {
            int val;
            Avago_serdes_vernier_cal_t   cal;
            Avago_serdes_vernier_delay_t delay, reg;
            avago_serdes_vernier_cal_read(aapl, addr, &cal);
            avago_serdes_vernier_delay_read(aapl, addr, &delay);

            reg.upper_even_dly = vernier_decode(val = avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, 0xaa));
            reg.upper_odd_dly  = vernier_decode(val >> 8);
            reg.middle_even_dly= vernier_decode(val = avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, 0xb7));
            reg.middle_odd_dly = vernier_decode(val >> 8);
            reg.lower_even_dly = vernier_decode(val = avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, 0x91));
            reg.lower_odd_dly  = vernier_decode(val >> 8);
            reg.test_even_dly  = vernier_decode(val = avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, 0xac));
            reg.test_odd_dly   = vernier_decode(val >> 8);
            reg.edge_even_dly  = vernier_decode(val = avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, 0xab));
            reg.edge_odd_dly   = vernier_decode(val >> 8);
            reg.tap_dly        = vernier_decode(      avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, 0xb3));

#           define  DTAB_PRINT(F) printf("    %-15s : ( %3d        + 9 ) = %2d      %2d\n", \
                                  #F, delay.F, delay.F + 9, reg.F)
#           define CDTAB_PRINT(F) printf("    %-15s : ( %3d +  %3d + 9 ) = %2d      %2d\n", \
                                  #F, delay.AAPL_CONCAT(F,_dly), cal.AAPL_CONCAT(F,_cal), cal.AAPL_CONCAT(F,_cal) + delay.AAPL_CONCAT(F,_dly) + 9, reg.AAPL_CONCAT(F,_dly))
            printf("SBus %s, Vernier Tables (Consolidated):\n", aapl_addr_to_str(addr));
            printf("{\n    Field              delay    cal       Total  reg_value\n");
            CDTAB_PRINT(upper_even);
            CDTAB_PRINT(upper_odd);
            CDTAB_PRINT(middle_even);
            CDTAB_PRINT(middle_odd);
            CDTAB_PRINT(lower_even);
            CDTAB_PRINT(lower_odd);
            DTAB_PRINT(test_even_dly);
            DTAB_PRINT(test_odd_dly);
            DTAB_PRINT(edge_even_dly);
            DTAB_PRINT(edge_odd_dly);
            printf("    tap_dly         :   %3d                        %2d\n", delay.tap_dly, reg.tap_dly);
            printf("}\n");
        }

        if( PRINT_REQUESTED(vernier_delay) )
        {
            char *buf;
            Avago_serdes_vernier_delay_t params;

            avago_serdes_vernier_delay_read(aapl, addr, &params);
            buf = avago_serdes_vernier_delay_print(aapl, addr, ~0, &params);
            printf("SBus %s, Vernier delay structure:\n{%s\n}\n", aapl_addr_to_str(addr), buf);
            aapl_free(aapl, buf, __func__);
        }

        if( PRINT_REQUESTED(vernier_cal) )
        {
            char *buf;
            Avago_serdes_vernier_cal_t params;

            avago_serdes_vernier_cal_read(aapl, addr, &params);
            buf = avago_serdes_vernier_cal_print(aapl, addr, ~0, &params);
            printf("SBus %s, Vernier cal structure:\n{%s\n}\n", aapl_addr_to_str(addr), buf);
            aapl_free(aapl, buf, __func__);
        }

        if( PRINT_REQUESTED(rx_clocks) )
        {
            char *buf;
            Avago_serdes_rx_clocks_t params;

            avago_serdes_rx_clock_read(aapl, addr, &params);
            buf = avago_serdes_rx_clock_print(aapl, addr, ~0, &params);
            printf("SBus %s, RX clocks structure:\n{%s\n}\n", aapl_addr_to_str(addr), buf);
            aapl_free(aapl, buf, __func__);
        }

        if( PRINT_REQUESTED(global_tune_params) )
        {
            char *buf;
            Avago_serdes_global_tune_params_t params;

            avago_serdes_global_tune_params_read(aapl, addr, &params);
            buf = avago_serdes_global_tune_params_print(aapl, addr, ~0, &params);
            printf("SBus %s, Global tune params structure:\n{%s\n}\n", aapl_addr_to_str(addr), buf);
            aapl_free(aapl, buf, __func__);
        }
        if( PRINT_REQUESTED(gradient_inputs) )
        {
            char *buf;
            Avago_serdes_gradient_inputs_t params;

            avago_serdes_gradient_inputs_read(aapl, addr, &params);
            buf = avago_serdes_gradient_inputs_print(aapl, addr, ~0, &params);
            printf("SBus %s, Gradient input structure:\n{%s\n}\n", aapl_addr_to_str(addr), buf);
            aapl_free(aapl, buf, __func__);
        }
#if 0
        if( get_channel_tables && d6_hal )
        {
            Avago_serdes_data_channel_inputs_d6_t inputs, cal;
            Avago_serdes_test_channel_inputs_t test_inputs, test_cal;
            avago_serdes_data_channel_inputs_d6_read(aapl, addr, &inputs);
            avago_serdes_data_channel_cal_d6_read(   aapl, addr, &cal);
            avago_serdes_test_channel_inputs_read(   aapl, addr, &test_inputs);
            avago_serdes_test_channel_cal_read(      aapl, addr, &test_cal);

#           define D6_DATA_PRINT(F,R) printf("    %-7s ( %4d       %4d   )    %4d\n", \
                                  #F, inputs.F - 256, cal.F - 256, \
                                  255-(avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, R) & 0x1ff))
#           define D6_TEST_PRINT(F,R) printf("    %-7s ( %4d       %4d   )    %4d\n", \
                                  #F, test_inputs.F - 256, test_cal.F - 256, \
                                  255-(avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, R) & 0x1ff))
            printf("SBus %s, Data & Test Channel Tables (Consolidated):\n", aapl_addr_to_str(addr));
            printf("{\n    Field    Inputs-256  Cal-256   255-Reg\n");
            D6_DATA_PRINT(vos_d0e, 0x5df);
            D6_DATA_PRINT(vos_d0o, 0x5da);
            D6_DATA_PRINT(vos_d1e, 0x5e1);
            D6_DATA_PRINT(vos_d1o, 0x5dc);
            D6_TEST_PRINT(test_e,  0x5e3);
            D6_TEST_PRINT(test_o,  0x5de);
            D6_TEST_PRINT(edge_e,  0x5e2);
            D6_TEST_PRINT(edge_o,  0x5dd);
            printf("}\n");
        }
#endif
        if( get_channel_tables && !d6_hal )
        {
            Avago_serdes_data_channel_inputs_t inputs, cal, delta;
            Avago_serdes_test_channel_inputs_t test_inputs, test_cal;
            avago_serdes_data_channel_inputs_read(   aapl, addr, &inputs);
            avago_serdes_data_channel_cal_read(      aapl, addr, &cal);
            avago_serdes_data_channel_cal_delta_read(aapl, addr, &delta);
            avago_serdes_test_channel_inputs_read(   aapl, addr, &test_inputs);
            avago_serdes_test_channel_cal_read(      aapl, addr, &test_cal);

#           define DATA_PRINT(F,R) printf("    %-7s ( %4d     %+4d   %+4d ) = %4d    %4d\n", \
                                  #F, inputs.F, cal.F - 255, delta.F, inputs.F + cal.F - 255 + delta.F, \
                                  (avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, R) & 0x1ff) - 255)
#           define TEST_PRINT(F,R) printf("    %-7s ( %4d     %+4d        ) = %4d    %4d\n", \
                                  #F, test_inputs.F, test_cal.F - 255, test_inputs.F + test_cal.F - 255, \
                                  (avago_serdes_mem_rd(aapl, addr, AVAGO_ESB, R) & 0x1ff) - 255)
            printf("SBus %s, Data & Test Channel Tables (Consolidated):\n", aapl_addr_to_str(addr));
            printf("{\n    Field     Inputs  Cal-255  Delta   Total  Reg-255\n");
            DATA_PRINT(upper_e, 0x9a);
            DATA_PRINT(upper_o, 0x99);
            DATA_PRINT(mid_e  , 0xf7);
            DATA_PRINT(mid_o  , 0x96);
            DATA_PRINT(lower_e, 0xef);
            DATA_PRINT(lower_o, 0x95);
            TEST_PRINT(test_e,  0xf9);
            TEST_PRINT(test_o,  0x98);
            TEST_PRINT(edge_e,  0xee);
            TEST_PRINT(edge_o,  0x97);
            printf("}\n");
        }
        if( PRINT_REQUESTED(data_channel_inputs) )
        {
            char *buf;
            Avago_serdes_data_channel_inputs_t params;

            avago_serdes_data_channel_inputs_read(aapl, addr, &params);
            buf = avago_serdes_data_channel_inputs_print(aapl, addr, ~0, &params);
            printf("SBus %s, Data channel input structure:\n{%s\n}\n", aapl_addr_to_str(addr), buf);
            aapl_free(aapl, buf, __func__);
        }
        if( PRINT_REQUESTED(data_channel_cal) )
        {
            char *buf;
            Avago_serdes_data_channel_inputs_t params;

            avago_serdes_data_channel_cal_read(aapl, addr, &params);
            buf = avago_serdes_data_channel_inputs_print(aapl, addr, ~0, &params);
            printf("SBus %s, Data channel cal structure:\n{%s\n}\n", aapl_addr_to_str(addr), buf);
            aapl_free(aapl, buf, __func__);
        }
        if( PRINT_REQUESTED(data_channel_cal_delta) )
        {
            char *buf;
            Avago_serdes_data_channel_inputs_t params;

            avago_serdes_data_channel_cal_delta_read(aapl, addr, &params);
            buf = avago_serdes_data_channel_inputs_print(aapl, addr, ~0, &params);
            printf("SBus %s, Data channel cal delta structure:\n{%s\n}\n", aapl_addr_to_str(addr), buf);
            aapl_free(aapl, buf, __func__);
        }
        if( PRINT_REQUESTED(test_channel_inputs) )
        {
            char *buf;
            Avago_serdes_test_channel_inputs_t params;

            avago_serdes_test_channel_inputs_read(aapl, addr, &params);
            buf = avago_serdes_test_channel_inputs_print(aapl, addr, ~0, &params);
            printf("SBus %s, Test channel inputs structure:\n{%s\n}\n", aapl_addr_to_str(addr), buf);
            aapl_free(aapl, buf, __func__);
        }
        if( PRINT_REQUESTED(test_channel_cal) )
        {
            char *buf;
            Avago_serdes_test_channel_inputs_t params;

            avago_serdes_test_channel_cal_read(aapl, addr, &params);
            buf = avago_serdes_test_channel_inputs_print(aapl, addr, ~0, &params);
            printf("SBus %s, Test channel cal structure:\n{%s\n}\n", aapl_addr_to_str(addr), buf);
            aapl_free(aapl, buf, __func__);
        }
        if( PRINT_REQUESTED(pam4_levels) )
        {
            char *buf;
            Avago_serdes_pam4_levels_t params;

            avago_serdes_pam4_levels_read(aapl, addr, &params);
            buf = avago_serdes_pam4_levels_print(aapl, addr, ~0, &params);
            printf("SBus %s, PAM4 levels structure:\n{%s\n}\n", aapl_addr_to_str(addr), buf);
            aapl_free(aapl, buf, __func__);
        }
        if( PRINT_REQUESTED(pam4_eye) )
        {
            char *buf;
            Avago_serdes_pam4_eye_t params;

            avago_serdes_pam4_eye_read(aapl, addr, &params);
            buf = avago_serdes_pam4_eye_print(aapl, addr, ~0, &params);
            printf("SBus %s, PAM4 eye structure:\n{%s\n}\n", aapl_addr_to_str(addr), buf);
            aapl_free(aapl, buf, __func__);
        }
        if( get_ctle_limits )
        {
            Avago_serdes_ctle_limits_t limits;
            avago_serdes_ctle_get_limits(aapl, addr, &limits);
            printf(":%0x CTLE limits:", addr);
            print_values("hf", 0, limits.hf_max);
            print_values("lf", 0, limits.lf_max);
            {
                print_values("dc", 0, limits.dc_max);
                print_values("bw", 0, limits.bw_max);
                print_values("gainshape1", 0, limits.gainshape1_max);
                print_values("gainshape2", 0, limits.gainshape2_max);
                print_values("short_channel_en", 0, limits.short_channel_en_max);
            }
            printf("\n");
        }
        if( get_rxffe_limits && !d6_hal )
        {
            Avago_serdes_rxffe_limits_t limits;
            avago_serdes_rxffe_get_limits(aapl, addr, &limits);
            printf(":%0x RxFFE limits:", addr);
            print_values("pre2", limits.pre2_min, limits.pre2_max);
            print_values("pre1", 0, limits.pre1_max);
            print_values("post1", limits.post1_min, limits.post1_max);
            print_values("bflf", 0, limits.bflf_max);
            print_values("bfhf", 0, limits.bfhf_max);
            print_values("datarate", 0, limits.datarate_max);
            print_values("short_channel_en", 0, limits.short_channel_en_max);
            printf("\n");
        }
        if( get_dfe_limits )
        {
            Avago_serdes_dfe_limits_t limits;
            avago_serdes_dfe_get_limits(aapl, addr, &limits);
            printf(":%0x DFE limits:", addr);
            print_values("gaintap", limits.gaintap_min, limits.gaintap_max);
            print_values("gaintap2", limits.gaintap2_min, limits.gaintap2_max);
            print_values("gain2-3",  limits.gainx_min, limits.gainx_max);
            print_values("gain4-12 ",  limits.gainy_min, limits.gainy_max);
            printf("\n");
        }
    }
cleanup_and_exit:
    avago_addr_delete(aapl, &addr_struct);
    return (aapl->return_code < 0) ? 1 : 0;

}

#endif /* AAPL_ENABLE_MAIN && AAPL_ENABLE_SERDES_HAL */
