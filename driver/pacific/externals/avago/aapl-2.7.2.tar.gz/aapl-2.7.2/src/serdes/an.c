/* **************************************************************** */
/*                                                                  */
/* ASIC and ASSP Programming Layer (AAPL)                           */
/* Copyright (c) 2014-2018 Avago Technologies. All rights reserved. */
/*                                                                  */
/* **************************************************************** */
/* AAPL Revision: 2.7.2                                        */
/* AAPL (ASIC and ASSP Programming Layer) support for configuring */
/* and initiating AN (16nm only). */

/** Doxygen File Header */
/** @file */
/** @brief Functions related to the AN. */
/** @defgroup AutoNeg Auto-Negotiation API */
/** @{ */


#define AAPL_ENABLE_INTERNAL_FUNCTIONS
#include "aapl.h"

#if AAPL_ENABLE_SERDES_AUTO_NEG

static Aapl_conv_table_t an_hcd_table[] =
{
    /* These are IEEE 802.3 values from table 73-4. */
    { "200GBASE-KR4/CR4",       0x11 },
    { "100GBASE-KR2/CR2",       0x10 },
    { "50GBASE-KR/CR",          0x0e },
    { "5GBASE-KR",              0x0d },
    { "2.5GBASE-KX",            0x0c },
    { "25GBASE-KRCR",           0x0b },
    { "25GBASE-KRCR-S",         0x0a },
    { "100GBASE-CR4",           0x09 },
    { "100GBASE-KR4",           0x08 },
    { "100GBASE-KP4",           0x06 },
    { "100GBASE-CR10",          0x05 },
    { "40GBASE-CR4",            0x04 },
    { "40GBASE-KR4",            0x03 },
    { "10GBASE-KR",             0x02 },
    { "10GBASE-KX4",            0x01 },
    { "1000BASE-KX",            0x00 }
};

/** @brief  Converts an Aapl_comm_method_t value into a string. */
/** @return Returns a string representing the type. */
/** @see    aapl_str_to_comm_method(). */
const char *aapl_an_hcd_to_str(int value)
{
    Aapl_conv_table_t *table = an_hcd_table;
    int index = value_to_index(table,value);
    return index >= 0 ? table[index].name : (value & 7) == 7 ? "No-Selection" : "unknown";
}

/** @brief   Retrieves basic status information from an auto-negotiation block. */
/** @details This IP only in 28nm. */
/** @return  Returns TRUE on success. */
/** @return  Decrements aapl->return_code and returns FALSE on error. */
BOOL avago_an_get_info(
    Aapl_t *aapl,           /**< [in] Pointer to Aapl_t structure. */
    uint sbus_addr,         /**< [in] SBus address of SerDes */
    Avago_an_info_t *info)  /**< [out] Structure into which to place results */
{
    info->ip_rev = avago_sbus_rd(aapl, sbus_addr, 0x23) >> 1;
    info->enabled = avago_sbus_rd(aapl, sbus_addr, 0x00) & 1;
    info->hcd = avago_sbus_rd(aapl, sbus_addr, 0x2b);
    if( info->ip_rev == 0x01 && info->hcd == 0x07 )
        info->hcd = 0xf; /* Remap "No technology selected" */
    return TRUE;
}

/** @brief   Validates number of sbus addresses in the list required to configure lanes as per selected HCD. */
/** @return  If addr_list contains the necessary number of lanes, returns TRUE. */
/** @return  Otherwise, returns FALSE. */
/** @see     avago_serdes_an_configure_to_hcd(). */
static BOOL validate_addr_list(
    Avago_addr_t *addr_list,  /**< [in] Address list */
    uint lanes)               /**< [in] Required address lanes for HCD */
{
    Avago_addr_t *addr_struct;
    uint count = 0;

    for( addr_struct = addr_list; addr_struct != 0; addr_struct = addr_struct->next )
        count++;

    return count >= lanes;
}

/* Configure SerDes to NRZ operation and given divider and widths. */
static void setup_nrz(Aapl_t *aapl, uint addr, int divider, int tx_width, int rx_width, BOOL enable_tx_output)
{
    BOOL tx_ready, rx_ready;
    avago_serdes_set_tx_rx_enable(aapl, addr, FALSE, FALSE, FALSE); /* Disable serdes */
    avago_spico_int(aapl, addr, 0x05, 0x9000 | divider); /* set serdes bit/ref ratio */
    avago_serdes_set_tx_rx_width(aapl, addr, tx_width, rx_width);
    avago_serdes_set_tx_rx_enable(aapl, addr, TRUE, TRUE, enable_tx_output); /* enable serdes for next operations */
    avago_serdes_get_tx_rx_ready(aapl, addr, &tx_ready, &rx_ready);
    if( tx_ready != 1 || rx_ready != 1 )
        aapl_log_printf(aapl,AVAGO_WARNING,__func__,__LINE__, "Tx or Rx is not ready. Tx bit %d, Rx bit %d\n ", tx_ready, rx_ready);
}

/* See Clause 94.2.2 and 94.2.3 for required encoding. */
/* Encoding:  FEC encoder -> gray -> [precoding] -> PAM4 -> [predecoding] -> gray -> FEC decoder; precoding/decoding is optional. */
/* Configure SerDes to PAM4 operation and given divider and widths. */
static void setup_pam4(Aapl_t *aapl, uint addr, int divider, int tx_width, int rx_width, BOOL enable_tx_output)
{
    BOOL tx_ready, rx_ready;
    avago_serdes_set_tx_rx_enable(aapl, addr, FALSE, FALSE, FALSE); /* Disable serdes */
    avago_spico_int(aapl, addr, 0x05, 0x9000 | divider); /* set serdes bit/ref ratio */
    avago_serdes_set_tx_rx_width_pam(aapl, addr, tx_width, rx_width, AVAGO_SERDES_PAM4, AVAGO_SERDES_PAM4);
    avago_serdes_set_tx_rx_enable(aapl, addr, TRUE, TRUE, enable_tx_output); /* enable serdes for next operations */
    avago_serdes_get_tx_rx_ready(aapl, addr, &tx_ready, &rx_ready);
    if( tx_ready != 1 || rx_ready != 1 )
        aapl_log_printf(aapl,AVAGO_WARNING,__func__,__LINE__, "Tx or Rx is not ready. Tx bit %d, Rx bit %d\n ", tx_ready, rx_ready);
}

/* Configure SerDes to 1.25G NRZ operation. */
static void setup_1_25G_nrz(Aapl_t *aapl, uint addr, int tx_width, int rx_width)
{
    setup_nrz(aapl, addr, 8, tx_width, rx_width, TRUE); /* set serdes bit/ref ratio = 1.25G */
}

/* Rate from Clause 71.7.1.3: */
/* Configure SerDes to 3.125G operation on 1 or 4 lanes. */
static BOOL configure_3_125G_nrz(Aapl_t *aapl, Avago_addr_t *addr_list, int lanes, int tx_width, int rx_width)
{
    int count = 0;
    Avago_addr_t *addr_struct;

    if( !validate_addr_list(addr_list, lanes) )
        return FALSE;

    for( addr_struct = addr_list; addr_struct != 0 && count < lanes; addr_struct = addr_struct->next )
    {
        uint addr = avago_struct_to_addr(addr_struct);
        setup_nrz(aapl, addr, 20, tx_width, rx_width, TRUE); /* Set SerDes bit/ref ratio = 3.125G */
        count++;
    }
    return TRUE;
}

/* Rate from Clause 74.5.2: */
/* Configure SerDes to 5.15625G NRZ operation. */
static void setup_5_15625G_nrz(Aapl_t *aapl, uint addr, int tx_width, int rx_width)
{
    setup_nrz(aapl, addr, 33, tx_width, rx_width, TRUE); /* set serdes bit/ref ratio = 5.15625G */
}

/* Rate from Clause 94.2.2.8: */
/* Configure SerDes to 13.59375G PAM4 operation on given number of lanes. */
static BOOL configure_13_59375G_pam4(Aapl_t *aapl, Avago_addr_t *addr_list, int lanes, int tx_width, int rx_width)
{
    int count = 0;
    Avago_addr_t *addr_struct;

    if( !validate_addr_list(addr_list, lanes) )
        return FALSE;

    for( addr_struct = addr_list; addr_struct != 0 && count < lanes; addr_struct = addr_struct->next )
    {
        uint addr = avago_struct_to_addr(addr_struct);
        setup_pam4(aapl, addr, 87, tx_width, rx_width, TRUE); /* Set SerDes bit/ref ratio = 13.59375G */
        count++;
    }
    return TRUE;
}

/* Rate from Clause 74.5.2: */
/* Configure SerDes to 10.3125G NRZ operation on 1, 4 or 10 lanes.  Run PMD if pmd_config is not NULL. */
static BOOL configure_10_3125G_nrz(Aapl_t *aapl, Avago_addr_t *addr_list, int lanes, int tx_width, int rx_width, Avago_serdes_pmd_config_t *pmd_config)
{
    int count = 0;
    Avago_addr_t *addr_struct;

    if( !validate_addr_list(addr_list, lanes) )
        return FALSE;

    for( addr_struct = addr_list; addr_struct != 0 && count < lanes; addr_struct = addr_struct->next )
    {
        uint addr = avago_struct_to_addr(addr_struct);
        setup_nrz(aapl, addr, 66, tx_width, rx_width, !pmd_config); /* Set SerDes bit/ref ratio = 10.3125G */
        if( pmd_config )
        {
            pmd_config->sbus_addr = addr;
            pmd_config->lane = count++;
            avago_serdes_pmd_train(aapl, pmd_config);
            avago_serdes_set_tx_rx_enable(aapl, addr, TRUE, TRUE, TRUE); /* enable SerDes for next operations */
        }
    }
    return TRUE;
}

/* Rate from Clause 136.3 */
/* Configure SerDes to 25_78125G NRZ operation on 1, 2 or 4 lanes and run PMD. */
static BOOL configure_25_78125G_nrz(Aapl_t *aapl, Avago_addr_t *addr_list, int lanes, int tx_width, int rx_width, Avago_serdes_pmd_config_t *pmd_config)
{
    int count = 0;
    Avago_addr_t *addr_struct;

    if( !validate_addr_list(addr_list, lanes) )
        return FALSE;

    for( addr_struct = addr_list; addr_struct != 0 && count < lanes; addr_struct = addr_struct->next )
    {
        uint addr = avago_struct_to_addr(addr_struct);
        setup_nrz(aapl, addr, 165, tx_width, rx_width, FALSE); /* Set SerDes bit/ref ratio = 25.78125G */
        pmd_config->sbus_addr = addr;
        pmd_config->lane = count++;
        avago_serdes_pmd_train(aapl, pmd_config);
        avago_serdes_set_tx_rx_enable(aapl, addr, TRUE, TRUE, TRUE); /* enable SerDes for next operations */
    }
    return TRUE;
}

/* Rate from Clause 136.3 */
/* Configure SerDes to 26.5625G PAM4 operation on 1, 2 or 4 lanes and run PMD. */
static BOOL configure_26_5625G_pam4(Aapl_t *aapl, Avago_addr_t *addr_list, int lanes, int tx_width, int rx_width, Avago_serdes_pmd_config_t *pmd_config)
{
    int count = 0;
    Avago_addr_t *addr_struct;

    if( !validate_addr_list(addr_list, lanes) )
         return FALSE;

    for( addr_struct = addr_list; addr_struct != 0 && count < lanes; addr_struct = addr_struct->next )
    {
        uint addr = avago_struct_to_addr(addr_struct);
        setup_pam4(aapl, addr, 170, tx_width, rx_width, FALSE); /* Set SerDes bit/ref ratio = 26.5625G */
        pmd_config->sbus_addr = addr;
        pmd_config->lane = count++;
        avago_serdes_pmd_train(aapl, pmd_config);
        avago_serdes_set_tx_rx_enable(aapl, addr, TRUE, TRUE, TRUE); /* enable SerDes for next operations */
    }
    return TRUE;
}

/** @brief   Constructs an auto-negotiation structure. */
/** @details Allocates and initializes memory for configuring AN. */
/** @return  Allocated structure.  Call avago_serdes_an_config_destruct() to free it. */
Avago_serdes_an_config_t *avago_serdes_an_config_construct(Aapl_t *aapl)
{
    size_t bytes = sizeof(Avago_serdes_an_config_t);
    Avago_serdes_an_config_t *config;

    if( ! (config = (Avago_serdes_an_config_t *) aapl_malloc(aapl, bytes, __func__)) )
        return NULL;
    memset(config, 0, sizeof(*config));         /* set all bytes to zero */
    config->pmd_config = 0x02;
    return config;
}

/** @brief   Releases the resources associated with config. */
/** @see     avago_serdes_an_config_construct(). */
void avago_serdes_an_config_destruct(Aapl_t *aapl, Avago_serdes_an_config_t *config)
{
   aapl_free(aapl, config, "Avago_serdes_an_config_t struct");
}

/** @brief   Starts Auto Negotiation. */
/** @details Configures AN and loads Base page using Serdes Interrupt 0x29. */
/** @return  On success, returns 0. */
/** @see     avago_serdes_an_config_construct(), avago_serdes_an_config_destruct(). */
uint avago_serdes_an_start(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure. */
    uint addr,                          /**< [in] Serdes address */
    Avago_serdes_an_config_t *config)   /**< [in,out] The input configuration struct */
{
    int AN_input = 0x001; /* Enable AN */
    uint ret;

    uint pause = (config->pause & 0x1) << 10;
    uint asm_dir = (config->asm_dir & 0x1) << 11;
    uint np = (config->np_enable & 0x1) << 15;

    /* See 802.3 Table 73-4 for user_cap definitions. */
    uint cap = (config->user_cap & 0x07ff) << 5;
    uint cap2 = (config->user_cap & 0xf800) >> 11;

    uint fec_request = (((config->fec_ability & 0x1) << 14) |  ((config->fec_request & 0x1) << 15) |
                   ((config->fec_request & 0x2) << 11) | ((config->fec_request & 0x4) << 11));

    /* Base page bit definition (See 802.3 Clause 73.6 and Annex 28): */
    /* D[4:0] Selector field = 1 for 802.3 standard                    bit[15:0] configured through Int 0x0029 */
    /* D[9:5] contains the Echoed Nonce field */
    /* D[11:10] contains pause capability (see Annex 28B) */
    /* D[15:13] contains the RF, Ack, and NextPage bits                      bit[16:31] configured through Int 0x0129 */
    /* D[20:16] contains the Transmitted Nonce field */
    /* D[43:21] contains the Technology Ability field                  bit[47:32] configured through Int 0x0229 */
    /* D[44]    contains AN_RSFEC_ENABLE */
    /* D[45]    contains AN_FEC_ENABLE */
    /* D[47:46] contains FEC capability */

    /* Load base page using Serdes Interrupt 0x29 */
    avago_spico_int(aapl, addr, 0x0029, 0x0001 | np | pause | asm_dir);
    avago_spico_int(aapl, addr, 0x0129, (config->nonce_user_pattern & 0x1f) | cap);
    avago_spico_int(aapl, addr, 0x0229, fec_request | cap2 );

    /* Configure Auto KR */
    if(config->auto_kr)
    {
      avago_spico_int(aapl, addr, 0x0907, 0x01);
      avago_spico_int(aapl, addr, 0x0A07, config->pmd_config);
    }

    /* auto load device's next pages to null */
    if(config->np_continuous_load == 1)
       avago_spico_int(aapl, addr, 0x0507, 0x02);

    /* No change, same as base page */
    if( config->nonce_user_pattern > 0 )
        config->nonce_pattern_sel = 0x3;

    /* Set user settings from the config struct and enable Auto Negotiation */
    AN_input |= (config->an_clk                      & 0x1) <<  1;
    AN_input |= (config->disable_link_inhibit_timer  & 0x1) <<  2;
    AN_input |= (config->ignore_nonce_match          & 0x1) <<  3;
    AN_input |= (config->nonce_pattern_sel           & 0x3) <<  4;

    /* Final call to configure and execute Auto Negotiation */
    ret = avago_spico_int(aapl, addr, 0x0007, 0x0001 | AN_input);
    if( ret == 0x7 )
    {
        aapl_log_printf(aapl,AVAGO_DEBUG3, 0, 0, "Addr 0x%02x, AN_interrupt_input=0x%x, user_cap=0x%x, ret=%u\n", addr, (AN_input | 0x0001), config->user_cap,ret);
        return 0;
    }

    return ret;
}

/** @brief   Reads various status of AN. */
/** @details Call this to read various AN status. */
/** @return  On success, returns actual status. */
/** @return  On error, returns -1. */
int avago_serdes_an_read_status(
    Aapl_t *aapl,                    /**< [in] Pointer to Aapl_t structure */
    uint addr,                       /**< [in] Serdes address */
    Avago_serdes_an_status_t status) /**< structure defining various AN serdes status */
{
    switch( status )
    {
    case AVAGO_SERDES_AN_READ_HCD:
         return (avago_spico_int(aapl, addr, 0x0707, 0x0001) >>  0) & 0x1f;
    case AVAGO_SERDES_AN_READ_RSFEC_ENABLE:
         return (avago_spico_int(aapl, addr, 0x0707, 0x0001) >>  7) & 1;
    case AVAGO_SERDES_AN_READ_FEC_ENABLE:
         return (avago_spico_int(aapl, addr, 0x0707, 0x0001) >>  8) & 1;
    case AVAGO_SERDES_AN_BASE_PAGE_RX:
         return (avago_spico_int(aapl, addr, 0x0707, 0x0001) >>  9) & 1;
    case AVAGO_SERDES_AN_LP_AN_ABLE:
         return (avago_spico_int(aapl, addr, 0x0707, 0x0001) >> 12) & 1;
    case AVAGO_SERDES_AN_NEXT_PAGE_RX:
     /*  return (avago_spico_int(aapl, addr, 0x0707, 0x0001) >> 10) & 1; */
         return (avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x69) >> 1) & 1; /* o_next_page_rx */
    case AVAGO_SERDES_AN_COMPLETE:
         return (avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x69) >> 3) & 1; /* o_autoneg_complete */
    case AVAGO_SERDES_AN_GOOD:
         return (avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x69) >> 4) & 1; /* o_an_link_good */
    default:
         return -1;
    }
}

/** @brief Reads various status of AN.  Deprecated. */
/** @see avago_serdes_an_read_status(). */
int avago_serdes_read_an_status(
    Aapl_t *aapl,                    /**< [in] Pointer to Aapl_t structure */
    uint addr,                       /**< [in] Serdes address */
    Avago_serdes_an_status_t status) /**< structure defining various AN serdes status */
{
    return avago_serdes_an_read_status(aapl, addr, status);
}

/** @brief   Loads next page data and assert next page loaded bit. */
/** @details #data_buf contains the next page information to send */
/** @return  On success, returns 0. */
int avago_serdes_an_next_page_transmit(
    Aapl_t *aapl,                     /**< [in] Pointer to Aapl_t structure */
    uint addr,                        /**< [in] Serdes address */
    const char *data_buf                    /**< [in] 48-bit data buffer */
)
{
    uint i, j = 0, index = 0;
    long np_data[4] = {0};
    char temp[16];

    /* Convert 48-bit data into chunks of 15bits hex value */
    for( i = 0; i < 14; i++ )
    {
         temp[j++] = data_buf[i];
         if( (data_buf[i] == '_') || (data_buf[i] == ',') || (i == 13) )
         {
             temp[j] = '\0';
             j = 0;
             np_data[index++] = aapl_strtol(temp, NULL, 16);
         }
    }

    /* Next page bit definition: */
    /* D[10:0]  Message code field */
    /* D[15:11] NP, Ack, MP, Ack2, Toggle bit */
    /* D[47:16] Unformatted Code Field */
    /* Load next page using Serdes Interrupt 0x29 */
    avago_spico_int(aapl, addr, 0x0329, np_data[2] & 0xffff); /* bit[15:0] */
    avago_spico_int(aapl, addr, 0x0429, np_data[1] & 0xffff); /* bit [31:16] */
    avago_spico_int(aapl, addr, 0x0529, np_data[0] & 0xffff); /* bit [47:32] */

    /* allowing next page data transmission and reception to begin */
    avago_spico_int(aapl, addr, 0x0507, 0x1);

    return 0;
}

/** @brief   Monitors o_next_page_rx and validate the received data. */
/** @details #data_buf contains the transmitted data which is compared with the received data */
/** @return  On success, returns 0. */
/** @return  On error, returns -1. */
int avago_serdes_an_next_page_receive(
    Aapl_t *aapl,                     /**< [in] Pointer to Aapl_t structure */
    uint addr,                        /**< [in] Serdes address */
    const char *data_buf)             /**< [in] 48-bit data buffer */
{
    uint status = 0, i, j = 0, index = 0;
    int wait_time = 0;
    long np_data[4] = {0};
    char temp[16];
    long np_15_0, np_31_16, np_47_32;

    /* monitor o_base_page_rx */
    while( status == 0 && wait_time <= 200 )
    {
         status = avago_serdes_an_read_status(aapl, addr, AVAGO_SERDES_AN_NEXT_PAGE_RX);
         ms_sleep(10);
         wait_time+=10;
    }
    if (status != 1)
         return aapl_fail(aapl, __func__, __LINE__, "Fail to receive next page on 0x%02x \n", addr);

    aapl_log_printf(aapl,AVAGO_DEBUG4, __func__,__LINE__,"Received next page on 0x%02x\n", addr);

    /* verify next page data received */
    np_15_0  = avago_spico_int(aapl, addr, 0x0729, 0x0); /* Reads bit[15:0] of next page */
    np_31_16 = avago_spico_int(aapl, addr, 0x0729, 0x1); /* Reads bit[31:16] of next page */
    np_47_32  = avago_spico_int(aapl, addr, 0x0729,0x2); /* Reads bit[47:32] of next page */

    for( i = 0; i < 14; i++ )
    {
         temp[j++] = data_buf[i];
         if( (data_buf[i] == '_') || (data_buf[i] == ',') || (i == 13) )
         {
             temp[j] = '\0';
             j = 0;
             np_data[index++] = aapl_strtol(temp, NULL, 16);
         }
    }
    /* Compare read data with the received data */
    if( ((np_15_0 & 0x7ff) == (np_data[2] & 0x7ff)) &&
                           (np_31_16 == np_data[1]) &&
                           (np_47_32 == np_data[0]))
         aapl_log_printf(aapl,AVAGO_DEBUG4, __func__,__LINE__,"Received correct next page information on 0x%02x\n", addr);
    else
         return aapl_fail(aapl, __func__, __LINE__, "Received incorrect next page data on 0x%02x \n", addr);

    return 0;
}

/** @brief   Asserts link status for selected HCD technology. */
/** @return  On success, returns 0. */
/** @return  On error, returns -1. */
/** @see     avago_serdes_an_configure_to_hcd(). */
int avago_serdes_an_assert_link_status(
    Aapl_t *aapl,                     /**< [in] Pointer to Aapl_t structure */
    uint addr,                        /**< [in] Serdes address */
    uint an_hcd)                      /**< [in] Selected HCD */
{
    uint link_control;
    int return_code = aapl->return_code;
    int fw_rev = aapl_get_firmware_rev(aapl, addr);
    Avago_ip_type_t ip_type = aapl_get_ip_type(aapl,addr);
    if( ip_type == AVAGO_M4 || (fw_rev & 0xff) >= 0x6E )
        avago_spico_int(aapl, addr, 0x0107, (1<<15) | an_hcd);
    else if( an_hcd < 8 ) avago_spico_int(aapl, addr, 0x0107, (1 << an_hcd)); /* assert link status */
    else                  avago_spico_int(aapl, addr, 0x0107, (1 << (an_hcd-1)));

    /* Verify that o_link_control high bit is set: */
    link_control = avago_serdes_mem_rd(aapl, addr, AVAGO_LSB, 0x69) & 0x60;
    return ( (aapl->return_code == return_code) && (link_control & 0x40) ) ? 0 : -1;
}

/** @brief   Asserts link status, checks FEC/RSFEC bit and AN complete. */
/** @return  On success, returns 0. */
/** @return  On error, returns -1. */
/** @see     avago_serdes_an_configure_to_hcd(). */
int avago_serdes_an_complete(
    Aapl_t *aapl,                       /**< [in] Pointer to Aapl_t structure */
    uint addr,                          /**< [in] Device address number */
    uint an_hcd,                        /**< [in] Selected HCD */
    Avago_serdes_an_config_t *config)   /**< [in] The input configuration structure */
{
    uint status = 0;

    if( avago_serdes_an_assert_link_status(aapl, addr, an_hcd) == -1 )
        return aapl_fail(aapl, __func__, __LINE__, "SBus %s, Failed to assert link status.\n", addr);

    if( config->fec_ability == 1 || config->fec_request )
    {
        if( an_hcd == 0x00 || an_hcd == 0x01 )
            return aapl_fail(aapl, __func__, __LINE__, "Selected HCD 0x%02x does not support FEC enable.\n", an_hcd);

        if( config->fec_request & 0x2 )
        {
            status = avago_serdes_an_read_status(aapl, addr, AVAGO_SERDES_AN_READ_RSFEC_ENABLE);
            if (status != 1)
                return aapl_fail(aapl, __func__, __LINE__, "Fail to assert RSFEC Enable. Both devices should advertise FEC ability and at lease one device should request RSFEC.\n");
            aapl_log_printf(aapl,AVAGO_DEBUG4, __func__,__LINE__,"RSFEC enable bit asserted.\n");
        }
        else
        {
            status = avago_serdes_an_read_status(aapl, addr, AVAGO_SERDES_AN_READ_FEC_ENABLE);
            if (status != 1)
                return aapl_fail(aapl, __func__, __LINE__, "Fail to assert FEC Enable. Both devices should advertise FEC ability and at lease one device should request FEC.\n");
            aapl_log_printf(aapl,AVAGO_DEBUG4, __func__,__LINE__,"FEC enable bit asserted.\n");
        }
    }

    /* wait for AN complete */
    status = avago_serdes_an_wait_complete(aapl, addr, 10, 1000);
    if( status != 0 )
        return aapl_fail(aapl, __func__, __LINE__, "Fail to achieve AN Complete on 0x%02x\n", addr);

    aapl_log_printf(aapl,AVAGO_DEBUG3, __func__,__LINE__,"Auto-Negotiation completed on serdes on 0x%02x\n", addr);
    return 0;
}
static void disable_extra_lanes(
    Aapl_t *aapl,                   /**< [in] Pointer to Aapl_t structure */
    Avago_addr_t *addr_list,        /**< [in] List of Serdes addresses */
    int lanes_used)                 /**< [in] Count of lanes in use. */
{
    Avago_addr_t *addr_struct;
    for( addr_struct = addr_list; addr_struct != 0; addr_struct = addr_struct->next )
    {
        if( --lanes_used < 0 )
        {
            uint addr = avago_struct_to_addr(addr_struct);
            avago_serdes_set_tx_output_enable(aapl, addr, FALSE);
        }
    }
}

static int hcd_to_lanes(int hcd)
{
    int lanes = 1;
    switch( hcd )
    {
    case 0x00:
    case 0x02:
    case 0x0a:
    case 0x0b:
    case 0x0c:
    case 0x0d:
    case 0x0e: return  1;
    case 0x10: return  2;
    case 0x01:
    case 0x03:
    case 0x04:
    case 0x06:
    case 0x08:
    case 0x09:
    case 0x11: return  4;
    case 0x05: return 10;
    default: return  0;
    }
    return lanes;
}

/** @brief   Waits for given AN state before returning. */
/** @details Writes progress status to the INFO log if aapl->verbose is non-zero. */
/** @return  On AN state achieved, returns 0. */
/** @return  On timeout, returns -1 (will not timeout if timeout_ms == 0). */
static int avago_serdes_an_wait(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure */
    uint addr,          /**< [in] Device address number */
    uint poll_ms,       /**< [in] Frequency to poll AN status. */
    uint timeout_ms,    /**< [in] Minimum time to wait before timing out.  Pass 0 to never timeout. */
    Avago_serdes_an_status_t status) /**< enum defining various AN SerDes states */
{
    int count = -1;
    int an_status;
    while( !(an_status = avago_serdes_an_read_status(aapl, addr, status)) && an_status != -1 )
    {
        if( timeout_ms == 1 ) break;

        if( aapl->verbose && ++count % 20 == 0 ) /* Once per second */
        {
            aapl_log_printf(aapl, AVAGO_INFO, 0, 0, count == 0 ? "Waiting for AN" : ".");
            fflush(AAPL_STREAM);
        }
        ms_sleep(poll_ms);

        if( timeout_ms > poll_ms ) timeout_ms -= poll_ms;
        else if( timeout_ms != 0 ) timeout_ms = 1;
    }
    if( count >= 0 )
        aapl_log_printf(aapl, AVAGO_INFO, 0, 0, "\n");
    return an_status ? 0 : -1;
}

/** @brief   Waits for AN HCD to be negotiated before returning. */
/** @details Writes progress status to the INFO log if aapl->verbose is non-zero. */
/** @return  On AN good, returns 0. */
/** @return  On timeout, returns -1 (will not timeout if timeout_ms == 0). */
int avago_serdes_an_wait_hcd(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure */
    uint addr,          /**< [in] Device address number */
    uint poll_ms,       /**< [in] Frequency to poll AN status. */
    uint timeout_ms)    /**< [in] Minimum time to wait before timing out.  Pass 0 to never timeout. */
{
    return avago_serdes_an_wait(aapl, addr, poll_ms, timeout_ms, AVAGO_SERDES_AN_GOOD);
}

/** @brief   Waits for AN complete state. */
/** @details Writes progress status to the INFO log if aapl->verbose is non-zero. */
/** @return  On AN complete, returns 0. */
/** @return  On timeout, returns -1 (will not timeout if timeout_ms == 0). */
int avago_serdes_an_wait_complete(
    Aapl_t *aapl,       /**< [in] Pointer to Aapl_t structure */
    uint addr,          /**< [in] Device address number */
    uint poll_ms,       /**< [in] Frequency to poll AN status. */
    uint timeout_ms)    /**< [in] Minimum time to wait before timing out.  Pass 0 to never timeout. */
{
    return avago_serdes_an_wait(aapl, addr, poll_ms, timeout_ms, AVAGO_SERDES_AN_COMPLETE);
}

/** @brief   Reads HCD from first SerDes in list and configures SerDes group accordingly. */
/** @details Waits for AN HCD to be negotiated, then, if config->auto_kr is 0, configures */
/**          SerDes list according to the selected HCD and specified Tx and Rx widths. */
/** @return  On success, returns HCD value. */
/** @return  On error, returns -1. */
/** @see     avago_serdes_an_complete(), avago_serdes_an_assert_link_status(). */
int avago_serdes_an_configure_to_hcd(
    Aapl_t *aapl,                           /**< [in] Pointer to Aapl_t structure */
    Avago_addr_t *addr_list,                /**< [in] List of Serdes addresses */
    Avago_serdes_an_config_t *config,       /**< [in] The input AN configuration struct */
    Avago_serdes_pmd_config_t *pmd_config,  /**< [in,out] The input PMD configuration struct */
    int tx_width,                           /**< [in] The Tx core data bit width to set. */
    int rx_width)                           /**< [in] The Rx core data bit width to set. */
{
    uint an_hcd;
    uint an_addr = avago_struct_to_addr(addr_list); /* First address in list. */

    /* Wait for an_good which indicates valid HCD has been selected */
    if( 0 != avago_serdes_an_wait_hcd(aapl, an_addr, 10, 200) )
        return aapl_fail(aapl, __func__, __LINE__, "Failed to achieve AN link_good on %s\n", aapl_addr_to_str(an_addr));

    aapl_log_printf(aapl,AVAGO_DEBUG4, __func__,__LINE__,"Achieved AN link state on %s\n", aapl_addr_to_str(an_addr));

    /* Read HCD */
    an_hcd = avago_serdes_an_read_status(aapl, an_addr, AVAGO_SERDES_AN_READ_HCD);
    if( config->auto_kr )
        aapl_log_printf(aapl, AVAGO_INFO, __func__, __LINE__, "In case of auto_kr enable, no need to do setup.\n");
    else
    {
        BOOL wrong_lane_count = 0;
        uint lanes = hcd_to_lanes(an_hcd);
        const char *tech = aapl_an_hcd_to_str(an_hcd);
        if( lanes > 0 ) /* If valid HCD */
             aapl_log_printf(aapl,AVAGO_INFO, 0, 0,"HCD Technology selected on SerDes 0x%02x: %s\n", an_addr, tech);

        pmd_config->clause = AVAGO_PMD_NONE;    /* Will be overridden if PMD is performed. */
        switch(an_hcd)
        {
        case 0x00: /* 1000BASE-KX */
             if( !validate_addr_list(addr_list, lanes) ) { wrong_lane_count = TRUE; break; }
             setup_1_25G_nrz(aapl, an_addr, tx_width, rx_width);
             break;
        case 0x01: /* 10GBASE-KX4 */
        case 0x0c: /* 2.5GBASE-KX */
             wrong_lane_count = !configure_3_125G_nrz(aapl, addr_list, lanes, tx_width, rx_width);
             break;
        case 0x0d:  /* 5GBASE-KR */
             if( !validate_addr_list(addr_list, lanes) ) { wrong_lane_count = TRUE; break; }
             setup_5_15625G_nrz(aapl, an_addr, tx_width, rx_width);
             break;
        case 0x02:  /* 10GBASE-KR */
             pmd_config->clause = AVAGO_PMD_CL72;
             wrong_lane_count = !configure_10_3125G_nrz(aapl, addr_list, lanes, tx_width, rx_width, pmd_config);
             break;
        case 0x03: /* 40GBASE-KR4 */
        case 0x04: /* 40GBASE-CR4 */
        case 0x05: /* 100GBASE-CR10 */
             pmd_config->clause = AVAGO_PMD_CL92;
             wrong_lane_count = !configure_10_3125G_nrz(aapl, addr_list, lanes, tx_width, rx_width, pmd_config);
             break;
        case 0x06: /* 100GBASE-KP4 */
             wrong_lane_count = !configure_13_59375G_pam4(aapl, addr_list, lanes, tx_width, rx_width);
             break;
        case 0x08: /* 100GBASE-KR4 */
        case 0x09: /* 100GBASE-CR4 */
             pmd_config->clause = AVAGO_PMD_CL92;
             wrong_lane_count = !configure_25_78125G_nrz(aapl, addr_list, lanes, tx_width, rx_width, pmd_config);
             break;
        case 0x0a: /* 25GBASE-KRCR-S */
        case 0x0b: /* 25GBASE-KRCR */
             pmd_config->clause = AVAGO_PMD_CL72;
             wrong_lane_count = !configure_25_78125G_nrz(aapl, addr_list, lanes, tx_width, rx_width, pmd_config);
             break;
        case 0x0e: /* 50GBASE-KR/CR */
        case 0x10: /* 100GBASE-KR2/CR2 */
        case 0x11: /* 200GBASE-KR4/CR4 */
             pmd_config->clause = AVAGO_PMD_CL136;
             wrong_lane_count = !configure_26_5625G_pam4(aapl, addr_list, lanes, tx_width, rx_width, pmd_config);
             break;
        default:
        case 0x07:
        case 0x0f:
        case 0x1f:
             return aapl_fail(aapl, __func__, __LINE__, "No HCD Technology selected on SerDes 0x%02x.\n", avago_struct_to_addr(addr_list));
        }
        if( wrong_lane_count )
        {
            disable_extra_lanes(aapl, addr_list, 0);
            return aapl_fail(aapl, __func__, __LINE__,"For HCD Technology %d = %s, %d SBus address%s required.\n", an_hcd, tech, lanes, lanes == 1 ? " is" : "es are");
        }
        disable_extra_lanes(aapl, addr_list, lanes);
    }
    return an_hcd;
}

/** @} */

#endif /* AAPL_ENABLE_SERDES_AUTO_NEG */
